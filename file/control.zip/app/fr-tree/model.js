export { default } from 'framework-control/fr-tree/model';
