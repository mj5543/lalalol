export { default, frEqual } from 'framework-control/helpers/fr-equal';
