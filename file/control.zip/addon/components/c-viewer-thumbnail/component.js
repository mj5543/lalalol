import Ember from 'ember';
import layout from './template';
// import CHIS from 'framework/chis-framework';
import Control from '../c-control/component';

export default Control.extend({
  layout,
  filtName: null,
  thumbnailPosition: null,
  sliderWidth: null,
  thumbnailMargin: null,
  // itemSourceData: Ember.computed.alias('itemSource').readOnly(),
  itemSourceData: Ember.computed('itemSource', function() {
    const data = this.get('itemSource');
    if (!Ember.isEmpty(this.get('thumbnailMargin'))) {
      this.set('thumbnailMargin', 20);
    }
    if (!Ember.isEmpty(data)) {
      Ember.run.debounce(() => this.set('sliderWidth', (this.$().find('.thumbnail-item').width() + 20) * data.length));
    }
    return !Ember.isEmpty(data) ? (
      this._map(data, p => {
      let obj = {};
      obj.type = p.type;
      obj.src = p.src;
      obj.fileName = p.src.split('/')[p.src.split('/').length - 1];
      return obj;
    })
    ) : null;

  }).readOnly(),
  onPropertyInit(){
    this._super(...arguments);
    this.setStateProperties(['']);
    if (this.hasState() === false) {
      this.set('thumbnailMargin', 20);
      this.set('sliderWidth', 0);
    }
  },

  didInsertElement(){
    this._super(...arguments);
  },
  willDestroyElement() {
    this._super(...arguments);
  },
  actions: {
    selectedItem(e) {
      this._raiseEvents('selectedCB', e);
    },
    mouseWheel(e) {
      e.preventDefault();
      const wheel = e.deltaY < 0 ? 1 : -1;

      // wheel > 0 ?
    }
  }
});