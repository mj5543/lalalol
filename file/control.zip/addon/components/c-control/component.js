import Ember from 'ember';
import GlobalServiceContainerMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';

export default Ember.Component.extend(GlobalServiceContainerMixin, {
  classNameBindings: ['accessableClassName', 'readOnly:readonly'],
  attributeBindings: ['htmlSafeStyle:style', 'name'],
  accessableElements: null,
  notAccessable: Ember.computed.or('disabled', 'showLoader').readOnly(),
  destinationElementId: 'c-wormhole-container',
  componentGuid: Ember.computed(function () {
    return Ember.guidFor(this);
  }).readOnly(),
  htmlSafeStyle: Ember.computed('style', function () {
    if (!Ember.isNone(this.get('style'))) {
      return Ember.String.htmlSafe(this.get('style'));
    }
  }).readOnly(),
  accessableClassName: Ember.computed('disabled', 'showLoader', function () {
    const disabled = this.get('disabled'), loader = this.get('showLoader'), accessableElements = this.get('accessableElements');

    if (disabled || loader) {
      (this.$().is(':focus') ? this.$() : this.$(':focus')).blur();
      (this.$().is(':tabbable') ? this.$().add(this.$(':tabbable')) : this.$(':tabbable')).each(function (index, element) {
        accessableElements.addObject({ element: element, tabindex: Ember.$(element).attr('tabindex') });
        Ember.$(element).attr('tabindex', '-1');
      });

      return loader ? 'disabled loader spinner' : 'disabled';
    } else {
      accessableElements.forEach(function (o) {
        Ember.isNone(o.tabindex) ? Ember.$(o.element).removeAttr('tabindex') : Ember.$(o.element).attr('tabindex', o.tabindex);
      });
      accessableElements.clear();
    }
  }).readOnly(),
  init() {
    this._super(...arguments);
    this.set('accessableElements', Ember.A());
  },
  didInsertElement() {
    this._super(...arguments);
    if (this.useParentWormhole) {
      let wormholeParent = this.$().closest('.wormhole-parent');

      if (wormholeParent.length > 0) {
        this.set('destinationElementId', wormholeParent.children('.wormhole-container').attr('id'));
      }
      wormholeParent = null;
    }
    this.$().on('_getComponent', function (event, param) {
      param.component = this;
      event.stopPropagation();
      event.preventDefault();
    }.bind(this));
    this._raiseEvents('onLoaded', { source: this });
  },
  willDestroyElement() {
    this._raiseEvents('onUnload', { source: this });
    this.$().off('_getComponent');
    this._super(...arguments);
  },
  _getComponent($target) {
    let param = { component: {} }, component = null;

    $target.trigger('_getComponent', param);
    component = param.component;
    param.component = null;
    param = null;

    return component;
  },
  _raiseEvents(name, args) {
    if (!Ember.isNone(this.get(name))) {
      if (Ember.isArray(args)) {
        return this.get(name)(...args);
      } else {
        return this.get(name)(args);
      }
    }
  },
  _releaseObjectProperty(obj) {
    if (obj instanceof Object) {
      Object.getOwnPropertyNames(obj).forEach(function (prop) {
        Ember.set(obj, prop, null);
      });
    }
  },
  // 자주 쓰는 함수 추가. 안병철
  _curry(f) {
    (a, ..._) => _.length ? f(a, ..._) : (..._) => f(a, ..._);
  },
  _map(iter, f) {
    let res = [];
    for (const a of iter) {
      res.push(f(a));
    }
    return res;
  },
  _filter(iter, f) {
    let res = [];
    for (const a of iter) {
      if (f(a)) res.push(a);
    }
    return res;
  },
  _reduce(iter, f, acc) {
    if (!iter) {
      iter = acc[Symbol.iterator()];
      acc = iter.next().value;
    }
    for (const a of iter) {
      acc = f(acc, a);
    }
    return acc;
  }
});