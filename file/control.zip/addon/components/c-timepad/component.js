
import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';

export default Control.extend({
  layout,
  tagName: 'div',
  classNames: ['c-timepad'],
  classNameBindings: ['isEmbeded:datepicker'],
  selectedTime: null,
  _timer: 0,
  _baseTime: null,
  _currentTime: Ember.computed('_timer', '_baseTime', function () {
    if (!this.get('isDestroying') && !this.get('isDestroyed')) {
      let _baseTime = this.get('_baseTime'), _timer = this.get('_timer');

      if (Ember.isNone(_baseTime) || 180 < _timer) {
        _baseTime = moment(this.get('co_CommonService').getNow());
        this.set('_baseTime', _baseTime);
        _timer = 0;
      }
      Ember.run.later(this, function () {
        if (!this.get('isDestroying') && !this.get('isDestroyed')) {
          _baseTime.add(1, 'seconds');
          this.set('_timer', _timer + 1);
        } else {
          _baseTime = null;
          _timer = null;
        }
      }, 1000);

      return _baseTime.toDate();
    }
  }).readOnly(),
  displayHours: Ember.computed('selectedTime', {
    get () {
      if (this.get('selectedTime') instanceof Date && !isNaN(this.get('selectedTime').valueOf())) {
        return moment(this.get('selectedTime')).format('hh');
      }

      return moment(`${moment(this.get('co_CommonService').getNow()).format('YYYY-MM-DD')} 00:00`, 'YYYY-MM-DD HH:mm').format('hh');
    },
    set (key, value) {
      return value;
    },
  }),
  displayMinutes: Ember.computed('selectedTime', {
    get () {
      if (this.get('selectedTime') instanceof Date && !isNaN(this.get('selectedTime').valueOf())) {
        return moment(this.get('selectedTime')).format('mm');
      }

      return moment(`${moment(this.get('co_CommonService').getNow()).format('YYYY-MM-DD')} 00:00`, 'YYYY-MM-DD HH:mm').format('mm');
    },
    set (key, value) {
      return value;
    },
  }),
  isAM: Ember.computed('selectedTime', function () {
    if (this.get('selectedTime') instanceof Date && !isNaN(this.get('selectedTime').valueOf())) {
      return moment(this.get('selectedTime')).hours() < 12;
    }

    return moment(`${moment(this.get('co_CommonService').getNow()).format('YYYY-MM-DD')} 00:00`, 'YYYY-MM-DD HH:mm').hours() < 12;
  }),
  _observedProperty1: Ember.computed('selectedTime', function () {
    Ember.run.once(this, '_selectedTimeChanged');
  }).readOnly(),
  didInsertElement() {
    this._super(...arguments);
    this.$('input:eq(0)').inputmask({ alias: 'datetime', placeholder: '-', inputFormat: 'hh', });
    this.$('input:eq(1)').inputmask({ alias: 'datetime', placeholder: '-', inputFormat: 'MM', });
  },
  willDestroyElement() {
    this.$('input').each(function (idx, el) { if (el.inputmask) { el.inputmask.remove(); } });
    this._super(...arguments);
  },
  mouseDown(event) {
    if (!this.$(event.target).is('input')) {
      event.preventDefault();
    }
  },
  focusOut(event) {
    this._syncDataValue();
  },
  _selectedTimeChanged() {
    if (this.hasLoaded) {
      this._raiseEvents('onSelectedTimeChanged', {
        source: this,
        selectedTime: this.get('selectedTime'),
      });
    }
  },
  _syncDataValue() {
    let currentMoment = null;

    if (this.get('selectedTime') instanceof Date && !isNaN(this.get('selectedTime').valueOf())) {
      currentMoment = moment(this.get('selectedTime'));
    } else {
      currentMoment = moment(`${moment(this.get('co_CommonService').getNow()).format('YYYY-MM-DD')} 00:00`, 'YYYY-MM-DD HH:mm');
    }
    if (this.$('input:eq(0)').inputmask('isComplete')) {
      const hours = parseInt(this.get('displayHours'));
      
      if (currentMoment.hours() < 12) {
        currentMoment.hours(hours === 12 ? 0 : hours);
      } else {
        currentMoment.hours(hours + 12 === 24 ? 12 : hours);
      }
    } else {
      currentMoment.hours(currentMoment.hours() < 12 ? 0 : 12);
    }
    if (this.$('input:eq(1)').inputmask('isComplete')) {
      currentMoment.minutes(parseInt(this.get('displayMinutes')));
    } else {
      currentMoment.minutes(0);
    }
    Ember.run.once(this, '_setSelectedTime', currentMoment.toDate())
    currentMoment = null;
  },
  _setSelectedTime(date) {
    this.set('selectedTime', date);
    Ember.run.schedule('afterRender', this, function () {
      if (!this.get('isDestroying') && !this.get('isDestroyed')) {
        this.$('input:eq(0)').val(moment(date).format('hh'));
        this.$('input:eq(1)').val(moment(date).format('mm'));
      }
    });
  },
  actions: {
    updateStart(param1, param2, param3) {
      let currentDelay = 250, repeat = param3, updateStart = function() {
        if (!this.get('isDestroying') && !this.get('isDestroyed')) {
          let currentMoment = null;
  
          if (this.get('selectedTime') instanceof Date && !isNaN(this.get('selectedTime').valueOf())) {
            currentMoment = moment(this.get('selectedTime'));
          } else {
            currentMoment = moment(`${moment(this.get('co_CommonService').getNow()).format('YYYY-MM-DD')} 00:00`, 'YYYY-MM-DD HH:mm');
          }
          const dates = currentMoment.dates(), hours = currentMoment.hours();
          
          if (!(param1 === -12 && hours < 12) && !(param1 === 12 && 12 <= hours)) {
            currentMoment.add(param1, param2);
            if (param1 === -1 && param2 === 'hours' && (hours === 0 || hours === 12)) {
              currentMoment.add(-12, 'hours');
            }
            if (param1 === 1 && param2 === 'hours' && (hours === 11 || hours === 23)) {
              currentMoment.add(12, 'hours');
            }
            if (param2 === 'minutes') {
              currentMoment.hours(hours);
            }
            currentMoment.dates(dates);
            this.set('selectedTime', currentMoment.toDate());
            Ember.run.later(this, function () {
              if (!this.get('isDestroying') && !this.get('isDestroyed') && repeat) {
                currentDelay = 100;
                updateStart();
              } else {
                currentDelay = null;
                repeat = null;
                updateStart - null;
              }
            }, currentDelay);
          }
        }
      }.bind(this);
      this.$(event.currentTarget).on('mouseup mouseleave', function () {
        repeat = false;
        this.$(event.currentTarget).off('mouseup mouseleave');
      }.bind(this));
      updateStart();
    },
    setCurrentTime() {
      this.set('selectedTime', moment(this.get('co_CommonService').getNow()).toDate());
    },
    currentTimeDoubleClick(event) {
      this._raiseEvents('onInternalCurrentTimeDoubleClick', {
        source: this,
        originalEvent: event,
        selectedTime: this.get('selectedTime'),
      });
    },
  }
});