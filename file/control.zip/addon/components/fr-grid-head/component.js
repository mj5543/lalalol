import Ember from 'ember';
import layout from './template';

const { computed } = Ember;

export default Ember.Component.extend({
  tagName: 'thead',
  classNameBindings: [ '_hasMultiHeader:tbl-grid-dheader' ],
  layout,

  _notHasFrozen: computed.not('_readOnly').readOnly(),
  _frozenTableOrNotHasFrozen: computed.or('_frozenTable', '_notHasFrozen').readOnly(),
  _flexResizeType: computed.equal('columnResizeType', 'flex').readOnly(),
  _notFlexResizeType: computed.not('_flexResizeType').readOnly(),
});