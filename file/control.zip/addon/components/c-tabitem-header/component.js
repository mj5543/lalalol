import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';

export default Control.extend({
  attributeBindings: ['watchSelectedTabName:data-name'],
  layout,
  tagName : 'li',
  classNames: ['ui-state-default'],
  // == Public Properties ====================
  dataItem : null,
  content : null,
  hasSelected : false,
  enableTabClose : false,
  tooltipDisabled: false,
  tooltip: null,
  // == Public Events ========================
  selected : null,
  closing : null,
  // adding: null,
  // == Computed Properties ==================
  watchSelectedTabName: Ember.computed('name', 'selectedTabName', function() {
    if ( !Ember.isEmpty(this.get('selectedTabName')) && this.get('name') === this.get('selectedTabName')) {
      if (this.enableTabClose) {
        this.set('hasSelected', true) ;
        this.$().addClass('close');
      }
      this.$().addClass('c-tab-active').addClass('on').addClass('active');
    } else {
      this.set('hasSelected', false);
      this.$().removeClass('close').removeClass('c-tab-active').removeClass('on').removeClass('active');
    }
    this.set('tooltip', this.get('selectedTabName'));
    Ember.run.next(this, function () {
      if (!this.get('isDestroying') && !this.get('isDestroyed')) {
        Ember.run.once(this, () => {
          this._changeTab();
        });
      }
    });
    // Ember.run.once(this, () => {
    //   this._changeTab();
    // });

    return this.get('name') ;
  }).readOnly(),
  _changeTab() {
    const tabli = this.$();

    const clone = tabli.clone()
      .css({display: 'inline', width: 'auto', visibility: 'hidden'})
      .appendTo('body');

    if(clone.width() + 10 > tabli.width()) {
      if(this.get('tooltipDisabled')) {
        this.set('tooltipDisabled', false);
      }
    } else {
      this.set('tooltipDisabled', true);
    }
    // clone.width() + 30 > tabli.width() ? this.set('isTooltip', true) : this.set('isTooltip', false);
    Ember.run.debounce(() => clone.remove(), 10);
  },
  didInsertElement(){
    this._super(...arguments);

    if ( this.get('name') === this.get('selectedTabName')) {
      if (this.enableTabClose === true) {
        this.$().addClass('close');
      }

      this.$().addClass('c-tab-active').addClass('on').addClass('active');
    }

  },
  actions: {
    onSelectedAction() {
      this._raiseEvents('selected', { id : this.get('name') });
    },
    onTabClosingAction(e) {
      e.preventDefault();
      e.stopPropagation();

      this._raiseEvents('closing', { source : null, originalSource : this, cancel : false}) ;
    }
  }
});