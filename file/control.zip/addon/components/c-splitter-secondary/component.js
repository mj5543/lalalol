import layout from './template';
import Control from '../c-control/component';

export default Control.extend({
  tagName: 'div',
  layout,
  classNames: ['panel-secondary']
});