import Ember from 'ember';
import Template from './template';
import Selector from '../fr-selector/component';
import ContextMenuMixin from '../../mixins/contextmenu-mixin';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

//== TreeVew
export default Selector.extend(ContextMenuMixin, StatefulComponentMixin, {
  layout: Template,
  tagName: 'div',
  classNames: ['fr-treeview'],
  // == Component properties ===========================
  //_treeViewItem: null,
  expandedItems: null,
  //_activateItem: null,
  // == Component properties ===========================
  allowEditallowEdit: false,
  checkBoxPath: null,
  childrenMemberPath: 'children',
  expandedDepth: 1,
  isCheckBoxVisible: false,
  isLeafNodeMemberPath: null,
  generatrUniqueId: false,
  editItemTemplate: null,
  isDrop: false,
  // == Public Events ==================================
  expanded: null,
  collapsed: null,
  editModeStarting: null,
  editModeEnded: null,
  mouseDoubleClick: null,
  checked: null,
  unchecked: null,
  // == Public Events =================================
  findItem(isSelected, value) {
    const findItem = this.get('_items').findBy(this.get('selectedValuePath'), value);

    if (!Ember.isNone(findItem)) {
      const itemPath = this._getItemPath(findItem), component = this._getComponent(this.$().find(`li[data-item-path="${itemPath}"]`));

      if (isSelected) {
        this.set('selectedItem', findItem);
      }

      return component;
    }

    return null;
  },
  collapseAll() {
    const expandedItems = this.get('expandedItems');

    expandedItems.clear();
  },
  expandAll(depth) {
    const expandedItems = this.get('expandedItems'), _items = this.get('_items');

    expandedItems.clear();
    if (!Ember.isNone(depth) && !isNaN(depth)) {
      expandedItems.addObjects(this._getChilrenItemsWithDepth(this.get('itemsSource'), depth));
    } else {
      expandedItems.addObjects(_items);
    }
  },
  // == Event Hook  ===================================
  init() {
    this._super(...arguments);

    if (this.get('generatrUniqueId')) {
      this.get('itemsSource').forEach(this._addUniqueId(1).bind(this));
    }
  },
  onPropertyInit() {
    this._super(...arguments);

    this.setStateProperties([ 'expandedItems'/*, '_activateItem'*/ ]);
    if (!this.hasState()) {
      const expandedItems = Ember.A(), expandedDepth = this.get('expandedDepth');

      if (!Ember.isNone(expandedDepth) && !isNaN(expandedDepth)) {
        expandedItems.addObjects(this._getChilrenItemsWithDepth(this.get('itemsSource'), this.get('expandedDepth')));
      }
      this.set('expandedItems', expandedItems);
      //this.set('_activateItem', null);
    }
  },
  didInsertElement() {
    this._super(...arguments);

    this.$().on('_getComponent', function (event, param) {
      param.component = this;
      event.stopPropagation();
      event.preventDefault();
    }.bind(this));
  },
  willDestroyElement() {
    this._super(...arguments);

    this.$().off('_getComponent');
  },
  // == Private Methods ===============================
  _addUniqueId(id) {
    return function iter(o) {
      if ((this.selectedValuePath in o) === false) {
        Ember.set(o, this.selectedValuePath, id++);
      }
      Object.keys(o).forEach(function (k) {
        Array.isArray(o[k]) && o[k].forEach(iter.bind(this));
      }.bind(this));
    };
  },
  /*
  _isExpanded(uniqueId) {
    return this.get('expandedItems').includes(uniqueId);
  },
  */
  keyDown(event) {
    if (this.allowEdit && event.keyCode === 13) {
      const $target = this.$(event.target).closest('.fr-treeviewitem');

      if ($target.length > 0) {
        const component = this._getComponent($target), arg = { 'source': this, 'originalSource': component, 'cancel': false };

        this._raiseEvents('editModeStarting', arg);
        if (!arg.cancel) {
          component.editMode();
        }
      }
    }
  },
  _treeViewGuid: Ember.computed(function () {
    return Ember.guidFor(this);
  }).readOnly(),
  _observedProperty1: Ember.computed('selectedItem', function () {
    if (this.hasLoaded) {
      Ember.run.once(this, this._selectedChanged);
    }

    return null;
  }).readOnly(),
  _observedProperty2: Ember.computed('itemsSource.[]', function () {
    Ember.run.once(this, this._itemsSourceChange);

    return null;
  }).readOnly(),
  _items: Ember.computed('itemsSource.[]', function () {
    const _items = Ember.A(), itemsSource = this.get('itemsSource');

    if (Ember.isArray(itemsSource)) {
      _items.addObjects(this._getChilrenItems(itemsSource));
    }

    return _items;
  }).readOnly(),
  _getChilrenItems(childrenItems) {
    const items = Ember.A();

    if (Ember.isArray(childrenItems)) {
      childrenItems.forEach(function (child) {
        items.addObjects(this._getChilrenItems(Ember.get(child, this.get('childrenMemberPath'))));
      }.bind(this));
      items.addObjects(childrenItems);
    }

    return items;
  },
  _getChilrenItemsWithDepth(childrenItems, depth) {
    const items = Ember.A();

    if (0 < depth && Ember.isArray(childrenItems)) {
      childrenItems.forEach(function (child) {
        items.addObjects(this._getChilrenItemsWithDepth(Ember.get(child, this.get('childrenMemberPath')), depth - 1));
      }.bind(this));
      items.addObjects(childrenItems);
    }

    return items;
  },
  _itemsSourceChange() {
    const selectedItem = this.get('selectedItem'), _items = this.get('_items');

    if (!Ember.isNone(selectedItem) && !_items.includes(selectedItem)) {
      this.set('selectedItem', null);
    }

    const expandedItems = this.get('expandedItems'), expandedItemsGarbage = Ember.A();

    if (Ember.isEmpty(_items) && !Ember.isEmpty(expandedItems)) {
      expandedItems.clear();
    } else {
      expandedItems.forEach(function (item) {
        if (!_items.includes(item)) {
          expandedItemsGarbage.addObject(item);
        }
      });
      if (!Ember.isEmpty(expandedItemsGarbage)) {
        expandedItems.removeObjects(expandedItemsGarbage);
      }
    }
  },
  _getItemPath(item) {
    const itemsSource = this.get('itemsSource');
    let path = '';

    if (!Ember.isNone(item) && Ember.isArray(itemsSource)) {
      for (let i = 0; i < itemsSource.length; i++) {
        path = this._getItemSubPath(item, itemsSource[i], i);
        if (!Ember.isEmpty(path)) {
          path = this.get('_treeViewGuid') + '-' + path;
          break;
        }
      }
    }

    return path;
  },
  _getItemSubPath(item, sourceItem, index) {
    let subPath = '';

    if (item === sourceItem) {
      subPath = index.toString();
    } else {
      const childrenItems = Ember.get(sourceItem, this.get('childrenMemberPath'));

      if (Ember.isArray(childrenItems)) {
        for (let i = 0; i < childrenItems.length; i++) {
          subPath = this._getItemSubPath(item, childrenItems[i], i);
          if (!Ember.isEmpty(subPath)) {
            subPath = index.toString() + '-' + subPath;
            break;
          }
        }
      }
    }

    return subPath;
  },
  _selectedChanged() {
    const selectedItem = this.get('selectedItem');

    if(!Ember.isNone(selectedItem)) {
      const itemPath = this._getItemPath(selectedItem), component = this._getComponent(this.$().find(`li[data-item-path="${itemPath}"]`)), parentComponent = component.getParent();

      this._raiseEvents('selectedChanged', {
        source: this,
        originalSource: component,
        dataItem: Ember.get(component, 'dataItem'),
        parent: parentComponent
      });
    } else {
      this._raiseEvents('selectedChanged', {
        source: this,
        originalSource: null,
        dataItem: null,
        parent: null
      });
    }
  },
  _getComponent($target) {
    let param = { component: {} }, component = null;

    $target.trigger('_getComponent', param);
    component = param.component;
    param.component = null;
    param = null;

    return component;
  },
  _onContextMenuOpening(e) {
    const $target = this.$(e.originalEvent.target).closest('.fr-treeviewitem');

    if ($target.length > 0) {
      const component = this._getComponent($target), parentComponent = component.getParent(), dataItem = Ember.get(component, 'dataItem');
      e.originalSource = this._getComponent($target);
      e.parent = parentComponent;
      e.dataItem = dataItem;
      if (!this.get('disableContextmenuNodeSelection')) {
        this.set('selectedItem', dataItem);
      }
    }
    /*
    if (element.length === 0) {
      if (!Ember.isEmpty(this._treeViewItem)) {
        this._treeViewItem._onDeactive();
      }
      this._treeViewItem = null;
    } else {

      this.$(element).trigger('onactivate', e);

      if (!Ember.isEmpty(this._treeViewItem)) {
        if (this._treeViewItem === e.originalSource) {
          return false;
        } else {
          this._treeViewItem._onDeactive();
        }
      }

      if (!Ember.isEmpty(e.originalSource)) {
        this._treeViewItem = e.originalSource;
        this.set('selectedItem', e.originalSource.get('dataItem'));
        //this._onActivate(e);
      }
    }
    */
  },
  /*
  _onMouseDoubleclick(e) {
    this._raiseEvents('mouseDoubleClick', e)
  },
  _onCollapsed(e) {
    this._raiseEvents('collapsed', e);
  },
  _onExpanded(e) {
    this._raiseEvents('expanded', e);
  },
  _onToggle(isExpanded, uniqueId) {
    if (isExpanded === false) {
      this.get('expandedItems').removeObject(uniqueId);
    } else {
      this.get('expandedItems').addObject(uniqueId);
    }
  },
  _onActivate(e) {
    this.$('.item').removeClass('selected');
    this.$('.fr-treeviewitem').attr('draggable', false);
    if (!Ember.isEmpty(e) && !Ember.isEmpty(e.originalSource)) {
      e.originalSource.set('isActive', true);
      this.set('_activateItem', e.originalSource.get(`dataItem.${this.selectedValuePath}`));
    }
  },
  */
  _onEndEidtMode(e) {
    //this._raiseEvents('editModeEnded', e);
  },
  _onSelected(e) {
    //this.set('selectedItem', e.originalSource.get('dataItem'));
  /*
    if (!Ember.isEmpty(this._treeViewItem)) {
      if (this._treeViewItem === e.originalSource) {
        return false;
      } else {
        this._treeViewItem._onDeactive();
      }
    }

    this.set('selectedItem', e.originalSource.get('dataItem'));
    this._treeViewItem = e.originalSource;
    this._onActivate(e);
    this._raiseEvents('selectedChanged', e);
*/
  },
  _onChecked(e) {
    //this._raiseEvents('checked', e);
  },
  _onUnChecked(e) {
    //this._raiseEvents('unchecked', e);
  }
});