import Ember from 'ember';
import Control from '../fr-control/component';

// == TextArea =======================================================

export default Control.extend({
  classNames: [ 'fr-textarea', 'scrollbar-macosx' ],
  tagName: 'textarea',
  attributeBindings: [ /*'_observedAttribute', */'autocomplete', 'autocorrect', 'autocapitalize', 'spellcheck', 'disabled:disabled',
    'readonly:readonly', 'required:required', 'tabindex', 'name', 'type', 'title', 'placeholder', 'autofocus',
    'value', 'pattern', 'min', 'max', 'maxlength', 'pattern', 'size', 'step' ],
  autocomplete: 'off',
  autocorrect: 'off',
  autocapitalize: 'off',
  spellcheck: false,
  updateSourceTrigger: false,
  autoHeight: false,
  //defaultHeight:null,
  /*_observedAttribute: Ember.computed('isDataSucess', 'isDataError', 'disabled', 'readonly', function () {
    Ember.run.schedule('afterRender', this, function () {
      if (!this.get('isDestroying') && !this.get('isDestroyed')) {
        if (this.get('isDataSucess')) {
          this.$().closest('.scroll-textarea').addClass('ok');
        } else {
          this.$().closest('.scroll-textarea').removeClass('ok');
        }
        if (this.get('isDataError')) {
          this.$().closest('.scroll-textarea').addClass('error');
        } else {
          this.$().closest('.scroll-textarea').removeClass('error');
        }
        if (this.get('disabled')) {
          this.$().closest('.scroll-textarea').addClass('disabled');
        } else {
          this.$().closest('.scroll-textarea').removeClass('disabled');
        }
        if (this.get('readonly')) {
          this.$().closest('.scroll-textarea').addClass('readonly');
        } else {
          this.$().closest('.scroll-textarea').removeClass('readonly');
        }
      }
    });

    return null;
  }),*/
  _onBlur() {
    if (this.updateSourceTrigger === false) {
      this.set('value', this.$().val());
    }
  },
  _onChange() {
    if (this.updateSourceTrigger) {
      this.set('value', this.$().val());
    }
    if (this.autoHeight) {
      this._autoGrow();
    }
  },

  _autoGrow() {
    if(this.defaultHeight < this.$().prop('scrollHeight')){
      this.$().css('height', 'auto');
      this.$().height(this.$().prop('scrollHeight') + 12);
    } else {
      this.$().css('height', this.defaultHeight);
    }
  },

  didInsertElement() {
    this._super(...arguments);

    this.set('defaultHeight', this.$().get(0).clientHeight + 2);
    this.$().on('input propertychange', this._onChange.bind(this));
    this.$().blur(function () {
      if(!this.get('isDestroying') || !this.get('isDestroyed')){
        if (this.updateSourceTrigger === false) {
          this.set('value', this.$().val());
        }
      }
    }.bind(this))
    .focusin(function () {
      this.$().closest('.scroll-textarea').addClass('on');
    }.bind(this))
    .focusout(function () {
      this.$().closest('.scroll-textarea').removeClass('on');
    }.bind(this));
    this.$().scrollbar();
    //this.$().closest('.text-area').attr('tabindex', -1);
    //this.$().closest('.text-area').find('> .scroll-wrapper').attr('tabindex', -1);
    //this.$().closest('.text-area').find('> .scroll-wrapper > .scroll-content').attr('tabindex', -1);
  },
  willDestroyElement() {
    this._super(...arguments);

    this.$().off('input propertychange');
    this.$().scrollbar('destroy');
  }
});

