import Ember from 'ember';
import layout from './template';

export default Ember.Component.extend({
  contextmenuService: Ember.inject.service('contextmenuService'),
  layout,
  tagName: 'ol',
  classNames: ['c-contextmenu'],
  _options: Ember.computed('contextmenuService.options', function () {
    const options = this.get('contextmenuService.options');

    if (Ember.isNone(options)) {
      Ember.run.once(this, '_deactivate');
    } else if (!Ember.isNone(options.originalEvent)) {
      Ember.run.once(this, '_activate');
    }

    return options;
  }).readOnly(),
  _activate() {
    let originalEvent = this.get('contextmenuService.options.originalEvent');

    Ember.$(document).off('mousedown.ctxhelper');
    Ember.$(document).on('mousedown.ctxhelper', function (event) {
      if (Ember.$(event.target).closest('.c-contextmenu').length === 0) {
        this._deactivate();
      }
    }.bind(this));
    Ember.run.next(this, function() {
      if (!this.get('isDestroying') && !this.get('isDestroyed')) {
        const outerHeight = this.$().height(), outerWidth = this.$().width();
        let offsetTop = originalEvent.clientY + 5, offsetLeft = originalEvent.clientX + 5;

        if (offsetTop + outerHeight + 10 >= Ember.$(window).height()) {
          offsetTop = offsetTop - outerHeight;
        }
        if (offsetLeft + outerWidth + 10 >= Ember.$(window).width()) {
          offsetLeft = offsetLeft - outerWidth;
        }
        this.$().css({ 'top': offsetTop, 'left': offsetLeft });
        this.$().show();
      }
      originalEvent = null;
    });
  },
  _deactivate() {
    Ember.$(document).off('mousedown.ctxhelper');
    this.get('contextmenuService').close();
    this.$().hide();
  },
  willDestroyElement() {
    this._deactivate();
    this._super(...arguments);
  },
  actions: {
    itemClick(callback, arg) {
      if (callback !== 'undefined') {
        callback(arg);
      }
      this._deactivate();
    },
  },
});