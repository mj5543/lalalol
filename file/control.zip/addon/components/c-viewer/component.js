// import Ember from 'ember';
import layout from './template';
// import CHIS from 'framework/chis-framework';
import Control from '../c-control/component';

export default Control.extend({
  layout,
  tagName: 'div',
  classNames: ['c-viewer'],
  style: null,
  isBlock: null,
  zoomIntensity: null,
  thumbnailPosition: null,
  viewerData: null,
  itemSourceData: Ember.computed('itemSource', function() {
    const data = this.get('itemSource');
    // let newData = null;
    // return !Ember.isEmpty(data) ? (
    //   data.length > 1 ? this.set('isBlock', true): this.set('isBlock',false),
    //   data.length > 4 ? data.splice(0, 3) : data
    // ) : (
    //   this.set('isBlock', false),
    //   data
    // );
    // if (!Ember.isEmpty(data)) {
    //   data.length > 1 ? this.set('isBlock', true): this.set('isBlock',false);
    //   return data.length > 4 ? data.splice(0, 3) : data
    // } else {
    //   this.set('isBlock', false);
    //   return data;
    // }
    return data;
  }),
  onPropertyInit(){
    this._super(...arguments);
    this.setStateProperties(['']);
    if (this.hasState() === false) {
      this.set('isBlock', false);
      this.set('zoomIntensity', 0.2);
    }
  },

  didInsertElement(){
    this._super(...arguments);
    console.log('itemSource', this.get('itemSource'));
    // console.log(this.height);
    // this.style.height = this.height;
  },

  willDestroyElement() {
    this._super(...arguments);
  },

  actions: {
    onSaveImage(e) {
      this._raiseEvents('onSaveImage', e);
    },
    selectItem(e) {
      // console.log('선택된 데이터', e);
      this.set('viewerData', e);
      this._raiseEvents('onSelectionChanged', {
        'source' : this, 'originalSource': this, 'dataItem': e
      });
    }
  }
});