import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';

export default Control.extend({
  layout,
  tagName: 'span',
  ignoreClick: false,
  isTrigger: Ember.computed('isOpen', {
    get () {
      return this.get('isOpen');
    },
    set (key, value) {
      this.set('ignoreClick', true);
      Ember.run.next(this, function () {
        if (!this.get('isDestroying') && !this.get('isDestroyed')) {
          this.set('isOpen', this.get('isTrigger'));
          this.set('ignoreClick', false);
        }
      });

      return value;
    },
  }),
  click(event) {
    if (!this.get('ignoreClick')) {
      this._raiseEvents('onTriggerClick');
    }
  },
});