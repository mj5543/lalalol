import Ember from 'ember';
import layout from './template';
import Control from '../fr-control/component';

export default Control.extend({
  layout,
  tagName: 'div',
  classNames: ['fr-timepad'],
  //== Public Properties ===============================================
  selectedTime: null,
  beforeSelectedTime: null,
  selectedTimeChanged: null,
  //== Private Properties ===============================================
  _currentTime: null,
  _am: null,
  _pm: null,
  _min2: null,
  _min1: null,
  _isAm : true,
  _selectedHour: null,
  _selectedMin2: null,
  _selectedMin1: null,
  //== Private Methods ==============================================
  _watchTime: Ember.computed('selectedTime', function () {
    Ember.run.once(this, this._selectedTimeChanged);

    return null;
  }).readOnly(),
  _trySetTime(hour, minute2, minute1) {
    const dt = this.get('co_CommonService').getNow();
    let newHour = 0, newMinute2 = 0, newMinute = 0;

    if (!Ember.isNone(hour)) {
      newHour = parseInt(hour, 10);
    }
    if (!Ember.isNone(minute2)) {
      newMinute2 = parseInt(minute2, 10) * 10;
    }
    if (!Ember.isNone(minute1)) {
      newMinute = parseInt(minute1, 10);
    }

    const newDate = new Date(dt.getFullYear(), dt.getMonth(), dt.getDate(), newHour, newMinute2 + newMinute, 0, 0);

    this.set('selectedTime', newDate);
  },
  _selectedTimeChanged() {
    const datetime = this.get('selectedTime');
    let changed = false;

    if (datetime instanceof Date && !isNaN(datetime.valueOf())) {
      const hour = datetime.getHours();
      let minute2 = datetime.getMinutes(), minute1 = datetime.getMinutes();

      if (minute2.toString().length === 2) {
        minute2 = minute2.toString().substr(0, 1);
        minute1 = minute1.toString().substr(1, 1);
      } else {
        minute2 = '0';
      }
      if (hour >= 12) {
        this.set('_isAm', false);
      } else {
        this.set('_isAm', true);
      }
      if (this.get('_selectedHour') !== hour.toString()) {
        this.set('_selectedHour', hour.toString());
        changed = true;
      }
      if (this.get('_selectedMin2') !== minute2.toString()) {
        this.set('_selectedMin2', minute2.toString());
        changed = true;
      }
      if (this.get('_selectedMin1') !== minute1.toString()) {
        this.set('_selectedMin1', minute1.toString());
        changed = true;
      }
    } else {
      this.set('_isAm', true);
      if (this.get('_selectedHour') !== null) {
        this.set('_selectedHour', null);
        changed = true;
      }
      if (this.get('_selectedMin2') !== null) {
        this.set('_selectedMin2', null);
        changed = true;
      }
      if (this.get('_selectedMin1') !== null) {
        this.set('_selectedMin1', null);
        changed = true;
      }
    }

    if (this.hasLoaded && changed) {
      Ember.run.once(this, this._raiseSelectedTimeChanged);
    }
  },
  _raiseSelectedTimeChanged() {
    const datetime = this.get('selectedTime');

    if (datetime instanceof Date && !isNaN(datetime.valueOf())) {
      this._raiseEvents('selectedTimeChanged', { 
        'source': this,
        'selectedTime': datetime,
        'Hour': datetime.getHours(),
        'Minute': datetime.getMinutes()
      });
    } else {
      this._raiseEvents('selectedTimeChanged', { 
        'source': this,
        'selectedTime': null,
        'Hour': null,
        'Minute': null
      });
    }
  },
  init() {
    this._super(...arguments);

    const now = this.get('co_CommonService').getNow();

    this.set('_currentTime', now);

    this.set('_am', [['0', '6'], ['1', '7'], ['2', '8'], ['3', '9'], ['4', '10'], ['5', '11']],);
    this.set('_pm', [['12', '18'], ['13', '19'], ['14', '20'], ['15', '21'], ['16', '22'], ['17', '23']]);
    this.set('_min2', ['0', '1', '2', '3', '4', '5']);
    this.set('_min1', [['0', '6'], ['1', '7'], ['2', '8'], ['3', '9'], ['4', ''], ['5', '']]);
  },
  didInsertElement() {
    this._super(...arguments);
  },
  didRender() {
    this._super(...arguments);
  },
  //== Event Handler============================================
  actions: {
    onHourClickAction(e) {
      this._trySetTime(this.$(e.currentTarget).attr('data-num'), this.get('_selectedMin2'), this.get('_selectedMin1'));
    },
    onMinute2ClickAction(e) {
      this._trySetTime(this.get('_selectedHour'), this.$(e.currentTarget).attr('data-num'), this.get('_selectedMin1'));
    },
    onMinute1ClickAction(e) {
      if (!Ember.isEmpty(this.$(e.currentTarget).attr('data-num'))) {
        this._trySetTime(this.get('_selectedHour'), this.get('_selectedMin2'), this.$(e.currentTarget).attr('data-num'));
      }
    },
    onHourDoubleClickAction() {
      this._raiseEvents('onHourDoubleClick', { 'source': this, 'selectedTime': this.get('selectedTime') });
    },
    onMinute2DoubleClickAction() {
      this._raiseEvents('onMinute2DoubleClick', { 'source': this, 'selectedTime': this.get('selectedTime') });
    },
    onMinute1DoubleClickAction() {
      this._raiseEvents('onMinute1DoubleClick', { 'source': this, 'selectedTime': this.get('selectedTime') });
    },
    onCurrentTimeClickAction() {
      const dt = this.get('co_CommonService').getNow(), hour = dt.getHours();
      let minute2 = dt.getMinutes(), minute1 = dt.getMinutes();

      if (minute2.toString().length === 2) {
        minute2 = minute2.toString().substr(0, 1);
        minute1 = minute1.toString().substr(1, 1);
      } else {
        minute2 = 0;
      }

      this._trySetTime(hour, minute2, minute1);
    },
    onToggleAction() {
      if ( this.get('_isAm') === true) {
        this._trySetTime(12, this.get('_selectedMin2'), this.get('_selectedMin1'));
      } else {
        this._trySetTime(0, this.get('_selectedMin2'), this.get('_selectedMin1'));
      }
    }
  }
});