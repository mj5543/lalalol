import layout from './template';
import ButtonBase from '../fr-buttonbase/component';
import ContextMenuMixin from '../../mixins/contextmenu-mixin';
import ToolTipMixin from '../../mixins/tooltip-mixin';

export default ButtonBase.extend(ContextMenuMixin, ToolTipMixin, {
  attributeBindings: ['autofocus', 'form', 'formaction', 'formenctype', 'formmethod', 'formnovalidate', 'formtarget'],
  layout,
  classNames: ['fr-button', 'btn'],
  type:'div'
});