import Ember from 'ember';
import Control from '../c-control/component';
import layout from './template';
import globalServiceMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';
import pickerComputedMixin from '../../mixins/picker-computed-mixin';
import pickerDataloadMixin from '../../mixins/picker-dataload-mixin';

export default Control.extend(globalServiceMixin, pickerComputedMixin, pickerDataloadMixin, {
    // == default properties   ==========================
    attributeBindings: ['getSelectedDate','getDisplayDate'],
    // attributeBindings: ['getSelectedDate:date-date'],
    tagName: 'div',
    layout,
    classNames: ['c-calendar'],
    //== Public Properties ==============================
    displayDate: null,
    selectedDate: null,
    toDay: null,
    datePropertyPath: null,
    itemsSource: null,
    cols: 1,
    dayOfWeekHeaderVisibility: true,
    dayofWeek: 'sunday',
    calendarMode: 'month',
    rowFixed: true,
    rowHeight: 27,
    yearRowHeight: 33,
    yearCount: 100,
    rows: 1,
    selectionMode: 'singleDate',
    minCalendarMode: 'decade',
    pickerType: 'month',
    navigationVisibility: true,
    todayNavigationVisibility: true,
    todayText: 'Today',
    patternDays: null,
    holiDays: null,
    memoDatas: null,
    eventDays: null,
    maxDate: null,
    minDate: null,
    disabledDates: null,
    isInternal: true,

    //== Public Events ==================================
    selectedDatesChanged: null,
    calendarModeChanged: null,
    calendarDayButtonDoubleClick: null,

    // == life cycle ====================================
    selectedDateFormatString: Ember.computed('selectedDate', function () {
      if (this._isDateInstance(this.get('selectedDate'))) {
        return moment(this.get('selectedDate')).format('YYYY-MM-DD');
      }
    }),
    todayFormatString: Ember.computed('toDay', function () {
      if (this._isDateInstance(this.get('toDay'))) {
        return moment(this.get('toDay')).format('YYYY-MM-DD');
      }
    }),
    _displayDate: Ember.computed('displayDate', 'selectedDate', 'toDay', function () {
      if (this._isDateInstance(this.get('displayDate'))) {
        return moment(this.get('displayDate')).toDate();
      }
      if (this._isDateInstance(this.get('selectedDate'))) {
        return moment(this.get('selectedDate')).toDate();
      }
      return moment(this.get('toDay')).toDate();
    }),
    init() {
      this._super(...arguments);
      this.set('toDay', moment(moment(this.get('co_CommonService').getNow()).format('YYYY-MM-DD'), 'YYYY-MM-DD').toDate());
    },
    didInsertElement() {
      this._super(...arguments);
      this._setCurrentYear();
    },
    mouseLeave() {
      // ignored
    },
    mouseEnter() {
      this._setCurrentYear();
    },
    mouseDown(e) {
      e.preventDefault();
    },
    _isDateInstance(date) {
      return date instanceof Date && !Number.isNaN(date.valueOf());
    },
    _setCurrentYear() {
      if(this.get('_watchOptions').isDecade) {
        Ember.run.debounce(() => {
          if(this.$('.year-list')) {
            this.$('.year-list').scrollTop( this.get('yearRowHeight') * (this.get('yearCount') - 3) );
          }
        });
      }
    },
    _onDateSelected(newDate) {
      if (Ember.isNone(this.get('selectedDate')) ||
        moment(this.get('selectedDate')).format('YYYY-MM-DD') !== moment(newDate).format('YYYY-MM-DD')) {
        this.set('selectedDate', moment(newDate).toDate());
        this.set('displayDate', moment(newDate).toDate());
      }
    },
    _onMoveToday() {
      if (moment(this.get('toDay')).format('YYYY-MM') !== moment(this.get('_displayDate')).format('YYYY-MM')) {
        this.set('displayDate', moment(this.get('toDay')).toDate());
      }
    },
    // == actions =======================================
    actions: {
      onPrevDecade(thisYear) {
        this.set('displayDate', thisYear.addYears(-10));
      },
      onNextDecade(thisYear) {
        this.set('displayDate', thisYear.addYears(10));
      },
      onPrevYear(thisMonth) {
        this.set('displayDate', thisMonth.addMonths(-12));
      },
      onNextYear(thisMonth) {
        this.set('displayDate', thisMonth.addMonths(12));
      },
      onSelectedDecade() {
        this.set('calendarMode', 'decade');
      },
      onMoveToday() {
        this._onMoveToday();
      },
      onSelectedYear(year) {
        if (this.pickerType === 'year') {
          this._onDateSelected(moment(year.toString(), 'Y').toDate());
        } else {
          this.set('displayDate', moment(this.get('_displayDate')).year(year).toDate());
          this.set('calendarMode', 'year');
        }
      },
      onSelectedMonth(month) {
        if (this.pickerType === 'yearMonth') {
          this._onDateSelected(moment(`${moment(this.get('_displayDate')).format('Y')}`, 'Y').months(month).toDate());
        } else {
          this.set('displayDate', moment(this.get('_displayDate')).months(month).toDate());
          this.set('calendarMode', 'month');
        }
      },
      onMovePrevious(thisMonth) {
        const date = thisMonth || this.get('co_CommonService').getNow();
        const prev = date.addMonths(-1);

        this.set('displayDate', prev);
      },
      onMoveNext(thisMonth) {
        const date = thisMonth || this.get('co_CommonService').getNow();
        const next = date.addMonths(1);

        this.set('displayDate', next);
      },
      onYearButtonDoubleClick(year) {
        this._raiseEvents('calendarYearButtonDoubleClick', {
          source: this,
          year: year,
          selectedDate: this.get('selectedDate'),
        });
      },
      onMonthButtonDoubleClick(month) {
        this._raiseEvents('calendarMonthButtonDoubleClick', {
          source: this,
          month: month,
          selectedDate: this.get('selectedDate'),
        });
      },
      onDayButtonDoubleClick(e) {
        this._raiseEvents('calendarDayButtonDoubleClick', {
          source: this,
          selectedDate: this.get('selectedDate'),
        });
      },
      onDayButtonClick(e) {
        this._onDateSelected(moment(this.$(e.currentTarget).data('day'), 'YYYY-MM-DD').toDate());
      }
    }
  });
