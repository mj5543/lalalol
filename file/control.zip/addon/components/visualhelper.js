import Ember from 'ember';

const visualHelper = Ember.Object.extend({

  getScrollWidth(el) {

    let leftRightWidth = el[0].offsetWidth - el[0].clientWidth;
    let bottomWidth = el[0].offsetHeight - el[0].clientHeight;
    let widths;

    leftRightWidth = this._sanitizeScrollbarWidth(leftRightWidth);
    bottomWidth = this._sanitizeScrollbarWidth(bottomWidth);

    widths = { left: 0, right: 0, top: 0, bottom: bottomWidth };

    // is the scrollbar on the left side?
    if (this._getIsLeftRtlScrollbars() && el.css('direction') == 'rtl') {
      widths.left = leftRightWidth;
    }else {
      widths.right = leftRightWidth;
    }

    return widths;
  },
  _sanitizeScrollbarWidth(width) {
    // no negatives
    width = Math.max(0, width);
    width = Math.round(width);
    return width;
  },
  // responsible for caching the computation
  _getIsLeftRtlScrollbars() {
    return this._computeIsLeftRtlScrollbars();
  },
  // creates an offscreen test element, then removes it
  _computeIsLeftRtlScrollbars() {
    let el = Ember.$('<div><div/></div>')
      .css({
        position: 'absolute',
        top: -1000,
        left: 0,
        border: 0,
        padding: 0,
        overflow: 'scroll',
        direction: 'rtl'
      })
      .appendTo('body');
    let innerEl = el.children();
    // is the inner div shifted to accommodate a left scrollbar?
    let res = innerEl.offset().left > el.offset().left;
    el.remove();
    return res;
  }
});

export default visualHelper;
