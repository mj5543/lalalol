import Ember from 'ember';
const { computed, guidFor } = Ember;

export default Ember.Component.extend({
  attributeBindings: ['_style:style'],
  classNames: ['fr-positioned-container'],
  oninserted: null,
  targetElement: null,
  destinationElementId: null,
  targetAttachment: 'middle center',
  attachment: 'middle center',
  offsetTop: 0,
  offsetLeft: 0,
  isScrollSync: false,
  _beforeTargetElement: null,
  _contentWidth: 0,
  _contentHeight: 0,
  _hasInserted: false,
  _style: computed('targetElement', 'targetAttachment', 'attachment', '_contentWidth', '_contentHeight', {
    get() {

      if (this.get('_hasInserted') === false) {
        return Ember.String.htmlSafe('');
      }

      const targetElement = this.get('targetElement');

      if (this.get('isScrollSync') === true) {
        const _beforeTargetElement = this.get('_beforeTargetElement');

        if (!Ember.$(targetElement).is(Ember.$(_beforeTargetElement))) {
          this._getScrollableAncestors(_beforeTargetElement).forEach((el) => {
            Ember.$(el).off(`scroll.fr-positioned-container-${guidFor(this)}`);
          });
          this._getScrollableAncestors(targetElement).forEach((el) => {
            Ember.$(el).on(`scroll.fr-positioned-container-${guidFor(this)}`, this._updateTargetAttachment.bind(this));
          });
          this.set('_beforeTargetElement', targetElement);
        }
      }

      if (!Ember.isEmpty(targetElement)) {
        const newPosition = this._calculatePosition(targetElement, this.get('targetAttachment'), this.get('attachment'), this._getVerticalOffset(), this._getHorizontalOffset());
        const safetyStyle = Ember.String.htmlSafe(newPosition);

        return safetyStyle;
      }
    },
    set(key, value) {
      return Ember.String.htmlSafe(value);
    },
  }),
  didInsertElement() {
    this._super(...arguments);

    Ember.$(window).on(`scroll.fr-positioned-container-${guidFor(this)}`, this._updateTargetAttachment.bind(this))
      .on(`resize.fr-positioned-container-${guidFor(this)}`, this._updateTargetAttachment.bind(this))
      .on(`orientationchange.fr-positioned-container-${guidFor(this)}`, this._updateTargetAttachment.bind(this));

    Ember.$(document).on(`mousedown.fr-positioned-container-${guidFor(this)}`, this._handleRootMouseDown.bind(this));

    const _oninserted = this.get('oninserted');

    const _targetId = this.get('targetElement');

    if (!Ember.isEmpty(_targetId)) {
      this.$().data('targetId', Ember.$(_targetId).attr('id'));
    }

    if (_oninserted) {
      _oninserted(this);
    }

    this.set('_hasInserted', true);

    this._onloaded();
    this.$('.scrollbar-macosx:not(.scroll-content)').scrollbar();
  },
  didRender() {
    this._super(...arguments);
  },
  willDestroyElement() {
    this._super(...arguments);

    if (this.get('isScrollSync') === true) {
      this._getScrollableAncestors(this.get('_beforeTargetElement')).forEach((el) => {
        Ember.$(el).off(`scroll.fr-positioned-container-${guidFor(this)}`);
      });
    }

    Ember.$(window).off(`scroll.fr-positioned-container-${guidFor(this)}`)
      .off(`resize.fr-positioned-container-${guidFor(this)}`)
      .off(`orientationchange.fr-positioned-container-${guidFor(this)}`);
    Ember.$(document).off(`mousedown.fr-positioned-container-${guidFor(this)}`);
    this.$('.scrollbar-macosx.scroll-content').scrollbar('destroy');
  },
  _onloaded() {
    const currentContentWidth = this.$().width();
    const currentContentHeight = this.$().height();
    const _contentWidth = this.get('_contentWidth');
    const _contentHeight = this.get('_contentHeight');

    if (currentContentWidth !== _contentWidth) {
      this.set('_contentWidth', this.$().width());
    }

    if (currentContentHeight !== _contentHeight) {
      this.set('_contentHeight', this.$().height());
    }
  },
  _calculatePosition(targetElement, targetAttachment, attachment, top, left) {

    const targetOffset = Ember.$(targetElement).offset();
    const scrollLeft = targetOffset.left - Ember.$(window).scrollLeft();
    const scrollTop = targetOffset.top - Ember.$(window).scrollTop();

    let tatargetAttachmentTop = targetAttachment.split(' ')[0];
    let attachmentTop = attachment.split(' ')[0];

    const tatargetAttachmentLeft = targetAttachment.split(' ')[1];
    const attachmentLeft = attachment.split(' ')[1];

    let offsetTop = top;
    let offsetLeft = left;

    if(!Ember.isEmpty(this.destinationElementId)){
      const wormholeOffset = Ember.$(`#${this.destinationElementId}`).offset();

      offsetTop = top - wormholeOffset.top;
      offsetLeft = left - wormholeOffset.left;
    }

    const outerWidth = this.$().outerWidth();
    const outerHeight = this.$().outerHeight();
    const targetWidth = Ember.$(targetElement).outerWidth();
    const targetHeight = Ember.$(targetElement).outerHeight();

    if (tatargetAttachmentTop === 'bottom') {
      if (targetOffset.top + outerHeight + 10 >= Ember.$(window).height()) {
        tatargetAttachmentTop = 'top';

        if (attachmentTop === 'top') {
          attachmentTop = 'bottom';
          //TODO 2018-04-02 ASH : offset 값에 음수를 대입한 경우 타겟을 가리려는 의도가 있기 때문에 타겟을 덮어줘야 한다.
          if(top < 0) {
            offsetTop += Math.abs(top)*2;
          }
        }
      }
    }

    switch (tatargetAttachmentTop) {
      case 'top':
        offsetTop += scrollTop;
        break;
      case 'middle':
        const tmp = targetHeight / 2;

        offsetTop += scrollTop + tmp;
        break;
      case 'bottom':
        offsetTop += scrollTop + targetHeight;
        break;
      default:
        // ignored
        break;
    }

    switch (tatargetAttachmentLeft) {
      case 'left':
        offsetLeft += scrollLeft;
        break;
      case 'center':
        const tmp = targetWidth / 2;

        offsetLeft += scrollLeft + tmp;
        break;
      case 'right':
        offsetLeft += scrollLeft + targetWidth;
        break;
      default:
        // ignored
        break;
    }

    switch (attachmentTop) {
      case 'top':
        offsetTop -= 0;
        break;
      case 'middle':
        offsetTop -= outerHeight / 2;
        break;
      case 'bottom':
        offsetTop -= outerHeight;
        break;
      default:
        // ignored
        break;
    }

    switch (attachmentLeft) {
      case 'left':
        offsetLeft -= 0;
        break;
      case 'center':
        offsetLeft -= outerWidth / 2;
        break;
      case 'right':
        offsetLeft -= outerWidth;
        break;
      default:
        // ignored
        break;
    }

    if (offsetLeft + outerWidth > Ember.$(window).width()) {
      offsetLeft += Ember.$(window).width() - (offsetLeft + outerWidth + 10);
    }

    return `top: ${offsetTop < 0 ? 0 : offsetTop}px; left: ${offsetLeft}px`;
  },
  _getScrollableAncestors(targetElement) {
    const scrollableAncestors = [];

    if (document.body.contains(targetElement)) {
      let nextScrollable = this._getScrollParent(targetElement.parentNode);

      while (nextScrollable && nextScrollable.tagName.toUpperCase() !== 'BODY' && nextScrollable.tagName.toUpperCase() !== 'HTML') {
        scrollableAncestors.push(nextScrollable);
        nextScrollable = this._getScrollParent(nextScrollable.parentNode);
      }
    }
    return scrollableAncestors;
  },
  _getVerticalOffset() {
    const _offset = parseInt(this.get('offsetTop'), 10);

    return Number.isNaN(_offset) ? 0 : _offset;
  },
  _getHorizontalOffset() {

    const _offset = parseInt(this.get('offsetLeft'), 10);

    return Number.isNaN(_offset) ? 0 : _offset;
  },
  _getScrollParent(targetElement) {

    let style = window.getComputedStyle(targetElement);
    const excludeStaticParent = style.position === "absolute";
    const overflowRegex = /(auto|scroll)/;

    if (style.position === "fixed") {
      return document.body;
    }

    for (let parent = targetElement; parent = parent.parentElement;) {
      style = window.getComputedStyle(parent);
      if (excludeStaticParent && style.position === "static") {
        continue;
      }

      if (overflowRegex.test(style.overflow + style.overflowY + style.overflowX)) {
        return parent;
      }
    }

    return document.body;
  },
  _handleRootMouseDown(event) {
    if (Ember.$(event.target).closest(this.$()).length === 0) {
      this._tryAction('onMouseDownToOutside', event);
    }
  },
  _updateTargetAttachment() {
    const targetElement = this.get('targetElement');

    // targetElement가 Html Node가 아닐경우 개선해야 한다. 임시적으로 예외처리 하였고 document.body.contains 비교 구문도 개선 예정
    try {
      if (document.body.contains(targetElement)) {
        this.set('_style', this._calculatePosition(targetElement, this.get('targetAttachment'),
          this.get('attachment'), this._getVerticalOffset(), this._getHorizontalOffset()));
      }
    } catch (error) {
    }
  },
  _tryAction(name, args) {
    const action = this.get(name);

    if (action) {
      if (Ember.isArray(args)) {
        action(...args);
      } else {
        action(args);
      }
    }
  },
});
