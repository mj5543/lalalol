import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

export default Control.extend(StatefulComponentMixin, {
  attributeBindings: ['watchSelectedTabName:name'],
  classNames: ['tab-item'],
  layout,
  tagName : 'div',
  header : '',
  content: null,
  contentClass: '',
  dataItem : null,
  onRender: null,
  isRendered : false,
  watchSelectedTabName: Ember.computed('name', 'selectedTabName', function() {
    if ( !Ember.isEmpty(this.get('selectedTabName')) && this._getName() === this.get('selectedTabName')) {
      if ( this.get('isRendered') === false ) {
        this.set('isRendered', true);
        Ember.run.schedule('afterRender', this, function () {
          this.$('.scrollbar-macosx:not(.scroll-content)').scrollbar();
        });
      }
      this.$().addClass('c-tab-active');
      Ember.run.once(this, function() {
        this._raiseEvents('onSelected', {
          source : null,
          originalSource : this,
          dataItem : this.get('dataItem')
        });
      });
    } else {
      this.$().removeClass('c-tab-active');
    }
  }).readOnly(),
  _getName() {
    const _name = this.get('name');

    if ( !Ember.isEmpty(_name)) {
      return _name ;
    }

    return this.get('elementId') ;
  },
  didInsertElement(){
    this._super(...arguments);
    if ( this._getName() === this.get('selectedTabName')) {
      this.$().addClass('c-tab-active');
    }
    this._raiseEvents('onRender', {
      id : this._getName(),
      header : this.header,
      content : this.content
    });
  },
  willDestroyElement(){
    this.$('.scrollbar-macosx').scrollbar('destroy');
    this._super(...arguments);
  },
});
