import Ember from 'ember';
import layout from './template';
import Control from '../fr-control/component';
import ReportViewContainerMixIn from 'framework-control/mixins/reportview-mixin';

export default Control.extend(ReportViewContainerMixIn, {
  layout,
  tagName: 'div',
  targetTag: '#ReportViewer',
  classNames: ['fr-reportview'],

  /*
  //== Component Properties =================================
  layout,
  tagName: 'div',
  files: null,
  clipReportUrl:null,
  itemsSource: null,
  fieldParameters:null,
  connectionType: null,
  initializeOnLoad: false,
  saveFileName: null,
  classNames: ['fr-reportview'],
  isShowSaveButton: true,
  isShowPdfButton: true,
  isShowExcelButton: true,
  isShowHWPButton: false,
  isShowPrintButton: true,
  isShowFirstPageButton: true,
  isShowPrevButton: true,
  isShowInputBox: true,
  isShowTotalCount: true,
  isShowNextButton: true,
  isShowLastButton: true,
  isShowZoomIn: true,
  isShowReportInfoButton: false,
  isShowCloseButton: false,
  enabledDebug : false,
  onStartPrint: null,
  clipReports : null,
  //== Attribute Properties =================================
  attributeBindings: ['_watchSource:data-source', 'data-field-*'],
  //== Public Properties ====================================
  //== Private Properties ===================================
  _report : null,
  //== Computed Properties ==================================
  _watchSource: Ember.computed('itemsSource', function () {

    if (this.get('initializeOnLoad') === false) {

      if (this.hasLoaded !== true) {
        return;
      }
    }
    this.view();

    return Ember.isEmpty(this.get('itemsSource')) ? 1 : 0;
  }).readOnly(),
  view() {
    this._getReportFiles();

    if(!Ember.isEmpty(this.get('clipReports'))){
      this._clipReportView();
    }
  },
  print(options) {
    this._getReportFiles();
    const newOptions = this._getReportPrintOptions(options);

    if(!Ember.isEmpty(this.get('clipReports'))){
      this._setClipReportPrint();

      if ( newOptions.isDirect === true) {
        this.get('_report').exeDirectPrint(newOptions.isPopUp, newOptions.printName, newOptions.tray, newOptions.startNumber,newOptions.endNumber, newOptions.copies, newOptions.option);
      } else {
        this.get('_report').setDirectPrint(true);
        this.get('_report').view();
      }
    }
  },
  setfieldParameters(dataField){
    this.set('fieldParameters',dataField);
  },
  setReportFiles(filePath){
    this.set('files', filePath);
  },
  _getReportFiles(){
    this.get('clipReports').clear();
    if(!Ember.isEmpty(this.get('files'))){
      const filelist = this.get('files').split(';');

      filelist.forEach((file) => {
        var format = file.split('.');

        if(format[1]=='crf'){
          Ember.Logger.log("clip :     "+ file);
          this.get('clipReports').push(file);
        }
      });
    }
  },
  _getReportPrintOptions(options) {
    let newOptions = options;

    if ( Ember.isEmpty(newOptions) ) {
      newOptions = {
        isDirect : false,
        isPopUp : false,
        printName : '',
        tray : '',
        startNumber : 1,
        endNumber : -1,
        copies : 1,
        option : ''
      };
    }

    if (!newOptions.hasOwnProperty('isDirect')) {
      newOptions.isDirect = false;
    }

    if (!newOptions.hasOwnProperty('isPopUp')) {
      newOptions.isPopUp = false;
    }

    if (!newOptions.hasOwnProperty('printName')) {
      newOptions.printName = '';
    }

    if (!newOptions.hasOwnProperty('tray')) {
      newOptions.tray = '';
    }

    if (!newOptions.hasOwnProperty('startNumber')) {
      newOptions.startNumber = 1;
    }

    if (!newOptions.hasOwnProperty('endNumber')) {
      newOptions.endNumber = -1;
    }

    if (!newOptions.hasOwnProperty('copies')) {
      newOptions.copies = 1;
    }

    if (!newOptions.hasOwnProperty('option')) {
      newOptions.option = '';
    }

    return newOptions;
  },
  _clipReportView() {

    if (Ember.isEmpty(this.get('files'))) {
      return;
    }
    this._setClipReportPrint();

    this.get('_report').view();
  },
  _setClipReportPrint() {
    const data = JSON.stringify(this.get('itemsSource'));
    const oof = new OOFDocument();

    Object.keys(this).forEach(function (key) {
      if (key.substr(0, 11) === 'data-field-') {
        oof.addField(key.substr(11), this.get(key));
      }
    }.bind(this));
    if (!Ember.isEmpty(this.get('fieldParameters'))) {
      var params= this.get('fieldParameters');

      for (var key in params) {
        oof.addField(key, params[key]);
      }
    }

    const connection = oof.addConnectionMemo('*', data);

    if(!Ember.isEmpty(this.get('clipReports'))){

      this.get('clipReports').forEach((file)=>{
        Ember.Logger.log("ddd " + file);
        oof.addFile('crf.root', '%root%/crf/' + file);
      });
    }


    connection.addContentParamJSON('*', 'utf-8', '{%dataset.json.root%}');

    var report = createReport(this.get('clipReportUrl'), oof.toString(), this.$('#OZViewer')[0]);

    report.setEnabledCrossDomain(true);
    report.setOOFEncoding(true);
    report.setDisplayPrintOption("exe", true);
    if ( this.get('enabledDebug') === true) {
      report.setDebug(true);
    }
    if (!Ember.isEmpty(this.get('saveFileName'))) {
      report.setSaveFileName(this.get('saveFileName'));
    }
    report.setStartPrintButtonEvent(function () {

      const arg = { source: this, cancel: false } ;

      this._raiseEvents('onStartPrint', arg);

      return !arg.cancel;

    }.bind(this));

    report.setCrossChromePDFPrint(true);

    // report.setStyle("firstPage_button", "left:50px;z-index:3;visibility:hidden");
    // report.setStyle("prev_button", "left:100px;z-index:3;visibility:hidden");
    // report.setStyle("input_box", "width:30px;font-size:10pt;text-align:right;");
    // report.setStyle("totalCount_box", "width:30px;font-size:10pt;text-align:center;");
    // report.setStyle("next_button", "left:240px;z-index:3;visibility:hidden");
    // report.setStyle("lastPage_button", "left:290px;z-index:3;visibility:hidden");
    // report.setStyle("zoomIn", "left:335px;font-size:10pt;z-index:3;visibility:hidden;width:90px");
    // report.setStyle("close_button", "right:5px");

    // report.setStyle("save_button", "top:-2px;left:0px;width:60px;background-image:url(./user_img/theme1/save.svg);");
    // report.setStyle("pdf_button", "top:-5px;width:40px;height:40px;background-image:url(./user_img/theme1/pdf.svg);");
    // report.setStyle("excel_button", "top:-5px;width:40px;height:40px;background-image:url(./user_img/theme1/excel.svg);");
    // report.setStyle("hwp_button", "top:-5px;width:40px;height:40px;background-image:url(./user_img/theme1/hwp.svg);");
    // report.setStyle("print_button", "top:-5px;width:40px;height:40px;background-image:url(./user_img/theme1/print.svg);");
    // report.setStyle("firstPage_button", "top:-5px;width:40px;height:40px;background-image:url(./user_img/theme1/leftEnd.svg);");
    // report.setStyle("prev_button", "top:-5px;width:40px;height:40px;background-image:url(./user_img/theme1/left.svg);");
    // report.setStyle("input_box", "left:inherit;right:140px;");
    // report.setStyle("totalCount_box", "left:inherit;right:90px;");
    // report.setStyle("next_button", "top:-5px;width:40px;height:40px;background-image:url(./user_img/theme1/right.svg);");
    // report.setStyle("lastPage_button", "top:-5px;width:40px;height:40px;background-image:url(./user_img/theme1/rightEnd.svg);");
    // report.setStyle("zoomIn", "visibility:hidden;");
    // report.setStyle("reportInfo_button", "top:-5px;width:40px;height:40px;background-image:url(./user_img/theme1/info.svg);");
    // report.setStyle("close_button", "top:-2px;width:60px;background-image:url(./user_img/theme1/close.svg);");

    if (this.get('isShowSaveButton') !== true) {
      report.setStyle('save_button', 'visibility:hidden');
    }

    if (this.get('isShowPdfButton') !== true) {
      report.setStyle('pdf_button', 'visibility:hidden');
    }

    if (this.get('isShowExcelButton') !== true) {
      report.setStyle('excel_button', 'visibility:hidden');
    }

    if (this.get('isShowHWPButton') !== true) {
      report.setStyle('hwp_button', 'visibility:hidden');
    }

    if (this.get('isShowPrintButton') !== true) {
      report.setStyle('print_button', 'visibility:hidden');
    }

    if (this.get('isShowFirstPageButton') !== true) {
      report.setStyle('firstPage_button', 'visibility:hidden');
    }

    if (this.get('isShowPrevButton') !== true) {
      report.setStyle('prev_button', 'visibility:hidden');
    }

    if (this.get('isShowInputBox') !== true) {
      report.setStyle('input_box', 'visibility:hidden');
    }

    if (this.get('isShowTotalCount') !== true) {
      report.setStyle('totalCount_box', 'visibility:hidden');
    }

    if (this.get('isShowNextButton') !== true) {
      report.setStyle('next_button', 'visibility:hidden');
    }

    if (this.get('isShowLastButton') !== true) {
      report.setStyle('lastPage_button', 'visibility:hidden');
    }

    if (this.get('isShowZoomIn') !== true) {
      report.setStyle('zoomIn', 'visibility:hidden');
    }

    if (this.get('isShowReportInfoButton') !== true) {
      report.setStyle('reportInfo_button', 'visibility:hidden');
    }

    if (this.get('isShowCloseButton') !== true) {
      report.setStyle('close_button', 'visibility:hidden');
    }

    this.set('_report', report);
  },
  //== Life Cycle ===========================================
  init() {
    this._super(...arguments);
    this.set('clipReports',[]);

    // bind attributes beginning with 'data-'
    if (Ember.isEmpty(this.get('connectionType'))) {
      this.set('connectionType', 'json');
    }
    if (Ember.isEmpty(this.get('clipReportUrl'))) {
      this.set('clipReportUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'clipReportServerUrl') + "Clip.jsp");
    }
  },
  didInsertElement() {
    this._super(...arguments);
  },
  willDestroyElement() {
    this._super(...arguments);

    const report = this.get('_report');

    if ( !Ember.isEmpty(report) ) {
      report.closeReport();
    }

    this.set('_report', null);
    this.set('clipReports',null);
    this.set('clipReportUrl', null);
  }
  //== Private Methods  =====================================
  */
});
