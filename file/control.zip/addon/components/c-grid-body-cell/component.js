import Ember from 'ember';
import layout from './template';

export default Ember.Component.extend({
  layout,
  tagName: 'td',
  classNameBindings: ['_gridBodyCellClass', '_gridColumnAlignClass', '_editing:editing-cell', '_vline:vline', 'selected:selected-cell'],
  attributeBindings: ['cellIndex:data-body-cell-index', 'rowspan', 'tabindex'],
  selected: false,
  editing: false,
  tabindex: -1,
  _min: Ember.computed.readOnly('column.min'),
  _max: Ember.computed.readOnly('column.max'),
  _minDate: Ember.computed.readOnly('column.minDate'),
  _maxDate: Ember.computed.readOnly('column.maxDate'),
  _allowDecimal: Ember.computed.readOnly('column.allowDecimal'),
  _step: Ember.computed.readOnly('column.step'),
  _maxDropDownWidth: Ember.computed.readOnly('column.maxDropDownWidth'),
  _maxDropDownHeight: Ember.computed.readOnly('column.maxDropDownHeight'),
  _options: Ember.computed.readOnly('column.itemsSource'),
  _selectedValuePath: Ember.computed.readOnly('column.selectedValuePath'),
  _displayMemberPath: Ember.computed.readOnly('column.displayMemberPath'),
  _format: Ember.computed.readOnly('column.dataFormat'),
  _vline: Ember.computed.or('column.vline', 'column.merge').readOnly(),
  _noneType: Ember.computed.none('column.type').readOnly(),
  _stringType: Ember.computed.equal('column.type', 'string').readOnly(),
  _booleanType: Ember.computed.equal('column.type', 'boolean').readOnly(),
  _numberType: Ember.computed.equal('column.type', 'number').readOnly(),
  _dropdownType: Ember.computed.equal('column.type', 'dropdown').readOnly(),
  _dateType: Ember.computed.equal('column.type', 'date').readOnly(),
  _noneOrStringType: Ember.computed.or('_noneType', '_stringType').readOnly(),
  _notReadOnly: Ember.computed.not('_readOnly').readOnly(),
  _allowEditing: Ember.computed.and('editable', '_notReadOnly').readOnly(),
  _editing: Ember.computed.and('_allowEditing', 'editing').readOnly(),
  _readOnly: Ember.computed('column.readOnly', function () {
    const _readOnly = this.get('column.readOnly');

    return Ember.typeOf(_readOnly) !== 'function' ? _readOnly :
      _readOnly({ cellComponent: this, item: this.get('item'), column: this.get('column'), });
  }).readOnly(),
  _pickerType: Ember.computed('column.pickerType', function () {
    const _pickerType = this.get('column.pickerType');

    return Ember.isNone(_pickerType) ? 'date' : _pickerType;
  }).readOnly(),
  _gridBodyCellClass: Ember.computed('_gridGuid', function () {
    return `${this.get('_gridGuid')}-body-cell`;
  }).readOnly(),
  _gridColumnAlignClass: Ember.computed('column.align', function () {
    const _align = this.get('column.align');

    return Ember.isNone(_align) ? 'left' : _align;
  }).readOnly(),
  _booleanClass: Ember.computed('_gridGuid', '_allowEditing', '_dataValue', function () {
    return `${this.get('_gridGuid')}-body-cell-boolean checkbox ${!this.get('_allowEditing') ? 'readonly' : ''} ${this.get('_dataValue') ? 'checked' : ''}`;
  }).readOnly(),
  init() {
    this._super(...arguments);
    const _init = this.get('column.onBodyCellInit');

    if (Ember.typeOf(_init) === 'function') {
      _init.call(this, { cellComponent: this, item: this.get('item'), column: this.get('column'), });
    }
    if (!Ember.isNone(this.get('column.bodyTemplateName'))) {
      Ember.defineProperty(this, 'layout', Ember.computed(function () {
        return Ember.HTMLBars.compile(`{{observedProperty}}<div style={{_htmlSafeBodyLineHeight}}><div>{{yield (hash ${this.get('column.bodyTemplateName')}=(component 'c-grid-body-cell-template' editing=_editing item=item column=column rowIndex=rowIndex))}}</div></div>{{#if description}}<label>{{c-tooltip placement='top' text=description}}</label>{{/if}}`);
      }).readOnly());
    }
    if (!Ember.isNone(this.get('column.field'))) {
      Ember.defineProperty(this, '_dataValue', Ember.computed(`item.${this.get('column.field')}`, {
        get (key) {
          return this.get(`item.${this.get('column.field')}`);
        },
        set (key, value) {
          this.set(`item.${this.get('column.field')}`, value);

          return value;
        },
      }));
    }
  },
  didInsertElement() {
    this._super(...arguments);
    const _render = this.get('column.onBodyCellRender');

    if (Ember.typeOf(_render) === 'function') {
      _render.call(this, { cellComponent: this, item: this.get('item'), column: this.get('column'), });
    }
    this.$().on('_getComponent', function (event, param) {
      param.component = this;
      event.stopPropagation();
      event.preventDefault();
    }.bind(this));
  },
  willDestroyElement() {
    this.$().off('_getComponent');
    this._super(...arguments);
  },
});