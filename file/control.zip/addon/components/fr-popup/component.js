import Ember from 'ember';
import GlobalServiceContainerMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';
import layout from './template';

export default Ember.Component.extend(GlobalServiceContainerMixin, {
  //== Component Properties =================================
  layout,
  tagName: 'div',
  //== Attribute Properties =================================
  attributeBindings: ['_watchisOpen:data-name'],
  accesskey: null,
  contenteditable: null,
  dir: null,
  disabled: null,
  draggable: null,
  dropzone: null,
  hidden: null,
  lang: null,
  name: null,
  spellcheck: null,
  style: null,
  tabindex: null,
  translate: null,
  //== Public Properties ====================================
  targetAttachment: 'bottom left',
  attachment: 'top left',
  isOpen: false,
  staysOpen: true,
  placementTarget: '',
  isEmbedded: false,
  inputTarget: '',
  verticalOffset: '2px',
  horizontalOffset: '0px',
  opened: null,
  closed: null,
  //== Private Properties ===================================
  _hasLoaded: false,
  _destinationMainlementId: 'fr-wormhole-container',
  _destinationElementId: Ember.computed(function () {
    return this.$().closest('.wormhole-parent').find('.wormhole-contaner').attr('id');
  }).readOnly(),
  _targetElement: null,
  _hasOpen: null,
  _eventType: null,
  //== Computed Properties ==================================
  _watchisOpen: Ember.computed('isOpen', function () {
    if (this.get('isOpen') === true) {
      return this._onOpened();
    } else {
      return this._onClosed();
    }
  }),
  //== Life Cycle ===========================================
  init() {
    this._super(...arguments);
    this.set('_eventType', 'mousedown.' + this.get('elementId'));
  },
  didInsertElement() {
    this._super(...arguments);

    this._hasLoaded = true;
  },
  willDestroyElement() {
    this._super(...arguments);

    this.set('_targetElement', null);
    if (this.get('staysOpen') === false) {
      Ember.$('body').off(this._eventType);
    }
  },
  //== Private Methods  =====================================
  _staysClosed(e) {

    if (this.get('isDestroyed') || this.get('isDestroying')) {
      Ember.$('body').off(this._eventType);

      return;
    }

    const _parentId = Ember.$(e.target).closest('.fr-popup').eq(0).data('id');
    const _elementId = this.get('elementId');
    const _targetId = Ember.$(e.target).closest('.fr-positioned-container').data('targetId');

    if (!Ember.isEmpty(this.inputTarget) && Ember.$(this.inputTarget)[0] === e.target) {
      return;
    }

    if (_elementId === _parentId) {
      return;
    }

    if (Ember.$(`body > #${this._destinationMainlementId} > div > div[data-id='${_elementId}']`).find(`#${_targetId}`).length === 1) {
      return;
    }

    if (Ember.$(`#${this.get('_destinationElementId')}`).find('#' + _targetId).length === 1) {
      return;
    }

    if (Ember.$(e.target).hasClass('fr-menuitem') === true) {
      return;
    }

    // TODO 2018-04-05 _staysClosed 속성에 대한 예외처리에 관하여 개선필요 및 mixin으로 dropdownbutton에도 적용해야함.
    // dropdopbutton StayOpen 속성 추가 작업에서 개선할 예정
    if (Ember.$(e.target).hasClass('search') === true) {
      return;
    }

    if (Ember.$(e.target).closest('.fr-message-box').length > 0 || Ember.$(e.target).closest('.fr-message-box-bg').length > 0) {
      return;
    }

    this.set('isOpen', false);
  },
  _onOpened() {

    this.set('_targetElement', Ember.$(this.placementTarget).get(0));

    Ember.run.once(this, function () {

      this._raiseEvents('opened', { 'source': this });

      if (this.get('staysOpen') === false) {
        Ember.$('body').on(this._eventType, this._staysClosed.bind(this));
      }

      this.set('_hasOpen', true);
    });
  },
  _onClosed() {

    if (this.get('staysOpen') === false) {
      Ember.$('body').off(this._eventType);
    }

    if (this._hasLoaded === true) {
      Ember.run.once(this, function () {
        this._raiseEvents('closed', { 'source': this });
      });
    }

    this.set('_hasOpen', false);
  },
  _raiseEvents(eventName, arg) {
    const events = this.get(eventName);

    if (events) {
      events(arg);
    }
  },
});
