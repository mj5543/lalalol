import Ember from 'ember';
import layout from './template';

const { computed } = Ember;

export default Ember.Component.extend({
  layout,
  tagName: 'tr',
  classNameBindings: ['_gridBodyGheadClass'],
  attributeBindings: ['rowIndex:data-body-ghead-row-index'],
  _gridBodyGheadClass: computed(function () {
    return `${this.get('_gridGuid')}-body-ghead ghead`;
  }).readOnly(),
  didInsertElement() {
    this._super(...arguments);
    this.$().on('_getComponent', function (event, param) {
      param.component = this;
      event.stopPropagation();
      event.preventDefault();
    }.bind(this));
  },
  willDestroyElement() {
    this.$().off('_getComponent');
    this._super(...arguments);
  },
  mouseEnter(event) {
    this.$().closest('div.c-grid-body-container').find('> div.lock > table > tbody, > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx > table > tbody')
      .children(`tr[data-body-ghead-row-index=${this.$(event.currentTarget).attr('data-body-ghead-row-index')}]`).addClass('hover');
  },
  mouseLeave() {
    this.$().closest('div.c-grid-body-container').find('> div.lock > table > tbody, > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx > table > tbody')
      .children('tr[data-body-ghead-row-index]').removeClass('hover');
  },
});