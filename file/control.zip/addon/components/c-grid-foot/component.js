import Ember from 'ember';
import layout from './template';

const { computed } = Ember;

export default Ember.Component.extend({
  layout,
  tagName: 'tfoot',
  _notHasFrozen: computed.not('_hasFrozen').readOnly(),
  _frozenTableOrNotHasFrozen: computed.or('_frozenTable', '_notHasFrozen').readOnly(),
  didInsertElement() {
    this._super(...arguments);
    this.$().on('_getComponent', function (event, param) {
      param.component = this;
      event.stopPropagation();
      event.preventDefault();
    }.bind(this));
  },
  willDestroyElement() {
    this.$().off('_getComponent');
    this._super(...arguments);
  },
});