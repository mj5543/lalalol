import Ember from 'ember';
import Control from '../c-control/component';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';
import layout from './template';

//Expander
export default Control.extend(StatefulComponentMixin, {
  layout,
  tagName: 'div',
  classNames: ['c-expander', 'wrap-expander'],
  classNameBindings: [ 'expandDirectionClassName' ],
  hasContentLoaded: false,
  // == Public Properties ==============================
  duration: 250,
  expanderSize: 35,
  isExpanded: false,
  expandDirection: 'down',
  // == Public Events ==================================
  onExpanded: null,
  onCollapsed: null,
  targetElement: null,
  // == Computed Properties ============================
  expandDirectionClassName: Ember.computed('expandDirection', function () {
    const direction = this.get('expandDirection');

    if (direction === 'left') {
      return 'left';
    } else if (direction === 'right') {
      return 'right';
    } else if (direction === 'up') {
      return 'up';
    }
  }),
  // == Private Properties =============================
  _onCollapsed(element) {
    const direction = this.get('expandDirection');
    let content = element.find('> div.expander-view');

    // const curton = content.find('> .expander-curton');
    content.css('overflow-y', 'hidden');
    if(direction === 'left' || direction === 'right') {
      content.css({
        width: '0'
      });
    } else {
      content.css({
        height: '0'
      });
    }
    content = null;
    this._raiseEvents('onCollapsed', { 'source': this, 'isExpanded': false });
  },
  _onExpanded(element) {
    const direction = this.get('expandDirection');
    let content = element.find('> div.expander-view');
    // const curton = content.find('> .expander-curton');

    this._loadContent();
    if(direction === 'left' || direction === 'right') {
      content.css('width', this.get('width'));
    } else {
      Ember.run.schedule('afterRender', this, function () {
        content.css({ height: Ember.isNone(this.get('height')) ? this.get('height') : content.prop('scrollHeight') });
        content = null;
      });
    }
    this._raiseEvents('onExpanded', { 'source': this, 'isExpanded': true });
  },
  _loadContent() {
    this.set('hasContentLoaded', true);
  },
  didInsertElement() {
    this._super(...arguments);
    const direction = this.get('expandDirection');

    if (direction === 'left' || direction === 'right') {
      if (this.get('isExpanded')) {
        this.$('> div.expander-list').css('width', Ember.isNone(this.get('width')) ? '100%' : this.get('width'));
      }
      this.$('> div.expander-list').css('height', Ember.isNone(this.get('height')) ? 'auto' : this.get('height'));
    } else {
      this.$().css('width', Ember.isNone(this.get('width')) ? '100%' : this.get('width'));
    }
    if (this.get('isExpanded')) {
      this.set('hasContentLoaded', true);
    }
  },
  actions: {
    toggleAction(elem) {
      const target = this.$(elem.target).closest('.expander-list');

      target[0].classList.toggle('active');
      if (target[0].classList.contains('active')) {
        this._onExpanded(target);
      } else {
        this._onCollapsed(target);
      }
      target.find('.expander-curton').css('width', this.get('width'));
    }
  }
});