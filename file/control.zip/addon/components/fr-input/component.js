import Ember from 'ember';
import Control from '../fr-control/component';
//import InputMixin from '../../mixins/input-mixin';

export default Control.extend(/*InputMixin, */{
  tagName: 'input',
  attributeBindings: [ '_observedAttribute', 'autocomplete', 'autocorrect', 'autocapitalize', 'spellcheck', 'disabled:disabled',
    'readonly:readonly', 'required:required', 'tabindex', 'name', 'type', 'title', 'placeholder', 'autofocus',
    'value', 'pattern', 'min', 'max', 'maxlength', 'pattern', 'size', 'step' ],
  autocomplete: 'off',
  autocorrect: 'off',
  autocapitalize: 'off',
  spellcheck: false,
  updateSourceTrigger: false,
  type: 'text',
  textMode: 'text',
  _observedAttribute: Ember.computed('clearButtonVisibility', 'searchButtonVisibility', 'isDataSucess', 'isDataError', 'disabled', 'readonly', function () {
    Ember.run.schedule('afterRender', this, function () {
      if (!this.get('isDestroying') && !this.get('isDestroyed')) {
        if (this.get('clearButtonVisibility')) {
          this.$().closest('.inp-txt').addClass('focus');
        } else {
          this.$().closest('.inp-txt').removeClass('focus');
        }
        if (this.get('searchButtonVisibility')) {
          this.$().closest('.inp-txt').addClass('inp-search');
          if ( this.$().closest('.inp-txt').children('span.search').length === 0) {
            this.$().closest('.inp-txt').children('button.del').after(`<span class='search'><span class='blind'>search</span></span>`);
            this.$().closest('.inp-txt').children('span.search').on('mousedown', this._onTextSearch.bind(this));
          }
        } else {
          this.$().closest('.inp-txt').removeClass('inp-search');
          this.$().closest('.inp-txt').children('span.search').remove();
          this.$().closest('.inp-txt').children('span.search').off('mousedown');
        }
        if (this.get('isDataSucess')) {
          this.$().closest('.inp-txt').addClass('ok');
        } else {
          this.$().closest('.inp-txt').removeClass('ok');
        }
        if (this.get('isDataError')) {
          this.$().closest('.inp-txt').addClass('error');
        } else {
          this.$().closest('.inp-txt').removeClass('error');
        }
        if (this.get('disabled')) {
          this.$().closest('.inp-txt').addClass('disabled');
        } else {
          this.$().closest('.inp-txt').removeClass('disabled');
        }
        if (this.get('readonly')) {
          this.$().closest('.inp-txt').addClass('readonly');
        } else {
          this.$().closest('.inp-txt').removeClass('readonly');
        }
      }
    });

    return null;
  }),
  didInsertElement() {
    this._super(...arguments);

    this.$().addClass('fr-input');
    this.$().wrap(`<div class="inp-txt"></div>`);
    this.$().after(`<button class='del'><span class='blind'>delete</span></button>`);
    this.$().closest('.inp-txt').children('button.del').on('mousedown', this._onTextClear.bind(this));
    this.$().closest('.inp-txt').css('width', this.$().prop('style')['width']);
    if (Ember.isArray(this.get('classNames'))) {
      this.get('classNames').forEach(function (className) {
        this.$().closest('.inp-txt').addClass(className);
        this.$().removeClass(className);
      }.bind(this));
    }
    this.$().on('focus', this._onFocus.bind(this)).on('focusout', this._onFoucsout.bind(this))
      .on('blur', this._onBlur.bind(this)).on('keypress', this._onKeyPress.bind(this));
    this.setTextMode(this.get('textMode'));
    this.setCapital(this.get('isCapital'));
    if (this.updateSourceTrigger === true) {
      this.$().on('input propertychange', this._onChange.bind(this));
    }
  },
  willDestroyElement() {
    this._super(...arguments);

    this.$().off('focus').off('focusout').off('blur').off('keypress').off('input propertychange');
    this.$().closest('.inp-txt').children('button.del').off('mousedown');
    this.$().closest('.inp-txt').children('span.search').off('mousedown');
  },
  setCapital(value) {
    this.set('isCapital', value);
    this.$().off('keyup');
    if (value) {
      this.$().on('keyup', this._onKeyUp.bind(this));
    }
  },
  setTextMode(mode) {
    this.set('textMode', mode);
    this.$().off('keydown').off('keyup').removeClass('ime-disabled');
    if (mode === 'number' || mode === 'decimal' || mode === 'alphaNumeric' || mode === 'alphabet') {
      this.$().on('keydown', this._onKeyDown.bind(this)).on('keyup', this._onKeyUp.bind(this)).addClass('ime-disabled');
    }
  },
  _setValue(val) {
    this.set('value', val);
  },
  _negativeHangule(e) {
    if (this.textMode === 'alphabet' || this.textMode === 'alphaNumeric' || this.textMode === 'decimal' || this.textMode === 'number') {
      Ember.$(e.currentTarget).val(Ember.$(e.currentTarget).val().replace(/[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/g, ''));
    }
  },
  _onInternalTextCommit(e) {
    if (this.get('isDestroyed') || this.get('isDestroying') || this.get('readonly')) {
      return;
    }

    this._negativeHangule(e);

    if (this.updateSourceTrigger === false) {
      this._setValue(Ember.$(e.currentTarget).val());
    }
  },
  _onInternalKeyDown(e) {
    if (e.keyCode === 110 || e.keyCode === 190) {
      if (this.textMode === 'decimal') {
        if (Ember.$(e.currentTarget).val().indexOf('.') !== -1) {
          e.preventDefault();
          return;
        }
      }
      else if (this.textMode === 'alphaNumeric' || this.textMode === 'number') {
        e.preventDefault();
        return;
      }
    }

    if (e.keyCode === 13) {
      e.preventDefault();
      return;
    }

    if (Ember.$.inArray(e.keyCode, [46, 8, 9, 27, 110, 190]) !== -1 ||
      // Allow: Ctrl/cmd+A
      (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
      // Allow: Ctrl/cmd+C
      (e.keyCode === 67 && (e.ctrlKey === true || e.metaKey === true)) ||
      // Allow: Ctrl/cmd+X
      (e.keyCode === 88 && (e.ctrlKey === true || e.metaKey === true)) ||
      // Allow: home, end, left, right
      (e.keyCode >= 35 && e.keyCode <= 39)) {
      // let it happen, don't do anything
      return;
    }

    if (this.textMode === 'alphaNumeric') {
      let regex = new RegExp("^[a-zA-Z]+$");
      let str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
      if (regex.test(str)) {
        return;
      }
    }

    if (this.textMode === 'alphabet') {
      let regex = new RegExp("^[a-zA-Z]+$");
      let str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
      if (regex.test(str)) {
        return;
      } else {
        e.preventDefault();
        return;
      }
    }

    // Ensure that it is a number and stop the keypress
    if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
      if (this.allowNegativeNumber === true && (e.keyCode === 109 || e.keyCode === 189)) {
        if (Ember.isEmpty(Ember.$(e.currentTarget).val())) {
          return;
        }
      }
      e.preventDefault();
    }
  },
  _onFocus(e) {
    if (this.get('isGotFocusAutoSelect')) {
      this.$(e.currentTarget).select();
    }
  },
  _onFoucsout(e){
    this._onInternalTextCommit(e);
  },
  _onBlur(e) {
    this._onInternalTextCommit(e);
  },
  _onKeyDown(e) {
    if (e.keyCode !== 13) {
      this._onInternalKeyDown(e);
    }
  },
  _onKeyPress(e) {
    if (e.keyCode === 13) {
      this._onInternalTextCommit(e);

      this._raiseEvents('textCommit', { 'source': this, 'originalEvent': e });

      e.preventDefault();
      return false;
    }
  },
  _onKeyUp(e) {
    if(this.isCapital){
      Ember.$(e.currentTarget).val(Ember.$(e.currentTarget).val().toUpperCase());
    }
    this._negativeHangule(e);
  },
  _onChange(e) {
    this._setValue(Ember.$(e.currentTarget).val());
  },
  _onTextClear(e) {
    this.$().val('');
    this._setValue('');

    this._raiseEvents('textCleared', { 'source': this, 'originalEvent': e });
  },
  _onTextSearch(e) {
    e.preventDefault();
    this._setValue(this.$().val());
    this._raiseEvents('textSearch', { 'source': this, 'originalEvent': e });
  },
  /*
  // == Component Properties ====================================================
  classNames: ['inp-txt'],
  tagName: 'input',
  attributeBindings: ['_propertyChangedCallback:data-somevalue', 'name', 'type', 'required', 'title', 'placeholder', 'autofocus', 'value', 'pattern', 'onblur', 'min', 'max', 'maxlength', 'pattern', 'size', 'step'],
  // == Public Properties =======================================================
  allowNegativeNumber: false,
  type: 'text',
  textMode: '',
  isCapital: false,
  clearButtonVisibility: false,
  isGotFocusAutoSelect: false,
  updateSourceTrigger: false,
  inputStyle: '',
  // == Public Event ==========================================================
  textCleared: null,
  textCommit: null,
  textSearch: null,
  //== Event Handler ===========================================================
  _propertyChangedCallback: Ember.computed('value', 'clearButtonVisibility', 'readonly', 'disabled', 'searchButtonVisibility', function () {
    this._onStateChanged();
    const val = this.get('value');

    if (Ember.isEmpty(val)) {
      return 0;
    }

    return val.length;
  }),
  _setValue(val) {
    this.set('value', val);
  },
  _negativeHangule(e) {
    if (this.textMode === 'alphabet' || this.textMode === 'alphaNumeric' || this.textMode === 'decimal' || this.textMode === 'number') {
      Ember.$(e.currentTarget).val(Ember.$(e.currentTarget).val().replace(/[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/g, ''));
    }
  },
  _onInternalTextCommit(e) {
    if (this.get('isDestroyed') || this.get('isDestroying') || this.get('readonly')) {
      return;
    }

    this._negativeHangule(e);

    if (this.updateSourceTrigger === false) {
      this._setValue(Ember.$(e.currentTarget).val());
    }
  },
  _onInternalKeyDown(e) {
    if (e.keyCode === 110 || e.keyCode === 190) {
      if (this.textMode === 'decimal') {
        if (Ember.$(e.currentTarget).val().indexOf('.') !== -1) {
          e.preventDefault();
          return;
        }
      }
      else if (this.textMode === 'alphaNumeric' || this.textMode === 'number') {
        e.preventDefault();
        return;
      }
    }

    if (e.keyCode === 13) {
      e.preventDefault();
      return;
    }

    if (Ember.$.inArray(e.keyCode, [46, 8, 9, 27, 110, 190]) !== -1 ||
      // Allow: Ctrl/cmd+A
      (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
      // Allow: Ctrl/cmd+C
      (e.keyCode === 67 && (e.ctrlKey === true || e.metaKey === true)) ||
      // Allow: Ctrl/cmd+X
      (e.keyCode === 88 && (e.ctrlKey === true || e.metaKey === true)) ||
      // Allow: home, end, left, right
      (e.keyCode >= 35 && e.keyCode <= 39)) {
      // let it happen, don't do anything
      return;
    }

    if (this.textMode === 'alphaNumeric') {
      let regex = new RegExp("^[a-zA-Z]+$");
      let str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
      if (regex.test(str)) {
        return;
      }
    }

    if (this.textMode === 'alphabet') {
      let regex = new RegExp("^[a-zA-Z]+$");
      let str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
      if (regex.test(str)) {
        return;
      } else {
        e.preventDefault();
        return;
      }
    }

    // Ensure that it is a number and stop the keypress
    if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
      if (this.allowNegativeNumber === true && (e.keyCode === 109 || e.keyCode === 189)) {
        if (Ember.isEmpty(Ember.$(e.currentTarget).val())) {
          return;
        }
      }
      e.preventDefault();
    }
  },
  _onFocus(e) {
    if (this.get('isGotFocusAutoSelect') === true && this.$().is('[readonly]') !== true) {
      this.$(e.currentTarget).select();
    }
  },
  _onFoucsout(e){
    this._onInternalTextCommit(e);
  },
  _onBlur(e) {
    this._onInternalTextCommit(e);
  },
  _onKeyDown(e) {
    if (e.keyCode !== 13) {
      this._onInternalKeyDown(e);
    }
  },
  _onKeyPress(e) {
    if (e.keyCode === 13) {
      this._onInternalTextCommit(e);

      this._raiseEvents('textCommit', { 'source': this, 'originalEvent': e });

      e.preventDefault();
      return false;
    }
  },
  _onKeyUp(e) {
    if(this.isCapital){
      Ember.$(e.currentTarget).val(Ember.$(e.currentTarget).val().toUpperCase());
    }
    this._negativeHangule(e);
  },
  _onChange(e) {
    this._setValue(Ember.$(e.currentTarget).val());
  },
  _onTextClear(e) {
    this.$().val('');
    this._setValue('');

    this._raiseEvents('textCleared', { 'source': this, 'originalEvent': e });
  },
  _onTextSearch(e) {
    e.preventDefault();
    this._setValue(this.$().val());
    this._raiseEvents('textSearch', { 'source': this, 'originalEvent': e });
  },
  setCapital(value){
    this.set('isCapital', value);
    this.$().off('keyup');
    if(value){
      this.$().on('keyup', this._onKeyUp.bind(this));
    }
  },
  setTextMode(mode) {
    this.set('textMode', mode);
    this.$().off('keydown')
      .off('keyup')
      .removeClass('ime-disabled');

    if (mode === 'number' || mode === 'decimal' || mode === 'alphaNumeric' || mode === 'alphabet') {
      this.$()
        .on('keydown', this._onKeyDown.bind(this))
        .on('keyup', this._onKeyUp.bind(this))
        .addClass('ime-disabled');
    }
  },
  // == Life Cycle=== ===========================
  didInsertElement() {
    this._super(...arguments);

    this._initializeTextBox();
    this.$()
      .on('focus', this._onFocus.bind(this))
      .on('focusout', this._onFoucsout.bind(this))
      .on('blur', this._onBlur.bind(this))
      .on('keypress', this._onKeyPress.bind(this));

    this.setTextMode(this.get('textMode'));
    this.setCapital(this.get('isCapital'));

    if (this.updateSourceTrigger === true) {
      this.$().on('input propertychange', this._onChange.bind(this));
    }

    this._onStateChanged();
  },
  willDestroyElement() {
    this._super(...arguments);
    this._destroy();
  }
  */
});
