import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';
import GlobalServiceContainerMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

export default Control.extend(GlobalServiceContainerMixin, StatefulComponentMixin, {
  layout,

  tagName: 'g',
  classNames: ['fr-chart-io'],

  chartData: null,
  height: null,
  seriesData: null,
  trace: null,
  width: null,
  xAxis: null,
  xScale: null,
  yAxis: null,
  yScale: null,
  setting: null,
  isValidData: null,
  newScale: null,

  _chartData: Ember.computed.alias('chartData').readOnly(),
  _trace: Ember.computed.alias('trace').readOnly(),
  _width: Ember.computed.alias('width').readOnly(),
  _xAxis: Ember.computed.alias('xAxis').readOnly(),
  _xScale: Ember.computed.alias('xScale').readOnly(),
  _yAxis: Ember.computed.alias('yAxis').readOnly(),
  _yScale: Ember.computed.alias('yScale').readOnly(),
  _isValidData: Ember.computed.alias('isValidData').readOnly(),
  _newScale: Ember.computed.alias('newScale').readOnly(),
  _browserType: null,

  _height: Ember.computed('height', 'setting', function() {
    return this.get('height') - this.get('_settingPaddingBottom');
  }),
  _seriesData: Ember.computed('chartData', function() {
    if(Ember.isEmpty(this.get('chartData'))){
      return null;
    }
    return this.get('chartData').series[0];
  }),
  _settingPaddingTop: Ember.computed('setting', function() {
    return this.get('setting').paddingTop;
  }),
  _settingPaddingRight: Ember.computed('setting', function() {
    return this.get('setting').paddingRight;
  }),
  _settingPaddingLeft: Ember.computed('setting', function() {
    return this.get('setting').paddingLeft;
  }),
  _settingPaddingBottom: Ember.computed('setting', function() {
    return this.get('setting').paddingBottom;
  }),
  _settingNormalOpacity: Ember.computed('setting', function() {
    return this.get('setting').normalOpacity;
  }),
  _settingDarkOpacity: Ember.computed('setting', function() {
    return this.get('setting').darkOpacity;
  }),
  _settingTransparentOpacity: Ember.computed('setting', function() {
    return this.get('setting').transparentOpacity;
  }),
  _settingGlyphiconPrefix: Ember.computed('setting', function() {
    return this.get('setting').glyphiconPrefix;
  }),

  onPropertyInit() {
    this._super(...arguments);
    this._logTrace('c-chart-io.onPropertyInit()');

    this.setStateProperties(['_browserType']);

    if (!this.hasState()) {
      this.set('_browserType', this._getBrowserType());
    }
  },

  init() {
    this._super(...arguments);
    this._logTrace('c-chart-io.init()');
  },

  didInsertElement() {
    this._super(...arguments);
    this._logTrace('c-chart-io.didInsertElement()');
  },

  didRender() {
    this._super(...arguments);
    this._logTrace('c-chart-io.didRender()');

    if(Ember.isEmpty(this.get('_chartData')) === true) {
      return;
    }

    if(this.get('_isValidData') === false) {
      return;
    }

    this._createSeries();
  },

  willDestroyElement() {
    this._super(...arguments);
    this._logTrace('c-chart-io.willDestroyElement()');

    // 이벤트 리스너 해제
    this._removeEventListener();
    this._removeDom();

    // 클로저 해제
    this._logTrace = null;
  },

  _getBrowserType() {
    const browserName = this.get('fr_GlobalSystemService').browserName;

    return browserName.toLowerCase();
  },

  _logTrace(text) {
    if(this.get('_trace') === true) {
      Ember.Logger.log(text);
    }
  },

  _convertDateString(date, format) {
    return this.get('fr_I18nService').formatDate(date, format);
  },

  _createSeries() {

    this._logTrace('c-chart-io._createSeries()');
    const zero = 0;

    this._removeEventListener();
    this._removeDom();

    const series = this.get('_chartData').series[zero];

    if(series.data.length === zero) {
      return;
    }

    // tooltipTemplate 을 위한 svg 의 sibling 개체
    const p = this.$().parent().parent();

    if(p.children('div.chartTooltipTemplate').length === zero) {
      p.append('<div class=\'chartTooltipTemplate\'></div>');
    }

    const el = this.$().parent().get(zero);
    const seriesRootG = d3.select(el)
        .select('.main')
        .select('.chartRoot')
        .append('g')
        .attr('class', 'chart seriesRoot' + series.no)
        .attr('data-id', 'seriesRoot' + series.no);

    // IO - Outer
    this._drawOuter(seriesRootG, series);

    // IO - Inner
    this._drawInner(seriesRootG, series);
  },

  _drawOuter(seriesRootG, series) {
    const minusOne = -1;
    const zero = 0;
    const xScaleFunction = this.get('_xScale');
    const yScaleFunction = this.get('_yScale');
    const paddingLeft = this.get('_settingPaddingLeft');
    const idProperty = series.config.idProperty;
    const dateFormat = this.get('_chartData').timeFormat.dataFormat;
    const newScale = this.get('_newScale');

    // outer positive
    seriesRootG
      .selectAll('.chart.io.outerPositive.series' + series.no)
      .data(series.data)
      .enter()
      .append('rect')
      .attr('class', 'chart io outerPositive series' + series.no)
      .attr('x', function(d) {
        if(Ember.isEmpty(xScaleFunction(d[series.config.xAxisProperty]))) {
          return paddingLeft * minusOne;
        }

        const temp = series.config.outerBar.width * 0.5 * newScale;
        const w = xScaleFunction(d[series.config.xAxisProperty]) - temp;

        return w;
      })
      .attr('y', function(d) {
        return yScaleFunction(d[series.config.outerBar.positive.property]);
      })
      .attr('width', series.config.outerBar.width * newScale)
      .attr('height', function(d) {
        return yScaleFunction(zero) - yScaleFunction(d[series.config.outerBar.positive.property]);
      })
      .attr('fill', function(d) {
        let result;

        if(d.isSubTotal) {
          result = series.config.subTotalBar.positive.color;
        } else {
          result = series.config.outerBar.positive.color;
        }

        return result;
      })
      .on('mouseover', () => {
        this._logTrace('fr-chart-io.outerPositive.mouseover()');
        this._raiseEvents('mouseoverSeriesCB', series);
        d3.event.stopPropagation();
      })
      .on('mouseout', () => {
        this._logTrace('fr-chart-io.outerPositive.mouseout()');
        this._raiseEvents('mouseoutSeriesCB', series);
        d3.event.stopPropagation();
      })
      .on('click', d => {
        const id = d[idProperty];
        const obj = { series: series, id: id, property: series.config.outerBar.positive.property };

        this._raiseEvents('clickDataCB', obj);
        d3.event.stopPropagation();
      });

    // outer positive tooltipTemplate
    let marginBottom = 19;
    // 30
    const browserType = this.get('_browserType');

    if(browserType === 'edge' || browserType === 'firefox') {
      marginBottom = 18;
      //25
    }

    const fontWidth = 7;

    seriesRootG.selectAll('.chart.io.outerPositiveTooltip.series' + series.no)
      .data(series.data)
      .enter()
      .append('svg:foreignObject')
      .attr('class', 'chart io outerPositiveTooltip series' + series.no)
      .attr('style', 'display: none')
      .attr('x', function(d) {
        if(Ember.isEmpty(xScaleFunction(d[series.config.xAxisProperty]))) {
          return paddingLeft * minusOne;
        }
        const len = d[series.config.outerBar.positive.property].toString().length;
        const width = fontWidth * len;
        const halfWidth = width * 0.5;
        const w = xScaleFunction(d[series.config.xAxisProperty]) - halfWidth;

        return w;
      })
      .attr('y', function(d) {
        return yScaleFunction(d[series.config.outerBar.positive.property]) - marginBottom;
      })
      .attr('width', function(d) {
        const len = d[series.config.outerBar.positive.property].toString().length;

        return len * fontWidth;
      })
      .attr('height', 30)
      .html(d => {
        let result;

        if(Ember.isEmpty(d.id)) {
          return;
        }

        if(d.isSubTotal) {
          result = series.config.subTotalBar.positive.tooltipTemplate;
        } else {
          result = series.config.outerBar.positive.tooltipTemplate;
        }

        for(const name in d) {
          let val = d[name];

          if( typeof val === 'object' && val instanceof Date) {
            val = this._convertDateString(val, dateFormat);
          }

          const regexp = new RegExp('{{' + name + '}}', 'gi');

          result = result.replace(regexp, val);
        }

        return result;
      });

    // outer negative
    seriesRootG
      .selectAll('.chart.io.outerNegative.series' + series.no)
      .data(series.data)
      .enter()
      .append('rect')
      .attr('class', 'chart io outerNegative series' + series.no)
      .attr('x', function(d) {
        if(Ember.isEmpty(xScaleFunction(d[series.config.xAxisProperty]))) {
          return paddingLeft * minusOne;
        }
        const temp = series.config.outerBar.width * 0.5 * newScale;
        const w = xScaleFunction(d[series.config.xAxisProperty]) - temp;

        return w;
      })
      .attr('y', function() {
        return yScaleFunction(0);
      })
      .attr('width', series.config.outerBar.width * newScale)
      .attr('height', function(d) {
        return yScaleFunction(d[series.config.outerBar.negative.property]) - yScaleFunction(zero);
      })
      .attr('fill', function(d) {
        let result;

        if(d.isSubTotal) {
          result = series.config.subTotalBar.negative.color;
        } else {
          result = series.config.outerBar.negative.color;
        }

        return result;
      })
      .on('mouseover', () => {
        this._logTrace('fr-chart-io.outerNegative.mouseover()');
        this._raiseEvents('mouseoverSeriesCB', series);
        d3.event.stopPropagation();
      })
      .on('mouseout', () => {
        this._logTrace('fr-chart-io.outerNegative.mouseout()');
        this._raiseEvents('mouseoutSeriesCB', series);
        d3.event.stopPropagation();
      })
      .on('click', d => {
        const id = d[idProperty];
        const obj = { series: series, id: id, property: series.config.outerBar.negative.property };

        this._raiseEvents('clickDataCB', obj);
        d3.event.stopPropagation();
      });

    // outer negative tooltipTemplate
    const marginTop = 2;

    seriesRootG.selectAll('.chart.io.outerNegativeTooltip.series' + series.no)
      .data(series.data)
      .enter()
      .append('svg:foreignObject')
      .attr('class', 'chart io outerNegativeTooltip series' + series.no)
      .attr('style', 'display: none')
      .attr('x', function(d) {
        if(Ember.isEmpty(xScaleFunction(d[series.config.xAxisProperty]))) {
          return paddingLeft * -1;
        }
        const len = Math.abs(d[series.config.outerBar.negative.property]).toString().length + 0.5;
        const width = fontWidth * len;
        const halfWidth = width * 0.5;
        const w = xScaleFunction(d[series.config.xAxisProperty]) - halfWidth;

        return w;
      })
      .attr('y', function(d) {
        const y = yScaleFunction(d[series.config.outerBar.negative.property]) + marginTop;

        return y;
      })
      .attr('width', function(d) {
        const len = Math.abs(d[series.config.outerBar.negative.property]).toString().length + 0.5;

        return len * fontWidth;
      })
      .attr('height', 30)
      .html(d => {
        let result;

        if(Ember.isEmpty(d.id)) {
          return;
        }

        if(d.isSubTotal) {
          result = series.config.subTotalBar.negative.tooltipTemplate;
        } else {
          result = series.config.outerBar.negative.tooltipTemplate;
        }

        for(const name in d) {
          let val = d[name];

          if( typeof val === 'object' && val instanceof Date) {
            val = this._convertDateString(val, dateFormat);
          }

          const regexp = new RegExp('{{' + name + '}}', 'gi');

          result = result.replace(regexp, val);
        }

        return result;
      });
  },

  _drawInner(seriesRootG, series) {
    const zero = 0;
    const minusOne = -1;
    const xScaleFunction = this.get('_xScale');
    const yScaleFunction = this.get('_yScale');
    const paddingLeft = this.get('_settingPaddingLeft');
    const idProperty = series.config.idProperty;
    const dateFormat = this.get('_chartData').timeFormat.dataFormat;
    const newScale = this.get('_newScale');

    // inner positive
    seriesRootG
      .selectAll('.chart.io.innerPositive.series' + series.no)
      .data(series.data)
      .enter()
      .append('rect')
      .attr('class', 'chart io innerPositive series' + series.no)
      .attr('x', function(d) {
        if(Ember.isEmpty(xScaleFunction(d[series.config.xAxisProperty]))) {
          return paddingLeft * -1;
        }

        let w = series.config.outerBar.innerBar.width * 0.5 * newScale;
        w = xScaleFunction(d[series.config.xAxisProperty]) - w;

        return w;
      })
      .attr('y', function(d) {
        const y = yScaleFunction(d[series.config.outerBar.innerBar.positive.property]);

        return y;
      })
      .attr('width', series.config.outerBar.innerBar.width * newScale)
      .attr('height', function(d) {
        return yScaleFunction(zero) - yScaleFunction(d[series.config.outerBar.innerBar.positive.property]);
      })
      .attr('fill', d => {
        let result;

        if(d.isSubTotal) {
          result = series.config.subTotalBar.innerBar.positive.color;
        } else {
          result = series.config.outerBar.innerBar.positive.color;
        }

        return result;
      })
      .on('mouseover', () => {
        this._logTrace('fr-chart-io.innerPositive.mouseover()');
        this._raiseEvents('mouseoverSeriesCB', series);
        d3.event.stopPropagation();
      })
      .on('mouseout', () => {
        this._logTrace('fr-chart-io.innerPositive.mouseout()');
        this._raiseEvents('mouseoutSeriesCB', series);
        d3.event.stopPropagation();
      })
      .on('click', d => {
        const id = d[idProperty];
        const obj = { series: series, id: id, property: series.config.outerBar.innerBar.positive.property };

        this._raiseEvents('clickDataCB', obj);
        d3.event.stopPropagation();
      });

    // inner positive tooltipTemplate
    const marginBottom = 18;
    const fontWidth = 7;

    seriesRootG.selectAll('.chart.io.innerPositiveTooltip.series' + series.no)
      .data(series.data)
      .enter()
      .append('svg:foreignObject')
      .attr('class', 'chart io innerPositiveTooltip series' + series.no)
      .attr('style', 'display: none')
      .attr('x', function(d) {
        if(Ember.isEmpty(xScaleFunction(d[series.config.xAxisProperty]))) {
          return paddingLeft * minusOne;
        }

        let w = series.config.outerBar.innerBar.width * newScale;
        w = xScaleFunction(d[series.config.xAxisProperty]) + w;

        return w;
      })
      .attr('y', function(d) {
        const y = yScaleFunction(d[series.config.outerBar.innerBar.positive.property]);

        return y;
      })
      .attr('width', function(d) {
        const len = d[series.config.outerBar.innerBar.positive.property].toString().length;

        return len * fontWidth;
      })
      .attr('height', 30)
      .html(d => {
        let result;

        if(Ember.isEmpty(d.id)) {
          return;
        }

        if(d.isSubTotal) {
          result = series.config.subTotalBar.innerBar.positive.tooltipTemplate;
        } else {
          result = series.config.outerBar.innerBar.positive.tooltipTemplate;
        }

        for(const name in d) {
          let val = d[name];

          if( typeof val === 'object' && val instanceof Date) {
            val = this._convertDateString(val, dateFormat);
          }

          const regexp = new RegExp('{{' + name + '}}', 'gi');

          result = result.replace(regexp, val);
        }

        return result;
      });

    // inner negative
    seriesRootG
      .selectAll('.chart.io.innerNegative.series' + series.no)
      .data(series.data)
      .enter()
      .append('rect')
      .attr('class', 'chart io innerNegative series' + series.no)
      .attr('x', function(d) {
        if(Ember.isEmpty(xScaleFunction(d[series.config.xAxisProperty]))) {
          return paddingLeft * minusOne;
        }
        let w = series.config.outerBar.innerBar.width * 0.5 * newScale;
        w = xScaleFunction(d[series.config.xAxisProperty]) - w;

        return w;
      })
      .attr('y', function() {
        return yScaleFunction(0);
      })
      .attr('width', series.config.outerBar.innerBar.width * newScale)
      .attr('height', function(d) {
        return yScaleFunction(d[series.config.outerBar.innerBar.negative.property]) - yScaleFunction(0);
      })
      .attr('fill', function(d) {
        let result;

        if(d.isSubTotal) {
          result = series.config.subTotalBar.innerBar.negative.color;
        } else {
          result = series.config.outerBar.innerBar.negative.color;
        }

        return result;
      })
      .on('mouseover', () => {
        this._logTrace('fr-chart-io.innerNegative.mouseover()');
        this._raiseEvents('mouseoverSeriesCB', series);
        d3.event.stopPropagation();
      })
      .on('mouseout', () => {
        this._logTrace('fr-chart-io.innerNegative.mouseout()');
        this._raiseEvents('mouseoutSeriesCB', series);
        d3.event.stopPropagation();
      })
      .on('click', d => {
        const id = d[idProperty];
        const obj = { series: series, id: id, property: series.config.outerBar.innerBar.negative.property };

        this._raiseEvents('clickDataCB', obj);
        d3.event.stopPropagation();
      });

    // inner negative tooltipTemplate
    seriesRootG.selectAll('.chart.io.innerNegativeTooltip.series' + series.no)
      .data(series.data)
      .enter()
      .append('svg:foreignObject')
      .attr('class', 'chart io innerNegativeTooltip series' + series.no)
      .attr('style', 'display: none')
      .attr('x', function(d) {
        if(Ember.isEmpty(xScaleFunction(d[series.config.xAxisProperty]))) {
          return paddingLeft * -1;
        }

        let temp = series.config.outerBar.innerBar.width * newScale;

        temp += xScaleFunction(d[series.config.xAxisProperty]);

        return temp;
      })
      .attr('y', function(d) {
        try{
          const y = yScaleFunction(d[series.config.outerBar.innerBar.negative.property]) - marginBottom;

          return y;
        } catch(e) {
          console.log(e);
        }
      })
      .attr('width', function(d) {
        const len = Math.abs(d[series.config.outerBar.innerBar.negative.property]).toString().length + 0.5;

        return len * fontWidth;
      })
      .attr('height', 30)
      .html(d => {
        let result;

        if(Ember.isEmpty(d.id)) {
          return;
        }
        if(d.isSubTotal) {
          result = series.config.subTotalBar.innerBar.negative.tooltipTemplate;
        } else {
          result = series.config.outerBar.innerBar.negative.tooltipTemplate;
        }

        for(const name in d) {
          let val = d[name];

          if( typeof val === 'object' && val instanceof Date) {
            val = this._convertDateString(val, dateFormat);
          }

          const regexp = new RegExp('{{' + name + '}}', 'gi');

          result = result.replace(regexp, val);
        }

        return result;
      });
  },

  _removeEventListener() {
    if(Ember.isEmpty(this.get('_seriesData'))){
      return;
    }

    const zero = 0;
    const series = this.get('_seriesData');
    const seriesNo = series.no;
    const mouseOverOut = [
      '.chart.io.outerPositive.series' + seriesNo,
      '.chart.io.outerNegative.series' + seriesNo,
      '.chart.io.innerPositive.series' + seriesNo,
      '.chart.io.innerNegative.series' + seriesNo
    ];

    const el = this.$().parent().get(zero);
    const thisObj = d3.select(el).select('.seriesRoot' + seriesNo);

    for(let i=0; i < mouseOverOut.length; i++) {
      thisObj.selectAll(mouseOverOut[i]).on('mouseover', null).on('mouseout', null);
    }
  },

  _removeDom() {
    const zero = 0;
    const series = this.get('_seriesData');
    const el = this.$().parent().get(zero);

    d3.select(el)
      .select('.main >.chartRoot > .seriesRoot' + series.no)
      .remove();
  },

  actions: {
  },

});