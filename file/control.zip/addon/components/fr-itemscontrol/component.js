import Control from '../fr-control/component';

export default Control.extend({
  //= public Properties =================================================
  itemsSource: null
});