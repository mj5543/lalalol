import Ember from 'ember';
import layout from './template';

const { computed } = Ember;

export default Ember.Component.extend({
  tagName: 'th',
  classNameBindings: [ '_gridHeadCellClass', '_nolineAfter:noline-after' ],
  attributeBindings: [ 'cellIndex:data-head-cell-index', '_rowspan:rowspan', '_colspan:colspan', '_key:data-column-key', '_topKey:data-column-top-key', 'tabindex' ],
  layout,

  tabindex: -1,
  
  _rowspan: computed.oneWay('column.rowspan').readOnly(),
  _colspan: computed.oneWay('column.colspan').readOnly(),
  _key: computed.oneWay('column.key').readOnly(),
  _topKey: computed.oneWay('column.topKey').readOnly(),
  _title: computed.oneWay('column.title').readOnly(),
  _styleOwner: computed.oneWay('column.styleOwner').readOnly(),
  _hideLastColumnResizer: computed.or('_frozenTable', '_notFlexResizeType').readOnly(),
  _hideColumnResizer: computed.and('_hideLastColumnResizer', '_isLastColumn').readOnly(),
  _notFrozenTable: computed.not('_frozenTable').readOnly(),
  _nolineAfter: computed.and('_notFrozenTable', '_isLastColumn').readOnly(),

  _gridHeadCellClass: computed('_gridGuid', function () {
    return `${this.get('_gridGuid')}-head-cell`;
  }).readOnly(),

  _isLastColumn: computed('_styleOwner', '_lastBindingColumnKey', function () {
    return this.get('_styleOwner') === this.get('_lastBindingColumnKey');
  }).readOnly(),

  _sortingTag: computed('_sortingColumns.[]', 'column',function () {
    const _sortingColumns = this.get('_sortingColumns'), column = this.get('column'),
      sortingColumn = _sortingColumns.findBy('column', column);

    if (!Ember.isNone(sortingColumn)) {
      if (sortingColumn.direction === 'asc') {
        return Ember.String.htmlSafe('<span class="sorting on"><span class="blind">sortint</span></span>');
      }

      return Ember.String.htmlSafe('<span class="sorting"><span class="blind">sortint</span></span>');
    }

    return Ember.String.htmlSafe('<!---->');
  }).readOnly(),

  _menuTag: computed('column.menuTemplate',function () {
    if (this.get('column.menuTemplate')) {
      return Ember.String.htmlSafe(`<span class="head-menu ${this.get('_gridGuid')}-head-cell-menu"></span>`);
    }

    return Ember.String.htmlSafe('<!---->');
  }).readOnly(),

  init() {
    this._super(...arguments);

    if (this.get('column.headTemplate')) {
      Ember.defineProperty(this, 'layout', computed(function () {
        return Ember.HTMLBars.compile(`<div style="{{_htmlSafeHeadLineHeight}}" tabindex="-1"><div>{{yield (hash ${this.get('column.headTemplate')}=(component 'fr-grid-head-cell-template' column=column))}}</div></div>{{_menuTag}}
          {{#unless _hideColumnResizer}}<div class="${this.get('_gridGuid')}-head-cell-resizer resizer" data-target-column="{{_styleOwner}}"></div>{{/unless}}`);
      }));
    }
  },

  didInsertElement() {
    this._super(...arguments);

    this.$().on('_getComponent', function (event, param) {
      param.component = this;
      event.stopPropagation();
    }.bind(this));
  },

  willDestroyElement() {
    this._super(...arguments);

    this.$().off('_getComponent');
  },
});