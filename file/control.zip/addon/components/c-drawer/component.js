import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';

export default Control.extend({
  layout,
  tagName: 'div',
  classNames: ['drawer-navigation'],
  //duration: 500,
  navComponent: 'c-drawer-nav',
  bodyComponent: 'c-drawer-body',
  //attributeBindings: ['_watchisOpen:data-name'],
  sideNavClose: true,
  didInsertElement() {
    this._super(...arguments);
    this.$('.drawer-opener').on(`click.${this.get('componentGuid')}-drawer`, function () {
      this.toggleProperty('isOpen');
    }.bind(this));
    if (this.get('container')) {
      this.$('.drawer-shutter').on(`click.${this.get('componentGuid')}-drawer`, function () {
        this.set('isOpen', false);
      }.bind(this));
    }
  },
  willDestroyElement() {
    this.$('.drawer-opener').off(`click.${this.get('componentGuid')}-drawer`);
    if (this.get('container')) {
      this.$('.drawer-shutter').off(`click.${this.get('componentGuid')}-drawer`);
    } else {
      const win = this.$().closest('.box-module');
      
      if (win.length > 0) {
        win.find('.sidenav-curton, .drawer-shutter').off(`click.${this.get('componentGuid')}-drawer`);
      }
    }
    this.set('sideNavClose', true);
    this._super(...arguments);
  },
  _observedProperty01: Ember.computed('isOpen', function () {
    if (this.get('isOpen')) {
      Ember.run.scheduleOnce('afterRender', this, '_openNav');
    } else {
      Ember.run.scheduleOnce('afterRender', this, '_closeNav');
    }
  }),
  _openNav() {
    if (this.get('container')) {
      this.$('.sidenav').css('width', this.get('width'));
      if (this.get('mode') === 'open') {
        this.$('.draw-content-area').css('backgroundColor', 'rgba(0,0,0,0.4)');
      }
    } else {
      let win = this.$().closest('.wormhole-parent');
      
      if (win.length > 0) {
        if (win.find('> .sidenav-container').length === 0) {
          if (this.get('mode') === 'open') {
            win.append(`<div class='sidenav-curton'></div>`);
          }
          win.append(`<div class='sidenav-container ${this.get('position')}'></div>`);
          win.find('.sidenav-container').append(this.$().find('.inner').clone());
          win.find('.sidenav-container').css('width', this.get('width'));
          win.find('.sidenav-curton, .drawer-shutter').on(`click.${this.get('componentGuid')}-drawer`, function () {
            this.set('isOpen', false);
          }.bind(this));
          this.set('sideNavClose', false);
        }
      }
      win = null;
    }
    this._raiseEvents('onOpened', { 'source': this });
  },
  _closeNav() {
    if (this.get('container')) {
      this.$('.sidenav').css('width', '0');
      if (this.get('mode') === 'open') {
        this.$('.draw-content-area').css('backgroundColor', 'transparent');
      }
    } else {
      let win = this.$().closest('.wormhole-parent');
  
      if (win.length > 0) {
        win.find('.sidenav-curton, .drawer-shutter').off(`click.${this.get('componentGuid')}-drawer`);
        win.find('> .sidenav-curton, > .sidenav-container').remove();
        this.set('sideNavClose', true);
      }
      win = null;
    }
    this._raiseEvents('onClosed', { 'source': this });
  },
  actions: {
    dimClick() {
      this.set('isOpen', false);
    }
  },
});