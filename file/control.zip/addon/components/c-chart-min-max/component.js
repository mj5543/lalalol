import Ember from 'ember';
import layout from './template';
//import CHIS from 'framework/chis-framework';
import Control from '../c-control/component';
import GlobalServiceContainerMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

export default Control.extend(GlobalServiceContainerMixin, StatefulComponentMixin, {
  layout,

  tagName: 'g',
  classNames: ['fr-chart-min-max'],

  chartData: null,
  parentType: null,
  height: null,
  seriesData: null,
  trace: null,
  width: null,
  xAxis: null,
  xScale: null,
  yAxis: null,
  yScale: null,
  setting: null,
  isValidData: null,
  removeSeries: null,

  _postfixMax: null,
  _postfixMin: null,

  _chartData: Ember.computed.alias('chartData').readOnly(),
  // isEmpty 면 일반 차트로 처리 , flowsheet 면 flowsheet 차트로 처리
  _parentType: Ember.computed.alias('parentType').readOnly(),
  ////_height: Ember.computed.alias('height').readOnly(),
  _seriesData: Ember.computed.alias('seriesData').readOnly(),
  _trace: Ember.computed.alias('trace').readOnly(),
  _width: Ember.computed.alias('width').readOnly(),
  _xAxis: Ember.computed.alias('xAxis').readOnly(),
  _xScale: Ember.computed.alias('xScale').readOnly(),
  _yAxis: Ember.computed.alias('yAxis').readOnly(),
  _yScale: Ember.computed.alias('yScale').readOnly(),
  _isValidData: Ember.computed.alias('isValidData').readOnly(),
  _removeSeries: Ember.computed.alias('removeSeries').readOnly(),

  _height: Ember.computed('height', 'setting', function() {
    return this.get('height') - this.get('_settingPaddingBottom');
  }),
  _settingPaddingTop: Ember.computed('setting', function() {
    return this.get('setting').paddingTop;
  }),
  _settingPaddingRight: Ember.computed('setting', function() {
    return this.get('setting').paddingRight;
  }),
  _settingPaddingLeft: Ember.computed('setting', function() {
    return this.get('setting').paddingLeft;
  }),
  _settingPaddingBottom: Ember.computed('setting', function() {
    return this.get('setting').paddingBottom;
  }),
  _settingNormalOpacity: Ember.computed('setting', function() {
    return this.get('setting').normalOpacity;
  }),
  _settingDarkOpacity: Ember.computed('setting', function() {
    return this.get('setting').darkOpacity;
  }),
  _settingTransparentOpacity: Ember.computed('setting', function() {
    return this.get('setting').transparentOpacity;
  }),
  _settingGlyphiconPrefix: Ember.computed('setting', function() {
    return this.get('setting').glyphiconPrefix;
  }),

  onPropertyInit() {
    this._super(...arguments);
    this._logTrace('c-chart-min-max.onPropertyInit()');

    this.setStateProperties([]);
  },

  init() {
    this._super(...arguments);
    this._logTrace('c-chart-min-max.init()');

    this.set('_postfixMax', 'Max');
    this.set('_postfixMin', 'Min');
  },

  didInsertElement() {
    this._super(...arguments);
    this._logTrace('c-chart-min-max.didInsertElement()');
  },

  didRender() {
    this._super(...arguments);
    this._logTrace('c-chart-min-max.didRender()');

    if(Ember.isEmpty(this.get('_chartData'))) {
      return;
    }

    if(this.get('_isValidData') === false) {
      return;
    }

    this._createSeries();
  },

  willDestroyElement() {
    this._super(...arguments);
    this._logTrace('fr-chart-min-max.willDestroyElement()');

    // 이벤트 리스너 제거
    this._removeEventListener();
    this._removeDom();

    // 클로저 제거
    this._convertDateFormat = null;
    this._logTrace = null;

  },

  _logTrace(text) {
    if(this.get('_trace') === true) {
      Ember.Logger.log(text);
    }
  },

  _convertDateString(date, format) {
    return this.get('fr_I18nService').formatDate(date, format);
  },
  // date타입 체크 후 변경
  _convertDateFormat(date, isTimeXAxis) {
    if(isTimeXAxis) {
      if(date instanceof Date && date.valueOf() && !Number.isNaN(date.valueOf())) {
        return date;
      } else {
        return new Date(date);
      }
    } else {
      return date;
    }
  },
  _createSeries() {
    const zero = 0;
    const half = 0.5;
    const adjustSymbolSize = 10;
    // const twenty = 20;
    const isTimeXAxis = this.get('_chartData').isTimeXAxis;
    const series = this.get('_seriesData');

    this._logTrace('c-chart-min-max._createSeries()');
    this._removeEventListener();
    this._removeDom();

    // 삭제된 데이터 그래프 삭제
    if (this.get('_removeSeries')) {
      this._removeSeriesDom(this.get('_removeSeries'));
    }

    if(series.data.length === zero) {
      return;
    }

    const xScaleFunction = this.get('_xScale');
    if(Ember.isEmpty(xScaleFunction)) {
      return;
    }
    const glyphiconPrefix = this.get('_settingGlyphiconPrefix');
    const tooltipTemplate = series.config.tooltipTemplate;
    const postfixMax = this.get('_postfixMax');
    const postfixMin = this.get('_postfixMin');
    const toBeSymbolSize = series.config.symbolSize + adjustSymbolSize;
    const dateFormat = this.get('_chartData').timeFormat.dataFormat;
    let isRotateBottomImage = series.config.isRotateBottomImage;

    let yScaleFunction = null;

    if (series.config.yAxisPosition) {
      const yScale  = this.get('_yScale').filter(obj => {
        const pos = series.config.yAxisPosition || 1;
        return obj.position === pos;
      });
      if (yScale.length) {
        yScaleFunction = yScale[0].scale;
      }
    } else {
      yScaleFunction = this.get('_yScale')
    }

    if(Ember.isEmpty(isRotateBottomImage)) {
      isRotateBottomImage = false;
    }

    // tooltipTemplate 을 위한 svg 의 sibling 개체
    const p = this.$().parent().parent();

    if(p.children('div.chartTooltipTemplate').length === zero) {
      p.append('<div class=\'chartTooltipTemplate\'></div>');
    }

    const toolTip = d3.select(p[zero]).selectAll('div.chartTooltipTemplate');
    const el = this.$().parent().get(zero);

    let seriesRootG;

    if(this.get('_parentType') === 'flowsheet') {
      seriesRootG = d3.select(el)
        .select('.main')
        .select('.chartRoot')
        .append('g')
        .attr('class', 'chart seriesRoot' + series.no)
        .attr('data-id', 'seriesRoot' + series.no);
    } else {
      // el = this.$().parent().get(zero);
      seriesRootG = d3.select(el)
        .select('.chartRenderArea')
        .append('g')
        .attr('class', 'chart seriesRoot' + series.no)
        .attr('data-id', 'seriesRoot' + series.no);
    }
    // minMax
    seriesRootG
      .selectAll('.chart.minMax.series' + series.no)
      .data(series.data)
      .enter()
      .append('rect')
      .attr('class', 'chart minMax series' + series.no)
      .attr('x', (d) => {
        //const half = 0.5;
        const tempWidth = series.config.strokeWidth * 0.5;
        const w = xScaleFunction(this._convertDateFormat(d[series.config.xAxisProperty], isTimeXAxis)) - tempWidth;

        return w;
      })
      .attr('y', function(d) {
        return yScaleFunction(d[series.config.yAxisProperty + postfixMax]);
      })
      .attr('width', series.config.strokeWidth)
      .attr('height', function(d) {
        // 하나만 있을 때 체크
        const min = d[series.config.yAxisProperty + postfixMin];
        const max = d[series.config.yAxisProperty + postfixMax];

        if(Ember.isEmpty(min) || Ember.isEmpty(max)) {
          return 0;
        }
        // 하나만 있을 때 체크.

        const tempMin = yScaleFunction(d[series.config.yAxisProperty + postfixMin]);
        const tempMax = yScaleFunction(d[series.config.yAxisProperty + postfixMax]);

        return tempMin - tempMax;
      })
      .attr('fill', series.config.strokeColor)
      .on('mouseover', () => {
        this._logTrace('fr-chart-min-max.minMax.mouseover()');
        this._raiseEvents('mouseoverSeriesCB', series);
        d3.event.stopPropagation();
      })
      .on('mouseout', () => {
        this._logTrace('fr-chart-min-max.minMax.mouseout()');
        toolTip.style('display', 'none');
        this._raiseEvents('mouseoutSeriesCB', series);
        d3.event.stopPropagation();
      })
      .on('mousemove', d => {
        this._logTrace('fr-chart-min-max.minMax.mousemove()');
        const adjustX = 10;
        const adjustY = 20;
        const x = d3.event.pageX + adjustX;
        const y = d3.event.pageY + adjustY;

        toolTip.style('left', x + 'px');
        toolTip.style('top', y + 'px');
        toolTip.style('display', 'inline-block');

        if(Ember.isEmpty(tooltipTemplate) || Ember.isBlank(tooltipTemplate) ) {
          let val = d[series.config.tooltipProperty];

          if( typeof val === 'object' && val instanceof Date) {
            val = this._convertDateString(val, dateFormat);
          }

          toolTip.html(val);
        } else {
          let result = tooltipTemplate;

          for(const name in d) {
            let val = d[name];

            if( typeof val === 'object' && val instanceof Date) {
              val = this._convertDateString(val, dateFormat);
            }
            const regexp = new RegExp('{{' + name + '}}', 'gi');

            result = result.replace(regexp, val);
          }
          toolTip.html(result);
        }
      });

    // minMaxTopSymbol
    seriesRootG
      .selectAll('.chart.minMaxTopSymbol.series' + series.no)
      .data(series.data)
      .enter()
      .append('svg:foreignObject')
      .attr('class', 'chart foreignObject series' + series.no )
      .attr('x', (d) => {
        const temp = toBeSymbolSize * 0.5;
        const w = xScaleFunction(this._convertDateFormat(d[series.config.xAxisProperty], isTimeXAxis)) - temp;

        return w;
      })
      .attr('y', function(d) {
        if(Ember.isEmpty(d[series.config.yAxisProperty + postfixMax])) {
          return -50;
        }

        const temp2 = toBeSymbolSize * 0.5;
        const w = yScaleFunction(d[series.config.yAxisProperty + postfixMax]) - temp2;

        return w;
      })
      // [COMPATIBILITY-EDGE]
      .attr('width', 20)
      .attr('height', 20)
      .append('xhtml:i')
      .attr('class', 'chart minMaxTopSymbol series' + series.no + ' ' + glyphiconPrefix + ' md-' + toBeSymbolSize)
      .style('color', series.config.symbolColor)
      .text(series.config.symbolType.replace(glyphiconPrefix + '-',''))
      .on('mouseover', () => {
        this._logTrace('fr-chart-min-max.minMaxTopSymbol.mouseover()');
        this._raiseEvents('mouseoverSeriesCB', series);
        d3.event.stopPropagation();
      })
      .on('mouseout', () => {
        this._logTrace('fr-chart-min-max.minMaxTopSymbol.mouseout()');
        this._raiseEvents('mouseoutSeriesCB', series);
        d3.event.stopPropagation();
      });

    // minMaxBottomSymbol
    seriesRootG
      .selectAll('.chart.minMaxBottomSymbol.series' + series.no)
      .data(series.data)
      .enter()
      .append('svg:foreignObject')
      .attr('class', 'chart foreignObject series' + series.no )
      .attr('x', (d) => {
        const tempX = toBeSymbolSize * half;
        const w = xScaleFunction(this._convertDateFormat(d[series.config.xAxisProperty], isTimeXAxis)) - tempX;

        return w;
      })
      .attr('y', function(d) {
        if(Ember.isEmpty(d[series.config.yAxisProperty + postfixMin])) {
          return -50;
        }

        const tempY = toBeSymbolSize * half;
        const w = yScaleFunction(d[series.config.yAxisProperty + postfixMin]) - tempY;

        return w;
      })
      // [COMPATIBILITY-EDGE]
      .attr('width', 20)
      .attr('height', 20)
      .attr('transform', (d) => {
        let degree = 0;

        if(isRotateBottomImage) {
          degree = 180;
        }

        const tempSize = toBeSymbolSize * half;
        let x = xScaleFunction(this._convertDateFormat(d[series.config.xAxisProperty], isTimeXAxis)) - tempSize;
        let y = yScaleFunction(d[series.config.yAxisProperty + postfixMin]) - tempSize;

        x += tempSize;
        y += tempSize;

        x = x.toFixed(2);
        y = y.toFixed(2);

        const result = 'rotate(' + degree + ' ' + x + ', ' + y + ')';

        return result;
      })
      .append('xhtml:i')
      .attr('class', 'chart minMaxBottomSymbol series' + series.no + ' ' + glyphiconPrefix + ' md-' + toBeSymbolSize)
      .style('color', series.config.symbolColor)
      .text(series.config.symbolType.replace(glyphiconPrefix + '-',''))
      .on('mouseover', () => {
        this._logTrace('fr-chart-min-max.minMaxBottomSymbol.mouseover()');
        this._raiseEvents('mouseoverSeriesCB', series);
        d3.event.stopPropagation();
      })
      .on('mouseout', () => {
        this._logTrace('fr-chart-min-max.minMaxBottomSymbol.mouseout()');
        this._raiseEvents('mouseoutSeriesCB', series);
        d3.event.stopPropagation();
      });

    // minMaxTopTooltip
    const topTooltipSize = this.get('_chartData').tooltipSize;

    seriesRootG
      .selectAll('.chart.minMaxTopTooltip.series' + series.no)
      .data(series.data)
      .enter()
      .append('text')
      .attr('class', 'chart minMaxTopTooltip series' + series.no)
      .attr('font-size', topTooltipSize)
      .attr('text-anchor', 'left')
      .attr('style', 'display: none')
      .attr('transform', (d) => {
        //let x = xScaleFunction(d[series.config.xAxisProperty]) - series.config.strokeWidth * 0.5;
        const strokeHalf = series.config.strokeWidth * half;
        const x = xScaleFunction(this._convertDateFormat(d[series.config.xAxisProperty], isTimeXAxis)) - strokeHalf;
        const tooltipHalf = topTooltipSize * 0.5;
        const y = yScaleFunction(d[series.config.yAxisProperty + postfixMax]) - tooltipHalf;

        return 'translate(' + x  + ', ' + y + ')';
      })
      .text(function(d) {
        return d[series.config.tooltipProperty + postfixMax];
      });

    // minMaxBottomTooltip
    const bottomTooltipSize = this.get('_chartData').tooltipSize;

    seriesRootG
      .selectAll('.chart.minMaxBottomTooltip.series' + series.no)
      .data(series.data)
      .enter()
      .append('text')
      .attr('class', 'chart minMaxBottomTooltip series' + series.no)
      .attr('font-size', bottomTooltipSize)
      .attr('text-anchor', 'left')
      .attr('style', 'display: none')
      .attr('transform', (d) => {
        //let x = xScaleFunction(d[series.config.xAxisProperty]) - series.config.strokeWidth * 0.5;
        const strokeHalf = series.config.strokeWidth * half;
        const x = xScaleFunction(this._convertDateFormat(d[series.config.xAxisProperty], isTimeXAxis)) - strokeHalf;
        const tooltipAdjust = bottomTooltipSize * 1.5;
        const y = yScaleFunction(d[series.config.yAxisProperty + postfixMin]) + tooltipAdjust;

        return 'translate(' + x  + ', ' + y + ')';
      })
      .text(function(d) {
        return d[series.config.tooltipProperty + postfixMin];
      });
  },

  _removeEventListener() {
    const zero = 0;
    const series = this.get('_seriesData');
    const seriesNo = series.no;
    const mouseOverOut = [
      '.chart.minMax.series' + seriesNo,
      '.chart.minMaxTopSymbol.series' + seriesNo,
      '.chart.minMaxBottomSymbol.series' + seriesNo,
      '.chart.foreignObject.series' + series.no
    ];
    const mouseMove = ['.chart.minMax.series' + seriesNo];
    const el = this.$().get(zero);
    const thisObj = d3.select(el);

    for(let i=0; i < mouseOverOut.length; i++) {
      thisObj.selectAll(mouseOverOut[i]).on('mouseover', null).on('mouseout', null);
    }

    for(let i=0; i < mouseMove.length; i++) {
      thisObj.selectAll(mouseMove[i]).on('mousemove', null);
    }
  },

  // 삭제된 시리즈 차트에서 삭제
  _removeSeriesDom(remove) {
    const zero = 0;
    const el = this.$().parent().get(zero);
    for (const item of remove) {
      const target = d3.select(el).select('.seriesRoot' + item.no);
      if (target) {
        target.remove();
      }
    }
  },

  _removeDom() {
    const series = this.get('_seriesData');
    const zero = 0;
    const el = this.$().parent().get(zero);
    if(this.get('_parentType') === 'flowsheet') {
      d3.select(el)
        .select('.main >.chartRoot > .seriesRoot' + series.no)
        .remove();
    } else {
      d3.select(el)
        .select('.chartRenderArea > .seriesRoot' + series.no)
        .remove();
    }
  },

  actions: {
  },
});