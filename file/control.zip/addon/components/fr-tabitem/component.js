import Ember from 'ember';
import Template from './template';
import Control from '../fr-control/component';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

export default  Control.extend(StatefulComponentMixin, {
  attributeBindings: ['watchSelectedName:name'],
  classNames: ['tab-item'],
  layout: Template,
  tagName : 'div',
  header : '',
  content: null,
  contentClass: '',
  dataItem : null,
  onRender: null,
  isRendered : false,
  watchSelectedName: Ember.computed('name', 'selectedName', function() {
    if ( !Ember.isEmpty(this.get('selectedName')) && this._getName() === this.get('selectedName')) {
      if ( this.get('isRendered') === false ) {
        this.set('isRendered', true);
        Ember.run.schedule('afterRender', this, function () {
          this.$('.scrollbar-macosx:not(.scroll-content)').scrollbar();
        });
      }
      this.$().addClass('fr-tab-active');
      Ember.run.once(this, function() {
        this._raiseEvents('onselected', {
          source : null,
          originalSource : this,
          dataItem : this.get('dataItem')
        });
      })
    } else {
      this.$().removeClass('fr-tab-active');
    }
  }).readOnly(),
  _getName() {
    const _name = this.get('name')

    if ( !Ember.isEmpty(_name)) {
      return _name ;
    }

    return this.get('elementId') ;
  },
  didInsertElement(){
    this._super(...arguments);

    if ( this._getName() === this.get('selectedName')) {
      this.$().addClass('fr-tab-active');
    }
    this._raiseEvents('onRender', {
      id : this._getName(),
      header : this.header,
      content : this.content
    });
  },
  willDestroyElement(){
    this._super(...arguments);

    this.$().off('onactivate');
    this.$().off('onselected');
    this.$('.scrollbar-macosx.scroll-content').scrollbar('destroy');
  },
});
