import Ember from 'ember';
import layout from './template';

export default Ember.Component.extend({
  attributeBindings: ['getValue:data-val'],
  classNames: ['fr-combobox-option'],
  layout,
  tagName: 'li',
  value: null,
  dataItem: null,
  content: '',
  selected: false,
  itemContainer : null,
  getValue: Ember.computed('dataItem', function () {

    if ( Ember.isEmpty(this.get('dataItem')) ) {
      return '' ;
    }

    return Ember.get(this.get('dataItem'), 'key');
  }).readOnly(),
  didInsertElement() {
    this._super(...arguments);

    if (!Ember.isEmpty(this.get('onrender'))) {
      this.onrender(Ember.Object.create({ 'content': this.content, 'value': this.value }), this.selected);
    }
  },
  click() {
    const itemsPanel = this.get('itemContainer');

    if (!Ember.isEmpty(itemsPanel)) {
      itemsPanel._onSelected(this.get('dataItem'));
    }
  }
});