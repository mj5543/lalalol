import Ember from 'ember';
import layout from './template';
import Control from '../fr-control/component';
import SlderMixin from '../../mixins/slider-mixin';

// == Slider
export default Control.extend(SlderMixin, {
  // == Component Properties ========================
  attributeBindings: ['getValue:data-value'],
  classNames: ['fr-slider'],
  layout,
  tagName: 'div',
  value: 0,
  valueChanged: null,
  getValue: Ember.computed('value', function () {
    const _newValue = this._inergerValue(this.get('value'));

    if (this.hasLoaded) {
      Ember.run.once(this, function () {
        this._raiseValueChanged();
      }.bind(this));
    }

    Ember.run.next(this, function () {
      this._setPositionFromValue();
    }.bind(this));

    return parseInt(_newValue);
  }).readOnly(),

  // == Private Methods =============================
  _getThumbPosition() {
    return parseInt(this._sliderThumb().css('left'), 10);
  },
  _getValueFromPosition() {
    // ignored
  },
  _getPositionFromValue() {
    // ignored
  },
  _setPositionFromValue() {

    const newValue = this._inergerValue(this.get('value'));
    let newLeft = 0;

    if (this._isSnapToTickEnabled() === true) {

      const indexAt = this._getIndexOfByTickValue(newValue);

      if (indexAt > -1) {
        const tmp = this._getDistancePixel() * (indexAt) ;

        if ( tmp > 0) {
          newLeft = tmp - this._thumbWidth();
        } else {
          newLeft = tmp;
        }
      }
    } else {
      const absValue = Math.abs(this._minimumValue()) + newValue;

      newLeft = this._getPixelByTick() * absValue;
    }

    this._sliderThumb().css('left', newLeft);
    this._sliderSelection().width(newLeft);
  },
  _setValueFromPosition() {

    let _newValue = 0;

    if (this._isSnapToTickEnabled() === true) {
      const position = this._getThumbPosition();

      if (position !== 0) {
        const idx = Math.ceil(position / this._getDistancePixel());

        _newValue = Ember.get(this._getTicks().objectAt(idx), this.valuePropertyPath);
      }
    } else {
      const tmp = this._sliderSelection().width() / this._getPixelByTick() ;

      _newValue = Math.round(this._minimumValue() + tmp);
    }

    this.setValue(_newValue);
  },
  _raiseValueChanged() {
    this._raiseEvents('valueChanged', { 'source': this, value: this._inergerValue(this.get('value')) });
  },
  _onhorizontalmove(e) {
    e.preventDefault();

    const rect = this._trackRect(e.pageX);

    const thumbRadius = this._thumbWidth() / 2;
    const newLeft = rect.relativeX - thumbRadius;

    if (e.pageX >= rect.right) {
      e.data.handle.css('left', rect.width);
      this._sliderSelection().css('width', rect.width);
    } else if (e.pageX < rect.left) {
      e.data.handle.css('left', 0);
      this._sliderSelection().css('width', 0);
    } else if (0 <= newLeft && newLeft <= rect.width) {
      e.data.handle.css('left', newLeft);
      this._sliderSelection().css('width', newLeft);
    }
  },
  _onhorizontaltickmove(e) {
    e.preventDefault();

    const rect = this._trackRect(e.pageX);
    const thumbWidth = this._thumbWidth();
    const distance = this._getDistancePixel();
    const pos = Math.round(rect.relativeX / distance);
    const newLeft = pos * distance;

    if (e.pageX >= rect.right) {
      e.data.handle.css('left', rect.width);
      this._sliderSelection().css('width', rect.width);
    } else if (e.pageX < rect.left) {
      e.data.handle.css('left', 0);
      this._sliderSelection().css('width', 0);
    } else if (pos === 0) {
      e.data.handle.css('left', newLeft);
      this._sliderSelection().css('width', newLeft);
    } else {
      e.data.handle.css('left', newLeft - thumbWidth);
      this._sliderSelection().css('width', newLeft - thumbWidth);
    }
  },
  _onverticalltickmove(e) {
    e.preventDefault();

    return false;
  },
  _onverticallmove(e) {
    e.preventDefault();

    return false;
  },
  _onmouseup(e) {
    e.preventDefault();

    this._destory();

    this._setValueFromPosition();
  },

  // == Public Methods ==============================
  setValue(value) {
    this.set('value', value);
  },
  // == Action Methods ==============================
  actions: {
    onTickClickAction(e) {
      this.setValue(e.value);
    }
  }
});