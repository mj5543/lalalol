import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';

export default Control.extend({
  tagName: 'div',
  layout,
  classNames: ['c-splitter'],
  primaryComponent: 'c-splitter-primary',
  secondaryComponent: 'c-splitter-secondary',
  _primarySize: null,
  didInsertElement() {
    this._super(...arguments);
    this._resize();

    const container = this.$('.panel-container');
    let oldWidth = Number(container.width());
    let oldHeight = Number(container.height());
    container.on('resize', function () {
      if(oldWidth !== Number(container.width())) {
        this._resize();
        oldWidth = Number(container.width());
      }
      if(oldHeight !== Number(container.height())) {
        this._resize();
        oldHeight = Number(container.height());
      }
    }.bind(this));
  },
  willDestroyElement() {
    Ember.$().off('resize');
    this._super(...arguments);
  },
  _resize() {
    const minSize = JSON.parse(this.get('minSize'));
    const hozt = this.$('.splitter-horizontal');
    const vert = this.$('.splitter-vertical');
    // const parent = this.$('.panel-container');

    if(hozt.length) {
      hozt.find('.panel-primary').resizable({
        handles: 'e',
        minWidth: minSize[0],
        maxWidth: hozt[0].offsetWidth - minSize[1]
      });
    }
    if(vert.length) {
      vert.find('.panel-primary').resizable({
        handles: 's',
        minHeight: minSize[0],
        maxHeight: vert[0].offsetHeight - minSize[1]
      });
    }
  }
});