import Ember from 'ember';
import layout from './template';
//import CHIS from 'framework/chis-framework';
import Control from '../c-control/component';
import GlobalServiceContainerMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

export default Control.extend(GlobalServiceContainerMixin, StatefulComponentMixin, {
  layout,

  tagName: 'g',
  classNames: ['c-chart-line'],

  chartData: null,
  parentType: null,
  height: null,
  seriesData: null,
  trace: null,
  width: null,
  xAxis: null,
  xScale: null,
  yAxis: null,
  yScale: null,
  setting: null,
  isValidData: null,
  reload: null,
  removeSeries: null,
  // actionMode: null,

  _chartData: Ember.computed.alias('chartData').readOnly(),
  _reload: Ember.computed.alias('reload').readOnly(),
  // isEmpty 면 일반 차트로 처리 , flowsheet 면 flowsheet 차트로 처리
  _parentType: Ember.computed.alias('parentType').readOnly(),
  ////_height: Ember.computed.alias('height').readOnly(),
  _seriesData: Ember.computed.alias('seriesData').readOnly(),
  _trace: Ember.computed.alias('trace').readOnly(),
  _width: Ember.computed.alias('width').readOnly(),
  _xAxis: Ember.computed.alias('xAxis').readOnly(),
  _xScale: Ember.computed.alias('xScale').readOnly(),
  _yAxis: Ember.computed.alias('yAxis').readOnly(),
  _yScale: Ember.computed.alias('yScale').readOnly(),
  _isValidData: Ember.computed.alias('isValidData').readOnly(),
  _removeSeries: Ember.computed.alias('removeSeries').readOnly(),

  _height: Ember.computed('height', 'setting', function() {
    return this.get('height') - this.get('_settingPaddingBottom');
  }),
  _settingPaddingTop: Ember.computed('setting', function() {
    return this.get('setting').paddingTop;
  }),
  _settingPaddingRight: Ember.computed('setting', function() {
    return this.get('setting').paddingRight;
  }),
  _settingPaddingLeft: Ember.computed('setting', function() {
    return this.get('setting').paddingLeft;
  }),
  _settingPaddingBottom: Ember.computed('setting', function() {
    return this.get('setting').paddingBottom;
  }),
  _settingNormalOpacity: Ember.computed('setting', function() {
    return this.get('setting').normalOpacity;
  }),
  _settingDarkOpacity: Ember.computed('setting', function() {
    return this.get('setting').darkOpacity;
  }),
  _settingTransparentOpacity: Ember.computed('setting', function() {
    return this.get('setting').transparentOpacity;
  }),
  _settingGlyphiconPrefix: Ember.computed('setting', function() {
    return this.get('setting').glyphiconPrefix;
  }),

  onPropertyInit() {
    this._super(...arguments);
    this._logTrace('c-chart-line.initProperties()');

    this.setStateProperties([ 'width', 'height', 'seriesData', 'actionMode', 'chartData',
      'xAxis', 'yAxis', 'xScale',
      'yScale', 'setting', 'reload', 'isValidData',
      'trace'
    ]);
  },

  didInsertElement() {
    this._super(...arguments);
    this._logTrace('c-chart-line.didInsertElement()');
  },

  didRender() {
    this._super(...arguments);
    this._logTrace('c-chart-line.didRender()');

    const zero = 0;
    const one = 1;

    if(Ember.isEmpty(this.get('_chartData'))) {
      return;
    }

    if(this.get('_isValidData') === false) {
      return;
    }

    // x축 경계를 넘지 않게 ( line 시리즈 특성상)
    const valueDomain = this.get('_chartData').valueDomain;
    const isTimeXAxis = this.get('_chartData').isTimeXAxis;

    if(!Ember.isEmpty(valueDomain)) {
      const series = this.get('_seriesData');
      const data = series.data;

      series.data = data.filter(d => {
        const val = this._convertDateFormat(d[series.config.xAxisProperty], isTimeXAxis);

        return val >= valueDomain[zero] && val <= valueDomain[one];
      });
    }

    if(this.get('_parentType') === 'flowsheet') {
      const series = this.get('_seriesData');
      const data = series.data;

      series.data = data.filter( function(d) {
        if( Ember.isEmpty(d[series.config.yAxisProperty])) {
          return false;
        }
        return true;
      });
    }

    this._createSeries();
  },

  didUpdateAttrs() {
    this._super(...arguments);
    this._logTrace('c-chart-line.didUpdateAttrs()');
  },

  willDestroyElement() {
    this._super(...arguments);
    this._logTrace('c-chart-line.willDestroyElement()');

    // 이벤트 리스너 해제
    this._removeEventListener();
    this._removeDom();

    // 클로저 해제
    this._convertDateFormat = null;
    this._logTrace = null;
  },

  _logTrace(text) {
    if(this.get('_trace') === true) {
      Ember.Logger.log(text);
    }
  },

  _convertDateString(date, format) {
    return this.get('fr_I18nService').formatDate(date, format);
  },

  // date타입 체크 후 변경
  _convertDateFormat(date, isTimeXAxis) {
    if(isTimeXAxis) {
      if(date instanceof Date && date.valueOf() && !Number.isNaN(date.valueOf())) {
        return date;
      } else {
        return new Date(date);
      }
    } else {
      return date;
    }
  },

  _createSeries() {
    const zero = 0;
    const half = 0.5;
    const twenty = 20;
    const chartData = this.get('_chartData');
    const isTimeXAxis = chartData.isTimeXAxis;
    const series = this.get('_seriesData');

    this._logTrace('c-chart-line._createSeries()');

    this._removeEventListener();
    this._removeDom();

    // 삭제된 데이터 그래프 삭제
    if (this.get('_removeSeries')) {
      this._removeSeriesDom(this.get('_removeSeries'));
    }
    if (series.data.length === zero) {
      return;
    }

    const xScaleFunction = this.get('_xScale');
    if (Ember.isEmpty(xScaleFunction)) {
      return;
    }

    const glyphiconPrefix = this.get('_settingGlyphiconPrefix');
    const tooltipTemplate = series.config.tooltipTemplate;
    const noDisplaySymbol = series.config.noDisplaySymbol;
    const noDisplayTooltipProperty = series.config.noDisplayTooltipProperty;
    let noDisplayTooltipValues = series.config.noDisplayTooltipValues;
    const dateFormat = chartData.timeFormat.dataFormat;

    let yScaleFunction = null;

    if (series.config.yAxisPosition) {
      const yScale  = this.get('_yScale').filter(obj => {
        const pos = series.config.yAxisPosition || 1;
        return obj.position === pos;
      });
      if (yScale.length) {
        yScaleFunction = yScale[0].scale;
      }
    } else {
      yScaleFunction = this.get('_yScale')
    }
    // yScaleFunction = this.get('_yScale');

    if ( Ember.isEmpty(noDisplayTooltipValues)) {
      noDisplayTooltipValues = [];
    }

    // tooltipTemplate 을 위한 svg 의 sibling 개체
    const p = this.$().parent().parent();

    if(p.children('div.chartTooltipTemplate').length === zero) {
      p.append('<div class=\'chartTooltipTemplate\'></div>');
    }

    const toolTip = d3.select(p[zero]).selectAll('div.chartTooltipTemplate');
    const el = this.$().parent().get(zero);

    let seriesRootG;

    if(this.get('_parentType') === 'flowsheet') {
      seriesRootG = d3.select(el)
        .select('.main')
        .select('.chartRoot')
        .append('g')
        .attr('class', 'chart seriesRoot' + series.no)
        .attr('data-id', 'seriesRoot' + series.no);
    } else {
      seriesRootG = d3.select(el)
        .select('.chartRenderArea')
        .append('g')
        .attr('class', 'chart seriesRoot' + series.no)
        .attr('data-id', 'seriesRoot' + series.no);
    }

    if(Ember.isEmpty(tooltipTemplate)) {
      // lineTooltip
      seriesRootG.selectAll('.chart.lineTooltip.series' + series.no)
        .data(series.data.filter(d => {
          if(!Ember.isEmpty(noDisplayTooltipProperty)) {
            const targetValue = d[noDisplayTooltipProperty];

            if(noDisplayTooltipValues.includes(targetValue) === true) {
              return false;
            } else {
              return true;
            }
          } else {
            return true;
          }
        }))
        .enter()
        .append('text')
        .attr('class', 'chart lineTooltip series' + series.no)
        .attr('font-size', this.get('_chartData').tooltipSize)
        .attr('text-anchor', 'left')
        .attr('style', 'display: none')
        .attr('transform', d => {
          let x, y;
          if(noDisplaySymbol === true) {
            x = parseFloat(xScaleFunction(this._convertDateFormat(d[series.config.xAxisProperty], isTimeXAxis)));
            y = parseFloat(yScaleFunction(d[series.config.yAxisProperty]));
          } else {
            x = parseFloat(xScaleFunction(this._convertDateFormat(d[series.config.xAxisProperty], isTimeXAxis))) + parseFloat(series.config.symbolSize);

            const twice = parseFloat(series.config.symbolSize) * 2;

            y = parseFloat(yScaleFunction(d[series.config.yAxisProperty])) + twice;

          }

          let tempA = 'translate(' + x;
          let tempB = ', ' + y + ')';

          return tempA + tempB;
        })
        .text(function(d) {
          return d[series.config.tooltipProperty];
        });
    } else {
      seriesRootG.selectAll('.chart.lineTooltip.series' + series.no)
      //.data(series.data)
      .data(series.data.filter(function(d) {
        if(!Ember.isEmpty(noDisplayTooltipProperty)) {
          const targetValue = d[noDisplayTooltipProperty];

          if(noDisplayTooltipValues.includes(targetValue)) {
            return false;
          } else {
            return true;
          }
        } else {
          return true;
        }
      }))
      .enter()
      .append('svg:foreignObject')
      .attr('class', 'chart lineTooltip series' + series.no)
      .attr('style', 'display: none')
      .attr('x', d => {
        const w = parseFloat(xScaleFunction(this._convertDateFormat(d[series.config.xAxisProperty], isTimeXAxis)));

        return w;
      })
      .attr('y', function(d) {
        const w = parseFloat(yScaleFunction(d[series.config.yAxisProperty]));
        return w;
      })
      .attr('width', 30)
      .attr('height', 30)
      .html(d => {
        return d[series.config.tooltipProperty];
      });
    }

    const tweetLine = d3.line()
      .x(d => xScaleFunction(this._convertDateFormat(d[series.config.xAxisProperty], isTimeXAxis)))
      .y(d => yScaleFunction(d[series.config.yAxisProperty]));

    // line
    seriesRootG.append('path')
      .attr('class', 'chart line series' + series.no)
      .attr('d', tweetLine(series.data))
      .attr('fill', 'none')
      .attr('stroke', series.config.strokeColor)
      .attr('stroke-width', series.config.strokeWidth)
      .on('mouseover', () => {
        this._logTrace('c-chart-line.line.mouseover()');
        this._raiseEvents('mouseoverSeriesCB', series);
        d3.event.stopPropagation();
      })
      .on('mouseout', () => {
        this._logTrace('c-chart-line.line.mouseout()');
        this._raiseEvents('mouseoutSeriesCB', series);
        d3.event.stopPropagation();
      });

    // thickLine, 라인 얇을때 투명한 두꺼운 라인 추가
    if(series.config.strokeWidth <= 3) {
      seriesRootG.append('path')
        .attr('class', 'chart thickLine series' + series.no)
        .attr('d', tweetLine(series.data))
        .attr('fill', 'none')
        .attr('stroke', series.config.strokeColor)
        .attr('stroke-width', 10)
        .style('opacity', zero)
        .on('mouseover', () => {
          this._logTrace('c-chart-line.line.mouseover()');
          this._raiseEvents('mouseoverSeriesCB', series);
          d3.event.stopPropagation();
        })
        .on('mouseout', () => {
          this._logTrace('c-chart-line.line.mouseout()');
          this._raiseEvents('mouseoutSeriesCB', series);
          d3.event.stopPropagation();
        });
    }

    const toBeSymbolSize = series.config.symbolSize + 10;

    if(noDisplaySymbol !== true) {
      // line symbol
      seriesRootG.selectAll('.chart.lineSymbol.series' + series.no)
        .data(series.data)
        .enter()
        .append('svg:foreignObject')
        .attr('class', 'chart foreignObject series' + series.no )
        .attr('x', (d) => {
          const tempX = toBeSymbolSize * half;
          const w = xScaleFunction(this._convertDateFormat(d[series.config.xAxisProperty], isTimeXAxis)) - tempX;

          return w;
        })
        .attr('y', function(d) {
          const tempY = toBeSymbolSize * half;
          const w = yScaleFunction(d[series.config.yAxisProperty]) - tempY;

          return w;
        })
        // [COMPATIBILITY-EDGE] 프로퍼티에 어떤 값이라도 있어야 보임
        .attr('width', twenty)
        .attr('height', twenty)
        .append('xhtml:i')
        .attr('class', 'chart lineSymbol series' + series.no + ' ' + glyphiconPrefix + ' md-' + toBeSymbolSize)
        .style('color', series.config.symbolColor)
        .text(series.config.symbolType.replace(glyphiconPrefix + '-',''))
        .on('mouseover', () => {
          this._logTrace('c-chart-line.lineSymbol.mouseover()');
          this._raiseEvents('mouseoverSeriesCB', series);
          d3.event.stopPropagation();
        })
        .on('mouseout', () => {
          this._logTrace('c-chart-line.lineSymbol.mouseout()');
          toolTip.style('display', 'none');
          this._raiseEvents('mouseoutSeriesCB', series);
          d3.event.stopPropagation();
        })
        .on('mousemove', d => {
          let button = null;
          if(Ember.isEmpty(d3.event.sourceEvent)) {
            button = d3.event.buttons;
          } else {
            button = d3.event.sourceEvent.buttons;
          }
          if(button === 2) {
            return;
          }
          this._logTrace('c-chart-line.line.mousemove()');
          const tempX = 10;
          const tempY = 20;
          const x = d3.event.pageX + tempX;
          const y = d3.event.pageY + tempY;

          toolTip.style('left', x + 'px');
          toolTip.style('top', y + 'px');
          toolTip.style('display', 'inline-block');

          if(Ember.isEmpty(tooltipTemplate) || Ember.isBlank(tooltipTemplate) ) {
            let val = d[series.config.tooltipProperty];

            if( typeof val === 'object' && val instanceof Date) {
              val = this._convertDateString(val, dateFormat);
            }
            toolTip.html(val);
          } else {
            let result = tooltipTemplate;

            for(const name in d) {
              let val = d[name];

              if( typeof val === 'object' && val instanceof Date) {
                val = this._convertDateString(val, dateFormat);
              }

              const regexp = new RegExp('{{' + name + '}}', 'gi');

              result = result.replace(regexp, val);
            }
            toolTip.html(result);
          }
        });
    }
  },

  _removeEventListener() {
    const zero = 0;
    const series = this.get('_seriesData');
    const seriesNo = series.no;

    const mouseOverOut = [
      '.chart.line.series' + seriesNo,
      '.chart.lineSymbol.series' + seriesNo,
      '.chart.thickLine.series' + seriesNo
    ];
    const mouseMove = ['.chart.lineSymbol.series' + seriesNo];

    const el = this.$().get(zero);
    const thisObj = d3.select(el);

    for(let i=0; i < mouseOverOut.length; i++) {
      thisObj.selectAll(mouseOverOut[i]).on('mouseover', null).on('mouseout', null);
    }

    for(let i=0; i < mouseMove.length; i++) {
      thisObj.selectAll(mouseMove[i]).on('mousemove', null);
    }
  },
  // 삭제된 시리즈 차트에서 삭제
  _removeSeriesDom(remove) {
    const zero = 0;
    const el = this.$().parent().get(zero);
    for (const item of remove) {
      const target = d3.select(el).select('.seriesRoot' + item.no);
      if (target) {
        target.remove();
      }
    }
  },

  _removeDom() {
    const zero = 0;
    const series = this.get('_seriesData');
    const el = this.$().parent().get(zero);
    if(this.get('_parentType') === 'flowsheet') {
      d3.select(el)
        .select('.main >.chartRoot > .seriesRoot' + series.no)
        .remove();
    } else {
      d3.select(el)
        .select('.chartRenderArea > .seriesRoot' + series.no)
        .remove();
    }
  },

  actions: {
  },

});