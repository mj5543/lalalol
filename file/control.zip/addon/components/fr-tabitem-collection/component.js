import Ember from 'ember';
import Template from './template';
import Control from '../fr-control/component';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

export default  Control.extend(StatefulComponentMixin, {
  attributeBindings: ['watchSelectedName:isOpen'],
  classNames: ['tab-more'],
  layout: Template,
  tagName : 'div',
  itemsSource : null,
  selected : null,
  isOpen : false,
  closing : null,
  displayMemberPath: null,
  allowTabClosing: false,
  watchSelectedName: Ember.computed('isOpen', function() {
    if(this.isOpen){
      this.$().show();
    }else{
      this.$().hide();
    }
  }).readOnly(),
  didInsertElement(){
    this._super(...arguments);
    this.$().hide();
  },
  willDestroyElement(){
    this._super(...arguments);
  },
  actions: {
    onSelectedAction(e) {
      this._raiseEvents('selected', e);
    },

    onTabClosingAction(e) {
      this._raiseEvents('closing', { source : null, originalSource : {dataItem : e} , cancel : false}) ;
    },

    onOpen() {
      const isActive = this.$('.tab-more').is('.active');

      if(isActive){
        this.$('.tab-more').removeClass('active');
      }else{
        this.$('.tab-more').addClass('active');
      }
    }
  }
});
