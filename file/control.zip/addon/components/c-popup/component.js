import Ember from 'ember';
import GlobalServiceContainerMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';
import Control from '../c-control/component';
import layout from './template';

export default Control.extend(GlobalServiceContainerMixin, {
  //== Component Properties =================================
  layout,
  tagName: 'div',
  //== Attribute Properties =================================
  attributeBindings: ['originStyle:style', '_watchisOpen:data-name', '_watchDestroy:data-destroy'],
  // disabled: null,
  draggable: true,
  style: null,
  tabindex: null,
  //== Public Properties ====================================
  targetAttachment: 'bottom left',
  attachment: 'top left',
  isOpen: false,
  showCloseButton: true,
  placeInArea: false,
  stayOpen: true,
  placementTarget: null,
  isEmbedded: false,
  onOpened: null,
  onClosed: null,
  movingOffsetTop: 0,
  movingOffsetLeft: 0,
  destroyOnHide: true,
  showHideClass: 'hide',
  hasOpen: false,
  useParentWormhole: true,
  //== Private Properties ===================================
  _hasLoaded: false,
  //== Computed Properties ==================================
  _watchDestroy: Ember.computed('destroyOnHide', function () {
    if (this._hasLoaded) {
      if (this.get('destroyOnHide')) {
        this.set('hasOpen', false);
      }
    }
    return this.get('destroyOnHide');
  }).readOnly(),
  _watchisOpen: Ember.computed('isOpen', function () {
    if (this.get('isOpen')) {
      Ember.run.once(this, '_onOpened');
    } else {
      Ember.run.once(this, '_onClosed');
    }

    return this.get('isOpen');
  }).readOnly(),
  _targetElement: Ember.computed('isOpen', 'placementTarget', function () {
    if (!Ember.isNone(this.get('placementTarget'))) {
      return Ember.$(this.get('placementTarget')).get(0);
    }

    return document.body;
  }).readOnly(),
  offsetTop: Ember.computed('verticalOffset', 'movingOffsetTop', function () {
    const verticalOffset = this.get('verticalOffset');
    let offsetTop = this.get('movingOffsetTop');

    if (typeof verticalOffset === 'number') {
      offsetTop += verticalOffset;
    }

    return offsetTop;
  }).readOnly(),
  offsetLeft: Ember.computed('horizontalOffset', 'movingOffsetLeft', function () {
    const horizontalOffset = this.get('horizontalOffset');
    let offsetLeft = this.get('movingOffsetLeft');

    if (typeof horizontalOffset === 'number') {
      offsetLeft += horizontalOffset;
    }

    return offsetLeft;
  }).readOnly(),
  // //== Life Cycle ===========================================
  didInsertElement() {
    this._super(...arguments);
    this._hasLoaded = true;
  },
  willDestroyElement() {
    if (!this.get('stayOpen')) {
      /* Ember.$(document).off(`mousedown.${this.get('componentGuid')}`); */
    }
    this._super(...arguments);
  },
  _onOpened() {
    /* if (!this.get('stayOpen')) {
      Ember.$(document).on(`mousedown.${this.get('componentGuid')}`, function (event) {
        if (!this.get('isDestroying') && !this.get('isDestroyed')) {
          let component = this._getComponent(Ember.$(event.target).closest('.c-positioned-container'));
    
          if (!component || !this.get('element').contains(Ember.get(component, 'ownerElement'))) {
            const _parentId = Ember.$(event.target).closest('.c-popup').eq(0).data('id'), _elementId = this.get('elementId');
      
            if (!Ember.isEmpty(this.inputTarget) && Ember.$(this.inputTarget)[0] === event.target) {
              return;
            }
            if (_elementId === _parentId) {
              return;
            }
            if (Ember.$(event.target).hasClass('fr-menuitem')) {
              return;
            }
            if (Ember.$(event.target).closest('.search').length > 0) {
              return;
            }
            if (Ember.$(event.target).hasClass('btn-group') || Ember.$(event.target).hasClass('icon-btn') || Ember.$(event.target).hasClass('icon-search')) {
              return;
            }
            if (Ember.$(event.target).closest('.c-message-box').length > 0 || Ember.$(event.target).closest('.c-message-box-bg').length > 0) {
              return;
            }
            this.set('isOpen', false);
          }
          component = null;
        }
      }.bind(this));
    } */
    this.set('showHideClass', 'show');
    if (this.get('_hasLoaded') && this.get('hasOpen')) {
      this._raiseEvents('onOpened', { 'source': this });
    } else {
      this.set('hasOpen', true);
    }
  },
  _onClosed() {
    if (this.get('destroyOnHide')) {
      this.set('hasOpen', false);
    }
    this.set('showHideClass', 'hide');
    if (this.get('_hasLoaded') && !this.get('isOpen')) {
      this._raiseEvents('onClosed', { 'source': this });
    }
  },
  actions: {
    mouseDownToOutside(event) {
      if (this.element && !this.element.contains(event.target) && !this.get('stayOpen') &&
      !document.getElementById('max-wormhole-parent').contains(event.target)) {
        this.set('isOpen', false);
      }
    },
    onCloseModal() {
      this.set('isOpen', false);
    },
    containerShown() {
      this._raiseEvents('onOpened', { 'source': this });
    },
  }
});
