import Ember from 'ember';
import layout from './template';
import ButtonBase from '../fr-buttonbase/component';
import ContextMenuMixin from '../../mixins/contextmenu-mixin';


// == DropDownButton
export default ButtonBase.extend(ContextMenuMixin, {
  layout,
  classNames: ['fr-dropdownbutton', 'btn', 'btn-sm', 'btn-ext', 'bt-inico'],
  // == State properties ======================================================
  isOpened: false,
  selectedClass: '',
  directionIndicatorVisibility: true,
  dropDownAnimation: false,
  placement: '',
  placementTarget: '',
  staysOpen: false,
  horizontalOffset: '0px',
  verticalOffset: '2px',
  isOpenedChanged: null,
  header: null,
  tagName:'div',
  //_destinationElementId: 'fr-wormhole-container',
  _destinationElementId: Ember.computed(function () {
    return this.$().closest('.wormhole-parent').find('.wormhole-contaner').attr('id');
  }).readOnly(),
  _targetElement: null,
  //== Computed Properties ==========================================================
  _watchisOpened: Ember.computed('isOpened', function () {
    return this._isOpenChanged(this.get('isOpened'));
  }),
  //== Private Methods===============================================================
  _isOpenChanged(isOpened) {

    let rtn = '';

    if (isOpened) {

      if (!Ember.isEmpty(this.get('selectedClass'))) {
        this.$().addClass(this.get('selectedClass'));
      }

      rtn = 'Y';
    } else {

      if (!Ember.isEmpty(this.get('selectedClass'))) {
        this.$().removeClass(this.get('selectedClass'));
      }

      rtn = 'N';
    }

    if (this.hasLoaded === false) {
      return rtn;
    }

    this._raiseEvents('isOpenedChanged', { 'source': this, 'isOpened': isOpened });

    return rtn;
  },
  click() {
    if (this.get('isOpened') === true) {
      this.set('isOpened', false);
    } else {
      this.set('isOpened', true);
    }
  },
  // == protected methods ===================================================
  init() {
    this._super(...arguments);

    if (!Ember.isEmpty(this.id)) {
      this.set('placementTarget', '#ddbtn_' + this.id);
    }
  },
  didInsertElement() {
    this._super(...arguments);
    this.set('_targetElement', this.$().get(0));
  },
  willDestroyElement() {
    this._super(...arguments);
  }
});