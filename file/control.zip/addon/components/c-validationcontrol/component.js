import Ember from 'ember';
import Control from '../c-control/component';

export default Control.extend({
  classNameBindings: ['_showValidationRequired:required','_showValidationError:error','showValidationSuccess:success'],
  attributeBindings: ['_validationFailed:data-invalid'],
  showValidationError: Ember.computed.readOnly('_showValidationError'),
  internalRules: Ember.computed('defaultRules.[]', 'validationRules.[]', function () {
    const internalRules = Ember.A(), defaultRules = this.get('defaultRules'), validationRules = this.get('validationRules');

    if (Ember.isArray(defaultRules)) {
      internalRules.addObjects(defaultRules);
    }
    if (Ember.isArray(validationRules)) {
      internalRules.addObjects(validationRules);
    }

    return internalRules;
  }).readOnly(),
  internalErrorMessage: Ember.computed('_internalValue', 'internalRules.[]', function () {
    const _internalValue = this.get('_internalValue'), internalRules = this.get('internalRules');
    let internalErrorMessage = null;

    if (Ember.isArray(internalRules)) {
      internalRules.forEach(function (o) {
        if (Ember.isNone(internalErrorMessage) && !o.rule.call(this, _internalValue)) {
          internalErrorMessage = o.message;
        }
      }.bind(this));
    }

    return internalErrorMessage;
  }).readOnly(),
  errorMessage: Ember.computed('required', '_internalValue', 'externalErrorMessage', 'internalErrorMessage', function () {
    if (!this.get('required') || !Ember.isEmpty(this.get('_internalValue')) || this.get('_internalValue') !== false) {
      const externalErrorMessage = this.get('externalErrorMessage'), internalErrorMessage = this.get('internalErrorMessage');

      if (!Ember.isNone(externalErrorMessage)) {
        return externalErrorMessage;
      }

      return internalErrorMessage;
    }
  }).readOnly(),
  _validationFailed: Ember.computed.or('_showValidationRequired', '_showValidationError').readOnly(),
  _showValidationRequired: Ember.computed('required', '_internalValue', function () {
    return this.get('required') && (Ember.isEmpty(this.get('_internalValue')) || this.get('_internalValue') === false);
  }).readOnly(),
  /*showValidationRequiredSatisfy: Ember.computed('required', '_internalValue', 'errorMessage', 'showValidationSuccess', function () {
    return this.get('required') && Ember.isEmpty(this.get('_internalValue')) && !Ember.isNone(this.get('errorMessage')) && !this.get('showValidationSuccess');
  }).readOnly(),*/
  _showValidationError: Ember.computed('errorMessage', function () {
    return !Ember.isNone(this.get('errorMessage'));
  }).readOnly(),
  /*showValidationArea: Ember.computed('required', 'errorMessage', 'showValidationSuccess', function () {
    return this.get('required') || !Ember.isNone(this.get('errorMessage')) || this.get('showValidationSuccess');
  }).readOnly(),*/
});