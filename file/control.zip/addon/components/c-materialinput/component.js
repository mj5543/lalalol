import Ember from 'ember';
import layout from './template';
import ValidationControl from '../c-validationcontrol/component';

export default ValidationControl.extend({
  layout,
  classNames: ['c-materialinput', 'material-input'],
  tagName: 'div',
  //public properties
  style: null,
  type: 'text',
  title: null,
  value: null,
  textMode: null,
  tabindex: null,
  placeHolder: null,
  maxLength: null,
  disabled: false,
  readOnly: false,
  casing: null,
  hintText: null,
  prefix: null,
  suffix: null,
  maxCharacterCount: null,
  enableGotFocusAutoSelect: false,
  showClearButton: false,
  showSearchButton: false,
  required: false,
  showValidationSuccess: false,
  externalErrorMessage: null,
  validationRules: null,
  //public events
  onLoaded: null,
  onUnload: null,
  onClick: null,
  onFocusIn: null,
  onFocusOut: null,
  onKeyPress: null,
  onKeyUp: null,
  onKeyDown: null,
  onChanged: null,
  onTextCommit: null,
  onTextSearch: null,
  onTextCleared: null,

  _notReadOnly: Ember.computed.not('readOnly'),
  _showClearButtonAndNotReadOnly: Ember.computed.and('showClearButton', '_notReadOnly'),
  _showHintText: Ember.computed.notEmpty('hintText').readOnly(),
  _showCharacterCount: Ember.computed.notEmpty('maxCharacterCount').readOnly(),
  _internalType: Ember.computed('type', function () {
    if (this.get('type') === 'password') {
      return type;
    }
  }),
  _internalValue: Ember.computed('value', {
    get (key) {
      const prefix = this.get('prefix'), suffix = this.get('suffix');
      let fixValue = this.get('value');

      if (typeof fixValue === 'string' && typeof prefix === 'string' && fixValue.startsWith(prefix)) {
        fixValue = fixValue.substring(prefix.length);
      }
      if (typeof fixValue === 'string' && typeof suffix === 'string' && fixValue.endsWith(suffix)) {
        fixValue = fixValue.substring(0, fixValue.length - suffix.length);
      }

      return Ember.isNone(fixValue) ? '' : fixValue;
    },
    set (key, value) {
      Ember.run.once(this, '_inputModeFilter', value);

      return value;
    },
  }),
  defaultRules: Ember.computed('_showCharacterCount', function () {
    if (this.get('_showCharacterCount')) {
      return Ember.A().addObject({
        rule: function () {
          return this.get('stringByteLength') <= this.get('maxCharacterCount');
        },
        message: 'The string exceeds the maximum size.'
      });
    }
  }).readOnly(),
  stringByteLength: Ember.computed('_internalValue', function () {
    const _internalValue = this.get('_internalValue');

    if (typeof _internalValue === 'string') {
      return (function (s,b,i,c) {
        for(b=i=0; c=s.charCodeAt(i++); b+=c>>11?3:c>>7?2:1);
        return b;
      })(_internalValue);
    }

    return 0;
  }),
  click(event) {
    this._raiseEvents('onClick', {
      source: this,
      originalEvent: event
    });
  },
  focusIn(event) {
    if (this.get('enableGotFocusAutoSelect')) {
      this.$('input').select();
    }
    this._raiseEvents('onFocusIn', {
      source: this,
      originalEvent: event
    });
  },
  focusOut(event) {
    this._syncDataValue();
    this._raiseEvents('onFocusOut', {
      source: this,
      originalEvent: event
    });
  },
  keyPress(event) {
    if (event.keyCode === 13) {
      event.preventDefault();
      this._syncDataValue();
      this._raiseEvents('onTextCommit', {
        source: this,
        originalEvent: event
      });
    }
    this._raiseEvents('onKeyPress', {
      source: this,
      originalEvent: event
    });
  },
  keyUp(event) {
    this._raiseEvents('onKeyUp', {
      source: this,
      originalEvent: event
    });
  },
  keyDown(event) {
    this._raiseEvents('onKeyDown', {
      source: this,
      originalEvent: event
    });
  },
  _syncDataValue() {
    const prefix = this.get('prefix'), suffix = this.get('suffix');
    let _internalValue = this.get('_internalValue'), fixValue = _internalValue;

    if (typeof prefix === 'string') {
      fixValue = prefix + fixValue;
    }
    if (typeof suffix === 'string') {
      fixValue = fixValue + suffix;
    }
    this.set('value', fixValue);
    Ember.run.schedule('afterRender', this, function () {
      if (!this.get('isDestroying') && !this.get('isDestroyed')) {
        this.$('input').val(_internalValue);
      }
      _internalValue = null;
    });
  },
  _inputModeFilter(_internalValue) {
    const textMode = this.get('textMode'), casing = this.get('casing');
    let filterdValue = _internalValue;

    if (casing === 'upper') {
      filterdValue = filterdValue.toUpperCase();
    }
    if (casing === 'lower') {
      filterdValue = filterdValue.toLowerCase();
    }
    if (textMode === 'number') {
      filterdValue = filterdValue.replace(/[^0-9]/g, '');
    }
    if (textMode === 'korean') {
      filterdValue = filterdValue.replace(/[^0-9|^ㄱ-ㅎ|^ㅏ-ㅣ|^가-힣]/g, '');
    }
    if (textMode === 'alphabet') {
      filterdValue = filterdValue.replace(/[^0-9|^a-z|^A-Z]/g, '');
    }
    if (_internalValue !== filterdValue) {
      Ember.run.schedule('afterRender', this, function () {
        if (!this.get('isDestroying') && !this.get('isDestroyed')) {
          this.$('input').val(filterdValue);
        }
        filterdValue = null;
      });
    }
  },
  actions: {
    searchMouseDown(event) {
      event.preventDefault();
      this._raiseEvents('onTextSearch', {
        source: this,
        originalEvent: event,
        searchText: this.get('_internalValue')
      });
    },
    delMouseDown(event) {
      event.preventDefault();
      this.set('_internalValue', '');
      this._raiseEvents('onTextCleared', {
        source: this,
        originalEvent: event
      });
    },
    change(event) {
      this._syncDataValue();
      this._raiseEvents('onChanged', {
        source: this,
        originalEvent: event,
        value: this.get('value')
      });
    },
  },
});