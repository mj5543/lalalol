import Ember from 'ember';
import layout from './template';
import Control from '../fr-control/component';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

export default Control.extend(StatefulComponentMixin, {
  attributeBindings: ['getName:name'],
  classNames: ['fr-accordionitem', 'accordion-list', 'wrap-check-view'],
  layout,
  tagName: 'div',
  hasExpanded: false,
  onActivate: null,
  onRender: null,
  onSelect: null,
  hasContentLoaded: false,
  getName: Ember.computed('name', function () {
    const nm = this.get('name') ;

    if (Ember.isEmpty(nm)) {
      return this.get('elementId');
    }

    return nm;
  }).readOnly(),
  didInsertElement() {
    this._super(...arguments);
    this.get('onRender')(this);

    this.$().on('onactivate', this._onActivate.bind(this));
  },
  willDestroyElement() {
    this._super(...arguments);
    this.$().off('onactivate');
  },
  _onActivate(e) {
    e.preventDefault();
    e.stopPropagation();

    this.get('onActivate')(this);

    if (this.get('hasContentLoaded') === false) {
      this.set('hasContentLoaded', true);
    }

    return false;
  },
  actions: {
    onHeaderClickAction() {
      this.get('onSelect')(this);
    }
  }
});