import Ember from 'ember';
import Template from './template';
import Control from '../fr-control/component';

export default Control.extend({
  attributeBindings: ['watchSelectedName:data-name'],
  layout : Template,
  tagName : 'li',
  // == Public Properties ====================
  dataItem : null,
  content : null,
  hasSelected : false,
  allowTabClosing : false,
  // == Public Events ========================
  selected : null, 
  closing : null,
  // == Computed Properties ==================
  watchSelectedName: Ember.computed('name', 'selectedName', function() {

    if ( !Ember.isEmpty(this.get('selectedName')) && this.get('name') === this.get('selectedName')) {
      if (this.allowTabClosing === true) {
        this.set('hasSelected', true) ;
        this.$().addClass('close');
      }

      this.$().addClass('fr-tab-active').addClass('on').addClass('active');
    } else {
      this.set('hasSelected', false);
      this.$().removeClass('close').removeClass('fr-tab-active').removeClass('on').removeClass('active');
    }

    return this.get('name') ;
  }).readOnly(),
  didInsertElement(){
    this._super(...arguments);

    if ( this.get('name') === this.get('selectedName')) {

      if (this.allowTabClosing === true) {
        this.$().addClass('close');
      }

      this.$().addClass('fr-tab-active').addClass('on').addClass('active');
    }
  },
  actions: {
    onSelectedAction() {
      this._raiseEvents('selected', { id : this.get('name') });
    },
    onTabClosingAction(e) {

      e.preventDefault();
      e.stopPropagation();

      this._raiseEvents('closing', { source : null, originalSource : this, cancel : false}) ;
    }
  }
});