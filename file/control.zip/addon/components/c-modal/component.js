import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';

export default Control.extend({
  layout,
  attributeBindings: ['_internalHtmlSafeStyle:style', '_watchisOpen:data-name'],
  classNameBindings: ['_watchisOpen:display-none'],
  htmlSafeStyle: null,
  isOpen: false,
  showCloseButton: true,
  backdropClose: false,
  enableKeyDownClose: true,
  footer: null,
  body: null,
  offsetLeft: 0,
  movingOffsetTop: 0,
  destinationElementId: 'modal-wormhole-container',
  useParentWormhole: false,
  onOpened: null,
  onClosed: null,
  placeInArea: false,
  attachment: Ember.computed('position', function () {
    if (this.get('position') === 'middle') {
      return 'middle center';
    }
    return 'top center';
  }).readOnly(),
  targetAttachment: Ember.computed('position', function () {
    if (this.get('position') === 'middle') {
      return 'middle center';
    }
    return 'top center';
  }).readOnly(),
  dialogHtmlSafeStyle: Ember.computed('style', function () {
    if (!Ember.isNone(this.get('style'))) {
      return Ember.String.htmlSafe(this.get('style'));
    }
  }).readOnly(),
  offsetTop: Ember.computed('position', 'movingOffsetTop', function () {
    let offsetTop = this.get('movingOffsetTop');

    if (this.get('position') !== 'middle') {
      offsetTop += 100;
    }

    return offsetTop;
  }).readOnly(),
  _targetElement: Ember.computed(function () {
    return document.body;
  }),
  _internalHtmlSafeStyle: Ember.String.htmlSafe('display:none !important;'),
  init() {
    this._super(...arguments);
    let section = Ember.Object.extend({ hasFooter: false }).create();

    this.set('body', Ember.Object.extend({ isBody: true, }).create());
    this.set('section', section);
    this.set('footer', Ember.Object.extend({ 
      isFooter: Ember.computed(function () { 
        Ember.run.once(function () {
          Ember.set(section, 'hasFooter', true);
        });
        return true;
      }),
    }).create());
  },
  didInsertElement() {
    this._super(...arguments);
    this.$().removeAttr('style');
    if (!Ember.isEmpty(this.get('classNames'))) {
      this.get('classNames').forEach((className) => {
        if (className !== 'c-modalcontainer') {
          this.$().removeClass(className);
        }
      });
    }
    if (this.enableKeyDownClose) {
      Ember.$(document).on(`keydown.c-modal-${this.get('_componentGuid')}`, function (event) {
        if (event.keyCode === 27) {
          this.set('isOpen', false);
        }
      }.bind(this));
    }
    this.hasLoaded = true;
  },
  willDestroyElement(){
    Ember.$(document).off(`keydown.c-modal-${this.get('_componentGuid')}`);
    this._super(...arguments);
  },
  //== Computed Properties ==================================
  _watchisOpen: Ember.computed('isOpen', function () {
    if (this.get('isOpen')) {
      return true;
    } else {
      if (this.hasLoaded === true) {
        Ember.run.once(this, '_onModalClose');
      }
      return false;
    }
  }),
  //== Private Methods ======================================
  _onModalClose() {
    this._raiseEvents('onClosed', { 'source': this });
  },
  actions: {
    mouseDownToOutside(event) {
      if (this.element && !this.element.contains(event.target) && this.backdropClose &&
      !document.getElementById('max-wormhole-parent').contains(event.target)) {
        this.set('isOpen', false);
      }
    },
    onCloseModal() {
      this.set('isOpen', false);
    },
    containerShown() {
      if (this.hasLoaded === true) {
        this._raiseEvents('onOpened', { 'source': this });
      }
    },
  }
});