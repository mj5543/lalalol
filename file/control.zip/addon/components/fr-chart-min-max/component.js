import Ember from 'ember';
import layout from './template';
//import CHIS from 'framework/chis-framework';
import Control from '../fr-control/component';
import GlobalServiceContainerMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

export default Control.extend(GlobalServiceContainerMixin, StatefulComponentMixin, {
  layout,

  tagName: 'g',
  classNames: ['fr-chart-min-max'],

  chartData: null,
  parentType: null,
  height: null,
  seriesData: null,
  trace: null,
  width: null,
  xAxis: null,
  xScale: null,
  yAxis: null,
  yScale: null,
  setting: null,
  isValidData: null,

  _postfixMax: null,
  _postfixMin: null,

  _chartData: Ember.computed.alias('chartData').readOnly(),
  // isEmpty 면 일반 차트로 처리 , flowsheet 면 flowsheet 차트로 처리
  _parentType: Ember.computed.alias('parentType').readOnly(),
  ////_height: Ember.computed.alias('height').readOnly(),
  _seriesData: Ember.computed.alias('seriesData').readOnly(),
  _trace: Ember.computed.alias('trace').readOnly(),
  _width: Ember.computed.alias('width').readOnly(),
  _xAxis: Ember.computed.alias('xAxis').readOnly(),
  _xScale: Ember.computed.alias('xScale').readOnly(),
  _yAxis: Ember.computed.alias('yAxis').readOnly(),
  _yScale: Ember.computed.alias('yScale').readOnly(),
  _isValidData: Ember.computed.alias('isValidData').readOnly(),

  _height: Ember.computed('height', 'setting', function() {
    return this.get('height') - this.get('_settingPaddingBottom');
  }),
  _settingPaddingTop: Ember.computed('setting', function() {
    return this.get('setting').paddingTop;
  }),
  _settingPaddingRight: Ember.computed('setting', function() {
    return this.get('setting').paddingRight;
  }),
  _settingPaddingLeft: Ember.computed('setting', function() {
    return this.get('setting').paddingLeft;
  }),
  _settingPaddingBottom: Ember.computed('setting', function() {
    return this.get('setting').paddingBottom;
  }),
  _settingNormalOpacity: Ember.computed('setting', function() {
    return this.get('setting').normalOpacity;
  }),
  _settingDarkOpacity: Ember.computed('setting', function() {
    return this.get('setting').darkOpacity;
  }),
  _settingTransparentOpacity: Ember.computed('setting', function() {
    return this.get('setting').transparentOpacity;
  }),
  _settingGlyphiconPrefix: Ember.computed('setting', function() {
    return this.get('setting').glyphiconPrefix;
  }),

  onPropertyInit() {
    this._super(...arguments);
    this._logTrace('fr-chart-min-max.onPropertyInit()');

    this.setStateProperties([]);
  },

  init() {
    this._super(...arguments);
    this._logTrace('fr-chart-min-max.init()');

    this.set('_postfixMax', 'Max');
    this.set('_postfixMin', 'Min');
  },

  didInsertElement() {
    this._super(...arguments);
    this._logTrace('fr-chart-min-max.didInsertElement()');
  },

  didRender() {
    this._super(...arguments);
    this._logTrace('fr-chart-min-max.didRender()');

    if(Ember.isEmpty(this.get('_chartData')) === true) {
      return;
    }

    if(this.get('_isValidData') === false) {
      return;
    }

    this._createSeries();
  },

  // // didUpdateAttrs() {
  // //   this._super(...arguments);
  // //   this._logTrace('fr-chart-min-max.didUpdateAttrs()');
  // // },

  willDestroyElement() {
    this._super(...arguments);
    this._logTrace('fr-chart-min-max.willDestroyElement()');

    this._removeEventListener();
  },

  _logTrace(text) {
    if(this.get('_trace') === true) {
      Ember.Logger.log(text);
    }
  },

  _convertDateString(date, format) {
    return this.get('fr_I18nService').formatDate(date, format);
  },

  _createSeries() {

    // debugger;

    const zero = 0;
    const half = 0.5;
    const adjustSymbolSize = 10;
    const twenty = 20;

    //this._logTrace('fr-chart-min-max._createSeries()');
    this._removeEventListener();
    this._removeDom();

    const series = this.get('_seriesData');

    if(series.data.length === zero) {
      return;
    }

    const xScaleFunction = this.get('_xScale');
    const yScaleFunction = this.get('_yScale');

    if(xScaleFunction == null){
      return;
    }

    const glyphiconPrefix = this.get('_settingGlyphiconPrefix');
    const tooltipTemplate = series.config.tooltipTemplate;
    ////let height = parseInt(this.get('_height'));
    //let transparentOpacity = this.get('_settingTransparentOpacity');
    //let normalOpacity = this.get('_settingNormalOpacity');
    const postfixMax = this.get('_postfixMax');
    const postfixMin = this.get('_postfixMin');
    const toBeSymbolSize = series.config.symbolSize + adjustSymbolSize;
    const dateFormat = this.get('_chartData').timeFormat.dataFormat;
    let isRotateBottomImage = series.config.isRotateBottomImage;

    if(Ember.isEmpty(isRotateBottomImage)) {
      isRotateBottomImage = false;
    }

    // tooltipTemplate 을 위한 svg 의 sibling 개체
    const p = this.$().parent().parent();

    if(p.children('div.chartTooltipTemplate').length === zero) {
      p.append('<div class=\'chartTooltipTemplate\'></div>');
    }

    const toolTip = d3.select(p[zero]).selectAll('div.chartTooltipTemplate');
    let el = this.$().get(zero);
    // const seriesRootG = d3.select(el)
    //   .attr('class', 'chart seriesRoot' + series.no)
    //   .attr('data-id', 'seriesRoot' + series.no);


    // debugger;


    let seriesRootG;

    if(this.get('_parentType') === 'flowsheet') {
      el = this.$().parent().get(zero);
      seriesRootG = d3.select(el)
        .select('.main')
        .select('.chartRoot')
        .append('g')
        .attr('class', 'chart seriesRoot' + series.no)
        .attr('data-id', 'seriesRoot' + series.no);
    } else {
      seriesRootG = d3.select(el)
        .attr('class', 'chart seriesRoot' + series.no)
        .attr('data-id', 'seriesRoot' + series.no);
    }

    // minMax
    seriesRootG
      .selectAll('.chart.minMax.series' + series.no)
      .data(series.data)
      .enter()
      .append('rect')
      .attr('class', 'chart minMax series' + series.no)
      .attr('x', function(d) {
        //const half = 0.5;

        // debugger;
        const tempWidth = series.config.strokeWidth * 0.5;

        let xAxisProperty = d[series.config.xAxisProperty];
        if(typeof xAxisProperty === 'string'){
          xAxisProperty = new Date(xAxisProperty);
        }

        const w = xScaleFunction(xAxisProperty) - tempWidth;
       // const w = xScaleFunction.range()[0] - tempWidth;

        // w가 NaN이 나오는 이유를 확인한다.

        return w;
      })
      .attr('y', function(d) {
        // debugger;
        return yScaleFunction(d[series.config.yAxisProperty + postfixMax]);
        //return xScaleFunction.range()[1];
      })
      .attr('width', series.config.strokeWidth)
      .attr('height', function(d) {
        // 하나만 있을 때 체크
        const min = d[series.config.yAxisProperty + postfixMin];
        const max = d[series.config.yAxisProperty + postfixMax];

        if(Ember.isEmpty(min) || Ember.isEmpty(max)) {
          return 0;
        }
        // 하나만 있을 때 체크.

        const tempMin = yScaleFunction(d[series.config.yAxisProperty + postfixMin]);
        const tempMax = yScaleFunction(d[series.config.yAxisProperty + postfixMax]);

        return tempMin - tempMax;
      })
      .attr('fill', series.config.strokeColor)
      .on('mouseover', function() {
        this._logTrace('fr-chart-min-max.minMax.mouseover()');
        this._raiseEvents('mouseoverSeriesCB', series);
        d3.event.stopPropagation();
      }.bind(this))
      .on('mouseout', function() {
        this._logTrace('fr-chart-min-max.minMax.mouseout()');
        toolTip.style('display', 'none');
        this._raiseEvents('mouseoutSeriesCB', series);
        d3.event.stopPropagation();
      }.bind(this))
      .on('mousemove', function(d) {
        this._logTrace('fr-chart-min-max.minMax.mousemove()');
        const adjustX = 10;
        const adjustY = 20;
        const x = d3.event.x + adjustX;
        const y = d3.event.y + adjustY;

        toolTip.style('left', x + 'px');
        toolTip.style('top', y + 'px');
        toolTip.style('display', 'inline-block');

        if(Ember.isEmpty(tooltipTemplate) || Ember.isBlank(tooltipTemplate) ) {
          let val = d[series.config.tooltipProperty];

          if( typeof val === 'object' && val instanceof Date) {
            val = this._convertDateString(val, dateFormat);
          }

          toolTip.html(val);
        } else {
          let result = tooltipTemplate;

          for(const name in d) {
            let val = d[name];

            if( typeof val === 'object' && val instanceof Date) {
              val = this._convertDateString(val, dateFormat);
            }
            const regexp = new RegExp('{{' + name + '}}', 'gi');

            result = result.replace(regexp, val);
          }
          toolTip.html(result);
        }
      }.bind(this));

    // minMaxTopSymbol
    seriesRootG
      .selectAll('.chart.minMaxTopSymbol.series' + series.no)
      .data(series.data)
      .enter()
      .append('svg:foreignObject')
      .attr('class', 'chart foreignObject series' + series.no )
      .attr('x', function(d) {

        const temp = toBeSymbolSize * 0.5;

        let xAxisProperty = d[series.config.xAxisProperty];
        if(typeof xAxisProperty === 'string'){
          xAxisProperty = new Date(xAxisProperty);
        }

        const w = xScaleFunction(xAxisProperty) - temp;

        //const w = xScaleFunction.range()[0] - temp;

        return w;
      })
      .attr('y', function(d) {
        if(Ember.isEmpty(d[series.config.yAxisProperty + postfixMax])) {
          return -50;
        }

        const temp2 = toBeSymbolSize * 0.5;
        const w = yScaleFunction(d[series.config.yAxisProperty + postfixMax]) - temp2;
        //const w = xScaleFunction.range()[1] - temp2;

        return w;
      })
      // [COMPATIBILITY-EDGE]
      .attr('width', 20)
      .attr('height', 20)
      .append('xhtml:i')
      .attr('class', 'chart minMaxTopSymbol series' + series.no + ' ' + glyphiconPrefix + ' md-' + toBeSymbolSize)
      .style('color', series.config.symbolColor)
      .text(series.config.symbolType.replace(glyphiconPrefix + '-',''))
      .on('mouseover', function() {
        this._logTrace('fr-chart-min-max.minMaxTopSymbol.mouseover()');
        this._raiseEvents('mouseoverSeriesCB', series);
        d3.event.stopPropagation();
      }.bind(this))
      .on('mouseout', function() {
        this._logTrace('fr-chart-min-max.minMaxTopSymbol.mouseout()');
        this._raiseEvents('mouseoutSeriesCB', series);
        d3.event.stopPropagation();
      }.bind(this));

    // minMaxBottomSymbol
    seriesRootG
      .selectAll('.chart.minMaxBottomSymbol.series' + series.no)
      .data(series.data)
      .enter()
      .append('svg:foreignObject')
      .attr('class', 'chart foreignObject series' + series.no )
      .attr('x', function(d) {
        const tempX = toBeSymbolSize * half;

        let xAxisProperty = d[series.config.xAxisProperty];
        if(typeof xAxisProperty === 'string'){
          xAxisProperty = new Date(xAxisProperty);
        }

        const w = xScaleFunction(xAxisProperty) - tempX;

        return w;
      })
      .attr('y', function(d) {
        if(Ember.isEmpty(d[series.config.yAxisProperty + postfixMin])) {
          return -50;
        }

        const tempY = toBeSymbolSize * half;
        const w = yScaleFunction(d[series.config.yAxisProperty + postfixMin]) - tempY;

        return w;
      })
      // [COMPATIBILITY-EDGE]
      .attr('width', twenty)
      .attr('height', twenty)
      .attr('transform', function(d) {
        let degree = 0;

        if(isRotateBottomImage) {
          degree = 180;
        }

        const tempSize = toBeSymbolSize * half;

        let xAxisProperty = d[series.config.xAxisProperty];
        if(typeof xAxisProperty === 'string'){
          xAxisProperty = new Date(xAxisProperty);
        }

        let x = xScaleFunction(xAxisProperty) - tempSize;
        let y = yScaleFunction(d[series.config.yAxisProperty + postfixMin]) - tempSize;

        x += tempSize;
        y += tempSize;

        x = x.toFixed(2);
        y = y.toFixed(2);

        const result = 'rotate(' + degree + ' ' + x + ', ' + y + ')';

        return result;
      })
      .append('xhtml:i')
      .attr('class', 'chart minMaxBottomSymbol series' + series.no + ' ' + glyphiconPrefix + ' md-' + toBeSymbolSize)
      .style('color', series.config.symbolColor)
      .text(series.config.symbolType.replace(glyphiconPrefix + '-',''))
      .on('mouseover', function() {
        this._logTrace('fr-chart-min-max.minMaxBottomSymbol.mouseover()');
        this._raiseEvents('mouseoverSeriesCB', series);
        d3.event.stopPropagation();
      }.bind(this))
      .on('mouseout', function() {
        this._logTrace('fr-chart-min-max.minMaxBottomSymbol.mouseout()');
        this._raiseEvents('mouseoutSeriesCB', series);
        d3.event.stopPropagation();
      }.bind(this));

    // minMaxTopTooltip
    const topTooltipSize = this.get('_chartData').tooltipSize;

    seriesRootG
      .selectAll('.chart.minMaxTopTooltip.series' + series.no)
      .data(series.data)
      .enter()
      .append('text')
      .attr('class', 'chart minMaxTopTooltip series' + series.no)
      .attr('font-size', topTooltipSize)
      .attr('text-anchor', 'left')
      .attr('style', 'display: none')
      .attr('transform', function(d) {
        //let x = xScaleFunction(d[series.config.xAxisProperty]) - series.config.strokeWidth * 0.5;
        const strokeHalf = series.config.strokeWidth * half;

        let xAxisProperty = d[series.config.xAxisProperty];
        if(typeof xAxisProperty === 'string'){
          xAxisProperty = new Date(xAxisProperty);
        }


        const x = xScaleFunction(xAxisProperty) - strokeHalf;
        const tooltipHalf = topTooltipSize * 0.5;
        const y = yScaleFunction(d[series.config.yAxisProperty + postfixMax]) - tooltipHalf;

        return 'translate(' + x  + ', ' + y + ')';
      })
      .text(function(d) {
        return d[series.config.tooltipProperty + postfixMax];
      });

    // minMaxBottomTooltip
    const bottomTooltipSize = this.get('_chartData').tooltipSize;

    seriesRootG
      .selectAll('.chart.minMaxBottomTooltip.series' + series.no)
      .data(series.data)
      .enter()
      .append('text')
      .attr('class', 'chart minMaxBottomTooltip series' + series.no)
      .attr('font-size', bottomTooltipSize)
      .attr('text-anchor', 'left')
      .attr('style', 'display: none')
      .attr('transform', function(d) {
        //let x = xScaleFunction(d[series.config.xAxisProperty]) - series.config.strokeWidth * 0.5;
        const strokeHalf = series.config.strokeWidth * half;

        let xAxisProperty = d[series.config.xAxisProperty];
        if(typeof xAxisProperty === 'string'){
          xAxisProperty = new Date(xAxisProperty);
        }

        const x = xScaleFunction(xAxisProperty) - strokeHalf;
        const tooltipAdjust = bottomTooltipSize * 1.5;
        const y = yScaleFunction(d[series.config.yAxisProperty + postfixMin]) + tooltipAdjust;

        return 'translate(' + x  + ', ' + y + ')';
      })
      .text(function(d) {
        return d[series.config.tooltipProperty + postfixMin];
      });
  },

  _removeEventListener() {
    const zero = 0;
    const series = this.get('_seriesData');
    const seriesNo = series.no;
    const mouseOverOut = ['.chart.minMax.series' + seriesNo, '.chart.minMaxTopSymbol.series' + seriesNo, '.chart.minMaxBottomSymbol.series' + seriesNo];
    const mouseMove = ['.chart.minMax.series' + seriesNo];
    const el = this.$().get(zero);
    const thisObj = d3.select(el);

    for(let i=0; i < mouseOverOut.length; i++) {
      thisObj.selectAll(mouseOverOut[i]).on('mouseover', null).on('mouseout', null);
    }

    for(let i=0; i < mouseMove.length; i++) {
      thisObj.selectAll(mouseMove[i]).on('mousemove', null);
    }
  },

  _removeDom() {
    if(this.get('_parentType') === 'flowsheet') {
      const zero = 0;
      const series = this.get('_seriesData');
      const el = this.$().parent().get(zero);

      d3.select(el)
        .select('.main >.chartRoot > .seriesRoot' + series.no)
        .remove();
    } else {
      this.$().children().remove();
    }
  },

  actions: {
  },
});