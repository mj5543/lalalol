import Ember from 'ember';
import layout from './template';

// ContextMenu Helper
export default Ember.Component.extend({
  contextmenuService: Ember.inject.service('contextmenuService'),
  layout,
  tagName: 'ol',
  classNames: ['fr-contextmenu', 'contain-list', 'scrollbar-macosx'],
  _offset: 5,
  placement: '',
  isContextMenu: false,
  _addDeactivateHandler() {
    Ember.$(document.body).on('mousedown.ctxhelper', this.actions.onMouseDownAction.bind(this));
  },
  _removeDeactivateHandler() {
    Ember.$(document.body).off('mousedown.ctxhelper');
  },
  _deactivate(e) {
    this.$().css({ 'display': 'none' });
    this._removeDeactivateHandler();
    this.get('contextmenuService').close();
  },
  _options: Ember.computed('contextmenuService.options', function () {

    this._removeDeactivateHandler();

    const ctxservice = this.get('contextmenuService');

    if (Ember.isEmpty(ctxservice)) {
      return null;
    }

    const options = ctxservice.get('options');

    if (Ember.isEmpty(options)) {
      this._deactivate();
    } else if (!Ember.isEmpty(options.originalEvent)) {
      this._addDeactivateHandler();

      Ember.run.next(this, function(){
        let offsetTop = options.originalEvent.clientY + this._offset ;
        let offsetLeft = options.originalEvent.clientX + this._offset ;
        const outerHeight = this.$().height();
        const outerWidth = this.$().width();

        if (offsetTop + outerHeight + 10 >= Ember.$(window).height()) {
          offsetTop = offsetTop - outerHeight ;
        }

        if (offsetLeft + outerWidth + 10 >= Ember.$(window).width()) {
          offsetLeft = offsetLeft - outerWidth ;
        }

        this.$().css({ 'display': 'block', 'top': offsetTop, 'left': offsetLeft });
      }.bind(this));
    }

    return options;
  }).readOnly(),
  _onContextMenu(e) {
    e.preventDefault();
    Ember.$(document.body).on('mousedown.ctxhelper', this.actions.onMouseDownAction.bind(this));
  },
  didRender() {
    this._super(...arguments);
  },
  didInsertElement(){
    this._super(...arguments);
    this.$().on('contextmenu', this._onContextMenu.bind(this));
  },
  willDestroyElement() {
    this._super(...arguments);
    this.$().off('contextmenu');
    this._removeDeactivateHandler();
  },
  willDestroy() {
    this._super(...arguments);
  },
  actions: {
    onMouseDownAction(e) {
      if (Ember.$(e.target).closest('.fr-contextmenu').length === 0) {
        this._deactivate();
      }
    },
    onClickAction(callback, arg) {
      if (callback !== undefined) {
        callback(arg);
      }
      this._deactivate();
    }
  }
});