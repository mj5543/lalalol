import itemsControl from '../fr-itemscontrol/component';

export default itemsControl.extend({

  // - selectedValue 와 selectedItem 은 동시 지원 불가 ====================================================
  selectedItem: null,
  selectedValue : null,
  selectedChanged: null,
  selectedValuePath :'',
  displayMemberPath : '',
  _selectionChanged() {
  },
  actions: {
  },
});