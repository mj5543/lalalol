import Control from '../fr-control/component';

// == ButtonBase
export default Control.extend({
  attributeBindings: ['type'],
  tagName: 'button',
  classNames: [],
  buttonType: 'none',
  content: ''
});