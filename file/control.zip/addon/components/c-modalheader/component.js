import Ember from 'ember';
import layout from './template';

export default Ember.Component.extend({
  layout,
  classNames: ['modal-header'],
  attributeBindings: ['htmlSafeStyle:style'],
  noneTitle: Ember.computed.none('title').readOnly(),
  htmlSafeStyle: Ember.computed('draggable', function () {
    if (this.get('draggable')) {
      return Ember.String.htmlSafe('cursor:move;');
    }
  }).readOnly(),
  mouseDown(event) {
    if (this.get('draggable')) {
      let originX = event.pageX, originY = event.pageY;

      Ember.$(document).on('mousemove.modal-header', function (mousemoveEvent) {
        mousemoveEvent.stopPropagation();
        mousemoveEvent.preventDefault();
        this.set('movingOffsetLeft', this.get('movingOffsetLeft') + mousemoveEvent.pageX - originX);
        this.set('movingOffsetTop', this.get('movingOffsetTop') + mousemoveEvent.pageY - originY);
        originX = mousemoveEvent.pageX;
        originY = mousemoveEvent.pageY;
      }.bind(this)).on('mouseup.modal-header', function () {
        Ember.$(document).off('mousemove.modal-header').off('mouseup.modal-header');
        originX = null;
        originY = null;
      }.bind(this));
    }
  },
});