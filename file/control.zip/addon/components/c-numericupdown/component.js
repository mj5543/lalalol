import Ember from 'ember';
import layout from './template';
import ValidationControl from '../c-validationcontrol/component';

export default ValidationControl.extend({
  layout,
  classNames: ['c-numericupdown', 'c-inp-txt'],
  tagName: 'div',
  //public properties
  style: null,
  value: null,
  allowDecimal: false,
  step: null,
  min: null,
  max: null,
  tabindex: null,
  placeHolder: null,
  maxLength: null,
  disabled: false,
  readOnly: false,
  enableGotFocusAutoSelect: false,
  required: false,
  clearSpin: false,
  showValidationSuccess: false,
  externalErrorMessage: null,
  validationRules: null,
  //public events
  onLoaded: null,
  onUnload: null,
  onClick: null,
  onFocusIn: null,
  onFocusOut: null,
  onKeyPress: null,
  onKeyUp: null,
  onKeyDown: null,
  onChanged: null,
  onTextCommit: null,

  _internalValue: Ember.computed('value', {
    get (key) {
      const value = this.get('value');

      return Ember.isNone(value) ? '' : value;
    },
    set (key, value) {
      return value;
    },
  }),
  /*
  defaultRules: Ember.computed(function () {
    return Ember.A().addObject({
      rule: function (_internalValue) {
        return /-?(\d+|\d+\.\d+|\.\d+)([eE][-+]?\d+)?/.test(_internalValue);
      },
      message: 'Invalid numeric.'
    });
  }).readOnly(),
  */
  click(event) {
    this._raiseEvents('onClick', {
      source: this,
      originalEvent: event
    });
  },
  focusIn(event) {
    if (this.get('enableGotFocusAutoSelect')) {
      this.$('input').select();
    }
    this._raiseEvents('onFocusIn', {
      source: this,
      originalEvent: event
    });
  },
  focusOut(event) {
    this._syncDataValue();
    this._raiseEvents('onFocusOut', {
      source: this,
      originalEvent: event
    });
  },
  keyPress(event) {
    if (event.keyCode === 13) {
      event.preventDefault();
      this._syncDataValue();
      this._raiseEvents('onTextCommit', {
        source: this,
        originalEvent: event
      });
    }
    this._raiseEvents('onKeyPress', {
      source: this,
      originalEvent: event
    });
  },
  keyUp(event) {
    this._raiseEvents('onKeyUp', {
      source: this,
      originalEvent: event
    });
  },
  keyDown(event) {
    this._raiseEvents('onKeyDown', {
      source: this,
      originalEvent: event
    });
  },
  _syncDataValue() {
    const _internalValue = this.get('_internalValue'), min = this.get('min'), max = this.get('max');
    let floatValue = this.get('allowDecimal') ? parseFloat(_internalValue) : parseInt(_internalValue);

    if (!Ember.isNone(min) && floatValue < min) {
      floatValue = min;
    }
    if (!Ember.isNone(max) && max < floatValue) {
      floatValue = max;
    }
    if (isNaN(floatValue)) {
      floatValue = null;
    }
    this.set('value', floatValue);
    Ember.run.schedule('afterRender', this, function () {
      if (!this.get('isDestroying') && !this.get('isDestroyed')) {
        this.$('input').val(floatValue);
      }
      floatValue = null;
    });
  },
  actions: {
    change(event) {
      this._syncDataValue();
      this._raiseEvents('onChanged', {
        source: this,
        originalEvent: event,
        value: this.get('value')
      });
    },
  },
});