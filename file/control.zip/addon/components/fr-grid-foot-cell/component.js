import Ember from 'ember';

const { computed } = Ember;

export default Ember.Component.extend({
  tagName: 'td',
  classNameBindings: [ '_gridFootCellClass', '_gridColumnAlignClass' ],
  attributeBindings: [ 'cellIndex:data-foot-cell-index', 'tabindex' ],
  layout: computed(function () {
    return Ember.HTMLBars.compile(`<div style="{{_htmlSafeFootLineHeight}}" tabindex="-1"><div>
      {{yield (hash ${this.get('column.footTemplate')}=(component 'fr-grid-foot-cell-template'computedGroupValues=_computedGroupValues))}}</div></div>`);
  }),
  tabindex: -1,

  _gridFootCellClass: computed('_gridGuid', function () {
    return `${this.get('_gridGuid')}-foot-cell`;
  }).readOnly(),

  _gridColumnAlignClass: computed('column.align', function () {
    const _align = this.get('column.align');

    if (!Ember.isNone(_align)) {
      return _align;
    }

    return 'left';
  }).readOnly(),

  init() {
    this._super(...arguments);

    if (this.get('column.field')) {
      Ember.defineProperty(this, '_computedGroupValues', computed(`_items.@each.${this.get('column.field')}`, function () {
        const _items = this.get('_items');

        if (Ember.isArray(_items)) {
          return _items.mapBy(this.get('column.field'));
        }

        return Ember.A();
      }).readOnly());
    } else {
      Ember.defineProperty(this, '_computedGroupValues', Ember.A());
    }
  },

  didInsertElement() {
    this._super(...arguments);

    this.$().on('_getComponent', function (event, param) {
      param.component = this;
      event.stopPropagation();
      event.preventDefault();
    }.bind(this));
  },

  willDestroyElement() {
    this._super(...arguments);

    this.$().off('_getComponent');
  },
});