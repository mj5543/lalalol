import Ember from 'ember';
import Control from '../fr-control/component';
import layout from './template';

export default Control.extend({
  //== Component Properties =================================
  layout,
  //== Attribute Properties =================================
  attributeBindings: ['_watchisOpen:data-name'],
  classNames : ['fr-modalcontainer'],
  accesskey: null,
  contenteditable: null,
  dir: null,
  disabled: null,
  draggable: null,
  dropzone: null,
  hidden: null,
  lang: null,
  name: null,
  spellcheck: null,
  style: null,
  tabindex: null,
  translate: null,
  //== Public Properties ===================================
  isOpen: false,
  footer: null,
  body: null,
  opened: null,
  closed: null,
  init(){
    this._super(...arguments);
    this.set('footer',{ isFooter: true });
    this.set('body', { isBody: true });
  },
  //== Life Cycle ===========================================
  didInsertElement() {
    this._super(...arguments);

    if (!Ember.isEmpty(this.get('classNames'))) {
      this.get('classNames').forEach((css) => {
        if ( css !== 'fr-modalcontainer') {
          this.$().removeClass(css);
        }
      });
    }
    this.$().removeAttr('style');
  },
  willDestroyElement(){
    this._super(...arguments);
  },
  //== Computed Properties ==================================
  _watchisOpen: Ember.computed('isOpen', function () {
    if (this.get('isOpen')) {
      Ember.run.schedule('afterRender', this, function () {
        this.$('.scrollbar-macosx:not(.scroll-content)').scrollbar();
      });
      if (this.hasLoaded === true) {
        Ember.run.once(this, function () {
          this._onModalOpen();
        }.bind(this));
      }
      return true;
    } else {
      if (this.hasLoaded === true) {
        Ember.run.once(this, function () {
          this._onModalClose();
        }.bind(this));
      }
      this.$('.scrollbar-macosx.scroll-content').scrollbar('destroy');
      return false;
    }
  }),
  //== Private Methods ======================================
  _onModalOpen() {
    this._raiseEvents('opened', { 'source': this });
  },

  _onModalClose() {
    this._raiseEvents('closed', { 'source': this });
  },
  actions: {
    onCloseClick() {
      this.set('isOpen', false);
    }
  }
});
