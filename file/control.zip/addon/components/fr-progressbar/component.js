import Ember from 'ember';
import layout from './template';
import Control from '../fr-control/component';

export default Control.extend({
  attributeBindings: ['_watchValueChanged:data-valuechanged'],
  layout,
  tagName : 'div',
  classNames: ['fr-progressbar', 'wrap-progress'],
  value : 0,
  unit : '',
  duration : 1000,
  _watchValueChanged: Ember.computed('value', function() {
    this._onValueChanged();
  }),
  _onValueChanged() {
    const getPercent = ( parseInt(this.get('value')) / 100);
    const getProgressWrapWidth = this.$().width();
    const progressTotal = getPercent * getProgressWrapWidth;
    const animationLength = parseInt(this.get('duration'));

    this.$('.progress-bar').stop().animate({
        width: progressTotal
    }, animationLength);
  },
  init(){
    this._super(...arguments);
    this.set('unit', '%');
  },
  didInsertElement() {
    this._super(...arguments);
    this._onValueChanged();
  }
});
