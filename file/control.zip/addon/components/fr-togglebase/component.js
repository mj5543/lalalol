import Ember from 'ember';
import ButtonBase from '../fr-buttonbase/component';

// == ToggleBase
export default ButtonBase.extend({
  attributeBindings: ['watchisToggle:data-toggle'],
  labelClass: '',
  checked: false,
  isThreeState: false,
  changed: null,
  watchisToggle: Ember.computed('checked', 'content', function () {

    this._onCheckChanged();

    return this.get('checked') === true ? 'on' : 'off';

  }).readOnly(),
  _onCheckChanged() {
    // ignored
  },
  _onRaiseChanged(newValue) {
    if (this.hasLoaded) {
      Ember.run.once(this, function () {
        this._raiseEvents('changed', { 'source': this, 'checked': newValue, 'value': this.get('value') });
      }.bind(this));
    }
  },
  didInsertElement() {
    this._super(...arguments);

    if (Ember.isEmpty(this.id)) {
      this.id = this.elementId;
    }
  }
});
