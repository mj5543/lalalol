import Ember from 'ember';
import layout from './template';
import uiControl from '../fr-control/component';

export default uiControl.extend( {

  // == Component properties ===============================================
  classNames: ['fr-pagenavigation', 'paging'],
  layout,
  tagName : 'div',
  // == private properties =================================================
  _startAt : 0,
  _endAt : 0,
  _pages : 0,
  // == Public properties ==================================================
  blockSize : 0,
  currentPage : 1,
  recordCount : 0,
  recordSize : 0,
  changed : null,
  // == Computed properties ==================================================
  _watchIsdata : Ember.computed('currentPage', 'recordCount', 'recordSize', 'blockSize', function() {

    this._pages = parseInt( this.get('recordCount') / this.get('recordSize')) ;

    if ( (this.get('recordCount') % this.get('recordSize')) > 0)
    {
        this._pages++;
    }

    return this._calculates();

  }).readOnly(),
  // == Life Cycles ==========================================================
  didInsertElement() {
    this._super(...arguments);
  },
  //== private Methods =======================================================
  _raiseEvent()
  {
      let events = this.get('changed');

      if ( events) {
        events({'source' : this, 'page' : this.get('currentPage'), 'pages' : this._pages});
      }
  },
  _calculates() {

    let rest = parseInt(this.get('currentPage')) %  parseInt(this.get('blockSize'));

    if ( rest === 0)
    {
      rest = parseInt(this.get('blockSize'));
    }

    let i = parseInt(this.get('currentPage')) - rest;

    this._startAt = i + 1;
    this._endAt = this._startAt + parseInt(this.get('blockSize'));

    if (this._startAt <= 0)
    {
        this._startAt = 1;
    }

    if (this._endAt > this._pages)
    {
        this._endAt = this._pages + 1;
    }

    if (this._startAt === this._endAt)
    {
      this._endAt = 2;
    }

    let tmp = Ember.A([]) ;

    for (let index = this._startAt; index < this._endAt; index++)
    {
        tmp.pushObject( { 'index' : index, 'isSelected' :  index === this.get('currentPage') }) ;
    }

    return {
      items : tmp,
      isFirst : this._startAt === 1,
      isPrev : this._startAt === 1,
      isNext : (this._endAt -1 >= this._pages),
      isLast : (this._endAt -1 >= this._pages)
    } ;

  },
  //== Action Methods =======================================================
  actions: {
    onMoveFirst() {
      this.set('currentPage', 1) ;
      this._raiseEvent();
    },
    onMovePrev() {
      this.set('currentPage', this._startAt - 1) ;
      this._raiseEvent();
    },
    onMoveNext() {
      this.set('currentPage', this._endAt) ;
      this._raiseEvent();
    },
    onMoveLast() {

      this.set('currentPage', this._pages);

      this._raiseEvent();
    },
    onSelected(index) {

      this.set('currentPage', index);

      this._raiseEvent();
    }
  }
});
