import Ember from 'ember';
import layout from './template';

const { computed } = Ember;

export default Ember.Component.extend({
  layout,
  tagName: 'thead',
  classNameBindings: ['_hasMultipleHeader:tbl-grid-dheader'],
  _notHasFrozen: computed.not('_hasFrozen').readOnly(),
  _frozenTableOrNotHasFrozen: computed.or('_frozenTable', '_notHasFrozen').readOnly(),
  _flexResizeType: computed.equal('columnResizeType', 'flex').readOnly(),
  _notFlexResizeType: computed.not('_flexResizeType').readOnly(),
  _hideLastColumnResizer: computed.or('_frozenTable', '_notFlexResizeType').readOnly(),
  _hideLastColumnLine: computed.not('_frozenTable').readOnly(),
});