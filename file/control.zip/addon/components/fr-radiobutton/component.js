import Ember from 'ember';
import Togglebase from '../fr-togglebase/component';

// fr-radioButton
export default Togglebase.extend({
  attributeBindings: ['watchGroupValue:data-groupval', 'type', 'value'],
  tagName: 'input',
  type: 'radio',
  classNames: [],
  _wasState : false,
  groupValue : '',
  watchGroupValue: Ember.computed('groupValue', function() {

    const isEqual = (this.get('value') === this.get('groupValue')) ;

    this.$().prop('checked', isEqual);

    if (isEqual || this._wasState === true) {
      this._onRaiseChanged(isEqual) ;
    }

    this._wasState = isEqual ;

    return isEqual.toString();

  }).readOnly(),
  _onInputChange(){
    if ( this.$().is(':checked') === true) {
      this.set('groupValue', this.get('value'));
    }
  },
  _onLabelMouseDown(e) {
    //this._raiseEvents('mouseDown', e);
  },
  _onLabelClick(e) {
    e.stopPropagation();
  },
  didInsertElement(){
    this._super(...arguments);

    const tabIndex = this.$().attr('tabindex') ;

    if ( Ember.isEmpty(tabIndex) || Number.isNaN(tabIndex)) {
      this.$().wrap(`<span class='fr-radio inp-rd ${this.classNames.join(' ')}'></span>`);
    } else {
      this.$().wrap(`<span tabindex='${tabIndex}' class='fr-radio inp-rd ${this.classNames.join(' ')}'></span>`);
    }

    this.$()
      .on('change.radiobutton', this._onInputChange.bind(this))
      .attr('tabindex', -1)
      .after(`<label for='${this.id}'>${this.content}</label>`)
      .next()
      .on('mousedown', this._onLabelMouseDown.bind(this))
      .on('click', this._onLabelClick.bind(this));
  },
  willDestroyElement(){
    this._super(...arguments);
    this.$().off('change.radiobutton')
    .next()
    .off('mousedown')
    .off('click');
  },
});