import Ember from 'ember';
import Selector from '../fr-selector/component';
import TreeViewDragDropMixin from '../../mixins/treeview-dragndrop-mixin';

export default Selector.extend(TreeViewDragDropMixin, {
  // == Component properties ==================================================
  attributeBindings: [ 'data-id', 'data-item-path' ],
  layout: Ember.computed(function () {
    let itemTemplate = this.get('itemTemplate'), editItemTemplate = this.get('editItemTemplate');

    if (Ember.isNone(itemTemplate)) {
      itemTemplate = '{{get dataItem displayMemberPath }}';
    }
    if (Ember.isNone(editItemTemplate)) {
      editItemTemplate = `{{fr-input value=(get dataItem displayMemberPath) }}`;
    }

    return Ember.HTMLBars.compile(`<div class='item-box'>
                                    {{#unless hasChildren}}
                                      <span class='tree-leap'></span>
                                    {{else}}
                                      <span class='{{if isExpanded 'tree-min' 'tree-plus'}}' onclick={{action 'onToggle'}}></span>
                                    {{/unless}}
                                    <div class='item {{if isActive 'selected'}}' ondblclick={{action 'itemDoubleClick' }} onclick={{action 'onSelected'}} onmousedown={{action 'createDraggable'}}  onmouseup={{action 'destroyDraggable'}}>
                                      <div class='item-presenter' tabindex="-1">
                                        {{#if isEditMode }}
                                          ${editItemTemplate}
                                        {{else}}
                                          {{#if isCheckBoxVisible}}
                                            {{fr-checkbox checked=(get dataItem checkBoxPath) indeterminate=_indeterminate change=(action 'checkBoxChanged') }}
                                          {{/if}}
                                          {{#unless hasChildren}}
                                            <span class='tree-file'></span>${itemTemplate}
                                          {{else}}
                                            <span class='{{if isExpanded 'tree-unfold' 'tree-fold'}}'></span>${itemTemplate}
                                          {{/unless}}
                                        {{/if}}
                                      </div>
                                      <div class='item-indicator'></div>
                                    </div>
                                  </div>
                                  <ol class='itemgroup {{if isExpanded 'on'}}'>
                                    {{#each (get dataItem childrenMemberPath) as |item index|}}
                                      {{fr-treeviewitem
                                        data-item-path=(concat data-item-path '-' index)
                                        data-id=(get item selectedValuePath)
                                        childrenMemberPath=childrenMemberPath
                                        selectedValuePath=selectedValuePath
                                        displayMemberPath=displayMemberPath
                                        checkBoxPath=checkBoxPath
                                        isCheckBoxVisible=isCheckBoxVisible
                                        isLeafNodeMemberPath=isLeafNodeMemberPath
                                        itemTemplate=itemTemplate
                                        editItemTemplate=editItemTemplate
                                        expandedItems=expandedItems
                                        selectedItem=selectedItem
                                        _draggable=_draggable
                                        dataItem=item
                                        treeview=treeview}}
                                    {{/each}}
                                  </ol>
                                  {{_observedProperty1}}`);
  }),
  tagName: 'li',
  classNames: [ 'fr-treeviewitem' ],
  _indeterminate: false,
  _sliderSpeed: 100,
  //_level: 0,
  //_owner: null,
  //_parent: null,
  //_items: null,
  //_rendered: null,
  //isActive: false,
  //dataItem: null,
  //isEditMode: false,
  //isExpanded: false,
  expand() {
    const expandedItems = this.get('expandedItems'), dataItem = this.get('dataItem');

    if (!expandedItems.includes(dataItem)) {
      expandedItems.addObject(dataItem);
    }
  },
  expandParent() {
    this._expandParent(this);
  },
  collapse() {
    const expandedItems = this.get('expandedItems'), dataItem = this.get('dataItem');

    if (expandedItems.includes(dataItem)) {
      expandedItems.removeObject(dataItem);
    }
  },
  editMode() {
    this._expandParent(this);
    this.set('isEditMode', true);
    this.set('beforeText', Ember.get(this.get('dataItem'), this.get('displayMemberPath')));
    Ember.run.next(this, function() {
      if (!Ember.get(this, 'isDestroyed')) {
        this.$('> div.item-box > div.item').find(':focusable').focus();
      }
    });
  },
  getParent() {
    const $target = this.$().parent().closest('.fr-treeviewitem');

    if ($target.length > 0) {
      return this._getComponent($target);
    }
    return null;
  },
  _expandParent(component) {
    let parent = component.getParent();
    if (!Ember.isNone(parent) && !Ember.isNone(parent.expand)) {
      parent.expand();
      this._expandParent(parent);
    }
    parent = null;
  },
  isActive: Ember.computed('dataItem', 'selectedItem', function () {
    return this.get('dataItem') === this.get('selectedItem');
  }).readOnly(),
  isExpanded: Ember.computed('dataItem', 'expandedItems.[]', function () {
    const expandedItems = this.get('expandedItems'), isExpanded = expandedItems.includes(this.get('dataItem'));

    if (isExpanded) {
      this.$('.itemgroup').eq(0).slideDown({
        'duration': this._sliderSpeed,
        'complete': function () {
          if (this.$('.material-icons').length > 0) {
            this.$('.material-icons').eq(0).removeClass('collapsed');
          }
        }.bind(this)
      });
    } else {
      this.$('.itemgroup').eq(0).slideUp({
        'duration': this._sliderSpeed,
        'complete': function () {
          if (this.$('.material-icons').length > 0) {
            this.$('.material-icons').eq(0).addClass('collapsed');
          }
        }.bind(this)
      });
    }

    return isExpanded;
  }).readOnly(),
  _getComponent($target) {
    let param = { component: {} }, component = null;

    $target.trigger('_getComponent', param);
    component = param.component;
    param.component = null;
    param = null;

    return component;
  },
  _getChilrenItems(childrenItems) {
    const items = Ember.A();

    if (Ember.isArray(childrenItems)) {
      childrenItems.forEach(function (child) {
        items.addObjects(this._getChilrenItems(Ember.get(child, this.get('childrenMemberPath'))));
      }.bind(this));
      items.addObjects(childrenItems);
    }

    return items;
  },
  _indeterminateChange() {
    const childrenItems = this.get('childrenItems'), checkedChildrenItems = childrenItems.filterBy(this.get('checkBoxPath'), true);

    if (childrenItems.length > 0) {
      if (checkedChildrenItems.length > 0) {
        Ember.set(this.get('dataItem'), this.get('checkBoxPath'), true);
        if (childrenItems.length === checkedChildrenItems.length) {
          this.set('_indeterminate' , false);
        } else {
          this.set('_indeterminate' , true);
        }
      } else {
        Ember.set(this.get('dataItem'), this.get('checkBoxPath'), false);
        this.set('_indeterminate' , false);
      }
    } else {
      this.set('_indeterminate' , false);
    }
  },
  // == Life Cycle =======================================
  init() {
    this._super(...arguments);

    //this.set('_items', []);
    //this.set('_level', this._getLevel() + 1);
    //this.set('isExpanded', this._getExpandedDepth() > this._getLevel());

    //if (!Ember.isEmpty(this._parent)) {
      //this._parent._items.pushObject(this);
    //}

    //if (this._owner.hasState()) {

      //const uniqueId = this._getSelectedValue();
      //const _isExpand = this._owner._isExpanded(uniqueId);

      //if (_isExpand === true) {
        //this.set('isExpanded', true);
      //}

      /*
      if (this._owner.get('_activateItem') === uniqueId) {
        this.set('isActive', true);
      }
      */
    //}
    Ember.defineProperty(this, 'hasChildren', Ember.computed('isLeafNodeMemberPath', `dataItem.${this.get('childrenMemberPath')}`, function () {
      const isLeafNodeMemberPath = this.get('isLeafNodeMemberPath'), childrenMemberPath = this.get('childrenMemberPath');

      if (!Ember.isNone(isLeafNodeMemberPath)) {
        return !Ember.get(this.get('dataItem'), isLeafNodeMemberPath);
      }
      return !Ember.isEmpty(Ember.get(this.get('dataItem'), childrenMemberPath));
    }));
    Ember.defineProperty(this, 'childrenItems', Ember.computed(`dataItem.${this.get('childrenMemberPath')}`, function () {
      return this._getChilrenItems(Ember.get(this.get('dataItem'), this.get('childrenMemberPath')));
    }));
    if (this.get('isCheckBoxVisible')) {
      Ember.defineProperty(this, '_observedProperty1', Ember.computed(`childrenItems.@each.${this.get('checkBoxPath')}`, function () {
        Ember.run.once(this, this._indeterminateChange);

        return null;
      }));
      /*
      this.childrenItems
      const _childrens = this._getChildrens(), _checkeds = _childrens.filterBy(this._getCheckBoxPath(), true).length;

      if (this._checkedValue() === true && _childrens.length !== _checkeds) {
        this.set('_indeterminate', true);
      }
      */
    }
    //this._initializeComponent();
  },
  didInsertElement() {
    this._super(...arguments);

    this.$().on('_getComponent', function (event, param) {
      param.component = this;
      event.stopPropagation();
      event.preventDefault();
    }.bind(this));

    /*
    this.$().on('onactivate', this._onActivate.bind(this))
      .on('onselected', this._onSelected.bind(this))
      .on('onexpanded', this.expand.bind(this))
      .on('oncollapse', this.collapse.bind(this));
    */
    //this._rendered = true;
  },
  willDestroyElement() {
    /*
    if (!Ember.isEmpty(this._parent)) {
      this._parent._items.removeObject(this);
    }
    */
    this._super(...arguments);

    this.$().off('_getComponent');
    /*
    this.$().off('onactivate')
      .off('onselected')
      .off('onexpanded')
      .off('oncollapse');
    */
  },
  // == Private Methods======================================
  /*
  _initializeComponent() {
    const childrenPath = `dataItem.${this._getChildrenMemberPath()}.[]`;

    Ember.defineProperty(this, '_watchitem', Ember.computed('isExpanded', childrenPath, function () {

      const childrens = this._getChildrens();

      const isExpand = this.get('isExpanded');
      const isLeaf = Ember.isEmpty(this._getLeafNodeMemberPath()) ? true : this.get(`dataItem.${this._getLeafNodeMemberPath()}`);

      this._owner._onToggle(isExpand, this.get(`dataItem.${this._getSelectedValuePath()}`));

      if (isExpand === true) {
        this.$('.itemgroup').eq(0).slideDown({
          'duration': this._sliderSpeed,
          'complete': function () {
            if (Ember.isEmpty(this.$('.material-icons'))) {
              Ember.Logger.log(this);
            } else {
              this.$('.material-icons').eq(0).removeClass('collapsed');
            }
          }.bind(this)
        });
      } else {
        this.$('.itemgroup').eq(0).slideUp({
          'duration': this._sliderSpeed,
          'complete': function () {
            if (Ember.isEmpty(this.$('.material-icons'))) {
              Ember.Logger.log(this);
            } else {
              this.$('.material-icons').eq(0).addClass('collapsed');
            }
          }.bind(this)
        });
      }

      return {
        expand: isExpand,
        collapsed: !isExpand,
        isEmpty: isLeaf === false ? false : Ember.isEmpty(childrens),
        items: childrens
      };
    }));
  },
  _getSelectedValue() {
    return this.get(`dataItem.${this._getSelectedValuePath()}`);
  },
  _getLeafNodeMemberPath() {
    return this._owner.get('isLeafNodeMemberPath');
  },
  _getItemTemplate() {
    return this._owner.get('itemTemplate');
  },
  _getEditeditItemTemplate() {
    return this._owner.get('editItemTemplate');
  },
  _getExpandedDepth() {
    return parseInt(this._owner.get('expandedDepth'), 10);
  },
  _getCheckBoxPath() {
    return this._owner.get('checkBoxPath');
  },
  _checkedValue(newValue) {
    if (Ember.isEmpty(newValue) === true) {
      return this.get(`dataItem.${this._getCheckBoxPath()}`);
    } else {
      this.set(`dataItem.${this._getCheckBoxPath()}`, newValue);
    }
  },
  _getChildrenMemberPath() {
    return this._owner.get('childrenMemberPath');
  },
  _getChildrens() {
    const _childrens = this.get(`dataItem.${this._getChildrenMemberPath()}`);

    if (Ember.isEmpty(_childrens) === true) {
      return [];
    }
    return _childrens;
  },
  _getLevel() {
    return parseInt(this.get('_level'), 10);
  },
  _getSelectedValuePath() {
    return this._owner.get('selectedValuePath');
  },
  _hasCheckBoxVisible() {
    return this._owner.get('isCheckBoxVisible');
  },
  _onActivate(e, arg) {
    e.preventDefault();
    e.stopPropagation();

    if (!Ember.isEmpty(arg)) {
      arg.originalSource = this;
      arg.dataItem = this.get('dataItem');
      arg.parent = this._parent;
    }
    return false;
  },
  _onDeactive() {
    if (this.get('isDestroyed') === true || this.get('isDestroying') === true) {
      return;
    }
    this.set('isEditMode', false);
    //this.set('isActive', false);
  },
  _onParentStateUpdate(isindeterminate) {

    const childrens = this._getChildrens();
    const checkedCount = childrens.filterBy(this._getCheckBoxPath(), true).length;

    if (isindeterminate === true) {
      this._checkedValue(true);
      this.set('_indeterminate', true);
    }
    else if (childrens.length === checkedCount) {
      this._checkedValue(true);
      this.set('_indeterminate', false);
    } else if (checkedCount === 0) {
      this._checkedValue(false);
      this.set('_indeterminate', false);
    } else {

      isindeterminate = checkedCount > 0 && checkedCount < childrens.length;
      this._checkedValue(isindeterminate);
      this.set('_indeterminate', isindeterminate);
    }

    if (!Ember.isEmpty(this._parent)) {
      this._parent._onParentStateUpdate(isindeterminate);
    }
  },
  _onChildStateUpdate(ischecked) {

    this._checkedValue(ischecked);
    this.set('_indeterminate', false);

    if (!Ember.isEmpty(this._items)) {
      this._items.forEach(function (item) {
        item._onChildStateUpdate(ischecked)
      });
    }
  },
  _onSelected(e) {
    if (!Ember.isEmpty(e)) {
      e.preventDefault();
      e.stopPropagation();
    }

    this._owner._onSelected({ 'source': this._owner, 'originalSource': this, 'parent': this._parent, 'dataItem': this.get('dataItem') });
  },
  _onCheckChanged(checked) {
    this.set('_indeterminate', false);

    if (!Ember.isEmpty(this._parent)) {
      this._parent._onParentStateUpdate();
    }

    if (!Ember.isEmpty(this._items)) {
      this._items.forEach(function (item) {
        item._onChildStateUpdate(checked)
      });
    }

    if (this._rendered) {
      const arg = { 'source': this._owner, 'originalSource': this, 'dataItem': this.get('dataItem') };

      if (checked === true) {
        this._owner._onChecked(arg);
      } else {
        this._owner._onUnChecked(arg);
      }
    }

  },
  */
  focusOut(event) {
    if (this.get('isEditMode')) {
      let $target = this.$(event.target).closest(`.item-presenter`);
      
      if (!this.get('element').contains(event.relatedTarget) || !this.$(event.relatedTarget).closest('.item-presenter').is($target)) {
        const treeComponent = this.get('treeview'), beforeText = this.get('beforeText');

        this.set('isEditMode', false);
        this.set('beforeText', null);
        treeComponent._raiseEvents('editModeEnded', { 'source': treeComponent, 'originalSource': this, 'textchanged': beforeText !== Ember.get(this.get('dataItem'), this.get('displayMemberPath')) });
      }
      $target = null;
    }
  },
  _createDraggable() {
    if (!this.get('isDestroyed') && this.get('_draggable')) {
      this._getPresenter().attr('draggable', true).fr_draggable({
        dragId : 'tvdnd',
        dragstart : this._dragStart.bind(this),
        dragend : this._dragEnd.bind(this)
      });
    }
  },
  _destroyDraggable() {
    if (!this.get('isDestroyed') && this.get('_draggable')) {
      this._getPresenter().attr('draggable', null).fr_draggable('destroy');
    }
  },
  // == Actions =============================================
  actions: {
    createDraggable() {
      this._createDraggable();
    },
    destroyDraggable() {
      this._destroyDraggable();
    },
    checkBoxChanged(event) {
      this.get('childrenItems').setEach(this.get('checkBoxPath'), this.$(event.target).is(":checked"));
      //const _checked = this.$(event.target).is(":checked");

      //this._onCheckChanged(_checked);
    },
    itemDoubleClick() {
      const treeComponent = this.get('treeview');

      treeComponent._raiseEvents('mouseDoubleClick', { 'source': treeComponent, 'originalSource': this, 'parent': this.getParent(), 'dataItem': this.get('dataItem') });
    },
    onFocusOut() {
      //if (this.get('isEditMode') === true) {
        //this.set('isEditMode', false);

        //this._owner._onEndEidtMode({ 'source': this._owner, 'originalSource': this, 'textchanged': false });
      //}
    },
    onTextCommit() {
      //this.set('isEditMode', false);

      //this._owner._onEndEidtMode({ 'source': this._owner, 'originalSource': this, 'textchanged': true });
    },
    onToggle() {
      /*
      const _hasExpanded = !this.get('isExpanded');

      const arg = { 'source': this._owner, 'originalSource': this, 'dataItem': this.get('dataItem'), 'cancel': false };

      if (_hasExpanded) {
        this._owner._onExpanded(arg);
      } else {
        this._owner._onCollapsed(arg);
      }

      if (arg.cancel === true) {
        return;
      }

      this.set('isExpanded', _hasExpanded);
      */
      const expandedItems = this.get('expandedItems'), dataItem = this.get('dataItem'), treeComponent = this.get('treeview'),
      args = { 'source': treeComponent, 'originalSource': this, 'dataItem': dataItem, 'cancel': false };

      if (expandedItems.includes(dataItem)) {
        treeComponent._raiseEvents('collapsed', args);
        if (!args.cancel) {
          expandedItems.removeObject(dataItem);
        }
      } else {
        treeComponent._raiseEvents('expanded', args);
        if (!args.cancel) {
          expandedItems.addObject(dataItem);
        }
      }
    },
    onSelected() {
      this.set('selectedItem', this.get('dataItem'));
    },
  },
});