import Ember from 'ember';
import GlobalServiceContainerMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';

export default Ember.Component.extend(GlobalServiceContainerMixin, {
  classNameBindings: [ 'isDataSucess:ok', 'isDataError:error', 'disabled', 'readonly' ],
  attributeBindings: [ 'htmlSafeStyle:style', 'accesskey', 'contenteditable', 'dir', 'readonly:readonly', 'disabled:disabled', 'draggable', 'dropzone', 'hidden', 'lang', 'name', 'spellcheck', 'tabindex', 'translate' ],
  htmlSafeStyle: Ember.computed('style', function () {
    const style = this.get('style');

    if (!Ember.isNone(style)) {
      return Ember.String.htmlSafe(style);
    }

    return null;
  }),
  didInsertElement() {
    this._super(...arguments);

    this.hasLoaded = true;
    this._raiseEvents('loaded', { source: this });
  },
  willDestroyElement() {
    this._super(...arguments);

    this._raiseEvents('unload', { source: this });
  },
  _raiseEvents(name, args) {
    const action = this.get(name);

    if (action) {
      if (Ember.isArray(args)) {
        return action(...args);
      } else {
        return action(args);
      }
    }
  },
  /*
  // == Component Properties
  attributeBindings: [ 'accesskey', 'contenteditable', 'dir', 'readonly', 'disabled', 'draggable', 'dropzone', 'hidden', 'lang', 'name', 'spellcheck', 'safetyStyle:style', 'tabindex', 'translate'],
  classNameBindings : [ 'getClassNames' ],
  loaded : null,
  disabled: false,
  readonly: false,
  hasLoaded : false,
  contextmenu : null,
  isDataSucess : null,
  isDataError: null,
  validationResult : null,
  // == Computed ==========================================
  getClassNames: Ember.computed('disabled', 'readonly', 'isDataSucess', 'isDataError', 'validationResult', function() {

    if ( this.get('tagName') === 'input' ) {
      this._inputClassChange(this.$().parent());
    } else if ( this.get('hasInput') === true ) {
      this._inputClassChange(this.$());
    } else {
      if ( this.get('disabled') === true) {
        return 'disabled' ;
      }

      if ( this.get('readonly') === true) {
        return 'readonly' ;
      }
    }

    return '' ;

  }).readOnly(),
  safetyStyle: Ember.computed('style', function() {
     return Ember.String.htmlSafe(this.get('style'));
  }),
  // == public Methods ====================================
  updateLayout() {
    // ignored
  },
  _inputClassChange(element, isSucess = this.get('isDataSucess'), isError = this.get('isDataError')) {

    element.removeClass('disabled').removeClass('readonly').removeClass('ok').removeClass('error') ;

    if ( this.get('disabled') === true) {
      element.addClass('disabled');
      return;
    }

    if ( this.get('readonly') === true) {
      element.addClass('readonly');
      return;
    }

    if ( isError === true) {
      element.addClass('error');

      const result = this.get('validationResult') ;

      if ( !Ember.isEmpty(result)){
        element.append(`<span>${result}</span>`);
      }

      return ;
    }

    if ( isSucess === true) {
      element.addClass('ok');

      return ;
    }
  },
  _raiseEvents(eventName, arg) {
    let events = this.get(eventName) ;

    if ( events) {
      events(arg);
    }
  },
  _onLoaded() {
    this._raiseEvents('loaded', {'source' : this}) ;
  },
  // == Life Cycle ========================================
  didInsertElement() {
    this._super(...arguments);

    this.hasLoaded = true ;

    this._onLoaded();
  }
  */
});