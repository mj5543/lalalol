import Ember from 'ember';
import layout from './template';
import Control from '../fr-control/component';
import { v4 } from 'uuid';

// == fr-file
export default Control.extend({
  layout,
  classNames: ['fr-file', 'btn-fileadd'],
  tagName: 'div',
  labelId: null,
  multiple: false,
  text: 'find',
  selectionChanged: null,
  init() {
    this._super(...arguments);
    if (Ember.isEmpty(this.get('labelId'))) {
      this.set('labelId', v4());
    }
  },
  didInsertElement() {
    this._super(...arguments);
  },
  willDestroyElement() {
    this._super(...arguments);
  },
  actions: {
    onChangeAction(e) {
      this._raiseEvents('selectionChanged', { source: this, originalSource: e.srcElement, originalEvent: e, files: e.srcElement.files });
    }
  }
});
