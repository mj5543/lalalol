import Ember from 'ember';
import layout from './template';

export default Ember.Component.extend({
  tagName: 'ul',
  layout,
  classNames: ['c-scheduler-item'],
  classNameBindings: ['_schedulerItemClass'],
  _moreCount: 0,
  _schedulerItemClass: Ember.computed('_schedulerGuid', 'data.isDisabled', function () {
    return `${this.get('_schedulerGuid')}-item ${this.get('data.isDisabled') ? 'disabled-item' : ''}`;
  }).readOnly(),
  _htmlSafeBodyTemplateLineHeight: Ember.computed('_lineHeight', '_lineCount', '_moreCount', function () {
    const _lineHeight = this.get('_lineHeight'), _lineCount = this.get('_moreCount') > 0 ? this.get('_lineCount') - 1 : this.get('_lineCount');

    if (_lineCount > 0) {
      return Ember.String.htmlSafe(`height:${_lineHeight * _lineCount}px;`);
    }

    return Ember.String.htmlSafe(`height:0px;`);
  }).readOnly(),
  _source: Ember.computed('templateItemCount', '_lineCount', '_schedulerSource', function () {
    const source = Ember.A(), _lineCount = Ember.isNone(this.get('templateItemCount')) ? this.get('_lineCount') : this.get('templateItemCount'),
    _schedulerSource = this.get('_schedulerSource'), value = this.get('data.value'), _itemsSource = Ember.get(_schedulerSource, value);
    let _moreCount = 0;

    if (0 < _lineCount) {
      if (!Ember.isNone(_itemsSource)) {
        let props = Object.getOwnPropertyNames(_itemsSource);

        if (0 < props.length) {
          const length = parseInt(props[props.length - 1]) + 1;

          for (let i = 0; i < length; i++) {
            if (i < _lineCount) {
              source.addObject(!Ember.isNone(_itemsSource[i]) ? _itemsSource[i] : { size: 0, originSize: 0 });
            } else if (!Ember.isNone(_itemsSource[i])) {
              _moreCount++;
            }
          }
          if (_lineCount < length) {
            const lastItem = source.objectAt(source.length - 1);

            source.removeAt(source.length - 1);
            if (0 < lastItem.originSize) {
              _moreCount++;
            }
          } else if (_lineCount === length) {
            const lastItem = source.objectAt(source.length - 1);

            if (1 < lastItem.originSize) {
              const currentMoment = moment(value, 'YYYY-MM-DD').add(lastItem.padding, 'days');

              for(let i = 0; i < lastItem.originSize; i++) {
                props = Object.getOwnPropertyNames(Ember.get(_schedulerSource, currentMoment.format('YYYY-MM-DD')));
                if (_lineCount < parseInt(props[props.length - 1]) + 1) {
                  source.removeAt(source.length - 1);
                  _moreCount++;
                  break;
                }
                currentMoment.add(1, 'days');
              }
            }
          }
        }
      }
    }
    Ember.run.once(this, function () {
      this.set('_moreCount', _moreCount);
      _moreCount = null;
    });

    return source;
  }),
  _moreSource: Ember.computed('_schedulerSource', function () {
    const source = Ember.A(), _itemsSource = Ember.get(this.get('_schedulerSource'), this.get('data.value'));

    if (!Ember.isNone(_itemsSource)) {
      Object.getOwnPropertyNames(_itemsSource).forEach(function (prop) {
        source.addObject(_itemsSource[prop]);
      });
    }

    return source;
  }),
  didInsertElement() {
    this._super(...arguments);
    this.$().on('_getComponent', function (event, param) {
      param.component = this;
      event.stopPropagation();
      event.preventDefault();
    }.bind(this));
  },
  willDestroyElement() {
    this.$().off('_getComponent');
    this._super(...arguments);
  },
  _raiseEvents(name, args) {
    if (!Ember.isNone(this.get(name))) {
      if (Ember.isArray(args)) {
        return this.get(name)(...args);
      } else {
        return this.get(name)(args);
      }
    }
  },
  actions: {
    schedulerTaskItemClick(item, event) {
      this._raiseEvents('onSchedulerTaskItemClick', [item, event]);
    },
    schedulerMoreClick(event) {
      this._raiseEvents('onSchedulerMoreClick', [this, event]);
    },
  },
});