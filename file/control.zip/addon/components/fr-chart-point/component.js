import Ember from 'ember';
import layout from './template';
//import CHIS from 'framework/chis-framework';
import Control from '../fr-control/component';
import GlobalServiceContainerMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';
import SVGIconMixin from '../../mixins/svg-icon-mixin';

export default Control.extend(SVGIconMixin, GlobalServiceContainerMixin, StatefulComponentMixin, {
  layout,
  tagName: 'g',
  //attributeBindings:['_isTrendChart'],
  classNames: ['fr-chart-point'],

  chartData: null,
  reload: null,
  height: null,
  parentType: null,
  seriesData: null,
  trace: null,
  width: null,
  xAxis: null,
  xScale: null,
  yAxis: null,
  yScale: null,
  setting: null,

  _distance: null,
  _intersectionPoint: null,
  _seriesTop: null,

  _chartData: Ember.computed.alias('chartData').readOnly(),
  _reload: Ember.computed.alias('reload').readOnly(),
  _height: Ember.computed.alias('height').readOnly(),
  _parentType: Ember.computed.alias('parentType').readOnly(),
  _seriesData: Ember.computed.alias('seriesData').readOnly(),
  _trace: Ember.computed.alias('trace').readOnly(),
  _width: Ember.computed.alias('width').readOnly(),
  _xAxis: Ember.computed.alias('xAxis').readOnly(),
  _xScale: Ember.computed.alias('xScale').readOnly(),
  _yAxis: Ember.computed.alias('yAxis').readOnly(),
  _yScale: Ember.computed.alias('yScale').readOnly(),

  _isTrendChart: Ember.computed('_chartData', function() {
    // // let series = this.get('_chartData').series;
    // // for(let i=0; i < series.length; i++) {
    // //   if(series[i].config.type === 'point' || series[i].config.type === 'fromTo' )
    // //     return true;

    // // }

    //this.setDATA();
    return false;
  }),

  _settingPaddingTop: Ember.computed('_setting', function() {
    return this.get('_setting').paddingTop;
  }),
  _settingPaddingRight: Ember.computed('setting', function() {
    return this.get('setting').paddingRight;
  }),
  _settingPaddingLeft: Ember.computed('setting', function() {
    return this.get('setting').paddingLeft;
  }),
  _settingPaddingBottom: Ember.computed('setting', function() {
    return this.get('setting').paddingBottom;
  }),
  _settingNormalOpacity: Ember.computed('setting', function() {
    return this.get('setting').normalOpacity;
  }),
  _settingDarkOpacity: Ember.computed('setting', function() {
    return this.get('setting').darkOpacity;
  }),
  _settingTransparentOpacity: Ember.computed('setting', function() {
    return this.get('setting').transparentOpacity;
  }),
  _settingGlyphiconPrefix: Ember.computed('setting', function() {
    return this.get('setting').glyphiconPrefix;
  }),

  onPropertyInit() {
    this._super(...arguments);
    this._logTrace('fr-chart-point.onPropertyInit()');

    this.setStateProperties([]);
  },

  init() {
    this._super(...arguments);
    this._logTrace('fr-chart-point.init()');

    const one = 1;

    this.set('_distance', one);
    this.set('_intersectionPoint', []);
    this.set('_seriesTop', null);
  },

  didInsertElement() {
    this._super(...arguments);
    this._logTrace('fr-chart-point.didInsertElement()');
  },

  didRender() {
    this._super(...arguments);
    this._logTrace('fr-chart-point.didRender()');

    this.setDATA();
    
  },

  didUpdateAttrs() {
    
  },

  setDATA() {
    const zero = 0;
    const one = 1;
    if(Ember.isEmpty(this.get('_chartData')) === true) {
      return;
    }
    this._initProperty();
    if(this.get('_parentType') === 'timeline') {
      this._createTimelineSeries();
    } else {
      // x축 경계를 넘지 않게 ( line 시리즈 특성상)
      const valueDomain = this.get('_chartData').valueDomain;

      if(Ember.isEmpty(valueDomain) === false) {
        const series = this.get('_seriesData');
        const data = series.data;

        series.data = data.filter( function(d) {
          const val = d[series.config.xAxisProperty];

          return val >= valueDomain[zero] && val <= valueDomain[one];
        });
      }
      this._createChartSeries();
    }
    this._findIntersection();
    this._createIntersectionImage();
  },

  // // didUpdateAttrs() {
  // //   this._super(...arguments);
  // //   this._logTrace('fr-chart-point.didUpdateAttrs()');
  // // },

  willDestroyElement() {
    this._super(...arguments);
    this._logTrace('fr-chart-point.willDestroyElement()');

    this._removeEventListener();

    if(this.get('_parentType') === 'timeline') {
      this._removeTimelineDom();
    } else {
      this._removeChartDom();
    }
  },

  _logTrace(text) {
    if(this.get('_trace') === true) {
      Ember.Logger.log(text);
    }
  },

  _initProperty() {
    const ten = 10;
    const half = 0.5;
    const minusOne = -1;
    const series = this.get('_seriesData');
    const toBeSymbolSize = series.config.symbolSize + ten;

    this.set('_distance', toBeSymbolSize * minusOne * half);
  },

  _createChartSeries() {
    const zero = 0;
    const half = 0.5;
    const adjustSymbolSize = 10;
    //this._logTrace('fr-chart-point._createChartSeries()');

    this._removeEventListener();
    this._removeChartDom();

    const series = this.get('_seriesData');

    if(series.data.length === zero) {
      return;
    }

    const xScaleFunction = this.get('_xScale');
    const yScaleFunction = this.get('_yScale');
    //let height = parseInt(this.get('height'));
    //let normalOpacity = this.get('_settingNormalOpacity');
    const isTrendChart = this.get('_isTrendChart');
    const glyphiconPrefix = this.get('_settingGlyphiconPrefix');

    const toBeSymbolSize = series.config.symbolSize + adjustSymbolSize;
    const tooltipTemplate = series.config.tooltipTemplate;
    const idProperty = series.config.idProperty;
    const dateFormat = this.get('_chartData').timeFormat.dataFormat;

    // tooltipTemplate 을 위한 svg 의 sibling 개체
    const p = this.$().parent().parent();

    if(p.children('div.chartTooltipTemplate').length === zero) {
      p.append('<div class=\'chartTooltipTemplate\'></div>');
    }

    const toolTip = d3.select(p[zero]).selectAll('div.chartTooltipTemplate');
    let el, seriesRootG;

    if(isTrendChart === true) {
      el = this.$().parent().get(zero);
      seriesRootG = d3.select(el)
        .select('.main')
        .select('.chartRoot')
        .append('g')
        .attr('class', 'chart seriesRoot' + series.no)
        .attr('data-id', 'seriesRoot' + series.no);
    } else {
      el = this.$().get(zero);
      seriesRootG = d3.select(el);
    }

    // point
    seriesRootG.selectAll('.chart.point.series' + series.no)
      .data(series.data)
      .enter()
      .append('svg:foreignObject')
      .attr('class', 'chart foreignObject series' + series.no )
      .attr('x', function(d) {
        const tempX = toBeSymbolSize * half;

        let xAxisProperty = d[series.config.xAxisProperty];
        if(typeof xAxisProperty === 'string'){
          xAxisProperty = new Date(xAxisProperty);
        }

        const w = xScaleFunction(xAxisProperty) - tempX;

        return w;
      })
      .attr('y', function(d) {
        const tempY = toBeSymbolSize * half;
        const w = yScaleFunction(d[series.config.yAxisProperty]) - tempY;

        return w;
      })
      // [COMPATIBILITY-EDGE]
      .attr('width', toBeSymbolSize)
      .attr('height', toBeSymbolSize)
      .append('xhtml:i')
      .attr('class', 'chart point series' + series.no + ' ' + glyphiconPrefix + ' md-' + toBeSymbolSize)
      .style('color', series.config.symbolColor)
      .text(series.config.symbolType.replace(glyphiconPrefix + '-',''))
      .on('click', function(d) {
        const id = d[idProperty];
        const obj = { series: series, id: id};

        this._raiseEvents('clickDataCB', obj);
        d3.event.stopPropagation();
      }.bind(this))
      .on('mouseover', function() {
        this._logTrace('fr-chart-point.point.mouseover()');
        this._raiseEvents('mouseoverSeriesCB', series);
        d3.event.stopPropagation();
      }.bind(this))
      .on('mouseout', function() {
        this._logTrace('fr-chart-point.point.mouseout()');
        this._raiseEvents('mouseoutSeriesCB', series);
        toolTip.style('display', 'none');
        d3.event.stopPropagation();
      }.bind(this))
      .on('mousemove', function(d) {
        this._logTrace('fr-chart-point.point.mousemove()');
        const adjustX = 10;
        const adjustY = 20;
        const x = d3.event.x + adjustX;
        const y = d3.event.y + adjustY;

        toolTip.style('left', x + 'px');
        toolTip.style('top', y + 'px');
        toolTip.style('display', 'inline-block');

        if(Ember.isEmpty(tooltipTemplate) || Ember.isBlank(tooltipTemplate) ) {
          let val = d[series.config.tooltipProperty];

          if( typeof val === 'object' && val instanceof Date) {
            val = this._convertDateString(val, dateFormat);
          }
          toolTip.html(val);
        } else {
          let result = tooltipTemplate;

          for(const name in d) {
            let val = d[name];

            if( typeof val === 'object' && val instanceof Date) {
              val = this._convertDateString(val, dateFormat);
            }

            const regexp = new RegExp('{{' + name + '}}', 'gi');

            result = result.replace(regexp, val);
          }
          toolTip.html(result);
        }
      }.bind(this));
  },

  _convertDateString(date, format) {
    return this.get('fr_I18nService').formatDate(date, format);
  },

  _removeEventListener() {
    const zero = 0;
    const series = this.get('_seriesData');
    const seriesNo = series.no;
    const click = ['.' + this.get('_parentType') + '.point.series' + seriesNo];
    const mouseOverOut = ['.' + this.get('_parentType') + '.point.series' + seriesNo];
    const mouseMove = ['.' + this.get('_parentType') + '.point.series' + seriesNo];
    const el = this.$().parent().get(zero);
    const thisObj = d3.select(el).select('.seriesRoot' + seriesNo);

    for(let i=0; i < click.length; i++) {
      thisObj.selectAll(click[i]).on('click', null);
    }

    for(let i=0; i < mouseOverOut.length; i++) {
      thisObj.selectAll(mouseOverOut[i]).on('mouseover', null).on('mouseout', null);
    }

    for(let i=0; i < mouseMove.length; i++) {
      thisObj.selectAll(mouseMove[i]).on('mousemove', null);
    }
  },

  _removeChartDom() {
    // let series = this.get('_seriesData');
    // let el = this.$().parent().get(0);

    // d3.select(el)
    //   .select('.main >.chartRoot > .seriesRoot' + series.no)
    //   .remove();
    this.$().children().remove();
  },

  _removeTimelineDom() {
    const zero = 0;
    const series = this.get('_seriesData');
    const el = this.$().parent().get(zero);

    d3.select(el)
      .select('.main >.timelineRoot > .seriesRoot' + series.no)
      .remove();
  },

  _createTimelineSeries() {
    const zero = 0;
    const half = 0.5;
    const adjustSymbolSize = 10;

    this._removeEventListener();
    this._removeTimelineDom();

    const series = this.get('_seriesData');

    if(series.data.length === zero) {
      return;
    }

    const xScaleFunction = this.get('_xScale');
    const yScaleFunction = this.get('_yScale');
    //let height = parseInt(this.get('height'));
    //let normalOpacity = this.get('_settingNormalOpacity');
    const glyphiconPrefix = this.get('_settingGlyphiconPrefix');
    const toBeSymbolSize = series.config.symbolSize + adjustSymbolSize;
    const tooltipTemplate = series.config.tooltipTemplate;
    const idProperty = series.config.idProperty;
    const dateFormat = this.get('_chartData').timeFormat.dataFormat;

    // tooltipTemplate 을 위한 svg 의 sibling 개체
    const p = this.$().parent().parent();

    if(p.children('div.chartTooltipTemplate').length === zero) {
      p.append('<div class=\'chartTooltipTemplate\'></div>');
    }

    const toolTip = d3.select(p[zero]).selectAll('div.chartTooltipTemplate');
    const el = this.$().parent().get(zero);
    const seriesRootG = d3.select(el)
      .select('.main')
      .select('.timelineRoot')
      .append('g')
      .attr('class', 'timeline seriesRoot' + series.no)
      .attr('data-id', 'seriesRoot' + series.no);


    const this_ = this;
    //point
    seriesRootG
      .selectAll('.timeline.foreignObject.series' + series.no)
      .data(series.data)
      .enter()
      // .append('svg:foreignObject')
      .append('g')
      .attr('class', 'timeline foreignObject series' + series.no )
      .attr('transform', function(d) {
        const tempX = toBeSymbolSize * half;
        const tempY = toBeSymbolSize * half;
        const x = xScaleFunction(d[series.config.xAxisProperty]) - tempX;
        const y = yScaleFunction(d[series.config.yAxisProperty]) - tempY;
        return 'translate(' + x + ', ' + y + ')';
      })
      .append(function(d) { 

        const rect = d3.select(this).append('g');
        rect.append('rect').style('fill', 'transparent')
        .attr('width', toBeSymbolSize)
        .attr('height', toBeSymbolSize);


        // json에서 값을 불러와서 object를 만들어야 한다. 


        rect.append('path')
        .attr('d', this_._getChartIcon(series.config.symbolType.replace(glyphiconPrefix + '-','')))
        .attr("transform", `translate(-3, -3)`);
        return rect.node();
       })

      // .attr('x', function(d) {
      //   const tempX = toBeSymbolSize * half;
      //   const w = xScaleFunction(d[series.config.xAxisProperty]) - tempX;

      //   return w;
      // })
      // .attr('y', function(d) {
      //   const tempY = toBeSymbolSize * half;
      //   const w = yScaleFunction(d[series.config.yAxisProperty]) - tempY;

      //   return w;
      // })

      // [COMPATIBILITY-EDGE]
      .attr('width', toBeSymbolSize)
      .attr('height', toBeSymbolSize)
     // .append('xhtml:i')
      .attr('class', 'timeline point series' + series.no + ' ' + glyphiconPrefix + ' md-' + toBeSymbolSize)
      .style('fill', series.config.symbolColor)
     // .style('color', series.config.symbolColor)
     // .text(series.config.symbolType.replace(glyphiconPrefix + '-',''))
      .on('click', function(d) {
        const id = d[idProperty];
        const obj = { series: series, id: id};

        this._raiseEvents('clickDataCB', obj);
        d3.event.stopPropagation();
      }.bind(this))
      .on('mouseover', function() {
        this._logTrace('fr-chart-point.point.mouseover()');
        this._raiseEvents('mouseoverSeriesCB', series);
        d3.event.stopPropagation();
      }.bind(this))
      .on('mouseout', function() {
        this._logTrace('fr-chart-point.point.mouseout()');
        this._raiseEvents('mouseoutSeriesCB', series);
        toolTip.style('display', 'none');
        d3.event.stopPropagation();
      }.bind(this))
      .on('mousemove', function(d) {
        this._logTrace('fr-chart-point.point.mousemove()');
        const tempX = 10;
        const tempY = 20;

        const x = d3.event.x  + tempX;
        const y = d3.event.y + tempY;

        toolTip.style('left', x + 'px');
        toolTip.style('top', y + 'px');
        toolTip.style('display', 'inline-block');

        if(Ember.isEmpty(tooltipTemplate) || Ember.isBlank(tooltipTemplate) ) {
          let val = d[series.config.tooltipProperty];

          if( typeof val === 'object' && val instanceof Date) {
            val = this._convertDateString(val, dateFormat);
          }
          toolTip.html(val);
        } else {
          let result = tooltipTemplate;

          for(const name in d) {
            let val = d[name];

            if( typeof val === 'object' && val instanceof Date) {
              val = this._convertDateString(val, dateFormat);
            }

            const regexp = new RegExp('{{' + name + '}}', 'gi');

            result = result.replace(regexp, val);
          }
          toolTip.html(result);
        }
      }.bind(this));
  },

  _findIntersection() {
    // timeline 과 chart 위치 다름!!
    const zero = 0;
    const one = 1;
    const two = 2;
    let series = this.get('_seriesData');
    let el = null;
    let rectDom = null;

    if(this.get('_parentType') === 'timeline') {
      series = this.get('_seriesData');
      el = this.$().parent().get(0);
      rectDom = d3.select(el)
        .select('.main')
        .select('.timelineRoot')
        .selectAll('.timeline.foreignObject.series' + series.no);
    } else {
      series = this.get('_seriesData');
      el = this.$().parent().get(0);
      // d3.select(this.$().parent().get(0)).selectAll('.chart.foreignObject.series' + series.no)

      rectDom = d3.select(el)
        .select('.main')
        .select('.chartRoot')
        .selectAll('.chart.foreignObject.series' + series.no);
    }

    const rects = [];
    const distance = this.get('_distance');

    if(rectDom.length === zero) {
      return;
    }

    if(Ember.isNone(rectDom[0])){
      return;
    }

    this.set('_seriesTop', this.$(rectDom[zero][zero]).attr('y'));

    for(let i=0; i < rectDom[zero].length; i++) {
      const currentDom = rectDom[zero][i];

      rects.push({
        x: parseFloat(this.$(currentDom).attr('x')),
        width: parseFloat(this.$(currentDom).attr('width'))
      });
    }

    rects.sort(function(a, b) {
      if(a.x == b.x) {
        return 0;
      } else if (a.x < b.x) {
        return -1;
      } else {
        return 1;
      }
    });

    const results = [];

    for(let i=0; i < rects.length; i++) {
      if(i === rects.length - one) {
        break;
      }

      const current = rects[i];
      const next = rects[i+1];

      if(current.x + current.width + distance > next.x) {
        results.push((current.x + next.x) / two);
      }
    }

    this.set('_intersectionPoint', results);

  },

  _createIntersectionImage() {
    const zero = 0;
    const target = this.get('_intersectionPoint');
    const seriesTop = this.get('_seriesTop');
    const series = this.get('_seriesData');
    const glyphiconPrefix = this.get('_settingGlyphiconPrefix');
    const toBeSymbolSize = series.config.symbolSize + 10;

    //if(target === null || target.length === zero) {
    if(Ember.isEmpty(target) || target.length === zero) {
      return;
    }

    let el = null;
    let seriesRoot = null;

    if(this.get('_parentType') === 'timeline') {
      el = this.$().parent().get(zero);
      seriesRoot = d3.select(el)
        .select('.main')
        .select('.timelineRoot')
        .select('.timeline.seriesRoot' + series.no);

      seriesRoot
        .selectAll('.timeline.foreignObject.intersect.series' + series.no)
        .data(target)
        .enter()
        .append('svg:foreignObject')
        .attr('class', 'timeline foreignObject intersect series' + series.no )
        .attr('x', function(d) {
          const w = d;
          // xScaleFunction(d[series.config.xAxisProperty]) - (toBeSymbolSize * 0.5);

          return w;
        })
        .attr('y', function() {
          const w = seriesTop - toBeSymbolSize;
          //yScaleFunction(d[series.config.yAxisProperty]) - (toBeSymbolSize * 0.5);

          return w;
        })
        // [COMPATIBILITY-EDGE]
        .attr('width', toBeSymbolSize)
        .attr('height', toBeSymbolSize)
        .append('xhtml:i')
        .attr('class', 'timeline intersect series' + series.no + ' ' + glyphiconPrefix + ' md-' + toBeSymbolSize)
        .style('color', '#FF4000')
        .text('toll');
    } else {
      el = this.$().parent().get(0);

      seriesRoot = d3.select(el)
        .select('.main')
        .select('.chartRoot')
        .select('.chart.seriesRoot' + series.no);

      seriesRoot
        .selectAll('.chart.foreignObject.intersect.series' + series.no)
        .data(target)
        .enter()
        .append('svg:foreignObject')
        .attr('class', 'chart foreignObject intersect series' + series.no )
        .attr('x', function(d) {
          const w = d;
          // xScaleFunction(d[series.config.xAxisProperty]) - (toBeSymbolSize * 0.5);

          return w;
        })
        .attr('y', function() {
          const w = seriesTop - toBeSymbolSize;
          //yScaleFunction(d[series.config.yAxisProperty]) - (toBeSymbolSize * 0.5);

          return w;
        })
        // [COMPATIBILITY-EDGE]
        .attr('width', toBeSymbolSize)
        .attr('height', toBeSymbolSize)
        .append('xhtml:i')
        .attr('class', 'chart intersect series' + series.no + ' ' + glyphiconPrefix + ' md-' + toBeSymbolSize)
        .style('color', '#FF4000')
        .text('toll');
    }
  },

  actions: {
  },
});