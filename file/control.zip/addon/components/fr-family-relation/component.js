import Ember from 'ember';
import layout from './template';
import GlobalServiceContainerMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';
import ContextMenuMixin from '../../mixins/contextmenu-mixin';
const { computed, guidFor } = Ember;

export default Ember.Component.extend(GlobalServiceContainerMixin, StatefulComponentMixin, ContextMenuMixin, {
  tagName: 'div',
  classNames: [ 'fr-family-tree' ],
  attributeBindings: [ '_style:style' ],
  layout,

  onPropertyInit() {
    this._super(...arguments);
  },

  didInsertElement() {
    this._super(...arguments);
  },

  didRender() {
    this._super(...arguments);
  },

  willDestroyElement() {
    this._super(...arguments);
  },

  actions: {

  },
});