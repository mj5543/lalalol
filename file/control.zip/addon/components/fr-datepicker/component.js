import Ember from 'ember';
import layout from './template';
import Control from '../fr-control/component';
import DatePickerMixin from '../../mixins/datepicker-mixin';
import GlobalServiceContainerMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';
import maskHelper from '../maskHelper';

export default Control.extend(GlobalServiceContainerMixin, DatePickerMixin, {
  layout,
  tagName: 'div',
  classNames: ['fr-datepicker', 'inp-txt'],
  attributeBindings: [ '_observedAttribute' ],
  classNameBindings: [ 'navigationVisibility:inp-control', 'calendarButtonClassName' ],
  calendarButtonClassName: Ember.computed('calendarButtonVisibility', 'pickerType', function () {
    if (this.get('calendarButtonVisibility')) {
      if (this.get('pickerType') === 'time') {
        return 'inp-time';
      } else {
        return 'inp-date';
      }
    }

    return null;
  }),
  _observedAttribute: Ember.computed('_wasPickerType', 'pickerType', 'isPartialModify', function () {
    Ember.run.schedule('afterRender', this, function () {
      const wasPickerType = this.get('_wasPickerType');

      if (!Ember.isEmpty(wasPickerType) && wasPickerType !== this.get('pickerType')) {
        this._maskinput._$element.val('');
      }
      this.set('_wasPickerType', this.get('pickerType'));
      this._maskinput.mask = this._getMaskFormat();
      this._maskinput.partialModify = this.get('isPartialModify');
      this._maskinput.setMask();
    });

    return null;
  }),
  //== Private Properties ===============================================
  _maskinput: null,
  _selectedDate: null,
  _selectedTime: null,
  //== Public Properties ================================================
  displayDate: null,
  isAutoClose: true,
  isPartialModify : false,
  selectedDate: null,
  navigationMode: 'date',
  navigationInterval: 1,
  //== Public Events ================================================
  dateKeyDown: null,
  focus: null,
  blur: null,
  //== Private Methods ==============================================
  /*
  _onPropertyChanged() {

    //this._onStateChanged(this.$(), this.get('isDataSucess'), this.get('isDataError'));

    const wasPickerType = this.get('_wasPickerType');

    if (!Ember.isEmpty(wasPickerType) && wasPickerType !== this.get('pickerType')) {
      this._maskinput._$element.val('');
    }

    if (this.get('readonly') === true) {
      this.$('input[type=text]').prop('readonly', true);
    } else {
      this.$('input[type=text]').prop('readonly', false);
    }

    this.set('_wasPickerType', this.get('pickerType'));
    this._maskinput.mask = this._getMaskFormat();
    this._maskinput.partialModify = this.get('isPartialModify');
    this._maskinput.setMask();

    return null;
  },
  */
  _onTextChanged(text, value) {
    const newDate = this._formatTextToDate(text, value);

    if (this._isDateInstance(newDate)) {
      this._setDate(newDate);
    } else {
      this._setDate(null);
    }
  },
  _setDate(newValue) {
    this.set('selectedDate', newValue);
    if (!this._isDateInstance(newValue)) {
      this._maskinput.clear();
    }
  },
  _setToday() {
    this.set('displayDate', this.toDay);
    this.set('_selectedDate', this.toDay);
    this.set('_selectedTime', this.toDay);
    this.set('calendarMode', 'month');
  },
  _setNow() {
    const now = this.get('co_CommonService').getNow();
    this.set('displayDate', now);
    this.set('_selectedDate', now);
    this.set('_selectedTime', now);
    this.set('_selectedTime', now);
    this.set('calendarMode', 'month');
  },
  _isDateInstance(date) {
    return date instanceof Date && !isNaN(date.valueOf());
  },
  // == Public Methods =============================================
  displayText() {
    return this._getDisplayText(this.dateFormat, this.get('selectedDate'));
  },
  calendarOpen() {
    const selectedDate = this.get('selectedDate');

    if (this._isDateInstance(selectedDate)) {
      this.set('_selectedDate', selectedDate);
      this.set('_selectedTime', selectedDate);
    }

    this.set('isOpen', true);
  },
  _isOpenChanged() {
    if (Ember.isNone(this.attrs.displayDate) && this.get('isOpen')) {
      if (!Ember.isNone(this.get('selectedDate'))) {
        this.set('displayDate', new Date(this.get('selectedDate')));
      } else {
        this.set('displayDate', new Date(Date.now()));
      }
    }
    this._raiseEvents('isOpenChanged', { 'source': this, 'selectedDate': this.get('selectedDate') });
  },
  _selectedDateChanged() {
    const selectedDate = this.get('selectedDate');

    if (this._isDateInstance(selectedDate)) {
      this._raiseEvents('selectedDateChanged', {
        'source': this,
        'selectedDate': selectedDate,
        'Year': selectedDate.getFullYear(),
        'Month': selectedDate.getMonth(),
        'Date': selectedDate.getDate(),
        'Day': selectedDate.getDay(),
        'Hour': selectedDate.getHours(),
        'Minute': selectedDate.getMinutes()
      });
    } else {
      this._raiseEvents('selectedDateChanged', {
        'source': this,
        'selectedDate': null,
        'Year': null,
        'Month': null,
        'Date': null,
        'Day': null,
        'Hour': null,
        'Minute': null
      });
    }
  },
  // == Computed Properties ========================================
  /*getClassNames: Ember.computed('disabled', 'readonly', 'isPartialModify', 'isDataSucess', 'isDataError', 'validationResult', 'calendarButtonVisibility', 'navigationVisibility', 'pickerType', function () {
    return this._onPropertyChanged();
  }).readOnly(),*/
  _watchSelectedDate: Ember.computed('selectedDate', function () {
    if (this.hasLoaded) {
      Ember.run.once(this, this._selectedDateChanged);
    }

    return this._getDisplayText(this.dateFormat, this.get('selectedDate'));
  }).readOnly(),
  _datePickerValue: Ember.computed.oneWay('_watchSelectedDate').readOnly(),
  //== Life cycle ==================================================
  init() {
    this._super(...arguments);

    this._trySetToday();
    this.set('displayDate', this.toDay);
    this._maskinput = maskHelper.create();
    this._maskinput.textCancel = this.actions.onTextCancelAction.bind(this);
    this._maskinput.textCommit = this.actions.onTextCommitAction.bind(this);
    this._maskinput.partialModify = this.isPartialModify;
    this._maskinput.autoclear = true;
  },
  didInsertElement() {
    this._super(...arguments);

    this.$().attr('tabindex', -1);
    this.set('_targetElement', this.$().get(0));
    this._maskinput._$element = this.$('.datepicker-input');
    //this._onPropertyChanged();
  },
  willDestroyElement() {
    this._super(...arguments);

    this._maskinput.destroy();
    this._maskinput = null;
  },
  //== Event Handler================================================
  actions: {
    selectedDatesChanged() {
      this._setDate(this._getPickerTypeDate(this.pickerType, this.get('_selectedDate'), this.get('_selectedTime')));
      if (this.isAutoClose === true && (this.pickerType === 'date' || this.pickerType === 'year' || this.pickerType === 'yearMonth')) {
        this.calendarClose();
      }
      Ember.Logger.log('_datePickerValue',typeof this.get('_datePickerValue'));
    },
    selectedTimeChanged() {
      this._setDate(this._getPickerTypeDate(this.pickerType, this.get('_selectedDate'), this.get('_selectedTime')));
    },
    timepadDoubleClick() {
      this.calendarClose();
    },
    calendarDoubleClick() {
      this.calendarClose();
    },
    onTextCancelAction() {
      if (!this._isDateInstance(this.get('selectedDate'))) {
        this._setDate(null);
      }
    },
    onTextCommitAction(e) {
      this._onTextChanged(e.text, e.value);
    },
    onMouseDoubleClickAction(e) {
      this._raiseEvents('mouseDoubleClick', { 'source': this, 'originalEvent': e });
    },
    onToggleAction() {
      if (this.get('isOpen') === true) {
        this.calendarClose();
      } else {
        this.calendarOpen();
      }
    },
    onKeydownAction(e) {
      this._raiseEvents('dateKeyDown', { 'source': this, 'originalEvent': e });
    },
    onFocusAction(e) {
      this.$().addClass('on');
      if (this.isGotFocusAutoSelect === true) {
        this.$(e.currentTarget).select();
      }
      e.stopPropagation();
      this._raiseEvents('focus', { 'source': this, 'originalEvent': e });
    },
    onBlurAction(e) {
      if(!this.get('isDestroyed')){
        this.$().removeClass('on');
        e.stopPropagation();
        this._raiseEvents('blur', { 'source': this, 'originalEvent': e });
      }
    },
    onTodayClickAction() {
      this._setToday();
    },
    onNowClickAction() {
      this._setNow();
    },
    onPreButtonClickAction() {
      const tmp = this.get('selectedDate');

      if (this._isDateInstance(tmp)) {
        switch (this.get('navigationMode')) {
          case 'year': this._setDate(new Date(tmp.setFullYear(tmp.getFullYear() + this.get('navigationInterval') * -1))); break;
          case 'month': this._setDate(new Date(tmp.setMonth(tmp.getMonth() + this.get('navigationInterval') * -1))); break;
          case 'date': this._setDate(new Date(tmp.setDate(tmp.getDate() + this.get('navigationInterval') * -1))); break;
          case 'hours': this._setDate(new Date(tmp.setHours(tmp.getHours() + this.get('navigationInterval') * -1))); break;
          case 'minutes': this._setDate(new Date(tmp.setMinutes(tmp.getMinutes() + this.get('navigationInterval') * -1))); break;
          case 'seconds': this._setDate(new Date(tmp.setSeconds(tmp.getSeconds() + this.get('navigationInterval') * -1))); break;
          case 'milliseconds': this._setDate(new Date(tmp.setMilliseconds(tmp.getMilliseconds() + this.get('navigationInterval') * -1))); break;
        }
      }
    },
    onNextButtonClickAction() {
      const tmp = this.get('selectedDate');

      if (this._isDateInstance(tmp)) {
        switch (this.get('navigationMode')) {
          case 'year': this._setDate(new Date(tmp.setFullYear(tmp.getFullYear() + this.get('navigationInterval')))); break;
          case 'month': this._setDate(new Date(tmp.setMonth(tmp.getMonth() + this.get('navigationInterval')))); break;
          case 'date': this._setDate(new Date(tmp.setDate(tmp.getDate() + this.get('navigationInterval')))); break;
          case 'hours': this._setDate(new Date(tmp.setHours(tmp.getHours() + this.get('navigationInterval')))); break;
          case 'minutes': this._setDate(new Date(tmp.setMinutes(tmp.getMinutes() + this.get('navigationInterval')))); break;
          case 'seconds': this._setDate(new Date(tmp.setSeconds(tmp.getSeconds() + this.get('navigationInterval')))); break;
          case 'milliseconds': this._setDate(new Date(tmp.setMilliseconds(tmp.getMilliseconds() + this.get('navigationInterval')))); break;
        }
      }
    },
  }
});