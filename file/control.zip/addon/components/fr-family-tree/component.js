import Ember from 'ember';
import layout from './template';
import GlobalServiceContainerMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';
import ContextMenuMixin from '../../mixins/contextmenu-mixin';

const { computed, guidFor } = Ember;

export default Ember.Component.extend(GlobalServiceContainerMixin, StatefulComponentMixin, ContextMenuMixin, {
  tagName: 'div',
  classNames: [ 'fr-family-tree' ],
  attributeBindings: [ '_style:style' ],
  layout,

  //public Properties

  itemsSource: null,
  width: null,
  height: null,

  _itemsSource: computed.alias('itemsSource').readOnly(),

  _treeGuid: computed(function () {
    return guidFor(this);
  }).readOnly(),

  _style: computed('width', 'height', function () {
    const width = this.get('width'), height = this.get('height');
    let _style = ``;
    if (!Ember.isNone(width)) {
      _style += `width: ${width}px;`;
    } else {
      _style += `width: 100%;`;
    }
    if (!Ember.isNone(height)) {
      _style += ` height: ${height}px;`;
    }
    return Ember.String.htmlSafe(_style);
  }).readOnly(),

  emptyProp: computed('_itemsSource.[]', function () {
    const _itemsSource = this.get('_itemsSource');
    d3.select(this.get('element')).select('svg').selectAll('*').remove();
    if (Ember.isArray(_itemsSource)) {
      _itemsSource.filterBy('classification', 'person').forEach(function (item) {
        this._createPerson(item);
      }.bind(this));
    }
    return null;
  }).readOnly(),

  onPropertyInit() {
    this._super(...arguments);
  },

  didInsertElement() {
    this._super(...arguments);
  },

  didRender() {
    this._super(...arguments);
  },

  willDestroyElement() {
    this._super(...arguments);
  },

  mouseDown(event) {
    const $person = this.$(event.target).closest('g.person');
    if ($person.length > 0) {
      let beforeX = event.clientX, beforeY = event.clientY, adjustX = 0, adjustY = 0;
      if (!$person.hasClass('active') && !event.ctrlKey) {
        d3.select(this.get('element')).select('svg').selectAll('g.person.active').each(function () {
          d3.select(this).attr('class', 'person');
        });
      }
      d3.selectAll($person).each(function () {
        d3.select(this).attr('class', 'person active');
      });
      Ember.$(document).on(`mousemove.fr-family-tree-${this.get('_treeGuid')}`, function (event) {
        const treeElement = this.get('element'), svgW = this.$().width(), svgH = this.$().height();
        let afterX = event.clientX - beforeX, afterY = event.clientY - beforeY, size = 0;
        beforeX = event.clientX; beforeY = event.clientY;
        d3.select(treeElement).select('svg').selectAll('g.person.active').each(function (d) {
          if ((d.x + 40 + afterX) > svgW) { afterX = svgW - (d.x + 40); }
          if ((d.x + afterX) < 0) { afterX = 0 - d.x; }
          if ((d.y + 40 + afterY) > svgH) { afterY = svgH - (d.y + 40); }
          if ((d.y + afterY) < 0) { afterY = 0 - d.y; }
          size++;
        });
        d3.select(treeElement).select('svg').selectAll('path.alignment').remove();
        d3.select(treeElement).select('svg').selectAll('g.person.active').each(function (d) {
          let moveX = d.x + afterX, moveY = d.y + afterY;
          if (size === 1) {
            adjustX = 0; adjustY = 0;
            d3.select(treeElement).select('svg').selectAll('g.person:not(.active)').each(function (q) {
              if (parseInt((q.x - moveX) / 15) === 0) {
                if (parseInt((q.x - moveX) / 5) === 0) {
                  adjustX = q.x - moveX;
                }
                d3.select(treeElement).select('svg').append('path').datum({ x1: q.x, y1: q.y, x2: (moveX  + adjustX), y2: (moveY  + adjustY) })
                .attr('class', 'alignment')
                .attr('d', function (r) { return `M ${r.x1} ${r.y1} L ${r.x1} ${r.y2}` })
                .attr('fill', 'none')
                .attr('stroke', 'red')
                .attr('stroke-width', function (r) { if (r.x1 === r.x2) return 2; else return 1; })
                .attr('stroke-dasharray', 5);
              }
              if (parseInt((q.y - moveY) / 15) === 0) {
                if (parseInt((q.y - moveY) / 5) === 0) {
                  adjustY = q.y - moveY;
                }
                d3.select(treeElement).select('svg').append('path').datum({ x1: q.x, y1: q.y, x2: (moveX  + adjustX), y2: (moveY  + adjustY) })
                .attr('class', 'alignment')
                .attr('d', function (r) { return `M ${r.x1} ${r.y1} L ${r.x2} ${r.y1}` })
                .attr('fill', 'none')
                .attr('stroke', 'red')
                .attr('stroke-width', function (r) { if (r.y1 === r.y2) return 2; else return 1; })
                .attr('stroke-dasharray', 5);
              }
            });
          }
          d3.select(this).attr('transform', `translate(${moveX + adjustX}, ${moveY + adjustY})`);
          Ember.set(d, 'x', moveX); Ember.set(d, 'y', moveY);
        });
      }.bind(this))
      .on(`mouseup.fr-family-tree-${this.get('_treeGuid')}`, function () {
        const treeElement = this.get('element');
        d3.select(treeElement).select('svg').selectAll('g.person.active').each(function (d) {
          Ember.set(d, 'x', d.x + adjustX); Ember.set(d, 'y', d.y + adjustY);
        });
        d3.select(treeElement).select('svg').selectAll('path.alignment').remove();
        beforeX = null; beforeY = null, adjustX = null, adjustY = null;
        Ember.$(document).off(`mousemove.fr-family-tree-${this.get('_treeGuid')}`).off(`mouseup.fr-family-tree-${this.get('_treeGuid')}`);
      }.bind(this));
    } else {
      let offsetX = event.offsetX, offsetY = event.offsetY, beforeX = event.clientX, beforeY = event.clientY;
      if (!event.ctrlKey) {
        d3.select(this.get('element')).select('svg').selectAll('g.person.active').each(function () {
          d3.select(this).attr('class', 'person');
        });
      }
      Ember.$(document).on(`mousemove.fr-family-tree-${this.get('_treeGuid')}`, function (event) {
        const treeElement = this.get('element');
        let afterX = event.clientX - beforeX, afterY = event.clientY - beforeY, datum = {
          x1: offsetX, x2: offsetX + afterX, y1: offsetY, y2: offsetY + afterY };
        if (event.shiftKey) {
          datum.x2 = offsetX + Math.min(afterX, afterY);
          datum.y2 = offsetY + Math.min(afterX, afterY);
        }
        d3.select(treeElement).select('svg').selectAll('path.selector').remove();
        d3.select(treeElement).select('svg').append('path').datum(datum)
        .attr('class', 'selector')
        .attr('d', function (d) { return `M ${d.x1} ${d.y1} L ${d.x2} ${d.y1} L ${d.x2} ${d.y2} L ${d.x1} ${d.y2} Z` })
        .attr('fill', 'none')
        .attr('stroke', 'black')
        .attr('stroke-dasharray', 5);
      }.bind(this))
      .on(`mouseup.fr-family-tree-${this.get('_treeGuid')}`, function () {
        const treeElement = this.get('element');
        d3.select(treeElement).select('svg').selectAll('path.selector').each(function (d) {
          d3.select(treeElement).select('svg').selectAll('g.person').each(function (q) {
            if (Math.min(d.x1, d.x2) < (q.x + 40) && Math.max(d.x1, d.x2) > q.x &&
            Math.min(d.y1, d.y2) < (q.y + 40) && Math.max(d.y1, d.y2) > q.y) {
              d3.select(this).attr('class', 'person active');
            }
          });
        });
        d3.select(treeElement).select('svg').selectAll('path.selector').remove();
        offsetX = null; offsetY = null; beforeX = null; beforeY = null;
        Ember.$(document).off(`mousemove.fr-family-tree-${this.get('_treeGuid')}`).off(`mouseup.fr-family-tree-${this.get('_treeGuid')}`);
      }.bind(this));
    }
  },

  _createPerson(d) {
    const person = d3.select(this.get('element')).select('svg').append('g').datum(d)
    .attr('class', 'person')
    .attr('pointer-events', 'all')
    .attr('transform', function (q) {
      return `translate(${q.x}, ${q.y})`;
    });
    switch (d.type) {
      case 'mail': this._addMail(person); break;
      case 'femail': this._addFemail(person); break;
    }
    this._addActiveZone(person, [ { x: 0, y: 0 }, { x: 18, y: 0 },
      { x: 36, y: 0 }, { x: 0, y: 18 }, { x: 36, y: 18 },
      { x: 0, y: 36 }, { x: 18, y: 36 }, { x: 36, y: 36 } ]);
  },

  _addMail(person) {
    person.append('rect')
    .attr('x', 2)
    .attr('y', 2)
    .attr('width', 36)
    .attr('height', 36)
    .attr('fill', 'none')
    .attr('stroke', 'black')
    .attr('stroke-width', 1);
  },

  _addFemail(person) {
    person.append('circle')
    .attr('cx', 20)
    .attr('cy', 20)
    .attr('r', 18)
    .attr('fill', 'none')
    .attr('stroke', 'black')
    .attr('stroke-width', 1);
  },

  _addActiveZone(person, offset) {
    person.append('rect')
    .attr('class', 'active-zone')
    .attr('x', 2)
    .attr('y', 2)
    .attr('width', 36)
    .attr('height', 36)
    .attr('fill', 'none')
    .attr('stroke', 'black')
    .attr('stroke-dasharray', 1);

    for (let i = 0; i < offset.length; i++) {
      person.append('rect')
      .attr('class', 'active-zone')
      .attr('x', offset[i].x)
      .attr('y', offset[i].y)
      .attr('width', 4)
      .attr('height', 4)
      .attr('fill', 'none')
      .attr('stroke', 'black');
    }
  },

  actions: {

  },
});