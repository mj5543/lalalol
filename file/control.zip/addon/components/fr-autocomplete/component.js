import Ember from 'ember';
import ComboBox from '../fr-combobox/component';
import ContextMenuMixin from '../../mixins/contextmenu-mixin';

// AutoComplete
export default ComboBox.extend(ContextMenuMixin, {
  classNames: ['fr-autocomplete'],
  layout: Ember.computed(function () {

    let _itemTemplate = this.get('itemTemplate');
    let _headerTemplate = this.get('headerTemplate');

    if (Ember.isEmpty(_itemTemplate)) {
      _itemTemplate = "<span class='alink'>{{fr-format-result-helper (get item displayMemberPath) text}}</span>";
    }

    if (Ember.isEmpty(_headerTemplate)) {
      if (this.get('useSelectedValue') === true) {
        _headerTemplate = "{{ watchSelectedValue }}";
      } else {
        _headerTemplate = "{{ watchSelectedItem }}";
      }
    }

    const template = `<div class='inp-txt{{if isDropdownbuttonVisible ' inp-auto'}}{{if clearButtonVisibility ' focus'}}'><input type='text' tabindex={{tabindex}} value='${_headerTemplate}' placeholder='{{placeholder}}' class='fr-combobox-input' disabled={{disabled}} /><button class='del' type='button' onclick={{action 'textClearAction'}}><span class='blind'>delete</span></button><button type='button' onclick={{action 'toggleAction'}}><span class='blind'>down</span></button></div>
                    {{#if isOpen}}
                      {{#fr-wormhole to=_destinationElementId}}
                        {{#fr-positioned-container targetElement=_targetElement targetAttachment='bottom left' attachment='top left'}}
                          {{#if useItemsPanelTemplate}}
                            {{yield (hash itemsPanelTemplate=(component 'fr-combobox-itemspanel' itemsSource=watchItemsSource tabindex='-1' classNames='list-box scrollbar-macosx' owner=this scrollIndex=_scrollIndex ) )}}
                          {{else}}
                            {{#fr-combobox-itemspanel isAutoScroll=true isDesignScroll=true tabindex='-1' classNames='list-box scrollbar-macosx' owner=this scrollIndex=_scrollIndex}}
                              <ul>
                              {{#each watchItemsSource as |item index|}}
                                <li data-val='{{get item selectedValuePath}}' onclick={{action 'onSelectAction' item }} class='fr-combobox-option'>
                                  ${_itemTemplate}
                                </li>
                              {{/each}}
                              </ul>
                            {{/fr-combobox-itemspanel}}
                          {{/if}}
                        {{/fr-positioned-container}}
                      {{/fr-wormhole}}
                    {{/if}}`;

    return Ember.HTMLBars.compile(template);
  }),
  autoclear: true,
  clearButtonVisibility: false,
  searchItems: null,  
  editable: true,
  minChars: 2,
  isDropdownbuttonVisible: true,
  text: '',
  placeholder: null,
  change: null,
  textCleared: null,
  textCommit: null,
  isFullTextSearch: false,
  watchItemsSource: Ember.computed('itemsSource.[]', function () {

    const _searchWord = this.get('text');
    const _source = this.get('itemsSource');
    const _searchItems = this.get('searchItems');

    if (this.get('isFullTextSearch') === false) {
      return _source;
    }

    const _tmp = Ember.A([]);

    if (_searchWord.length < this.minChars) {
      return _source;
    }

    if (!Ember.isEmpty(_source)) {
      for (let i = 0; i <= _source.length - 1; i++) {
        const _original = _source.objectAt(i);

        if(!Ember.isEmpty(_searchItems)) {
          _searchItems.some(path => {
            const _originaltext = Ember.get(_original, path);
  
            if(Ember.isEmpty(_originaltext)){
              return true;
            }

            if (_originaltext.toUpperCase().indexOf(_searchWord) > -1) {
              _tmp.pushObject(_original);
              return true;
            }
          });
        } else {
          let _originaltext = Ember.get(_original, this.displayMemberPath);

          if(Ember.isEmpty(_originaltext)){
            _originaltext = '';
          }

          if (_originaltext.toUpperCase().indexOf(_searchWord) > -1) {
            _tmp.pushObject(_original);
          }
        }
      }
    }

    return _tmp;
  }).readOnly(),
  // == Private Methods  ======================================================
  _onfocus() {
    //ignored
  },
  _onblur(e) {

    if (this.$(e.relatedTarget).is('.fr-combobox-options') === false) {
      this._onDropDownClosed();
    }

    if (this.autoclear === false || Ember.isEmpty(this.get('itemsSource'))) {
      return false;
    }

    const item = this.itemsSource.filterBy(this.displayMemberPath, this.$('.fr-combobox-input').val());

    if (Ember.isEmpty(item)) {
      this.set('selectedValue', null);
      this.set('selectedItem', null);
      this.$('.fr-combobox-input').val('');
    }
  },
  _onTextClear(e) {
    this.set('selectedValue', null);
    this.set('selectedItem', null);
    this.$('.fr-combobox-input').val('');
    this._inputChange(this.$('.fr-combobox-input'));
    this._raiseEvents('textCleared', { 'source': this, 'originalEvent': e });
  },
  _onTextCommit(e) {

    const _text = this.$('.fr-combobox-input').val().toUpperCase();
    const _source = this.get('itemsSource');

    for (let i = 0; i <= _source.length - 1; i++) {
      const _original = _source.objectAt(i);
      const _originaltext = Ember.get(_original, this.displayMemberPath);

      if (_originaltext.toUpperCase() === _text) {
        this.set('selectedValue', Ember.get(_original, this.selectedValuePath));
        this.set('selectedItem', _original);
        this._onDropDownClosed();

        this._raiseEvents('textCommit', { 'source': this, 'originalEvent': e });

        return false;
      }
    }
  },
  _onValueUpdate(newobject) {

    if (this.useSelectedValue === true) {
      if (this.get('selectedValue') === Ember.get(newobject, this.selectedValuePath)) {
        this.set('selectedValue', null);
      }

    } else {

      if (this.get('selectedItem') === newobject) {
        this.set('selectedItem', null);
      }
    }

    this._onDropDownClosed();

    Ember.run.later(this, function () {
      if (this.useSelectedValue === true) {
        this.set('selectedValue', Ember.get(newobject, this.selectedValuePath));
      } else {
        this.set('selectedItem', newobject);
      }
      this._raiseEvents('selectedChanged', { 'source': this, 'data': newobject });
    }.bind(this));

  },
  _inputChange(e) {

    const _searchWord = this.$(e.target).val().toUpperCase();

    this.set('text', _searchWord);

    if (_searchWord.length < this.minChars) {
      return;
    } else if (this.get('isOpen') === false) {
      this._onDropDownOpened();
    }
    this.isTyping = true;
    this.searchWord = this.$(e.target).val();
    const arg = { 'source': this, 'originalEvent': e, 'cancel': false, 'text': this.$(e.target).val(), 'itemsSource': null };

    this._raiseEvents('change', arg);

    if (arg.cancel === true) {
      if (!Ember.isNone(arg.itemsSource)) {
        this.set('itemsSource', arg.itemsSource);
      }

      return;
    }

    if (_searchWord.length < this.minChars) {
      this.set('isOpen', false);

      return;
    } else if (this.get('isOpen') === false) {
      this._onDropDownOpened();
    }

    const _source = this.get('itemsSource');

    this.set('itemsSource', Ember.A([]));
    this.set('itemsSource', _source);

    if (_searchWord.length === 0) {
      this.set('isOpen', false);

      return;
    }
  },
  didInsertElement() {
    this._super(...arguments);

    this.set('_targetElement', this.$().get(0));

    this.$('.fr-combobox-input')
      .on('focus', this._onfocus.bind(this))
      .on('blur', this._onblur.bind(this))
      .on('keydown', this._onkeydown.bind(this))
      .on('input propertychange', this._inputChange.bind(this));

    this.$().on('change', function (e) {
      e.stopImmediatePropagation();
      e.preventDefault();
      e.stopPropagation();
    })
      .removeClass('fr-combobox')
      .attr('tabindex', -1);
  },
  willDestroyElement() {
    this._super(...arguments);
    this.$('.fr-combobox-input')
      .off('focus')
      .off('blur')
      .off('keydown')
      .off("input propertychange");
    this.$().next().off('mousedown');
    this.$().off('change');
  },
  actions: {
    toggleAction() {
      this._onDropDownToggle();
    },
    textClearAction() {
      this._onTextClear();
    },
  }
});
