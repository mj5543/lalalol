import Ember from 'ember';
import layout from './template';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

const { computed } = Ember;

export default Ember.Component.extend(StatefulComponentMixin, {
  layout,
  tagName: 'tbody',
  _notHasFrozen: computed.not('_hasFrozen').readOnly(),
  _frozenTableOrNotHasFrozen: computed.or('_frozenTable', '_notHasFrozen').readOnly(),
  _notFrozenTable: computed.not('_frozenTable').readOnly(),
  _rowSelectionType: computed.equal('selectionType', 'row').readOnly(),
  _checkboxSelectionType: computed.equal('selectionType', 'checkbox').readOnly(),
  _itemSelectionType: computed.or('_rowSelectionType', '_checkboxSelectionType').readOnly(),
  _cellSelectionType: computed.equal('selectionType', 'cell').readOnly(),
  _handleColumnsLength: computed('_frozenTableOrNotHasFrozen', 'selectionType', 'showRowIndex', 'enableReorderRow', 'enableDetailRow', function () {
    return this.get('_frozenTableOrNotHasFrozen') ? (this.get('selectionType') === 'checkbox' ? 1 : 0) + (this.get('showRowIndex') ? 1 : 0) +
    (this.get('enableReorderRow') ? 1 : 0) + (this.get('enableDetailRow') ? 1 : 0) : 0;
  }).readOnly(),
  _templateColumnsLength: computed('_bindingColumns.[]', function () {
    return this.get('_bindingColumns.length');
  }).readOnly(),
  actions: {
    rowMouseEnter(event) {
      this.$().closest('div.c-grid-body-container').find('> div.lock > table > tbody, > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx > table > tbody')
        .children(`tr[data-body-row-index=${this.$(event.currentTarget).attr('data-body-row-index')}]`).addClass('hover');
    },
    rowMouseLeave() {
      this.$().closest('div.c-grid-body-container').find('> div.lock > table > tbody, > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx > table > tbody')
        .children('tr[data-body-row-index]').removeClass('hover');
    },
  },
});