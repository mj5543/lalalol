import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';

export default Control.extend({
  layout,
  tagName: 'span',
  classNames: ['c-switch'],
  attributeBindings: ['tabindex'],
  tabindex: -1,
  checked: false,
  onChanged: null,

  _switchGuid: Ember.computed.readOnly('componentGuid'),
  click(event) {
    if (this.$(event.target).is(':checkbox')) {
      this._raiseEvents('onClick', {
        source: this,
        originalEvent: event
      });
    }
  },
  actions: {
    change(event) {
      this.set('checked', this.$(event.target).is(':checked'));
      this._raiseEvents('onChanged', {
        source: this,
        originalEvent: event,
        checked: this.get('checked')
      });
    },
  },
});