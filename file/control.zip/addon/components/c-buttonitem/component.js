import layout from './template';
import Control from '../c-control/component';
// import ToolTipMixin from '../../mixins/tooltip-mixin';

export default Control.extend({
  layout,
  tagName: 'li',
  classNames: ['c-buttonitem'],
  classNameBindings: ['type'],
  attributeBindings: ['notAccessable:disabled'],
  //public properties
  style: null,
  title: null,
  type: 'event',
  enableAutoClose: false,
  content: null,
  tabindex: null,
  disabled: false,
  //public events
  onLoaded: null,
  onUnload: null,
  onClick: null,

  click(event) {
    if (this.get('enableAutoClose')) {
      this.set('isOpen', false);
    }
    this._raiseEvents('onClick', {
      source: this,
      originalEvent: event
    });
  },
});