import Ember from 'ember';
import layout from './template';
import ValidationControl from '../c-validationcontrol/component';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

export default ValidationControl.extend(StatefulComponentMixin, {
  layout,
  tagName: 'div',
  classNames: ['c-listbox'],
  //public properties
  style: null,
  itemsSource: null,
  displayMemberPath: null,
  selectedValuePath: null,
  selectionMode: 'single',
  selectedValue: null,
  selectedItem: null,
  enableKeepSelectedValue: false,
  tabindex: -1,
  disabled: false,
  readOnly: false,
  required: false,
  showValidationSuccess: false,
  externalErrorMessage: null,
  validationRules: null,
  //public methods
  selectItem(itemParam) {
    let itemIndex = null;
    if(typeof itemParam === 'object') {
      itemIndex = this._getItemIndex(itemParam);
    }else if(typeof itemParam === 'number') {
      itemIndex = itemParam;
    }else {
      itemIndex = -1;
    }
    this._selectItem(itemIndex);
    // this._selectItem(typeof itemParam === 'object' ? this._getItemIndex(itemParam) :
    //   typeof itemParam === 'number' ? itemParam : -1);
  },
  deselectItem(itemParam) {
    let itemIndex = null;
    if(typeof itemParam === 'object') {
      itemIndex = this._getItemIndex(itemParam);
    }else if(typeof itemParam === 'number') {
      itemIndex = itemParam;
    }else {
      itemIndex = -1;
    }
    this._deselectItem(itemIndex);
    // this._deselectItem(typeof itemParam === 'object' ? this._getItemIndex(itemParam) :
    //   typeof itemParam === 'number' ? itemParam : -1);
  },
  selectAll() {
    this._selectAll();
  },
  deselectAll() {
    this._deselectAll();
  },
  //public events
  onLoaded: null,
  onUnload: null,
  onClick: null,
  onFocusIn: null,
  onFocusOut: null,
  onKeyPress: null,
  onKeyUp: null,
  onKeyDown: null,
  onChanged: null,
  onSelectionChanged: null,
  //public readonly properties
  selectedItems: Ember.computed.readOnly('_sortedSelectedItems'),

  _singleSelectionMode: Ember.computed.equal('selectionMode', 'single'),
  _multipleSelectionMode: Ember.computed.equal('selectionMode', 'multiple'),
  _isAttrsSelectedProperty: Ember.computed.or('_isAttrsSelectedItem', '_isAttrsSelectedValue').readOnly(),
  _isAttrsSelectedItem: Ember.computed(function () {
    return !Ember.isNone(this.attrs.selectedItem);
  }).readOnly(),
  _isAttrsSelectedValue: Ember.computed(function () {
    return !Ember.isNone(this.attrs.selectedValue);
  }).readOnly(),
  _computedSelectedItems: Ember.computed('_selectedItems.[]', function () {
    const _computedSelectedItems = this.get('_selectedItems').map(function (data) {
      return data;
    });

    Ember.run.once(this, '_selectedItemsChange');

    return _computedSelectedItems;
  }).readOnly(),
  _sortedSelectedItems: Ember.computed('_computedSelectedItems.[]', '_itemsSource.[]', function () {
    const _computedSelectedItems = this.get('_computedSelectedItems'), _itemsSource = this.get('_itemsSource'), _sortedSelectedItems = Ember.A();
    let index = -1;

    _computedSelectedItems.forEach(function (item) {
      index = _itemsSource.indexOf(item);
      if (_itemsSource.indexOf(Ember.get(_sortedSelectedItems, 'lastObject')) < index) {
        _sortedSelectedItems.addObject(item);
      } else {
        for (let i = 0; i < _sortedSelectedItems.length; i++) {
          if (index < _itemsSource.indexOf(_sortedSelectedItems[i])) {
            _sortedSelectedItems.insertAt(i, item);
            break;
          }
        }
      }
    });

    return _sortedSelectedItems;
  }).readOnly(),
  _itemsSource: Ember.computed('itemsSource.[]', function () {
    let itemsSource = this.get('itemsSource');

    if (!Ember.isArray(itemsSource)) {
      itemsSource = Ember.A();
    }
    Ember.run.once(this, '_itemsSourceChange');

    return itemsSource;
  }).readOnly(),
  _observedProperty1: Ember.computed('selectedItem', 'selectedValue', function () {
    const _itemsSource = this.get('_itemsSource'), lastSelectedItem = this.get('_selectedItems.lastObject'), _isAttrsSelectedValue = this.get('_isAttrsSelectedValue'), selectedValuePath = this.get('selectedValuePath'),
      selectedItem = _isAttrsSelectedValue ? _itemsSource.findBy(selectedValuePath, this.get('selectedValue')) : this.get('selectedItem');

    if ((lastSelectedItem && selectedItem && lastSelectedItem !== selectedItem) || (!lastSelectedItem && selectedItem)) {
      this._selectItem(_itemsSource.indexOf(selectedItem));
    } else if (lastSelectedItem && !selectedItem) {
      this._deselectItem(_itemsSource.indexOf(lastSelectedItem));
    }
  }).readOnly(),
  _observedProperty2: Ember.computed('selectedItem', function () {
    Ember.run.once(this, '_syncSelectedValue');
  }).readOnly(),
  _observedProperty3: Ember.computed('selectedValue', 'selectedValuePath', function () {
    if (!Ember.isNone(this.get('selectedValuePath'))) {
      Ember.run.once(this, '_syncSelectedItem');
    }
  }).readOnly(),
  onPropertyInit() {
    this._super(...arguments);
    this.setStateProperties([ '_selectedItems' ]);
    if (!this.hasState()) {
      this.set('_selectedItems', Ember.A());
    }
  },
  didInsertElement() {
    this._super(...arguments);
    this.$('.scrollbar-macosx:not(.scroll-content)').scrollbar();
  },
  willDestroyElement() {
    this.$('.scrollbar-macosx').scrollbar('destroy');
    this._super(...arguments);
  },
  click(event) {
    const $target = this.$(event.target).closest('li[data-item]');
    let item = null;

    if ($target.length > 0) {
      item = this.get('_itemsSource').objectAt(parseInt($target.attr('data-item')));
    }
    this._raiseEvents('onClick', {
      source: this,
      originalEvent: event,
      item: item
    });
  },
  doubleClick(event) {
    const $target = this.$(event.target).closest('li[data-item]');
    let item = null;

    if ($target.length > 0) {
      item = this.get('_itemsSource').objectAt(parseInt($target.attr('data-item')));
    }
    this._raiseEvents('onDoubleClick', {
      source: this,
      originalEvent: event,
      item: item
    });
  },
  focusIn(event) {
    this._raiseEvents('onFocusIn', {
      source: this,
      originalEvent: event
    });
  },
  focusOut(event) {
    this._raiseEvents('onFocusOut', {
      source: this,
      originalEvent: event
    });
  },
  keyPress(event) {
    this._raiseEvents('onKeyPress', {
      source: this,
      originalEvent: event
    });
  },
  keyUp(event) {
    this._raiseEvents('onKeyUp', {
      source: this,
      originalEvent: event
    });
  },
  keyDown(event) {
    this._raiseEvents('onKeyDown', {
      source: this,
      originalEvent: event
    });
  },
  _itemsSourceChange() {
    const _itemsSource = this.get('_itemsSource');

    const enableKeepSelectedValue = this.get('enableKeepSelectedValue'),
      _selectedItems = this.get('_selectedItems'), selectedItemsGarbage = Ember.A();

    if (enableKeepSelectedValue) {
      const selectedItem = _itemsSource.findBy(this.get('selectedValuePath'), this.get('selectedValue'));

      if (!Ember.isNone(selectedItem)) {
        if (_selectedItems.includes(selectedItem)) {
          selectedItemsGarbage.addObjects(_selectedItems);
          selectedItemsGarbage.removeObject(selectedItem);
          if (!Ember.isEmpty(selectedItemsGarbage)) {
            _selectedItems.removeObjects(selectedItemsGarbage);
            Ember.run.once(this, '_selectionChange', true);
          }
        } else {
          _selectedItems.clear();
          _selectedItems.addObject(selectedItem);
          Ember.run.once(this, '_selectionChange', true);
        }
      } else if (!Ember.isEmpty(_selectedItems)) {
        _selectedItems.clear();
        Ember.run.once(this, '_selectionChange', true);
      }
    } else if (Ember.isEmpty(_itemsSource) && !Ember.isEmpty(_selectedItems)) {
      _selectedItems.clear();
      Ember.run.once(this, '_selectionChange');
    } else {
      _selectedItems.forEach(function (item) {
        if (!_itemsSource.includes(item)) {
          selectedItemsGarbage.addObject(item);
        }
      });
      if (!Ember.isEmpty(selectedItemsGarbage)) {
        _selectedItems.removeObjects(selectedItemsGarbage);
        Ember.run.once(this, '_selectionChange');
      }
    }
  },
  _syncSelectedItem() {
    const selectedValue = this.get('selectedValue'), selectedValuePath = this.get('selectedValuePath');

    if (!Ember.isNone(selectedValue) && !Ember.isNone(selectedValuePath)) {
      const selectedItem = this.get('_itemsSource').findBy(selectedValuePath, selectedValue);

      this.set('selectedItem', !Ember.isNone(selectedItem) ? selectedItem : null);
    } else if (!Ember.isNone(this.get('selectedItem'))) {
      this.set('selectedItem', null);
    }
  },
  _syncSelectedValue() {
    const enableKeepSelectedValue = this.get('enableKeepSelectedValue');

    if (!enableKeepSelectedValue) {
      const selectedItem = this.get('selectedItem'), selectedValuePath = this.get('selectedValuePath');

      if (!Ember.isNone(selectedItem) && !Ember.isNone(selectedValuePath)) {
        this.set('selectedValue', Ember.get(selectedItem, selectedValuePath));
      } else if (!Ember.isNone(this.get('selectedValue'))) {
        this.set('selectedValue', null);
      }
    }
  },
  _getItemIndex(item) {
    return this.get('_itemsSource').indexOf(item);
  },
  _selectItem(index) {
    const _itemsSource = this.get('_itemsSource'), _selectedItems = this.get('_selectedItems'), item = _itemsSource.objectAt(index);

    if (!Ember.isNone(item) && !_selectedItems.includes(item)) {
      if (this.get('_singleSelectionMode')) {
        _selectedItems.clear();
      }
      _selectedItems.addObject(item);
      Ember.run.once(this, '_selectionChange');
    }
  },
  _deselectItem(index) {
    const _itemsSource = this.get('_itemsSource'), _selectedItems = this.get('_selectedItems'), item = _itemsSource.objectAt(index);

    if (!Ember.isNone(item) && _selectedItems.includes(item)) {
      _selectedItems.removeObject(item);
      Ember.run.once(this, '_selectionChange');
    }
  },
  _selectAll() {
    if (this.get('_multipleSelectionMode')) {
      const _itemsSource = this.get('_itemsSource'), _selectedItems = this.get('_selectedItems');

      if (_itemsSource.length !== _selectedItems.length) {
        _selectedItems.clear();
        _selectedItems.addObjects(_itemsSource);
        Ember.run.once(this, '_selectionChange');
      }
    }
  },
  _deselectAll() {
    const _selectedItems = this.get('_selectedItems');

    if (!Ember.isEmpty(_selectedItems)) {
      _selectedItems.clear();
      Ember.run.once(this, '_selectionChange');
    }
  },
  _selectionChange(keepSelectedValue) {
    const lastSelectedItem = this.get('_selectedItems.lastObject'), selectedItem = this.get('selectedItem'), selectedValuePath = this.get('selectedValuePath'),
    lastSelectedValue = !Ember.isNone(selectedValuePath) && lastSelectedItem ? Ember.get(lastSelectedItem, selectedValuePath) : null, selectedValue = this.get('selectedValue');

    if ((selectedItem && lastSelectedItem && selectedItem !== lastSelectedItem) || (!selectedItem && lastSelectedItem)) {
      this.set('selectedItem', lastSelectedItem);
    } else if (selectedItem && !lastSelectedItem) {
      this.set('selectedItem', null);
    }
    if (!keepSelectedValue) {
      if ((!Ember.isNone(selectedValue) && !Ember.isNone(lastSelectedValue) && selectedValue !== lastSelectedValue) || (Ember.isNone(selectedValue) && !Ember.isNone(lastSelectedValue))) {
        this.set('selectedValue', lastSelectedValue);
      } else if (!Ember.isNone(selectedValue) && Ember.isNone(lastSelectedValue)) {
        this.set('selectedValue', null);
      }
    }
    this._raiseEvents('onSelectionChanged', {
      source: this,
      selectedItems: this.get('_selectedItems')
    });
  },
  _selectedItemsChange() {
    this.set('_internalValue', !Ember.isEmpty(this.get('_selectedItems')));
  },
  actions: {
    itemClick(item, event) {
      const selectionMode = this.get('selectionMode'), _selectedItems = this.get('_selectedItems');
      let changed = false, selected = true;

      if (selectionMode === 'single') {
        if (2 <= _selectedItems.length || (!Ember.isNone(item) && !_selectedItems.includes(item))) {
          _selectedItems.clear();
          _selectedItems.addObject(item);
          changed = true;
        }
      } else if (selectionMode === 'multiple') {
        if (_selectedItems.includes(item)) {
          _selectedItems.removeObject(item);
          changed = true;
          selected = false;
        } else {
          _selectedItems.addObject(item);
          changed = true;
        }
      }
      if (changed) {
        Ember.run.once(this, '_selectionChange');
        this._raiseEvents('onChanged', {
          source: this,
          originalEvent: event,
          item: item,
          selected: selected,
          selectedItems: this.get('_selectedItems')
        });
      }
    },
  },
});