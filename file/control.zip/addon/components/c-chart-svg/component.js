import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';
import GlobalServiceContainerMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

export default Control.extend(GlobalServiceContainerMixin, StatefulComponentMixin, {
  layout,

  tagName: 'svg',
  attributeBindings: ['width', 'height'],
  classNames: ['c-chart-svg'],

  actionMode: null,
  addSeries: null,
  chartData: null,
  reload: null,
  height: null,
  removeSeriesNo: null,
  removeSeriesSet: null,
  trace: null,
  width: null,

  _addSymbolSize: null,
  _brush: null,
  _clickedLegendRect: null,
  // 현재 활성화된 y 축
  _currentYAxis: null,
  // 차트 데이터의 기본 y 축
  _defaultYAxis: null,
   // 그룹 레전 일 경우에 그룹명까지 포함된 데이터
  _groupLegend: null,
  _groupLegendWidth: null,
  _isCollapsed: null,
  // json 데이터 평가 결과
  _isValidData: null,
  _lineLeading: null,
  _maxX: null,
  _maxY: null,
  _miniXScale: null,
  _minX: null,
  _minY: null,
  _onlyOne: null,
  _parentType: null,
  _postfixFrom: null,
  _postfixMax: null,
  _postfixMin: null,
  _postfixTo: null,
  _rect: null,
  _selectedLegendRect: null,
  _selectedLegendRectForNormal: null,
  _selectedLegendRectForYAxis: null,
  _selectedLegendSymbol: null,
  _symbolMulple: null,
  _tickAndFormat: null,
  _violateProperty: null,
  _xAxis: null,
  _xScale: null,
  _yAxis: null,
  _yScale: null,
  _zoom: null,
  _setting: null,
  _ccSeries: null,
  _browserType: null,
  _hasLoaded: false,
  _oldChartData: null,
  _innerWidth: null,
  _isMouseMove: null,
  _chartPaddingCollapse: null,
  _chartPaddingExpand: null,
  _showLegend: Ember.computed.alias('showLegend').readOnly(),
  _offset: Ember.computed('offset', function() {
    return !Ember.isEmpty(this.get('offset')) ? this.get('offset') : 20;
  }).readOnly(),
  _scalePoint: Ember.computed.alias('scalePoint').readOnly(),
  _chartData: Ember.computed('chartData', function() {
    const dataset = this.get('chartData');
    // isSortedData 여부 체크 후, false면 타입별로 데이터 정렬
    if (dataset) {
      const isSortedData = dataset.isSortedData;
      if (!isSortedData) {
        for (const series of dataset.series) {
          let aAxis = null, bAxis = null;
          const seq = series.config.xAxisProperty;
          const position = series.config.yAxisPosition;
          for (const data of series.data) {
            if (typeof data[seq] === 'string') {
              return dataset;
            }
          }
          if (!position) {
            series.config.yAxisPosition = 1;
          }
          series.data.sort((a, b) => {
            if (dataset.isTimeXAxis) {
              aAxis = this._convertDateFormat(a[seq]);
              bAxis = this._convertDateFormat(b[seq]);
            } else {
              if (typeof a[seq] === 'string' && typeof b[seq] === 'string') {
                aAxis = a[seq].toUpperCase();
                bAxis = b[seq].toUpperCase();
              } else {
                aAxis = a[seq]; bAxis = b[seq];
              }
            }
            return +(aAxis > bAxis) || +(aAxis === bAxis) - 1;
          });
        }
        console.log('dataset', dataset);
        return dataset;
      }
      return dataset;
    }
  }).readOnly(),
  _reload: Ember.computed.alias('reload').readOnly(),
  _trace: Ember.computed.alias('trace').readOnly(),
  _width: Ember.computed.alias('width').readOnly(),
  _innerWidth: Ember.computed('width', function() {
    return this.get('width') - this.get('_settingPaddingLeft') - this.get('_settingPaddingRight')
  }).readOnly(),
  _height: Ember.computed('height', '_setting', function() {
    return this.get('height') - this.get('_settingPaddingBottom');
  }),
  _changedData: Ember.computed('actionMode', function() {
    if(Ember.isEmpty(this.get('actionMode'))) {
      return false;
    } else {
      return true;
    }
  }),

  _hasSeries: Ember.computed('_chartData', function() {
    let result = false;
    const data = this.get('_chartData');
    const zero = 0;

    if(!Ember.isEmpty(data) && data.series.length > zero) {
      result = true;
    }

    return result;
  }),
  _isTrendChart: Ember.computed('_chartData', function() {
    if(Ember.isEmpty(this.get('_chartData'))) {
      return false;
    }
    return false;
  }),
  _settingPaddingTop: Ember.computed('_setting', function() {
    return this.get('_setting').paddingTop;
  }),
  _settingPaddingRight: Ember.computed('_setting', function() {
    return this.get('_setting').paddingRight;
  }),
  _settingPaddingLeft: Ember.computed('_setting', function() {
    return this.get('_setting').paddingLeft;
  }),
  _settingPaddingBottom: Ember.computed('_setting', function() {
    return this.get('_setting').paddingBottom;
  }),
  _settingNormalOpacity: Ember.computed('_setting', function() {
    return this.get('_setting').normalOpacity;
  }),
  _settingDarkOpacity: Ember.computed('_setting', function() {
    return this.get('_setting').darkOpacity;
  }),
  _settingTransparentOpacity: Ember.computed('_setting', function() {
    return this.get('_setting').transparentOpacity;
  }),
  _settingGlyphiconPrefix: Ember.computed('_setting', function() {
    return this.get('_setting').glyphiconPrefix;
  }),

  // legend 에 표시하지 않는 옵션 적용
  _filteringChartData: Ember.computed('_chartData.series.[]', function() {
    const data = this.get('_chartData');
    console.log('_chartData',data);
    const one = 1;
    const zero = 0;

    if(Ember.isEmpty(data)) {
      return data;
    }

    const temp = Ember.$.extend(true, {}, data);
    let noDisplayInLegend;

    for(let i = temp.series.length - one; i >= zero ; i--) {
      noDisplayInLegend = temp.series[i].config.noDisplayInLegend;

      if(Ember.isEmpty(noDisplayInLegend)) {
        continue;
      }

      if(noDisplayInLegend === true) {
        temp.series.removeAt(i);
      }
    }
    return temp;
  }),

  onPropertyInit() {
    this._super(...arguments);
    this._logTrace('c-chart.onPropertyInit()');

    this.setStateProperties([ 'actionMode', 'addSeries', 'chartData', 'reload', 'height',
      'removeSeriesNo', 'trace', 'width',
      '_addSymbolSize', '_brush', '_clickedLegendRect', '_currentYAxis',
      '_defaultYAxis','_groupLegend', '_groupLegendWidth',
      '_isCollapsed', '_isValidData', '_lineLeading', '_maxX',
      '_maxY', '_miniXScale', '_minX', '_minY',
      '_onlyOne', '_parentType', '_postfixFrom', '_postfixMax', '_postfixMin',
      '_postfixTo', '_rect', '_selectedLegendRect', '_selectedLegendRectForNormal','_selectedLegendRectForYAxis', '_selectedLegendSymbol',
      '_symbolMulple', '_tickAndFormat', '_violateProperty', '_xAxis',
      '_xScale', '_yAxis', '_yScale',
      '_zoom', '_setting', '_ccSeries', '_browserType'
    ]);

    this._logTrace('c-chart.onPropertyInit().this.hasState() = ' + this.hasState());

    //const one = 1;
    const ten = 10;
    const groupLegendWidth = 150;

    if (!this.hasState()) {
      this.set('reload', true);
      this.set('scaleBand', false);
      this.set('showLegend', true);
      this.set('_addSymbolSize', ten);
      this.set('_clickedLegendRect', false);
      this.set('_groupLegendWidth', groupLegendWidth);
      this.set('_isCollapsed', true);
      this.set('_isValidData', true);
      this.set('_lineLeading', ten);
      this.set('_onlyOne', false);
      this.set('_parentType', 'chart');
      this.set('_postfixFrom', 'From');
      this.set('_postfixMax', 'Max');
      this.set('_postfixMin', 'Min');
      this.set('_postfixTo', 'To');
      this.set('_selectedLegendRect', Ember.A());
      this.set('_selectedLegendRectForNormal', Ember.A());
      this.set('_selectedLegendRectForYAxis', Ember.A());
      this.set('_selectedLegendSymbol', Ember.A());
      this.set('_symbolMulple', ten);
      this.set('_chartPaddingCollapse',  80),
      this.set('_chartPaddingExpand', 160),
      this.set('_setting', {
        paddingTop: 10,
        paddingRight: this.get('_chartPaddingCollapse'),
        paddingLeft: this.get('_chartPaddingExpand'),
        paddingBottom: 50,
        normalOpacity: 1,
        darkOpacity: 0.9,
        transparentOpacity: 0.3,
        glyphiconPrefix: 'material-icons'
      });
      this.set('_browserType', this._getBrowserType());
      this.set('_isMouseMove', false);

      const tickFormat = [];
      let item;

      item = {};
      item.type = 'month';
      item.ticks = d3.timeMonth;
      // 2017 Jan
      // item.tickFormat = d3.timeParse('%Y %b');
      item.tickFormat = d3.timeParse('%Y %b');
      tickFormat.pushObject(item);

      item = {};
      item.type = 'week';
      item.ticks = d3.timeWeek;
      // 17 Jan 9
      item.tickFormat = d3.timeParse('%y %b %e');
      tickFormat.pushObject(item);

      item = {};
      item.type = 'day';
      item.ticks = d3.timeDay;
      // Jan 3
      item.tickFormat = d3.timeParse('%b %e');
      tickFormat.pushObject(item);

      item = {};
      item.type = 'hour';
      item.ticks = d3.timeHour;
      // 7 PM 3
      item.tickFormat = d3.timeParse('%e %p %I');
      tickFormat.pushObject(item);

      item = {};
      item.type = 'minute';
      item.ticks = d3.timeMinute;
      // PM 3
      item.tickFormat = d3.timeParse('%p %I');
      tickFormat.pushObject(item);

      // [REF-URL]
      // https://github.com/d3/d3-3.x-api-reference/blob/master/Time-Scales.md
      // https://bl.ocks.org/zanarmstrong/ca0adb7e426c12c06a95
      // https://github.com/d3/d3-3.x-api-reference/blob/master/Time-Formatting.md
      this.set('_tickAndFormat', tickFormat);
    }
  },

  didInsertElement() {
    this._super(...arguments);
    this._logTrace('c-chart-svg.didInsertElement()');

    this.set('_elementId', this.elementId);

    this._setMouseRightClick();
    if(Ember.isEmpty(this.get('_chartData')) === true) {
      return;
    }
    this._renderChart();
    this.set('_hasLoaded', true);
  },

  didRender() {
    this._super(...arguments);
    this._logTrace('c-chart-svg.didRender()');

    this._initSeriesStyle();

    this._copyChartData();
  },

  didUpdateAttrs() {
    this._super(...arguments);
    this._logTrace('c-chart-svg.didUpdateAttrs()');

    if(Ember.isEmpty(this.get('_chartData'))) {
      return;
    }

    const oldData = this.get('_oldChartData');
    const chartData = this.get('_chartData');
    // 추가, 삭제된 데이터만 핸들링
    if(this.get('_changedData')) {
      const actionMode = this.get('actionMode');
      const newSeries = this.get('addSeries');

      if(oldData && (oldData.series.length > chartData.series.length)) {
        const num = [];
        for (const item of chartData.series) {
          num.push(item.no);
        }
        let removeTarget = oldData.series.filter(obj => {
          return !~num.indexOf(obj.no);
        });

        if (actionMode === 'update') {
          this.set('removeSeriesSet', removeTarget);
        }
      }
      const removeSeriesNo = this.get('removeSeriesNo');

      this._removeAxis();
      this.$('g[data-id=todayRoot]').remove();

      if(actionMode === 'add' && !Ember.isEmpty(newSeries)) {
        this._addToChartData(newSeries);
      }

      if(actionMode === 'remove' && !Ember.isEmpty(removeSeriesNo)) {
        this._applyRemovedData(removeSeriesNo);
        this._removeToChartDataByNo(removeSeriesNo);
      }
    }

    this.set('_ccSeries', null);
    this._copyChartData();

    if (JSON.stringify(oldData) !== JSON.stringify(chartData)) {
      this._renderChart();
    } else {
      this._reRenderChart();
    }

    this.set('_oldChartData', this.get('_chartData'));
  },

  willDestroyElement() {
    this._super(...arguments);
    this._logTrace('c-chart-svg.willDestroyElement()');

    // 이벤트 리스너 해제
    this._removeEventListener();

    this.set('_hasLoaded', false);
    this.set('_tickAndFormat', null);
    this._removeDom();

    // 클로저 해제
    this._convertDateFormat = null;
    this._setTooltipOpacity = null;
    this._setLegendOpacity = null;
    this._onlyOneChecked = null;
    this._setSeriesOpacity = null;
    this._showSeriesTooltip = null;
    this._showSeries = null;
    this._getD3Svg = null;
    this._logTrace = null;
    this._initSeriesStyle = null;
    this._copyChartData = null;
    this._setCurrentYAxis = null;
  },

  _copyChartData() {
    if(!Ember.isEmpty(this.get('chartData'))) {
      if(Ember.isEmpty(this.get('_ccSeries'))) {
        const temp = Ember.$.extend(true, [], this.get('chartData').series);

        this.set('_ccSeries', temp);
      }
    }
  },

  _removeEventListener() {
    const zoom = this.get('_zoom');
    const brush = this.get('_brush');
    const brushExtect = d3.selectAll('rect.extent');
    const rect = this.get('_rect');
    const svg = this._getD3Svg();
    const root = svg.select('g.main').select('g.chartRoot');

    this.$().off('contextmenu');

    if(brush !== null) {
      brush.on('brush', null);
    }
    if(brushExtect !== null) {
      brushExtect.on('mouseover', null);
      brushExtect.on('mouseout', null);
    }
    if(rect !== null) {
      rect.on('dblclick.zoom', null);
      rect.on('mousedown', null);
      rect.on('mouseup', null);
    }
    if(zoom !== null) {
      zoom.on('zoom', null);
    }
    if(root !== null) {
      root.on('mousedown', null);
      root.on('mouseup', null);
    }

    svg.on('mousedown', null);
    svg.on('mousemove', null);
    svg.on('mouseup', null);
  },

  _logTrace(text) {
    if(this.get('_trace') === true) {
      Ember.Logger.log(text);
    }
  },

  _getD3Svg() {
    const zero = 0;

    return d3.select(this.$().get(zero));
  },
  _isDateInstance(date) {
    return date instanceof Date && date.valueOf() && !Number.isNaN(date.valueOf());
  },

  _setMouseRightClick() {
    this.$().on('contextmenu', e => {
      this._logTrace('[contextmenu]');
      this._onContextMenu(e);
      ////this._resetZoomBrush();
      e.preventDefault();
      e.stopPropagation();
    });
  },

  _applyRemovedData(no) {
    const one = 1;
    const zero = 0;
    //let data = this.get('_chartData');
    const selectedLegend = this.get('_selectedLegendRect');
    const selectedLegendForYAxis = this.get('_selectedLegendRectForYAxis');
    const selectedLegendSymbol = this.get('_selectedLegendSymbol');

    // 현재 1개 선택된 상태에서 그것을 삭제한 경우
    if(selectedLegend.length === one) {
      if(selectedLegend[zero] === no) {
        this.set('_setNormalAll', true);
      }
    }

    if(selectedLegend.includes(no)) {
      for(let i=zero; i < selectedLegend.length; i++) {
        if(selectedLegend[i] === no) {
          selectedLegend.removeObject(selectedLegend[i]);
        }
      }
    }

    if(selectedLegendSymbol.includes(no)) {
      for(let i=zero; i < selectedLegendSymbol.length; i++) {
        if(selectedLegendSymbol[i] === no) {
          selectedLegendSymbol.removeObject(selectedLegendSymbol[i]);
        }
      }
    }

    if(selectedLegendForYAxis.includes(no)) {
      for(let i=zero; i < selectedLegendForYAxis.length; i++) {
        if(selectedLegendForYAxis[i] === no) {
          selectedLegendForYAxis.removeObject(selectedLegendForYAxis[i]);
        }
      }
    }
  },

  _removeAxis() {
    const zero = 0;

    this.set('xScale', null);
    this.set('yScale', null);
    this.set('_xAxis', null);
    this.set('_yAxis', null);
    this.set('_miniXScale', null);

    const el = this.$().get(zero);
    const isTrendChart = this.get('_isTrendChart');

    d3.select(el).selectAll('g[data-id=\'xAxisG\']').remove();
    d3.select(el).selectAll('g[data-id=\'yAxisG\']').remove();

    if(isTrendChart === true) {
      d3.select(el).selectAll('.main').remove();
      d3.select(el).selectAll('.mini').remove();
      d3.select(el).select('defs').remove();
    }
    d3.select(el).select('rect.pane').remove();
  },

  _initSeriesStyle() {
    const chartData = this.get('_chartData');
    const zero = 0;

    if(Ember.isEmpty(chartData)) {
      return;
    }

    const allSeries = chartData.series;
    const transparentOpacity = this.get('_settingTransparentOpacity');
    const normalOpacity = this.get('_settingNormalOpacity');
    const selectedLegendSymbol = this.get('_selectedLegendSymbol');
    const selectedLegendRect = this.get('_selectedLegendRect');
    const el = this.$().get(zero);

    // 선택된 레전드 처리
    for(let i=0; i < allSeries.length; i++) {
      const seriesNo = allSeries[i].no;

      if(selectedLegendRect.includes(seriesNo)) {
        // 상태 변경된 아이템
        const legendLabel = d3.select(el)
        .selectAll('.chart.legendG.series' + seriesNo)
        ////.selectAll('text');
        .selectAll('.legendText');

        if(selectedLegendRect.includes(seriesNo)) {
          legendLabel.classed('selectedLegend', true);
        } else {
          legendLabel.classed('selectedLegend', false);
        }
      }
    }

    this._onlyOneChecked();

    // 하나만 있다면, 그것을 제외한 모든 것을 투명하게 처리
    if(this.get('_onlyOne') === true) {

      for(let i = 0; i < allSeries.length; i++) {
        const tempSeriesNo = allSeries[i].no;

        if(selectedLegendRect.includes(tempSeriesNo)) {
          this._setSeriesOpacity(tempSeriesNo, normalOpacity);

          if(selectedLegendSymbol.includes(tempSeriesNo)) {
            this._showSeriesTooltip(tempSeriesNo, false);
          } else {
            this._showSeriesTooltip(tempSeriesNo, true);
          }
        } else {
          this._setSeriesOpacity(tempSeriesNo, transparentOpacity);
          this._showSeriesTooltip(tempSeriesNo, false);
        }
      }
    } else {
      // 선택된 것이 하나도 없다면 모두 표시
      if(selectedLegendRect.length === zero) {
        for(let i = 0; i < allSeries.length; i++) {
          const tempSeriesNo = allSeries[i].no;

          this._setSeriesOpacity(tempSeriesNo, normalOpacity);
          this._showSeriesTooltip(tempSeriesNo, false);
        }
      } else {
        for(let i = 0; i < allSeries.length; i++) {
          const tempSeriesNo = allSeries[i].no;

          if(selectedLegendRect.includes(tempSeriesNo)) {
            this._setSeriesOpacity(tempSeriesNo, normalOpacity);

            if(selectedLegendSymbol.includes(tempSeriesNo)) {
              this._showSeriesTooltip(tempSeriesNo, false);
            } else {
              this._showSeriesTooltip(tempSeriesNo, true);
            }
          } else {
            this._setSeriesOpacity(tempSeriesNo, transparentOpacity);
            this._showSeriesTooltip(tempSeriesNo, false);
          }
        }
      }
    }

    // 선택된 심볼 처리
    for(let i=0; i < allSeries.length; i++) {
      const seriesNo = allSeries[i].no;

      if(selectedLegendSymbol.includes(seriesNo)) {
        this._showSeries(seriesNo, false);
        this.$('.chart.legendSymbol.series' + seriesNo).parent().css('opacity', transparentOpacity);
      } else {
        this._showSeries(seriesNo, true);
        this.$('.chart.legendSymbol.series' + seriesNo).parent().css('opacity', normalOpacity);
      }
    }
  },

  _onContextMenu(e) {
    this._raiseEvents('onMouseRightClick', e);
  },

  _resetZoomBrush() {
    const svg = this._getD3Svg();
    const brush = this.get('_brush');
    const minX = this.get('_minX');
    const maxX = this.get('_maxX');
    const brushExtent = [minX, maxX];

    svg.select('.brush').call(brush.extent(brushExtent));
    brush.event(svg.select('.brush'));
  },

  _hasProperty(obj, propertyName) {
    let result = true;
    let prop = '';

    for( let i=0; i < propertyName.length; i++) {
      if( !obj.hasOwnProperty([propertyName[i]]) ) {
        prop = propertyName[i];
        result = false;
        break;
      }
    }

    return { result: result, message: prop };
  },

  _isValidate() {
    let result = true;
    const data = this.get('chartData');

    this.set('_violateProperty', '');

    try {
      const rootPropertyName = [
        'xAxisOrient',
        'tooltipSize',
        'isSortedData',
        'isTimeXAxis',
        'isGroupLegend',
        'isCollapsibleLegend',
        'isCustomYAxis',
        'series'
      ];
      const temp = this._hasProperty(data, rootPropertyName);

      if( temp.result === false) {
        this.set('_violateProperty', this.get('_violateProperty') + '\n root property -> ' + temp.message);
      }

      const xAxisOrientDomain = ['bottom'];

      if(xAxisOrientDomain.includes(data.xAxisOrient) === false) {
        this.set('_violateProperty', this.get('_violateProperty') + '\n xAxisOrient -> not valid value');
      }

      if(Number.isInteger(data.tooltipSize) === false) {
        this.set('_violateProperty', this.get('_violateProperty') + '\n tooltipSize -> must number value');
      }

      if(typeof data.isSortedData !== 'boolean') {
        this.set('_violateProperty', this.get('_violateProperty') + '\n isSortedData -> must boolean value');
      }

      if(typeof data.isTimeXAxis !== 'boolean') {
        this.set('_violateProperty', this.get('_violateProperty') + '\n isTimeXAxis -> must boolean value');
      }

      if(typeof data.isGroupLegend !== 'boolean') {
        this.set('_violateProperty', this.get('_violateProperty') + '\n isGroupLegend -> must boolean value');
      }

      if(typeof data.isCollapsibleLegend !== 'boolean') {
        this.set('_violateProperty', this.get('_violateProperty') + '\n isCollapsibleLegend -> must boolean value');
      }

      if(typeof data.isCustomYAxis !== 'boolean') {
        this.set('_violateProperty', this.get('_violateProperty') + '\n isCustomYAxis -> must boolean value');
      }

      if(Ember.isEmpty(data.collapsibleLegendWidth) === false) {
        if(Number.isInteger(data.collapsibleLegendWidth) === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n collapsibleLegendWidth -> must number value');
        }
      }

      if(Ember.isEmpty(data.isGroupLegend) === false) {
        if(data.isGroupLegend === true && Ember.isEmpty(data.groupLegend) === true) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n groupLegend -> must set groupLegend with isGroupLegend');
        }
      }

      const seriesPropertyName = ['no', 'name', 'config', 'data'];
      const seriesConfigPropertyName = ['type', 'xAxisProperty', 'yAxisProperty', 'tooltipProperty', 'isSelectSymbol', 'isSelectLegend'];
      const seriesTypeDomain = [ 'line', 'bar', 'minMax', 'pie', 'fromTo', 'point'];

      for(let i = 0; i < data.series.length; i++) {
        const series = data.series[i];
        let innerTemp = this._hasProperty(series, seriesPropertyName);

        if( innerTemp.result === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[] property -> ' + innerTemp.message);
        }

        if(Ember.isEmpty(series.name) === true) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].name -> is empty');
        }
        if(Ember.isEmpty(series.config) === true) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config -> is empty');
        }

        innerTemp = '';
        innerTemp = this._hasProperty(series.config, seriesConfigPropertyName);
        if( innerTemp.result === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config property -> ' + innerTemp.message);
        }

        const type = series.config.type;

        if(seriesTypeDomain.includes(type) === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config.type -> value domain');
        }

        if(Ember.isEmpty(series.config.strokeWidth) === false && Number.isInteger(series.config.strokeWidth) === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config.strokeWidth -> must number value');
        }

        if(Ember.isEmpty(series.config.symbolSize) === false && Number.isInteger(series.config.symbolSize) === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config.symbolSize -> must number value');
        }

        if(Ember.isEmpty(series.config.groupLegendNo) === false && Number.isInteger(series.config.groupLegendNo) === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config.groupLegendNo -> must number value');
        }

        if(Ember.isEmpty(series.config.isCustomYAxis) === false && typeof series.config.isCustomYAxis !== 'boolean') {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config.isCustomYAxis -> must boolean value');
        }

        if(typeof series.config.isSelectSymbol !== 'boolean') {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config.isSelectSymbol -> must boolean value');
        }

        if(typeof series.config.isSelectLegend !== 'boolean') {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config.isSelectLegendtype -> must boolean value');
        }

        if(Ember.isEmpty(series.config.groupLegendNo) === false && series.config.symbolType.startsWith('material-icons-') === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config.symbolType -> must specific prefix name');
        }

        let seriesTypePropertyName = [];

        if(series.config.type === 'line') {
          seriesTypePropertyName = ['strokeColor', 'strokeWidth', 'symbolColor', 'symbolSize', 'symbolType'];
        } else if(series.config.type === 'bar') {
          seriesTypePropertyName = ['strokeColor', 'strokeWidth', 'symbolColor'];
        } else if(series.config.type === 'minMax') {
          seriesTypePropertyName = ['strokeColor', 'strokeWidth', 'symbolColor', 'symbolSize', 'symbolType'];
        } else if(series.config.type === 'pie') {
          seriesTypePropertyName = ['symbolColor'];
        }

        innerTemp = null;
        innerTemp = this._hasProperty(series.config, seriesTypePropertyName);

        if( innerTemp.result === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[] property -> ' + innerTemp.message);
        }
      }

      if(Ember.isEmpty(this.get('_violateProperty')) === false) {
        result = false;
      }
    } catch(e) {
      result = false;
      // [i18N]
      this._logTrace('chart 데이터를 확인하는 과정에서 에러가 발생하였습니다. ' + e.message);
    }

    return result;
  },

  _renderChart() {
    this._logTrace('c-chart-svg._renderChart()');
    if (Ember.isEmpty(this.get('_chartData').series)) {
      return;
    }
    if (!this._isValidate()) {
      const failMessage = '[chartData is not valid] ' + this.get('_violateProperty');

      // [i18N]
      this._logTrace(failMessage);
      this._raiseEvents('onValidateFail', failMessage);
      this.set('_isValidData', false);
      console.log('chartData is not valid');
      return;
    }

    this._removeDom();
    const isTrendChart = this.get('_isTrendChart');

    this._setProperties();
    this._setClipArea();

    this._setScale();

    if(isTrendChart) {
      this._setBrush();
      this._setTrendChartRightDrag();
      this._setZoomPeriod();
    }
  },

  _removeDom() {
    const target = d3.selectAll(this.childNodes);
    target.remove();
  },

  _setProperties() {
    const chartData = this.get('_chartData');
    const isCollapsibleLegend = chartData.isCollapsibleLegend;

    if(isCollapsibleLegend) {
      this.get('_setting').paddingLeft = this.get('_chartPaddingCollapse');
      this.set('_groupLegendWidth', parseInt(chartData.collapsibleLegendWidth));
      this.set('_isCollapsed', chartData.isCollapseLegendPane);
    } else if (!this.get('_showLegend')) {
      this.set('_settingPaddingLeft', this.get('_chartPaddingCollapse'));
    } {
      this.get('_settingPaddingLeft', this.get('_chartPaddingExpand'));
    }

    for(let i=0; i < chartData.series.length; i++) {
      const current = chartData.series[i];

      if(current.config.isSelectSymbol === true){
        this.get('_selectedLegendSymbol').pushObject(current.no);
      }

      if(current.config.isSelectLegend === true) {
        this.get('_selectedLegendRect').pushObject(current.no);
      }
    }

    this._setXAxisTickFormat();
  },
  // tick 형식 설정
  _setXAxisTickFormat() {
    if(Ember.isEmpty(this.get('_chartData').timeFormat)) {
      return;
    }

    if(Ember.isEmpty(this.get('_chartData').timeFormat.xAxisTickFormat)) {
      return;
    }

    const result = [];
    const xAxisTickFormat = this.get('_chartData').timeFormat.xAxisTickFormat;

    for(let i=0; i < xAxisTickFormat.length; i++) {
      const item = {};

      item.type = xAxisTickFormat[i].type;
      item.tickFormat = d3.timeFormat(xAxisTickFormat[i].format);
      item.interval = xAxisTickFormat[i].interval || null;

      switch(xAxisTickFormat[i].type) {
        case 'year':
          item.interval ? item.ticks = d3.timeYear.every(item.interval) : item.ticks = d3.timeYear;
          break;
        case 'month':
          item.interval ? item.ticks = d3.timeMonth.every(item.interval) : item.ticks = d3.timeMonth;
          break;
        case 'week':
          item.interval ? item.ticks = d3.timeWeek.every(item.interval) : item.ticks = d3.timeWeek;
          break;
        case 'day':
          item.interval ? item.ticks = d3.timeDay.every(item.interval) : item.ticks = d3.timeDay;
          break;
        case 'hour':
          item.interval ? item.ticks = d3.timeHour.every(item.interval) : item.ticks = d3.timeHour;
          break;
        case 'minutes':
          item.interval ? item.ticks = d3.timeMinutes.every(item.interval): item.ticks = d3.timeMinutes;
          break;
        default:
          item.interval ? item.ticks = d3.timeDay.every(item.interval) : item.ticks = d3.timeDay;
      }

      result.pushObject(item);
    }

    this.set('_tickAndFormat', result);
  },
  // 클리핑마스크 제작
  _createDefs() {
    const svg = this._getD3Svg();
    if(!svg.selectAll(`#${this.get('_elementId')}clip`).size()) {
      const width = this.get('_innerWidth');
      const height = this.get('_height') - this.get('_settingPaddingTop');

      svg.append('defs')
        .append('clipPath')
        .attr('id', this.get('_elementId') + 'clip')
        .append('rect')
        .attr('width', width)
        .attr('height', height)
        .attr('transform', `translate(${this.get('_settingPaddingLeft')}, ${this.get('_settingPaddingTop')})`);
    }
  },

//   _calculateIntersectionPoint(line1StartX, line1StartY, line1EndX, line1EndY, line2StartX, line2StartY, line2EndX, line2EndY) {
//     // if the lines intersect, the result contains the x and y of the intersection (treating the lines as infinite) and booleans for whether line segment 1 or line segment 2 contain the point
//     const denominator, a, b, numerator1, numerator2, result = {
//       x: null,
//       y: null,
//       onLine1: false,
//       onLine2: false
//     };
//     denominator = ((line2EndY - line2StartY) * (line1EndX - line1StartX)) - ((line2EndX - line2StartX) * (line1EndY - line1StartY));
//     if (denominator == 0) {
//         return result;
//     }
//     a = line1StartY - line2StartY;
//     b = line1StartX - line2StartX;
//     numerator1 = ((line2EndX - line2StartX) * a) - ((line2EndY - line2StartY) * b);
//     numerator2 = ((line1EndX - line1StartX) * a) - ((line1EndY - line1StartY) * b);
//     a = numerator1 / denominator;
//     b = numerator2 / denominator;

//     // if we cast these lines infinitely in both directions, they intersect here:
//     result.x = line1StartX + (a * (line1EndX - line1StartX));
//     result.y = line1StartY + (a * (line1EndY - line1StartY));
// /*
//         // it is worth noting that this should be the same as:
//         x = line2StartX + (b * (line2EndX - line2StartX));
//         y = line2StartX + (b * (line2EndY - line2StartY));
//         */
//     // if line1 is a segment and line2 is infinite, they intersect if:
//     if (a > 0 && a < 1) {
//         result.onLine1 = true;
//     }
//     // if line2 is a segment and line1 is infinite, they intersect if:
//     if (b > 0 && b < 1) {
//         result.onLine2 = true;
//     }
//     // if line1 and line2 are segments, they intersect if both of the above are true

//     return result;
//   },

  _setMainMini() {
    const svg = this._getD3Svg();
    const main = svg.append('g').attr('class', 'main');
    const mini = svg.append('g').attr('class', 'mini');

    this.set('_main', main);
    this.set('_mini', mini);
  },

  _convertDateString(date, format) {
    return this.get('fr_I18nService').formatDate(date, format);
  },

  _resetPeriodLabel(extent) {
    const zero = 0;
    const one = 1;
    // chartRoot 아래 자식 추가
    const svg = this._getD3Svg();
    const chartRoot = svg.select('g.main');

    chartRoot.selectAll('text[data-id=startDate]').remove();
    chartRoot.selectAll('text[data-id=endDate]').remove();

    const gLabel = svg.select('g.main').select('g.chartRoot');
    const startX = 10;
    const hundred = 100;
    const endX = this.get('_width') - this.get('_settingPaddingLeft') - hundred;
    const y = 15;
    const dateFormat = 'd';

    const startDate = this._convertDateString(extent[zero], dateFormat);
    const endDate = this._convertDateString(extent[one], dateFormat);

    gLabel.append('text')
      .attr('data-id', 'startDate')
      .attr('class', 'startDate')
      .attr('transform', function() {
        const x = startX;
        let xy = x + ', ';

        xy = xy + y;

        return 'translate(' + xy + ')';
      })
      .text(startDate);

    gLabel.append('text')
      .attr('data-id', 'startDate')
      .attr('class', 'endDate')
      .attr('transform', function() {
        const x = endX;
        let xy = x + ', ';

        xy = xy + y;

        return 'translate(' + xy + ')';
      })
      .text(endDate);
  },

  // Zoom 기본값 설정
  _setZoomPeriod() {
    const zero = 0;
    const one = 1;
    const svg = this._getD3Svg();
    const brush = this.get('_brush');
    const customPeriod = this.get('_chartData').period;
    const minX = this.get('_minX');
    const maxX = this.get('_maxX');
    let brushExtent = [minX, maxX];

    if(!Ember.isEmpty(customPeriod)) {
      brushExtent = [customPeriod[zero], customPeriod[one]];
    }

    svg.select('.brush').call(brush.extent(brushExtent));
    brush.event(svg.select('.brush'));
  },

  _brushListener() {
    this._logTrace('[_brushListener]');
    const zero = 0;
    const one = 1;

    const svg = this._getD3Svg();
    const xScale = this.get('_xScale');
    const miniXScale = this.get('_miniXScale');
    const xAxis = this.get('_xAxis');
    //const main = this.get('_main');
    const brush = this.get('_brush');
    const zoom = this.get('_zoom');
    const width = this.get('_innerWidth');

    this._logTrace('[_brushListener] brush.extent = [' + brush.extent()[zero] + ', ' + brush.extent()[one] + ']');
    xScale.domain(brush.empty() ? miniXScale.domain() : brush.extent());
    // this.set('_xScale', xScale);

    const mainDomain = xScale.domain();
    const miniDomain = miniXScale.domain();
    const newScale = (miniDomain[one]-miniDomain[zero])/(mainDomain[one]-mainDomain[zero]);
    const t = (mainDomain[zero]-miniDomain[zero])/(miniDomain[one]-miniDomain[zero]);
    const trans = width * newScale * t;

    const intervalType = this._getIntervalType(mainDomain[zero], mainDomain[one]);
    // [ year, month, week, day, hour, minute]
    const tickItem = this._getTickAndFormat(intervalType);

    xAxis.ticks(tickItem.ticks)
      .tickFormat(tickItem.tickFormat);
    svg.select('g[data-id=xAxisG]').call(xAxis);
    this.set('_xAxis', xAxis);

    zoom.scale(newScale);
    zoom.translate([-trans, zero]);

    this._resetNowBar();
    // 자식 시리즈 다시 그리게
    this.set('reload', !this.get('_reload'));

    // 호출자에 기간 변경 콜백
    this._raiseEvents('onPeriodChange', brush.extent());

    // 현재 표시하는 데이터의 시작점과 끝점
    this._resetPeriodLabel(brush.extent());

    if(Ember.isEmpty(d3.event.sourceEvent)) {
      //
    } else if(Ember.isEmpty(d3.event.sourceEvent.sourceEvent)) {
      //
    } else {
      d3.event.sourceEvent.sourceEvent.cancelBubble = true;
    }
  },

  _getOffsetX(e) {
    const target = e.target || e.srcElement;
    const rect = target.getBoundingClientRect();
    let offsetX;

    if( e.clientX === Math.round(rect.left)) {
      offsetX = e.clientX - rect.right;
    } else {
      offsetX = e.clientX - rect.left;
    }

    return offsetX;
  },

  _getBrowserType() {
    const browserName = this.get('fr_GlobalSystemService').browserName;

    return browserName.toLowerCase();
  },

  _zoomListener() {
    let eventType = '';
    let button = '';
    let currentX = null;
    const two = 2;
    const one = 1;
    const zero = 0;

    if(Ember.isEmpty(d3.event.sourceEvent)) {
      // dblclick
      eventType = d3.event.type;
      button = d3.event.buttons;
      currentX = d3.event.offsetX;
    } else {
      eventType = d3.event.sourceEvent.type;
      button = d3.event.sourceEvent.buttons;
      currentX = d3.event.sourceEvent.offsetX;
    }

    if(eventType === 'mousemove' && button === two) {
      let tempStartX = this.get('_mousedownOffsetX');
      let tempEndX = currentX;
      const browserType = this.get('_browserType');

      if(browserType === 'edge' || browserType === 'firefox') {
        tempStartX += this.get('_settingPaddingLeft');
        tempEndX += this.get('_settingPaddingLeft');
      }
      // 각 브라우저의 rect 위치 조정
      this._setDraggingRect(tempStartX, tempEndX);
    }

    if(eventType === 'mousemove' && button === two) {
      return;
    }

    if(eventType === 'brush') {
      return;
    }

    const svg = this._getD3Svg();
    const xScale = this.get('_xScale');
    const brush = this.get('_brush');
    const width = this.get('_innerWidth');
    const minX = this.get('_minX');
    const maxX = this.get('_maxX');
    let scale;
    let brushExtent;
    let leftX, rightX;

    if(eventType === 'dblclick') {
      // 줄어드는 폭 기준
      const diff = 100;

      leftX = xScale.invert(diff);
      rightX = xScale.invert(width - diff);
      brushExtent = [leftX, rightX];
    } else if(eventType === 'mouseup') {
      const extentStartX = xScale(brush.extent()[zero]);
      const xAxisPadding = this.get('_settingPaddingLeft');
      const browserType = this.get('_browserType');

      this._logTrace('browserType =' + browserType + ', extentStartX = ' + extentStartX);
      this._logTrace('_mousedownOffsetX = ' + this.get('_mousedownOffsetX') + ', _mouseupOffsetX = ' + this.get('_mouseupOffsetX'));

      if(browserType === 'edge') {
        leftX = xScale.invert(this.get('_mousedownOffsetX') + extentStartX);
        rightX = xScale.invert(this.get('_mouseupOffsetX') + extentStartX);
      } else if(browserType === 'firefox') {
        leftX = xScale.invert(this.get('_mousedownOffsetX') + extentStartX);
        rightX = xScale.invert(this.get('_mouseupOffsetX') + extentStartX);
      } else {
        leftX = xScale.invert(this.get('_mousedownOffsetX') + extentStartX - xAxisPadding);
        rightX = xScale.invert(this.get('_mouseupOffsetX') + extentStartX - xAxisPadding);
      }

      brushExtent = [leftX, rightX];
    } else {
      scale = d3.event.scale;

      if(eventType === 'wheel' && scale <= one) {
        scale = one;
      }

      const t = d3.event.translate;
      const size = width * scale;

      leftX = xScale.invert(zero);
      rightX = xScale.invert(width);
      brushExtent = [leftX, rightX];
    }

    if(scale === one) {
      brushExtent = [minX, maxX];
    }

    svg.select('.brush').call(brush.extent(brushExtent));

    // 브러시 이벤트 호출
    brush.event(svg.select('.brush'));
  },

  _dblclickListener() {
    this._logTrace('[_dblclickListener]');
    this._zoomListener();
  },

  _allowValueDomain(beforeValue, afterValue) {
    const error = 2;
    const allowMin = afterValue - error;
    const allowMax = afterValue + error;

    if(allowMin <= beforeValue && beforeValue <= allowMax) {
      return true;
    }

    return false;
  },
  // 클리핑을 위한 외곽선 설정 및 디자인용 rect 설정
  _setClipArea() {
    const svg = this._getD3Svg();
    const series = this.get('_chartData').series;
    const clip = this.$().children('.chartRenderArea');
    const pane = this.$().children('rect.pane');
    const width = this.get('_innerWidth');
    const height = this.get('_height');

    if (!clip || !clip.length) {
      svg.append('g')
        .attr('class', 'chart chartRenderArea')
        .attr('clip-path', 'url(#' + this.get('_elementId') + 'clip)');
    }
    if (!pane || !pane.length && series.length) {
      svg.append('svg:rect')
        .attr('class', 'pane')
        .attr('width', width)
        .attr('height', height - this.get('_settingPaddingTop'))
        .attr('transform',  `translate(${this.get('_settingPaddingLeft')}, ${this.get('_settingPaddingTop')})`);
    }
  },

  _setBrush() {
    const xScale = this.get('_xScale');
    const miniXScale = this.get('_miniXScale');
    const brush = d3.brushX();
    const two = 2;
    const delay = 200;
    const zero = 0;
    const one = 1;

    brush.on('brush', () => {
      this._brushListener();
    });
    const zoom = d3.zoom()
    .scaleExtent([1, Infinity])
    .translateExtent([[this.get('_settingPaddingLeft'), parseInt(this.get('_height'))], [parseInt(this.get('_width')), parseInt(this.get('_height'))]])
    .extent([[this.get('_settingPaddingLeft'), parseInt(this.get('_height'))], [parseInt(this.get('_width')), parseInt(this.get('_height'))]]);

    const rect = d3.select('rect.pane')
      .call(zoom)
      .on('dblclick.zoom', () => {
        this._dblclickListener();
        d3.event.stopPropagation();
      })
      .on('mousedown', () => {
        this._logTrace('[rect.mousedown]');
        const button = d3.event.button;

        if(button === two) {
          this.set('_mousedownOffsetX', d3.event.offsetX);
          this._logTrace('[rect.mousedown] d3.event.offsetX = ' + this.get('_mousedownOffsetX'));
        }
      })
      .on('mouseup', () => {
        this._logTrace('[rect.mouseup]');
        const button = d3.event.button;

        this.set('_mouseupOffsetX', d3.event.offsetX);
        this._logTrace('[rect.mouseup] d3.event.offsetX = ' + d3.event.offsetX);

        if(button === two) {
          if(this._allowValueDomain(this.get('_mousedownOffsetX'), this.get('_mouseupOffsetX'))) {
            // 이동하지 않음. => zoom 리셋, context 실행
            this._resetZoomBrush();
            d3.event.preventDefault();
          } else {
            // 값 비교하여 전후 관계 조정
            if(this.get('_mousedownOffsetX') > this.get('_mouseupOffsetX')) {
              const temp = this.get('_mouseupOffsetX');

              this.set('_mouseupOffsetX', this.get('_mousedownOffsetX'));
              this.set('_mousedownOffsetX', temp);
            }

            this._zoomListener();
          }

          this._removeDraggingRect(delay);
        }
      });

    // tag order [defs - rect - main - mini - today - legend]
    this._setMainMini();

    zoom.on('zoom', () => {
      this._zoomListener();
    });

    zoom.x(xScale);

    const x0 = miniXScale.invert(this.get('_settingPaddingLeft'));
    const x1 = miniXScale.invert(parseInt(this.get('_width')) - this.get('_settingPaddingRight'));

    brush.extent([x0, x1]);

    const main = this.get('_main');
    const mini = this.get('_mini');

    main.append('g')
      .attr('data-id', 'xAxisG')
      .attr('class', 'x axis')
      .attr('transform', `translate(${this.get('_settingPaddingLeft')}, ${this.get('_settingPaddingTop')})`)
      .call(this.get('_xAxis'));

    main.append('g')
      .attr('data-id', 'yAxisG')
      .attr('class', 'y axis')
      .attr('transform', `translate(${this.get('_width')}, 0)`)
      .call(this.get('_yAxis'));

    main.append('g')
      .attr('class', 'chart chartRoot')
      .attr('clip-path', `url(#${this.get('_elementId')}clip)`)
      .attr('transform', `translate(${this.get('_settingPaddingLeft')}, 0)`);

    const brushRect = mini.append('g')
      .attr('class', 'x brush')
      .call(brush)
      .selectAll('rect')
      .attr('y', this.get('_height'))
      .attr('height', this.get('_settingPaddingBottom'));

    mini.append('g')
      .attr('class', 'chart chartDrag')
      .attr('clip-path', `url(#${this.get('_elementId')}clip)`)
      .attr('transform', 'translate(0, 0)');

    brushRect.selectAll('.background')
      .style({ fill: '#4b9e9e', visibility: 'hidden' });
    brushRect.selectAll('.extent')
      .style({ fill: '#78c5c5', visibility: 'visible'});
    brushRect.selectAll('.resize rect')
      .style({ fill: '#276c86', visibility: 'visible' });

    this.set('_zoom', zoom);
    this.set('_brush', brush);
    this.set('_rect', rect);

    // 마우스 오버 효과
    const dateFormat = this.get('_chartData').timeFormat.dataFormat;
    const p = this.$().parent();

    if(!p.children('div.chartTooltipTemplate').length) {
      p.append('<div class=\'chartTooltipTemplate\'></div>');
    }

    const toolTip = d3.select(p[zero]).selectAll('div.chartTooltipTemplate');
    const ten = 10;

    d3.selectAll('rect.extent')
      .on('mouseover', () => {
        const extent = brush.extent();
        const startDate = this._convertDateString(extent[zero], dateFormat);
        const endDate = this._convertDateString(extent[one], dateFormat);
        const x = d3.event.pageX + ten;
        const y = d3.event.pageY + ten;

        toolTip.style('left', x + 'px');
        toolTip.style('top', y + 'px');
        toolTip.style('display', 'inline-block');

        const val = startDate + ' ~ ' + endDate;

        toolTip.html(val);
      })
      .on('mouseout', function() {
        toolTip.style('display', 'none');
        d3.event.stopPropagation();
      });
  },

  _setTrendChartRightDrag() {
    const two = 2;
    const svg = this._getD3Svg();

    svg.select('g.main')
      .select('g.chartRoot')
      .on('mousedown', () => {
        this._logTrace('[chartRoot.mousedown]');
        const button = d3.event.button;

        if(button === two) {
          this.set('_mousedownOffsetX', d3.event.offsetX);
          this._logTrace('[chartRoot.mousedown] d3.event.offsetX = ' + this.get('_mousedownOffsetX'));
        }
      })
      .on('mouseup', () => {
        this._logTrace('[chartRoot.mouseup]');
        const button = d3.event.button;

        this.set('_mouseupOffsetX', d3.event.offsetX);
        this._logTrace('[chartRoot.mouseup] d3.event.offsetX = ' + d3.event.offsetX);
        //// [CAUTION]
        const moveSize = this._getOffsetX(d3.event);

        this._logTrace('[chartRoot.mouseup] moveSize = ' + moveSize);
        this.set('_mouseupOffsetX', this.get('_mousedownOffsetX') + moveSize);

        if(button === two) {
          if(this._allowValueDomain(this.get('_mousedownOffsetX'), this.get('_mouseupOffsetX'))) {
            // 이동하지 않음. => zoom 리셋, context 실행
            this._resetZoomBrush();
            d3.event.preventDefault();
          } else {
            // 값 비교하여 전후 관계 조정
            if(this.get('_mousedownOffsetX') > this.get('_mouseupOffsetX')) {
              const temp = this.get('_mouseupOffsetX');

              this.set('_mouseupOffsetX', this.get('_mousedownOffsetX'));
              this.set('_mousedownOffsetX', temp);
            }

            this._zoomListener();
          }
          this._removeDraggingRect(200);
        }
      });
  },

  // 마우스 우측버튼 줌 영역 설정
  _setDraggingRect(startX, endX) {
    const zero = 0;

    if(startX === endX) {
      return;
    }

    const paddingLeft = this.get('_settingPaddingLeft');
    const transparentOpacity = 0.2;
    //this.get('_settingTransparentOpacity');

    this._removeDraggingRect(0);

    const svg = this._getD3Svg();
    const chartRoot = svg.select('g.main')
      .select('g.chartRoot');

    chartRoot.append('rect')
      .attr('class', 'chart draggingRect')
      .attr('data-id', 'draggingRect')
      .style('opacity', transparentOpacity)
      .attr('x', function() {
        let result = startX;

        if(startX > endX) {
          result = endX;
        }
        result = result - paddingLeft;

        return result;
      })
      .attr('y', zero)
      .attr('width', function() {
        const width = Math.abs(endX - startX);

        return width;
      })
      .attr('height', this.get('_height'));
  },

  _removeDraggingRect(duration) {
    const zero = 0;
    const svg = this._getD3Svg();
    const chartRoot = svg.select('g.main')
      .select('g.chartRoot');

    if(duration === zero) {
      chartRoot.selectAll('rect[data-id=draggingRect').remove();
    } else {
      chartRoot.selectAll('rect[data-id=draggingRect').transition().duration(duration).remove();
    }
  },

  _removeSelectionContext(duration) {
    const zero = 0;

    if(duration === zero) {
      d3.selectAll('g[data-id=selectionContext]')
        .remove();
    } else {
      d3.selectAll('g[data-id=selectionContext]')
        .transition()
          .duration(duration)
        .remove();
    }
  },

  _resetNowBar() {
    this._logTrace('c-chart-svg._resetNowBar()');
    this.$('g[data-id=todayRoot]').remove();

    this._setNowBar();

    // legendRoot 를 현재 svg 의 끝으로 이동
    const parentObj = this.$();
    const childObj = this.$('g[data-id=\'legendRoot\']');

    this._moveToLast(parentObj, childObj);
  },
  _convertDateFormat(date, isTimeXAxis) {
    if (isTimeXAxis) {
      if(date instanceof Date && date.valueOf() && !Number.isNaN(date.valueOf())) {
        return date;
      } else {
        return new Date(date);
      }
    } else {
      return date;
    }
  },

  // 스케일 설정
  _setScale() {
    const zero = 0;
    const one = 1;
    const isTimeXAxis = this.get('_chartData').isTimeXAxis;
    const series = Ember.copy(this.get('_chartData').series, false);

    let maxX = null;
    let minX = null;
    let maxY = []; //type {position: Number, value: Number}
    let minY = [];
    const postfixMax = this.get('_postfixMax');
    const postfixMin = this.get('_postfixMin');
    const postfixFrom = this.get('_postfixFrom');
    const postfixTo = this.get('_postfixTo');
    const isTrendChart = this.get('_isTrendChart');
    let dataLength = zero;

    series.forEach((item) => {
      const type = item.config.type;
      let yAxisMax = null, yAxisMin = null;
      if(item.config.yAxis && item.config.yAxis.length) {
        yAxisMax = Math.max.apply(null, item.config.yAxis);
        yAxisMin = Math.min.apply(null, item.config.yAxis);
      }
      dataLength += item.data.length;

      let currentMaxX, currentMaxY;
      let currentMinX, currentMinY;
      let currentPosition;

      if(type === 'line' || type === 'bar' || type === 'pie') {
        currentMaxX = d3.max(item.data, d => this._convertDateFormat(d[item.config.xAxisProperty], isTimeXAxis));
        currentMinX = d3.min(item.data, d => this._convertDateFormat(d[item.config.xAxisProperty], isTimeXAxis));

        currentMaxY = d3.max(item.data, d => d[item.config.yAxisProperty]);
        currentMinY = d3.min(item.data, d => d[item.config.yAxisProperty]);

      } else if(type === 'minMax') {
        currentMaxX = d3.max(item.data, d => this._convertDateFormat(d[item.config.xAxisProperty], isTimeXAxis));
        currentMinX = d3.min(item.data, d => this._convertDateFormat(d[item.config.xAxisProperty], isTimeXAxis));

        currentMaxY = d3.max(item.data, d => d[item.config.yAxisProperty + postfixMax]);
        currentMinY = d3.min(item.data, d => d[item.config.yAxisProperty + postfixMin]);

      } else if(type === 'point') {
        currentMaxX = d3.max(item.data, d => this._convertDateFormat(d[item.config.xAxisProperty], isTimeXAxis));
        currentMinX = d3.min(item.data, d => this._convertDateFormat(d[item.config.xAxisProperty], isTimeXAxis));

        currentMaxY = d3.max(item.data, d => d[item.config.yAxisProperty]);
        currentMinY = d3.min(item.data, d => d[item.config.yAxisProperty]);
      } else if(type === 'fromTo') {
        const fromMax = d3.max(item.data, d => this._convertDateFormat(d[item.config.xAxisProperty + postfixFrom], isTimeXAxis));
        const fromMin = d3.min(item.data, d => this._convertDateFormat(d[item.config.xAxisProperty + postfixFrom], isTimeXAxis));
        const toMax = d3.max(item.data, d => this._convertDateFormat(d[item.config.xAxisProperty + postfixTo], isTimeXAxis));
        const toMin = d3.min(item.data, d => this._convertDateFormat(d[item.config.xAxisProperty + postfixTo], isTimeXAxis));

        currentMaxX = fromMax;
        currentMinX = fromMin;

        if(currentMaxX < toMax) {
          currentMaxX = toMax;
        }

        if(currentMinX > toMin) {
          currentMinX = toMin;
        }

        currentMaxY = d3.max(item.data, d => d[item.config.yAxisProperty]);
        currentMinY = d3.min(item.data, d => d[item.config.yAxisProperty]);
      } else {
        throw new Error('_setScale -> 지원하지 않는 chart type');
      }

      currentPosition = item.config.yAxisPosition || 1;

      if(maxX === null) {
        maxX = currentMaxX;
      } else {
        if(currentMaxX > maxX) {
          maxX = currentMaxX;
        }
      }

      if(minX === null) {
        minX = currentMinX;
      } else {
        if(currentMinX < minX) {
          minX = currentMinX;
        }
      }

      maxY.push({
        position: currentPosition,
        value: yAxisMax !== null ? yAxisMax : currentMaxY,
        seriesNo: item.no
      });
      minY.push({
        position: currentPosition,
        value: yAxisMin !== null ? yAxisMin : currentMinY,
        seriesNo: item.no
      });
    });

    // 범위 지정 있다면 사용
    if(!Ember.isEmpty(this.get('_chartData').timeDomain)) {
      minX = this._convertDateFormat(this.get('_chartData').timeDomain[zero], isTimeXAxis);
      maxX = this._convertDateFormat(this.get('_chartData').timeDomain[one], isTimeXAxis);
    }

    if(!Ember.isEmpty(this.get('_chartData').valueDomain)) {
      minX = this.get('_chartData').valueDomain[zero];
      maxX = this.get('_chartData').valueDomain[one];
    }

    let yDataPadding = zero;

    if (isTrendChart) {
      yDataPadding = one;
    }

    let xScale = null;
    const rangeStart = this.get('_settingPaddingLeft') + this.get('_offset');
    const rangeEnd = this.get('_width') - this.get('_settingPaddingRight') - this.get('_offset');

    // const dataLength = series.data

    if (isTimeXAxis) {
      if (isTrendChart) {
        xScale = d3.scaleTime()
          .domain([minX, maxX])
          .range([zero, this.get('_innerWidth')])
        this.set('_xScale', xScale);

        this.set('_miniXScale', d3.scaleTime()
          .domain([minX, maxX])
          .range([rangeStart, rangeEnd]));
      } else {
        xScale = d3.scaleTime()
          .domain([minX, maxX])
          .range([rangeStart, rangeEnd]);
        this.set('_xScale', xScale);
      }
    } else {
      if (this.get('_scalePoint') || dataLength / series.length < 4) {
        const range = this._map(series[0].data, item => item[series[0].config.xAxisProperty]);

        xScale = d3.scalePoint()
          .domain(range)
          .range([rangeStart, rangeEnd]);
        this.set('_xScale', xScale);
      } else {
        xScale = d3.scaleLinear()
          .domain([minX , maxX])
          .range([rangeStart, rangeEnd]);
        this.set('_xScale', xScale);
      }
    }

    const yScaleRoof = this._map(minY.entries(), ([key, val]) => {
      console.log('minY', minY, val.value === maxY[key].value);
      const start = this.get('_height') - this.get('_offset'), end = this.get('_settingPaddingTop') + this.get('_offset');
      const scale = val.value === maxY[key].value ? (
        d3.scaleBand()
        .domain([val.value - yDataPadding, maxY[key].value + yDataPadding])
        .range([start, end])
      ) : (
        d3.scaleLinear()
        .domain([val.value - yDataPadding, maxY[key].value + yDataPadding])
        .range([start, end])
      );

      return {
        position: val.position,
        scale: scale,
        seriesNo: val.seriesNo
      }
    });

    this.set('_yScale', yScaleRoof);

    this.set('_minX', minX);
    this.set('_maxX', maxX);
    this.set('_minY', minY);
    this.set('_maxY', maxY);

    // 축 라벨 텍스트 설정
    this._setAxis(xScale, yScaleRoof);
  },

  _setAxis(xScale, yScale) {

    // 축 라벨 텍스트와 축 간격
    const series = this.get('_chartData').series;
    if(series.length === 1 && series[0].config.type === 'pie') {
      return;
    }

    const tickPadding = 5;
    const ticksCount = 6;
    const isTrendChart = this.get('_isTrendChart');

    const isTimeXAxis = this.get('_chartData').isTimeXAxis;
    const intervalType = this._getIntervalType(this.get('_minX'), this.get('_maxX'));
    const tickItem = this._getTickAndFormat(intervalType);
    const orientX = this.get('_chartData').xAxisOrient;
    const xAxisNm = 'axis' + orientX.charAt(0).toUpperCase() + orientX.substr(1);
    const width = this.get('_innerWidth');
    const tickHeight = (this.get('_height') - this.get('_settingPaddingTop') - this.get('_settingPaddingBottom')) / ticksCount;

    const zero = 0;
    const el = this.$().get(zero);

    let xAxis;

    // if (this.get('_scalePoint')) {
    //   xAxis = d3[xAxisNm](xScale)
    //     .tickSize(this.get('_height'))
    //     .tickPadding(tickPadding);
    // } else {
    //   isTimeXAxis ? (
    //     xAxis = d3[xAxisNm](xScale)
    //     .ticks(tickItem.ticks)
    //     .tickFormat(tickItem.tickFormat)
    //     .tickSize(this.get('_height'))
    //     .tickPadding(tickPadding)
    //   ) : (
    //     xAxis = d3[xAxisNm](xScale)
    //     .tickSize(this.get('_height'))
    //     .tickPadding(tickPadding)
    //   );
    // }
    if(isTimeXAxis) {
      const ticksize = this.get('_scalePoint') ? series[zero].data.length : tickItem.ticks;
      xAxis = d3[xAxisNm](xScale)
        .ticks(ticksize)
        .tickFormat(tickItem.tickFormat)
        .tickSize(this.get('_height'))
        .tickPadding(tickPadding);
    } else {
      xAxis = d3[xAxisNm](xScale)
        .tickSize(this.get('_height'))
        .tickPadding(tickPadding)
    }
    if(!isTrendChart) {
      d3.select(el)
      .append('g')
      .attr('data-id', 'xAxisG')
      .attr('class', 'x axis')
      .attr('transform', `translate(0, ${this.get('_settingPaddingTop')})`)
      .call(xAxis);
      this._createDefs();
    }
    this.set('_xAxis', xAxis);

    const posArr = Ember.A();

    for(const item of series) {
      posArr.pushObject({
        position: item.config.yAxisPosition || 1,
        color: item.config.strokeColor,
        series: item,
        yAxis: item.config.yAxis || null,
        yAxisColor: item.config.yAxisColor || null,
      });
    }
    const yAxis = [];

    const isOverlapSeries = (se) => {
      return yAxis.filter(obj => {
        return obj.series === se;
      });
    };
    const selScale = (position, no) => {
      return yScale.filter(obj => {
        return obj.position === position && obj.seriesNo === no;
      });
    };
    const dynamicAxis = (direction, item, yData, width) => {
      if(yData && yData.length) {
        return d3[direction](item.scale)
          .ticks(yData.length)
          .tickValues(yData)
          .tickSize(width, (this.get('_height') - this.get('_settingPaddingTop') - this.get('_settingPaddingBottom')) / yData.length)
          .tickPadding(tickPadding);
      } else {
        return d3[direction](item.scale)
          .ticks(ticksCount)
          .tickSize(width, tickHeight)
          .tickPadding(tickPadding);
      }
    };

    const addAxis = {
      leftInner: ({position, color, series, yData, yDataColor}) => {
        const pos = selScale(position, series.no);
        if(pos && pos.length) {
          for (const item of pos) {
            const axis = dynamicAxis('axisLeft', item, yData, width);

            if(!isTrendChart) {
              d3.select(el)
                .append('g')
                .attr('data-id', 'yAxisG')
                .attr('data-position', 'y-1')
                .attr('data-series', `y-1-${series.no}`)
                .attr('class', 'y axis')
                .attr('transform', `translate(${this.get('_width') - this.get('_settingPaddingRight') - tickPadding}, 0)`)
                .call(axis)
                .style('opacity', 0)
                .selectAll('g>text').style('fill', (d, i) => yDataColor && yDataColor[i] ? yDataColor[i] : color);

              if (!isOverlapSeries(series).length) {
                yAxis.push({position: position, axis: axis, color: color, series: series});
                this.set('_yAxis', yAxis);
                this._setCurrentYAxis(series, true);
              }
            };
          }
        }
      },
      rightInner: ({position, color, series, yData, yDataColor}) => {
        const pos = selScale(position, series.no);
        if(pos && pos.length) {
          for (const item of pos) {
            const axis = dynamicAxis('axisRight', item, yData, 10);

            if(!isTrendChart) {
                d3.select(el)
                .append('g')
                .attr('data-id', 'yAxisG')
                .attr('data-position', 'y-2')
                .attr('data-series', `y-2-${series.no}`)
                .attr('class', 'y axis')
                .attr('transform', `translate(${this.get('_width') - this.get('_settingPaddingRight')}, 0)`)
                .call(axis)
                .style('opacity', 0)
                .selectAll('g>text').style('fill', (d, i) => yDataColor && yDataColor[i] ? yDataColor[i] : color);

              if (!isOverlapSeries(series).length) {
                yAxis.push({position: position, axis: axis, color: color, series: series});
                this.set('_yAxis', yAxis);
                this._setCurrentYAxis(series, true);
              }
            };
          }
        }
      },
      leftOuter: ({position, color, series, yData, yDataColor}) => {
        const pos = selScale(position, series.no);
        if(pos && pos.length) {
          for (const item of pos) {
            const axis = dynamicAxis('axisLeft', item, yData, 10);

            if(!isTrendChart) {
              d3.select(el)
                .append('g')
                .attr('data-id', 'yAxisG')
                .attr('data-position', 'y-3')
                .attr('data-series', `y-3-${series.no}`)
                .attr('class', 'y axis outer')
                .attr('transform', `translate(${this.get('_settingPaddingLeft') - 25}, 0)`)
                .call(axis)
                .style('opacity', 0)
                .selectAll('g>text').style('fill', (d, i) => yDataColor && yDataColor[i] ? yDataColor[i] : color);

              if (!isOverlapSeries(series).length) {
                yAxis.push({position: position, axis: axis, color: color, series: series});
                this.set('_yAxis', yAxis);
                this._setCurrentYAxis(series, true);
              }
            };
          }
        }
      },
      rightOuter: ({position, color, series, yData, yDataColor}) => {
        const pos = selScale(position, series.no);
        if(pos && pos.length) {
          for (const item of pos) {
            const axis = dynamicAxis('axisRight', item, yData, 10);

            if(!isTrendChart) {
              d3.select(el)
                .append('g')
                .attr('data-id', 'yAxisG')
                .attr('data-position', 'y-4')
                .attr('data-series', `y-4-${series.no}`)
                .attr('class', 'y axis outer')
                .attr('transform', `translate(${this.get('_width') - this.get('_settingPaddingRight') + 25}, 0)`)
                .call(axis)
                .style('opacity', 0)
                .selectAll('g>text').style('fill', (d, i) => yDataColor && yDataColor[i] ? yDataColor[i] : color);

              if (!isOverlapSeries(series).length) {
                yAxis.push({position: position, axis: axis, color: color, series: series});
                this.set('_yAxis', yAxis);
                this._setCurrentYAxis(series, true);
              }
            };
          }
        }
      }
    }
    if(!posArr || !posArr.length) {
      return;
    }

    const singleYAxis = posArr.reduce((accum, curr) => {
      return accum.position === curr.position;
    });
    if(posArr.length && !singleYAxis) {
      for(const item of posArr) {
        switch(item.position) {
          case 1:
            addAxis.leftInner({
              position: 1,
              color: item.color,
              series: item.series,
              yData: item.yAxis,
              yDataColor: item.yAxisColor
            });
            break;
          case 2:
            addAxis.rightInner({
              position: 2,
              color: item.color,
              series: item.series,
              yData: item.yAxis,
              yDataColor: item.yAxisColor
            });
            break;
          case 3:
            addAxis.leftOuter({
              position: 3,
              color: item.color,
              series: item.series,
              yData: item.yAxis,
              yDataColor: item.yAxisColor
            });
            break;
          case 4:
            addAxis.rightOuter({
              position: 4,
              color: item.color,
              series: item.series,
              yData: item.yAxis,
              yDataColor: item.yAxisColor
            });
            break;
          default:
            addAxis.leftInner({
              position: 1,
              color: item.color,
              series: item.series,
              yData: item.yAxis,
              yDataColor: item.yAxisColor
            });
        }
      }
    } else {
      addAxis.leftInner({
        position: 1,
        color: '#000000',
        series: posArr[0].series,
        yData: posArr[0].yAxis
      });
      return;
    }
    if (isTimeXAxis) {
      this._setNowBar();
    }
    this._setEvent();

    if(!isTrendChart) {
      this._setChartRightDrag();
    }
  },

  _setEvent() {
    const zero = 0;
    const twenty = 20;
    const event = this.get('_chartData').event;

    if(!event) {
      return;
    }

    const el = this.$().get(zero);
    const isTrendChart = this.get('_isTrendChart');

    this.$('g[data-id=eventRoot]').remove();

    // [TEMP]
    const xScaleFunction = this.get('_xScale');
    let gEventRoot = null;
    if(isTrendChart) {
      gEventRoot = d3.select(el)
        .select('g.main')
        .select('g.chartRoot')
        .append('g')
        .attr('class', 'chart eventRoot')
      .attr('data-id', 'eventRoot');
    } else {
      gEventRoot = d3.select(el)
        .append('g')
        .attr('class', 'chart eventRoot')
      .attr('data-id', 'eventRoot');
    }

    gEventRoot.selectAll('.chart.eventBar')
      .data(event)
      .enter()
      .append('line')
      .attr('x1', d => {
        return xScaleFunction(this._convertDateFormat(d.time, true));
      })
      .attr('y1', zero)
      .attr('x2', d => {
        return xScaleFunction(this._convertDateFormat(d.time, true));
      })
      .attr('y2', this.get('_height'))
      .style('stroke', function(d) {
        return d.color;
      })
      .attr('class', 'eventBar');

    gEventRoot.selectAll('.chart.eventBarText')
      .data(event)
      .enter()
      .append('text')
      .attr('class', 'eventBarText')
      .attr('transform', d => {
        const x = xScaleFunction(this._convertDateFormat(d.time, true)) - twenty;
        const y = 15;

        return 'translate(' + x + ', ' + y + ')';
      })
      .attr('stroke', 'none')
      .attr('fill', function(d) {
        return d.color;
      })
      .text(function(d) {
        return d.name;
      });
  },

  _getYAxisDom() {
    let yAxisDom = null;
    const isTrendChart = this.get('_isTrendChart');

    if(isTrendChart === true) {
      yAxisDom = this.$().children('.main');
    } else {
      yAxisDom = this.$();
    }

    return yAxisDom;
  },

  _replaceSeriesName() {

    const series = this.get('_chartData').series;
    const isTrendChart = this.get('_isTrendChart');
    const yAxisDom = this._getYAxisDom();
    let arrG = [];
    let name = '';

    arrG = yAxisDom.children('g[data-id=yAxisG]').children('g');

    for(let i=0; i < arrG.length; i++) {
      name = '';
      const seq = this.$(arrG[i]).children('text').text();

      for(let j=0; j < series.length; j++) {
        if(parseInt(seq) === series[j].no) {
          name = series[j].name;
          this.$(arrG[i]).children('text').text(name);
          break;
        }
      }
      // 트랜드 차트는 y축 텍스트를 변경할 때 일치하지 않는 것을 공백으로
      if(isTrendChart === true) {
        // 일치하지 않다면 공백으로 표시
        if(name === '') {
          this.$(arrG[i]).children('text').text('');
        }
      }
    }
  },

  _setCustomYAxis() {
    const yAxisDom = this._getYAxisDom();

    if(this.get('_chartData').isCustomYAxis) {
      const result = Ember.A();
      const arrG = yAxisDom.children('g[data-id=yAxisG]').children('g');

      for(let i=0; i < arrG.length; i++) {
        result.pushObject(this.$(arrG[i]).children('text').text());
      }

      this.set('_defaultYAxis', result);
    }
  },
  // 오늘날짜 표시
  _setNowBar() {
    const zero = 0;
    const isShowNowBar = this.get('_chartData').isShowNowBar;
    const isTrendChart = this.get('_isTrendChart');
    const adjustY = this.get('_settingPaddingTop');
    const el = this.$().get(zero);
    const timeFormat = this.get('_chartData').timeFormat

    if(isShowNowBar === true) {
      const now = this.get('co_CommonService').getNow();
      const xScaleFunction = this.get('_xScale');
      const xPoint = xScaleFunction(now);

      let todayRoot;

      if(isTrendChart) {
        todayRoot = d3.select(el)
          .select('g.main')
          .select('g.chartRoot')
          .append('g')
          .attr('class', 'chart todayRoot')
          .attr('data-id', 'todayRoot');
      } else {
        todayRoot = d3.select(el)
          .select('.chartRenderArea')
          .append('g')
          .attr('class', 'chart todayRoot')
          .attr('data-id', 'todayRoot');
      }

      todayRoot.append('line')
        .attr('x1', xPoint)
        .attr('y1', zero)
        .attr('x2', xPoint)
        .attr('y2', this.get('_height'))
        .attr('class', 'nowBar');

      todayRoot.append('svg:foreignObject')
        .html('<div class="now-bar-rect">Today</div>')
        .attr('x', function() {
          return xPoint - 30;
        })
        .attr('y', adjustY)
        .attr('width', 60)
        .attr('height', 20);
    }
    if(timeFormat) {
      const area = timeFormat.timePointer;
      if(area && area.length) {
        this._setTimeArea({
          // posy: adjustY,
          el: el,
          data: timeFormat.timePointer
        });
      }
    }
  },
  // 시간구역 설정
  _setTimeArea({el, data}) {
    const zero = 0;
    const dateFormat = this.get('_chartData').timeFormat.dataFormat;
    const isTrendChart = this.get('_isTrendChart');
    const isTimeXAxis = this.get('_chartData').isTimeXAxis;
    let areaRoot;
    if(data.length) {
      data.forEach((obj) => {
        const xScaleFunction = this.get('_xScale');
        const date = this._convertDateFormat(obj, isTimeXAxis);
        const xPoint = xScaleFunction(date);

        if(isTrendChart) {
          areaRoot = d3.select(el)
            .select('g.main')
            .select('g.chartRoot')
            .append('g')
            .attr('class', 'chart todayRoot')
            .attr('data-id', 'todayRoot');
        } else {
          areaRoot = d3.select(el)
            .select('g.chartRenderArea')
            .append('g')
            .attr('class', 'chart todayRoot')
            .attr('data-id', 'todayRoot');
        }

        areaRoot.append('line')
          .attr('x1', xPoint)
          .attr('y1', zero)
          .attr('x2', xPoint)
          .attr('y2', this.get('_height'))
          .attr('class', 'nowBar');

        areaRoot.append('svg:foreignObject')
          .html(`<div class="now-bar-rect">${this._convertDateString(date, dateFormat)}</div>`)
          .attr('x', function() {
            return xPoint - 50;
          })
          .attr('y', this.get('_settingPaddingTop'))
          .attr('width', 100)
          .attr('height', 20);
      });
    }
  },

  // 마우스 우측 드래그 확대
  _setChartRightDrag() {
    const svg = this._getD3Svg();
    const height = this.get('_height');
    const paddingLeft = this.get('_settingPaddingLeft');
    const transparentOpacity = 0.2;
    const xScaleFunction = this.get('_xScale');
    const minX = this.get('_minX');
    const maxX = this.get('_maxX');
    const two = 2;
    const zero = 0;

    svg.on('mousedown', () => {
      this._logTrace('[mousedown]');
      const button = d3.event.button;

      if(button === two) {
        if(d3.event.offsetX < paddingLeft ) {
          this.set('_mousedownOffsetX', null);
        } else {
          this.set('_mousedownOffsetX', d3.event.offsetX);
        }
      }
    })
    .on('mousemove', () => {
      this._logTrace('[mousemove]');
      const buttons = d3.event.buttons;
      if(buttons === two) {
        this._logTrace('[mousemove] d3.event.offsetX = ' + d3.event.offsetX);

        if(Ember.isEmpty(this.get('_mousedownOffsetX'))) {
          return;
        }
        this.set('_isMouseMove', true);

         // remove current rect
        svg.selectAll('rect[data-id=draggingRect').remove();

        const startX = this.get('_mousedownOffsetX');
        const endX = d3.event.offsetX;

        svg.append('rect')
          .attr('class', 'chart draggingRect')
          .attr('data-id', 'draggingRect')
          .style('opacity', transparentOpacity)
          .attr('x', function() {
            let result = startX;

            if(startX > endX) {
              result = endX;
            }

            return result;
          })
          .attr('y', zero)
          .attr('width', () => {
            const width = Math.abs(endX - startX);

            this._logTrace('width = ' + width);

            return width;
          })
          .attr('height', height);
        d3.event.preventDefault();
      }
    })
    .on('mouseup', () => {
      this._logTrace('[mousedown]');
      const button = d3.event.button;

      if(button === two) {
        if(Ember.isEmpty(this.get('_mousedownOffsetX'))) {
          return;
        }
        this.set('_isMouseMove', false);
        this.set('_mouseupOffsetX', d3.event.offsetX);

        if(this._allowValueDomain(this.get('_mousedownOffsetX'), this.get('_mouseupOffsetX'))) {
          // 초기화
          this.get('chartData').valueDomain = null;

          if(!Ember.isEmpty(this.get('_ccSeries'))) {
            const series = this.get('chartData').series;

            series.clear();

            for(let i=0; i < this.get('_ccSeries').length; i++) {
              series.pushObject(this.get('_ccSeries').objectAt(i));
            }
            this.set('_ccSeries', null);
          }
          // 호출자에 기간 변경 콜백
          this._raiseEvents('onPeriodChange', [minX, maxX]);
        } else {
          if(this.get('_mousedownOffsetX') > this.get('_mouseupOffsetX')) {
            const temp = this.get('_mouseupOffsetX');

            this.set('_mouseupOffsetX', this.get('_mousedownOffsetX'));
            this.set('_mousedownOffsetX', temp);
          }
          // remove current rect
          svg.selectAll('rect[data-id=draggingRect').remove();
          // 보다 작은 수
          let startX = xScaleFunction.invert(this.get('_mousedownOffsetX'));
          // 보다 큰 수
          let endX = xScaleFunction.invert(this.get('_mouseupOffsetX'));

          if(!(typeof startX === 'object' && startX instanceof Date)) {
            startX = Math.ceil(startX);
            endX = Math.floor(endX);
          }

          this.get('chartData').valueDomain = [startX, endX];

          // 호출자에 기간 변경 콜백
          this._raiseEvents('onPeriodChange', [startX, endX]);
        }

        this._reRenderChart();
        // 자식 시리즈 다시 그리게
        this.set('reload', !this.get('_reload'));
      }
    });
  },

  _reRenderChart() {
    this._removeAxis();
    this.$('g[data-id=todayRoot]').remove();
    this._renderChart();
  },

  _getIntervalType(min, max) {
    const thousand = 1000;
    const minutesPerHour = 60;
    const hourPerDay = 24;
    let result = 'month';
    const diff = max - min;
    const millisecondsPerDay = thousand * minutesPerHour * minutesPerHour * hourPerDay;
    const days = diff / millisecondsPerDay;

    // month, week, day, hour, minute
    if(days <= 0.05) {
      result = 'minute';
    } else if(days <= 2.5) {
      result = 'hour';
    } else if(days <= 32) {
      result = 'day';
    } else if(days <= 130) {
      result = 'week';
    } else if(days <= 720) {
      result = 'month';
    } else {
      result = 'year';
    }

    return result;
  },

  _getTickAndFormat(type) {
    const zero = 0;
    const items = this.get('_tickAndFormat');

    for(let i=0; i < items.length; i++) {
      if(items[i].type === type) {
        return items[i];
      }
    }

    // 기본값 리턴
    return items[zero];
  },

  _setSeriesOpacity(seriesNo, opacity) {
    // [ISSUE-EDGE] Object doesn't support property or method 'getElementsByClassName'
    // developer.microsoft.com/en-us/microsoft-edge/platform/issues/11729645
    this.$('.chart.line.series' + seriesNo).css('opacity', opacity);
    this.$('.chart.lineSymbol.series' + seriesNo).parent().css('opacity', opacity);
    this.$('.chart.bar.series' + seriesNo).css('opacity', opacity);
    this.$('.chart.minMax.series' + seriesNo).css('opacity', opacity);
    this.$('.chart.minMaxTopSymbol.series' + seriesNo).parent().css('opacity', opacity);
    this.$('.chart.minMaxBottomSymbol.series' + seriesNo).parent().css('opacity', opacity);
    this.$('.chart.pie.series' + seriesNo).css('opacity', opacity);
    this.$('.chart.pieText.series' + seriesNo).css('opacity', opacity);
    this.$('.chart.point.series' + seriesNo).parent().css('opacity', opacity);
    this.$('.chart.fromTo.series' + seriesNo).css('opacity', opacity);
    this.$('.chart.foreignObject.intersect.series'+ seriesNo).css('opacity', opacity);
    this.$('.chart.foreignObject.zoomin.series'+ seriesNo).css('opacity', opacity);

    this._setTooltipOpacity(seriesNo, opacity);
    this._setLegendOpacity(seriesNo, opacity);
  },

  _setTooltipOpacity(seriesNo, opacity) {
    this.$('.chart.lineTooltip.series' + seriesNo).css('opacity', opacity);
    this.$('.chart.barTooltip.series' + seriesNo).css('opacity', opacity);
    this.$('.chart.minMaxTopTooltip.series' + seriesNo).css('opacity', opacity);
    this.$('.chart.minMaxBottomTooltip.series' + seriesNo).css('opacity', opacity);
  },

  _showSeriesTooltip(seriesNo, isShow) {
    if(isShow) {
      this.$('.chart.lineTooltip.series' + seriesNo).show();
      this.$('.chart.barTooltip.series' + seriesNo).show();
      this.$('.chart.minMaxTopTooltip.series' + seriesNo).show();
      this.$('.chart.minMaxBottomTooltip.series' + seriesNo).show();
    } else {
      this.$('.chart.lineTooltip.series' + seriesNo).hide();
      this.$('.chart.barTooltip.series' + seriesNo).hide();
      this.$('.chart.minMaxTopTooltip.series' + seriesNo).hide();
      this.$('.chart.minMaxBottomTooltip.series' + seriesNo).hide();
    }
  },

  _setLegendOpacity(seriesNo, opacity) {
    this.$('.chart.legendG.series' + seriesNo).css('opacity', opacity);
    this.$('.chart.legendText.series' + seriesNo).css('opacity', opacity);
    ////this.$('.chart.legendRect.series' + seriesNo).css('opacity', opacity);
  },

  // 선택한 와이축 활성화
  _setCurrentYAxis(series, isSet) {
    if(!this.get('_yAxis')) {
      return;
    }
    const el = this.$().get(0);
    const selectAxis = this.get('_yAxis').filter(obj => {
      return JSON.stringify(obj.series) === JSON.stringify(series);
    });
    if(selectAxis.length) {
      d3.select(el)
        .selectAll(`[data-position=y-${selectAxis[0].position}]`)
        .style('opacity', 0);
      d3.select(el)
        .select(`[data-series=y-${selectAxis[0].position}-${selectAxis[0].series.no}]`)
        .style('opacity', 1);
    }

    if(series.isCustomYAxis === true) {
      if(isSet === true) {
        const currentYAxis = this._getCurrentYAxis();
        this.set('_currentYAxis', currentYAxis);
      }
    }
  },

  _getCurrentYAxis() {
    const result = Ember.A();
    const yAxisDom = this._getYAxisDom();
    const arrG = yAxisDom.children('g[data-id=yAxisG]').children('g').children('text');

    for(let i=0; i < arrG.length; i++) {
      result.pushObject(this.$(arrG[i]).text());
    }

    return result;
  },

  _replaceYAxisText(source) {
    const yAxisDom = this._getYAxisDom();
    const target = yAxisDom.children('g[data-id=yAxisG]').children('g').children('text');
    // const yAxisG = yAxisDom.children('g[data-id=yAxisG]');
    if (this.get('_yAxis').length === 1) {
      for(let i=0; i < target.length; i++) {
        this.$(target[i]).text(source[i]);
      }
    }
  },

  _onlyOneChecked() {
    const one = 1;
    let result = false;
    const selectedLegendRect = this.get('_selectedLegendRect');
    const allSeries = this.get('_chartData').series;

    // 여러개 중에, 1개 선택됨
    if(allSeries.length > one && selectedLegendRect.length === one) {
      result = true;
    }

    this.set('_onlyOne', result);

    return result;
  },

  _selectLegendRect(series) {
    const zero = 0;
    const one = 1;
    const seriesNo = series.no;
    const selectedLegendRect = this.get('_selectedLegendRect');
    const selectedLegendRectForYAxis = this.get('_selectedLegendRectForYAxis');
    let isSelected = false;

    if(selectedLegendRect.includes(seriesNo)) {
      for(let i=selectedLegendRect.length - one; i >= zero; i--) {
        if(selectedLegendRect[i] === seriesNo) {
          selectedLegendRect.removeObject(selectedLegendRect[i]);
          isSelected = false;
          break;
        }
      }
    } else {
      selectedLegendRect.pushObject(seriesNo);
      isSelected = true;
    }

    if(selectedLegendRectForYAxis.includes(seriesNo)){
      for(let i=selectedLegendRectForYAxis.length - one; i >= zero; i--) {
        if(selectedLegendRectForYAxis[i] === seriesNo) {
          selectedLegendRectForYAxis.removeObject(selectedLegendRectForYAxis[i]);
          break;
        }
      }
    } else {
      selectedLegendRectForYAxis.pushObject(seriesNo);
    }

    this._setDisplaySeriesAll(series);
    this._setSelectedYAxis(series);

    const currentOpacity = parseFloat(this.$('.chart.legendText.series' + seriesNo).css('opacity'));
    const selectedLegendRectForNormal = this.get('_selectedLegendRectForNormal');
    let isUpdated = false;

    for(let i = 0; i < selectedLegendRectForNormal.length; i++) {
      if(selectedLegendRectForNormal[i].seriesNo === seriesNo) {
        isUpdated = true;
        selectedLegendRectForNormal[i].opacity = currentOpacity;
        break;
      }
    }
    if(isUpdated === false){
      selectedLegendRectForNormal.pushObject({ seriesNo: seriesNo, opacity: currentOpacity});
    }

    this._raiseEvents('onSelectedSeriesChange', { seriesNo: seriesNo, isSelected: isSelected});
  },

  _setDisplaySeriesAll(series) {
    const zero = 0;
    const seriesNo = series.no;
    const transparentOpacity = this.get('_settingTransparentOpacity');
    const normalOpacity = this.get('_settingNormalOpacity');
    const chartData = this.get('_chartData');
    const allSeries = chartData.series;
    const selectedLegendRect = this.get('_selectedLegendRect');
    const selectedLegendSymbol = this.get('_selectedLegendSymbol');

    // 상태 변경된 아이템
    const el = this.$().get(zero);
    const legendLabel = d3.select(el)
      .selectAll('.chart.legendG.series' + seriesNo)
      ////.selectAll('text');
      .selectAll('.legendText');

    if(selectedLegendRect.includes(seriesNo)) {
      legendLabel.classed('selectedLegend', true);
    } else {
      legendLabel.classed('selectedLegend', false);
    }

    this._onlyOneChecked();

    // 하나만 있다면, 그것을 제외한 모든 것을 투명하게 처리
    if(this.get('_onlyOne') === true) {
      for(let i = 0; i < allSeries.length; i++) {
        const tempSeriesNo = allSeries[i].no;

        if(selectedLegendRect.includes(tempSeriesNo)) {
          this._setSeriesOpacity(tempSeriesNo, normalOpacity);

          if(selectedLegendSymbol.includes(tempSeriesNo)) {
            this._showSeriesTooltip(tempSeriesNo, false);
          } else {
            this._showSeriesTooltip(tempSeriesNo, true);
          }
        } else {
          this._setSeriesOpacity(tempSeriesNo, transparentOpacity);
          this._showSeriesTooltip(tempSeriesNo, false);
        }
      }
    } else {
      // 선택된 것이 하나도 없다면 모두 표시
      if(selectedLegendRect.length === zero) {
        for(let i = 0; i < allSeries.length; i++) {
          const tempSeriesNo = allSeries[i].no;

          this._setSeriesOpacity(tempSeriesNo, normalOpacity);
          this._showSeriesTooltip(tempSeriesNo, false);
        }
      } else {
        // 변경된 것만 처리
        if(selectedLegendRect.includes(seriesNo)) {
          this._setSeriesOpacity(seriesNo, normalOpacity);

          if(selectedLegendSymbol.includes(seriesNo)) {
            this._showSeriesTooltip(seriesNo, false);
          } else {
            this._showSeriesTooltip(seriesNo, true);
          }
        } else {
          this._setSeriesOpacity(seriesNo, transparentOpacity);
          this._showSeriesTooltip(seriesNo, false);
        }
      }
    }
  },

  _setSelectedYAxis(series) {
    const zero = 0;
    const one = 1;
    const selectedLegendForYAxis = this.get('_selectedLegendRectForYAxis');

    if(selectedLegendForYAxis === null || selectedLegendForYAxis.length === zero) {
      this._setDefaultYAxis();
    } else {
      const lastSelectedNo = selectedLegendForYAxis[selectedLegendForYAxis.length - one];
      const lastSeries = this._getSeriesByNo(lastSelectedNo);

      if(lastSeries.isCustomYAxis === true) {
        this._setCurrentYAxis(lastSeries, true);
      } else {
        this._setDefaultYAxis();
      }
    }
  },

  _getSeriesByNo(seriesNo) {
    const series = this.get('_chartData').series;

    for(let i = 0; i < series.length; i++) {
      if(series[i].no === seriesNo) {
        return series[i];
      }
    }
  },

  _setDefaultYAxis() {
    this.set('_currentYAxis', Ember.copy(this.get('_defaultYAxis'), true));
  },

  _selectSeriesSymbol(series) {
    const zero = 0;
    const one = 1;
    const seriesNo = series.no;
    const selectedLegendSymbol = this.get('_selectedLegendSymbol');
    let isSelected = false;

    // 없으면 추가, 있으면 제거
    if(selectedLegendSymbol.includes(seriesNo)) {
      for(let i=selectedLegendSymbol.length - one; i >= zero ; i--) {
        if(selectedLegendSymbol[i] === seriesNo) {
          selectedLegendSymbol.removeObject(selectedLegendSymbol[i]);
          isSelected = false;
          break;
        }
      }
    } else {
      selectedLegendSymbol.pushObject(seriesNo);
      isSelected = true;
    }

    this._setOpacityLegendSymbol(series);
    this._setDisplaySeries(series);

    this._raiseEvents('onSelectedSymbolChange', { seriesNo: seriesNo, isSelected: isSelected});
  },

  _setOpacityLegendSymbol(series) {
    const seriesNo = series.no;
    const transparentOpacity = this.get('_settingTransparentOpacity');
    const normalOpacity = this.get('_settingNormalOpacity');
    const selectedLegendSymbol = this.get('_selectedLegendSymbol');

    if(selectedLegendSymbol.includes(seriesNo)) {
      this.$('.chart.legendSymbol.series' + seriesNo).parent().css('opacity', transparentOpacity);
    } else {
      this.$('.chart.legendSymbol.series' + seriesNo).parent().css('opacity', normalOpacity);
    }
  },

  _setDisplaySeries(series) {
    const seriesNo = series.no;
    const selectedLegendSymbol = this.get('_selectedLegendSymbol');
    const selectedLegendRect = this.get('_selectedLegendRect');

    // 포함되면 숨기기
    if(selectedLegendSymbol.includes(seriesNo)) {
      this._showSeries(seriesNo, false);
      this._showSeriesTooltip(seriesNo, false);
    } else {
      this._showSeries(seriesNo, true);

      // 현재 선택된 rect 라면 tooltip 표시
      if(selectedLegendRect.includes(seriesNo)) {
        this._showSeriesTooltip(seriesNo, true);
      } else {
        this._showSeriesTooltip(seriesNo, false);
      }
    }
  },

  _showSeries(seriesNo, isShow) {
    if(isShow) {
      this.$('.chart.line.series' + seriesNo).show();
      this.$('.chart.lineSymbol.series' + seriesNo).show();
      this.$('.chart.bar.series' + seriesNo).show();
      this.$('.chart.minMax.series' + seriesNo).show();
      this.$('.chart.minMaxTopSymbol.series' + seriesNo).show();
      this.$('.chart.minMaxBottomSymbol.series' + seriesNo).show();
      this.$('.chart.pie.series' + seriesNo).show();
      this.$('.chart.pieText.series' + seriesNo).show();
      this.$('.chart.point.series' + seriesNo).show();
      this.$('.chart.fromTo.series' + seriesNo).show();
      this.$('.chart.foreignObject.intersect.series'+ seriesNo).show();
      this.$('.chart.foreignObject.zoomin.series'+ seriesNo).show();
    } else {
      this.$('.chart.line.series' + seriesNo).hide();
      this.$('.chart.lineSymbol.series' + seriesNo).hide();
      this.$('.chart.bar.series' + seriesNo).hide();
      this.$('.chart.minMax.series' + seriesNo).hide();
      this.$('.chart.minMaxTopSymbol.series' + seriesNo).hide();
      this.$('.chart.minMaxBottomSymbol.series' + seriesNo).hide();
      this.$('.chart.pie.series' + seriesNo).hide();
      this.$('.chart.pieText.series' + seriesNo).hide();
      this.$('.chart.point.series' + seriesNo).hide();
      this.$('.chart.fromTo.series' + seriesNo).hide();
      this.$('.chart.foreignObject.intersect.series'+ seriesNo).hide();
      this.$('.chart.foreignObject.zoomin.series'+ seriesNo).hide();
    }
  },

  _addToChartData(newSeries) {
    this.get('chartData').series.pushObject(newSeries);
  },

  _removeToChartDataByNo(seriesNo) {
    const chartData = this.get('chartData');
    let target = null;

    for(let i=0; i < chartData.series.length; i++) {
      if(chartData.series[i].no === seriesNo) {
        target = chartData.series[i];
        break;
      }
    }
    chartData.series.removeObject(target);
  },

  _moveToLast(parentObj, childObj) {
    childObj.appendTo(parentObj);
  },

  _moveToFirst(parentObj, childObj) {
    childObj.prependTo(parentObj);
  },

  actions: {

    completeProcessing(dataId) {
      this._logTrace('c-chart-svg.completeProcessing()');
      const chartData = this.get('_chartData');

      if(Ember.isEmpty(chartData)) {
        return;
      }

      this._replaceSeriesName();
      this._setCustomYAxis();

      const parentObj = this.$();
      const childObj = this.$('g[data-id=\'' + dataId + '\']');

      // legend 를 끝으로
      this._moveToLast(parentObj, childObj);

      const yAxis = this.$('g[data-id=yAxisG]');
      const xAxis = this.$('g[data-id=xAxisG]');
      const pane = this.$('rect.pane');

      this._moveToFirst(parentObj, yAxis);
      this._moveToFirst(parentObj, xAxis);
      this._moveToFirst(parentObj, pane);
    },

    mouseoverSeries(series) {
      console.log('_isMouseMove', this.get('_isMouseMove'));
      if(this.get('_isMouseMove')) {
        return;
      }
      const seriesNo = series.no;
      const transparentOpacity = this.get('_settingTransparentOpacity');
      const normalOpacity = this.get('_settingNormalOpacity');
      const selectedLegendRect = this.get('_selectedLegendRect');
      const selectedLegendSymbol = this.get('_selectedLegendSymbol');

      if(selectedLegendRect.includes(seriesNo) === true) {
        return;
      }

      const currentOpacity = parseFloat(this.$('.chart.legendText.series' + seriesNo).css('opacity'));
      const selectedLegendRectForNormal = this.get('_selectedLegendRectForNormal');

      let isUpdated = false;

      for(let i = 0; i < selectedLegendRectForNormal.length; i++) {
        if(selectedLegendRectForNormal[i].seriesNo === seriesNo) {
          isUpdated = true;
          selectedLegendRectForNormal[i].opacity = currentOpacity;
          break;
        }
      }
      if(isUpdated === false) {
        selectedLegendRectForNormal.pushObject({ seriesNo: seriesNo, opacity: currentOpacity});
      }

      this._setSeriesOpacity(seriesNo, normalOpacity);

      if(selectedLegendSymbol.includes(seriesNo) === false) {
        this._showSeriesTooltip(seriesNo, true);
      }

      if(!selectedLegendRect.length) {
        const allSeries = this.get('_chartData').series;

        for(let i=0; i < allSeries.length; i++) {
          if(allSeries[i].no !== seriesNo) {
            this._setSeriesOpacity(allSeries[i].no, transparentOpacity);
          }
        }
      }

      // y 축 변경
      this._setCurrentYAxis(series, true);
    },

    mouseoutSeries(series) {
      const seriesNo = series.no;
      const normalOpacity = this.get('_settingNormalOpacity');
      let opacity = normalOpacity;
      const selectedLegendRect = this.get('_selectedLegendRect');
      const zero = 0;

      if(selectedLegendRect.includes(seriesNo) === true) {
        return;
      }

      const selectedLegendRectForNormal = this.get('_selectedLegendRectForNormal');

      for(let i = 0; i < selectedLegendRectForNormal.length; i++) {
        if(selectedLegendRectForNormal[i].seriesNo === seriesNo) {
          opacity = selectedLegendRectForNormal[i].opacity;
          break;
        }
      }

      this._setSeriesOpacity(seriesNo, opacity);

      if(selectedLegendRect.length === zero) {
        const allSeries = this.get('_chartData').series;

        for(let i=0; i < allSeries.length; i++) {
          this._setSeriesOpacity(allSeries[i].no, normalOpacity);
        }
      }

      this._showSeriesTooltip(seriesNo, false);

      // y 축 변경
      if(series.isCustomYAxis === true) {
        const currentYAxis = this.get('_currentYAxis');

        this._replaceYAxisText(currentYAxis);
      }
    },

    selectLegendRect(series) {
      this._selectLegendRect(series);
    },

    selectLegendSymbol(series) {
      this._selectSeriesSymbol(series);
    },

    clickRemoveSeries(sereisNo) {
      this._raiseEvents('onRemoveSeriesClick', sereisNo);
    },

    changeCollapsibleLegend(isCollapsed) {
      const chartData = this.get('_chartData');
      const isCollapsibleLegend = chartData.isCollapsibleLegend;

      if(isCollapsibleLegend === true) {
        chartData.isCollapseLegendPane = isCollapsed;
      }
      this._raiseEvents('onLegendCollapse', isCollapsed);
    },

    clickData(obj) {
      this._raiseEvents('onDataSelect', obj);
    },
  },
});