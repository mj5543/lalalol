import Ember from 'ember';
import layout from './template';
import ValidationControl from '../c-validationcontrol/component';

export default ValidationControl.extend({
  layout,
  classNames: ['c-autocomplete', 'c-inp-txt'],
  tagName: 'div',
  //public properties
  style: null,
  value: null,
  itemsSource: null,
  enableMultipleFilter: false,
  enableIncompleteValue: false,
  maxDropDownWidth: null,
  maxDropDownHeight: null,
  selectedValuePath: null,
  displayMemberPath: null,
  searchMemberPaths: null,
  selectedItem: null,
  showDropDownLoader: false,
  tabindex: null,
  placeHolder: 'Enter keyword',
  disabled: false,
  readOnly: false,
  enableGotFocusAutoSelect: false,
  showClearButton: false,
  required: false,
  showValidationSuccess: false,
  externalErrorMessage: null,
  validationRules: null,
  useParentWormhole: true,
  placeInArea: false,
  //public events
  onLoaded: null,
  onUnload: null,
  onClick: null,
  onFocusIn: null,
  onFocusOut: null,
  onKeyPress: null,
  onKeyUp: null,
  onKeyDown: null,
  onChanged: null,
  onTextCleared: null,
  onFilterChanged: null,
  //public readonly Properties
  filterValue: Ember.computed.readOnly('_filterValue'),

  _beforeValue: null,
  _ignoreChange: false,
  _debounceImmediate: null,
  _autocompleteGuid: Ember.computed.readOnly('componentGuid'),
  _notReadOnly: Ember.computed.not('readOnly'),
  _showClearButtonAndNotReadOnly: Ember.computed.and('showClearButton', '_notReadOnly'),
  _isAttrsSelectedItem: Ember.computed(function () {
    return !Ember.isNone(this.attrs.selectedItem);
  }).readOnly(),
  _displayMemberPath: Ember.computed('enableIncompleteValue', 'selectedValuePath', 'displayMemberPath', function () {
    let displayMemberPath = this.get('displayMemberPath');

    if (Ember.isNone(displayMemberPath)) {
      displayMemberPath = this.get('selectedValuePath');
    }

    return displayMemberPath;
  }).readOnly(),
  _isAutocompleteDefault: Ember.computed('enableIncompleteValue', 'selectedValuePath', 'displayMemberPath', function () {
    const enableIncompleteValue = this.get('enableIncompleteValue'), selectedValuePath = this.get('selectedValuePath'), displayMemberPath = this.get('displayMemberPath');

    return enableIncompleteValue || Ember.isNone(displayMemberPath) || selectedValuePath === displayMemberPath;
  }).readOnly(),
  _internalValue: Ember.computed('value', {
    get (key) {
      const value = this.get('value');

      return Ember.isNone(value) ? '' : value;
    },
    set (key, value) {
      if (!this.get('_ignoreChange')) {
        this.set('_debounceImmediate', Ember.run.debounce(this, '_filterChange', value, 250));
      }

      return value;
    },
  }),
  _observedProperty1: Ember.computed('itemsSource.[]', function () {
    let itemsSource = this.get('itemsSource');

    if (!Ember.isArray(itemsSource)) {
      itemsSource = Ember.A();
    }
    Ember.run.once(this, '_syncInternalSelectedItem');
    this.set('_itemsSource', itemsSource);
  }).readOnly(),
  _observedProperty2: Ember.computed('selectedItem', function () {
    Ember.run.once(this, '_syncSelectedValue');
  }).readOnly(),
  _observedProperty3: Ember.computed('value', function () {
    Ember.run.once(this, '_syncSelectedItem');
    Ember.run.once(this, '_valueChanged');
  }).readOnly(),
  _observedProperty4: Ember.computed('value', function () {
    Ember.run.once(this, '_syncInternalSelectedItem');
    Ember.run.once(this, '_valueChanged');
  }).readOnly(),
  _filteredItemsSource: Ember.computed('_itemsSource.[]', '_internalValue', 'selectedValuePath', 'displayMemberPath', function () {
    const _itemsSource = this.get('_itemsSource'), _internalValue = this.get('_internalValue'), _displayMemberPath = this.get('_displayMemberPath');

    if (typeof _internalValue === 'string') {
      try {
        return _itemsSource.filter(function (item) {
          return new RegExp(_internalValue.split('').join('[, ]*'), 'gi').test(Ember.get(item, _displayMemberPath));
        });
      } catch (exception) {}
    }
  }).readOnly(),
  _multipleFilteredItemsSource: Ember.computed('_itemsSource.[]', '_internalValue', 'searchMemberPaths.[]', function () {
    const _itemsSource = this.get('_itemsSource'), _internalValue = this.get('_internalValue'), searchMemberPaths = this.get('searchMemberPaths');

    if (Ember.isArray(searchMemberPaths)) {
      const filteredItemsSource = Ember.A();

      if (typeof _internalValue === 'string') {
        searchMemberPaths.forEach(function (filter) {
          try {
            filteredItemsSource.addObjects(_itemsSource.filter(function (item) {
              return new RegExp(_internalValue.split('').join('[, ]*'), 'gi').test(Ember.get(item, filter));
            }));
          } catch (exception) {}
        });
      }

      return filteredItemsSource.uniq();
    }
  }).readOnly(),
  init() {
    this._super(...arguments);
    if (!this.get('_isAutocompleteDefault')) {
      Ember.defineProperty(this, '_internalValue',Ember.computed('displayMemberPath', 'selectedItem', {
        get (key) {
          const displayMemberPath = this.get('displayMemberPath'), selectedItem = this.get('selectedItem');
          return Ember.isNone(selectedItem) ? '' : Ember.get(selectedItem, displayMemberPath);
        },
        set (key, value) {
          if (!this.get('_ignoreChange')) {
            this.set('_debounceImmediate', Ember.run.debounce(this, '_filterChange', value, 250));
          }
          return value;
        },
      }));
    }
  },
  click(event) {
    this._raiseEvents('onClick', {
      source: this,
      originalEvent: event
    });
  },
  focusIn(event) {
    if (this.get('enableGotFocusAutoSelect')) {
      this.$('input').select();
    }
    this._raiseEvents('onFocusIn', {
      source: this,
      originalEvent: event
    });
  },
  focusOut(event) {
    const currentText = this.get('_internalValue');
    let item = this._findMatchItem(currentText);

    if (this.get('enableIncompleteValue')) {
      this._syncDataValue(currentText, item);
    } else {
      const _displayMemberPath = this.get('_displayMemberPath');

      if (Ember.isNone(item)) {
        if (!Ember.isEmpty(currentText)) {
          item = this.get('selectedItem');
        }
        if (!Ember.isNone(item)) {
          this._syncDataValue(Ember.get(item, _displayMemberPath), item);
        } else {
          this._syncDataValue('', item);
        }
      } else {
        this._syncDataValue(Ember.get(item, _displayMemberPath), item);
      }
    }
    this._raiseEvents('onFocusOut', {
      source: this,
      originalEvent: event
    });
  },
  keyPress(event) {
    if (event.keyCode === 13) {
      event.preventDefault();
      const currentText = this.get('_internalValue');
      let item = this._findMatchItem(currentText);

      if (this.get('enableIncompleteValue')) {
        this._syncDataValue(currentText, item);
      } else {
        const _displayMemberPath = this.get('_displayMemberPath');

        if (Ember.isNone(item)) {
          if (!Ember.isEmpty(currentText)) {
            item = this.get('selectedItem');
          }
          if (!Ember.isNone(item)) {
            this._syncDataValue(Ember.get(item, _displayMemberPath), item);
          } else {
            this._syncDataValue('', item);
          }
        } else {
          this._syncDataValue(Ember.get(item, _displayMemberPath), item);
        }
      }
    }
    this._raiseEvents('onKeyPress', {
      source: this,
      originalEvent: event
    });
  },
  keyUp(event) {
    this._raiseEvents('onKeyUp', {
      source: this,
      originalEvent: event
    });
  },
  keyDown(event) {
    if (event.keyCode === 40) {
      if (this.get('isOpen')) {
        event.stopPropagation();
        event.preventDefault();
        const $items = Ember.$(`.${this.get('_autocompleteGuid')}-itemspanel:not(.disabled) li[data-item]`);

        if ($items.length > 0) {
          const index = $items.index($items.filter('.on')) + 1;

          if (index < $items.length) {
            $items.removeClass('on');
            $items.eq(index).addClass('on');
            if ($items.eq(index).prev().length > 0) {
              this._setItemspanelScrollTop($items.eq(index).prev().offset().top + $items.eq(index).closest('div.scrollbar-macosx').scrollTop() - $items.eq(index).closest('div.scrollbar-macosx').offset().top);
            }
          }
        }
      } else {
        event.stopPropagation();
        event.preventDefault();
        this.set('isOpen', true);
      }
    }
    if (event.keyCode === 38) {
      if (this.get('isOpen')) {
        event.stopPropagation();
        event.preventDefault();
        const $items = Ember.$(`.${this.get('_autocompleteGuid')}-itemspanel:not(.disabled) li[data-item]`);

        if ($items.length > 0) {
          const index = $items.index($items.filter('.on')) - 1;

          if (0 <= index) {
            $items.removeClass('on');
            $items.eq(index).addClass('on');
            if ($items.eq(index).prev().length > 0) {
              this._setItemspanelScrollTop($items.eq(index).prev().offset().top + $items.eq(index).closest('div.scrollbar-macosx').scrollTop() - $items.eq(index).closest('div.scrollbar-macosx').offset().top);
            }
          }
        }
      }
    }
    if (event.keyCode === 13) {
      if (this.get('isOpen')) {
        event.stopPropagation();
        event.preventDefault();
        const $items = Ember.$(`.${this.get('_autocompleteGuid')}-itemspanel:not(.disabled) li[data-item]`), $currentItem = $items.filter('.on');

        if ($currentItem.length > 0) {
          $currentItem.trigger('click');
        } else {
          const currentText = this.get('_internalValue');
          let item = this._findMatchItem(currentText);

          if (this.get('enableIncompleteValue')) {
            this._syncDataValue(currentText, item);
          } else {
            const _displayMemberPath = this.get('_displayMemberPath');

            if (Ember.isNone(item)) {
              if ($items.length === 1 && !Ember.isEmpty(currentText)) {
                $items.trigger('click');
              } else {
                if (!Ember.isEmpty(currentText)) {
                  item = this.get('selectedItem');
                }
                if (!Ember.isNone(item)) {
                  this._syncDataValue(Ember.get(item, _displayMemberPath), item);
                } else {
                  this._syncDataValue('', item);
                }
              }
            } else {
              this._syncDataValue(Ember.get(item, _displayMemberPath), item);
            }
          }
        }
      }
    }
    this._raiseEvents('onKeyDown', {
      source: this,
      originalEvent: event
    });
  },
  _syncInternalSelectedItem() {
    if (!this.get('_isAutocompleteDefault') && !this.get('_isAttrsSelectedItem')) {
      const selectedValuePath = this.get('selectedValuePath'), _itemsSource = this.get('_itemsSource'), value = this.get('value');
      const selectedItem = this.get('selectedItem');

      if (Ember.isArray(_itemsSource) && !Ember.isNone(value) && !Ember.isNone(selectedItem) && Ember.get(selectedItem, selectedValuePath) !== value) {
        this.set('selectedItem', _itemsSource.findBy(selectedValuePath, value));
      } else if (Ember.isArray(_itemsSource) && !Ember.isNone(value) && Ember.isNone(selectedItem)) {
        this.set('selectedItem', _itemsSource.findBy(selectedValuePath, value));
      } else if (Ember.isNone(value) && !Ember.isNone(selectedItem)) {
        this.set('selectedItem', null);
      }
    }
  },
  _syncSelectedValue() {
    const selectedItem = this.get('selectedItem'), selectedValuePath = this.get('selectedValuePath');
    const value = this.get('value'), selectedValue = Ember.isNone(selectedItem) ? null : Ember.get(selectedItem, selectedValuePath);

    if ((!Ember.isNone(value) && !Ember.isNone(selectedValue) && value !== selectedValue) || (Ember.isNone(value) && !Ember.isNone(selectedValue))) {
      this.set('value', selectedValue);
    } else if (!Ember.isNone(value) && Ember.isNone(selectedValue)) {
      this.set('value', null);
    }
  },
  _syncSelectedItem() {
    const selectedItem = this.get('selectedItem'), selectedValuePath = this.get('selectedValuePath');
    const value = this.get('value'), selectedValue = Ember.isNone(selectedItem) ? null : Ember.get(selectedItem, selectedValuePath);

    if ((!Ember.isNone(value) && !Ember.isNone(selectedValue) && value !== selectedValue) || (!Ember.isNone(value) && Ember.isNone(selectedValue))) {
      this.set('selectedItem', this.get('_itemsSource').findBy(selectedValuePath, value));
    } else if (Ember.isNone(value) && !Ember.isNone(selectedValue)) {
      this.set('selectedItem', null);
    }
  },
  _valueChanged() {
    const value = this.get('value'), _beforeValue = this.get('_beforeValue');
    const item = this.get('_isAttrsSelectedItem') ? this.get('selectedItem') : this.get('_itemsSource').findBy(this.get('selectedValuePath'), value);

    if (_beforeValue !== value) {
      this.set('_beforeValue', value);
      this._raiseEvents('onValueChanged', {
        source: this,
        value: value,
        item: item
      });
    }
  },
  _setItemspanelScrollTop(y) {
    const $itemspanel = Ember.$(`.${this.get('_autocompleteGuid')}-itemspanel > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx`);
    if ($itemspanel.length > 0) {
      $itemspanel.scrollTop(y);
    }
  },
  _syncDataValue(currentText, item) {
    const selectedValuePath = this.get('selectedValuePath'), enableIncompleteValue = this.get('enableIncompleteValue');
    let before = null, after = null;

    before = this.get('value');
    this.set('_ignoreChange', true);
    Ember.run.cancel(this.get('_debounceImmediate'));
    this.set('isOpen', false);
    if (enableIncompleteValue) {
      this.set('value', currentText);
    } else if (!Ember.isNone(item)) {
      this.set('value', Ember.get(item, selectedValuePath));
    } else {
      this.set('value', null);
    }
    this.set('selectedItem', item);
    after = this.get('value');
    Ember.run.schedule('afterRender', this, function () {
      if (!this.get('isDestroying') && !this.get('isDestroyed')) {
        this.set('_internalValue', currentText);
        //this.$('input').val(_internalValue);
      }
      currentText = null;
    });
    Ember.run.next(this, function () {
      if (!this.get('isDestroying') && !this.get('isDestroyed')) {
        this.set('_ignoreChange', false);
      }
    });
    if (before !== after) {
      this._raiseEvents('onChanged', {
        source: this,
        originalEvent: event,
        value: after,
        item: item
      });
    }
  },
  _findMatchItem(currentText) {
    let item = null;

    if (!Ember.isEmpty(currentText)) {
      const _itemsSource = this.get('_itemsSource'), enableMultipleFilter = this.get('enableMultipleFilter');

      if (enableMultipleFilter) {
        const searchMemberPaths = this.get('searchMemberPaths');

        for (let i = 0; i < searchMemberPaths.length; i++) {
          item = _itemsSource.findBy(searchMemberPaths[i], currentText);
          if (!Ember.isNone(item)) {
            break;
          }
        }
      } else {
        const _displayMemberPath = this.get('_displayMemberPath');

        item = _itemsSource.findBy(_displayMemberPath, currentText);
      }
    }

    return item;
  },
  _filterChange(value) {
    if (!this.get('isDestroying') && !this.get('isDestroyed')) {
      this.set('isOpen', true);
      this.set('_filterValue', value);
      this._raiseEvents('onFilterChanged', {
        source: this,
        filterValue: this.get('filterValue'),
      });
    }
  },
  actions: {
    delMouseDown(event) {
      event.preventDefault();
      this.set('_internalValue', '');
      this._raiseEvents('onTextCleared', {
        source: this,
        originalEvent: event
      });
    },
    itemClick(item) {
      const _displayMemberPath = this.get('_displayMemberPath');

      this._syncDataValue(Ember.get(item, _displayMemberPath), item);
    },
  },
});