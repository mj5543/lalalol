import Ember from 'ember';
import layout from './template';
import Togglebase from '../fr-togglebase/component';
export default Togglebase.extend({
  layout,
  checked : false,
  classNames : ['fr-switch'],
  tagName: 'div',
  type: 'checkbox',
  _onCheckChanged(){
    this._onRaiseChanged(this.get('checked') ) ;
  },
  _onclick() {
    this.set('checked', !this.get('checked'));
  },
  didInsertElement(){
    this._super(...arguments);
    const tabIndex = this.$().attr('tabindex') ;
    this.$('input[type=checkbox]')
      .on('click.checkbox', this._onclick.bind(this))
      .attr('tabindex', -1);
  },
  willDestroyElement(){
    this._super(...arguments);
    this.$('input[type=checkbox]').off('click.checkbox')
      .next()
      .off('mousedown')
      .off('click');
  },
  actions: {
    onLabelClickAction(e) {
      e.stopPropagation();
    }
  }
});