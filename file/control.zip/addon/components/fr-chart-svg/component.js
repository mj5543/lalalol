import Ember from 'ember';
import layout from './template';
import Control from '../fr-control/component';
import GlobalServiceContainerMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

export default Control.extend(GlobalServiceContainerMixin, StatefulComponentMixin, {
  layout,

  tagName: 'svg',
  attributeBindings: ['width', 'height'],
  classNames: ['fr-chart-svg'],

  actionMode: null,
  addSeries: null,
  chartData: null,
  reload: null,
  height: null,
  removeSeriesNo: null,
  trace: null,
  width: null,

  _addSymbolSize: null,
  _brush: null,
  _clickedLegendRect: null,
  // 현재 활성화된 y 축
  _currentYAxis: null,
  // 차트 데이터의 기본 y 축
  _defaultYAxis: null,
   // 그룹 레전 일 경우에 그룹명까지 포함된 데이터
  _groupLegend: null,
  _groupLegendWidth: null,
  _isCollapsed: null,
  // json 데이터 평가 결과
  _isValidData: null,
  _lineLeading: null,
  _maxX: null,
  _maxY: null,
  _miniXScale: null,
  _minX: null,
  _minY: null,
  _onlyOne: null,
  _parentType: null,
  _postfixFrom: null,
  _postfixMax: null,
  _postfixMin: null,
  _postfixTo: null,
  _rect: null,
  _selectedLegendRect: null,
  _selectedLegendRectForNormal: null,
  _selectedLegendRectForYAxis: null,
  _selectedLegendSymbol: null,
  _symbolMulple: null,
  _tickAndFormat: null,
  _violateProperty: null,
  _xAxis: null,
  _xScale: null,
  _yAxis: null,
  _yScale: null,
  _zoom: null,
  _setting: null,
  _ccSeries: null,
  _browserType: null,

  _chartData: Ember.computed.alias('chartData').readOnly(),
  _reload: Ember.computed.alias('reload').readOnly(),
  _trace: Ember.computed.alias('trace').readOnly(),
  _width: Ember.computed.alias('width').readOnly(),

  _height: Ember.computed('height', '_setting', function() {
    return this.get('height') - this.get('_settingPaddingBottom');
  }),
  _changedData: Ember.computed('actionMode', function() {
    if(Ember.isEmpty(this.get('actionMode'))) {
      return false;
    } else {
      return true;
    }
  }),
  _hasSeries: Ember.computed('_chartData', function() {
    //this._logTrace('fr-chart-svg._hasSeries');
    let result = false;
    const data = this.get('_chartData');
    const zero = 0;

    if(!Ember.isEmpty(data) && data.series.length > zero) {
      result = true;
    }

    return result;
  }),
  _isTrendChart: Ember.computed('_chartData', function() {
    if(Ember.isEmpty(this.get('_chartData'))) {
      return false;
    }
    // point 시리즈를 일반 차트에 표시하기 위해
    // // let series = this.get('_chartData').series;
    // // for(let i=0; i < series.length; i++) {
    // //   if(series[i].config.type === 'point' || series[i].config.type === 'fromTo')
    // //     return true;
    // // }

    return false;
  }),
  _settingPaddingTop: Ember.computed('_setting', function() {
    return this.get('_setting').paddingTop;
  }),
  _settingPaddingRight: Ember.computed('_setting', function() {
    return this.get('_setting').paddingRight;
  }),
  _settingPaddingLeft: Ember.computed('_setting', function() {
    return this.get('_setting').paddingLeft;
  }),
  _settingPaddingBottom: Ember.computed('_setting', function() {
    return this.get('_setting').paddingBottom;
  }),
  _settingNormalOpacity: Ember.computed('_setting', function() {
    return this.get('_setting').normalOpacity;
  }),
  _settingDarkOpacity: Ember.computed('_setting', function() {
    return this.get('_setting').darkOpacity;
  }),
  _settingTransparentOpacity: Ember.computed('_setting', function() {
    return this.get('_setting').transparentOpacity;
  }),
  _settingGlyphiconPrefix: Ember.computed('_setting', function() {
    return this.get('_setting').glyphiconPrefix;
  }),

  // legend 에 표시하지 않는 옵션 적용
  _filteringChartData: Ember.computed('_chartData.series.[]', function() {
    const data = this.get('_chartData');
    const one = 1;
    const zero = 0;

    if(Ember.isEmpty(data)) {
      return data;
    }

    const temp = Ember.$.extend(true, {}, data);
    let noDisplayInLegend;

    for(let i = temp.series.length - one; i >= zero ; i--) {
      noDisplayInLegend = temp.series[i].config.noDisplayInLegend;

      if(Ember.isEmpty(noDisplayInLegend)) {
        continue;
      }

      if(noDisplayInLegend === true) {
        temp.series.removeAt(i);
      }
    }

    return temp;
  }),

  onPropertyInit() {
    this._super(...arguments);
    this._logTrace('fr-chart-svg.onPropertyInit()');

    this.setStateProperties([ 'actionMode', 'addSeries', 'chartData', 'reload', 'height',
      'removeSeriesNo', 'trace', 'width',
      '_addSymbolSize', '_brush', '_clickedLegendRect', '_currentYAxis',
      '_defaultYAxis','_groupLegend', '_groupLegendWidth',
      '_isCollapsed', '_isValidData', '_lineLeading', '_maxX',
      '_maxY', '_miniXScale', '_minX', '_minY',
      '_onlyOne', '_parentType', '_postfixFrom', '_postfixMax', '_postfixMin',
      '_postfixTo', '_rect', '_selectedLegendRect', '_selectedLegendRectForNormal','_selectedLegendRectForYAxis', '_selectedLegendSymbol',
      '_symbolMulple', '_tickAndFormat', '_violateProperty', '_xAxis',
      '_xScale', '_yAxis', '_yScale',
      '_zoom', '_setting', '_ccSeries', '_browserType'
    ]);

    this._logTrace('fr-chart-svg.onPropertyInit().this.hasState() = ' + this.hasState());

    //const one = 1;
    const ten = 10;
    //const paddingTop = 20;
    //const paddingRight = 30;
    //const paddingLeft = 160;
    //const paddingBottom = 30;
    const groupLegendWidth = 150;

    if (!this.hasState()) {
      this.set('reload', true);
      this.set('_addSymbolSize', ten);
      this.set('_clickedLegendRect', false);
      this.set('_groupLegendWidth', groupLegendWidth);
      this.set('_isCollapsed', true);
      this.set('_isValidData', true);
      this.set('_lineLeading', ten);
      this.set('_onlyOne', false);
      this.set('_parentType', 'chart');
      this.set('_postfixFrom', 'From');
      this.set('_postfixMax', 'Max');
      this.set('_postfixMin', 'Min');
      this.set('_postfixTo', 'To');
      this.set('_selectedLegendRect', Ember.A());
      this.set('_selectedLegendRectForNormal', Ember.A());
      this.set('_selectedLegendRectForYAxis', Ember.A());
      this.set('_selectedLegendSymbol', Ember.A());
      this.set('_symbolMulple', ten);
      this.set('_setting', {
        paddingTop: 20,
        paddingRight: 30,
        paddingLeft: 160,
        paddingBottom: 50,
        normalOpacity: 1,
        darkOpacity: 0.9,
        transparentOpacity: 0.3,
        glyphiconPrefix: 'material-icons'
      });
      this.set('_browserType', this._getBrowserType());

      const tickFormat = [];
      let item;

      item = {};
      item.type = 'month';
      item.ticks = d3.timeMonth;
      // 2017 Jan
      item.tickFormat = d3.timeFormat('%Y %b');
      tickFormat.pushObject(item);

      item = {};
      item.type = 'week';
      item.ticks = d3.timeWeek;
      // 17 Jan 9
      item.tickFormat = d3.timeFormat('%y %b %e');
      tickFormat.pushObject(item);

      item = {};
      item.type = 'day';
      item.ticks = d3.timeDay;
      // Jan 3
      item.tickFormat = d3.timeFormat('%b %e');
      tickFormat.pushObject(item);

      item = {};
      item.type = 'hour';
      item.ticks = d3.timeHour;
      // 7 PM 3
      item.tickFormat = d3.timeFormat('%e %p %I');
      tickFormat.pushObject(item);

      item = {};
      item.type = 'minute';
      item.ticks = d3.timeMinute;
      // PM 3
      item.tickFormat = d3.timeFormat('%p %I');
      tickFormat.pushObject(item);

      // [REF-URL]
      // https://github.com/d3/d3-3.x-api-reference/blob/master/Time-Scales.md
      // https://bl.ocks.org/zanarmstrong/ca0adb7e426c12c06a95
      // https://github.com/d3/d3-3.x-api-reference/blob/master/Time-Formatting.md
      this.set('_tickAndFormat', tickFormat);
    }
  },

  // init() {
  //   this._super(...arguments);
  //   this._logTrace('fr-chart-svg.init()');
  //   this._logTrace('fr-chart-svg.init().this.hasState() = ' + this.hasState());
  // },

  didInsertElement() {
    this._super(...arguments);
    this._logTrace('fr-chart-svg.didInsertElement()');

    this.set('_elementId', this.elementId);

    this._setMouseRightClick();
    console.log('차트데이터', this.get('_chartData'));
    if(Ember.isEmpty(this.get('_chartData')) === true) {
      return;
    }

    this._renderChart();
  },

  didRender() {
    this._super(...arguments);
    this._logTrace('fr-chart-svg.didRender()');

    this._initSeriesStyle();

    this._copyChartData();
  },

  didUpdateAttrs() {
    this._super(...arguments);
    this._logTrace('fr-chart-svg.didUpdateAttrs()');

    if(Ember.isEmpty(this.get('_chartData')) === true) {
      return;
    }

    // 추가, 삭제된 데이터만 핸들링
    if(this.get('_changedData') === true) {
      const actionMode = this.get('actionMode');
      const newSeries = this.get('addSeries');
      const removeSeriesNo = this.get('removeSeriesNo');

      this._removeAxis();
      this.$('g[data-id=todayRoot]').remove();

      if(actionMode === 'add' && !Ember.isEmpty(newSeries)) {
        this._addToChartData(newSeries);
      }

      if(actionMode === 'remove' && !Ember.isEmpty(removeSeriesNo)) {
        this._applyRemovedData(removeSeriesNo);
        this._removeToChartDataByNo(removeSeriesNo);
      }
    }

    this.set('_ccSeries', null);
    this._copyChartData();

    this._renderChart();
  },

  willDestroyElement() {
    this._super(...arguments);
    this._logTrace('fr-chart-svg.willDestroyElement()');

    this._removeEventListener();
    this._removeDom();
  },

  _copyChartData() {
    if(!Ember.isEmpty(this.get('chartData'))) {
      if(Ember.isEmpty(this.get('_ccSeries'))) {
        const temp = Ember.$.extend(true, [], this.get('chartData').series);

        this.set('_ccSeries', temp);
      }
    }
  },

  _removeEventListener() {
    const zoom = this.get('_zoom');
    const brush = this.get('_brush');
    const brushExtect = d3.selectAll('rect.extent');
    const rect = this.get('_rect');
    const svg = this._getD3Svg();
    const root = svg.select('g.main').select('g.chartRoot');

    this.$().off('contextmenu');

    if(brush !== null) {
      brush.on('brush', null);
    }
    if(brushExtect !== null) {
      brushExtect.on('mouseover', null);
      brushExtect.on('mouseout', null);
    }
    if(rect !== null) {
      rect.on('dblclick.zoom', null);
      rect.on('mousedown', null);
      rect.on('mouseup', null);
    }
    if(zoom !== null) {
      zoom.on('zoom', null);
    }
    if(root !== null) {
      root.on('mousedown', null);
      root.on('mouseup', null);
    }

    svg.on('mousedown', null);
    svg.on('mousemove', null);
    svg.on('mouseup', null);
  },

  _removeDom() {
    //
  },

  _logTrace(text) {
    if(this.get('_trace') === true) {
      Ember.Logger.log(text);
    }
  },

  _getD3Svg() {
    const zero = 0;

    return d3.select(this.$().get(zero));
  },

  _setMouseRightClick() {
    this.$().on('contextmenu', function(e) {
      this._logTrace('[contextmenu]');
      this._onContextMenu(e);
      ////this._resetZoomBrush();
      e.preventDefault();
      e.stopPropagation();
    }.bind(this));
  },

  _applyRemovedData(no) {
    const one = 1;
    const zero = 0;
    //let data = this.get('_chartData');
    const selectedLegend = this.get('_selectedLegendRect');
    const selectedLegendForYAxis = this.get('_selectedLegendRectForYAxis');
    const selectedLegendSymbol = this.get('_selectedLegendSymbol');

    // 현재 1개 선택된 상태에서 그것을 삭제한 경우
    if(selectedLegend.length === one) {
      if(selectedLegend[zero] === no) {
        this.set('_setNormalAll', true);
      }
    }

    if(selectedLegend.includes(no)) {
      for(let i=zero; i < selectedLegend.length; i++) {
        if(selectedLegend[i] === no) {
          selectedLegend.removeObject(selectedLegend[i]);
        }
      }
    }

    if(selectedLegendSymbol.includes(no)) {
      for(let i=zero; i < selectedLegendSymbol.length; i++) {
        if(selectedLegendSymbol[i] === no) {
          selectedLegendSymbol.removeObject(selectedLegendSymbol[i]);
        }
      }
    }

    if(selectedLegendForYAxis.includes(no)) {
      for(let i=zero; i < selectedLegendForYAxis.length; i++) {
        if(selectedLegendForYAxis[i] === no) {
          selectedLegendForYAxis.removeObject(selectedLegendForYAxis[i]);
        }
      }
    }
  },

  _removeAxis() {
    const zero = 0;

    this.set('xScale', null);
    this.set('yScale', null);
    this.set('_xAxis', null);
    this.set('_yAxis', null);
    this.set('_miniXScale', null);

    const el = this.$().get(zero);
    const isTrendChart = this.get('_isTrendChart');

    d3.select(el).selectAll('g[data-id=\'xAxisG\']').remove();
    d3.select(el).selectAll('g[data-id=\'yAxisG\']').remove();

    if(isTrendChart === true) {
      d3.select(el).selectAll('.main').remove();
      d3.select(el).selectAll('.mini').remove();
      d3.select(el).select('defs').remove();
      d3.select(el).select('rect.pane').remove();
    }
  },

  _initSeriesStyle() {
    const chartData = this.get('_chartData');
    const zero = 0;

    if(Ember.isEmpty(chartData)) {
      return;
    }

    const allSeries = chartData.series;
    const transparentOpacity = this.get('_settingTransparentOpacity');
    const normalOpacity = this.get('_settingNormalOpacity');
    const selectedLegendSymbol = this.get('_selectedLegendSymbol');
    const selectedLegendRect = this.get('_selectedLegendRect');
    const el = this.$().get(zero);

    // 선택된 레전드 처리
    for(let i=0; i < allSeries.length; i++) {
      const seriesNo = allSeries[i].no;

      if(selectedLegendRect.includes(seriesNo)) {
        // 상태 변경된 아이템
        const legendLabel = d3.select(el)
        .selectAll('.chart.legendG.series' + seriesNo)
        ////.selectAll('text');
        .selectAll('.legendText');

        if(selectedLegendRect.includes(seriesNo)) {
          legendLabel.classed('selectedLegend', true);
        } else {
          legendLabel.classed('selectedLegend', false);
        }
      }
    }

    this._onlyOneChecked();

    // 하나만 있다면, 그것을 제외한 모든 것을 투명하게 처리
    if(this.get('_onlyOne') === true) {

      for(let i = 0; i < allSeries.length; i++) {
        const tempSeriesNo = allSeries[i].no;

        if(selectedLegendRect.includes(tempSeriesNo)) {
          this._setSeriesOpacity(tempSeriesNo, normalOpacity);

          if(selectedLegendSymbol.includes(tempSeriesNo)) {
            this._showSeriesTooltip(tempSeriesNo, false);
          } else {
            this._showSeriesTooltip(tempSeriesNo, true);
          }
        } else {
          this._setSeriesOpacity(tempSeriesNo, transparentOpacity);
          this._showSeriesTooltip(tempSeriesNo, false);
        }
      }
    } else {
      // 선택된 것이 하나도 없다면 모두 표시
      if(selectedLegendRect.length === zero) {
        for(let i = 0; i < allSeries.length; i++) {
          const tempSeriesNo = allSeries[i].no;

          this._setSeriesOpacity(tempSeriesNo, normalOpacity);
          this._showSeriesTooltip(tempSeriesNo, false);
        }
      } else {
        for(let i = 0; i < allSeries.length; i++) {
          const tempSeriesNo = allSeries[i].no;

          if(selectedLegendRect.includes(tempSeriesNo)) {
            this._setSeriesOpacity(tempSeriesNo, normalOpacity);

            if(selectedLegendSymbol.includes(tempSeriesNo)) {
              this._showSeriesTooltip(tempSeriesNo, false);
            } else {
              this._showSeriesTooltip(tempSeriesNo, true);
            }
          } else {
            this._setSeriesOpacity(tempSeriesNo, transparentOpacity);
            this._showSeriesTooltip(tempSeriesNo, false);
          }
        }
      }
    }

    // 선택된 심볼 처리
    for(let i=0; i < allSeries.length; i++) {
      const seriesNo = allSeries[i].no;

      if(selectedLegendSymbol.includes(seriesNo)) {
        this._showSeries(seriesNo, false);
        this.$('.chart.legendSymbol.series' + seriesNo).parent().css('opacity', transparentOpacity);
      } else {
        this._showSeries(seriesNo, true);
        this.$('.chart.legendSymbol.series' + seriesNo).parent().css('opacity', normalOpacity);
      }
    }
  },

  _onContextMenu(e) {
    this._raiseEvents('onMouseRightClick', e);
  },

  _resetZoomBrush() {
    const svg = this._getD3Svg();
    const brush = this.get('_brush');
    const minX = this.get('_minX');
    const maxX = this.get('_maxX');
    const brushExtent = [minX, maxX];

    svg.select('.brush').call(brush.extent(brushExtent));
    brush.event(svg.select('.brush'));
  },

  _hasProperty(obj, propertyName) {
    let result = true;
    let prop = '';

    for( let i=0; i < propertyName.length; i++) {
      if( !obj.hasOwnProperty([propertyName[i]]) ) {
        prop = propertyName[i];
        result = false;
        break;
      }
    }

    return { result: result, message: prop };
  },

  _isValidate() {
    let result = true;
    const data = this.get('chartData');

    this.set('_violateProperty', '');

    try {
      const rootPropertyName = ['xAxisOrient', 'yAxisOrient', 'tooltipSize', 'isSortedData', 'isTimeXAxis',
        'isGroupLegend', 'isCollapsibleLegend', 'isCustomYAxis', 'series'];
      const temp = this._hasProperty(data, rootPropertyName);

      if( temp.result === false) {
        this.set('_violateProperty', this.get('_violateProperty') + '\n root property -> ' + temp.message);
      }

      const xAxisOrientDomain = ['bottom'];
      const yAxisOrientDomain = ['left'];

      if(xAxisOrientDomain.includes(data.xAxisOrient) === false) {
        this.set('_violateProperty', this.get('_violateProperty') + '\n xAxisOrient -> not valid value');
      }

      if(yAxisOrientDomain.includes(data.yAxisOrient) === false) {
        this.set('_violateProperty', this.get('_violateProperty') + '\n yAxisOrient -> not valid value');
      }

      if(Number.isInteger(data.tooltipSize) === false) {
        this.set('_violateProperty', this.get('_violateProperty') + '\n tooltipSize -> must number value');
      }

      if(typeof data.isSortedData !== 'boolean') {
        this.set('_violateProperty', this.get('_violateProperty') + '\n isSortedData -> must boolean value');
      }

      if(typeof data.isTimeXAxis !== 'boolean') {
        this.set('_violateProperty', this.get('_violateProperty') + '\n isTimeXAxis -> must boolean value');
      }

      if(typeof data.isGroupLegend !== 'boolean') {
        this.set('_violateProperty', this.get('_violateProperty') + '\n isGroupLegend -> must boolean value');
      }

      if(typeof data.isCollapsibleLegend !== 'boolean') {
        this.set('_violateProperty', this.get('_violateProperty') + '\n isCollapsibleLegend -> must boolean value');
      }

      if(typeof data.isCustomYAxis !== 'boolean') {
        this.set('_violateProperty', this.get('_violateProperty') + '\n isCustomYAxis -> must boolean value');
      }

      // if(typeof data.isCollapseLegendPane !== 'boolean')
      //   this.set('_violateProperty', this.get('_violateProperty') + '\n isCollapseLegendPane -> must boolean value');

      if(Ember.isEmpty(data.collapsibleLegendWidth) === false) {
        if(Number.isInteger(data.collapsibleLegendWidth) === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n collapsibleLegendWidth -> must number value');
        }
      }

      if(Ember.isEmpty(data.isGroupLegend) === false) {
        if(data.isGroupLegend === true && Ember.isEmpty(data.groupLegend) === true) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n groupLegend -> must set groupLegend with isGroupLegend');
        }
      }

      const seriesPropertyName = ['no', 'name', 'config', 'data'];
      const seriesConfigPropertyName = ['type', 'xAxisProperty', 'yAxisProperty', 'tooltipProperty', 'isSelectSymbol', 'isSelectLegend'];
      const seriesTypeDomain = [ 'line', 'bar', 'minMax', 'pie', 'fromTo', 'point'];

      for(let i = 0; i < data.series.length; i++) {
        const series = data.series[i];
        let innerTemp = this._hasProperty(series, seriesPropertyName);

        if( innerTemp.result === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[] property -> ' + innerTemp.message);
        }

        if(Ember.isEmpty(series.name) === true) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].name -> is empty');
        }
        if(Ember.isEmpty(series.config) === true) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config -> is empty');
        }

        innerTemp = '';
        innerTemp = this._hasProperty(series.config, seriesConfigPropertyName);
        if( innerTemp.result === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config property -> ' + innerTemp.message);
        }

        const type = series.config.type;

        if(seriesTypeDomain.includes(type) === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config.type -> value domain');
        }

        if(Ember.isEmpty(series.config.strokeWidth) === false && Number.isInteger(series.config.strokeWidth) === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config.strokeWidth -> must number value');
        }

        if(Ember.isEmpty(series.config.symbolSize) === false && Number.isInteger(series.config.symbolSize) === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config.symbolSize -> must number value');
        }

        if(Ember.isEmpty(series.config.groupLegendNo) === false && Number.isInteger(series.config.groupLegendNo) === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config.groupLegendNo -> must number value');
        }

        if(Ember.isEmpty(series.config.isCustomYAxis) === false && typeof series.config.isCustomYAxis !== 'boolean') {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config.isCustomYAxis -> must boolean value');
        }

        if(typeof series.config.isSelectSymbol !== 'boolean') {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config.isSelectSymbol -> must boolean value');
        }

        if(typeof series.config.isSelectLegend !== 'boolean') {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config.isSelectLegendtype -> must boolean value');
        }

        if(Ember.isEmpty(series.config.groupLegendNo) === false && series.config.symbolType.startsWith('material-icons-') === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config.symbolType -> must specific prefix name');
        }

        let seriesTypePropertyName = [];

        if(series.config.type === 'line') {
          seriesTypePropertyName = ['strokeColor', 'strokeWidth', 'symbolColor', 'symbolSize', 'symbolType'];
        } else if(series.config.type === 'bar') {
          seriesTypePropertyName = ['strokeColor', 'strokeWidth', 'symbolColor'];
        } else if(series.config.type === 'minMax') {
          seriesTypePropertyName = ['strokeColor', 'strokeWidth', 'symbolColor', 'symbolSize', 'symbolType'];
        } else if(series.config.type === 'pie') {
          seriesTypePropertyName = ['symbolColor'];
        }

        innerTemp = null;
        innerTemp = this._hasProperty(series.config, seriesTypePropertyName);

        if( innerTemp.result === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[] property -> ' + innerTemp.message);
        }
      }

      if(Ember.isEmpty(this.get('_violateProperty')) === false) {
        result = false;
      }
    } catch(e) {
      result = false;
      // [i18N]
      this._logTrace('chart 데이터를 확인하는 과정에서 에러가 발생하였습니다. ' + e.message);
    }

    return result;
  },
  // JSON ㅓ데이터의 유효성부터 검사.
  _renderChart() {
    //this._logTrace('fr-chart-svg._renderChart()');
    // if(this._isValidate() === false) {
    //   const failMessage = '[chartData is not valid] ' + this.get('_violateProperty');

    //   // [i18N]
    //   this._logTrace(failMessage);
    //   this._raiseEvents('onValidateFail', failMessage);
    //   this.set('_isValidData', false);

    //   return;
    // }

    const isTrendChart = this.get('_isTrendChart');

    this._setProperties();

    if(isTrendChart === true) {
      this._createDefs();
    }

    this._setScale();
    this._setAxis();

    if(isTrendChart === true) {
      //this._setBrush();
      //this._setTrendChartRightDrag();
      //this._setZoomPeriod();
    } else {
      this._createAxis();
    }

    this._setNowBar();

    if(isTrendChart === false) {
      this._setChartRightDrag();
    }
  },

  _setProperties() {
    const chartData = this.get('_chartData');
    const isCollapsibleLegend = chartData.isCollapsibleLegend;

    if(isCollapsibleLegend === true) {
      this.get('_setting').paddingLeft = 80;
      this.set('_groupLegendWidth', parseInt(chartData.collapsibleLegendWidth));
      this.set('_isCollapsed', chartData.isCollapseLegendPane);
    } else {
      this.get('_setting').paddingLeft = 160;
    }

    for(let i=0; i < chartData.series.length; i++) {
      const current = chartData.series[i];

      if(current.config.isSelectSymbol === true){
        this.get('_selectedLegendSymbol').pushObject(current.no);
      }

      if(current.config.isSelectLegend === true) {
        this.get('_selectedLegendRect').pushObject(current.no);
      }
    }

    this._setXAxisTickFormat();
  },

  _setXAxisTickFormat() {
    if(Ember.isEmpty(this.get('_chartData').timeFormat)) {
      return;
    }

    if(Ember.isEmpty(this.get('_chartData').timeFormat.xAxisTickFormat)) {
      return;
    }

    const result = [];
    const xAxisTickFormat = this.get('_chartData').timeFormat.xAxisTickFormat;

    for(let i=0; i < xAxisTickFormat.length; i++) {
      const item = {};

      item.type = xAxisTickFormat[i].type;
      item.tickFormat = d3.timeFormat(xAxisTickFormat[i].format);

      if(xAxisTickFormat[i].type === 'year') {
        item.ticks = d3.timeYear;
      } else if(xAxisTickFormat[i].type === 'month') {
        item.ticks = d3.timeMonth;
      } else if(xAxisTickFormat[i].type === 'week') {
        item.ticks = d3.timeWeek;
      } else if(xAxisTickFormat[i].type === 'day') {
        item.ticks = d3.timeDay;
      } else if(xAxisTickFormat[i].type === 'hour') {
        item.ticks = d3.timeHour;
      } else if(xAxisTickFormat[i].type === 'minutes') {
        item.ticks = d3.timeMinutes;
      } else {
        item.ticks = d3.timeDay;
      }

      result.pushObject(item);
    }

    this.set('_tickAndFormat', result);
  },

  _createDefs() {
    const svg = this._getD3Svg();
    const width = this.get('_width') - this.get('_settingPaddingLeft');
    const height = this.get('_height');

    svg.append('defs')
      .append('clipPath')
      .attr('id', this.get('_elementId') + 'clip')
      .append('rect')
      .attr('width', width)
      .attr('height', height);
  },

  _setMainMini() {
    const svg = this._getD3Svg();
    const main = svg.append('g').attr('class', 'main');
    const mini = svg.append('g').attr('class', 'mini');

    this.set('_main', main);
    this.set('_mini', mini);
  },

  _convertDateString(date, format) {
    return this.get('fr_I18nService').formatDate(date, format);
  },

  _resetPeriodLabel(extent) {
    const zero = 0;
    const one = 1;
    // chartRoot 아래 자식 추가
    const svg = this._getD3Svg();
    //let xPoint = this.get('_settingPaddingLeft');
    const chartRoot = svg.select('g.main');

    chartRoot.selectAll('text[data-id=startDate]').remove();
    chartRoot.selectAll('text[data-id=endDate]').remove();

    const gLabel = svg.select('g.main').select('g.chartRoot');
    const startX = 10;
    const hundred = 100;
    const endX = this.get('_width') - this.get('_settingPaddingLeft') - hundred;
    const y = 15;
    const dateFormat = 'd';

    const startDate = this._convertDateString(extent[zero], dateFormat);
    const endDate = this._convertDateString(extent[one], dateFormat);

    gLabel.append('text')
      .attr('data-id', 'startDate')
      .attr('class', 'startDate')
      .attr('transform', function() {
        const x = startX;
        let xy = x + ', ';

        xy = xy + y;

        return 'translate(' + xy + ')';
      })
      .text(startDate);

    gLabel.append('text')
      .attr('data-id', 'startDate')
      .attr('class', 'endDate')
      .attr('transform', function() {
        const x = endX;
        let xy = x + ', ';

        xy = xy + y;

        return 'translate(' + xy + ')';
      })
      .text(endDate);
  },

  // Zoom 기본값 설정
  _setZoomPeriod() {
    const zero = 0;
    const one = 1;
    const svg = this._getD3Svg();
    //let zoom = this.get('_zoom');
    const brush = this.get('_brush');
    //let xScale = this.get('_xScale');
    //let width = this.get('_width') - this.get('_settingPaddingLeft') - this.get('_settingPaddingRight');
    const customPeriod = this.get('_chartData').period;
    const minX = this.get('_minX');
    const maxX = this.get('_maxX');
    //let xAxisPadding = this.get('_settingPaddingLeft');
    let brushExtent = [minX, maxX];

    if(!Ember.isEmpty(customPeriod)) {
      brushExtent = [customPeriod[zero], customPeriod[one]];
    }

    svg.select('.brush').call(brush.extent(brushExtent));
    brush.event(svg.select('.brush'));
  },

  _brushListener() {
    this._logTrace('[_brushListener]');
    const zero = 0;
    const one = 1;

    // if(d3.event.sourceEvent === null) {
    //   //this._logTrace('[_brushListener] d3.event.type = ' + d3.event.type); // ['dblclick']
    // } else {
    //   //this._logTrace('[_brushListener] d3.event.sourceEvent.type = ' + d3.event.sourceEvent.type); // ['mousemove', 'zoom']
    // }

    const svg = this._getD3Svg();
    const xScale = this.get('_xScale');
    const miniXScale = this.get('_miniXScale');
    const xAxis = this.get('_xAxis');
    //const main = this.get('_main');
    const brush = this.get('_brush');
    const zoom = this.get('_zoom');
    const width = this.get('_width') - this.get('_settingPaddingLeft') - this.get('_settingPaddingRight');

    this._logTrace('[_brushListener] brush.extent = [' + brush.extent()[zero] + ', ' + brush.extent()[one] + ']');
    xScale.domain(brush.empty() ? miniXScale.domain() : brush.extent());

    // debugger;

    this.set('_xScale', xScale);

    const mainDomain = xScale.domain();
    const miniDomain = miniXScale.domain();
    const newScale = (miniDomain[one]-miniDomain[zero])/(mainDomain[one]-mainDomain[zero]);
    const t = (mainDomain[zero]-miniDomain[zero])/(miniDomain[one]-miniDomain[zero]);
    const trans = width * newScale * t;

    const intervalType = this._getIntervalType(mainDomain[zero], mainDomain[one]);
    // [ year, month, week, day, hour, minute]
    const tickItem = this._getTickAndFormat(intervalType);

    xAxis.ticks(tickItem.ticks)
      .tickFormat(tickItem.tickFormat);
    svg.select('g[data-id=xAxisG]').call(xAxis);
    this.set('_xAxis', xAxis);

    zoom.scale(newScale);
    zoom.translate([-trans, zero]);
    //this._logTrace('[_brushListener] newScale = ' + newScale + ', trans = ' + (-trans));

    this._resetNowBar();
    // 자식 시리즈 다시 그리게
    this.set('reload', !this.get('_reload'));

    // 호출자에 기간 변경 콜백
    this._raiseEvents('onPeriodChange', brush.extent());

    // 현재 표시하는 데이터의 시작점과 끝점
    this._resetPeriodLabel(brush.extent());

    if(Ember.isEmpty(d3.event.sourceEvent)) {
      //
    } else if(Ember.isEmpty(d3.event.sourceEvent.sourceEvent)) {
      //
    } else {
      d3.event.sourceEvent.sourceEvent.cancelBubble = true;
    }
  },

  _getOffsetX(e) {
    const target = e.target || e.srcElement;
    const rect = target.getBoundingClientRect();
    let offsetX;

    if( e.clientX === Math.round(rect.left)) {
      offsetX = e.clientX - rect.right;
    } else {
      offsetX = e.clientX - rect.left;
    }

    return offsetX;
  },

  _getBrowserType() {
    const browserName = this.get('fr_GlobalSystemService').browserName;

    return browserName.toLowerCase();
  },

  _zoomListener() {
    //this._logTrace('[_zoomListener]');
    let eventType = '';
    let button = '';
    let currentX = null;
    const two = 2;
    const one = 1;
    const zero = 0;

    if(Ember.isEmpty(d3.event.sourceEvent)) {
      // dblclick
      eventType = d3.event.type;
      button = d3.event.buttons;
      currentX = d3.event.offsetX;
    } else {
      eventType = d3.event.sourceEvent.type;
      button = d3.event.sourceEvent.buttons;
      currentX = d3.event.sourceEvent.offsetX;
    }

    //this._logTrace('[_zoomListener] eventType = ' + eventType + ', button = ' + button);
    if(eventType === 'mousemove' && button === two) {
      let tempStartX = this.get('_mousedownOffsetX');
      let tempEndX = currentX;
      const browserType = this.get('_browserType');

      if(browserType === 'edge' || browserType === 'firefox') {
        tempStartX += this.get('_settingPaddingLeft');
        tempEndX += this.get('_settingPaddingLeft');
      }
      // 각 브라우저의 rect 위치 조정
      this._setDraggingRect(tempStartX, tempEndX);
    }

    // if((eventType === 'mousemove' && button === two) || eventType === 'brush') {
    //   return;
    // }
    if(eventType === 'mousemove' && button === two) {
      return;
    }

    if(eventType === 'brush') {
      return;
    }

    const svg = this._getD3Svg();
    const xScale = this.get('_xScale');
    //let xAxis =  this.get('_xAxis');
    //let main = this.get('_main');
    const brush = this.get('_brush');
    const zoom = this.get('_zoom');
    const width = this.get('_width') - this.get('_settingPaddingLeft') - this.get('_settingPaddingRight');
    const minX = this.get('_minX');
    const maxX = this.get('_maxX');
    let scale;
    let brushExtent;
    let leftX, rightX;

    if(eventType === 'dblclick') {
      // 줄어드는 폭 기준
      const diff = 100;

      leftX = xScale.invert(diff);
      rightX = xScale.invert(width - diff);
      brushExtent = [leftX, rightX];
    } else if(eventType === 'mouseup') {
      const extentStartX = xScale(brush.extent()[zero]);
      const xAxisPadding = this.get('_settingPaddingLeft');
      const browserType = this.get('_browserType');

      this._logTrace('browserType =' + browserType + ', extentStartX = ' + extentStartX);
      this._logTrace('_mousedownOffsetX = ' + this.get('_mousedownOffsetX') + ', _mouseupOffsetX = ' + this.get('_mouseupOffsetX'));

      if(browserType === 'edge') {
        leftX = xScale.invert(this.get('_mousedownOffsetX') + extentStartX);
        rightX = xScale.invert(this.get('_mouseupOffsetX') + extentStartX);
      } else if(browserType === 'firefox') {
        leftX = xScale.invert(this.get('_mousedownOffsetX') + extentStartX);
        rightX = xScale.invert(this.get('_mouseupOffsetX') + extentStartX);
      } else {
        leftX = xScale.invert(this.get('_mousedownOffsetX') + extentStartX - xAxisPadding);
        rightX = xScale.invert(this.get('_mouseupOffsetX') + extentStartX - xAxisPadding);
      }

      brushExtent = [leftX, rightX];
    } else {
      scale = d3.event.scale;

      if(eventType === 'wheel' && scale <= one) {
        scale = one;
      }

      const t = d3.event.translate;
      const size = width * scale;

      t[zero] = Math.min(t[zero], zero);
      t[zero] = Math.max(t[zero], width-size);
      //this._logTrace('[_zoomListener] t[0] = ' + t[0] + ', width = ' + width + ', size = ' + size);
      zoom.translate(t);

      leftX = xScale.invert(zero);
      rightX = xScale.invert(width);
      brushExtent = [leftX, rightX];
    }

    if(scale === one) {
      brushExtent = [minX, maxX];
    }

    svg.select('.brush').call(brush.extent(brushExtent));

    // 브러시 이벤트 호출
    brush.event(svg.select('.brush'));
  },

  _dblclickListener() {
    this._logTrace('[_dblclickListener]');
    this._zoomListener();
  },

  _allowValueDomain(beforeValue, afterValue) {
    const error = 2;
    const allowMin = afterValue - error;
    const allowMax = afterValue + error;

    if(allowMin <= beforeValue && beforeValue <= allowMax) {
      return true;
    }

    return false;
  },
  // x축 확대,축소
  _setBrush() {
    const svg = this._getD3Svg();
    const width = this.get('_width') - this.get('_settingPaddingLeft') - this.get('_settingPaddingRight');
    const height = this.get('_height');
    const xScale = this.get('_xScale');
    const miniXScale = this.get('_miniXScale');
    const brush = d3.brush();
    const two = 2;
    const delay = 200;
    const zero = 0;
    const one = 1;

    // brush()
    //   .on('brush', function() {
    //     this._brushListener();
    //   }.bind(this));

    const zoom = d3.zoom();
    //const zoom = d3.zoom().size([ this.get('_minX'), this.get('_maxX') ]);

    const rect = svg.append('svg:rect')
      .attr('class', 'pane')
      .attr('width', width)
      .attr('height', height)
      .attr('transform', 'translate(' + this.get('_settingPaddingLeft') + ',' + zero + ')')
      .call(zoom)
      .on('dblclick.zoom', function() {
        this._dblclickListener();
        d3.event.stopPropagation();
      }.bind(this))
      .on('mousedown', function() {
        this._logTrace('[rect.mousedown]');
        const button = d3.event.button;

        if(button === two) {
          this.set('_mousedownOffsetX', d3.event.offsetX);
          this._logTrace('[rect.mousedown] d3.event.offsetX = ' + this.get('_mousedownOffsetX'));
        }
      }.bind(this))
      .on('mouseup', function() {
        this._logTrace('[rect.mouseup]');
        const button = d3.event.button;

        this.set('_mouseupOffsetX', d3.event.offsetX);
        this._logTrace('[rect.mouseup] d3.event.offsetX = ' + d3.event.offsetX);

        if(button === two) {
          if(this._allowValueDomain(this.get('_mousedownOffsetX'), this.get('_mouseupOffsetX'))) {
            // 이동하지 않음. => zoom 리셋, context 실행
            this._resetZoomBrush();
            d3.event.preventDefault();
          } else {
            // 값 비교하여 전후 관계 조정
            if(this.get('_mousedownOffsetX') > this.get('_mouseupOffsetX')) {
              const temp = this.get('_mouseupOffsetX');

              this.set('_mouseupOffsetX', this.get('_mousedownOffsetX'));
              this.set('_mousedownOffsetX', temp);
            }
            this._zoomListener();
          }

          this._removeDraggingRect(delay);
        }
      }.bind(this));

    // tag order [defs - rect - main - mini - today - legend]
    this._setMainMini();

    zoom.on('zoom', function() {
      this._zoomListener();
    }.bind(this));

    //zoom.x(xScale);

    const x0 = miniXScale.invert(this.get('_settingPaddingLeft'));
    const x1 = miniXScale.invert(parseInt(this.get('_width')) - this.get('_settingPaddingRight'));

    brush.extent([x0, x1]);

    const main = this.get('_main');
    const mini = this.get('_mini');

    main.append('g')
      .attr('data-id', 'xAxisG')
      .attr('class', 'x axis')
      .attr('transform', 'translate(' + this.get('_settingPaddingLeft') + ', 0)')
      .call(this.get('_xAxis'));

    main.append('g')
      .attr('data-id', 'yAxisG')
      .attr('class', 'y axis')
      .attr('transform', 'translate(' + this.get('_width') + ', 0)')
      .call(this.get('_yAxis'));

    main.append('g')
      .attr('class', 'chart chartRoot')
      .attr('clip-path', 'url(#' + this.get('_elementId') + 'clip)')
      .attr('transform', 'translate(' + this.get('_settingPaddingLeft') + ',' + zero + ')');

    const brushRect = mini.append('g')
      .attr('class', 'x brush')
      .call(brush)
      .selectAll('rect')
      .attr('y', this.get('_height'))
      .attr('height', this.get('_settingPaddingBottom'));

    mini.append('g')
      .attr('class', 'chart chartDrag')
      .attr('clip-path', 'url(#' + this.get('_elementId') + 'clip)')
      .attr('transform', 'translate(' + zero + ',' + zero + ')');
      //.style('display', 'none')

    brushRect.selectAll('.background')
      .style({ fill: '#4b9e9e', visibility: 'hidden' });
    brushRect.selectAll('.extent')
      .style({ fill: '#78c5c5', visibility: 'visible'});
    brushRect.selectAll('.resize rect')
      .style({ fill: '#276c86', visibility: 'visible' });

    this.set('_zoom', zoom);
    this.set('_brush', brush);
    this.set('_rect', rect);

    // 마우스 오버 효과
    const dateFormat = this.get('_chartData').timeFormat.dataFormat;
    const p = this.$().parent();

    if(p.children('div.chartTooltipTemplate').length === zero) {
      p.append('<div class=\'chartTooltipTemplate\'></div>');
    }

    const toolTip = d3.select(p[zero]).selectAll('div.chartTooltipTemplate');
    const ten = 10;

    d3.selectAll('rect.extent')
      .on('mouseover', function() {
        const extent = brush.extent();
        const startDate = this._convertDateString(extent[zero], dateFormat);
        const endDate = this._convertDateString(extent[one], dateFormat);
        const x = d3.event.x + ten;
        const y = d3.event.y + ten;

        toolTip.style('left', x + 'px');
        toolTip.style('top', y + 'px');
        toolTip.style('display', 'inline-block');

        const val = startDate + ' ~ ' + endDate;

        toolTip.html(val);
      }.bind(this))
      .on('mouseout', function() {
        toolTip.style('display', 'none');
        d3.event.stopPropagation();
      });
  },

  _setTrendChartRightDrag() {
    const two = 2;
    const svg = this._getD3Svg();

    svg.select('g.main')
      .select('g.chartRoot')
      .on('mousedown', function() {
        this._logTrace('[chartRoot.mousedown]');
        const button = d3.event.button;

        if(button === two) {
          this.set('_mousedownOffsetX', d3.event.offsetX);
          this._logTrace('[chartRoot.mousedown] d3.event.offsetX = ' + this.get('_mousedownOffsetX'));
        }
      }.bind(this))
      .on('mouseup', function() {
        this._logTrace('[chartRoot.mouseup]');
        const button = d3.event.button;

        this.set('_mouseupOffsetX', d3.event.offsetX);
        this._logTrace('[chartRoot.mouseup] d3.event.offsetX = ' + d3.event.offsetX);
        //// [CAUTION]
        const moveSize = this._getOffsetX(d3.event);

        this._logTrace('[chartRoot.mouseup] moveSize = ' + moveSize);
        this.set('_mouseupOffsetX', this.get('_mousedownOffsetX') + moveSize);

        if(button === two) {
          if(this._allowValueDomain(this.get('_mousedownOffsetX'), this.get('_mouseupOffsetX'))) {
            // 이동하지 않음. => zoom 리셋, context 실행
            this._resetZoomBrush();
            d3.event.preventDefault();
          } else {
            // 값 비교하여 전후 관계 조정
            if(this.get('_mousedownOffsetX') > this.get('_mouseupOffsetX')) {
              const temp = this.get('_mouseupOffsetX');

              this.set('_mouseupOffsetX', this.get('_mousedownOffsetX'));
              this.set('_mousedownOffsetX', temp);
            }

            this._zoomListener();
          }
          this._removeDraggingRect(200);
        }
      }.bind(this));
  },

  _setSelectionContext(offsetX) {
    //let xScaleFunction = this.get('_xScale');
    const zero = 0;
    const xPoint = offsetX - this.get('_settingPaddingLeft');
    const svg = this._getD3Svg();

    const gVerticalBar = svg.select('g.main')
      .select('g.chartRoot')
      .append('g')
      .attr('class', 'chart selectionContext')
      .attr('data-id', 'selectionContext');

    gVerticalBar.append('line')
      .attr('x1', xPoint)
      .attr('y1', zero)
      .attr('x2', xPoint)
      .attr('y2', this.get('_height'))
      .attr('class', 'selectionContext');
  },

  _setDraggingRect(startX, endX) {
    const zero = 0;

    if(startX === endX) {
      return;
    }

    const paddingLeft = this.get('_settingPaddingLeft');
    const transparentOpacity = 0.2;
    //this.get('_settingTransparentOpacity');

    this._removeDraggingRect(0);

    const svg = this._getD3Svg();
    const chartRoot = svg.select('g.main')
      .select('g.chartRoot');

    chartRoot.append('rect')
      .attr('class', 'chart draggingRect')
      .attr('data-id', 'draggingRect')
      .style('opacity', transparentOpacity)
      .attr('x', function() {
        let result = startX;

        if(startX > endX) {
          result = endX;
        }
        result = result - paddingLeft;
        //this._logTrace('x = ' + result);

        return result;
      })
      .attr('y', zero)
      .attr('width', function() {
        const width = Math.abs(endX - startX);
        //this._logTrace('width = ' + width);

        return width;
      })
      .attr('height', this.get('_height'));
  },

  _removeDraggingRect(duration) {
    const zero = 0;
    const svg = this._getD3Svg();
    const chartRoot = svg.select('g.main')
      .select('g.chartRoot');

    if(duration === zero) {
      chartRoot.selectAll('rect[data-id=draggingRect').remove();
    } else {
      chartRoot.selectAll('rect[data-id=draggingRect').transition().duration(duration).remove();
    }
  },

  _removeSelectionContext(duration) {
    const zero = 0;

    if(duration === zero) {
      d3.selectAll('g[data-id=selectionContext]')
        .remove();
    } else {
      d3.selectAll('g[data-id=selectionContext]')
        .transition()
          .duration(duration)
        .remove();
    }
  },

  _createAxis() {
    const zero = 0;
    const el = this.$().get(zero);

    d3.select(el)
      .append('g')
      .attr('data-id', 'xAxisG')
      .attr('class', 'x axis')
      .call(this.get('_xAxis'));

    d3.select(el)
      .append('g')
      .attr('data-id', 'yAxisG')
      .attr('class', 'y axis')
      .attr('transform', 'translate(' + this.get('_width') + ', 0)')
      .call(this.get('_yAxis'));
  },

  _resetNowBar() {
    this._logTrace('fr-chart-svg._resetNowBar()');
    //let el = this.$().get(0);
    // d3.select(el).select('g[data-id=todayRoot]').remove(); // today
    this.$('g[data-id=todayRoot]').remove();

    this._setNowBar();

    // legendRoot 를 현재 svg 의 끝으로 이동
    const parentObj = this.$();
    const childObj = this.$('g[data-id=\'legendRoot\']');

    this._moveToLast(parentObj, childObj);
  },
  // x축과 y축 렌더링
  _setScale() {

    // debugger;
    //let isSortedData = this.get('_chartData').isSortedData;
    const zero = 0;
    const one = 1;
    const isTimeXAxis = this.get('_chartData').isTimeXAxis;
    const series = Ember.copy(this.get('_chartData').series, false);

    let maxX = null;
    let minX = null;
    let maxY = null;
    let minY = null;
    const postfixMax = this.get('_postfixMax');
    const postfixMin = this.get('_postfixMin');
    const postfixFrom = this.get('_postfixFrom');
    const postfixTo = this.get('_postfixTo');
    const isTrendChart = this.get('_isTrendChart');
    //this._logTrace('fr-chart-svg._setScale() series.length=' + series.length);

    series.forEach(function(item) {

      const type = item.config.type;

      let currentMaxX, currentMaxY;
      let currentMinX, currentMinY;

      if(type === 'line' || type === 'bar' || type === 'pie') {
        currentMaxX = d3.max(item.data, function(d) {
          return d[item.config.xAxisProperty];
        });
        currentMinX = d3.min(item.data, function(d) {
          return d[item.config.xAxisProperty];
        });

        currentMaxY = d3.max(item.data, function(d) {
          return d[item.config.yAxisProperty];
        });
        currentMinY = d3.min(item.data, function(d) {
          return d[item.config.yAxisProperty];
        });
      } else if(type === 'minMax') {
        currentMaxX = d3.max(item.data, function(d) {
          return d[item.config.xAxisProperty];
        });
        currentMinX = d3.min(item.data, function(d) {
          return d[item.config.xAxisProperty];
        });

        currentMaxY = d3.max(item.data, function(d) {
          return d[item.config.yAxisProperty + postfixMax];
        });
        currentMinY = d3.min(item.data, function(d) {
          return d[item.config.yAxisProperty + postfixMin];
        });
      } else if(type === 'point') {
        currentMaxX = d3.max(item.data, function(d) {
          return d[item.config.xAxisProperty];
        });
        currentMinX = d3.min(item.data, function(d) {
          return d[item.config.xAxisProperty];
        });

        currentMaxY = d3.max(item.data, function(d) {
          return d[item.config.yAxisProperty];
        });
        currentMinY = d3.min(item.data, function(d) {
          return d[item.config.yAxisProperty];
        });
      } else if(type === 'fromTo') {
        const fromMax = d3.max(item.data, function(d) {
          return d[item.config.xAxisProperty + postfixFrom];
        });
        const fromMin = d3.min(item.data, function(d) {
          return d[item.config.xAxisProperty + postfixFrom];
        });
        const toMax = d3.max(item.data, function(d) {
          return d[item.config.xAxisProperty + postfixTo];
        });
        const toMin = d3.min(item.data, function(d) {
          return d[item.config.xAxisProperty + postfixTo];
        });

        currentMaxX = fromMax;
        currentMinX = fromMin;

        if(currentMaxX < toMax) {
          currentMaxX = toMax;
        }

        if(currentMinX > toMin) {
          currentMinX = toMin;
        }

        currentMaxY = d3.max(item.data, function(d) {
          return d[item.config.yAxisProperty];
        });
        currentMinY = d3.min(item.data, function(d) {
          return d[item.config.yAxisProperty];
        });
      } else {
        throw new Error('_setScale -> 지원하지 않는 chart type');
      }

      if(maxX === null) {
        maxX = currentMaxX;
      } else {
        if(currentMaxX > maxX) {
          maxX = currentMaxX;
        }
      }

      if(minX === null) {
        minX = currentMinX;
      } else {
        if(currentMinX < minX) {
          minX = currentMinX;
        }
      }

      if(maxY === null) {
        maxY = currentMaxY;
      } else {
        if(currentMaxY > maxY) {
          maxY = currentMaxY;
        }
      }

      if(minY === null) {
        minY = currentMinY;
      } else {
        if(currentMinY < minY) {
          minY = currentMinY;
        }
      }
    });


    // 범위 지정 있다면 사용
    if(!Ember.isEmpty(this.get('_chartData').timeDomain)) {
      minX = this.get('_chartData').timeDomain[zero];
      maxX = this.get('_chartData').timeDomain[one];
    }

    if(!Ember.isEmpty(this.get('_chartData').valueDomain)) {
      minX = this.get('_chartData').valueDomain[zero];
      maxX = this.get('_chartData').valueDomain[one];
    }

    //let xDataPadding = 1;
    let yDataPadding = zero;

    if(isTrendChart === true) {
      yDataPadding = one;
    }

    // debugger;

    if(typeof minX === 'string'){
      minX = new Date(minX);
    }

    if(typeof maxX === 'string'){
      maxX = new Date(maxX);
    }

    //let xScale = null, miniXScale = null;
    // debugger;

    if(isTimeXAxis) {
      if(isTrendChart === true) {
        this.set('_xScale', d3.scaleUtc()
          .domain([minX, maxX])
          .range([zero, this.get('_width') - this.get('_settingPaddingLeft') - this.get('_settingPaddingRight')]));

        this.set('_miniXScale', d3.scaleUtc()
          .domain([minX, maxX])
          .range([this.get('_settingPaddingLeft'), this.get('_width') - this.get('_settingPaddingRight')]));
      } else {
        this.set('_xScale', d3.scaleUtc()
          .domain([minX, maxX])
          .range([this.get('_settingPaddingLeft'), this.get('_width') - this.get('_settingPaddingRight')]));
      }
    } else {
      this.set('_xScale', d3.scaleLinear()
        .domain([minX , maxX])
        .range([this.get('_settingPaddingLeft'), this.get('_width') - this.get('_settingPaddingRight')]));
    }


    // debugger;


    // minY의 값이 없다.

    this.set('_yScale', d3.scaleLinear()
      .domain([minY - yDataPadding, maxY + yDataPadding])
      .range([this.get('_height'), this.get('_settingPaddingTop')]));

    this.set('_minX', minX);
    this.set('_maxX', maxX);
    this.set('_minY', minY);
    this.set('_maxY', maxY);
  },

  _setAxis() {
    // 축 라벨 텍스트와 축 간격
    const tickPadding = 10;
    const seriesCount = this.get('_chartData').series.length;
    //let isSortedData = this.get('_chartData').isSortedData;
    const isTimeXAxis = this.get('_chartData').isTimeXAxis;
    const intervalType = this._getIntervalType(this.get('_minX'), this.get('_maxX'));
    // year
    const tickItem = this._getTickAndFormat(intervalType);

    if(isTimeXAxis) {
      this.set('_xAxis', d3.axisBottom(this.get('_xScale'))
        //.orient(this.get('_chartData').xAxisOrient)
        .ticks(tickItem.ticks)
        .tickFormat(tickItem.tickFormat)
        .tickSize(this.get('_height'))
        //.tickSize(this.get('_height') - this.get('_settingPaddingTop'))
        .tickPadding(tickPadding));
    } else {
      this.set('_xAxis', d3.axisBottom(this.get('_xScale'))
        //.orient(this.get('_chartData').xAxisOrient)
        //.ticks(10)
        //.tickFormat(d3.format("d"))
        //.tickValues([-4, -2, 0, 2, 4])
        .tickSize(this.get('_height'))
        //.tickSize(this.get('_height') - this.get('_settingPaddingTop'))
        .tickPadding(tickPadding));
    }

    this.set('_yAxis', d3.axisLeft(this.get('_yScale'))
      //.orient(this.get('_chartData').yAxisOrient)
      .ticks(seriesCount + 2)
      // legend 영역 고려
      .tickSize(this.get('_width') - this.get('_settingPaddingLeft'))
      .tickPadding(tickPadding));
  },

  _getYAxisDom() {
    let yAxisDom = null;
    const isTrendChart = this.get('_isTrendChart');

    if(isTrendChart === true) {
      yAxisDom = this.$().children('.main');
    } else {
      yAxisDom = this.$().children('g.fr-chart-axis');
    }

    return yAxisDom;
  },

  _replaceSeriesName() {

    const series = this.get('_chartData').series;
    const isTrendChart = this.get('_isTrendChart');
    const yAxisDom = this._getYAxisDom();
    let arrG = [];
    let name = '';

    arrG = yAxisDom.children('g[data-id=yAxisG]').children('g');

    for(let i=0; i < arrG.length; i++) {
      name = '';
      const seq = this.$(arrG[i]).children('text').text();

      for(let j=0; j < series.length; j++) {
        if(parseInt(seq) === series[j].no) {
          name = series[j].name;
          this.$(arrG[i]).children('text').text(name);
          break;
        }
      }
      // 트랜드 차트는 y축 텍스트를 변경할 때 일치하지 않는 것을 공백으로
      if(isTrendChart === true) {
        // 일치하지 않다면 공백으로 표시
        if(name === '') {
          this.$(arrG[i]).children('text').text('');
        }
      }
    }
  },

  _setCustomYAxis() {
    const yAxisDom = this._getYAxisDom();

    if(this.get('_chartData').isCustomYAxis === true) {
      const result = Ember.A();
      const arrG = yAxisDom.children('g[data-id=yAxisG]').children('g');

      for(let i=0; i < arrG.length; i++) {
        result.pushObject(this.$(arrG[i]).children('text').text());
      }

      this.set('_defaultYAxis', result);
    }
  },

  _setNowBar() {
    //this._logTrace('fr-chart-svg._setNowBar().1');
    const zero = 0;
    const isShowNowBar = this.get('_chartData').isShowNowBar;
    const isTrendChart = this.get('_isTrendChart');
    const adjustX = 20;
    const adjustY = 15;

    if(isShowNowBar === true) {
      //this._logTrace('fr-chart-svg._setNowBar().2');
      const now = this.get('co_CommonService').getNow();
      const xScaleFunction = this.get('_xScale');
      const xPoint = xScaleFunction(now);
      const el = this.$().get(zero);

      let todayRoot;

      if(isTrendChart === true) {
        todayRoot = d3.select(el)
          .select('g.main')
          .select('g.chartRoot')
          .append('g')
          .attr('class', 'chart todayRoot')
          .attr('data-id', 'todayRoot');
      } else {
        todayRoot = d3.select(el)
          .append('g')
          .attr('class', 'chart todayRoot')
          .attr('data-id', 'todayRoot');
      }

      todayRoot.append('line')
        .attr('x1', xPoint)
        .attr('y1', zero)
        .attr('x2', xPoint)
        .attr('y2', this.get('_height'))
        .attr('class', 'nowBar');

      todayRoot.append('text')
        .attr('class', 'nowBarText')
        .attr('transform', function() {
          const x = xPoint - adjustX;
          const y = adjustY;
          const xy = x  + ', ' + y;

          return 'translate(' + xy + ')';
        })
        .text('TODAY');
    }
    //this._logTrace('fr-chart-svg._setNowBar().end');
  },

  _setChartRightDrag() {
    const svg = this._getD3Svg();
    //let width = this.get('_width') - this.get('_settingPaddingLeft') - this.get('_settingPaddingRight');
    const height = this.get('_height');
    const paddingLeft = this.get('_settingPaddingLeft');
    const transparentOpacity = 0.2;
    //this.get('_settingTransparentOpacity');
    const xScaleFunction = this.get('_xScale');
    const minX = this.get('_minX');
    const maxX = this.get('_maxX');
    const two = 2;
    const zero = 0;

    svg.on('mousedown', function() {
      this._logTrace('[mousedown]');
      const button = d3.event.button;

      if(button === two) {
        if(d3.event.offsetX < paddingLeft ) {
          this.set('_mousedownOffsetX', null);
        } else {
          this.set('_mousedownOffsetX', d3.event.offsetX);
        }
      }
    }.bind(this))
    .on('mousemove', function() {
      this._logTrace('[mousemove]');
      const buttons = d3.event.buttons;

      if(buttons === two) {
        this._logTrace('[mousemove] d3.event.offsetX = ' + d3.event.offsetX);

        if(Ember.isEmpty(this.get('_mousedownOffsetX'))) {
          return;
        }

        const tagName = d3.event.target.tagName.toLowerCase();

        if(tagName !== 'svg') {
          return;
        }

        if(tagName === 'rect' && this.$(d3.event.target).attr('data-id') != 'draggingRect') {
          return;
        }

        // remove current rect
        svg.selectAll('rect[data-id=draggingRect').remove();

        const startX = this.get('_mousedownOffsetX');
        const endX = d3.event.offsetX;

        svg.append('rect')
          .attr('class', 'chart draggingRect')
          .attr('data-id', 'draggingRect')
          .style('opacity', transparentOpacity)
          .attr('x', function() {
            let result = startX;

            if(startX > endX) {
              result = endX;
            }

            return result;
          })
          .attr('y', zero)
          .attr('width', function() {
            const width = Math.abs(endX - startX);

            this._logTrace('width = ' + width);

            return width;
          }.bind(this))
          .attr('height', height);
        //d3.event.stopPropagation();
        d3.event.preventDefault();
      }
    }.bind(this))
    .on('mouseup', function() {
      this._logTrace('[mousedown]');
      const button = d3.event.button;

      if(button === two) {
        if(Ember.isEmpty(this.get('_mousedownOffsetX'))) {
          return;
        }
        //this._logTrace('[mouseup] d3.event.offsetX = ' + d3.event.offsetX);
        this.set('_mouseupOffsetX', d3.event.offsetX);

        if(this._allowValueDomain(this.get('_mousedownOffsetX'), this.get('_mouseupOffsetX'))) {
          // 초기화
          this.get('chartData').valueDomain = null;

          if(!Ember.isEmpty(this.get('_ccSeries'))) {
            //let temp = Ember.$.extend({}, this.get('_ccSeries'));
            const series = this.get('chartData').series;

            series.clear();

            for(let i=0; i < this.get('_ccSeries').length; i++) {
              series.pushObject(this.get('_ccSeries').objectAt(i));
            }
            this.set('_ccSeries', null);
          }
          // 호출자에 기간 변경 콜백
          this._raiseEvents('onPeriodChange', [minX, maxX]);
        } else {
          if(this.get('_mousedownOffsetX') > this.get('_mouseupOffsetX')) {
            const temp = this.get('_mouseupOffsetX');

            this.set('_mouseupOffsetX', this.get('_mousedownOffsetX'));
            this.set('_mousedownOffsetX', temp);
          }
          // remove current rect
          svg.selectAll('rect[data-id=draggingRect').remove();
          // 보다 작은 수
          let startX = xScaleFunction.invert(this.get('_mousedownOffsetX'));
          // 보다 큰 수
          let endX = xScaleFunction.invert(this.get('_mouseupOffsetX'));

          if(!(typeof startX === 'object' && startX instanceof Date)) {
            startX = Math.ceil(startX);
            endX = Math.floor(endX);
          }

          this.get('chartData').valueDomain = [startX, endX];

          // 호출자에 기간 변경 콜백
          this._raiseEvents('onPeriodChange', [startX, endX]);
        }

        this._reRenderChart();
        // 자식 시리즈 다시 그리게
        this.set('reload', !this.get('_reload'));
      }
      // remove current rect
      //svg.selectAll('rect[data-id=draggingRect').remove();
    }.bind(this));
  },

  _reRenderChart() {
    this._removeAxis();
    this.$('g[data-id=todayRoot]').remove();
    this._renderChart();
  },

  _getIntervalType(min, max) {
    const thousand = 1000;
    const minutesPerHour = 60;
    const hourPerDay = 24;
    let result = 'month';
    const diff = max - min;
    const millisecondsPerDay = thousand * minutesPerHour * minutesPerHour * hourPerDay;
    const days = diff / millisecondsPerDay;

    // month, week, day, hour, minute
    if(days <= 0.05) {
      result = 'minute';
    } else if(days <= 2.5) {
      result = 'hour';
    } else if(days <= 32) {
      result = 'day';
    } else if(days <= 130) {
      result = 'week';
    } else if(days <= 720) {
      result = 'month';
    } else {
      result = 'year';
    }

    return result;
  },

  _getTickAndFormat(type) {
    const zero = 0;
    const items = this.get('_tickAndFormat');

    for(let i=0; i < items.length; i++) {
      if(items[i].type === type) {
        return items[i];
      }
    }

    // 기본값 리턴
    return items[zero];
  },

  _setSeriesOpacity(seriesNo, opacity) {
    // [ISSUE-EDGE] Object doesn't support property or method 'getElementsByClassName'
    // developer.microsoft.com/en-us/microsoft-edge/platform/issues/11729645
    this.$('.chart.line.series' + seriesNo).css('opacity', opacity);
    this.$('.chart.lineSymbol.series' + seriesNo).parent().css('opacity', opacity);
    this.$('.chart.bar.series' + seriesNo).css('opacity', opacity);
    this.$('.chart.minMax.series' + seriesNo).css('opacity', opacity);
    this.$('.chart.minMaxTopSymbol.series' + seriesNo).parent().css('opacity', opacity);
    this.$('.chart.minMaxBottomSymbol.series' + seriesNo).parent().css('opacity', opacity);
    this.$('.chart.pie.series' + seriesNo).css('opacity', opacity);
    this.$('.chart.pieText.series' + seriesNo).css('opacity', opacity);
    this.$('.chart.point.series' + seriesNo).parent().css('opacity', opacity);
    this.$('.chart.fromTo.series' + seriesNo).css('opacity', opacity);
    this.$('.chart.foreignObject.intersect.series'+ seriesNo).css('opacity', opacity);
    this.$('.chart.foreignObject.zoomin.series'+ seriesNo).css('opacity', opacity);

    this._setTooltipOpacity(seriesNo, opacity);
    this._setLegendOpacity(seriesNo, opacity);
  },

  _setTooltipOpacity(seriesNo, opacity) {
    this.$('.chart.lineTooltip.series' + seriesNo).css('opacity', opacity);
    this.$('.chart.barTooltip.series' + seriesNo).css('opacity', opacity);
    this.$('.chart.minMaxTopTooltip.series' + seriesNo).css('opacity', opacity);
    this.$('.chart.minMaxBottomTooltip.series' + seriesNo).css('opacity', opacity);
  },

  _showSeriesTooltip(seriesNo, isShow) {
    if(isShow) {
      this.$('.chart.lineTooltip.series' + seriesNo).show();
      this.$('.chart.barTooltip.series' + seriesNo).show();
      this.$('.chart.minMaxTopTooltip.series' + seriesNo).show();
      this.$('.chart.minMaxBottomTooltip.series' + seriesNo).show();
    } else {
      this.$('.chart.lineTooltip.series' + seriesNo).hide();
      this.$('.chart.barTooltip.series' + seriesNo).hide();
      this.$('.chart.minMaxTopTooltip.series' + seriesNo).hide();
      this.$('.chart.minMaxBottomTooltip.series' + seriesNo).hide();
    }
  },

  _setLegendOpacity(seriesNo, opacity) {
    this.$('.chart.legendG.series' + seriesNo).css('opacity', opacity);
    this.$('.chart.legendText.series' + seriesNo).css('opacity', opacity);
    ////this.$('.chart.legendRect.series' + seriesNo).css('opacity', opacity);
  },

  _setCurrentYAxis(series, isSet) {
    if(series.isCustomYAxis === true) {
      if(isSet === true) {
        const currentYAxis = this._getCurrentYAxis();

        this.set('_currentYAxis', currentYAxis);

        this._replaceYAxisText(series.customYAxis);
      }
    }
  },

  _getCurrentYAxis() {
    const result = Ember.A();
    const yAxisDom = this._getYAxisDom();
    const arrG = yAxisDom.children('g[data-id=yAxisG]').children('g').children('text');

    for(let i=0; i < arrG.length; i++) {
      result.pushObject(this.$(arrG[i]).text());
    }

    return result;
  },

  _replaceYAxisText(source) {
    const yAxisDom = this._getYAxisDom();
    const target = yAxisDom.children('g[data-id=yAxisG]').children('g').children('text');

    for(let i=0; i < target.length; i++) {
      this.$(target[i]).text(source[i]);
    }
  },

  _onlyOneChecked() {
    const one = 1;
    let result = false;
    const selectedLegendRect = this.get('_selectedLegendRect');
    const allSeries = this.get('_chartData').series;

    // 여러개 중에, 1개 선택됨
    if(allSeries.length > one && selectedLegendRect.length === one) {
      result = true;
    }

    this.set('_onlyOne', result);

    return result;
  },

  _selectLegendRect(series) {
    const zero = 0;
    const one = 1;
    const seriesNo = series.no;
    const selectedLegendRect = this.get('_selectedLegendRect');
    const selectedLegendRectForYAxis = this.get('_selectedLegendRectForYAxis');
    let isSelected = false;

    if(selectedLegendRect.includes(seriesNo)) {
      for(let i=selectedLegendRect.length - one; i >= zero; i--) {
        if(selectedLegendRect[i] === seriesNo) {
          selectedLegendRect.removeObject(selectedLegendRect[i]);
          isSelected = false;
          break;
        }
      }
    } else {
      selectedLegendRect.pushObject(seriesNo);
      isSelected = true;
    }

    if(selectedLegendRectForYAxis.includes(seriesNo)){
      for(let i=selectedLegendRectForYAxis.length - one; i >= zero; i--) {
        if(selectedLegendRectForYAxis[i] === seriesNo) {
          selectedLegendRectForYAxis.removeObject(selectedLegendRectForYAxis[i]);
          break;
        }
      }
    } else {
      selectedLegendRectForYAxis.pushObject(seriesNo);
    }

    this._setDisplaySeriesAll(series);
    this._setSelectedYAxis(series);

    ////let currentOpacity = parseFloat(this.$('.chart.legendRect.series' + seriesNo).css('opacity'));
    const currentOpacity = parseFloat(this.$('.chart.legendText.series' + seriesNo).css('opacity'));
    const selectedLegendRectForNormal = this.get('_selectedLegendRectForNormal');
    let isUpdated = false;

    for(let i = 0; i < selectedLegendRectForNormal.length; i++) {
      if(selectedLegendRectForNormal[i].seriesNo === seriesNo) {
        isUpdated = true;
        selectedLegendRectForNormal[i].opacity = currentOpacity;
        break;
      }
    }
    if(isUpdated === false){
      selectedLegendRectForNormal.pushObject({ seriesNo: seriesNo, opacity: currentOpacity});
    }

    this._raiseEvents('onSelectedSeriesChange', { seriesNo: seriesNo, isSelected: isSelected});
  },

  _setDisplaySeriesAll(series) {
    const zero = 0;
    const seriesNo = series.no;
    const transparentOpacity = this.get('_settingTransparentOpacity');
    const normalOpacity = this.get('_settingNormalOpacity');
    const chartData = this.get('_chartData');
    const allSeries = chartData.series;
    const selectedLegendRect = this.get('_selectedLegendRect');
    const selectedLegendSymbol = this.get('_selectedLegendSymbol');

    // 상태 변경된 아이템
    const el = this.$().get(zero);
    const legendLabel = d3.select(el)
      .selectAll('.chart.legendG.series' + seriesNo)
      ////.selectAll('text');
      .selectAll('.legendText');

    if(selectedLegendRect.includes(seriesNo)) {
      legendLabel.classed('selectedLegend', true);
    } else {
      legendLabel.classed('selectedLegend', false);
    }

    this._onlyOneChecked();

    // 하나만 있다면, 그것을 제외한 모든 것을 투명하게 처리
    if(this.get('_onlyOne') === true) {
      for(let i = 0; i < allSeries.length; i++) {
        const tempSeriesNo = allSeries[i].no;

        if(selectedLegendRect.includes(tempSeriesNo)) {
          this._setSeriesOpacity(tempSeriesNo, normalOpacity);

          if(selectedLegendSymbol.includes(tempSeriesNo)) {
            this._showSeriesTooltip(tempSeriesNo, false);
          } else {
            this._showSeriesTooltip(tempSeriesNo, true);
          }
        } else {
          this._setSeriesOpacity(tempSeriesNo, transparentOpacity);
          this._showSeriesTooltip(tempSeriesNo, false);
        }
      }
    } else {
      // 선택된 것이 하나도 없다면 모두 표시
      if(selectedLegendRect.length === zero) {
        for(let i = 0; i < allSeries.length; i++) {
          const tempSeriesNo = allSeries[i].no;

          this._setSeriesOpacity(tempSeriesNo, normalOpacity);
          this._showSeriesTooltip(tempSeriesNo, false);
        }
      } else {
        // 변경된 것만 처리
        if(selectedLegendRect.includes(seriesNo)) {
          this._setSeriesOpacity(seriesNo, normalOpacity);

          if(selectedLegendSymbol.includes(seriesNo)) {
            this._showSeriesTooltip(seriesNo, false);
          } else {
            this._showSeriesTooltip(seriesNo, true);
          }
        } else {
          this._setSeriesOpacity(seriesNo, transparentOpacity);
          this._showSeriesTooltip(seriesNo, false);
        }
      }
    }
  },

  _setSelectedYAxis() {
    const zero = 0;
    const one = 1;
    const selectedLegendForYAxis = this.get('_selectedLegendRectForYAxis');

    if(selectedLegendForYAxis === null || selectedLegendForYAxis.length === zero) {
      this._setDefaultYAxis();
    } else {
      const lastSelectedNo = selectedLegendForYAxis[selectedLegendForYAxis.length - one];
      const lastSeries = this._getSeriesByNo(lastSelectedNo);

      if(lastSeries.isCustomYAxis === true) {
        this._setCurrentYAxis(lastSeries, true);
      } else {
        this._setDefaultYAxis();
      }
    }
  },

  _getSeriesByNo(seriesNo) {
    const series = this.get('_chartData').series;

    for(let i = 0; i < series.length; i++) {
      if(series[i].no === seriesNo) {
        return series[i];
      }
    }
  },

  _setDefaultYAxis() {
    this.set('_currentYAxis', Ember.copy(this.get('_defaultYAxis'), true));
    this._replaceYAxisText(this.get('_currentYAxis'));
  },

  _selectSeriesSymbol(series) {
    const zero = 0;
    const one = 1;
    const seriesNo = series.no;
    const selectedLegendSymbol = this.get('_selectedLegendSymbol');
    let isSelected = false;

    // 없으면 추가, 있으면 제거
    if(selectedLegendSymbol.includes(seriesNo)) {
      for(let i=selectedLegendSymbol.length - one; i >= zero ; i--) {
        if(selectedLegendSymbol[i] === seriesNo) {
          selectedLegendSymbol.removeObject(selectedLegendSymbol[i]);
          isSelected = false;
          break;
        }
      }
    } else {
      selectedLegendSymbol.pushObject(seriesNo);
      isSelected = true;
    }

    this._setOpacityLegendSymbol(series);
    this._setDisplaySeries(series);

    this._raiseEvents('onSelectedSymbolChange', { seriesNo: seriesNo, isSelected: isSelected});
  },

  _setOpacityLegendSymbol(series) {
    const seriesNo = series.no;
    const transparentOpacity = this.get('_settingTransparentOpacity');
    const normalOpacity = this.get('_settingNormalOpacity');
    const selectedLegendSymbol = this.get('_selectedLegendSymbol');

    if(selectedLegendSymbol.includes(seriesNo)) {
      this.$('.chart.legendSymbol.series' + seriesNo).parent().css('opacity', transparentOpacity);
    } else {
      this.$('.chart.legendSymbol.series' + seriesNo).parent().css('opacity', normalOpacity);
    }
  },

  _setDisplaySeries(series) {
    const seriesNo = series.no;
    const selectedLegendSymbol = this.get('_selectedLegendSymbol');
    const selectedLegendRect = this.get('_selectedLegendRect');

    // 포함되면 숨기기
    if(selectedLegendSymbol.includes(seriesNo)) {
      this._showSeries(seriesNo, false);
      this._showSeriesTooltip(seriesNo, false);
    } else {
      this._showSeries(seriesNo, true);

      // 현재 선택된 rect 라면 tooltip 표시
      if(selectedLegendRect.includes(seriesNo)) {
        this._showSeriesTooltip(seriesNo, true);
      } else {
        this._showSeriesTooltip(seriesNo, false);
      }
    }
  },

  _showSeries(seriesNo, isShow) {
    if(isShow) {
      this.$('.chart.line.series' + seriesNo).show();
      this.$('.chart.lineSymbol.series' + seriesNo).show();
      this.$('.chart.bar.series' + seriesNo).show();
      this.$('.chart.minMax.series' + seriesNo).show();
      this.$('.chart.minMaxTopSymbol.series' + seriesNo).show();
      this.$('.chart.minMaxBottomSymbol.series' + seriesNo).show();
      this.$('.chart.pie.series' + seriesNo).show();
      this.$('.chart.pieText.series' + seriesNo).show();
      this.$('.chart.point.series' + seriesNo).show();
      this.$('.chart.fromTo.series' + seriesNo).show();
      this.$('.chart.foreignObject.intersect.series'+ seriesNo).show();
      this.$('.chart.foreignObject.zoomin.series'+ seriesNo).show();
    } else {
      this.$('.chart.line.series' + seriesNo).hide();
      this.$('.chart.lineSymbol.series' + seriesNo).hide();
      this.$('.chart.bar.series' + seriesNo).hide();
      this.$('.chart.minMax.series' + seriesNo).hide();
      this.$('.chart.minMaxTopSymbol.series' + seriesNo).hide();
      this.$('.chart.minMaxBottomSymbol.series' + seriesNo).hide();
      this.$('.chart.pie.series' + seriesNo).hide();
      this.$('.chart.pieText.series' + seriesNo).hide();
      this.$('.chart.point.series' + seriesNo).hide();
      this.$('.chart.fromTo.series' + seriesNo).hide();
      this.$('.chart.foreignObject.intersect.series'+ seriesNo).hide();
      this.$('.chart.foreignObject.zoomin.series'+ seriesNo).hide();
    }
  },

  _addToChartData(newSeries) {
    this.get('chartData').series.pushObject(newSeries);
    //this._logTrace(JSON.stringify(this.get('chartData')));
  },

  _removeToChartDataByNo(seriesNo) {
    const chartData = this.get('chartData');
    let target = null;

    for(let i=0; i < chartData.series.length; i++) {
      if(chartData.series[i].no === seriesNo) {
        target = chartData.series[i];
        break;
      }
    }
    chartData.series.removeObject(target);

    ////this.set('chartData', chartData);
  },

  _moveToLast(parentObj, childObj) {
    childObj.appendTo(parentObj);
  },

  _moveToFirst(parentObj, childObj) {
    childObj.prependTo(parentObj);
  },

  actions: {

    completeProcessing(dataId) {
      this._logTrace('fr-chart-svg.completeProcessing()');
      const chartData = this.get('_chartData');

      if(Ember.isEmpty(chartData)) {
        return;
      }

      this._replaceSeriesName();
      this._setCustomYAxis();
      //this._setNowBar();

      const parentObj = this.$();
      const childObj = this.$('g[data-id=\'' + dataId + '\']');

      // legend 를 끝으로
      this._moveToLast(parentObj, childObj);

      const yAxis = this.$('g[data-id=yAxisG]');
      const xAxis = this.$('g[data-id=xAxisG]');

      this._moveToFirst(parentObj, yAxis);
      this._moveToFirst(parentObj, xAxis);
    },

    mouseoverSeries(series) {
      const zero = 0;
      const seriesNo = series.no;
      const transparentOpacity = this.get('_settingTransparentOpacity');
      const normalOpacity = this.get('_settingNormalOpacity');
      const selectedLegendRect = this.get('_selectedLegendRect');
      const selectedLegendSymbol = this.get('_selectedLegendSymbol');

      if(selectedLegendRect.includes(seriesNo) === true) {
        return;
      }

      ////let currentOpacity = parseFloat(this.$('.chart.legendRect.series' + seriesNo).css('opacity'));
      const currentOpacity = parseFloat(this.$('.chart.legendText.series' + seriesNo).css('opacity'));
      const selectedLegendRectForNormal = this.get('_selectedLegendRectForNormal');

      let isUpdated = false;

      for(let i = 0; i < selectedLegendRectForNormal.length; i++) {
        if(selectedLegendRectForNormal[i].seriesNo === seriesNo) {
          isUpdated = true;
          selectedLegendRectForNormal[i].opacity = currentOpacity;
          break;
        }
      }
      if(isUpdated === false) {
        selectedLegendRectForNormal.pushObject({ seriesNo: seriesNo, opacity: currentOpacity});
      }

      this._setSeriesOpacity(seriesNo, normalOpacity);

      if(selectedLegendSymbol.includes(seriesNo) === false) {
        this._showSeriesTooltip(seriesNo, true);
      }

      if(selectedLegendRect.length === zero) {
        const allSeries = this.get('_chartData').series;

        for(let i=0; i < allSeries.length; i++) {
          if(allSeries[i].no !== seriesNo) {
            this._setSeriesOpacity(allSeries[i].no, transparentOpacity);
          }
        }
      }

      // y 축 변경
      this._setCurrentYAxis(series, true);
    },

    mouseoutSeries(series) {
      const seriesNo = series.no;
      //let transparentOpacity = this.get('_settingTransparentOpacity');
      const normalOpacity = this.get('_settingNormalOpacity');
      let opacity = normalOpacity;
      const selectedLegendRect = this.get('_selectedLegendRect');
      const zero = 0;

      if(selectedLegendRect.includes(seriesNo) === true) {
        return;
      }

      //let result = this._onlyOneChecked();
      const selectedLegendRectForNormal = this.get('_selectedLegendRectForNormal');

      for(let i = 0; i < selectedLegendRectForNormal.length; i++) {
        if(selectedLegendRectForNormal[i].seriesNo === seriesNo) {
          opacity = selectedLegendRectForNormal[i].opacity;
          break;
        }
      }

      this._setSeriesOpacity(seriesNo, opacity);

      if(selectedLegendRect.length === zero) {
        const allSeries = this.get('_chartData').series;

        for(let i=0; i < allSeries.length; i++) {
          this._setSeriesOpacity(allSeries[i].no, normalOpacity);
        }
      }

      this._showSeriesTooltip(seriesNo, false);

      // y 축 변경
      if(series.isCustomYAxis === true) {
        const currentYAxis = this.get('_currentYAxis');

        this._replaceYAxisText(currentYAxis);
      }
    },

    selectLegendRect(series) {
      this._selectLegendRect(series);
    },

    selectLegendSymbol(series) {
      this._selectSeriesSymbol(series);
    },

    clickRemoveSeries(sereisNo) {
      this._raiseEvents('onRemoveSeriesClick', sereisNo);
    },

    changeCollapsibleLegend(isCollapsed) {
      const chartData = this.get('_chartData');
      const isCollapsibleLegend = chartData.isCollapsibleLegend;

      if(isCollapsibleLegend === true) {
        chartData.isCollapseLegendPane = isCollapsed;
      }
      this._raiseEvents('onLegendCollapse', isCollapsed);
    },

    clickData(obj) {
      this._raiseEvents('onDataSelect', obj);
    },
  },
});