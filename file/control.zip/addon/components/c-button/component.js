import layout from './template';
import Control from '../c-control/component';
// import ToolTipMixin from '../../mixins/tooltip-mixin';

export default Control.extend({
  layout,
  tagName: 'button',
  classNames: ['c-button', 'btn'],
  attributeBindings: ['notAccessable:disabled', 'tabindex', 'type'],
  //public properties
  style: null,
  title: null,
  type: null,
  content: null,
  tabindex: null,
  disabled: false,
  //public events
  onLoaded: null,
  onUnload: null,
  onClick: null,
  onFocusIn: null,
  onFocusOut: null,

  click(event) {
    this._raiseEvents('onClick', {
      source: this,
      originalEvent: event
    });
  },
  mouseDown(event) {
    this._raiseEvents('onMouseDown', {
      source: this,
      originalEvent: event
    });
  },
  focusIn(event) {
    this._raiseEvents('onFocusIn', {
      source: this,
      originalEvent: event
    });
  },
  focusOut(event) {
    this._raiseEvents('onFocusOut', {
      source: this,
      originalEvent: event
    });
  },
});