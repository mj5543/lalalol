import Ember from 'ember';
import Control from '../fr-control/component';
import computedMixin from '../../mixins/calendar-computed-mixin';
import selectMixin from '../../mixins/calendar-select-common-mixin';
import multiMixin from '../../mixins/calendar-select-multi-mixin';
import singleMixin from '../../mixins/calendar-select-single-mixin';
import loadDataMixin from '../../mixins/calendar-dataload-mixin';
import globalServiceMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';
import contextMenuMixin from '../../mixins/contextmenu-mixin';
import toolTipMixin from '../../mixins/tooltip-mixin';

export default Control.extend(globalServiceMixin, contextMenuMixin, computedMixin, selectMixin, multiMixin, singleMixin, loadDataMixin, toolTipMixin, {
  // == default properties   ==========================
  attributeBindings: ['getSelectedDate','getDisplayDate'],
 // attributeBindings: ['getSelectedDate:date-date'],
  tagName: 'div',
  layout: Ember.computed(function () {
    const template = `{{#if _watchOptions.isMonth }}
                        ${this._getMonthTemplate()}
                      {{/if}}
                      {{#if _watchOptions.isYear }}
                        ${this._getYearTemplate()}
                      {{/if}}
                      {{#if _watchOptions.isDecade }}
                        ${this._getDecadeTemplate()}
                      {{/if}}
                      ` ;

    return Ember.HTMLBars.compile(template);
  }),
  _getMonthTemplate() {
    return `<div class='wrap-calendar {{if isEmbedded 'datepiker' 'calendar-full calendar-day'}}'>
              <table style='width:100%;'>
                <tbody>
                  {{#each _calendars as |calendar index|}}
                  <tr>
                    {{#each calendar as |month index|}}
                    <td>
                      <div class='calendar-in' id='{{month.id}}'>
                        <div class='calendar-field'>
                          {{#if navigationVisibility }}
                          <div class='calendar-nav'>
                            {{#if (fr-inverse-boolean-helper isEmbedded) }}
                            <div class='calendar-today'>
                              {{#if todayNavigationVisibility }}
                              <strong>{{fr-format-date toDay format='D'}}</strong>
                              <div class='button btn btn-sm btn-unit btn-line' onclick={{action 'onMoveToday'}}><span>{{todayText}}</span></div>
                              {{/if}}
                            </div>
                            {{/if}}
                            <div class='calendar-nav-in'>
                              {{#if _watchOptions.isMinCalendarisMonth }}
                                <div class='month-now'>{{ month.month }}</div>
                              {{else}}
                                <div class='month-now' onclick={{action 'onSelectedYear' month.year}}>{{ month.month }}</div>
                              {{/if}}
                              <span class='button calendar-nav-i calendar-nav-pre' onclick={{action 'onMovePrevious' this.displayDate}}><span class='blind'>privisus month</span></span>
                              <span class='button calendar-nav-i calendar-nav-next' onclick={{action 'onMoveNext' this.displayDate}}><span class='blind'>next month</span></span>
                            </div>
                          </div>
                          {{else}}
                          <div class='calendar-nav'>
                            <div class='calendar-nav-in'>
                              <div class='month-now'>{{ month.month }}</div>
                            </div>
                          </div>
                          {{/if}}
                          <div class='calendar-area'>
                            <table>
                              <caption>calendar</caption>
                              <colgroup>
                                <col style='width:15%'>
                                <col span='5' style='width:14%'>
                                <col style='width:15%'>
                              </colgroup>
                              {{#if dayOfWeekHeaderVisibility }}
                              <thead>
                                <tr>
                                  {{#each month.weekdays as |weekday index|}}
                                  <th scope='col'>{{ weekday.name }}</th>
                                  {{/each}}
                                </tr>
                              </thead>
                              {{/if}}
                              <tbody>
                                {{#each month.weeks as |week index|}}
                                <tr style='{{fr-html-safe-helper 'height:' rowHeight 'px;'}}'>
                                  {{#each week as |datacontext index|}}
                                  <td class='fr-calendar-cell cal-d {{if datacontext.hasDisabled 'cal-d-disabled' }} {{if datacontext.hasThisMonth '' 'cal-d-off'}}' data-day='{{datacontext.displayday}}' ondblclick={{action 'onDayButtonDoubleClick' }} onclick={{action 'onDayButtonClick' }}>
                                    <div><strong>{{ datacontext.day }}</strong></div>
                                    {{#unless isEmbedded}}
                                      <div class="cal-txt-area" style={{fr-html-safe-helper 'height:' (fr-numeric-addition-helper rowHeight -32) 'px;overflow:auto;'}}>
                                        ${this.get('itemTemplate')}
                                      </div>
                                    {{/unless}}
                                  </td>
                                  {{/each}}
                                </tr>
                                {{/each}}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    </td>
                    {{/each}}
                  </tr>
                  {{/each}}
                </tbody>
                {{#if isEmbedded }}
                {{#if todayNavigationVisibility }}
                <tfoot>
                  <tr>
                    <td colspan='{{cols}}'>
                      <div class='calendar-today'>
                        <strong>{{fr-format-date toDay format='D'}}</strong>
                        <div class='button btn btn-sm btn-unit btn-line' onclick={{action 'onMoveToday'}}><span>{{todayText}}</span></div>
                      </div>
                    </td>
                  </tr>
                </tfoot>
                {{/if}}
                {{/if}}
              </table>
            </div>` ;
  },
  _getYearTemplate() {
    return `<div class='wrap-calendar {{if isEmbedded 'datepiker' 'calendar-full calendar-period'}}  type03'>
              <div class='calendar-in'>
                <div class='calendar-field'>
                  {{#if navigationVisibility }}
                    <div class='calendar-nav'>
                      <div class='calendar-nav-in'>
                        {{#if _watchOptions.isMinCalendarisYear }}
                        <div class='month-now'>{{_years.year}}</div>
                        {{else}}
                        <div class='month-now' {{action 'onSelectedDecade'}}>{{_years.year}}</div>
                        {{/if}}
                        <span class='button calendar-nav-i calendar-nav-pre' {{action 'onPrevYear' this.displayDate}}><span class='blind'>privisus month</span></span>
                        <span class='button calendar-nav-i calendar-nav-next' {{action 'onNextYear' this.displayDate}}><span class='blind'>next month</span></span>
                      </div>
                    </div>
                  {{else}}
                    <div class='calendar-nav'>
                      <div class='calendar-nav-in'>
                        <div class='month-now'>{{_years.year}}</div>
                      </div>
                    </div>
                  {{/if}}
                  <div class='calendar-area'>
                    <table>
                      <caption>calendar month</caption>
                      <colgroup>
                        <col span='4' style='width:25%'>
                      </colgroup>
                      <tbody>
                        {{#each _years.months as |item|}}
                        <tr style='{{fr-html-safe-helper 'height:' (fr-numeric-addition-helper rowHeight rowHeight) 'px;'}}'>
                          {{#each item as |mm|}}
                          <td class='cal-d' ondblclick={{action 'onMonthButtonDoubleClick'  mm.value}} onclick={{action 'onSelectedMonth' mm.value}}>
                            {{#if on}}
                              <div class='strong'><strong>{{mm.text}}</strong></div>
                            {{else}}
                              <div><strong>{{mm.text}}</strong></div>
                            {{/if}}
                          </td>
                          {{/each}}
                        </tr>
                        {{/each}}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>` ;
  },
  _getDecadeTemplate() {
    return `<div class='wrap-calendar {{if isEmbedded 'datepiker' 'calendar-full calendar-period'}} type03'>
              <div class='calendar-in'>
                <div class='calendar-field'>
                  {{#if navigationVisibility }}
                    <div class='calendar-nav'>
                      <div class='calendar-nav-in'>
                        <div class='month-now'>{{ _decade.decade }}</div>
                        <span class='button calendar-nav-i calendar-nav-pre' {{action 'onPrevDecade' this.displayDate}}><span class='blind'>privisus month</span></span>
                        <span class='button calendar-nav-i calendar-nav-next' {{action 'onNextDecade' this.displayDate}}><span class='blind'>next month</span></span>
                      </div>
                    </div>
                  {{else}}
                    <div class='calendar-nav'>
                      <div class='calendar-nav-in'>
                        <div class='month-now'>{{ _decade.decade }}</div>
                      </div>
                    </div>
                  {{/if}}
                  <div class='calendar-area'>
                    <table>
                      <caption>calendar month</caption>
                      <colgroup>
                        <col style='width:25%'>
                        <col style='width:25%'>
                        <col style='width:25%'>
                        <col style='width:25%'>
                      </colgroup>
                      <tbody>
                        {{#each _decade.years as |item|}}
                        <tr style='{{fr-html-safe-helper 'height:' (fr-numeric-addition-helper rowHeight rowHeight) 'px;'}}'>
                          {{#each item as |year|}}
                          <td class='cal-d' ondblclick={{action 'onYearButtonDoubleClick' year.value}} onclick={{action 'onSelectedYear' year.value}}>
                            <div><strong>{{year.value}}{{year.text}}</strong></div>
                          </td>
                          {{/each}}
                        </tr>
                        {{/each}}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>`;
  },
  classNames: ['fr-calendar'],
  //== Public Properties ==============================
  displayDate: null,
  selectedDate: null,
  toDay: null,
  datePropertyPath: null,
  itemsSource: null,
  itemTemplate: '',
  memoToolTipDatePropertyPath: null,
  memoToolTipTextPropertyPath: null,
  cols: 1,
  dayOfWeekHeaderVisibility: true,
  dayofWeek: 'sunday',
  calendarMode: 'month',
  rowFixed: true,
  rowHeight: 27,
  rows: 1,
  selectionMode: 'singleDate',
  minCalendarMode: 'decade',
  pickerType: 'month',
  navigationVisibility: true,
  todayNavigationVisibility: true,
  todayText: 'Today',
  patternDays: null,
  holiDays: null,
  memoDatas: null,
  eventDays: null,
  maxDate: null,
  minDate: null,
  disabledDates: null,
  isEmbedded: false,
  isInternal: true,
  //== Public Events ==================================
  selectedDatesChanged: null,
  displayDateChanged: null,
  calendarModeChanged: null,
  calendarDayButtonClick: null,
  calendarDayButtonDoubleClick: null,

  // == life cycle ====================================
  init() {
    this._super(...arguments);
    this.set('_useToolTip', true);
    const dt = this.get('co_CommonService').getNow();
    const now = new Date(dt.getFullYear(), dt.getMonth(), dt.getDate(), 0, 0, 0, 0);

    this.set('toDay', now);

    if (Ember.isEmpty(this.get('displayDate'))) {

      if (Ember.isEmpty(this.get('selectedDate'))) {
        this.set('displayDate', now);
      } else {
        this.set('displayDate', this.get('selectedDate'));
      }
    }
  },
  didRender() {
    this._super(...arguments);
    this._destroy();
    this._appendloadData();
  },
  mouseLeave() {
    // ignored
  },
  mouseEnter() {
    // ignored
  },
  willDestroyElement() {
    this._super(...arguments);
    this._destroy();
    this.$().empty();
  },
  //== private ========================================
  _destroy() {
    if (!Ember.isEmpty(this._internalCalendarItems)) {
      this._internalCalendarItems.off('mousedown.calendar')
        .off('mouseup.calendar')
        .off('mousemove.calendar');
    }
  },


  _setCalendarMode(mode) {
    this.set('calendarMode', mode);
    this._raiseEvents('calendarModeChanged', { 'source': this, 'calendarMode': mode, 'displayDate': this.get('displayDate') });
  },
  _isDisableDate(date) {
    const displayday = date.toStandardDateString();

    if (!Ember.isEmpty(this.maxDate)) {
      if (date > this.maxDate) {
        return true;
      }
    }

    if (!Ember.isEmpty(this.minDate)) {
      if (date < this.minDate) {
        return true;
      }
    }

    if (!Ember.isEmpty(this.disabledDates)) {

      const isexists = this.disabledDates.find(function (item) {
        return item.toStandardDateString() === displayday;
      });

      if (isexists) {
        return true;
      }
    }

    return false;
  },
  _onDateSelected(newDate) {
    const oldDate = this.get('selectedDate');

    if (oldDate === newDate) {
      this._onRaiseSelectedDatesChanged(newDate);
    } else {
      this.set('selectedDate', newDate);
    }
  },
  _onRaiseSelectedDatesChanged(date) {
    const events = this.get('selectedDatesChanged');

    if (events) {
      let items = null;

      if (this.selectionMode === 'singleRange' || this.selectionMode === 'multiRange') {
        items = this._getSelectedItems();
      } else {
        items = [date];
      }

      events({ 'source': this, 'dataItem': this._getItem(date), 'selectedDate': date, 'selectedItems': items });
    }
  },
  _getSelectedItems() {
    const items = [];

    if (!Ember.isEmpty(this._internalCalendarItems)) {
      for (let i = 0; i < this._internalCalendarItems.length; i++) {
        const item = this.$(this._internalCalendarItems.eq(i));

        if (item.hasClass('calendar_day_rangesel') === true) {
          items.pushObject(this._yyyymmddToDate(item.data('day')));
        }
      }
    }

    return items;
  },
  _getItem(date) {
    const source = this.get('itemsSource');
    let dataitem = null;
    let displayday = '';

    if (date) {
      displayday = date.toStandardDateString();
    }

    if (!Ember.isEmpty(source)) {
      dataitem = source.find(function (item) {
        return Ember.get(item, this.datePropertyPath).toStandardDateString() === displayday;
      }.bind(this));
    }

    return dataitem;
  },
  _getContext(date) {

    const context = {
      'hasDisabled': this._isDisableDate(date),
      'hasThisMonth': date.getMonth() === this.get('displayDate').getMonth(),
      'displayday': date.toStandardDateString(),
      'day': date.getDate(),
      'date': date,
      'dataItem': this._getItem(date)
    };

    return context;
  },
  // == actions =======================================
  actions: {
    onPrevDecade(thisYear) {
      this.set('displayDate', thisYear.addYears(-10));
    },
    onNextDecade(thisYear) {
      this.set('displayDate', thisYear.addYears(10));
    },
    onPrevYear(thisMonth) {
      this.set('displayDate', thisMonth.addMonths(-12));
    },
    onNextYear(thisMonth) {
      this.set('displayDate', thisMonth.addMonths(12));
    },
    onSelectedDecade() {
      this._setCalendarMode('decade');
    },
    onMoveToday() {

      const _today = this.get('toDay');
      const _displayDay = this.get('displayDate');

      if (_today.getFullYear() === _displayDay.getFullYear() && _today.getMonth() === _displayDay.getMonth()) {
        return;
      }

      this.set('displayDate', _today);

      // const events = this.get('displayDateChanged');

      // if (!Ember.isEmpty(events)) {
      //   const firstDay = new Date(_today.getFullYear(), _today.getMonth(), 1, 0, 0, 0);
      //   const lastDay = new Date(_today.getFullYear(), _today.getMonth() + 1, 0, 0, 0, 0);

      //   events({ 'source': this, 'displayDate': _today, 'firstDay': firstDay, 'lastDay': lastDay, 'selectedDate': this.get('selectedDate') });
      // }
    },
    onSelectedYear(year) {
      if (this.pickerType === 'decade') {
        this._onDateSelected(new Date(year, 0, 1, 0, 0, 0));
      } else {

        const newDisplayDate = new Date(this.displayDate);

        newDisplayDate.setFullYear(year);

        this._setCalendarMode('year');
        this.set('displayDate', newDisplayDate);

        console.log('!@#!@#newDisplayDate', newDisplayDate);

      }
    },
    onSelectedMonth(month) {
      const newDisplayDate = new Date(this.get('displayDate'));

      newDisplayDate.setMonth(month);

      if (this.pickerType === 'year') {
        this._onDateSelected(new Date(this.displayDate.getFullYear(), month, 1, 0, 0, 0));
      } else {
        this._setCalendarMode('month');
        this.set('displayDate', newDisplayDate);

        console.log('!@#!@#newDisplayDate', newDisplayDate);


        //const firstDay = new Date(newDisplayDate.getFullYear(), newDisplayDate.getMonth(), 1, 0, 0, 0);
        //const lastDay = new Date(newDisplayDate.getFullYear(), newDisplayDate.getMonth() + 1, 0, 0, 0, 0);

        //this._raiseEvents('displayDateChanged', { 'source': this, 'displayDate': newDisplayDate, 'firstDay': firstDay, 'lastDay': lastDay, 'selectedDate': this.get('selectedDate') });
      }
    },
    onMovePrevious(thisMonth) {

      const prev = thisMonth.addMonths(-1);
    //  const firstDay = new Date(prev.getFullYear(), prev.getMonth(), 1, 0, 0, 0);
      //const lastDay = new Date(prev.getFullYear(), prev.getMonth() + 1, 0, 0, 0, 0);

      this.set('displayDate', prev);

     // this._raiseEvents('displayDateChanged', { 'source': this, 'displayDate': prev, 'firstDay': firstDay, 'lastDay': lastDay, 'selectedDate': this.get('selectedDate') });
    },
    onMoveNext(thisMonth) {

      const next = thisMonth.addMonths(1);
     // const firstDay = new Date(next.getFullYear(), next.getMonth(), 1, 0, 0, 0);
     // const lastDay = new Date(next.getFullYear(), next.getMonth() + 1, 0, 0, 0, 0);

      this.set('displayDate', next);

      //this._raiseEvents('displayDateChanged', { 'source': this, 'displayDate': next, 'firstDay': firstDay, 'lastDay': lastDay, 'selectedDate': this.get('selectedDate') });
    },
    onYearButtonDoubleClick(year) {
      this.set('selectedDate', new Date(year, 0, 1, 0, 0, 0));
      this._raiseEvents('calendarYearButtonDoubleClick', { 'source': this, 'year': year });
    },
    onMonthButtonDoubleClick(month) {
      this.set('selectedDate', new Date(this.displayDate.getFullYear(), month, 1, 0, 0, 0));
      this._raiseEvents('calendarMonthButtonDoubleClick', { 'source': this, 'year': this.displayDate.getFullYear(), 'month': month });
    },
    onDayButtonDoubleClick(e) {
      if (this.get('selectionMode') !== 'singleDate') {
        return;
      }

      const newDate = new Date(this.$(e.currentTarget).data('day') + 'T00:00:00');
      const dataitem = this._getItem(newDate);
      const context = this._getContext(newDate);

      this._onDateSelected(newDate);

      this._raiseEvents('calendarDayButtonDoubleClick', { 'source': this, 'dataItem': dataitem, 'datacontext': context, 'selectedDate': newDate });
    },
    onDayButtonClick(e) {

      if (this.get('selectionMode') !== 'singleDate') {
        return;
      }

      const newDate = new Date(this.$(e.currentTarget).data('day') + 'T00:00:00');
      const dataitem = this._getItem(newDate);
      const context = this._getContext(newDate);

      this._onDateSelected(newDate);

      this._raiseEvents('calendarDayButtonClick', { 'source': this, 'dataItem': dataitem, 'datacontext': context, 'selectedDate': newDate });
    }
  }
});
