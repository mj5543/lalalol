import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';

export default Control.extend({
  layout,
  tagName: 'span',
  classNames: ['c-radio','inp-rd'],
  classNameBindings: ['_verticalOrientation:vertical', 'enableUncheck:enable-uncheck'],
  attributeBindings: ['tabindex'],
  //public properties
  style: null,
  groupName: null,
  groupValue: null,
  value: null,
  content: null,
  tabindex: null,
  disabled: false,
  readOnly: false,
  enableUncheck: false,
  //public readonly Properties
  checked: Ember.computed.readOnly('_checked'),
  //public events
  onLoaded: null,
  onUnload: null,
  onClick: null,
  onFocusIn: null,
  onFocusOut: null,
  onKeyPress: null,
  onKeyUp: null,
  onKeyDown: null,
  onChanged: null,

  _radiobuttonGuid: Ember.computed.readOnly('componentGuid'),
  _readOnlyOrDisabled: Ember.computed.or('readOnly', 'notAccessable'),
  _checked: Ember.computed('groupValue', 'value', function () {
    return this.get('groupValue') === this.get('value');
  }),
  _observedProperty1: Ember.computed('groupValue', function () {
    Ember.run.once(this, '_syncGroupValue', this.get('groupValue'));
  }),
  focusIn(event) {
    this._raiseEvents('onFocusIn', {
      source: this,
      originalEvent: event
    });
  },
  focusOut(event) {
    this._raiseEvents('onFocusOut', {
      source: this,
      originalEvent: event
    });
  },
  keyPress(event) {
    this._raiseEvents('onKeyPress', {
      source: this,
      originalEvent: event
    });
  },
  keyUp(event) {
    this._raiseEvents('onKeyUp', {
      source: this,
      originalEvent: event
    });
  },
  keyDown(event) {
    this._raiseEvents('onKeyDown', {
      source: this,
      originalEvent: event
    });
  },
  _syncGroupValue(groupValue) {
    const $radioGroup = Ember.$(`input[type=radio][name=${this.get('groupName')}]`);
    let component, $control;

    $radioGroup.each(function (index, element) {
      $control = Ember.$(element).closest('.c-radio');
      if ($control.length > 0) {
        component = this._getComponent($control);
        if (Ember.get(component, 'groupValue') !== groupValue) {
          Ember.set(component, 'groupValue', groupValue);
        }
      }
    }.bind(this));
    component = null;
    $control = null;
  },
  actions: {
    click(event) {
      if (this.$(event.target).is(':radio')) {
        this._raiseEvents('onClick', {
          source: this,
          originalEvent: event
        });
        if (!event.defaultPrevented && this.enableUncheck && this.get('_checked')) {
          Ember.run(this, function () {
            this.set('groupValue', null);
          });
          this._raiseEvents('onChanged', {
            source: this,
            originalEvent: event,
            checked: this.get('_checked'),
            value: this.get('value'),
          });
        }
      }
    },
    change(event) {
      Ember.run(this, function () {
        this.set('groupValue', this.get('value'));
      });
      this._raiseEvents('onChanged', {
        source: this,
        originalEvent: event,
        checked: this.get('_checked'),
        value: this.get('value'),
      });
    },
  },
});