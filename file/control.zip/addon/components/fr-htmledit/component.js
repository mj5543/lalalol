import Ember from 'ember';
import Control from '../fr-control/component';
import layout from './template';

//HtmlEdit
//https://www.npmjs.com/package/ember-cli-simditor
export default Control.extend({
  classNames: ['fr-htmledit'],
  layout,
  // == Private Properties =============================
  _editor: null,
  _option: null,
  _hasinit: false,
  _watchValue: Ember.computed('value', function () {
    if (this._editor) {
      this._editor.setValue(this.get('value'));
    }
    return this.get('value');
  }).readOnly(),
  // == private Methods ================================
  _onGetFocus() {

    if (this.$('.simditor-body').is(':focus')) {
      return;
    }

    this._editor.focus();
  },
  // == public Properties ==============================
  value: '',
  locale: 'en-US',
  disabled: false,
  updateSourceTrigger: false,
  // == public Events ==================================
  valuechanged: null,
  selectionchanged: null,
  focus: null,
  blur: null,
  // == Life Cyclents ==================================
  didInsertElement() {
    this._super(...arguments);

    this.$().on('focus.htmledit', this._onGetFocus.bind(this));

    Simditor.locale = this.get('locale');
    this._option =
      {
        textarea: this.$('textarea'),
        upload: false,
        tabIndent: true,
        toolbar: [
          'title',
          'bold',
          'italic',
          'underline',
          'strikethrough',
          'fontScale',
          'color',
          'ol',
          'ul',
          // 'blockquote',
          // 'code',
          'table',
          'link',
          'image',
          'hr',
          'indent',
          'outdent',
          'alignment'
        ],
        toolbarFloat: false,
        toolbarFloatOffset: 0,
        toolbarHidden: false,
        pasteImage: false,
        cleanPaste: false,
        params: {},
        defaultImage: 'assets/passed.png',
        placeholder: 'Type something here',
        locale: 'en-US',
        name: 'content'
      };

    this._editor = new Simditor(this._option);
    let _value = this.get('value');
    if (_value) {
      this._editor.setValue(_value);
    }

    this._editor.on('valuechanged', function (e) {

      if (this.updateSourceTrigger === true) {
        this.set('value', this._editor.getValue());
      }

      this._raiseEvents('valuechanged', { 'source': this, 'originalSource': this._editor, 'originalEvent': e });
    }.bind(this))
      .on('pasting', function (e, pasteContent) {
        this._raiseEvents('pasting', { 'source': this, 'originalSource': this._editor, 'originalEvent': e, 'pasteContent': pasteContent });
      }.bind(this))
      .on('blur', function (e) {
        this.set('value', this._editor.getValue());
        this._raiseEvents('blur', { 'source': this, 'originalSource': this._editor, 'originalEvent': e });
      }.bind(this))
      .on('focus', function (e) {
        this._raiseEvents('focus', { 'source': this, 'originalSource': this._editor, 'originalEvent': e });
      }.bind(this))
      .on('selectionchanged', function (e) {
        this._raiseEvents('selectionchanged', { 'source': this, 'originalSource': this._editor, 'originalEvent': e });
      }.bind(this));
  },
  didRender() {
    this._super(...arguments);

    let _height = parseInt(this.$().css('height'), 10) - this.$('.simditor-toolbar').height() - 10;

    this.$('.simditor-body').css('height', _height);
  },
  willDestroyElement() {

    this._super(...arguments);

    this.$().off('focus.htmledit');

    if (this._editor) {
      this._editor.destroy();
    }

  }
});
