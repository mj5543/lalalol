import Ember from 'ember';
import layout from './template';

export default Ember.Component.extend( {
  layout,
  tagName : 'div',
  classNames: ['fr-expander-content'],

  didInsertElement() {
    this._super(...arguments);

    this.$('.scrollbar-macosx:not(.scroll-content)').scrollbar();
  },

  willDestroyElement(){
    this._super(...arguments);
    
    this.$('.scrollbar-macosx.scroll-content').scrollbar('destroy');
  },
});