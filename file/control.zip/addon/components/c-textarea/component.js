import Ember from 'ember';
import layout from './template';
import ValidationControl from '../c-validationcontrol/component';

export default ValidationControl.extend({
  layout,
  classNames: ['c-textarea'],
  tagName: 'div',
  //public properties
  style: null,
  tabindex: null,
  placeHolder: null,
  maxLength: null,
  disabled: false,
  readOnly: false,
  maxCharacterCount: null,
  showClearButton: false,
  enableAutoHeight: false,
  minAutoHeight: 22,
  clearPadding: false,
  required: false,
  showValidationSuccess: false,
  externalErrorMessage: null,
  validationRules: null,
  //public events
  onLoaded: null,
  onUnload: null,
  onClick: null,
  onFocusIn: null,
  onFocusOut: null,
  onKeyPress: null,
  onKeyUp: null,
  onKeyDown: null,
  onChanged: null,
  onTextCleared: null,

  _notReadOnly: Ember.computed.not('readOnly'),
  _showClearButtonAndNotReadOnly: Ember.computed.and('showClearButton', '_notReadOnly'),
  _showCharacterCount: Ember.computed.notEmpty('maxCharacterCount').readOnly(),
  _internalValue: Ember.computed('value', 'enableAutoHeight', {
    get (key) {
      if (this.get('enableAutoHeight')) {
        Ember.run.scheduleOnce('afterRender', this, '_resizeTextArea');
      }

      return this.get('value');
    },
    set (key, value) {
      if (this.get('enableAutoHeight')) {
        Ember.run.scheduleOnce('afterRender', this, '_resizeTextArea');
      }

      return value;
    },
  }),
  defaultRules: Ember.computed('_showCharacterCount', function () {
    if (this.get('_showCharacterCount')) {
      return Ember.A().addObject({
        rule: function () {
          return this.get('stringByteLength') <= this.get('maxCharacterCount');
        },
        message: 'The string exceeds the maximum size.'
      });
    }
  }).readOnly(),
  stringByteLength: Ember.computed('_internalValue', function () {
    const _internalValue = this.get('_internalValue');

    if (typeof _internalValue === 'string') {
      return (function (s,b,i,c) {
        for(b=i=0; c=s.charCodeAt(i++); b+=c>>11?3:c>>7?2:1);
        return b;
      })(_internalValue);
    }

    return 0;
  }),
  didInsertElement() {
    this._super(...arguments);
    this.$('.textarea-scrollbar').scrollbar();
  },
  willDestroyElement() {
    this.$('.scrollbar-macosx').scrollbar('destroy');
    this._super(...arguments);
  },
  click(event) {
    this._raiseEvents('onClick', {
      source: this,
      originalEvent: event
    });
  },
  focusIn(event) {
    this._raiseEvents('onFocusIn', {
      source: this,
      originalEvent: event
    });
  },
  focusOut(event) {
    this._syncDataValue();
    this._raiseEvents('onFocusOut', {
      source: this,
      originalEvent: event
    });
  },
  keyPress(event) {
    this._raiseEvents('onKeyPress', {
      source: this,
      originalEvent: event
    });
  },
  keyUp(event) {
    this._raiseEvents('onKeyUp', {
      source: this,
      originalEvent: event
    });
  },
  keyDown(event) {
    this._raiseEvents('onKeyDown', {
      source: this,
      originalEvent: event
    });
  },
  _resizeTextArea() {
    if (this.clearPadding) {
      this.$('textarea').css("cssText", `padding:0 !important;height:${this.get('minAutoHeight')}px !important;`);
      this.$('textarea').css("cssText", `padding:0 !important;height:${this.$('textarea').prop('scrollHeight')}px !important;`);
    } else {
      this.$('textarea').css("cssText", `height:${this.get('minAutoHeight')}px !important;`);
      this.$('textarea').css("cssText", `height:${this.$('textarea').prop('scrollHeight')}px !important;`);
    }
  },
  _syncDataValue() {
    let _internalValue = this.get('_internalValue');

    this.set('value', _internalValue);
    Ember.run.schedule('afterRender', this, function () {
      if (!this.get('isDestroying') && !this.get('isDestroyed')) {
        this.$('textarea').val(_internalValue);
      }
      _internalValue = null;
    });
  },
  actions: {
    delMouseDown(event) {
      event.preventDefault();
      this.set('_internalValue', '');
      this._raiseEvents('onTextCleared', {
        source: this,
        originalEvent: event
      });
    },
    change(event) {
      this._syncDataValue();
      this._raiseEvents('onChanged', {
        source: this,
        originalEvent: event,
        value: this.get('value')
      });
    },
  },
});

