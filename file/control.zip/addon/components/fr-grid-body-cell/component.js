import Ember from 'ember';
import layout from './template';

const { computed } = Ember;

export default Ember.Component.extend({
  tagName: 'td',
  classNameBindings: [ '_gridBodyCellClass', '_gridColumnAlignClass', '_merge:merge', 'selected:selected-cell', 'editing:editing-cell' ],
  attributeBindings: [ 'cellIndex:data-body-cell-index', 'rowspan', 'tabindex' ],
  layout,

  selected: false,
  editing: false,
  tabindex: -1,

  _merge: computed.oneWay('column.merge').readOnly(),
  _min: computed.oneWay('column.min').readOnly(),
  _max: computed.oneWay('column.max').readOnly(),
  _options: computed.oneWay('column.options').readOnly(),
  _selectedValuePath: computed.oneWay('column.selectedValuePath').readOnly(),
  _displayMemberPath: computed.oneWay('column.displayMemberPath').readOnly(),
  _format: computed.oneWay('column.format').readOnly(),
  _noneType: computed.none('column.type').readOnly(),
  _stringType: computed.equal('column.type', 'string').readOnly(),
  _booleanType: computed.equal('column.type', 'boolean').readOnly(),
  _numberType: computed.equal('column.type', 'number').readOnly(),
  _dropdownType: computed.equal('column.type', 'dropdown').readOnly(),
  _dateType: computed.equal('column.type', 'date').readOnly(),
  _noneOrStringType: computed.or('_noneType', '_stringType').readOnly(),
  _notReadOnly: computed.not('_readOnly').readOnly(),
  _allowEditing: computed.and('editable', '_notReadOnly').readOnly(),
  _editing: computed.and('_allowEditing', 'editing'),

  _readOnly: computed('column.readOnly', function () {
    const _readOnly = this.get('column.readOnly');

    if (Ember.typeOf(_readOnly) === 'function') {
      return _readOnly({ cellComponent: this, item: this.get('item'), column: this.get('column') });
    }

    return _readOnly;
  }).readOnly(),

  _pickerType: computed('column.pickerType', function () {
    const _pickerType = this.get('column.pickerType');

    if (!Ember.isNone(_pickerType)) {
      return _pickerType;
    }

    return 'date';
  }).readOnly(),

  _gridBodyCellClass: computed('_gridGuid', function () {
    return `${this.get('_gridGuid')}-body-cell`;
  }).readOnly(),

  _gridColumnAlignClass: computed('column.align', function () {
    const _align = this.get('column.align');

    if (!Ember.isNone(_align)) {
      return _align;
    }

    return 'left';
  }).readOnly(),

  _htmlSafeBooleanClass: computed('_gridGuid', '_allowEditing', '_dataValue', function () {
    return Ember.String.htmlSafe(`${this.get('_gridGuid')}-body-cell-boolean checkbox ${!this.get('_allowEditing') ? 'disabled' : ''} ${this.get('_dataValue') ? 'checked' : ''}`);
  }).readOnly(),

  init() {
    this._super(...arguments);

    const _init = this.get('column.init');

    if (Ember.typeOf(_init) === 'function') {
      _init.call(this, { cellComponent: this, item: this.get('item'), column: this.get('column') });
    }
    if (!Ember.isNone(this.get('column.bodyTemplate'))) {
      Ember.defineProperty(this, 'layout', computed(function () {
        return Ember.HTMLBars.compile(`{{#if description}}{{fr-grid-body-cell-description title=description}}{{/if}}<div style={{_htmlSafeBodyLineHeight}} tabindex="-1"><div>
          {{yield (hash ${this.get('column.bodyTemplate')}=(component 'fr-grid-body-cell-template' editing=_editing item=item column=column rowIndex=rowIndex))}}</div></div>`);
      }));
    }
    if (!Ember.isNone(this.get('column.field'))) {
      Ember.defineProperty(this, '_dataValue', computed(`item.${this.get('column.field')}`, {
        get (key) {
          return this.get(`item.${this.get('column.field')}`);
        },
        set (key, value) {
          this.set(`item.${this.get('column.field')}`, value);

          return value;
        },
      }));
    }
  },

  didInsertElement() {
    this._super(...arguments);

    const _render = this.get('column.render');

    if (Ember.typeOf(_render) === 'function') {
      _render.call(this, { cellComponent: this, item: this.get('item'), column: this.get('column') });
    }
    this.$().on('_getComponent', function (event, param) {
      param.component = this;
      event.stopPropagation();
      event.preventDefault();
    }.bind(this));
  },

  willDestroyElement() {
    this._super(...arguments);

    this.$().off('_getComponent');
  },
});