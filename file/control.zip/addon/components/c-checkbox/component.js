import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';

export default Control.extend({
  layout,
  tagName: 'span',
  classNames: ['c-checkbox', 'inp-chk'],
  classNameBindings: ['_checkedAndIndeterminate:indeterminate'],
  attributeBindings: ['tabindex'],
  //public properties
  style: null,
  value: null,
  content: null,
  checked: false,
  indeterminate: false,
  tabindex: null,
  disabled: false,
  readOnly: false,
  //public events
  onLoaded: null,
  onUnload: null,
  onClick: null,
  onFocusIn: null,
  onFocusOut: null,
  onKeyPress: null,
  onKeyUp: null,
  onKeyDown: null,
  onChanged: null,

  _checkboxGuid: Ember.computed.readOnly('componentGuid'),
  _readOnlyOrDisabled: Ember.computed.or('readOnly', 'notAccessable'),
  _checkedAndIndeterminate: Ember.computed.and('checked', 'indeterminate'),
  focusIn(event) {
    this._raiseEvents('onFocusIn', {
      source: this,
      originalEvent: event
    });
  },
  focusOut(event) {
    this._raiseEvents('onFocusOut', {
      source: this,
      originalEvent: event
    });
  },
  keyPress(event) {
    this._raiseEvents('onKeyPress', {
      source: this,
      originalEvent: event
    });
  },
  keyUp(event) {
    this._raiseEvents('onKeyUp', {
      source: this,
      originalEvent: event
    });
  },
  keyDown(event) {
    this._raiseEvents('onKeyDown', {
      source: this,
      originalEvent: event
    });
  },
  actions: {
    click(event) {
      if (this.$(event.target).is(':checkbox')) {
        this._raiseEvents('onClick', {
          source: this,
          originalEvent: event
        });
      }
    },
    change(event) {
      this.set('checked', this.$(event.target).is(':checked'));
      this._raiseEvents('onChanged', {
        source: this,
        originalEvent: event,
        checked: this.get('checked'),
        value: this.get('value')
      });
    },
  },
});