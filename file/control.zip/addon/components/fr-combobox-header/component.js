import Ember from 'ember';

// fr-control
export default Ember.Component.extend({
  // == Component Properties
  // == Computed ==========================================
  // == public Methods ====================================
  // == Life Cycle ========================================
});