import Ember from 'ember';
import layout from './template';
//import CHIS from 'framework/chis-framework';
import Control from '../c-control/component';
import GlobalServiceContainerMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

export default Control.extend(GlobalServiceContainerMixin, StatefulComponentMixin, {
  layout,

  tagName: 'g',
  classNames: ['fr-chart-bar'],

  chartData: null,
  parentType: null,
  height: null,
  seriesData: null,
  trace: null,
  width: null,
  xAxis: null,
  xScale: null,
  yAxis: null,
  yScale: null,
  setting: null,
  isValidData: null,
  removeSeries: null,

  _chartData: Ember.computed.alias('chartData').readOnly(),
  // isEmpty 면 일반 차트로 처리 , flowsheet 면 flowsheet 차트로 처리
  _parentType: Ember.computed.alias('parentType').readOnly(),
  ////_height: Ember.computed.alias('height').readOnly(),
  _seriesData: Ember.computed.alias('seriesData').readOnly(),
  _trace: Ember.computed.alias('trace').readOnly(),
  _width: Ember.computed.alias('width').readOnly(),
  _xAxis: Ember.computed.alias('xAxis').readOnly(),
  _xScale: Ember.computed.alias('xScale').readOnly(),
  _yAxis: Ember.computed.alias('yAxis').readOnly(),
  _yScale: Ember.computed.alias('yScale').readOnly(),
  _isValidData: Ember.computed.alias('isValidData').readOnly(),
  _removeSeries: Ember.computed.alias('removeSeries').readOnly(),

  _height: Ember.computed('height', 'setting', function() {
    return this.get('height') - this.get('_settingPaddingBottom');
  }),
  _settingPaddingTop: Ember.computed('setting', function() {
    return this.get('setting').paddingTop;
  }),
  _settingPaddingRight: Ember.computed('setting', function() {
    return this.get('setting').paddingRight;
  }),
  _settingPaddingLeft: Ember.computed('setting', function() {
    return this.get('setting').paddingLeft;
  }),
  _settingPaddingBottom: Ember.computed('setting', function() {
    return this.get('setting').paddingBottom;
  }),
  _settingNormalOpacity: Ember.computed('setting', function() {
    return this.get('setting').normalOpacity;
  }),
  _settingDarkOpacity: Ember.computed('setting', function() {
    return this.get('setting').darkOpacity;
  }),
  _settingTransparentOpacity: Ember.computed('setting', function() {
    return this.get('setting').transparentOpacity;
  }),
  _settingGlyphiconPrefix: Ember.computed('setting', function() {
    return this.get('setting').glyphiconPrefix;
  }),

  onPropertyInit() {
    this._super(...arguments);
    this._logTrace('c-chart-bar.initProperties()');

    this.setStateProperties([ 'width', 'height', 'seriesData', 'actionMode', 'chartData',
      'xAxis', 'yAxis', 'xScale',
      'yScale', 'setting', 'reload', 'isValidData',
      'trace'
    ]);
  },

  init() {
    this._super(...arguments);
    this._logTrace('c-chart-bar.init()');
  },

  didInsertElement() {
    this._super(...arguments);
    this._logTrace('c-chart-bar.didInsertElement()');
  },

  didRender() {
    this._super(...arguments);
    this._logTrace('c-chart-bar.didRender()');

    if(Ember.isEmpty(this.get('_chartData'))) {
      return;
    }

    if(this.get('_isValidData') === false) {
      return;
    }

    if(this.get('_parentType') === 'flowsheet') {
      const series = this.get('_seriesData');
      const data = series.data;

      series.data = data.filter( function(d) {
        if( Ember.isEmpty(d[series.config.yAxisProperty])) {
          return false;
        }

        return true;
      });
    }

    this._createSeries();
  },

  willDestroyElement() {
    this._super(...arguments);
    this._logTrace('c-chart-bar.willDestroyElement()');

    this._removeEventListener();
    this._removeDom();

    // 클로저 해제
    this._convertDateFormat = null;
    this._logTrace = null;
  },

  _logTrace(text) {
    if(this.get('_trace') === true) {
      Ember.Logger.log(text);
    }
  },

  _convertDateString(date, format) {
    return this.get('fr_I18nService').formatDate(date, format);
  },

  // date타입 체크 후 변경
  _convertDateFormat(date, isTimeXAxis) {
    if(isTimeXAxis) {
      if(date instanceof Date && date.valueOf() && !Number.isNaN(date.valueOf())) {
        return date;
      } else {
        return new Date(date);
      }
    } else {
      return date;
    }
  },

  _createSeries() {
    const zero = 0;
    const half = 0.5;
    const isTimeXAxis = this.get('_chartData').isTimeXAxis;
    const series = this.get('_seriesData');

    this._logTrace('fr-chart-bar._createSeries()');
    this._removeEventListener();
    this._removeDom();

    // 삭제된 데이터 그래프 삭제
    if (this.get('_removeSeries')) {
      this._removeSeriesDom(this.get('_removeSeries'));
    }

    if(series.data.length === zero) {
      return;
    }

    const xScaleFunction = this.get('_xScale');
    if(Ember.isEmpty(xScaleFunction)) {
      return;
    }
    const tooltipTemplate = series.config.tooltipTemplate;
    const height = parseInt(this.get('_height'));
    const dateFormat = this.get('_chartData').timeFormat.dataFormat;

    let yScaleFunction = null;

    if (series.config.yAxisPosition) {
      const yScale  = this.get('_yScale').filter(obj => {
        const pos = series.config.yAxisPosition || 1;
        return obj.position === pos;
      });
      if (yScale.length) {
        yScaleFunction = yScale[0].scale;
      }
    } else {
      yScaleFunction = this.get('_yScale')
    }

    // let el = this.$().get(zero);
    const el = this.$().parent().get(zero);
    // const seriesRootG = d3.select(el)
    //   .attr('class', 'chart seriesRoot' + series.no)
    //   .attr('data-id', 'seriesRoot' + series.no);
    let seriesRootG;

    if(this.get('_parentType') === 'flowsheet') {
      // el = this.$().parent().get(zero);
      seriesRootG = d3.select(el)
        .select('.main')
        .select('.chartRoot')
        .append('g')
        .attr('class', 'chart seriesRoot' + series.no)
        .attr('data-id', 'seriesRoot' + series.no);
    }
    else {
      seriesRootG = d3.select(el)
        .select('.chartRenderArea')
        .append('g')
        .attr('class', 'chart seriesRoot' + series.no)
        .attr('data-id', 'seriesRoot' + series.no);
    }

    // tooltipTemplate 을 위한 svg 의 sibling 개체
    const p = this.$().parent().parent();

    if(p.children('div.chartTooltipTemplate').length === zero) {
      p.append('<div class=\'chartTooltipTemplate\'></div>');
    }

    const toolTip = d3.select(p[zero]).selectAll('div.chartTooltipTemplate');

    // bar
    seriesRootG
      .selectAll('.chart.bar.series' + series.no)
      .data(series.data)
      .enter()
      .append('rect')
      .attr('class', 'chart bar series' + series.no)
      .attr('x', (d) => {
        const tempWidth = series.config.strokeWidth * half;
        const w = xScaleFunction(this._convertDateFormat(d[series.config.xAxisProperty], isTimeXAxis)) - tempWidth;

        return w;
      })
      .attr('y', function(d) {
        return yScaleFunction(d[series.config.yAxisProperty]);
      })
      .attr('width', series.config.strokeWidth)
      .attr('height', function(d) {
        ////return (height - yAxisPadding) - yScaleFunction(d[series.config.yAxisProperty]);
        return height - yScaleFunction(d[series.config.yAxisProperty]);
      })
      .attr('fill', series.config.strokeColor)
      .on('mouseover', () => {
        this._logTrace('fr-chart-bar.bar.mouseover()');
        this._raiseEvents('mouseoverSeriesCB', series);
        d3.event.stopPropagation();
      })
      .on('mouseout', () => {
        this._logTrace('fr-chart-bar.bar.mouseout()');
        toolTip.style('display', 'none');
        this._raiseEvents('mouseoutSeriesCB', series);
        d3.event.stopPropagation();
      })
      .on('mousemove', d => {
        this._logTrace('fr-chart-bar.bar.mousemove()');

        let button = null;
        if(Ember.isEmpty(d3.event.sourceEvent)) {
          button = d3.event.buttons;
        } else {
          button = d3.event.sourceEvent.buttons;
        }
        if(button === 2) {
          return;
        }

        const adjustX = 10;
        const adjustY = 20;
        const x = d3.event.pageX + adjustX;
        const y = d3.event.pageY + adjustY;

        toolTip.style('left', x + 'px');
        toolTip.style('top', y + 'px');
        toolTip.style('display', 'inline-block');

        if(Ember.isEmpty(tooltipTemplate) || Ember.isBlank(tooltipTemplate) ) {
          let val = d[series.config.tooltipProperty];

          if( typeof val === 'object' && val instanceof Date) {
            val = this._convertDateString(val, dateFormat);
          }

          toolTip.html(val);
        } else {
          let result = tooltipTemplate;

          for(const name in d) {
            let val = d[name];

            if( typeof val === 'object' && val instanceof Date) {
              val = this._convertDateString(val, dateFormat);
            }

            const regexp = new RegExp('{{' + name + '}}', 'gi');

            result = result.replace(regexp, val);
          }
          toolTip.html(result);
        }
      });

    // barTooltip
    const tooltipSize = this.get('_chartData').tooltipSize;

    seriesRootG
      .selectAll('.chart.barTooltip.series' + series.no)
      .data(series.data)
      .enter()
      .append('text')
      .attr('class', 'chart barTooltip series' + series.no)
      .attr('font-size', tooltipSize)
      .attr('text-anchor', 'left')
      .attr('style', 'display: none')
      .attr('transform',
        (d) => {
          const tempWidth = series.config.strokeWidth * half;
          const x = xScaleFunction(this._convertDateFormat(d[series.config.xAxisProperty], isTimeXAxis)) - tempWidth;
          const diff = tooltipSize * half;
          const y = yScaleFunction(d[series.config.yAxisProperty]) - diff;

          return 'translate(' + x + ', ' + y + ')';
        }
      )
      .text(function(d) {
        return d[series.config.tooltipProperty];
      });
  },

  _removeEventListener() {
    const zero = 0;
    const series = this.get('_seriesData');
    const seriesNo = series.no;

    const mouseOverOut = ['.chart.bar.series' + seriesNo];
    const mouseMove = ['.chart.bar.series' + seriesNo];

    const el = this.$().get(zero);
    const thisObj = d3.select(el);

    for(let i=0; i < mouseOverOut.length; i++) {
      thisObj.selectAll(mouseOverOut[i]).on('mouseover', null).on('mouseout', null);
    }

    for(let i=0; i < mouseMove.length; i++) {
      thisObj.selectAll(mouseMove[i]).on('mousemove', null);
    }
  },

  // 삭제된 시리즈 차트에서 삭제
  _removeSeriesDom(remove) {
    const zero = 0;
    const el = this.$().parent().get(zero);
    for (const item of remove) {
      const target = d3.select(el).select('.seriesRoot' + item.no);
      if (target) {
        target.remove();
      }
    }
  },

  _removeDom() {
    const zero = 0;
    const series = this.get('_seriesData');
    const el = this.$().parent().get(zero);
    if(this.get('_parentType') === 'flowsheet') {

      d3.select(el)
        .select('.main >.chartRoot > .seriesRoot' + series.no)
        .remove();
    } else {
      d3.select(el)
        .select('.chartRenderArea > .seriesRoot' + series.no)
        .remove();
      // this.$().children().remove();
    }
  },

  actions: {
  },
});