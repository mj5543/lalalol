import Ember from 'ember';
import Selector from '../fr-selector/component';
const { computed, guidFor } = Ember;

// == fr-radiobutton-list
export default Selector.extend({
  attributeBindings: ['disabled', 'getSelectedItem:data-value'],
  style: null,
  layout: Ember.computed(function () {
    let _itemTemplate = this.get('itemTemplate');
    const _style = this.get('style');

    if (Ember.isEmpty(_itemTemplate)) {
      _itemTemplate = "<span class='alink'>{{get dataItem displayMemberPath }}</span>";
    }

    const template = `<ul style='${_style}'>
                    {{#each itemsSource as |dataItem index|}}
                      <li class='fr-radiobutton-list-item {{itemClass}}' tabindex={{tabindex}}>
                        <span class='fr-radio inp-rd'>
                          <input type='radio' id='{{_itemGroupName}}_{{index}}' value='{{get dataItem selectedValuePath}}' name='{{_itemGroupName}}' disabled={{disabled}} checked={{get dataItem checkValuePath}} onchange={{action 'changedAction' dataItem}} />
                          <label for='{{_itemGroupName}}_{{index}}'>${_itemTemplate}</label>
                        </span>
                      </li>
                    {{/each}}
                    </ul>` ;

    return Ember.HTMLBars.compile(template);
  }),
  tagName: 'div',
  classNames: ['fr-radiobutton-list'],
  checkValuePath: '',
  itemGroupName: '',
  _itemGroupName: computed(function () {
    return guidFor(this);
  }).readOnly(),
  itemClass: '',
  itemTemplate: null,
  useSelectedValue: false,
  isEnableHighlight: false,
  orientation : 'horizontal', // vertical
  selectedItem: null,
  //== Computed Properties =================================
  getSelectedItem: Ember.computed('selectedValue', 'selectedItem', function () {
    const _selectedValue = this.get('selectedValue');
    const _selectedItem = this.get('selectedItem');
    let _newValue = '';

    if (this.useSelectedValue === true) {
      _newValue = _selectedValue;
    } else if (!Ember.isEmpty(_selectedItem) && !Ember.isEmpty(this.selectedValuePath)) {
      _newValue = Ember.get(_selectedItem, this.selectedValuePath);
    }

    if (!Ember.isEmpty(_selectedItem) || !Ember.isEmpty(_selectedValue)) {
      if (!Ember.isEmpty(this.checkValuePath) && !Ember.isEmpty(this.get('itemsSource'))) {
        this.get('itemsSource').forEach(function (item) {
          Ember.set(item, this.checkValuePath, false);
        }.bind(this));

        if (this.useSelectedValue === false) {
          if (!Ember.isEmpty(_selectedItem)) {
            Ember.set(_selectedItem, this.checkValuePath, true);
          }
        }
      }
    }

    if (!Ember.isEmpty(_newValue)) {
      this._getradio(_newValue).prop('checked', true);
    }

    if (this.hasLoaded) {
      Ember.run.once(this, function () {
        this._raiseEvents('selectedChanged', { 'source': this, 'data': _selectedItem, 'value': _newValue });
      }.bind(this));
    }

    return _newValue;

  }).readOnly(),
  //== Public Events =======================================
  selectedChanged: null,
  //== Private Methods =====================================
  _onLabelClick(e) {
    e.stopPropagation();
  },
  _getradio(val) {
    return this.$(`> ul > li > .inp-rd > input:radio[value='${val}']`);
  },
  _getradios() {
    return this.$('> ul > li > .inp-rd > input:radio');
  },
  _getradiocount() {
    return this.$('> ul > li > .inp-rd > input:radio:checked').length;
  },
  _getlabels() {
    return this.$('> ul > li > .inp-rd > label');
  },
  //== Life Cycle ==========================================
  didInsertElement() {
    this._super(...arguments);

    // if (!Ember.isEmpty(this.isEnableHighlight)) {
    //   this.$().addClass('fr-radiobutton-list-highlight') ;
    // }

    const _selectedItem = this.get('selectedItem');
    let _selectedValue = this.get('selectedValue');

    if (Ember.isEmpty(_selectedValue) && !Ember.isEmpty(_selectedItem) && !Ember.isEmpty(this.selectedValuePath)) {
      _selectedValue = Ember.get(_selectedItem, this.selectedValuePath);
    }

    if (!Ember.isEmpty(_selectedValue)) {
      this._getradio(_selectedValue).prop('checked', true);
    }

    this._getlabels().on('click', this._onLabelClick.bind(this));

    if ( this.get('orientation') === 'vertical') {
      this.$().addClass('vertical') ;
    }
  },
  willDestroyElement() {
    this._super(...arguments);
    this._getlabels().off('click');
  },
  //== Event Handler========================================
  actions: {
    changedAction(addItem) {

      if (this.useSelectedValue === true) {
        this.set('selectedValue', Ember.get(addItem, this.selectedValuePath));
      } else {
        this.set('selectedItem', addItem);
      }
    }
  }
});