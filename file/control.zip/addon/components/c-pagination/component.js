import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';

export default Control.extend( {

  // == Component properties ===============================================
  classNames: ['c-pagenavigation', 'paging'],
  layout,
  tagName : 'div',
  // == private properties =================================================
  _startAt : 0,
  _endAt : 0,
  pages : 0,
  // == Public properties ==================================================
  blockSize : 0,
  currentPage : 1,
  recordCount : 0,
  recordSize : 0,
  onChanged : null,
  // == Computed properties ==================================================
  _watchIsdata : Ember.computed('currentPage', 'recordCount', 'recordSize', 'blockSize', function() {
    this.set('pages', parseInt( this.get('recordCount') / this.get('recordSize')));

    if ((this.get('recordCount') % this.get('recordSize')) > 0) {
      this.set('pages', this.get('pages')+1);
    }
    return this._calculates();

  }).readOnly(),
  // == Life Cycles ==========================================================
  didInsertElement() {
    this._super(...arguments);
  },
  //== private Methods =======================================================
  _raiseEvent() {
    const events = this.get('onChanged');

    if ( events) {
      events({'source' : this, 'page' : this.get('currentPage'), 'pages' : this.get('pages')});
    }
    // this._raiseEvents('onChanged', {
    //   source: this,
    //   'page' : this.get('currentPage'),
    //   'pages' : this.get('pages')
    // });
  },
  _calculates() {
    let rest = parseInt(this.get('currentPage')) % parseInt(this.get('blockSize'));

    if (rest === 0) {
      rest = parseInt(this.get('blockSize'));
    }
    this._startAt = parseInt(this.get('currentPage')) - rest + 1;
    if (this._startAt <= 0) {
      this._startAt = 1;
    }
    this._endAt = this._startAt + parseInt(this.get('blockSize')) - 1;
    if (this._endAt > this.get('pages')) {
      this._endAt = this.get('pages');
    }
    /* if (this._startAt === this._endAt) {
      this._endAt = 2;
    } */
    const tmp = Ember.A();

    for (let index = this._startAt; index <= this._endAt; index++) {
      tmp.addObject({ 'index' : index, 'isSelected' :  index === this.get('currentPage') }) ;
    }
    return {
      items : tmp,
      isFirst : this._startAt === 1,
      isPrev : this._startAt === 1,
      isNotFirst : this._startAt > 1,
      isNotLast: this._endAt < this.get('pages'),
      isNext : this._endAt === this.get('pages'),
      isLast : this._endAt === this.get('pages')
    } ;

  },
  //== Action Methods =======================================================
  actions: {
    onMoveFirst() {
      this.set('currentPage', 1) ;
      this._raiseEvent();
    },
    onMovePrev() {
      this.set('currentPage', this._startAt - 1) ;
      this._raiseEvent();
    },
    onMoveNext() {
      this.set('currentPage', this._endAt + 1) ;
      this._raiseEvent();
    },
    onMoveLast() {
      this.set('currentPage', this.get('pages'));
      this._raiseEvent();
    },
    onSelected(index) {
      this.set('currentPage', index);
      this._raiseEvent();
    }
  }
});
