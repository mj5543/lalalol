import Control from '../fr-control/component';
import Ember from 'ember';

// == JsonView
export default Control.extend({
  // == Component Properties ===================================
  attributeBindings: ['getValue:data-length'],
  classNames: ['fr-jsonview'],
  tagName : 'div',
  isCollapserEnable : true,
  // == Computed Properties ====================================
  getValue: Ember.computed('value', function() {
    let newValue = this.get('value') ;

    if (Ember.isEmpty(newValue)) {
      this.$().html('');
    } else {
      this.$().JSONView(newValue, {collapsed: this.get('collapsed'), nl2br: this.get('nl2br')});
    }

    if ( this.get('isCollapserEnable') === false) {
      this.$('.collapser').remove();
    }

    return Ember.isEmpty(newValue) ? 0 : JSON.stringify(newValue).length ;
  }).readOnly(),
  // == Public Properties ======================================
  collapsed : true,
  nl2br : true,
  value : null,
  // == Public Events ==========================================
  // == Private Properties =====================================
  // == Public Methods =========================================
  // == Life Cycle =============================================
  didInsertElement(){
    this._super(...arguments);
  },
  // == Actions ================================================
  actions: {
  }
});