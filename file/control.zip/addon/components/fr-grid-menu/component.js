import Ember from 'ember';

const { computed } = Ember;

export default Ember.Component.extend({
  tagName: 'div',
  classNames: [ 'fr-grid-menu' ],

  init() {
    this._super(...arguments);

    if (this.get('_targetColumn.menuTemplate')) {
      Ember.defineProperty(this, 'layout', computed(function () {
        return Ember.HTMLBars.compile(`{{yield (hash ${this.get('_targetColumn.menuTemplate')}=(component 'fr-grid-menu-template' targetColumn=_targetColumn))}}`);
      }));
    }
  },
});