// import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';

export default Control.extend({
  layout,
  tagName: 'div',
  classNames: ['draw-content-area'],
  classNameBindings: ['position'],
  click(event) {
    if(this.get('mode') === 'open' && this.get('isOpen')) {
      this._raiseEvents('onDimClick');
    }
  },
});