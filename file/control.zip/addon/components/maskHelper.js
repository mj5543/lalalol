import Ember from 'ember';

// MaskedInput
// https://github.com/digitalBush/jquery.maskedinput

const maskinputHelper = Ember.Object.extend({
  _defs : null,
  _tests : null,
  _partialPosition : null,
  _firstNonMaskPos : null,
  _lastRequiredNonMaskPos : null,
  _defaultBuffer : null,
  _len : null,
  _buffer : null,
  _caretTimeoutId : null,
  _focusText : '',
  _$element : null,
  _definitions : null,
  _wasValue : null,
  textCommit : null,
  textCancel : null,
  autoclear : true,
  partialModify : false,
  mask : null,
  definitions : null,
  maskPlaceholder : '_',
  init(){
    this._super(...arguments);
    this.set('_definitions', { '9': "[0-9]", 'a': "[A-Za-z]", '*': "[A-Za-z0-9]" });
  },
  _getPlaceholder(i){
    if(i < this.maskPlaceholder.length){
      return this.maskPlaceholder.charAt(i);
    }
    return this.maskPlaceholder.charAt(0);
  },
  _seekNext(pos) {
    while (++pos < this._len && !this._tests[pos]){
      return pos;
    };
  },
  _seekPrev(pos) {
    while (--pos >= 0 && !this._tests[pos]){
      return pos;
    }
  },
  _shiftL(begin,end) {
    let i, j;

    if (begin<0) {
      return;
    }

    if (!this.partialModify) {
      for (i = begin, j = this._seekNext(end); i < this._len; i++) {
        if (this._tests[i]) {
          if (j < this._len && this._tests[i].test(this._buffer[j])) {
            this._buffer[i] = this._buffer[j];
            this._buffer[j] = this._getPlaceholder(j);
          } else {
            break;
          }
          j = this._seekNext(j);
        }
      }
    }

    this._writeBuffer();
    this._caret(Math.max(this._firstNonMaskPos, begin));
  },
  _shiftR(pos) {
    if (!this.partialModify) {
      let i, c, j, t;
      for (i = pos, c = this._getPlaceholder(pos); i < this._len; i++) {
        if (this._tests[i]) {
          j = this._seekNext(i);
          t = this._buffer[i];
          this._buffer[i] = c;
          if (j < this._len && this._tests[j].test(t)) {
            c = t;
          } else {
            break;
          }
        }
      }
    }
  },
  _clearBuffer(start, end) {
    let i;
    for (i = start; i < end && i < this._len; i++) {
      if (this._tests[i]) {
        this._buffer[i] = this._getPlaceholder(i);
      }
    }
  },
  _writeBuffer() {
    this._$element.val(this._buffer.join(''));
  },
  _checkVal(allow) {

    //try to place characters where they belong
    let test = '' ;
    let lastMatch = -1 ;
    let i ;
    let c ;
    let pos ;

    if ( !Ember.isEmpty(this._$element)) {
      test = this._$element.val() ;
    }

    for (i = 0, pos = 0; i < this._len; i++) {
      if (this._tests[i]) {
        this._buffer[i] = this._getPlaceholder(i);
        while (pos++ < test.length) {
          c = test.charAt(pos - 1);
          if (this._tests[i].test(c)) {
            this._buffer[i] = c;
            lastMatch = i;
            break;
          }
        }
        if (pos > test.length) {
          this._clearBuffer(i + 1, this._len);
          break;
        }
      } else {
        if (this._buffer[i] === test.charAt(pos)) {
          pos++;
        }
        if( i < this._partialPosition){
            lastMatch = i;
        }
      }
    }
    if (allow) {
      this._writeBuffer();
    } else if (lastMatch + 1 < this._partialPosition) {
      if (this.autoclear || this._buffer.join('') === this._defaultBuffer) {
        // Invalid value. Remove it and replace it with the
        // mask, which is the default behavior.
        if(this._$element.val()) {
          this._$element.val('');
        }
        this._clearBuffer(0, this._len);
      } else {
        // Invalid value, but we opt to show the value to the
        // user and allow them to correct their mistake.
        this._writeBuffer();
      }
    } else {
      this._writeBuffer();
      this._$element.val(this._$element.val().substring(0, lastMatch + 1));
    }
    return this._partialPosition ? i : this._firstNonMaskPos;
  },
  _caret(begin, end) {
    let range;

    if ( this._$element.is(":hidden") || this._$element.get(0) !== document.activeElement) {
      return;
    }

    if (typeof begin == 'number') {
      end = typeof end === 'number' ? end : begin;

      return this._$element.each(function(index, element) {
        if (element.setSelectionRange) {
          element.setSelectionRange(begin, end);
        } else if (element.createTextRange) {
          range = element.createTextRange();
          range.collapse(true);
          range.moveEnd('character', end);
          range.moveStart('character', begin);
          range.select();
        }
      }.bind(this));
    } else {
      if (this._$element[0].setSelectionRange) {
        begin = this._$element[0].selectionStart;
        end = this._$element[0].selectionEnd;
      } else if (document.selection && document.selection.createRange) {
        range = document.selection.createRange();
        begin = 0 - range.duplicate().moveStart('character', -100000);
        end = begin + range.text.length;
      }
      return { begin: begin, end: end };
    }
  },
  _tryFireCompleted(){

    const isValid = this._isValidationComplete();

    if ( isValid === true || this._$element.val().length === 0) {
      return this._raiseTextCommit();
    } else {
      return this._raiseTextCancel() ;
    }
  },
  _raiseTextCancel() {

    this._wasValue = null;

    this._clearBuffer(0, this._len);
    if (!Ember.isEmpty(this.textCancel)) {
      this.textCancel();
    }

    return false ;
  },
  _raiseTextCommit() {
    if (Ember.isEmpty(this.textCommit)) {
      return ;
    }

    const newValue = this.unMaskedValue() ;

    if ( Ember.isEmpty(this._wasValue) && Ember.isEmpty(newValue)) {
      return ;
    }

    if ( Ember.isEmpty(this._wasValue) || newValue !== this._wasValue) {
      this._wasValue = newValue ;
      this.textCommit( { text : this._$element.val(), value : newValue});
    }

    return true ;
  },
  _isValidationComplete(){
    for (let i = this._firstNonMaskPos; i <= this._lastRequiredNonMaskPos; i++) {
      if (this._tests[i] && this._buffer[i] === this._getPlaceholder(i)) {
        return false;
      }
    }

    return true;
  },
  _onFocus() {
    if (this._$element.prop('readonly') === true){
      return;
    }

    clearTimeout(this._caretTimeoutId);

    let pos;

    this._focusText = this._$element.val();

    pos = this._checkVal();

    this._caretTimeoutId = setTimeout(function(){
      if(this._$element.get(0) !== document.activeElement){
        return;
      }
      this._writeBuffer();
      if (pos == this.mask.replace("?","").length) {
        this._caret(0, pos);
      } else {
        this._caret(pos);
      }
    }.bind(this), 10);
  },
  _onBlur() {
    this._checkVal();

    if (this._$element.val() != this._focusText) {
      this._$element.change();
    }

    if ( this._isValidationComplete() !== true ) {
      return this._raiseTextCancel() ;
    }

    this._raiseTextCommit();
  },
  _onKeyDown(e) {

    if (this._$element.prop('readonly') === true){
      return;
    }

    let k = e.which || e.keyCode ;
    let pos;
    let begin;
    let end;

    if (k === 8 || k === 46 ) {
      pos = this._caret();
      begin = pos.begin;
      end = pos.end;

      if (end - begin === 0) {
        begin = k !== 46 ? this._seekPrev(begin) : end = this._seekNext(begin-1);
        end = k === 46 ? this._seekNext(end) : end;
      }
      this._clearBuffer(begin, end);
      this._shiftL(begin, end - 1);

      e.preventDefault();
      // enter
    } else if( k === 13 ) {

      this._checkVal();

      if (this._$element.val() != this._focusText) {
        this._$element.change();
      }

      this._tryFireCompleted();
      // escape
    } else if (k === 27) {
      this._$element.val(this._focusText);
      this._$element._caret(0, this._checkVal());
      e.preventDefault();
    }
  },
  _onKeyPress(e) {

    if (this._$element.prop('readonly') === true){
      return false;
    }

    let k = e.which || e.keyCode ;
    let pos = this._caret();
    let p;
    let c;
    let next;

    //Ignore
    if (e.ctrlKey || e.altKey || e.metaKey || k < 32) {
      return;
    } else if ( k && k !== 13 ) {
      if (pos.end - pos.begin !== 0){
        this._clearBuffer(pos.begin, pos.end);
        this._shiftL(pos.begin, pos.end-1);
      }

      p = this._seekNext(pos.begin - 1);
      if (p < this._len) {
        c = String.fromCharCode(k);
        if (this._tests[p].test(c)) {
          this._shiftR(p);

          this._buffer[p] = c;
          this._writeBuffer();
          next = this._seekNext(p);

          this._caret(next);
        }
      }
      e.preventDefault();

      return false;
    }
  },
  _onPaste(e) {
    if (this._$element.prop('readonly') === true){
      return;
    }

    setTimeout(function() {
      let pos = this._checkVal(true);
      this._caret(pos);
    }.bind(this), 0);
  },
  clear() {
    this._wasValue = null;

    if (!Ember.isEmpty(this._$element)) {
      this._$element.val('');
    }

    this._clearBuffer(0, this._len);
  },
  destroy() {

    if ( Ember.isEmpty(this._$element)) {
      return ;
    }

    this._$element.off('unmask')
      .off('focus.mask')
      .off('blur.mask')
      .off('keydown.mask')
      .off('keypress.mask')
      .off('input.mask paste.mask');

  },
  setMask(newValue) {

    if ( Ember.isEmpty(this._$element)) {
      return ;
    }

    if ( !Ember.isEmpty(newValue)) {
      this._$element.val(newValue);
      this._wasValue = newValue;
    }

    this.destroy();

    this._defs = this._definitions ;

    if (!Ember.isEmpty(this.definitions)) {
      this._defs = Ember.$.extend( this._defs,this.definitions);
    }

    this._tests = [];
    this._partialPosition = this._len = this.mask.length;
    this._firstNonMaskPos = null;

    this.mask.split('').forEach( function(c, i) {
      if (c == '?') {
        this._len--;
        this._partialPosition = i;
      } else if (this._defs[c]) {
        this._tests.push(new RegExp(this._defs[c]));
        if (this._firstNonMaskPos === null) {
          this._firstNonMaskPos = this._tests.length - 1;
        }

        if(i < this._partialPosition){
          this._lastRequiredNonMaskPos = this._tests.length - 1;
        }
      } else {
        this._tests.push(null);
      }
    }.bind(this));

    this._buffer = Ember.$.map( this.mask.split(''), function(c, i) {
      if (c != '?') {
        return this._defs[c] ? this._getPlaceholder(i) : c;
      }
    }.bind(this)) ;

    this._defaultBuffer = this._buffer.join('') ;
    this._focusText = this._$element.val();

    this._$element.one('unmask', function() {
      this._$element.off('.mask');
    }.bind(this))
      .on('focus.mask', this._onFocus.bind(this))
      .on('blur.mask', this._onBlur.bind(this))
      .on('keydown.mask', this._onKeyDown.bind(this))
      .on('keypress.mask', this._onKeyPress.bind(this))
      .on('input.mask paste.mask', this._onPaste.bind(this));

    this._checkVal();
  },
  unMaskedValue() {

    if ( Ember.isEmpty(this._buffer)) {
      return '' ;
    }

    return Ember.$.map(this._buffer, function(c, i) {
      return this._tests[i] && c !== this._getPlaceholder(i) ? c : null;
    }.bind(this)).join('');
  }
});

export default maskinputHelper;