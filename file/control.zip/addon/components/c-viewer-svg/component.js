import Ember from 'ember';
import layout from './template';
// import CHIS from 'framework/chis-framework';
import Control from '../c-control/component';

export default Control.extend({
  layout,
  tagName: 'div',
  classNames: ['c-viewer'],
  style: null,
  width: null,
  height: null,
  _radian: null,
  _svg: null,
  _scale: null,
  _startX: null,
  _startY: null,
  _imageX: null,
  _imageY: null,
  _canMouseX: null,
  _canMouseY: null,
  _isDragging: null,
  _targetImg: null,
  _resizeRate: null,
  _y: null,
  _x: null,
  _zoomIntensity: Ember.computed('zoomIntensity', function() {
    return !Ember.isEmpty(this.get('zoomIntensity')) ? this.get('zoomIntensity') : 0.2;
    // return this.get('zoomIntensity')
  }).readOnly(),
  // _itemSource: Ember.computed('itemSource', function() {
  //   const data = this.get('itemSource');
  //   if (!Ember.isEmpty(data)) {
  //     Ember.run.debounce(() => this._resetCanvas());
  //   }

  //   return data;
  // }),
  itemSourceData: Ember.computed('itemSource', function() {
    // debugger;
    return !Ember.isEmpty(this.get('itemSource')) ? this.get('itemSource') : false;
    // return this.get('zoomIntensity')
  }).readOnly(),
  onPropertyInit(){
    this._super(...arguments);
    this.setStateProperties(['']);
    if (this.hasState() === false) {
      this.set('_radian', 0);
      this.set('_scale', 1);
      this.set('_x', 1);
      this.set('_y', 1);
      this.set('_isDragging', false);
    }
  },

  didInsertElement(){
    this._super(...arguments);
    const svg = document.querySelector('.svg-viewer');
    this.set('_svg', svg);

    this.set('width', this.$().width());
    this.set('height', this.$().height());

    // svg.addEventListener('mousedown', e => this._handleMouseDown(e));
    // svg.addEventListener('mousemove', e => this._handleMouseMove(e));
    // svg.addEventListener('mouseup', e => this._handleMouseUp(e));
    // svg.addEventListener('mouseout', e => this._handleMouseOut(e));
  },
  willDestroyElement() {
    // this.element.removeChild(this.get('_svg'));
    this.set('_svg', null);
    this.$().off('keydown');
    this._super(...arguments);
  },

  _createCanvas() {

  },

  _getMousePosition(e) {
    const offsetX = this.get('_svg').getBoundingClientRect().left;
    const offsetY = this.get('_svg').getBoundingClientRect().top;
    this.set('_startX', parseInt(e.clientX - offsetX, 10));
    this.set('_startY', parseInt(e.clientY - offsetY, 10));
  },

  _handleMouseDown(e){
    // console.log('_handleMouseDown');
    this._getMousePosition(e);
    this.set('_isDragging', true);
  },

  _handleMouseUp(e) {
    // console.log('_handleMouseUp');
    this._getMousePosition(e);
    this.set('_isDragging', false);
    this.$().css('cursor', 'context-menu');
  },

  _handleMouseOut(e){
    // console.log('_handleMouseOut');
    this._getMousePosition(e);
    this.set('_isDragging', false);
  },

  _handleMouseMove(e){
    // this._getMousePosition(e);
    const svg = this.get('_svg');
    const scale = this.get('_scale');
    const resizeRate = this.get('_resizeRate') || 1;
    const startX = this.get('_startX');
    const startY = this.get('_startY');

    if (
        this.get('_isDragging')
        && (this.get('_targetImg').width * scale * resizeRate > svg.width || this.get('_targetImg').height * scale * resizeRate > svg.height)
        && !this.get('_radian')
      ) {

      this.$().css('cursor', 'grabbing');
      const offsetX = svg.getBoundingClientRect().left;
      const offsetY = svg.getBoundingClientRect().top;
      this.set('_canMouseX', parseInt(e.clientX - offsetX, 10));
      this.set('_canMouseY', parseInt(e.clientY - offsetY, 10));

      const dx = this.get('_canMouseX') - startX;
      const dy = this.get('_canMouseY') - startY;

      this._imageX += dx;
      this._imageY += dy;

      this.set('_imageX', Math.max(0, this.get('_imageX')));
      this.set('_imageY', Math.max(0, this.get('_imageY')));


      this.set('_startX', this.get('_canMouseX'));
      this.set('_startY', this.get('_canMouseY'));
    }
  },

  _setScale(wheel) {
    const zoom = Math.exp(wheel * this.get('_zoomIntensity'));
    const scale = this.get('_scale') || 1;

    this.set('_x', scale * zoom);
    this.set('_y', scale * zoom);
    this.set('_scale', scale * zoom);
    this._createCanvas();
  },
  _resetCanvas() {
    this.set('_radian', 0);
    this.set('_scale', 1);
    this.set('_x', 1);
    this.set('_y', 1);
    this._createCanvas();
  },
  actions: {
    clearCanvas() {

    },
    rotate(e) {
      // 90도 회전
      this.set('_radian', Number(this.get('_radian')) + e);
      this._createCanvas();
    },
    mouseWheel(e) {
      e.preventDefault();
      const wheel = e.deltaY < 0 ? 1 : -1;

      this._setScale(wheel);
    },
    // 캔버스 reset
    resetCanvas() {
      this._resetCanvas();
    },
    // 확대
    zoomIn() {
      this._setScale(1);
    },
    // 축소
    zoomOut() {
      this._setScale(-1);
    },
    // 100%
    zoomFit() {
      this.set('_scale', 1);
      this.set('_x', 1);
      this.set('_y', 1);
      this._createCanvas();
    },
    // 저장
    saveCanvas() {

    }
  }
});