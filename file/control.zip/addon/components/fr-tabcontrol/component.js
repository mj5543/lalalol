import Ember from 'ember';
import Template from './template';
import Selector from '../fr-selector/component';
import ContextMenuMixin from '../../mixins/contextmenu-mixin';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

// TabControl
export default Selector.extend(ContextMenuMixin, StatefulComponentMixin, {

  // == Component properties ================
  attributeBindings: ['getSelectedName:data-name'],
  classNames: ['fr-tabcontrol'],
  layout : Template,
  tagName: 'div',
  // == Public Properties ====================
  allowTabClosing : false,
  nameMemberPath : 'id',
  displayMemberPath : 'header',
  isDataBind : false,
  tabControlStyleType : null,
  postTabItemContent : '',
  tabItemCloseButtonVisibility : false,
  tabClosing : null,
  tabClosed : null,
  tabStripPlacement : '',
  selectedName : null,
  canUseHeaderTemplate : false,
  isColllectionOpen : false,
  isTabCollection:false,
  isTabAdd:false,

  //== Private Properties ==================
  _internalItemsSource : null,
  _tabCollectionSource: null,
  _tabControlClass : null,
  _tabAddFix:null,
  _tabAdd:null,

  //== Computed Properties ==================
  getSelectedName: Ember.computed('selectedName', function() {
    const tabid = this.get('selectedName') ;

    if ( Ember.isEmpty(tabid) ) {
      return '';
    }

    return tabid;
  }).readOnly(),
  // == Private Methods =======================
  _tapCollectionOpening(){
    if(this.isTabCollection){
      const navItems = this.$().find('.fr-tabcontrol-nav').first();
      let sum = 0, isOpen = false;

      navItems.children().each(function (index, element) {
        sum += element.offsetWidth;
        if(sum > navItems.context.offsetWidth){
          isOpen = true;

          return false;
        }
      });
      if(this.isTabAdd){
        if(isOpen){
          this._tabAddFix.addClass('active');
          this._tabAdd.removeClass('active');
        }else{
          this._tabAdd.addClass('active');
          this._tabAddFix.removeClass('active');
        }
      }
      this.set('isColllectionOpen', isOpen);
    }
  },
  _onContextMenuOpening(){
  },
  _getInternalItemsSource(){
    if (!Ember.isEmpty(this.get('itemsSource'))) {
      return this.get('itemsSource') ;
    }

    const _internalSource = this.get('_internalItemsSource') ;
    if ( Ember.isEmpty(_internalSource)) {
      this.set('_internalItemsSource', []);
    }

    return this.get('_internalItemsSource') ;
  },
  // == Life Cycle Event =======================
  onPropertyInit() {
    this._super(...arguments);
    this.setStateProperties(['selectedName']);

    switch ( this.tabControlStyleType ) {
      case "twoDepth" :
      this.set('_tabControlClass', 'tab-sub');
      break;
      case "threeDepth" :
      this.set('_tabControlClass', '');
      break;
      case "customStyle" :
      this.set('_tabControlClass', '');
      break;
      default :
      this.set('_tabControlClass', 'tab');
      break;
    }
  },
  didRender(){
    this._super(...arguments);
    if(this.isTabCollection){
      const navItems = this.$().find('.fr-tabcontrol-nav').first();
      let sum = 0;

      navItems.children().each(function (index, element) {
        sum += element.offsetWidth;
        if(sum > navItems.context.offsetWidth){
          this.set('isColllectionOpen', true);
          if(this.isTabAdd){
            this._tabAddFix.addClass('active');
            this._tabAdd.removeClass('active');
          }

          return false;
        }
      }.bind(this));
    }
  },
  didInsertElement(){
    this._super(...arguments);

    this._tabAddFix = this.$().find('.tab-add-fix').first();
    this._tabAdd = this.$().find('.tab-add').first();

    if(this.isTabAdd){
      this._tabAdd.addClass('active');
    }

    this.set('_tabCollectionSource', []);

    switch ( this.tabStripPlacement){
      case "left" :
        this.$().addClass('left') ;
        break;
      default :
        break;
    }

    const _internalSource = this._getInternalItemsSource();

    if (!Ember.isEmpty(_internalSource)) {
      let tabid = this.get('selectedName') ;

      let item = this._getInternalItemsSource().findBy(this.nameMemberPath, tabid) ;
      if ( Ember.isEmpty(item)) {
        tabid = null ;
      }

      if (Ember.isEmpty(tabid)) {
        this.set('selectedName', Ember.get(_internalSource.objectAt(0), this.nameMemberPath));
      } else {
        this.set('selectedName', tabid);
      }
    }
  },
  actions: {
    onTabAdd(){
      this._raiseEvents('tabAdding');
    },
    onRenderAction(item) {
      this._getInternalItemsSource().pushObject(item);
    },
    onSelectedAction(e) {
      if (!this.hasLoaded ) {
        return ;
      }

      Ember.set(e, 'source', this);
      this.set('selectedItem', e.dataItem);
      this._raiseEvents('selectedChanged', e);
    },
    onTabChangedAction(e){
      this._tapCollectionOpening();
      const tabid = Ember.get(e, this.nameMemberPath);
      this.set('selectedName', tabid);
    },
    onTabClosingAction(e) {
      this._raiseEvents('tabClosing', e) ;
      this._tapCollectionOpening();

      if ( e.cancel === false) {

        const _item = e.originalSource.dataItem;
        let _name = null;

        if ( !Ember.isEmpty(_item)) {

          if ( Ember.isEmpty(this.itemsSource)) {
            this.get('_internalItemsSource').removeObject(_item);

            if (!Ember.isEmpty(this.get('_internalItemsSource'))) {
              _name = Ember.get(this.get('_internalItemsSource').objectAt(0), this.nameMemberPath);
            }

          } else {
            this.get('itemsSource').removeObject(_item) ;

            if (!Ember.isEmpty(this.get('itemsSource'))) {
              _name = Ember.get(this.get('itemsSource').objectAt(0), this.nameMemberPath);
            }
          }
        }

        this.set('selectedName', _name);

        this._raiseEvents('tabClosed', { source : null, originalSource : this});
      }
    }
  }
});