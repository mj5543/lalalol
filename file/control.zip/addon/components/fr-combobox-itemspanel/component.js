import Ember from 'ember';
import layout from './template';

// ComboBox-ItemsPanel
export default Ember.Component.extend({
  attributeBindings: ['watchtoScrollTop:data-index', 'tabindex'],
  layout,
  classNames: ['fr-combobox-options', 'scrollbar-macosx'],
  tagName: 'div',
  owner: null,
  panelId: null,
  lineHeight: 25,
  scrollIndex: 0,
  isAutoScroll:false,
  isDesignScroll :true,
  watchtoScrollTop: Ember.computed('scrollIndex', function () {

    let index = parseInt(this.get('scrollIndex'));

    let top = 0;

    if (index < 1) {
      index = 1;
    }

    top = (index * this.lineHeight) - this.lineHeight;

    this.$().scrollTop(top);

    return top;

  }).readOnly(),
  _onSelected(dataItem) {
    this.owner._onSelected(dataItem);
  },
  didInsertElement() {
    this._super(...arguments);

    let options = this.$('.fr-combobox-option');

    options.removeClass('.select');

    let height = this.owner.dropDownHeight;

    if (options.length * this.lineHeight >= this.owner.maxDropDownHeight) {
      height = this.owner.maxDropDownHeight;
    } else if (options.length * this.lineHeight <= this.owner.minDropDownHeight) {
      height = this.owner.minDropDownHeight;
    }

    if ( this.get('isDesignScroll') === false) {
      this.$().css('height', height) ;
    }

    let active = this.$().find('.on');

    if (active.length === 1) {
      let index = options.index(active);

      if (index > 1) {
        Ember.run.once(this, function () {
          this.set('scrollIndex', index)
        }.bind(this));
      }
    }

    if ( this.get('isAutoScroll') === true && this.get('isDesignScroll') === true) {
      this.$().scrollbar({
        onUpdate: function (el) {
          el.parent().css('height', height);
        }
      });
    }
  },
  willDestroyElement() {
    this._super(...arguments);
    if ( this.get('isAutoScroll') === true && this.get('isDesignScroll') === true) {
      this.$().empty().scrollbar('destroy');
    }
  },
});