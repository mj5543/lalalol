import Ember from 'ember';
import Control from '../fr-control/component';
import GlobalServiceContainerMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';

export default Control.extend(GlobalServiceContainerMixin, {
  tagName: 'div',
  classNames: ['fr-scheduler'],
  layout: Ember.computed(function () {

    const widthStyle = `width:${this.get('timeAreaWidth')}px;` ;

    const template = `<div class='wrap-calendar datepicker calendar-full calendar-day'>
                        <div class='calendar-in'>
                        <div class='calendar-field'>
                          {{#if navigationVisibility}}
                          <div class='calendar-nav'>
                            <div class='calendar-today'>
                              <strong>{{fr-format-date displayDate format='D'}}</strong>
                              <button type='button' class='btn btn-sm btn-unit btn-line' onclick={{action 'onToDayDateChangedAction' }}><span>Today</span></button>
                            </div>
                            <div class='calendar-nav-in'>
                              <div class='month-now'>{{fr-format-date displayDate format='y'}}</div>
                              <button type='button' class='calendar-nav-i calendar-nav-pre' onclick={{ action 'onDisplayDateChangedAction' -1}}><span class='blind'>privisus month</span></button>
                              <button type='button' class='calendar-nav-i calendar-nav-next' onclick={{ action 'onDisplayDateChangedAction' 1}}><span class='blind'>next month</span></button>
                            </div>
                            <div class='calendar-tab'>
                              <div class='tab-etc'>
                                <ul>
                                  <li class='{{if ( fr-inverse-boolean-helper _watchData.isWeek ) 'on' }}'><span class='alink' onclick={{action 'onScheduleModeChangedAction' 'daily'}}>Daily</span></li>
                                  <li class='{{if _watchData.isWeek 'on' }}'><span class='alink' onclick={{action 'onScheduleModeChangedAction' 'week'}}>Week</span></li>
                                </ul>
                              </div>
                            </div>
                          </div>
                          {{/if}}
                          <div class='fr-scheduler-head calendar-area calendar-scheduler-header'>
                            <table>
                              <caption>calendar</caption>
                              <colgroup>
                                <col style='{{fr-html-safe-helper widthStyle}}' />
                                {{#if _watchData.isWeek }}
                                  <col span='7' style='width:13%;' />
                                {{else}}
                                  <col style='100%;' />
                                {{/if}}
                                <col style='width:17px;' />
                              </colgroup>
                              <thead>
                                <tr>
                                  <th scope='col'></th>
                                  {{#each _watchData.days as |day index|}}
                                  <th scope='col' class='{{if day.isToday 'scheduler-now'}}'>
                                  {{day.day }} {{ format-date day.date format='w' }}
                                  </th>
                                  {{/each}}
                                  <th scope='col'></th>
                                </tr>
                              </thead>
                            </table>
                          </div>
                          <div class='fr-scheduler-body calendar-area calendar-scheduler-body'>
                            <table>
                              <caption>calendar</caption>
                              <colgroup>
                                <col style='{{fr-html-safe-helper widthStyle}}' />
                                {{#if _watchData.isWeek }}
                                  <col span='7' style='width:13%;' />
                                {{else}}
                                  <col style='100%;' />
                                {{/if}}
                              </colgroup>
                              <tbody>
                                {{#each _watchData.minutes as |minute index|}}
                                <tr data-time='{{ format-date minute.minute format='t' }}'>
                                  <th scope='row'>
                                    <div class='scheduler-time'>
                                    {{#if minute.hour12}}<strong>{{minute.hour12}}</strong>{{/if}}{{ format-date minute.minute format='t' }}
                                    </div>
                                  </th>
                                  {{#each _watchData.days as |day index|}}
                                  <td class='fr-schedule-cell {{if day.isToday 'scheduler-now'}}' data-weekday='{{ format-date day.date format='w' }}' data-date='{{day.dateStr}}'>
                                  </td>
                                  {{/each}}
                                </tr>
                                {{/each}}
                              </tbody>
                            </table>
                            {{#each _watchSource as |item index|}}
                              {{fr-scheduler-taskitem _owner=this datacontext=item}}
                            {{/each}}
                          </div>
                        </div>
                      </div>
                    </div>`;

    return Ember.HTMLBars.compile(template);
  }),
  _watchSource: Ember.computed('itemsSource.[]', function () {
    this._internalItems = Ember.A([]);

    this._onPropertyChangedCallBack();

    return this.get('itemsSource');
  }).readOnly(),
  _watchData: Ember.computed('scheduleMode', 'scheduleTimeMode', 'displayDate', function () {
    return this._onPropertyChangedCallBack();
  }).readOnly(),
  itemsSource: null,
  itemTemplate: '',
  toolTipTemplate: '',
  scheduleMode: 'daily',
  canUseChageTask: false,
  scheduleTimeMode: 10,
  mappingFromDatePath: '',
  mappingToDatePath: '',
  timeAreaWidth: 90,
  timeAreaHeight: 25,
  headerHeight: 25,
  displayDate: null,
  navigationVisibility : false,
  //== Public Events ===========================
  displayDateChanged:null,
  schedulerTaskItemDoubleClicked: null,
  schedulerTaskItemChanged: null,
  schedulerTimeInfoDoubleClicked: null,
  schedulerModeChanged:null,
  selectedChanged: null,
  dragStart: null,
  // == Private Fields =========================
  _internalItems: null,
  _wasSelectedItem: null,
  // == Private Methods ========================
  _addItem(taskItem) {
    this._internalItems.pushObject(taskItem);
  },
  _onPropertyChangedCallBack() {
    const _scheduleMode = this.get('scheduleMode');
    const _timeMode = this.get('scheduleTimeMode');
    const _displayDate = this.get('displayDate');
    let cols = Ember.A([]);
    let rows = Ember.A([]);

    if (_scheduleMode === 'daily') {
      cols = this.getDay(_displayDate);
    } else {
      cols = this.getWeekDays(_displayDate);
    }

    const length = 1440 / _timeMode;
    let date = new Date(_displayDate.getFullYear(), _displayDate.getMonth(), _displayDate.getDate(), 0, 0, 0);

    for (let j = 0; j <= length; j++) {

      let time = new Date(date);
      let hour12 = '';
      if (time.getHours() === 0 && time.getMinutes() === 0) {
        hour12 = 'AM';
      } else if (time.getHours() === 12 && time.getMinutes() === 0) {
        hour12 = 'PM';
      }
      rows.pushObject(
        Ember.Object.create({
          'minute': time,
          'hour12': hour12
        })
      );

      date = date.addMinutes(_timeMode);
    }


    console.log({
      'days': cols,
      'minutes': rows,
      'isWeek': this.get('scheduleMode') === 'week'
    });

    console.log(JSON.stringify({
      'days': cols,
      'minutes': rows,
      'isWeek': this.get('scheduleMode') === 'week'
    }));

    return {
      'days': cols,
      'minutes': rows,
      'isWeek': this.get('scheduleMode') === 'week'
    };
  },
  _onSchedulerTaskItemDoubleClick(sender) {
    const args = { 'source': this, 'originalSource': sender, 'dataItem': sender.get('datacontext') };

    this._raiseEvents('schedulerTaskItemDoubleClicked', args);
  },
  _onDragStart(sender) {
    const args = { 'source': this, 'originalSource': sender, 'dataItem': sender.get('datacontext') };

    this._raiseEvents('dragStart', args);

    return args.cancel;
  },
  _onSelectedChanged(sender) {

    if (this._wasSelectedItem === sender) {
      return;
    }

    const args = { 'source': this, 'originalSource': sender, 'dataItem': sender.get('datacontext') };

    this._wasSelectedItem = sender;

    this._raiseEvents('selectedChanged', args);
  },
  _schedulerTaskItemChanged(sender) {

    this._afterRender();

    const args = { 'source': this, 'originalSource': sender, 'dataItem': sender.get('datacontext') };

    this._raiseEvents('schedulerTaskItemChanged', args);
  },
  _setHeight() {
    const outerHeight = this.$().height();
    this.$('.fr-scheduler-body').css('height', outerHeight - this.headerHeight);
  },
  _afterRender() {

    this.$('.fr-scheduler-head').find('tr').height(this.headerHeight);
    this.$('.fr-scheduler-body').find('tr').height(this.timeAreaHeight);

    this._internalItems.forEach(function (scheduleTaskItem) {
      scheduleTaskItem.calculatePosition();
    }.bind(this));

    this._internalItems.forEach(function (scheduleTaskItem) {

      const duplicateItems = Ember.A([]);

      this._internalItems.forEach(function (taskitem) {
        if (taskitem.elementId !== scheduleTaskItem.elementId && taskitem.contains(scheduleTaskItem.x, scheduleTaskItem.y)) {
          duplicateItems.pushObject(taskitem)
        }
      }.bind(this));

      let length = duplicateItems.length;

      if (length > 0) {
        duplicateItems.pushObject(scheduleTaskItem);

        const newWith = (scheduleTaskItem.width - (length * 2)) / (length + 1);
        let newLeft = scheduleTaskItem.x;
        duplicateItems.forEach(function (item) {
          item.split(newLeft, newWith);

          newLeft = newLeft + newWith + 2;
        });
      }

    }.bind(this));
  },
  // == Event Hooks ============================
  didRender() {
    this._super(...arguments);

    this._setHeight();

    this._afterRender();
  },
  willDestroyElement() {
    this._super(...arguments);
  },
  doubleClick(e) {
    const el = this.$(e.target);

    if (el.hasClass('fr-schedule-cell')) {
      const date = new Date(el.data('date'));
      const args = { 'source': this, 'date': date };

      this._raiseEvents('schedulerTimeInfoDoubleClicked', args);
    }
  },
  getDay(baseDate = this.get('co_CommonService').getNow()) {

    const theYear = baseDate.getFullYear();
    const theMonth = baseDate.getMonth();
    const theDate = baseDate.getDate();
    const theDayOfWeek = baseDate.getDay();

    const thisWeek = Ember.A([]);
    const toDayStr = this.get('co_CommonService').getNow().toStandardDateString()

    const resultDay = new Date(theYear, theMonth, theDate);
    const yyyy = resultDay.getFullYear();
    let mm = Number(resultDay.getMonth());
    let dd = resultDay.getDate();

    mm = String(mm).length === 1 ? '0' + mm : mm;
    dd = String(dd).length === 1 ? '0' + dd : dd;

    const dt = new Date(yyyy, mm, dd)
    const dtStr = dt.toStandardDateString();

    thisWeek.pushObject({
      date : dt,
      day : dt.getDate(),
      isToday : dtStr === toDayStr,
      dateStr :  dtStr
    });

    return thisWeek;
  },
  getWeekDays(baseDate = this.get('co_CommonService').getNow()) {

    const theYear = baseDate.getFullYear();
    const theMonth = baseDate.getMonth();
    const theDate = baseDate.getDate();
    const theDayOfWeek = baseDate.getDay();

    const thisWeek = Ember.A([]);
    const toDayStr = this.get('co_CommonService').getNow().toStandardDateString()
    for (let i = 0; i < 7; i++) {
      const resultDay = new Date(theYear, theMonth, theDate + (i - theDayOfWeek));
      const yyyy = resultDay.getFullYear();
      let mm = Number(resultDay.getMonth());
      let dd = resultDay.getDate();

      mm = String(mm).length === 1 ? '0' + mm : mm;
      dd = String(dd).length === 1 ? '0' + dd : dd;

      const dt = new Date(yyyy, mm, dd)
      const dtStr = dt.toStandardDateString();

      thisWeek.pushObject({
        date : dt,
        day : dt.getDate(),
        isToday : dtStr === toDayStr,
        dateStr :  dtStr
      });
    }

    return thisWeek;
  },
  actions : {
    onScheduleModeChangedAction(mode) {
      this.set('scheduleMode', mode);

      Ember.run.once(this, function(){
        this._raiseEvents('schedulerModeChanged', { 'source': this});
      }.bind(this));
    },
    onDisplayDateChangedAction(arg) {
      let newDate = null;
      if ( this.scheduleMode === 'week') {
        newDate = this.get('displayDate').addDays(7 * parseInt(arg)) ;
      } else {
        newDate = this.get('displayDate').addDays(1 * parseInt(arg)) ;
      }

      this.set('displayDate', newDate);

      this._raiseEvents('displayDateChanged', { 'source': this, 'displayDate' : newDate });
    },
    onToDayDateChangedAction() {

      let newDate = this.get('co_CommonService').getNow();

      this.set('displayDate', newDate);

      this._raiseEvents('displayDateChanged', { 'source': this, 'displayDate' : newDate });
    }
  }
});