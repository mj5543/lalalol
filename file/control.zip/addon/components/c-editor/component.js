import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';

export default Control.extend({
  layout,
  tagName: 'div',
  classNames: ['c-editor'],
  //public properties
  style: null,
  disabled: false,
  options: null,
  //public events
  onLoaded: null,
  onUnload: null,

  _toolbarContainerHeight: 0,
  _toolbarContainer: Ember.computed('componentGuid', function () {
    return `${this.get('componentGuid')}-toolbar-container`;
  }).readOnly(),
  _editorContainer: Ember.computed('componentGuid', function () {
    return `${this.get('componentGuid')}-editor-container`;
  }).readOnly(),
  _editorContainerSafeStyle: Ember.computed('_toolbarContainerHeight', function () {
    Ember.run.scheduleOnce('afterRender', this, '_updateContainer');

    return Ember.String.htmlSafe(`width:100%;height:calc(100% - ${this.get('_toolbarContainerHeight')}px);`);
  }).readOnly(),
  _opservedProperty1: Ember.computed('options', function () {
    Ember.run.scheduleOnce('afterRender', this, '_optionsChange');
  }).readOnly(),
  didInsertElement() {
    this._super(...arguments);
    this._raiseEvents('onLoaded', { source: this, editorSelector: `.${this.get('_editorContainer')}` });
    this.$('.observation.scrollbar-macosx:not(.scroll-content)').scrollbar({
      onUpdate: function(el) {
        Ember.run.once(this, '_updateLayout');
      }.bind(this),
    });
    this.$('.editor.scrollbar-macosx:not(.scroll-content)').scrollbar({
      onUpdate: function(el) {
        Ember.run.once(this, '_updateContainer');
      }.bind(this),
    });
  },
  willDestroyElement() {
    this.$('.scrollbar-macosx').scrollbar('destroy');
    if (this.$(`.${this.get('_editorContainer')}`).data('froala.editor')) {
      this.$(`.${this.get('_editorContainer')}`).froalaEditor('destroy');
    }
    this._super(...arguments);
  },
  click(event) {
    const $target = this.$(event.target);

    if ($target.closest('.editor.scrollbar-macosx.scroll-content').length > 0 && $target.closest(`.${this.get('_editorContainer')}`).length === 0) {
      this.$(`.${this.get('_editorContainer')}`).froalaEditor('events.focus');
    }
  },
  _optionsChange() {
    let options = Ember.$.extend({ zIndex: 20001, pluginsEnabled: ['align', 'charCounter', 'codeBeautifier', 'codeView', 'colors', 'draggable',
    'embedly', 'emoticons', 'entities', 'file', 'fontAwesome', 'fontFamily', 'fontSize',  'image', 'imageTUI',
    'imageManager', 'inlineStyle', 'inlineClass', 'lineBreaker', 'lineHeight', 'link', 'lists', 'paragraphFormat',
    'paragraphStyle', 'quote', 'save', 'table', 'url', 'video', 'wordPaste'], placeholderText: 'Type Something', toolbarButtons: ['bold', 'italic',
    'underline', 'strikeThrough', '|', 'fontFamily', 'fontSize', 'color', 'lineHeight', '|', 'align', 'outdent', 'indent',
    '-', 'insertLink', 'insertImage', 'insertTable', '|', 'insertHR', 'selectAll', 'html', '|', 'undo', 'redo'], }, this.get('options'),
    { toolbarContainer: `.${this.get('_toolbarContainer')}`, charCounterCount: false, height: null, heightMax: null, heightMin: null, iframe: false,
    toolbarBottom: false, toolbarSticky: true, toolbarStickyOffset: 0, });

    options.pluginsEnabled = options.pluginsEnabled.filter(function(value){
      return value !== 'quickInsert' && value !== 'fullscreen';
    });
    if (options.toolbarInline) {
      options.toolbarContainer = null;
    }
    if (this.$(`.${this.get('_editorContainer')}`).data('froala.editor')) {
      this.$(`.${this.get('_editorContainer')}`).froalaEditor('destroy');
    }
    if (!this.$(`.${this.get('_editorContainer')}`).data('froala.editor')) {
      this.$(`.${this.get('_editorContainer')}`).froalaEditor(options);
    }
  },
  _updateLayout() {
    const height = this.$('.observation.scrollbar-macosx.scroll-content').prop('clientHeight');

    if (this.get('_toolbarContainerHeight') !== height) {
      this.set('_toolbarContainerHeight', height);
    }
  },
  _updateContainer() {
    const scrollNode = this.$('.editor.scrollbar-macosx.scroll-content').get(0), editorNode = this.$('.fr-element.fr-view').get(0);
    let focusNode = document.getSelection().focusNode;

    if (editorNode && focusNode && editorNode !== focusNode && editorNode.contains(focusNode)) {
      focusNode = this._getChildNode(editorNode, focusNode);
      if (scrollNode.scrollTop > focusNode.offsetTop) {
        scrollNode.scrollTop = focusNode.offsetTop - parseInt(scrollNode.offsetHeight / 2);
      }
      if (scrollNode.scrollTop + scrollNode.offsetHeight < focusNode.offsetTop + focusNode.offsetHeight) {
        scrollNode.scrollTop = focusNode.offsetTop + focusNode.offsetHeight - parseInt(scrollNode.offsetHeight / 2);
      }
    }
  },
  _getChildNode(parentNode, childNode) {
    return parentNode === childNode.parentNode ? childNode : this._getChildNode(parentNode, childNode.parentNode);
  },
  actions: {
  },
});