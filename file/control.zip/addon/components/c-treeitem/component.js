import Ember from 'ember';
import layout from './template';

export default Ember.Component.extend({
  layout,
  tagName: 'li',
  classNames: ['c-treeviewitem'],
  classNameBindings: ['_treeItemClass'],
  attributeBindings: ['data-item-path'],
  indeterminate: false,
  sliderSpeed: 100,
  changeEditMode() {
    this.set('editing', true);
    this.set('beforeText', Ember.get(this.get('item'), this.get('displayMemberPath')));
    Ember.run.next(this, function() {
      if (!Ember.get(this, 'isDestroying') && !Ember.get(this, 'isDestroyed')) {
        this.$('> div.item-box > div.item').find(':focusable').focus();
      }
    });
  },
  getParent() {
    const $target = this.$().parent().closest(`.${this.get('_treeItemClass')}`);

    if ($target.length > 0) {
      return this._getComponent($target);
    }

    return null;
  },
  isActive: Ember.computed('item', '_selectedItem', function () {
    return this.get('item') === this.get('_selectedItem');
  }).readOnly(),
  isExpanded: Ember.computed('item', '_expandedItems.[]', function () {
    const _expandedItems = this.get('_expandedItems'), isExpanded = _expandedItems.includes(this.get('item'));

    if (isExpanded) {
      this.$('.itemgroup').eq(0).slideDown({
        'duration': this.get('sliderSpeed'),
        'complete': function () {
          if (this.$('.material-icons').length > 0) {
            this.$('.material-icons').eq(0).removeClass('collapsed');
          }
        }.bind(this)
      });
    } else {
      this.$('.itemgroup').eq(0).slideUp({
        'duration': this.get('sliderSpeed'),
        'complete': function () {
          if (this.$('.material-icons').length > 0) {
            this.$('.material-icons').eq(0).addClass('collapsed');
          }
        }.bind(this)
      });
    }

    return isExpanded;
  }).readOnly(),
  _getComponent($target) {
    let param = { component: {} }, component = null;

    $target.trigger('_getComponent', param);
    component = param.component;
    param.component = null;
    param = null;

    return component;
  },
  _getChilrenItems(childrenItems) {
    const items = Ember.A();

    if (Ember.isArray(childrenItems)) {
      childrenItems.forEach(function (child) {
        items.addObjects(this._getChilrenItems(Ember.get(child, this.get('childrenMemberPath'))));
      }.bind(this));
      items.addObjects(childrenItems);
    }

    return items;
  },
  indeterminateChange() {
    const childrenItems = this.get('childrenItems'), checkedChildrenItems = childrenItems.filterBy(this.get('checkBoxPath'), true);

    if (childrenItems.length > 0) {
      if (checkedChildrenItems.length > 0) {
        Ember.set(this.get('item'), this.get('checkBoxPath'), true);
        if (childrenItems.length === checkedChildrenItems.length) {
          this.set('indeterminate' , false);
        } else {
          this.set('indeterminate' , true);
        }
      } else {
        Ember.set(this.get('item'), this.get('checkBoxPath'), false);
        this.set('indeterminate' , false);
      }
    } else {
      this.set('indeterminate' , false);
    }
  },
  init() {
    this._super(...arguments);
    Ember.defineProperty(this, 'hasChildren', Ember.computed('leafNodeMemberPath', `item.${this.get('childrenMemberPath')}.[]`, function () {
      const leafNodeMemberPath = this.get('leafNodeMemberPath'), childrenMemberPath = this.get('childrenMemberPath');

      if (!Ember.isNone(leafNodeMemberPath)) {
        return !Ember.get(this.get('item'), leafNodeMemberPath);
      }

      return !Ember.isEmpty(Ember.get(this.get('item'), childrenMemberPath));
    }).readOnly());
    Ember.defineProperty(this, 'childrenItems', Ember.computed(`item.${this.get('childrenMemberPath')}.[]`, {
      get (key) {
        return this._getChilrenItems(Ember.get(this.get('item'), this.get('childrenMemberPath')));
      },
      set (key, value) {
      return value;
      },
    }));
    if (this.get('showCheckBox')) {
      Ember.defineProperty(this, '_observedProperty1', Ember.computed(`childrenItems.@each.${this.get('checkBoxPath')}`, function () {
        Ember.run.once(this, 'indeterminateChange');
      }));
    }
  },
  didInsertElement() {
    this._super(...arguments);
    this.$().on('_getComponent', function (event, param) {
      param.component = this;
      event.stopPropagation();
      event.preventDefault();
    }.bind(this));
    this.$().on('_treeitemupdate', function (event) {
      this.set('childrenItems', this._getChilrenItems(Ember.get(this.get('item'), this.get('childrenMemberPath'))));
      event.stopPropagation();
      event.preventDefault();
    }.bind(this));
    if (this.get('draggable')) {
      this.$('> .item-box > .item').on('dragstart', function (event) {
        let treeComponent = this._getComponent(this.$().closest('.c-tree'));
  
        treeComponent._raiseEvents('onDragStart', { source: treeComponent, originalSource: this, originalEvent: event });
        if (!event.isDefaultPrevented()) {
          Ember.set(treeComponent, 'dragItem', this.get('item'));
          event.dataTransfer.setData('text/plain', JSON.stringify(this.get('item')));
          event.effectAllowed = 'move';
        }
        treeComponent = null;
      }.bind(this)).on('dragend', function (event) {
        let treeComponent = this._getComponent(this.$().closest('.c-tree'));
  
        treeComponent._raiseEvents('onDragEnd', { source: treeComponent, originalSource: this, originalEvent: event, dragItem: Ember.get(treeComponent, 'dragItem') });
        Ember.set(treeComponent, 'dragItem', null);
        treeComponent = null;
      }.bind(this));
      this.$('> .item-box > .item > .item-indicator').on('dragenter', function (event) {
        this.$(event.currentTarget).addClass('drag-over-item-indicator');
        event.stopPropagation();
        event.preventDefault();
      }.bind(this)).on('dragleave', function (event) {
        this.$(event.currentTarget).removeClass('drag-over-item-indicator');
        event.stopPropagation();
        event.preventDefault();
      }.bind(this)).on('dragover', function (event) {
        let treeComponent = this._getComponent(this.$().closest('.c-tree')),
        args = { source: treeComponent, originalSource: this, originalEvent: event, item: this.get('item'), allowDrop: true, };
    
        treeComponent._raiseEvents('onDragOver', args);
        if (args.allowDrop) {
          event.stopPropagation();
          event.preventDefault();
        }
        this._releaseObjectProperty(args);
        treeComponent = null;
        args = null;
      }.bind(this)).on('drop', function (event) {
        this.$(event.currentTarget).removeClass('drag-over-item-indicator');
        let treeComponent = this._getComponent(this.$().closest('.c-tree'));

        treeComponent._raiseEvents('onDrop', { source: treeComponent, originalSource: this, originalEvent: event });
        if (!event.isDefaultPrevented()) {
          const item = this.get('item'), childrenMemberPath = this.get('childrenMemberPath'), currentParent = this.getParent();
          let dragItem = Ember.get(treeComponent, 'dragItem'), itemChildren = null;

          if (!Ember.isNone(currentParent)) {
            itemChildren = Ember.get(Ember.get(currentParent, 'item'), childrenMemberPath);
          }
          if (Ember.isNone(dragItem)) {
            dragItem = JSON.parse(event.dataTransfer.getData('text/plain'));
            if (Ember.isArray(itemChildren)){
              itemChildren.insertAt(itemChildren.indexOf(item), dragItem);
            } else {
              const itemsSource = Ember.get(treeComponent, 'itemsSource');

              itemsSource.insertAt(itemsSource.indexOf(item), dragItem);
            }
            treeComponent.updateTree();
            treeComponent.expandNodeByItem(item);
          } else if (dragItem !== item && !this._getChilrenItems(Ember.get(dragItem, childrenMemberPath)).includes(item)) {
            let component = this._getComponent(treeComponent.$().find(`li[data-item-path="${treeComponent._getItemPath(dragItem)}"]`)), parentComponent = component.getParent();

            if (!Ember.isNone(parentComponent)) {
              Ember.get(Ember.get(parentComponent, 'item'), childrenMemberPath).removeObject(dragItem);
            } else {
              Ember.get(treeComponent, 'itemsSource').removeObject(dragItem);
            }
            if (Ember.isArray(itemChildren)) {
              itemChildren.insertAt(itemChildren.indexOf(item), dragItem);
            } else {
              const itemsSource = Ember.get(treeComponent, 'itemsSource');

              itemsSource.insertAt(itemsSource.indexOf(item), dragItem);
            }
            treeComponent.updateTree();
            treeComponent.expandNodeByItem(item);
            Ember.set(treeComponent, 'dragItem', null);
            component = null;
            parentComponent = null;
          }
          dragItem = null;
          itemChildren = null;
        }
        treeComponent = null;
      }.bind(this));
      this.$('> .item-box > .item > .item-presenter').on('dragenter', function (event) {
        this.$(event.currentTarget).addClass('drag-over-item');
        event.stopPropagation();
        event.preventDefault();
      }.bind(this)).on('dragleave', function (event) {
        this.$(event.currentTarget).removeClass('drag-over-item');
        event.stopPropagation();
        event.preventDefault();
      }.bind(this)).on('dragover', function (event) {
        let treeComponent = this._getComponent(this.$().closest('.c-tree')),
        args = { source: treeComponent, originalSource: this, originalEvent: event, item: this.get('item'), allowDrop: true, };
    
        treeComponent._raiseEvents('onDragOver', args);
        if (args.allowDrop) {
          event.stopPropagation();
          event.preventDefault();
        }
        this._releaseObjectProperty(args);
        treeComponent = null;
        args = null;
      }.bind(this)).on('drop', function (event) {
        this.$(event.currentTarget).removeClass('drag-over-item');
        let treeComponent = this._getComponent(this.$().closest('.c-tree'));
    
        treeComponent._raiseEvents('onDrop', { source: treeComponent, originalSource: this, originalEvent: event });
        if (!event.isDefaultPrevented()) {
          const item = this.get('item'), childrenMemberPath = this.get('childrenMemberPath');
          let dragItem = Ember.get(treeComponent, 'dragItem'), itemChildren = Ember.get(item, childrenMemberPath);
    
          if (Ember.isNone(dragItem)) {
            dragItem = JSON.parse(event.dataTransfer.getData('text/plain'));
            if (Ember.isArray(itemChildren)){
              itemChildren.addObject(dragItem);
            } else {
              itemChildren = Ember.A();
              itemChildren.addObject(dragItem);
              Ember.set(item, childrenMemberPath, itemChildren);
            }
            treeComponent.updateTree();
            treeComponent.expandNodeByItem(item);
          } else if (dragItem !== item && !this._getChilrenItems(Ember.get(dragItem, childrenMemberPath)).includes(item)) {
            let component = this._getComponent(treeComponent.$().find(`li[data-item-path="${treeComponent._getItemPath(dragItem)}"]`)), parentComponent = component.getParent();
    
            if (!Ember.isNone(parentComponent)) {
              Ember.get(Ember.get(parentComponent, 'item'), childrenMemberPath).removeObject(dragItem);
            } else {
              Ember.get(treeComponent, 'itemsSource').removeObject(dragItem);
            }
            if (Ember.isArray(itemChildren)){
              itemChildren.addObject(dragItem);
            } else {
              itemChildren = Ember.A();
              itemChildren.addObject(dragItem);
              Ember.set(item, childrenMemberPath, itemChildren);
            }
            treeComponent.updateTree();
            treeComponent.expandNodeByItem(item);
            Ember.set(treeComponent, 'dragItem', null);
            component = null;
            parentComponent = null;
          }
          dragItem = null;
          itemChildren = null;
        }
        treeComponent = null;
      }.bind(this));
    }
  },
  willDestroyElement() {
    this.$().off('_getComponent');
    this.$().off('_treeitemupdate');
    if (this.get('draggable')) {
      this.$('> .item-box > .item').off('dragstart').off('dragend');
      this.$('> .item-box > .item > .item-indicator').off('dragenter').off('dragleave').off('dragover').off('drop');
      this.$('> .item-box > .item > .item-presenter').off('dragenter').off('dragleave').off('dragover').off('drop');
    }
    this._super(...arguments);
  },
  focusOut(event) {
    if (this.get('editing')) {
      let $target = this.$(event.target).closest(`.item-presenter`);

      if (!this.get('element').contains(event.relatedTarget) || !this.$(event.relatedTarget).closest('.item-presenter').is($target)) {
        let treeComponent = this._getComponent(this.$().closest('.c-tree')), beforeText = this.get('beforeText');

        this.set('editing', false);
        this.set('beforeText', null);
        treeComponent._raiseEvents('onEditModeEnded', { source: treeComponent, originalSource: this, textchanged: beforeText !== Ember.get(this.get('item'), this.get('displayMemberPath')) });
        treeComponent = null;
      }
      $target = null;
    }
  },
  _releaseObjectProperty(obj) {
    if (obj instanceof Object) {
      Object.getOwnPropertyNames(obj).forEach(function (prop) {
        Ember.set(obj, prop, null);
      });
    }
  },
  actions: {
    checkBoxChanged(event) {
      let treeComponent = this._getComponent(this.$().closest('.c-tree')), checked = this.$(event.originalEvent.target).is(":checked");

      this.get('childrenItems').setEach(this.get('checkBoxPath'), checked);
      if (checked) {
        treeComponent._raiseEvents('onChecked', { source: treeComponent, originalSource: this, originalEvent: event.originalEvent, parent: this.getParent(), item: this.get('item') });
      } else {
        treeComponent._raiseEvents('onUnchecked', { source: treeComponent, originalSource: this, originalEvent: event.originalEvent, parent: this.getParent(), item: this.get('item') });
      }
      treeComponent = null;
    },
    itemDoubleClick(event) {
      let treeComponent = this._getComponent(this.$().closest('.c-tree'));

      treeComponent._raiseEvents('onDoubleClick', { source: treeComponent, originalSource: this, originalEvent: event, parent: this.getParent(), item: this.get('item') });
      treeComponent = null;
    },
    expanderClick(event) {
      const _expandedItems = this.get('_expandedItems'), item = this.get('item');
      let treeComponent = this._getComponent(this.$().closest('.c-tree')), args = { source: treeComponent, originalSource: this, originalEvent: event, parent: this.getParent(), item: item, cancel: false };

      if (_expandedItems.includes(item)) {
        treeComponent._raiseEvents('onCollapse', args);
        if (!args.cancel) {
          _expandedItems.removeObject(item);
        }
      } else {
        treeComponent._raiseEvents('onExpand', args);
        if (!args.cancel) {
          _expandedItems.addObject(item);
        }
      }
      this._releaseObjectProperty(args);
      treeComponent = null;
      args = null;
    },
    itemClick() {
      const _selectedItem = this.get('_selectedItem'), item = this.get('item');

      if (_selectedItem !== item) {
        let treeComponent = this._getComponent(this.$().closest('.c-tree'));

        this.set('_selectedItem', item);
        Ember.run.once(treeComponent, Ember.get(treeComponent, '_selectionChange'));
        treeComponent = null;
      }
    },
  },
});