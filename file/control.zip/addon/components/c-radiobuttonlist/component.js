import Ember from 'ember';
import layout from './template';
import ValidationControl from '../c-validationcontrol/component';

export default ValidationControl.extend({
  layout,
  tagName: 'div',
  classNames: ['c-radiobutton-list'],
  classNameBindings: ['_verticalOrientation:vertical'],
  attributeBindings: ['tabindex'],
  //public properties
  style: null,
  itemStyle: null,
  itemsSource: null,
  displayMemberPath: null,
  selectedValuePath: null,
  selectedValue: null,
  selectedItem: null,
  enableKeepSelectedValue: false,
  orientation: 'horizontal',
  tabindex: -1,
  disabled: false,
  readOnly: false,
  required: false,
  showValidationSuccess: false,
  externalErrorMessage: null,
  validationRules: null,
  enableUncheck: false,
  //public events
  onLoaded: null,
  onUnload: null,
  onClick: null,
  onFocusIn: null,
  onFocusOut: null,
  onKeyPress: null,
  onKeyUp: null,
  onKeyDown: null,
  onChanged: null,
  onSelectionChanged: null,

  _radiobuttonGuid: Ember.computed.readOnly('componentGuid'),
  _verticalOrientation: Ember.computed.equal('orientation', 'vertical'),
  _readOnlyOrDisabled: Ember.computed.or('readOnly', 'notAccessable'),
  _isAttrsSelectedProperty: Ember.computed.or('_isAttrsSelectedItem', '_isAttrsSelectedValue').readOnly(),
  _isAttrsSelectedItem: Ember.computed(function () {
    return !Ember.isNone(this.attrs.selectedItem);
  }).readOnly(),
  _isAttrsSelectedValue: Ember.computed(function () {
    return !Ember.isNone(this.attrs.selectedValue);
  }).readOnly(),
  _itemsSource: Ember.computed('itemsSource.[]', function () {
    let itemsSource = this.get('itemsSource');

    if (!Ember.isArray(itemsSource)) {
      itemsSource = Ember.A();
    }
    Ember.run.once(this, '_itemsSourceChange');

    return itemsSource;
  }).readOnly(),
  _observedProperty1: Ember.computed('selectedItem', 'selectedValue', function () {
    const _itemsSource = this.get('_itemsSource'), _selectedItem = this.get('_selectedItem'), _isAttrsSelectedValue = this.get('_isAttrsSelectedValue'), selectedValuePath = this.get('selectedValuePath'),
      selectedItem = _isAttrsSelectedValue ? _itemsSource.findBy(selectedValuePath, this.get('selectedValue')) : this.get('selectedItem');

    if ((_selectedItem && selectedItem && _selectedItem !== selectedItem) || (!_selectedItem && selectedItem)) {
      this._selectItem(_itemsSource.indexOf(selectedItem));
    } else if (_selectedItem && !selectedItem) {
      this._deselectItem(_itemsSource.indexOf(_selectedItem));
    }
  }).readOnly(),
  _observedProperty2: Ember.computed('selectedItem', function () {
    Ember.run.once(this, '_syncSelectedValue');
  }).readOnly(),
  _observedProperty3: Ember.computed('selectedValue', function () {
    Ember.run.once(this, '_syncSelectedItem');
  }).readOnly(),
  didInsertElement() {
    this._super(...arguments);
    this.$('.scrollbar-macosx:not(.scroll-content)').scrollbar();
  },
  willDestroyElement() {
    this.$('.scrollbar-macosx').scrollbar('destroy');
    this._super(...arguments);
  },
  focusIn(event) {
    this._raiseEvents('onFocusIn', {
      source: this,
      originalEvent: event
    });
  },
  focusOut(event) {
    this._raiseEvents('onFocusOut', {
      source: this,
      originalEvent: event
    });
  },
  keyPress(event) {
    this._raiseEvents('onKeyPress', {
      source: this,
      originalEvent: event
    });
  },
  keyUp(event) {
    this._raiseEvents('onKeyUp', {
      source: this,
      originalEvent: event
    });
  },
  keyDown(event) {
    this._raiseEvents('onKeyDown', {
      source: this,
      originalEvent: event
    });
  },
  _itemsSourceChange() {
    const _itemsSource = this.get('_itemsSource');

    const enableKeepSelectedValue = this.get('enableKeepSelectedValue'),
      _selectedItem = this.get('_selectedItem');

    if (enableKeepSelectedValue) {
      const selectedItem = _itemsSource.findBy(this.get('selectedValuePath'), this.get('selectedValue'));

      if (!Ember.isNone(selectedItem)) {
        if (_selectedItem !== selectedItem) {
          this.set('_selectedItem', selectedItem);
          Ember.run.once(this, '_selectionChange', true);
        }
      } else if (!Ember.isNone(_selectedItem)) {
        this.set('_selectedItem', null);
        Ember.run.once(this, '_selectionChange', true);
      }
    } else if (!Ember.isNone(_selectedItem) && !_itemsSource.includes(_selectedItem)) {
      this.set('_selectedItem', null);
      Ember.run.once(this, '_selectionChange');
    }
  },
  _syncSelectedItem() {
    const selectedValue = this.get('selectedValue'), selectedValuePath = this.get('selectedValuePath');

    if (!Ember.isNone(selectedValue) && !Ember.isNone(selectedValuePath)) {
      const selectedItem = this.get('_itemsSource').findBy(selectedValuePath, selectedValue);

      this.set('selectedItem', !Ember.isNone(selectedItem) ? selectedItem : null);
    } else if (!Ember.isNone(this.get('selectedItem'))) {
      this.set('selectedItem', null);
    }
  },
  _syncSelectedValue() {
    const enableKeepSelectedValue = this.get('enableKeepSelectedValue');

    if (!enableKeepSelectedValue) {
      const selectedItem = this.get('selectedItem'), selectedValuePath = this.get('selectedValuePath');

      if (!Ember.isNone(selectedItem) && !Ember.isNone(selectedValuePath)) {
        this.set('selectedValue', Ember.get(selectedItem, selectedValuePath));
      } else if (!Ember.isNone(this.get('selectedValue'))) {
        this.set('selectedValue', null);
      }
    }
  },
  _selectItem(index) {
    const _itemsSource = this.get('_itemsSource'), _selectedItem = this.get('_selectedItem'), item = _itemsSource.objectAt(index);

    if (!Ember.isNone(item) && _selectedItem !== item) {
      this.set('_selectedItem', item);
      Ember.run.once(this, '_selectionChange');
    }
  },
  _deselectItem(index) {
    const _itemsSource = this.get('_itemsSource'), _selectedItem = this.get('_selectedItem'), item = _itemsSource.objectAt(index);

    if (!Ember.isNone(item) && _selectedItem === item) {
      this.set('_selectedItem', null);
      Ember.run.once(this, '_selectionChange');
    }
  },
  _selectionChange(keepSelectedValue) {
    const _selectedItem = this.get('_selectedItem'), selectedItem = this.get('selectedItem'),
      _selectedValue = _selectedItem ? Ember.get(_selectedItem, this.get('selectedValuePath')) : null, selectedValue = this.get('selectedValue');

    if ((selectedItem && _selectedItem && selectedItem !== _selectedItem) || (!selectedItem && _selectedItem)) {
      this.set('selectedItem', _selectedItem);
    } else if (selectedItem && !_selectedItem) {
      this.set('selectedItem', null);
    }
    if (!keepSelectedValue) {
      if ((!Ember.isNone(selectedValue) && !Ember.isNone(_selectedValue) && selectedValue !== _selectedValue) || (Ember.isNone(selectedValue) && !Ember.isNone(_selectedValue))) {
        this.set('selectedValue', _selectedValue);
      } else if (!Ember.isNone(selectedValue) && Ember.isNone(_selectedValue)) {
        this.set('selectedValue', null);
      }
    }
    this.set('_internalValue', !Ember.isEmpty(_selectedItem));
    this._raiseEvents('onSelectionChanged', {
      source: this,
      selectedItem: this.get('selectedItem')
    });
  },
  actions: {
    click(item, event) {
      if (this.$(event.target).is(':radio')) {
        this._raiseEvents('onClick', {
          source: this,
          originalEvent: event
        });
        if (!event.defaultPrevented && this.enableUncheck && this.get('_selectedItem') === item) {
          Ember.run(this, function () {
            this.set('_selectedItem', null);
            Ember.run.once(this, '_selectionChange');
          });
          this._raiseEvents('onChanged', {
            source: this,
            originalEvent: event,
            item: item,
            checked: false,
          });
        }
      }
    },
    change(item, event) {
      if (this.get('_selectedItem') !== item) {
        Ember.run(this, function () {
          this.set('_selectedItem', item);
          Ember.run.once(this, '_selectionChange');
        });
        this._raiseEvents('onChanged', {
          source: this,
          originalEvent: event,
          item: item,
          checked: true
        });
      }
    },
  },
});