import Ember from 'ember';
import layout from './template';

export default Ember.Component.extend({
  layout,
  classNames: ['c-loader'],
  showLoader: true,
  loaderType: 'spinner',
  loaderSize: 'md',
  loaderDimed: false,
  accessableElements: null,
  _observedProperty1: Ember.computed('showLoader', 'loaderType', 'loaderSize', 'loaderDimed', function () {
    Ember.run.scheduleOnce('afterRender', this, '_changeLoaderState');
  }),
  init() {
    this._super(...arguments);
    this.set('accessableElements', Ember.A());
  },
  _changeLoaderState() {
    if (!this.get('isDestroying') && !this.get('isDestroyed')) {
      const $target = this.$().parent(), showLoader = this.get('showLoader'), accessableElements = this.get('accessableElements');

      if ($target.length > 0) {
        if (showLoader) {
          ($target.is(':focus') ? $target : $target.find(':focus').blur());
          ($target.is(':tabbable') ? $target.add($target.find(':tabbable')) : $target.find(':tabbable')).each(function (index, element) {
            accessableElements.addObject({ element: element, tabindex: Ember.$(element).attr('tabindex') });
            Ember.$(element).attr('tabindex', '-1');
          });
          $target.removeClass(`spinner progress loader-sm loader-md loader-lg loader-dimed`);
          $target.addClass(`disabled loader ${this.get('loaderType')} loader-${this.get('loaderSize')}`);
          if (this.get('loaderDimed')) {
            $target.addClass('loader-dimed');
          }
        } else {
          accessableElements.forEach(function (o) {
            Ember.isNone(o.tabindex) ? Ember.$(o.element).removeAttr('tabindex') : Ember.$(o.element).attr('tabindex', o.tabindex);
          });
          accessableElements.clear();
          $target.removeClass(`disabled loader spinner progress loader-sm loader-md loader-lg loader-dimed`);
        }
      }
    }
  },
});