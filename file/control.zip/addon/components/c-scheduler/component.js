import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';
import moment from 'moment';

export default Control.extend({
  tagName: 'div',
  layout,
  classNames: ['c-scheduler'],
  attributeBindings: ['tabindex'],
  //public properties
  style: null,
  tabindex: -1,
  disabled: false,
  displayDate: null,
  selectedDate: null,
  schedulerMode: 'month',
  displayTitlePath: 'title',
  isAllDayPath: 'isAllDay',
  fromDatePath: 'fromDate',
  toDatePath: 'toDate',
  minDate: null,
  maxDate: null,
  templateItemCount: null,
  useParentWormhole: true,
  placeInArea: false,
  //public events
  onLoaded: null,
  onUnload: null,
  onDisplayRangeChanged: null,
  onSelectionChanged: null,
  onSchedulerTaskItemClick: null,

  _lineHeight: 21,
  _bodyContainerWidth: 0,
  _bodyContainerHeight: 0,
  _offsetTop: 0,
  _targetElement: null,
  _moreSource: null,
  _schedulerGuid: Ember.computed.readOnly('componentGuid'),
  _sortedItems: Ember.computed.sort('_unsortedItems', '_sortingParams').readOnly(),
  _unsortedItems: Ember.computed('itemsSource.[]', function () {
    const itemsSource = this.get('itemsSource');

    if (!Ember.isArray(itemsSource)) {
      return Ember.A();
    }

    return itemsSource;
  }).readOnly(),
  _schedulerSource: Ember.computed('_sortedItems.[]', 'startMoment', 'endMoment', function () {
    const source = {}, startMoment = this.get('startMoment'), endMoment = this.get('endMoment'), fromDatePath = this.get('fromDatePath'), toDatePath = this.get('toDatePath');

    if (!Ember.isNone(startMoment) && !Ember.isNone(endMoment)) {
      let fromDate, toDate, itemStart, itemEnd, currentStart, currentEnd, dateSource, props, index, size, originSize, padding;
      this.get('_sortedItems').forEach(function (item) {
        fromDate = Ember.get(item, fromDatePath);
        if (!Ember.isNone(fromDate)) {
          itemStart = moment(fromDate);
          if (itemStart.format('YYYY-MM-DD') < endMoment.format('YYYY-MM-DD')) {
            toDate = Ember.get(item, toDatePath);
            if (!Ember.isNone(toDate)) {
              itemEnd = moment(toDate);
              if (startMoment.format('YYYY-MM-DD') <= itemEnd.format('YYYY-MM-DD')) {
                if (itemStart.format('YYYY-MM-DD') < startMoment.format('YYYY-MM-DD')) {
                  currentStart = moment(startMoment.format('YYYY-MM-DD'), 'YYYY-MM-DD');
                } else {
                  currentStart = moment(itemStart.format('YYYY-MM-DD'), 'YYYY-MM-DD');
                }
                if (endMoment.format('YYYY-MM-DD') < itemEnd.format('YYYY-MM-DD')) {
                  currentEnd = moment(endMoment.format('YYYY-MM-DD'), 'YYYY-MM-DD');
                } else {
                  currentEnd = moment(itemEnd.format('YYYY-MM-DD'), 'YYYY-MM-DD');
                }
                index = null;
                originSize = 0;
                padding = 0;
                while (currentStart.format('YYYY-MM-DD') <= currentEnd.format('YYYY-MM-DD')) {
                  if (currentStart.day() === 0) {
                    index = null;
                  }
                  dateSource = Ember.get(source, currentStart.format('YYYY-MM-DD'));
                  if (Ember.isNone(dateSource)) {
                    if (Ember.isNone(index)) {
                      index = 0;
                      size = 1 + Math.min(itemEnd.diff(currentStart, 'days'), 6 - currentStart.day());
                      originSize = size;
                    } else {
                      size = 0;
                      padding--;
                    }
                    dateSource = {};
                    Ember.set(dateSource, index.toString(), { item: item, size: size, originSize: originSize, padding: padding });
                    Ember.set(source, currentStart.format('YYYY-MM-DD'), dateSource);
                  } else {
                    if (Ember.isNone(index)) {
                      props = Object.getOwnPropertyNames(dateSource);
                      for (let i = 0; i <= props.length; i++) {
                        if (i.toString() !== props[i]) {
                          index = i;
                          break;
                        }
                      }
                      size = 1 + Math.min(itemEnd.diff(currentStart, 'days'), 6 - currentStart.day());
                      originSize = size;
                    } else {
                      size = 0;
                      padding--;
                    }
                    Ember.set(dateSource, index.toString(), { item: item, size: size, originSize: originSize, padding: padding });
                  }
                  currentStart.add(1, 'days');
                }
              }
            } else if (startMoment.format('YYYY-MM-DD') <= itemStart.format('YYYY-MM-DD')) {
              dateSource = Ember.get(source, itemStart.format('YYYY-MM-DD'));
              if (Ember.isNone(dateSource)) {
                dateSource = {};
                Ember.set(dateSource, '0', { item: item, size: 1, originSize: 1, padding: 0 });
                Ember.set(source, itemStart.format('YYYY-MM-DD'), dateSource);
              } else {
                props = Object.getOwnPropertyNames(dateSource);
                for (let i = 0; i <= props.length; i++) {
                  if (i.toString() !== props[i]) {
                    Ember.set(dateSource, i.toString(), { item: item, size: 1, originSize: 1, padding: 0 });
                    break;
                  }
                }
              }
            }
          }
        }
      });
    }

    return source;
  }).readOnly(),
  _displayMoment: Ember.computed('displayDate', function () {
    return this._isDateInstance(this.get('displayDate')) ? moment(this.get('displayDate')) : this.get('_todayMoment');
  }).readOnly(),
  _selectedDateFormatString: Ember.computed('selectedDate', function () {
    Ember.run.once(this, '_selectionChange');

    return this._isDateInstance(this.get('selectedDate')) ? moment(this.get('selectedDate')).format('YYYY-MM-DD') : null;
  }).readOnly(),
  _todayMoment: Ember.computed(function () {
    return moment(this.get('co_CommonService').getNow());
  }).readOnly(),
  _yearText: Ember.computed('_displayMoment', function () {
    return this.get('_displayMoment').format('Y');
  }).readOnly(),
  _monthText1: Ember.computed('_displayMoment', function () {
    return this.get('_displayMoment').format('M');
  }).readOnly(),
  _monthText2: Ember.computed('_displayMoment', function () {
    return this.get('_displayMoment').format('MMMM');
  }).readOnly(),
  _todayText1: Ember.computed('_todayMoment', function () {
    return this.get('_todayMoment').format('MM/DD/YYYY');
  }).readOnly(),
  _todayText2: Ember.computed('_todayMoment', function () {
    return this.get('_todayMoment').format('dddd');
  }).readOnly(),
  _decadeSource: Ember.computed('_displayMoment', function () {
    const source = Ember.A(), currentMoment = moment(`${this.get('_displayMoment').format('YYYY')}-01-01`, 'YYYY-MM-DD');

    currentMoment.add(-50, 'years');
    for (let i = 0; i < 100; i++) {
      source.addObject({
        year: currentMoment.year(),
        isCurrent: this.get('_displayMoment').format('Y') === currentMoment.format('Y'),
      });
      currentMoment.add(1, 'years');
    }

    return source;
  }).readOnly(),
  _yearSource: Ember.computed('_displayMoment', function () {
    const source = Ember.A(), currentMoment = moment(`${this.get('_displayMoment').format('YYYY')}-01-01`, 'YYYY-MM-DD');

    for (let i = 0; i < 3; i++) {
      const row = Ember.A();

      for (let j = 0; j < 4; j++) {
        row.addObject({
          monthName: currentMoment.format('MMM'),
          month: currentMoment.month(),
          isCurrent: this.get('_displayMoment').format('YYYY-MM') === currentMoment.format('YYYY-MM'),
        });
        currentMoment.add(1, 'months');
      }
      source.addObject(row);
    }

    return source;
  }).readOnly(),
  _monthSource: Ember.computed('_displayMoment', function () {
    const source = Ember.A(), currentMoment = moment(`${this.get('_displayMoment').format('YYYY-MM')}-01`, 'YYYY-MM-DD'),
    minDateFormat = this._isDateInstance(this.get('minDate')) ? moment(this.get('minDate')).format('YYYY-MM-DD') : null,
    maxDateFormat = this._isDateInstance(this.get('maxDate')) ? moment(this.get('maxDate')).format('YYYY-MM-DD') : null;

    currentMoment.add(currentMoment.day() * -1, 'days');
    for (let i = 0; i < 6; i++) {
      const row = Ember.A();

      for (let j = 0; j < 7; j++) {
        row.addObject({
          value: currentMoment.format('YYYY-MM-DD'),
          day: currentMoment.format('ddd'),
          date: currentMoment.date(),
          isCurrent: this.get('_displayMoment').format('YYYY-MM') === currentMoment.format('YYYY-MM'),
          isDisabled: (minDateFormat && currentMoment.format('YYYY-MM-DD') < minDateFormat) || (maxDateFormat && maxDateFormat < currentMoment.format('YYYY-MM-DD')),
          isToday: this.get('_todayMoment').format('YYYY-MM-DD') === currentMoment.format('YYYY-MM-DD'),
        });
        currentMoment.add(1, 'days');
      }
      source.addObject(row);
    }

    return source;
  }).readOnly(),
  /*
  _weeklySource: Ember.computed('_displayMoment', function () {
    const _todayMoment = this.get('_todayMoment'), _displayMoment = this.get('_displayMoment'), currentMoment = moment(`${_displayMoment.format('YYYY-MM-DD')} 00:00:00`, 'YYYY-MM-DD HH:mm:ss'),
    _weeklySource = {
      year: _displayMoment.format('Y'),
      month1: _displayMoment.format('M'),
      month2: _displayMoment.format('MMMM'),
      today1: _todayMoment.format('MM/DD/YYYY'),
      today2: _todayMoment.format('dddd'),
      header: Ember.A(),
      body: Ember.A(),
    };

    currentMoment.add(currentMoment.day() * -1, 'days');
    for (let i = 0; i < 24; i++) {
      const data = Ember.A(), tempMoment = moment(currentMoment.format('YYYY-MM-DD HH:mm:ss'), 'YYYY-MM-DD HH:mm:ss');

      for (let j = 0; j < 7; j++) {
        if (i === 0) {
          _weeklySource.header.addObject({ date: tempMoment.format('D'), day: tempMoment.format('ddd'), });
        }
        data.addObject({
          text: null,
          value: tempMoment.format('YYYY-MM-DD HH:mm:ss'),
          isCurrent: _displayMoment.format('YYYY-MM') === tempMoment.format('YYYY-MM'),
          isToday: _todayMoment.format('YYYY-MM-DD') === tempMoment.format('YYYY-MM-DD'),
        });
        tempMoment.add(1, 'days');
      }
      _weeklySource.body.addObject({ time: currentMoment.format('HH:mm'), data: data });
      currentMoment.add(1, 'hours');
    }

    return _weeklySource;
  }).readOnly(),
  _dailySource: Ember.computed('_displayMoment', function () {
    const _todayMoment = this.get('_todayMoment'), _displayMoment = this.get('_displayMoment'), currentMoment = moment(`${_displayMoment.format('YYYY-MM-DD')} 00:00:00`, 'YYYY-MM-DD HH:mm:ss'),
    _dailySource = {
      year: _displayMoment.format('Y'),
      month1: _displayMoment.format('M'),
      month2: _displayMoment.format('MMMM'),
      today1: _todayMoment.format('MM/DD/YYYY'),
      today2: _todayMoment.format('dddd'),
      header: { date: currentMoment.format('D'), day: currentMoment.format('dddd') },
      body: Ember.A(),
    };

    for (let i = 0; i < 24; i++) {
      _dailySource.body.addObject({
        time: currentMoment.format('HH:mm'),
        data: {
          text: null,
          value: currentMoment.format('YYYY-MM-DD HH:mm:ss'),
          isToday: _todayMoment.format('YYYY-MM-DD') === currentMoment.format('YYYY-MM-DD'),
        }
      });
      currentMoment.add(1, 'hours');
    }

    return _dailySource;
  }).readOnly(),
  */
  _htmlSafeBodyColWidth: Ember.computed('_bodyContainerWidth', function () {
    return Ember.String.htmlSafe(`width:${parseInt(this.get('_bodyContainerWidth') / 7)}px;`);
  }).readOnly(),
  _htmlSafeBodyFirstRowHeight: Ember.computed('_lineHeight', '_bodyContainerHeight', function () {
    const _bodyContainerHeight = this.get('_bodyContainerHeight'), _lineHeight = this.get('_lineHeight');

    if (_bodyContainerHeight - _lineHeight > 0) {
      return Ember.String.htmlSafe(`height:${parseInt((_bodyContainerHeight - _lineHeight) / 6) + _lineHeight}px;`);
    }
  }).readOnly(),
  _htmlSafeBodyRowHeight: Ember.computed('_lineHeight', '_bodyContainerHeight', function () {
    const _bodyContainerHeight = this.get('_bodyContainerHeight'), _lineHeight = this.get('_lineHeight');

    if (_bodyContainerHeight - _lineHeight > 0) {
      return Ember.String.htmlSafe(`height:${parseInt((_bodyContainerHeight - _lineHeight) / 6)}px;`);
    }
  }).readOnly(),
  _lineCount: Ember.computed('_lineHeight', '_bodyContainerHeight', function () {
    const _bodyContainerHeight = this.get('_bodyContainerHeight'), _lineHeight = this.get('_lineHeight');

    if (_bodyContainerHeight - _lineHeight > 0) {
      return parseInt(parseInt((_bodyContainerHeight - _lineHeight) / 6) / _lineHeight) - 1;
    }

    return 0;
  }).readOnly(),
  _htmlSafeMoreTemplateHeight: Ember.computed('_lineHeight', function () {
    return Ember.String.htmlSafe(`min-height:${this.get('_lineHeight')}px;`);
  }).readOnly(),
  _htmlSafeBodyLineHeight: Ember.computed('_lineHeight', function () {
    return Ember.String.htmlSafe(`height:${this.get('_lineHeight')}px;`);
  }).readOnly(),
  _htmlSafeMoreContainerStyle: Ember.computed('_bodyContainerWidth', '_bodyContainerHeight', function () {
    return Ember.String.htmlSafe(`width:${(this.get('_bodyContainerWidth') / 7) + 10}px;`);
  }).readOnly(),
  _moreOpen: Ember.computed('_targetElement', function () {
    return !Ember.isNone(this.get('_targetElement'));
  }).readOnly(),
  _moreSource: Ember.computed('_moreSchedulerSource', '_moreData', function () {
    const source = Ember.A(), _itemsSource = Ember.get(this.get('_moreSchedulerSource'), this.get('_moreData.value'));

    if (!Ember.isNone(_itemsSource)) {
      Object.getOwnPropertyNames(_itemsSource).forEach(function (prop) {
        source.addObject(_itemsSource[prop]);
      });
    }

    return source;
  }),
  _observedProperty1: Ember.computed('schedulerMode', function () {
    Ember.run.scheduleOnce('afterRender', this, '_schedulerModeChange');
  }).readOnly(),
  _observedProperty2: Ember.computed('_displayMoment', function () {
    const _displayMoment = this.get('_displayMoment');

    if (!Ember.isNone(_displayMoment)) {
      const currentMoment = moment(`${_displayMoment.format('YYYY-MM')}-01`, 'YYYY-MM-DD'),
        startMoment = this.get('startMoment'), endMoment = this.get('endMoment');
      currentMoment.add(currentMoment.day() * -1, 'days');
      if (Ember.isNone(startMoment) || startMoment.format('YYYY-MM-DD') !== currentMoment.format('YYYY-MM-DD')) {
        this.set('startMoment', moment(currentMoment.format('YYYY-MM-DD'), 'YYYY-MM-DD'));
        Ember.run.once(this, '_displayRangeChange');
      }
      currentMoment.add(7 * 6, 'days');
      if (Ember.isNone(endMoment) || endMoment.format('YYYY-MM-DD') !== currentMoment.format('YYYY-MM-DD')) {
        this.set('endMoment', moment(currentMoment.format('YYYY-MM-DD'), 'YYYY-MM-DD'));
        Ember.run.once(this, '_displayRangeChange');
      }
    }
  }).readOnly(),
  init() {
    this._super(...arguments);
    this.set('_sortingParams', [`${this.get('fromDatePath')}:asc`, `${this.get('toDatePath')}:desc`]);
    this.set('schedulerModeSource', [
      { text: 'Day', value: 'day'},
      { text: 'Week', value: 'week'},
      { text: 'Month', value: 'month'},
      { text: 'Year', value: 'year'},
      { text: 'Decade', value: 'decade'},
    ]);
  },
  didInsertElement() {
    this._super(...arguments);
    this.$('div.scrollbar-macosx').scrollbar({
      'onUpdate': function(el) {
        Ember.run.once(this, '_schedulerBodySizeChange', el.prop('clientWidth'), el.prop('clientHeight'));
      }.bind(this),
    });
  },
  willDestroyElement() {
    this.$('.scrollbar-macosx').scrollbar('destroy');
    this._super(...arguments);
  },
  click(event) {
    const $target = Ember.$(event.target).closest(`.${this.get('_schedulerGuid')}-item`);

    if ($target.length > 0) {
      let component = this._getComponent($target);

      if (!Ember.get(component, 'data.isDisabled')) {
        const selectedDate = this.get('selectedDate');
  
        if (Ember.isNone(selectedDate) || moment(selectedDate).format('YYYY-MM-DD') !== Ember.get(component, 'data.value')) {
          this.set('selectedDate', moment(Ember.get(component, 'data.value'), 'YYYY-MM-DD').toDate());
        }
      }
      component = null;
    }
  },
  _isDateInstance(date) {
    return date instanceof Date && !Number.isNaN(date.valueOf());
  },
  _schedulerModeChange() {
    if (this.get('schedulerMode') === 'decade') {
      this.$('div.scrollbar-macosx').removeClass('observation');
      this.$('div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx').scrollTop(
        (this.$('div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx').prop('scrollHeight') - this.$('div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx').height()) / 2);
    } else {
      this.$('div.scrollbar-macosx').addClass('observation');
    }
  },
  _schedulerBodySizeChange(width, height) {
    this.set('_bodyContainerWidth', width);
    this.set('_bodyContainerHeight', height);
  },
  _displayRangeChange() {
    this._raiseEvents('onDisplayRangeChanged', {
      source: this, displayDate: this.get('displayDate'), firstDate: this.get('startMoment').toDate(), lastDate: this.get('endMoment').toDate(),
    });
  },
  _selectionChange() {
    const includedItems = Ember.A(), _selectedDateFormatString = this.get('_selectedDateFormatString');
    let _itemsSource = null;

    if (!Ember.isNone(_selectedDateFormatString)) {
      _itemsSource = Ember.get(this.get('_schedulerSource'), _selectedDateFormatString);
    }
    if (!Ember.isNone(_itemsSource)) {
      Object.getOwnPropertyNames(_itemsSource).forEach(function (prop) {
        includedItems.addObject(_itemsSource[prop]);
      });
    }
    this._raiseEvents('onSelectionChanged', {
      source: this, selectedDate: this.get('selectedDate'), includedItems: includedItems,
    });
  },
  actions: {
    moveDisplayDate(param1, param2) {
      this.set('displayDate', moment(`${this.get('_displayMoment').format('YYYY-MM-DD')} 00:00:00`, 'YYYY-MM-DD HH:mm:ss').add(param1, param2).toDate());
    },
    moveToday() {
      const schedulerMode = this.get('schedulerMode');

      if (schedulerMode === 'decade' || schedulerMode === 'year') {
        this.set('schedulerMode', 'month');
      }
      this.set('displayDate', moment(`${this.get('_todayMoment').format('YYYY-MM-DD')} 00:00:00`, 'YYYY-MM-DD HH:mm:ss').toDate());
    },
    changeDisplayDate(param1, param2) {
      if (param1 === 'year') {
        this.set('displayDate', moment(`${this.get('_displayMoment').format('YYYY-MM-DD')} 00:00:00`, 'YYYY-MM-DD HH:mm:ss').year(param2).toDate());
        this.set('schedulerMode', param1);
      }
      if (param1 === 'month') {
        this.set('displayDate', moment(`${this.get('_displayMoment').format('YYYY-MM-DD')} 00:00:00`, 'YYYY-MM-DD HH:mm:ss').month(param2).toDate());
        this.set('schedulerMode', param1);
      }
    },
    changeMoveMode(param1) {
      this.set('schedulerMode', param1);
    },
    mouseDownToOutside(event) {
      if (!document.getElementById('max-wormhole-parent').contains(event.target)) {
        this.set('_targetElement', null);
        this.set('_offsetTop', 0);
        this.set('_moreData', null);
        this.set('_moreSchedulerSource', null);
      }
    },
    schedulerTaskItemClick(item, event) {
      event.stopPropagation();
      this._raiseEvents('onSchedulerTaskItemClick', { source: this, originalEvent: event, item: item });
    },
    schedulerMoreClick(component, event) {
      event.stopPropagation();
      this.set('_targetElement', Ember.get(component, 'element'));
      this.set('_offsetTop', moment(Ember.get(component, 'data.value'), 'YYYY-MM-DD').diff(this.get('startMoment'), 'days') < 7 ? -6 : -6 - this.get('_lineHeight'));
      this.set('_moreData', Ember.get(component, 'data'));
      this.set('_moreSchedulerSource', Ember.get(component, '_schedulerSource'));
      
    },
    schedulerMoreAreaClick(event) {
      if (!this.get('_moreData.isDisabled')) {
        const selectedDate = this.get('selectedDate');
  
        if (Ember.isNone(selectedDate) || moment(selectedDate).format('YYYY-MM-DD') !== this.get('_moreData.value')) {
          this.set('selectedDate', moment(this.get('_moreData.value'), 'YYYY-MM-DD').toDate());
        }
      }
    },
  },
});