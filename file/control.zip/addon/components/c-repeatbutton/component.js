import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';
// import ToolTipMixin from '../../mixins/tooltip-mixin';

export default Control.extend({
  layout,
  tagName: 'div',
  classNames: ['c-repeatbutton'],
  attributeBindings: ['tabindex'],
  //public properties
  style: null,
  type: 'updown',
  value: 0,
  delay: 100,
  min: null,
  max: null,
  tabindex: -1,
  disabled: false,
  //public events
  onLoaded: null,
  onUnload: null,
  onClick: null,
  onFocusIn: null,
  onFocusOut: null,

  _updownType: Ember.computed.equal('type', 'updown'),
  _upType: Ember.computed.equal('type', 'up'),
  _downType: Ember.computed.equal('type', 'down'),
  _repeat: false,
  click(event) {
    this._raiseEvents('onClick', {
      source: this,
      originalEvent: event
    });
  },
  focusIn(event) {
    this._raiseEvents('onFocusIn', {
      source: this,
      originalEvent: event
    });
  },
  focusOut(event) {
    this._raiseEvents('onFocusOut', {
      source: this,
      originalEvent: event
    });
  },
  actions: {
    increaseStart(event) {
      const max = this.get('max');
      let delay = this.get('delay'), currentDelay = 250, repeat = true, increaseValue = function() {
        if (!this.get('isDestroying') && !this.get('isDestroyed') && (Ember.isNone(max) || isNaN(max) || this.get('value') < max)) {
          this.set('value', this.get('value') + 1);
          this._raiseEvents('onChanged', {
            source: this,
            originalEvent: event,
            value: this.get('value')
          });
          Ember.run.later(this, function () {
            if (!this.get('isDestroying') && !this.get('isDestroyed') && repeat) {
              currentDelay = delay;
              increaseValue();
            } else {
              delay = null;
              currentDelay = null;
              repeat = null;
              increaseValue = null;
            }
          }, currentDelay);
        }
      }.bind(this);

      this.$(event.currentTarget).on('mouseup mouseleave', function () {
        repeat = false;
        this.$(event.currentTarget).off('mouseup mouseleave');
      }.bind(this));
      increaseValue();
    },
    decreaseStart(event) {
      const min = this.get('min');
      let delay = this.get('delay'), currentDelay = 250, repeat = true, decreaseValue = function() {
        if (!this.get('isDestroying') && !this.get('isDestroyed') && (Ember.isNone(min) || isNaN(min) || min < this.get('value'))) {
          this.set('value', this.get('value') - 1);
          this._raiseEvents('onChanged', {
            source: this,
            originalEvent: event,
            value: this.get('value')
          });
          Ember.run.later(this, function () {
            if (!this.get('isDestroying') && !this.get('isDestroyed') && repeat) {
              currentDelay = delay;
              decreaseValue();
            } else {
              delay = null;
              currentDelay = null;
              repeat = null;
              decreaseValue = null;
            }
          }, currentDelay);
        }
      }.bind(this);

      this.$(event.currentTarget).on('mouseup mouseleave', function () {
        repeat = false;
        this.$(event.currentTarget).off('mouseup mouseleave');
      }.bind(this));
      decreaseValue();
    },
  },
});