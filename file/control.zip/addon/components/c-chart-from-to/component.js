import Ember from 'ember';
import layout from './template';
//import CHIS from 'framework/chis-framework';
import Control from '../c-control/component';
import GlobalServiceContainerMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

export default Control.extend(GlobalServiceContainerMixin, StatefulComponentMixin, {
  layout,

  tagName: 'g',
  classNames: ['c-chart-from-to'],

  chartData: null,
  reload: null,
  height: null,
  parentType: null,
  seriesData: null,
  trace: null,
  width: null,
  xAxis: null,
  xScale: null,
  yAxis: null,
  yScale: null,
  setting: null,
  // 다음 심볼과의 거리
  _distance: null,
  _intersectionPoint: null,
  // 현재 심볼 폭
  _minWidth: null,
  _postfixFrom: null,
  _postfixTo: null,
  _seriesTop: null,
  _zoominPoint: null,

  _chartData: Ember.computed.alias('chartData').readOnly(),
  _reload: Ember.computed.alias('reload').readOnly(),
  _height: Ember.computed.alias('height').readOnly(),
  _parentType: Ember.computed.alias('parentType').readOnly(),
  _seriesData: Ember.computed.alias('seriesData').readOnly(),
  _trace: Ember.computed.alias('trace').readOnly(),
  _width: Ember.computed.alias('width').readOnly(),
  _xAxis: Ember.computed.alias('xAxis').readOnly(),
  _xScale: Ember.computed.alias('xScale').readOnly(),
  _yAxis: Ember.computed.alias('yAxis').readOnly(),
  _yScale: Ember.computed.alias('yScale').readOnly(),

  _isTrendChart: Ember.computed('_chartData', function() {


    const series = this.get('_chartData').series;

    for(let i=0; i < series.length; i++) {
      if(series[i].config.type === 'point' || series[i].config.type === 'fromTo' ) {
        return true;
      }
    }

    return false;
  }),
  _settingPaddingTop: Ember.computed('_setting', function() {
    return this.get('_setting').paddingTop;
  }),
  _settingPaddingRight: Ember.computed('setting', function() {
    return this.get('setting').paddingRight;
  }),
  _settingPaddingLeft: Ember.computed('setting', function() {
    return this.get('setting').paddingLeft;
  }),
  _settingPaddingBottom: Ember.computed('setting', function() {
    return this.get('setting').paddingBottom;
  }),
  _settingNormalOpacity: Ember.computed('setting', function() {
    return this.get('setting').normalOpacity;
  }),
  _settingDarkOpacity: Ember.computed('setting', function() {
    return this.get('setting').darkOpacity;
  }),
  _settingTransparentOpacity: Ember.computed('setting', function() {
    return this.get('setting').transparentOpacity;
  }),
  _settingGlyphiconPrefix: Ember.computed('setting', function() {
    return this.get('setting').glyphiconPrefix;
  }),

  onPropertyInit() {
    this._super(...arguments);
    this._logTrace('c-chart-from-to.onPropertyInit()');

    this.setStateProperties([]);

    const two = 2;

    this.set('_distance', two);
    this.set('_intersectionPoint', []);
    this.set('_minWidth', two);
    this.set('_postfixFrom', 'From');
    this.set('_postfixTo', 'To');
    this.set('_zoominPoint', []);
  },

  didInsertElement() {
    this._super(...arguments);
    this._logTrace('c-chart-from-to.didInsertElement()');
  },

  didRender() {
    this._super(...arguments);
    this._logTrace('c-chart-from-to.didRender()');
    if(Ember.isEmpty(this.get('_chartData')) === true) {
      return;
    }
    this.redraw();
  },

  didUpdateAttrs() {
    this._super(...arguments);
    this._logTrace('c-chart-from-to.didUpdateAttrs()');
  },

  willDestroyElement() {
    this._super(...arguments);
    this._logTrace('c-chart-from-to.willDestroyElement()');

    this._removeEventListener();

    if(this.get('_parentType') === 'timeline') {
      this._removeTimelineDom();
    } else {
      this._removeChartDom();
    }
    // this._removeDom(this.get('_parentType'));

    // 클로저 해제
    this._logTrace = null;
    this._convertDateFormat = null;
  },

  _logTrace(text) {
    if(this.get('_trace') === true) {
      Ember.Logger.log(text);
    }
  },

  // date타입 체크 후 변경
  _convertDateFormat(date, isTimeXAxis) {
    if (isTimeXAxis) {
      if (date instanceof Date && date.valueOf() && !Number.isNaN(date.valueOf())) {
        return date;
      } else {
        return new Date(date);
      }
    } else {
      return date;
    }
  },

  redraw() {
    // _seriesData 기준 데이터 정렬 by width
    this._sortSeriesData();
    if (this.get('_parentType') === 'timeline') {
      this._createTimelineSeries();
    }
    else {
      this._createChartSeries();
    }
    this._checkRect();
    this._createIntersectionImage();
    this._createZoominImage();
  },


  _sortSeriesData() {
    const zero = 0;
    const one = 1;
    const minusOne = -1;
    const postfixFrom = this.get('_postfixFrom');
    const postfixTo = this.get('_postfixTo');
    const series = this.get('_seriesData');
    const fromName = series.config.xAxisProperty + postfixFrom;
    const toName = series.config.xAxisProperty + postfixTo;
    const data = series.data;

    for(let i=0; i < data.length; i++) {
      const current = data[i];
      const from = current[fromName];
      const to = current[toName];
      const fromDate = new Date(from);
      const toDate = new Date(to);
      const diff = toDate.getTime() - fromDate.getTime();

      current.diff = diff;
    }

    data.sort(function(a, b) {
      if(a.diff == b.diff) {
        return zero;
      } else if (a.diff < b.diff) {
        return one;
      } else {
        return minusOne;
      }
    });
  },

  _createChartSeries() {
    const zero = 0;
    const adjustSymbolSize = 10;
    const half = 0.5;

    this._removeEventListener();
    this._removeChartDom();
    // this._removeDom(this.get('_parentType'));

    const series = this.get('_seriesData');

    if(series.data.length === zero) {
      return;
    }

    const xScaleFunction = this.get('_xScale');
    const yScaleFunction = this.get('_yScale');
    const postfixFrom = this.get('_postfixFrom');
    const postfixTo = this.get('_postfixTo');
    const isTrendChart = this.get('_isTrendChart');
    const isTimeXAxis = this.get('_chartData').isTimeXAxis;

    const fromName = series.config.xAxisProperty + postfixFrom;
    const toName = series.config.xAxisProperty + postfixTo;
    const toBeSymbolSize = series.config.symbolSize + adjustSymbolSize;
    const tooltipTemplate = series.config.tooltipTemplate;
    const idProperty = series.config.idProperty;
    const dateFormat = this.get('_chartData').timeFormat.dataFormat;

    // tooltipTemplate 을 위한 svg 의 sibling 개체
    const p = this.$().parent().parent();

    if(p.children('div.chartTooltipTemplate').length === zero) {
      p.append('<div class=\'chartTooltipTemplate\'></div>');
    }

    const toolTip = d3.select(p[zero]).selectAll('div.chartTooltipTemplate');
    let el, seriesRootG;

    if(isTrendChart === true) {
      el = this.$().parent().get(zero);
      seriesRootG = d3.select(el)
        .select('.main')
        .select('.chartRoot')
        .append('g')
        .attr('class', 'chart seriesRoot' + series.no)
        .attr('data-id', 'seriesRoot' + series.no);
    } else {
      el = this.$().get(zero);
      seriesRootG = d3.select(el);
    }

    // fromTo
    seriesRootG.selectAll('.chart.fromTo.series' + series.no)
      .data(series.data)
      .enter()
      .append('rect')
      .attr('class', 'chart fromTo series' + series.no)
      .attr('x', d => {
        let xAxisProperty = this._convertDateFormat(d[fromName], isTimeXAxis);

        const w = xScaleFunction(xAxisProperty);

        return w;
      })
      .attr('y', function(d) {
        const temp = yScaleFunction(d[series.config.yAxisProperty]);
        const diff = toBeSymbolSize * half;
        const w = temp - diff;

        return w;
      })
      .attr('width', d => {
        const result = xScaleFunction(this._convertDateFormat(d[toName], isTimeXAxis)) - xScaleFunction(this._convertDateFormat(d[fromName], isTimeXAxis));

        return result;
      })
      .attr('height', toBeSymbolSize)
      .attr('fill', series.config.symbolColor)
      .attr('stroke', series.config.strokeColor || 'none')
      .on('click', function(d) {
        const id = d[idProperty];
        const obj = { series: series, id: id};

        this._raiseEvents('clickDataCB', obj);
        d3.event.stopPropagation();
      }.bind(this))
      .on('mouseover', function() {
        this._logTrace('c-chart-fromTo.fromTo.mouseover()');
        this._raiseEvents('mouseoverSeriesCB', series);
        d3.event.stopPropagation();
      }.bind(this))
      .on('mouseout', function() {
        this._logTrace('c-chart-fromTo.fromTo.mouseout()');
        this._raiseEvents('mouseoutSeriesCB', series);
        toolTip.style('display', 'none');

        d3.event.stopPropagation();
      }.bind(this))
      .on('mousemove', function(d) {
        this._logTrace('c-chart-fromTo.fromTo.mousemove()');

        let button = null;
        if(Ember.isEmpty(d3.event.sourceEvent)) {
          button = d3.event.buttons;
        } else {
          button = d3.event.sourceEvent.buttons;
        }
        if(button === 2) {
          return;
        }

        const adjustX = 10;
        const adjustY = 20;
        const x = d3.event.x + adjustX;
        const y = d3.event.y + adjustY;

        toolTip.style('left', x + 'px');
        toolTip.style('top', y + 'px');
        toolTip.style('display', 'inline-block');

        if(Ember.isEmpty(tooltipTemplate) || Ember.isBlank(tooltipTemplate) ) {
          let val = d[series.config.tooltipProperty];

          if( typeof val === 'object' && val instanceof Date) {
            val = this._convertDateString(val, dateFormat);
          }
          toolTip.html(val);
        } else {
          let result = tooltipTemplate;

          for(const name in d) {
            let val = d[name];

            if( typeof val === 'object' && val instanceof Date) {
              val = this._convertDateString(val, dateFormat);
            }

            const regexp = new RegExp('{{' + name + '}}', 'gi');

            result = result.replace(regexp, val);
          }
          toolTip.html(result);
        }
      }.bind(this));
  },

  _convertDateString(date, format) {
    return this.get('fr_I18nService').formatDate(date, format);
  },

  _removeEventListener() {
    const zero = 0;
    const series = this.get('_seriesData');
    const seriesNo = series.no;
    const click = ['.' + this.get('_parentType') + '.fromTo.series' + seriesNo];
    const dblclick = ['.' + this.get('_parentType') + '.fromTo.series' + seriesNo];
    const mouseOverOut = ['.' + this.get('_parentType') + '.fromTo.series' + seriesNo];
    const mouseMove = ['.' + this.get('_parentType') + '.fromTo.series' + seriesNo];
    const el = this.$().parent().get(zero);
    const thisObj = d3.select(el).select('.seriesRoot' + seriesNo);

    for(let i=0; i < click.length; i++) {
      thisObj.selectAll(click[i]).on('click', null);
    }

    for(let i=0; i < dblclick.length; i++) {
      thisObj.selectAll(dblclick[i]).on('dblclick', null);
    }

    for(let i=0; i < mouseOverOut.length; i++) {
      thisObj.selectAll(mouseOverOut[i]).on('mouseover', null).on('mouseout', null);
    }

    for(let i=0; i < mouseMove.length; i++) {
      thisObj.selectAll(mouseMove[i]).on('mousemove', null);
    }
  },

  // _removeDom(type) {
  //   const zero = 0;
  //   const series = this.get('_seriesData');
  //   const el = this.$().parent().get(zero);
  //   let target = null;
  //   if (type === 'timeline') {
  //     target = d3.select(el).select(`.main >.timelineRoot > .seriesRoot` + series.no);
  //   } else {
  //     target = d3.select(el).select(`.main >.chartRoot > .seriesRoot` + series.no);
  //   }

  //   for (const iter of target.selectAll('g')) {
  //     iter.remove();
  //   }
  //   target.remove();
  // },

  _removeChartDom() {
    const zero = 0;
    const series = this.get('_seriesData');
    const el = this.$().parent().get(zero);

    d3.select(el)
      .selectAll('.main >.chartRoot > .seriesRoot' + series.no)
      .remove();
  },

  _removeTimelineDom() {
    const zero = 0;
    const series = this.get('_seriesData');
    const el = this.$().parent().get(zero);
    const target = d3.select(el).select('.main >.timelineRoot > .seriesRoot' + series.no);

    Array.from(target.selectAll('g')).forEach(() => node.remove());
    target.remove();

  },

  _createTimelineSeries() {
    const zero = 0;
    const ten = 10;
    const half = 0.5;

    this._removeEventListener();
    this._removeTimelineDom();
    // this._removeDom(this.get('_parentType'));

    const series = this.get('_seriesData');

    if(series.data.length === zero) {
      return;
    }

    const xScaleFunction = this.get('_xScale');
    const yScaleFunction = this.get('_yScale');

    const postfixFrom = this.get('_postfixFrom');
    const postfixTo = this.get('_postfixTo');
    const fromName = series.config.xAxisProperty + postfixFrom;
    const toName = series.config.xAxisProperty + postfixTo;
    const isTimeXAxis = this.get('_chartData').isTimeXAxis;

    const toBeSymbolSize = series.config.symbolSize + ten;
    const tooltipTemplate = series.config.tooltipTemplate;
    const idProperty = series.config.idProperty;
    const dateFormat = this.get('_chartData').timeFormat.dataFormat;

    // tooltipTemplate 을 위한 svg 의 sibling 개체
    const p = this.$().parent().parent();

    if(p.children('div.chartTooltipTemplate').length === zero) {
      p.append('<div class=\'chartTooltipTemplate\'></div>');
    }

    const toolTip = d3.select(p[zero]).selectAll('div.chartTooltipTemplate');
    const el = this.$().parent().get(zero);
    const seriesRootG = d3.select(el)
      .select('.main')
      .select('.timelineRoot')
      .append('g')
      .attr('class', 'chart-type-fromto timeline seriesRoot' + series.no)
      .attr('data-id', 'seriesRoot' + series.no);

    let _this = this;

    // fromTo
    seriesRootG
      .selectAll('.timeline.fromTo.series' + series.no)
      .data(series.data)
      .enter()
      .append('rect')
      .attr('class', 'timeline fromTo series' + series.no)
      .attr('x', d => {
        let xAxisProperty = this._convertDateFormat(d[fromName], isTimeXAxis);
        const w = xScaleFunction(xAxisProperty);

        return w;
      })
      .attr('y', function(d) {
        const temp = yScaleFunction(d[series.config.yAxisProperty]);
        const diff = toBeSymbolSize * half;
        const w = temp - diff;

        return w;
      })
      .attr('width', d => {
        const result = xScaleFunction(this._convertDateFormat(d[toName], isTimeXAxis)) - xScaleFunction(this._convertDateFormat(d[fromName], isTimeXAxis));

        return result;
      })
      .attr('height', toBeSymbolSize)
      .attr('fill', function(d) {
        // TODO ASH : 2018.6.8 동일 Series에서 색상 지정
        const result = Ember.isNone(d['color']) ? series.config.symbolColor : d['color'];
        return result;
      })
      .attr('stroke', series.config.strokeColor || 'none')
      .attr("data-index", function(d, i) { return i; })
      .on('click', function(d) {
        const id = d[idProperty];
        const obj = { series: series, id: id};

        this._raiseEvents('clickDataCB', obj);
        d3.event.stopPropagation();
      }.bind(this))
      .on('dblclick', d => {
        const id = d[idProperty];
        const obj = {
          series: series,
          id: id,
          data: d
        };
        this._raiseEvents('dblclickSeriesCB', obj);
        d3.event.stopPropagation();
      })
      .on('mouseover', function(data) {
        this.parentNode.appendChild(this);
        _this._logTrace('c-chart-fromTo.fromTo.mouseover()');
        _this._raiseEvents('mouseoverSeriesCB', series);
        d3.event.stopPropagation();
      })
      .on('mouseout', function() {
        this._logTrace('c-chart-fromTo.fromTo.mouseout()');
        this._raiseEvents('mouseoutSeriesCB', series);
        toolTip.style('display', 'none');

        this.redraw();
        d3.event.stopPropagation();
      }.bind(this))
      .on('mousemove', function(d) {
        this._logTrace('c-chart-fromTo.fromTo.mousemove()');

        let button = null;
        if(Ember.isEmpty(d3.event.sourceEvent)) {
          button = d3.event.buttons;
        } else {
          button = d3.event.sourceEvent.buttons;
        }
        if(button === 2) {
          return;
        }

        const adjustX = 10;
        const adjustY = 20;
        const x = d3.event.x + adjustX;
        const y = d3.event.y + adjustY;

        toolTip.style('left', x + 'px');
        toolTip.style('top', y + 'px');
        toolTip.style('display', 'inline-block');

        if(Ember.isEmpty(tooltipTemplate) || Ember.isBlank(tooltipTemplate)) {
          let val = d[series.config.tooltipProperty];

          if( typeof val === 'object' && val instanceof Date) {
            val = this._convertDateString(val, dateFormat);
          }
          toolTip.html(val);
        } else {
          let result = tooltipTemplate;

          for(const name in d) {
            let val = d[name];

            if( typeof val === 'object' && val instanceof Date) {
              val = this._convertDateString(val, dateFormat);
            }

            const regexp = new RegExp('{{' + name + '}}', 'gi');

            result = result.replace(regexp, val);
          }
          toolTip.html(result);
        }
      }.bind(this));
  },

  _checkRect() {
    const zero = 0;
    const one = 1;
    const minusOne = -1;
    // timeline 과 chart 위치 다름!!
    let series = this.get('_seriesData');
    let el = null;
    let rectDom = null;
    const zoominResults = [];

    if(this.get('_parentType') === 'timeline') {
      series = this.get('_seriesData');
      el = this.$().parent().get(zero);

      rectDom = d3.select(el)
        .select('.main')
        .select('.timelineRoot')
        .selectAll('.timeline.fromTo.series' + series.no);
    } else {
      series = this.get('_seriesData');
      el = this.$().parent().get(zero);

      rectDom = d3.select(el)
        .select('.main')
        .select('.chartRoot')
        .selectAll('.chart.fromTo.series' + series.no);
    }

    const rects = [];

    if(!rectDom._groups.length) {
      return;
    }

    if(Ember.isNone(rectDom._groups[0])){
      return;
    }

    this.set('_seriesTop', this.$(rectDom._groups[zero][zero]).attr('y'));

    for(let i=0; i < rectDom._groups[zero].length; i++) {
      const currentDom = rectDom._groups[zero][i];

      rects.push({
        x: parseFloat(this.$(currentDom).attr('x')),
        width: parseFloat(this.$(currentDom).attr('width'))
      });

      // width 체크
      if(this.$(currentDom).attr('width') <= this.get('_minWidth')) {
        zoominResults.push(this.$(currentDom).attr('x'));
      }
    }

    rects.sort(function(a, b) {
      if(a.x == b.x) {
        return zero;
      } else if (a.x < b.x) {
        return minusOne;
      } else {
        return one;
      }
    });

    const intersectionResults = [];

    for(let i=0; i < rects.length; i++) {
      if(i === rects.length - one) {
        break;
      }

      const current = rects[i];
      const next = rects[i+1];

     // Todo ASH : 겹침 오류로 인하여 distance 제거
     if(current.x + current.width > next.x ) {
        intersectionResults.push((current.x + next.x) /2);
      }
    }

    this.set('_intersectionPoint', intersectionResults);
    this.set('_zoominPoint', zoominResults);
  },
  // 중복되는 영역에 특정 표시. z-index까지 처리
  _createIntersectionImage() {
    const zero = 0;
    const ten = 10;
    const twenty = 20;
    const target = this.get('_intersectionPoint');
    const seriesTop = this.get('_seriesTop');
    const series = this.get('_seriesData');
    const glyphiconPrefix = this.get('_settingGlyphiconPrefix');
    const toBeSymbolSize = series.config.symbolSize + ten;
    // console.log('중복되는 영역', target);

    if(target === null || !target.length) {
      return;
    }

    let el = null;
    let seriesRoot = null;

    if(this.get('_parentType') === 'timeline') {
      el = this.$().parent().get(zero);

      seriesRoot = d3.select(el)
        .select('.main')
        .select('.timelineRoot')
        .select('.timeline.seriesRoot' + series.no);
        //fromToSymbol

      seriesRoot
        .selectAll('.timeline.foreignObject.intersect.series' + series.no)
        .data(target)
        .enter()
        .append('svg:foreignObject')
        .attr('class', 'timeline foreignObject intersect series' + series.no )
        .attr('x', function(d) {
          const w = d;
          // xScaleFunction(d[series.config.xAxisProperty]) - (toBeSymbolSize * 0.5);

          return w;
        })
        .attr('y', function() {
          const w = seriesTop - toBeSymbolSize;
          //yScaleFunction(d[series.config.yAxisProperty]) - (toBeSymbolSize * 0.5);

          return w;
        })
        // [COMPATIBILITY-EDGE]
        .attr('width', twenty)
        .attr('height', twenty)
        .append('xhtml:i')
        .attr('class', 'timeline intersect series' + series.no + ' ' + glyphiconPrefix + ' md-12')
        .style('color', '#FF4000')
        .text('toll');
    } else {
      el = this.$().parent().get(0);

      seriesRoot = d3.select(el)
        .select('.main')
        .select('.chartRoot')
        .select('.chart.seriesRoot' + series.no);

      seriesRoot
        .selectAll('.chart.foreignObject.intersect.series' + series.no)
        .data(target)
        .enter()
        .append('svg:foreignObject')
        .attr('class', 'chart foreignObject intersect series' + series.no )
        .attr('x', function(d) {

          const w = d;
          // xScaleFunction(d[series.config.xAxisProperty]) - (toBeSymbolSize * 0.5);

          return w;
        })
        .attr('y', function() {
          const w = seriesTop - toBeSymbolSize;
          //yScaleFunction(d[series.config.yAxisProperty]) - (toBeSymbolSize * 0.5);

          return w;
        })
        // [COMPATIBILITY-EDGE]
        .attr('width', 20)
        .attr('height', 20)
        .append('xhtml:i')
        .attr('class', 'chart intersect series' + series.no + ' ' + glyphiconPrefix + ' md-12')
        .style('color', '#FF4000')
        .text('toll');
    }
  },

  _createZoominImage() {
    const zero = 0;
    const ten = 10;
    const twenty = 20;
    const target = this.get('_zoominPoint');
    const seriesTop = this.get('_seriesTop');
    const series = this.get('_seriesData');
    const glyphiconPrefix = this.get('_settingGlyphiconPrefix');
    const toBeSymbolSize = series.config.symbolSize + ten;

    if(target === null || target.length === zero) {
      return;
    }

    let el = null;
    let seriesRoot = null;

    if(this.get('_parentType') === 'timeline') {
      el = this.$().parent().get(zero);
      seriesRoot = d3.select(el)
        .select('.main')
        .select('.timelineRoot')
        .select('.timeline.seriesRoot' + series.no);

      seriesRoot
        .selectAll('.timeline.foreignObject.zoomin.series' + series.no)
        .data(target)
        .enter()
        .append('svg:foreignObject')
        .attr('class', 'timeline foreignObject zoomin series' + series.no )
        .attr('x', function(d) {
          //let temp = d;
          // xScaleFunction(d[series.config.xAxisProperty]) - (toBeSymbolSize * 0.5);
          const half = twenty * 0.5;
          const w = d - half;
          // image width 50%

          return w;
        })
        .attr('y', function() {
          const w = seriesTop - toBeSymbolSize;
          //yScaleFunction(d[series.config.yAxisProperty]) - (toBeSymbolSize * 0.5);

          return w;
        })
        // [COMPATIBILITY-EDGE]
        .attr('width', twenty)
        .attr('height', twenty)
        .append('xhtml:i')
        .attr('class', 'timeline zoomin series' + series.no + ' ' + glyphiconPrefix + ' md-12')
        .style('color', '#0000FF')
        .text('zoom_in');
    } else {
      el = this.$().parent().get(0);

      seriesRoot = d3.select(el)
        .select('.main')
        .select('.chartRoot')
        .select('.chart.seriesRoot' + series.no);

      seriesRoot
        .selectAll('.chart.foreignObject.zoomin.series' + series.no)
        .data(target)
        .enter()
        .append('svg:foreignObject')
        .attr('class', 'chart foreignObject zoomin series' + series.no )
        .attr('x', function(d) {
          const w = d;
          // xScaleFunction(d[series.config.xAxisProperty]) - (toBeSymbolSize * 0.5);

          return w;
        })
        .attr('y', function() {
          const w = seriesTop - toBeSymbolSize;

          return w;
        })
        // [COMPATIBILITY-EDGE]
        .attr('width', 20)
        .attr('height', 20)
        .append('xhtml:i')
        .attr('class', 'chart zoomin series' + series.no + ' ' + glyphiconPrefix + ' md-12')
        .style('color', '#0000FF')
        .text('zoom_in');
    }
  },

  actions: {
  },
});

