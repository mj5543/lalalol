import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';

export default Control.extend({
  layout,
  tagName: 'div',
  classNames: ['c-togglebutton','btn','btn-default','btn-rounded'],
  classNameBindings: ['_unchecked:off'],
  attributeBindings: ['tabindex'],
  //public properties
  style: null,
  content: null,
  checked: false,
  showDefaultIcon: true,
  tabindex: -1,
  disabled: false,
  readOnly: false,
  //public events
  onLoaded: null,
  onUnload: null,
  onClick: null,
  onFocusIn: null,
  onFocusOut: null,
  onChanged: null,

  _unchecked: Ember.computed.not('checked').readOnly(),
  click(event) {
    this.toggleProperty('checked');
    this._raiseEvents('onChanged', {
      source: this,
      originalEvent: event,
      checked: this.get('checked')
    });
    this._raiseEvents('onClick', {
      source: this,
      originalEvent: event
    });
  },
  focusIn(event) {
    this._raiseEvents('onFocusIn', {
      source: this,
      originalEvent: event
    });
  },
  focusOut(event) {
    this._raiseEvents('onFocusOut', {
      source: this,
      originalEvent: event
    });
  },
});