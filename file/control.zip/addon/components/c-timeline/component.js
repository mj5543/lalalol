import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';
import GlobalServiceContainerMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

export default Control.extend(GlobalServiceContainerMixin, StatefulComponentMixin, {
  layout,

  classNames: ['c-timeline'],

  actionMode: null,
  addSeries: null,
  reload: null,
  height: null,
  removeSeriesNo: null,
  timelineData: null,
  trace: null,
  width: null,
  legendWidth: null,
  uniqId: null,

  _brush: null,
  _clickedLegendRect: null,
  _currentYAxis: null,
  _defaultYAxis: null,
  // 그룹 레전 일 경우에 그룹명까지 포함된 데이터
  _groupLegend: null,
  _groupLegendWidth: null,
  _isCollapsed: null,
  _isValidData: null,
  _legendTextSize: null,
  _lineLeading: null,
  _main: null,
  _mainXAxis: null,
  _mainXScale: null,
  _mainYAxis: null,
  _mainYScale: null,
  _maxX: null,
  _maxY: null,
  _mini: null,
  _miniXScale: null,
  _minX: null,
  _minY: null,
  _mousedownOffsetX: null,
  _mouseupOffsetX: null,
  _onlyOne: null,
  _parentType: null,
  _postfixFrom: null,
  _postfixTo: null,
  _rect: null,
  _selectedLegendRect: null,
  _selectedLegendRectForNormal: null,
  _selectedLegendRectForYAxis: null,
  _selectedLegendSymbol: null,
  _symbolMulple: null,
  _tickAndFormat: null,
  _violateProperty: null,
  _zoom: null,
  _setting: null,
  _browserType: null,
  _defaultWidth: null,
  _defaultHeight: null,
  _ccSeries: null,

  _reload: Ember.computed.alias('reload').readOnly(),
  ////_height: Ember.computed.alias('height').readOnly(),
  _timelineData: Ember.computed.alias('timelineData').readOnly(),
  _trace: Ember.computed.alias('trace').readOnly(),
  _width: Ember.computed.alias('width').readOnly(),
  _height: Ember.computed('height', '_setting', function() {
    return this.get('height') - this.get('_settingPaddingBottom');
  }),
  _changedData: Ember.computed('actionMode', function() {
    if(Ember.isEmpty(this.get('actionMode'))) {
      return false;
    } else {
      return true;
    }
  }),
  _hasSeries: Ember.computed('_timelineData', function() {
    const zero = 0;
    let result = false;
    const data = this.get('_timelineData');

    if(!Ember.isEmpty(data) && data.series.length > zero) {
      result = true;
    }

    return result;
  }),
  _settingPaddingTop: Ember.computed('_setting', function() {
    return this.get('_setting').paddingTop;
  }),
  _settingPaddingRight: Ember.computed('_setting', function() {
    return this.get('_setting').paddingRight;
  }),
  _settingPaddingLeft: Ember.computed('_setting', function() {
    return this.get('_setting').paddingLeft;
  }),
  _settingPaddingBottom: Ember.computed('_setting', function() {
    return this.get('_setting').paddingBottom;
  }),
  _settingNormalOpacity: Ember.computed('_setting', function() {
    return this.get('_setting').normalOpacity;
  }),
  _settingDarkOpacity: Ember.computed('_setting', function() {
    return this.get('_setting').darkOpacity;
  }),
  _settingTransparentOpacity: Ember.computed('_setting', function() {
    return this.get('_setting').transparentOpacity;
  }),
  _settingGlyphiconPrefix: Ember.computed('_setting', function() {
    return this.get('_setting').glyphiconPrefix;
  }),

  onPropertyInit() {
    this._super(...arguments);
    this._logTrace('c-timeline-svg.onPropertyInit()');

    this.setStateProperties([ 'actionMode','addSeries','reload','height','removeSeriesNo',
      'timelineData','trace','width',

      '_brush','_clickedLegendRect','_currentYAxis',
      '_defaultYAxis','_groupLegend','_groupLegendWidth',
      '_isCollapsed','_isValidData','_lineLeading','_main',
      '_mainXAxis','_mainXScale','_mainYAxis','_mainYScale','_maxX',
      '_maxY','_mini', '_miniXScale','_minX',
      '_minY', '_mousedownOffsetX','_mouseupOffsetX', '_onlyOne','_parentType','_postfixFrom',
      '_postfixTo','_rect','_selectedLegendRect','_selectedLegendRectForNormal','_selectedLegendRectForYAxis','_selectedLegendSymbol',
      '_symbolMulple','_tickAndFormat','_violateProperty', '_ccSeries',
      '_zoom','_setting', '_browserType' ]);

    if (!this.hasState()) {
      this.set('reload', true);

      this.set('_clickedLegendRect', false);
      this.set('_groupLegendWidth', 150);
      this.set('_isCollapsed', true);
      this.set('_isValidData', true);
      this.set('_lineLeading', 10);
      this.set('_onlyOne', false);
      this.set('_parentType', 'timeline');
      this.set('_postfixFrom', 'From');
      this.set('_postfixTo', 'To');
      this.set('_selectedLegendRect', Ember.A());
      this.set('_selectedLegendRectForNormal', Ember.A());
      this.set('_selectedLegendRectForYAxis', Ember.A());
      this.set('_selectedLegendSymbol', Ember.A());
      this.set('_symbolMulple', 10);
      this.set('_setting', {
        paddingTop: 5,
        paddingRight: 30,
        paddingLeft: 160,
        paddingBottom: 30,
        normalOpacity: 1,
        darkOpacity: 0.9,
        transparentOpacity: 0.3,
        glyphiconPrefix: 'material-icons'
      });
      this.set('legendWidth', 140);
      this.set('_browserType', this._getBrowserType());
      this.set('_defaultWidth', 680);
      this.set('_defaultHeight', 144);
      this.set('uniqId', 'timeline-' + Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1));

      if (Ember.isEmpty(this.get('width'))) {

        // this.set('_width', 680);
      }
      // if (Ember.isEmpty(this.get('height'))) {
      //   this.set('_height', 144);
      // }

      const tickFormat = [];
      let item;

      item = {};
      item.type = 'year';
      item.ticks = d3.timeYear;
      item.tickFormat = d3.timeFormat('%Y');
      // 2017
      tickFormat.pushObject(item);

      item = {};
      item.type = 'month';
      item.ticks = d3.timeMonth;
      item.tickFormat = d3.timeFormat('%Y %b');
      // 2017 Jan
      tickFormat.pushObject(item);

      item = {};
      item.type = 'week';
      item.ticks = d3.timeWeek;
      item.tickFormat = d3.timeFormat('%y %b %e');
      // 17 Jan 9
      tickFormat.pushObject(item);

      item = {};
      item.type = 'day';
      item.ticks = d3.timeDay;
      item.tickFormat = d3.timeFormat('%b %e');
      // Jan 3
      tickFormat.pushObject(item);

      item = {};
      item.type = 'hour';
      item.ticks = d3.timeHour;
      item.tickFormat = d3.timeFormat('%e %p %I');
      // 7 PM 3
      tickFormat.pushObject(item);

      item = {};
      item.type = 'minute';
      item.ticks = d3.timeMinute;
      item.tickFormat = d3.timeFormat('%p %I');
      // PM 3
      tickFormat.pushObject(item);

      // [REF-URL]
      // https://github.com/d3/d3-3.x-api-reference/blob/master/Time-Scales.md
      // https://bl.ocks.org/zanarmstrong/ca0adb7e426c12c06a95
      // https://github.com/d3/d3-3.x-api-reference/blob/master/Time-Formatting.md
      this.set('_tickAndFormat', tickFormat);
    }
    // if(console.log('parent', this.$().parent());)
  },

  init() {
    this._super(...arguments);
    this._logTrace('fr-timeline-svg.init()');
  },

  didInsertElement() {
    this._super(...arguments);
    this._logTrace('fr-timeline-svg.didInsertElement()');

    this.$().css({
      width: this.get('width'),
      height: this.get('height')
    });

    this.set('_elementId', this.elementId);
    this.$('.scroll-area').css('height', this.get('height'));

    this._setMouseRightClick();
    this._renderChart();

  },

  didRender() {
    this._super(...arguments);
    //this._logTrace('fr-timeline-svg.didRender()');
    // 초기 상태

    this._initSeriesStyle();
  },

  didUpdateAttrs() {

    this._super(...arguments);
    this._logTrace('c-timeline-svg.didUpdateAttrs()');


    if(Ember.isEmpty(this.get('_timelineData')) === true) {
      return;
    }

    // 추가, 삭제된 데이터만 핸들링
    if(this.get('_changedData') === true) {
      const actionMode = this.get('actionMode');
      const newSeries = this.get('addSeries');
      const removeSeriesNo = this.get('removeSeriesNo');

      this._removeAxis();
      this.$('g[data-id=todayRoot]').remove();

      if(actionMode === 'add' && !Ember.isEmpty(newSeries)) {
        this._addToChartData(newSeries);
      }

      if(actionMode === 'remove' && !Ember.isEmpty(removeSeriesNo)) {
        this._applyRemovedData(removeSeriesNo);
        this._removeToChartDataByNo(removeSeriesNo);
      }
    }
    this.set('_ccSeries', null);
    this._copyChartData();

    this._renderChart();
  },

  willDestroyElement() {
    this._super(...arguments);
    this._logTrace('fr-timeline-svg.willDestroyElement()');

    // 이벤트 리스너 해제
    this._removeEventListener();
    this._removeDom();
    this.$('.scrollbar-macosx').scrollbar('destroy');

    // 클로저 해제
    this._convertDateFormat = null;
    this._setLegendOpacity = null;
    this._onlyOneChecked = null;
    this._setSeriesOpacity = null;
    this._showSeries = null;
    this._getD3Svg = null;
    this._logTrace = null;
    this._initSeriesStyle = null;
    this._copyChartData = null;
    this._setCurrentYAxis = null;
  },

  _copyChartData() {
    if(!Ember.isEmpty(this.get('_timelineData'))) {
      if(Ember.isEmpty(this.get('_ccSeries'))) {
        const temp = Ember.$.extend(true, [], this.get('_timelineData').series);

        this.set('_ccSeries', temp);
      }
    }
  },

  _removeEventListener() {
    const zoom = this.get('_zoom');
    const brush = this.get('_brush');
    const brushExtect = d3.selectAll('rect.extent');
    const rect = this.get('_rect');
    const svg = this._getD3Svg();
    const root = svg.select('g.main').select('g.timelineRoot');

    this.$().off('contextmenu');

    if(brush !== null) {
      brush.on('brush', null);
    }
    if(brushExtect !== null) {
      brushExtect.on('mouseover', null);
      brushExtect.on('mouseout', null);
    }
    if(rect !== null) {
      rect.on('dblclick.zoom', null);
      rect.on('mousedown', null);
      rect.on('mouseup', null);
    }
    if(zoom !== null) {
      zoom.on('zoom', null);
    }
    if(root !== null) {
      root.on('mousedown', null);
      root.on('mouseup', null);
    }
  },

  _removeDom() {
    const target = d3.selectAll(this.childNodes);
    target.remove();
  },

  _logTrace(text) {
    if(this.get('_trace') === true) {
      Ember.Logger.log(text);
    }
  },
  // svg 선택
  _getD3Svg() {
    return d3.select('#' + this.get('uniqId'));
  },

  _setMouseRightClick() {
    this.$().on('contextmenu', e => {
      this._logTrace('[contextmenu]');
      this._onContextMenu(e);
      e.preventDefault();
      e.stopPropagation();
    });
  },

  _applyRemovedData(no) {
    const zero = 0;
    const one = 1;
    //let data = this.get('timelineData');
    const selectedLegend = this.get('_selectedLegendRect');
    const selectedLegendForYAxis = this.get('_selectedLegendRectForYAxis');
    const selectedLegendSymbol = this.get('_selectedLegendSymbol');

    // 현재 1개 선택된 상태에서 그것을 삭제한 경우
    if(selectedLegend.length === one ) {
      if(selectedLegend[zero] === no) {
        this.set('_setNormalAll', true);
      }
    }

    if(selectedLegend.includes(no)) {
      for(let i=0; i < selectedLegend.length; i++) {
        if(selectedLegend[i] === no) {
          selectedLegend.removeObject(selectedLegend[i]);
        }
      }
    }

    if(selectedLegendSymbol.includes(no)) {
      for(let i=0; i < selectedLegendSymbol.length; i++) {
        if(selectedLegendSymbol[i] === no) {
          selectedLegendSymbol.removeObject(selectedLegendSymbol[i]);
        }
      }
    }

    if(selectedLegendForYAxis.includes(no)) {
      for(let i=0; i < selectedLegendForYAxis.length; i++) {
        if(selectedLegendForYAxis[i] === no) {
          selectedLegendForYAxis.removeObject(selectedLegendForYAxis[i]);
        }
      }
    }
  },

  _removeAxis() {
    const zero = 0;
    const el = this.$().get(zero);

    d3.select(el).selectAll('g[data-id=\'xAxisG\']').remove();
    d3.select(el).selectAll('g[data-id=\'yAxisG\']').remove();

    d3.select(el).selectAll('.main').remove();
    d3.select(el).selectAll('.mini').remove();
    d3.select(el).select('defs').remove();
    d3.select(el).select('rect.pane').remove();

    this.set('_mainXScale', null);
    this.set('_miniXScale', null);
    this.set('_mainYScale', null);
    this.set('_mainXAxis', null);
    this.set('_mainYAxis', null);
  },

  _initSeriesStyle() {
    const zero = 0;
    const timelineData = this.get('_timelineData');

    if(Ember.isEmpty(timelineData)) {
      return;
    }

    const allSeries = timelineData.series;
    const transparentOpacity = this.get('_settingTransparentOpacity');
    const normalOpacity = this.get('_settingNormalOpacity');
    const selectedLegendSymbol = this.get('_selectedLegendSymbol');
    const selectedLegendRect = this.get('_selectedLegendRect');
    const svg = this._getD3Svg();

    // 선택된 레전드 처리
    for(let i=0; i < allSeries.length; i++) {
      const seriesNo = allSeries[i].no;

      if(selectedLegendRect.includes(seriesNo)) {
        // 상태 변경된 아이템
        const legendLabel = svg.selectAll('.timeline.legendG.series' + seriesNo)
          .selectAll('.legendText');

        if(selectedLegendRect.includes(seriesNo)) {
          legendLabel.classed('selectedLegend', true);
        } else {
          legendLabel.classed('selectedLegend', false);
        }
      }
    }

    this._onlyOneChecked();

    if(this.get('_onlyOne') === true) {
      // 하나만 있다면, 그것을 제외한 모든 것을 투명하게 처리
      for(let i = 0; i < allSeries.length; i++) {
        const tempSeriesNo = allSeries[i].no;

        if(selectedLegendRect.includes(tempSeriesNo)) {
          this._setSeriesOpacity(tempSeriesNo, normalOpacity);
        } else {
          this._setSeriesOpacity(tempSeriesNo, transparentOpacity);
        }
      }
    } else {
      // 선택된 것이 하나도 없다면 모두 표시
      if(selectedLegendRect.length === zero) {
        for(let i = 0; i < allSeries.length; i++) {
          const tempSeriesNo = allSeries[i].no;

          this._setSeriesOpacity(tempSeriesNo, normalOpacity);
        }
      } else {
        for(let i = 0; i < allSeries.length; i++) {
          const tempSeriesNo = allSeries[i].no;

          if(selectedLegendRect.includes(tempSeriesNo)) {
            this._setSeriesOpacity(tempSeriesNo, normalOpacity);
          } else {
            this._setSeriesOpacity(tempSeriesNo, transparentOpacity);
          }
        }
      }
    }

    // 선택된 심볼 처리
    for(let i=0; i < allSeries.length; i++) {
      const seriesNo = allSeries[i].no;

      if(selectedLegendSymbol.includes(seriesNo)) {
        this._showSeries(seriesNo, false);
        this.$('.timeline.legendSymbol.series' + seriesNo).parent().css('opacity', transparentOpacity);
      } else {
        this._showSeries(seriesNo, true);
        this.$('.timeline.legendSymbol.series' + seriesNo).parent().css('opacity', normalOpacity);
      }
    }
  },

  _onContextMenu(e) {
    this._raiseEvents('onMouseRightClick', e);
  },

  _resetZoomBrush() {
    const svg = this._getD3Svg();
    const brush = this.get('_brush');
    const width = this.get('_width') - this.get('_settingPaddingRight');
    const mainXScale = this.get('_mainXScale');
    const leftX = mainXScale.invert(this.get('_settingPaddingLeft'));
    const rightX = mainXScale.invert(width);

    svg.select('.brush').call(brush.move, [leftX, rightX].map(mainXScale));
  },

  _hasProperty(obj, propertyName) {
    let result = true;
    let prop = '';

    for( let i=0; i < propertyName.length; i++) {
      if( !obj.hasOwnProperty([propertyName[i]]) ) {
        prop = propertyName[i];
        result = false;
        break;
      }
    }

    return { result: result, message: prop };
  },

  _isValidate() {
    let result = true;
    const data = this.get('timelineData');

    this.set('_violateProperty', '');

    try {
      const rootPropertyName = ['xAxisOrient', 'yAxisOrient', 'tooltipSize', 'isSortedData', 'isTimeXAxis',
        'isGroupLegend', 'isCollapsibleLegend', 'isCustomYAxis', 'series'];
      const temp = this._hasProperty(data, rootPropertyName);

      if( temp.result === false) {
        this.set('_violateProperty', this.get('_violateProperty') + '\n root property -> ' + temp.message);
      }

      const xAxisOrientDomain = ['bottom'];
      const yAxisOrientDomain = ['left'];

      if(xAxisOrientDomain.includes(data.xAxisOrient) === false) {
        this.set('_violateProperty', this.get('_violateProperty') + '\n xAxisOrient -> not valid value');
      }

      if(yAxisOrientDomain.includes(data.yAxisOrient) === false) {
        this.set('_violateProperty', this.get('_violateProperty') + '\n yAxisOrient -> not valid value');
      }

      if(Number.isInteger(data.tooltipSize) === false) {
        this.set('_violateProperty', this.get('_violateProperty') + '\n tooltipSize -> must number value');
      }

      if(typeof data.isSortedData !== 'boolean') {
        this.set('_violateProperty', this.get('_violateProperty') + '\n isSortedData -> must boolean value');
      }

      if(typeof data.isTimeXAxis !== 'boolean') {
        this.set('_violateProperty', this.get('_violateProperty') + '\n isTimeXAxis -> must boolean value');
      }

      if(typeof data.isGroupLegend !== 'boolean') {
        this.set('_violateProperty', this.get('_violateProperty') + '\n isGroupLegend -> must boolean value');
      }

      if(typeof data.isCollapsibleLegend !== 'boolean') {
        this.set('_violateProperty', this.get('_violateProperty') + '\n isCollapsibleLegend -> must boolean value');
      }

      if(typeof data.isCustomYAxis !== 'boolean') {
        this.set('_violateProperty', this.get('_violateProperty') + '\n isCustomYAxis -> must boolean value');
      }

      if(Ember.isEmpty(data.collapsibleLegendWidth) === false) {
        if(Number.isInteger(data.collapsibleLegendWidth) === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n collapsibleLegendWidth -> must number value');
        }
      }

      if(Ember.isEmpty(data.isGroupLegend) === false) {
        if(data.isGroupLegend === true && Ember.isEmpty(data.groupLegend) === true) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n groupLegend -> must set groupLegend with isGroupLegend');
        }
      }

      const seriesPropertyName = ['no', 'name', 'config', 'data'];
      const seriesConfigPropertyName = ['type', 'xAxisProperty', 'yAxisProperty', 'tooltipProperty', 'isSelectSymbol',
        'isSelectLegend'];
      const seriesTypeDomain = ['fromTo', 'point'];

      for(let i = 0; i < data.series.length; i++) {
        const series = data.series[i];
        let innerTemp = this._hasProperty(series, seriesPropertyName);

        if( innerTemp.result === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[] property -> ' + innerTemp.message);
        }

        if(Ember.isEmpty(series.name) === true) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].name -> is empty');
        }
        if(Ember.isEmpty(series.config) === true) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config -> is empty');
        }

        innerTemp = '';
        innerTemp = this._hasProperty(series.config, seriesConfigPropertyName);

        if( innerTemp.result === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config property -> ' + innerTemp.message);
        }

        const type = series.config.type;

        if(seriesTypeDomain.includes(type) === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config.type -> value domain');
        }

        if(Ember.isEmpty(series.config.strokeWidth) === false && Number.isInteger(series.config.strokeWidth) === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config.strokeWidth -> must number value');
        }

        if(Ember.isEmpty(series.config.symbolSize) === false && Number.isInteger(series.config.symbolSize) === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config.symbolSize -> must number value');
        }

        if(Ember.isEmpty(series.config.groupLegendNo) === false && Number.isInteger(series.config.groupLegendNo) === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config.groupLegendNo -> must number value');
        }

        if(Ember.isEmpty(series.config.isCustomYAxis) === false && typeof series.config.isCustomYAxis !== 'boolean') {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config.isCustomYAxis -> must boolean value');
        }

        if(typeof series.config.isSelectSymbol !== 'boolean') {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config.isSelectSymbol -> must boolean value');
        }

        if(typeof series.config.isSelectLegend !== 'boolean') {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config.isSelectLegendtype -> must boolean value');
        }

        if(Ember.isEmpty(series.config.groupLegendNo) === false && series.config.symbolType.startsWith('material-icons-') === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[].config.symbolType -> must specific prefix name');
        }

        let seriesTypePropertyName = [];

        if(series.config.type === 'point') {
          seriesTypePropertyName = ['symbolColor', 'symbolSize', 'symbolType'];
        } else if(series.config.type === 'fromTo') {
          seriesTypePropertyName = ['symbolColor', 'symbolSize'];
        }

        innerTemp = null;
        innerTemp = this._hasProperty(series.config, seriesTypePropertyName);

        if( innerTemp.result === false) {
          this.set('_violateProperty', this.get('_violateProperty') + '\n series[] property -> ' + innerTemp.message);
        }
      }

      if(Ember.isEmpty(this.get('_violateProperty')) === false) {
        result = false;
      }
    } catch(e) {
      result = false;
      // [i18N]
      this._logTrace('chart 데이터를 확인하는 과정에서 에러가 발생하였습니다. ' + e.message);
    }

    return result;
  },

  _renderChart() {

    if(Ember.isEmpty(this.get('_timelineData'))) {
      return;
    }
    this._removeDom();
    // width 값이 %일 경우 넓이 동적 할당
    if (~this.get('width').indexOf('%') || Ember.isEmpty(this.get('width'))) {
      this.set('width', $(this.element).width());
    }
    const data = this.get('_timelineData');
    if (!Ember.isEmpty(data)) {
      if (data.isCollapseLegendPane) {
        this.set('legendWidth', this.get('_settingPaddingRight') - 10);
      } else {
        this.set('legendWidth', data.collapsibleLegendWidth);
      }
    }

    if(this._isValidate() === false) {
      const failMessage = '[timelineData is not valid] ' + this.get('_violateProperty');

      // [i18N]
      this._logTrace(failMessage);
      this._raiseEvents('onValidateFail', failMessage);
      this.set('_isValidData', false);

      return;
    }

    // 조건을 고려한 변수 초기화
    this._setProperties();
    this._createDefs();
    this._setScale();
    this._setAxis();
    this._setBrush();
    // this._setMouseRightDrag();
    // this._setZoomPeriod();
    // callback 에서 _setCustomYAxis()
    this._setNowBar();
  },

  _setProperties() {
    const timelineData = this.get('_timelineData');
    const isCollapsibleLegend = timelineData.isCollapsibleLegend;
    const legend = this.$().find('.timeline-legend');

    if(isCollapsibleLegend === true) {
      if (!legend.hasClass('collapse')) {
        legend.addClass('collapse');
        legend.css('width', timelineData.collapsibleLegendWidth);
      }

      this.get('_setting').paddingLeft = 80;
      this.set('_groupLegendWidth', parseInt(timelineData.collapsibleLegendWidth));
      this.set('_isCollapsed', timelineData.isCollapseLegendPane);
    } else {
      if (legend.hasClass('collapse')) {
        legend.removeClass('collapse');
        legend.css('width', 'auto');
      }
      this.get('_setting').paddingLeft = 160;
    }

    for(let i=0; i < timelineData.series.length; i++) {
      const current = timelineData.series[i];

      if(current.config.isSelectSymbol === true) {
        this.get('_selectedLegendSymbol').pushObject(current.no);
      }

      if(current.config.isSelectLegend === true) {
        this.get('_selectedLegendRect').pushObject(current.no);
      }
    }

    this._setXAxisTickFormat();
  },

  _setXAxisTickFormat() {
    if(Ember.isEmpty(this.get('_timelineData').timeFormat)) {
      return;
    }

    if(Ember.isEmpty(this.get('_timelineData').timeFormat.xAxisTickFormat)) {
      return;
    }

    const result = [];
    const xAxisTickFormat = this.get('_timelineData').timeFormat.xAxisTickFormat;

    for(let i=0; i < xAxisTickFormat.length; i++) {
      const item = {};

      item.type = xAxisTickFormat[i].type;
      item.tickFormat = d3.timeFormat(xAxisTickFormat[i].format);

      if(xAxisTickFormat[i].type === 'year') {
        item.ticks = d3.timeYear;
      } else if(xAxisTickFormat[i].type === 'month') {
        item.ticks = d3.timeMonth;
      } else if(xAxisTickFormat[i].type === 'week') {
        item.ticks = d3.timeWeek;
      } else if(xAxisTickFormat[i].type === 'day') {
        item.ticks = d3.timeDay;
      } else if(xAxisTickFormat[i].type === 'hour') {
        item.ticks = d3.timeHour;
      } else if(xAxisTickFormat[i].type === 'minutes') {
        item.ticks = d3.timeMinutes;
      } else {
        item.ticks = d3.timeDay;
      }

      result.pushObject(item);
    }

    this.set('_tickAndFormat', result);
  },

  _createDefs() {
    const svg = this._getD3Svg();

    const width = Number(this.get('_width')) - this.get('_settingPaddingLeft') - this.get('_settingPaddingRight');
    const height = Number(this.get('_height'));

    svg.append('defs')
      .append('clipPath')
      .attr('id', this.get('_elementId') + 'clip')
      .append('rect')
      .attr('width', width)
      .attr('height', height);
  },

  _setMainMini() {

    const svg = this._getD3Svg();
    const main = svg.append('g').attr('class', 'main');
    const mini = svg.append('g').attr('class', 'mini');

    this.set('_main', main);
    this.set('_mini', mini);
  },

  _convertDateString(date, format) {
    return this.get('fr_I18nService').formatDate(date, format);
  },

  _resetPeriodLabel(extent) {
    const zero = 0;
    const one = 1;
    const hundred = 100;
    // timelineRoot 아래 자식 추가
    const svg = this._getD3Svg();
    const timelineRoot = svg.select('g.main');

    timelineRoot.selectAll('text[data-id=startDate]').remove();
    timelineRoot.selectAll('text[data-id=endDate]').remove();

    const gLabel = svg.select('g.main').select('g.timelineRoot');
    const startX = 10;
    const endX = this.get('_width') - this.get('_settingPaddingLeft') - hundred;
    const y = 15;
    const dateFormat = 'd';
    const startDate = this._convertDateString(extent[zero], dateFormat);
    const endDate = this._convertDateString(extent[one], dateFormat);

    gLabel.append('text')
      .attr('data-id', 'startDate')
      .attr('class', 'startDate')
      .attr('transform', function() {
        const x = startX;

        return 'translate(' + x + ', ' + y + ')';
      })
      .text(startDate);

    gLabel.append('text')
      .attr('data-id', 'startDate')
      .attr('class', 'endDate')
      .attr('transform', function() {
        const x = endX;

        return 'translate(' + x + ', ' + y + ')';
      })
      .text(endDate);
  },

  // Zoom 기본값 설정
  // _setZoomPeriod() {
  //   const zero = 0;
  //   const one = 1;
  //   const customPeriod = this.get('_timelineData').period;

  //   if(!Ember.isEmpty(customPeriod)) {
  //     brushExtent = [customPeriod[zero], customPeriod[one]];
  //   }
  // },

  _brushListener({range, mainXScale, miniXScale}) {
    if(Ember.isEmpty(this.get('_brush'))){
      return;
    }
    const zero = 0;
    const one = 1;

    const svg = this._getD3Svg();
    const mainXAxis = this.get('_mainXAxis');
    const brush = this.get('_brush');

    var s = d3.event.selection;
    if (s !== null) {
      mainXScale.domain(s.map(miniXScale.invert, miniXScale));
    }

    this.set('_mainXScale', mainXScale);

    const mainDomain = mainXScale.domain();
    // const miniDomain = miniXScale.domain();
    // getTime() 계산과 동일
    const intervalType = this._getIntervalType(mainDomain[zero], mainDomain[one]);
    // [ year, month, week, day, hour, minute]
    const tickItem = this._getTickAndFormat(intervalType);

    mainXAxis.ticks(tickItem.ticks)
      .tickFormat(tickItem.tickFormat);


    svg.select('g[data-id=xAxisG]').call(mainXAxis);

    this.set('_mainXAxis', mainXAxis);

    this._resetNowBar();

    // 자식 시리즈 다시 그리게
    this.set('reload', !this.get('_reload'));

    // 호출자에 기간 변경 콜백
    if(range) {
      this._raiseEvents('onPeriodChange', {start: range[0], end: range[1]});
    }

    // 현재 표시하는 데이터의 시작점과 끝점
    this._resetPeriodLabel(brush.extent());

    // 현재 범위 저장
    this.get('_timelineData').period = brush.extent();

    if(Ember.isEmpty(d3.event.sourceEvent)) {
      //
    } else if(Ember.isEmpty(d3.event.sourceEvent.sourceEvent)) {
      //
    } else {
      d3.event.sourceEvent.sourceEvent.cancelBubble = true;
    }
  },

  _getOffsetX(e) {
    const target = e.target || e.srcElement;
    const rect = target.getBoundingClientRect();
    let offsetX;

    if( e.clientX === Math.round(rect.left)) {
      offsetX = e.clientX - rect.right;
    } else {
      offsetX = e.clientX - rect.left;
    }

    return offsetX;
  },

  _getBrowserType() {
    const browserName = this.get('fr_GlobalSystemService').browserName;

    return browserName.toLowerCase();
  },

  _zoomListener({type}) {
    const two = 2;
    let eventType = null;
    let button = null;

    if(Ember.isEmpty(d3.event.sourceEvent)) {
      // dblclick
      eventType = d3.event.type;
      button = d3.event.button;
      // currentX = d3.event.offsetX;
    } else {
      eventType = d3.event.sourceEvent.type;
      button = d3.event.sourceEvent.button;
      // currentX = d3.event.sourceEvent.offsetX;
    }

    if(eventType === 'mouseup' && type === 'move' && button === two) {
      let tempStartX = this.get('_mouseupOffsetX');
      let tempEndX = this.get('_mousedownOffsetX');
      const browserType = this.get('_browserType');

      if(browserType === 'edge' || browserType === 'firefox') {
        tempStartX += this.get('_settingPaddingLeft');
        tempEndX += this.get('_settingPaddingLeft');
      }

      // 각 브라우저의 rect 위치 조정
      this._setDraggingRect(tempStartX, tempEndX);
    }

    if(eventType === 'mousemove' && button === two) {
      return;
    }

    if(eventType === 'brush') {
      return;
    }

    const svg = this._getD3Svg();
    const mainXScale = this.get('_mainXScale');
    const miniXScale = this.get('_miniXScale');
    const brush = this.get('_brush');

    if(d3.event.transform != null){
      var t = d3.event.transform;
      mainXScale.domain(t.rescaleX(miniXScale).domain());
      svg.select('.brush').call(brush.move, miniXScale.range().map(t.invertX, t));
    }
    svg.select('.brush').call(brush.move, [
      mainXScale.invert(this.get('_mousedownOffsetX')),
      mainXScale.invert(this.get('_mouseupOffsetX'))
    ].map(mainXScale));
  },

  _dblclickListener() {
    this._logTrace('[_dblclickListener]');
    this._zoomListener({type: 'dblclick'});
  },

  _allowValueDomain(beforeValue, afterValue) {
    const error = 2;
    const allowMin = afterValue - error;
    const allowMax = afterValue + error;

    if(allowMin <= beforeValue && beforeValue <= allowMax) {
      return true;
    }

    return false;
  },

  _setBrush() {
    const zero = 0;
    const one = 1;
    const two = 2;
    const svg = this._getD3Svg();
    const width = this.get('_width') - this.get('_settingPaddingLeft') - this.get('_settingPaddingRight');
    const height = this.get('_height') - this.get('_settingPaddingTop');
    const mainXScale = this.get('_mainXScale');
    const miniXScale = this.get('_miniXScale');

    const brush = d3.brushX()
      .extent([
        [this.get('_settingPaddingLeft'), Number(this.get('_height'))],
        [Number(this.get('_width')) - this.get('_settingPaddingRight'), Number(this.get('_height')) + 26]
      ])
      .on('brush', brushed)
      .handleSize(this.get('_settingPaddingBottom') - 6);

    // brush.on('brush', brushed);

    const setBrush = (range) => {
      this._brushListener({
        brush: brush,
        range: range,
        mainXScale: mainXScale,
        miniXScale: miniXScale
      });
    };

    function brushed() {
      const range = d3.brushSelection(this);
      setBrush(range);
    }

    const zoom = d3.zoom()
      .scaleExtent([1, Infinity])
      .translateExtent([[this.get('_settingPaddingLeft'), parseInt(this.get('_height'))], [parseInt(this.get('_width')), parseInt(this.get('_height'))]])
      .extent([
        [this.get('_settingPaddingLeft'), parseInt(this.get('_height'))],
        [parseInt(this.get('_width')), parseInt(this.get('_height'))]
      ]);

    const rect = svg.append('svg:rect')
      .attr('class', 'pane')
      .attr('width', width)
      .attr('height', height)
      .attr('transform', `translate(${this.get('_settingPaddingLeft')}, ${this.get('_settingPaddingTop')})`)
      .call(zoom)
      .on('dblclick.zoom', () => {
        this._dblclickListener();
        d3.event.stopPropagation();
      })
      .on('mousedown', () => {
        this._logTrace('[rect.mousedown]');
        const button = d3.event.button;

        if(button === two) {
          this.set('_mousedownOffsetX', d3.event.offsetX);
          this._logTrace('[rect.mousedown] d3.event.offsetX = ' + this.get('_mousedownOffsetX'));
        }
      })
      .on('mouseup', () => {
        this._logTrace('[rect.mouseup]');
        const button = d3.event.button;

        this.set('_mouseupOffsetX', d3.event.offsetX);
        this._logTrace('[rect.mouseup] d3.event.offsetX = ' + this.get('_mouseupOffsetX'));

        if(button === two) {
          if(this._allowValueDomain(this.get('_mousedownOffsetX'), this.get('_mouseupOffsetX'))) {
            // 이동하지 않음. => zoom 리셋, context 실행
            this._resetZoomBrush();
            d3.event.preventDefault();
          } else {
            // 값 비교하여 전후 관계 조정
            if(this.get('_mousedownOffsetX') > this.get('_mouseupOffsetX')) {
              const temp = this.get('_mouseupOffsetX');

              this.set('_mouseupOffsetX', this.get('_mousedownOffsetX'));
              this.set('_mousedownOffsetX', temp);
            }
            this._zoomListener({type: 'move'});
          }

          const delay = 200;

          // 보완하고자 여기에서도 호출
          this._removeDraggingRect(delay);
        }
      });

      // tag order [defs - rect - main - mini - today - legend]

    this._setMainMini();

    zoom.on('zoom', () => {
      this._zoomListener({type: 'zoom'});
    });

    const main = this.get('_main');
    const mini = this.get('_mini');

    const gBrush = mini.append('g')
      .attr('class', 'x brush')
      .call(brush)
      .call(brush.move, miniXScale.range())
      .selectAll('rect')
      .attr('y', this.get('_height'))
      .attr('rx', 3)
      .attr('ry', 3)
      .attr('height', this.get('_settingPaddingBottom') - 6)
      .attr('transform', 'translate(0, 3)');

    mini.append('g')
      .attr('class', 'timeline timelineDrag')
      .attr('clip-path', 'url(#' + this.get('_elementId') + 'clip)')
      .attr('transform', 'translate(' + zero + ',' + zero + ')');

    main.append('g')
      .attr('data-id', 'xAxisG')
      .attr('class', 'x axis')
      .attr('transform', `translate(${this.get('_settingPaddingLeft')}, ${this.get('_settingPaddingTop')})`)
      .call(this.get('_mainXAxis'));

    main.append('g')
      .attr('data-id', 'yAxisG')
      .attr('class', 'y axis')
      .attr('transform', `translate(${this.get('_width') - this.get('_settingPaddingRight')}, 0)`)
      .call(this.get('_mainYAxis'));

    main.append('g')
      .attr('class', 'timeline timelineRoot')
      .attr('clip-path', 'url(#' + this.get('_elementId') + 'clip)')
      .attr('transform', `translate(${this.get('_settingPaddingLeft')}, 0)`);

    gBrush.selectAll('.handle-custom')
      .data([{type: 'w'}, {type: 'e'}])
      .enter()
      .append('svg:foreignObject')
      .attr('class', 'handle-custom')
      .append('xhtml:i')
      .attr('class', 'timeline legendRootGImage material-icons md-20')
      .style('color', '#000000')
      .text('chevron_left');

    this.set('_zoom', zoom);
    this.set('_brush', brush);
    this.set('_rect', rect);

    // 마우스 오버 효과
    const dateFormat = this.get('_timelineData').timeFormat.dataFormat;
    const p = this.$().parent();

    if(p.children('div.chartTooltipTemplate').length === zero) {
      p.append('<div class=\'chartTooltipTemplate\'></div>');
    }

    const toolTip = d3.select(p[zero]).selectAll('div.chartTooltipTemplate');

    d3.selectAll('rect.extent')
      .on('mouseover', () => {
        const extent = brush.extent();
        const startDate = this._convertDateString(extent[zero], dateFormat);
        const endDate = this._convertDateString(extent[one], dateFormat);
        const adjustTemp = 10;

        const x = d3.event.x + adjustTemp;
        const y = d3.event.y + adjustTemp;

        toolTip.style('left', x + 'px');
        toolTip.style('top', y + 'px');
        toolTip.style('display', 'inline-block');

        const val = startDate + ' ~ ' + endDate;

        toolTip.html(val);
      })
      .on('mouseout', function() {
        toolTip.style('display', 'none');
        d3.event.stopPropagation();
      });
  },

  // _setMouseRightDrag() {
  //   const two = 2;
  //   const svg = this._getD3Svg();

  //   svg.select('g.main')
  //     .select('g.timelineRoot')
  //     .on('mousedown', () => {
  //       this._logTrace('[timelineRoot.mousedown]');
  //       const button = d3.event.button;

  //       if(button === two) {
  //         this.set('_mousedownOffsetX', d3.event.offsetX);
  //         this._logTrace('[timelineRoot.mousedown] d3.event.offsetX = ' + this.get('_mousedownOffsetX'));
  //       }
  //     })
  //     .on('mouseup', () => {
  //       this._logTrace('[timelineRoot.mouseup]');
  //       const button = d3.event.button;

  //       this.set('_mouseupOffsetX', d3.event.offsetX);
  //       this._logTrace('[timelineRoot.mouseup] d3.event.offsetX = ' + this.get('_mouseupOffsetX'));

  //       //// [CAUTION]
  //       const moveSize = this._getOffsetX(d3.event);

  //       this._logTrace('[chartRoot.mouseup] moveSize = ' + moveSize);
  //       this.set('_mouseupOffsetX', this.get('_mousedownOffsetX') + moveSize);

  //       if(button === two) {
  //         if(this._allowValueDomain(this.get('_mousedownOffsetX'), this.get('_mouseupOffsetX'))) {
  //           // 이동하지 않음. => zoom 리셋, context 실행
  //           this._resetZoomBrush();
  //           d3.event.preventDefault();
  //         } else {
  //           // 값 비교하여 전후 관계 조정
  //           if(this.get('_mousedownOffsetX') > this.get('_mouseupOffsetX')) {
  //             const temp = this.get('_mouseupOffsetX');

  //             this.set('_mouseupOffsetX', this.get('_mousedownOffsetX'));
  //             this.set('_mousedownOffsetX', temp);
  //           }

  //           this._zoomListener({type: 'move'});
  //         }

  //         const delay = 200;

  //         this._removeDraggingRect(delay);
  //       }
  //     });
  // },

  _reRenderChart() {
    this._removeAxis();
    this.$('g[data-id=todayRoot]').remove();
    this._renderChart();
  },
  _setSelectionContext(offsetX) {
    const xPoint = offsetX - this.get('_settingPaddingLeft');
    const svg = this._getD3Svg();

    const gVerticalBar = svg.select('g.main')
      .select('g.timelineRoot')
      .append('g')
      .attr('class', 'timeline selectionContext')
      .attr('data-id', 'selectionContext');

    gVerticalBar.append('line')
      .attr('x1', xPoint)
      .attr('y1', 0)
      .attr('x2', xPoint)
      .attr('y2', this.get('_height'))
      .attr('class', 'selectionContext');
  },

  _setDraggingRect(startX, endX) {
    const zero = 0;

    if( startX === endX) {
      return;
    }

    const paddingLeft = this.get('_settingPaddingLeft');
    const transparentOpacity = 0.2;

    this._removeDraggingRect(zero);

    const svg = this._getD3Svg();
    const timelineRoot = svg.select('g.main')
      .select('g.timelineRoot');

    timelineRoot.append('rect')
      .attr('class', 'timeline draggingRect')
      .attr('data-id', 'draggingRect')
      .style('opacity', transparentOpacity)
      .attr('x', function() {
        let result = startX;

        if( startX > endX) {
          result = endX;
        }

        result = result - paddingLeft;

        return result;
      })
      .attr('y', zero)
      .attr('width', function() {
        const width = Math.abs(endX - startX);

        return width;
      })
      .attr('height', this.get('_height'));
  },

  _removeDraggingRect(duration) {
    const zero = 0;
    const svg = this._getD3Svg();
    const timelineRoot = svg.select('g.main')
      .select('g.timelineRoot');

    if(duration === zero) {
      timelineRoot.selectAll('rect[data-id=draggingRect').remove();
    } else {
      timelineRoot.selectAll('rect[data-id=draggingRect').transition().duration(duration).remove();
    }
  },

  _removeSelectionContext(duration) {
    const zero = 0;

    if(duration === zero) {
      d3.selectAll('g[data-id=selectionContext]')
        .remove();
    } else {
      d3.selectAll('g[data-id=selectionContext]')
        .transition()
        .duration(duration)
        .remove();
    }
  },

  _resetNowBar() {
    this.$('g[data-id=todayRoot]').remove();
    this._setNowBar();

    const parentObj = this.$('.timeline-legend').children('svg');
    const childObj = this.$('g[data-id=\'legendRoot\']');
    // legendRoot 를 svg 마지막 자식으로
    this._moveToLast(parentObj, childObj);
  },

  _convertDateFormat(date) {
    if(date instanceof Date && date.valueOf() && !Number.isNaN(date.valueOf())) {
      return date;
    } else {
      return new Date(date);
    }
  },

  _setScale() {
    const zero = 0;
    const one = 1;
    const series = Ember.copy(this.get('_timelineData').series, false);

    let maxX = null;
    let minX = null;
    let maxY = null;
    let minY = null;
    const postfixFrom = this.get('_postfixFrom');
    const postfixTo = this.get('_postfixTo');

    series.forEach((item) => {

      const type = item.config.type;
      let currentMaxX, currentMaxY;
      let currentMinX, currentMinY;

      if(type === 'point') {
        currentMaxX = d3.max(item.data, d => {
          return this._convertDateFormat(d[item.config.xAxisProperty]);
        });
        currentMinX = d3.min(item.data, d => {
          return this._convertDateFormat(d[item.config.xAxisProperty]);
        });

        currentMaxY = d3.max(item.data, function(d) {
          return d[item.config.yAxisProperty];
        });
        currentMinY = d3.min(item.data, function(d) {
          return d[item.config.yAxisProperty];
        });
      } else if(type === 'fromTo') {
        const fromMax = d3.max(item.data, d => {
          return this._convertDateFormat(d[item.config.xAxisProperty + postfixFrom]);
        });
        const fromMin = d3.min(item.data, d => {
          return this._convertDateFormat(d[item.config.xAxisProperty + postfixFrom]);
        });

        const toMax = d3.max(item.data, d => {
          return this._convertDateFormat(d[item.config.xAxisProperty + postfixTo]);
        });
        const toMin = d3.min(item.data, d => {
          return this._convertDateFormat(d[item.config.xAxisProperty + postfixTo]);
        });

        currentMaxX = fromMax;
        currentMinX = fromMin;

        if(currentMaxX < toMax) {
          currentMaxX = toMax;
        }

        if(currentMinX > toMin) {
          currentMinX = toMin;
        }

        currentMaxY = d3.max(item.data, function(d) {
          return d[item.config.yAxisProperty];
        });
        currentMinY = d3.min(item.data, function(d) {
          return d[item.config.yAxisProperty];
        });
      } else {
        throw new Error('_setScale -> 지원하지 않는 timeline type');
      }

      if(maxX === null) {
        maxX = currentMaxX;
      } else {
        if(currentMaxX > maxX) {
          maxX = currentMaxX;
        }
      }

      if(minX === null) {
        minX = currentMinX;
      } else {
        if(currentMinX < minX) {
          minX = currentMinX;
        }
      }

      if(maxY === null) {
        maxY = currentMaxY;
      } else {
        if(currentMaxY > maxY) {
          maxY = currentMaxY;
        }
      }

      if(minY === null) {
        minY = currentMinY;
      } else {
        if(currentMinY < minY) {
          minY = currentMinY;
        }
      }
    });

    // 범위 지정 있다면 사용
    if(!Ember.isEmpty(this.get('_timelineData').timeDomain)) {
      minX = this._convertDateFormat(this.get('_timelineData').timeDomain[zero]);
      maxX = this._convertDateFormat(this.get('_timelineData').timeDomain[one]);
    }

    // 축에 데이터 여백 추가
    const yDataPadding = 1;

    this.set('_mainXScale',
      d3.scaleTime()
        .domain([minX, maxX])
        .range([0, this.get('_width') - this.get('_settingPaddingLeft') - this.get('_settingPaddingRight')])
    );

    this.set('_miniXScale',
      d3.scaleTime()
        .domain([minX, maxX])
        .range([this.get('_settingPaddingLeft'), this.get('_width') - this.get('_settingPaddingRight')])
    );
    this.set('_mainYScale',
      d3.scaleLinear()
        .domain([minY - yDataPadding, maxY + yDataPadding])
        .range([this.get('_height'), this.get('_settingPaddingTop')]));

    this.set('_minX', minX);
    this.set('_maxX', maxX);
    this.set('_minY', minY);
    this.set('_maxY', maxY);
  },

  _setAxis() {
    // 축 라벨 텍스트와 축 간격
    const tickPadding = 10;
    const seriesCount = this.get('_timelineData').series.length;
    const group = this.get('_timelineData').groupLegend;
    const intervalType = this._getIntervalType(this.get('_minX'), this.get('_maxX'));
    const tickItem = this._getTickAndFormat(intervalType);

    const mainXAxis = d3.axisBottom(this.get('_mainXScale'))
      .ticks(tickItem.ticks)
      .tickFormat(tickItem.tickFormat)
      .tickSize(this.get('_height') - this.get('_settingPaddingTop'))
      .tickPadding(tickPadding);
    let mainYAxis;
    if(group && group.length) {
      mainYAxis = d3.axisLeft(this.get('_mainYScale'))
        .ticks(group.length + 2)
        // legend 영역 고려
        .tickSize(this.get('_width') - this.get('_settingPaddingLeft') - this.get('_settingPaddingRight'))
        .tickPadding(tickPadding);
    } else {
      mainYAxis = d3.axisLeft(this.get('_mainYScale'))
        .ticks(seriesCount + 1)
        // legend 영역 고려
        .tickSize(this.get('_width') - this.get('_settingPaddingLeft') - this.get('_settingPaddingRight'))
        .tickPadding(tickPadding);
    }

    this.set('_mainXAxis', mainXAxis);
    this.set('_mainYAxis', mainYAxis);
  },

  _replaceSeriesName() {
    const data = this.get('_timelineData');
    const arrG = this.$().find('.c-timeline-svg').children('.main').children('g[data-id=yAxisG]').children('g');
    let arrNm = null;
    const group = data.groupLegend;
    if(group && group.length) {
      arrNm = group;
    } else {
      arrNm = data.series
    }

    let name = '';

    for(let i=0; i < arrG.length; i++) {
      name = '';
      const seq = this.$(arrG[i]).children('text').text();
      for (const item of arrNm) {
        if(Number(seq) === item.no) {
          name = item.name;
          this.$(arrG[i]).children('text').text(name);

          break;
        }
      }
      if(name === '') {
        // 같은 이름이 없다면 공백으로 표시
        this.$(arrG[i]).children('text').text('');
      }
    }
  },

  _setCustomYAxis() {
    const isCustomYAxis = this.get('_timelineData').isCustomYAxis;

    if(isCustomYAxis === true) {
      const result = Ember.A();
      const arrG = this.$().children('.main').children('g[data-id=yAxisG]').children('g');

      for(let i=0; i < arrG.length; i++) {
        result.pushObject(this.$(arrG[i]).children('text').text());
      }

      this.set('_defaultYAxis', result);
    }
  },

  _setNowBar() {
    const isShowNowBar = this.get('_timelineData').isShowNowBar;

    if(isShowNowBar === true) {
      const now = this.get('co_CommonService').getNow();
      const xScaleFunction = this.get('_mainXScale');

      const xPoint = xScaleFunction(now);
      const svg = this._getD3Svg();
      const gTodayRoot = svg.select('g.main')
        .select('g.timelineRoot')
        .append('g')
        .attr('class', 'timeline todayRoot')
        .attr('data-id', 'todayRoot');

      gTodayRoot.append('line')
        .attr('x1', xPoint)
        .attr('y1', 0)
        .attr('x2', xPoint)
        .attr('y2', this.get('_height'))
        .attr('class', 'nowBar');

      gTodayRoot.append('svg:foreignObject')
        .html('<div class="now-bar-rect">Today</div>')
        .attr('x', xPoint)
        .attr('y', 0)
        .attr('width', 60)
        .attr('height', 20);
    }
  },

  _getIntervalType(min, max) {
    const thousand = 1000;
    const minutesPerHour = 60;
    const hourPerDay = 24;
    let result = 'month';
    const diff = max - min;
    const millisecondsPerDay = thousand * minutesPerHour * minutesPerHour * hourPerDay;
    const days = diff / millisecondsPerDay;

    // year, month, week, day, hour, minute
    if(days <= 0.2) {
      result = 'minute';
    } else if(days <= 2.5) {
      result = 'hour';
    } else if(days <= 32) {
      result = 'day';
    } else if(days <= 130) {
      result = 'week';
    } else if(days <= 720) {
      result = 'month';
    } else {
      result = 'year';
    }

    return result;
  },

  _getTickAndFormat(type) {
    const zero = 0;
    const items = this.get('_tickAndFormat');

    for(let i=0; i < items.length; i++) {
      if(items[i].type === type) {
        return items[i];
      }
    }

    // 기본값 리턴
    return items[zero];
  },

  _setSeriesOpacity(seriesNo, opacity) {
    // [ISSUE-EDGE] Object doesn't support property or method 'getElementsByClassName'
    // [URL] developer.microsoft.com/en-us/microsoft-edge/platform/issues/11729645
    this.$('.timeline.point.series' + seriesNo).parent().css('opacity', opacity);
    this.$('.timeline.fromTo.series' + seriesNo).css('opacity', opacity);
    this.$('.timeline.foreignObject.intersect.series'+ seriesNo).css('opacity', opacity);
    this.$('.timeline.foreignObject.zoomin.series'+ seriesNo).css('opacity', opacity);

    this._setLegendOpacity(seriesNo, opacity);
  },

  _setLegendOpacity(seriesNo, opacity) {
    this.$('.timeline.legendG.series' + seriesNo).css('opacity', opacity);
    this.$('.timeline.legendText.series' + seriesNo).css('opacity', opacity);
  },

  _setCurrentYAxis(series, isSet) {
    if(series.isCustomYAxis === true) {
      if(isSet === true) {
        const currentYAxis = this._getCurrentYAxis();

        this.set('_currentYAxis', currentYAxis);
        this._replaceYAxisText(series.customYAxis);
      }
    }
  },

  _getCurrentYAxis() {
    const result = Ember.A();
    const arrG = this.$().children('.main').children('g[data-id=yAxisG]').children('g').children('text');

    for(let i=0; i < arrG.length; i++) {
      result.pushObject(this.$(arrG[i]).text());
    }

    return result;
  },

  _replaceYAxisText(source) {
    const target = this.$().children('.main').children('g[data-id=yAxisG]').children('g').children('text');

    for(let i=0; i < target.length; i++) {
      this.$(target[i]).text(source[i]);
    }
  },

  _onlyOneChecked() {
    const one = 1;
    let result = false;
    const selectedLegendRect = this.get('_selectedLegendRect');
    const allSeries = this.get('_timelineData').series;

    // 여러개 중에, 1개 선택됨
    if(allSeries.length > one && selectedLegendRect.length === one) {
      result = true;
    }

    this.set('_onlyOne', result);

    return result;
  },

  _selectLegendRect(series) {
    const zero = 0;
    const one = 1;
    const seriesNo = series.no;
    const selectedLegendRect = this.get('_selectedLegendRect');
    const selectedLegendRectForYAxis = this.get('_selectedLegendRectForYAxis');
    let isSelected = false;

    if(selectedLegendRect.includes(seriesNo)) {
      for(let i=selectedLegendRect.length - one; i >= zero; i--) {
        if(selectedLegendRect[i] === seriesNo) {
          selectedLegendRect.removeObject(selectedLegendRect[i]);
          isSelected = false;
          break;
        }
      }
    } else {
      selectedLegendRect.pushObject(seriesNo);
      isSelected = true;
    }

    if(selectedLegendRectForYAxis.includes(seriesNo )) {
      for(let i=selectedLegendRectForYAxis.length - one; i >= zero; i--) {
        if(selectedLegendRectForYAxis[i] === seriesNo) {
          selectedLegendRectForYAxis.removeObject(selectedLegendRectForYAxis[i]);
          break;
        }
      }
    } else {
      selectedLegendRectForYAxis.pushObject(seriesNo);
    }

    this._setDisplaySeriesAll(series);
    this._setSelectedYAxis(series);

    const currentOpacity = parseFloat(this.$('.timeline.legendText.series' + seriesNo).css('opacity'));
    const selectedLegendRectForNormal = this.get('_selectedLegendRectForNormal');
    let isUpdated = false;

    for(let i = 0; i < selectedLegendRectForNormal.length; i++ ) {
      if(selectedLegendRectForNormal[i].seriesNo === seriesNo) {
        isUpdated = true;
        selectedLegendRectForNormal[i].opacity = currentOpacity;
        break;
      }
    }
    if(isUpdated === false) {
      selectedLegendRectForNormal.pushObject({ seriesNo: seriesNo, opacity: currentOpacity});
    }

    this._raiseEvents('onSelectedSeriesChange', { seriesNo: seriesNo, isSelected: isSelected} );
  },

  _setDisplaySeriesAll(series) {
    const zero = 0;
    const seriesNo = series.no;
    const transparentOpacity = this.get('_settingTransparentOpacity');
    const normalOpacity = this.get('_settingNormalOpacity');
    const timelineData = this.get('_timelineData');
    const allSeries = timelineData.series;
    const selectedLegendRect = this.get('_selectedLegendRect');

    // 상태 변경된 아이템
    const svg = this._getD3Svg();
    const legendLabel = svg.selectAll ('.timeline.legendG.series' + seriesNo)
      .selectAll('.legendText');

    if(selectedLegendRect.includes(seriesNo)) {
      legendLabel.classed('selectedLegend', true);
    } else {
      legendLabel.classed('selectedLegend', false);
    }

    this._onlyOneChecked();

     // 하나만 있다면, 그것을 제외한 모든 것을 투명하게 처리
    if(this.get('_onlyOne') === true) {
      for(let i = 0; i < allSeries.length; i++) {
        const tempSeriesNo = allSeries[i].no;

        if(selectedLegendRect.includes(tempSeriesNo)) {
          this._setSeriesOpacity(tempSeriesNo, normalOpacity);
        } else {
          this._setSeriesOpacity(tempSeriesNo, transparentOpacity);
        }
      }
    } else {
      // 선택된 것이 하나도 없다면 모두 표시
      if(selectedLegendRect.length === zero) {
        for(let i = 0; i < allSeries.length; i++) {
          const tempSeriesNo = allSeries[i].no;

          this._setSeriesOpacity(tempSeriesNo, normalOpacity);
        }
      } else {
        // 변경된 것만 처리
        if(selectedLegendRect.includes(seriesNo)) {
          this._setSeriesOpacity(seriesNo, normalOpacity);
        } else {
          this._setSeriesOpacity(seriesNo, transparentOpacity);
        }
      }
    }
  },

  _setSelectedYAxis() {
    const zero = 0;
    const one = 1;
    const selectedLegendForYAxis = this.get('_selectedLegendRectForYAxis');

    if(selectedLegendForYAxis === null || selectedLegendForYAxis.length === zero ) {
      this._setDefaultYAxis();
    } else {
      const lastSelectedNo = selectedLegendForYAxis[selectedLegendForYAxis.length - one];
      const lastSeries = this._getSeriesByNo(lastSelectedNo);

      if(lastSeries.isCustomYAxis === true) {
        this._setCurrentYAxis(lastSeries, true);
      } else {
        this._setDefaultYAxis();
      }
    }
  },

  _getSeriesByNo(seriesNo) {
    const series = this.get('_timelineData').series;

    for(let i = 0; i < series.length; i++) {
      if(series[i].no === seriesNo) {
        return series[i];
      }
    }
  },

  _setDefaultYAxis() {
    this.set('_currentYAxis', Ember.$.extend(true, [], this.get('_defaultYAxis')));
    this._replaceYAxisText(this.get('_currentYAxis'));
  },

  _selectSeriesSymbol(series) {
    const zero = 0;
    const one = 1;
    const seriesNo = series.no;
    const selectedLegendSymbol = this.get('_selectedLegendSymbol');
    let isSelected = false;

    // 없으면 추가, 있으면 제거
    if(selectedLegendSymbol.includes(seriesNo)) {
      for(let i=selectedLegendSymbol.length - one; i >= zero ; i--) {
        if(selectedLegendSymbol[i] === seriesNo) {
          selectedLegendSymbol.removeObject(selectedLegendSymbol[i]);
          isSelected = false;
          break;
        }
      }
    } else {
      selectedLegendSymbol.pushObject(seriesNo);
      isSelected = true;
    }

    this._setOpacityLegendSymbol(series);
    this._setDisplaySeries(series);

    this._raiseEvents('onSelectedSymbolChange', { seriesNo: seriesNo, isSelected: isSelected});
  },

  _setOpacityLegendSymbol(series) {
    const seriesNo = series.no;
    const transparentOpacity = this.get('_settingTransparentOpacity');
    const normalOpacity = this.get('_settingNormalOpacity');
    const selectedLegendSymbol = this.get('_selectedLegendSymbol');

    if(selectedLegendSymbol.includes(seriesNo)) {
      this.$('.timeline.legendSymbol.series' + seriesNo).parent().css('opacity', transparentOpacity);
    } else {
      this.$('.timeline.legendSymbol.series' + seriesNo).parent().css('opacity', normalOpacity);
    }
  },

  _setDisplaySeries(series) {
    const seriesNo = series.no;
    const selectedLegendSymbol = this.get('_selectedLegendSymbol');

    // 포함되면 숨기기
    if(selectedLegendSymbol.includes(seriesNo)) {
      this._showSeries(seriesNo, false);
    } else {
      this._showSeries(seriesNo, true);
    }
  },

  _showSeries(seriesNo, isShow) {
    if(isShow) {
      this.$('.timeline.point.series' + seriesNo).show();
      this.$('.timeline.fromTo.series' + seriesNo).show();
      this.$('.timeline.foreignObject.intersect.series'+ seriesNo).show();
      this.$('.timeline.foreignObject.zoomin.series'+ seriesNo).show();
    } else {
      this.$('.timeline.point.series' + seriesNo).hide();
      this.$('.timeline.fromTo.series' + seriesNo).hide();
      this.$('.timeline.foreignObject.intersect.series'+ seriesNo).hide();
      this.$('.timeline.foreignObject.zoomin.series'+ seriesNo).hide();
    }
  },

  _addToChartData(newSeries) {
    this.get('timelineData').series.pushObject(newSeries);
  },

  _removeToChartDataByNo(seriesNo) {
    const timelineData = this.get('timelineData');
    let target = null;

    for(let i=0; i < timelineData.series.length; i++) {
      if(timelineData.series[i].no === seriesNo) {
        target = timelineData.series[i];
        break;
      }
    }
    timelineData.series.removeObject(target);
  },

  _moveToLast(parentObj, childObj) {
    childObj.appendTo(parentObj);
  },

  _moveToFirst(parentObj, childObj) {
    childObj.prependTo(parentObj);
  },

  actions: {
    // fr-chart-legend 에서 호출
    completeProcessing(dataId) {

      const timelineData = this.get('_timelineData');

      if(Ember.isEmpty(timelineData)) {
        return;
      }

      this._replaceSeriesName();
      this._setCustomYAxis();

      const parentObj = this.$().find('.c-timeline-svg');
      const parentRoot = this.$().find('.timelineRoot')

      const yAxis = this.$('g[data-id=yAxisG]');
      const xAxis = this.$('g[data-id=xAxisG]');
      const pane = this.$('rect.pane');
      const pointChart = this.$('.chart-type-point');

      this._moveToFirst(parentObj, yAxis);
      this._moveToFirst(parentObj, xAxis);
      this._moveToFirst(parentObj, pane);
      this._moveToLast(parentRoot, pointChart);
    },

    mouseoverSeries(series) {
      let button = null;
      if(Ember.isEmpty(d3.event.sourceEvent)) {
        button = d3.event.buttons;
      } else {
        button = d3.event.sourceEvent.buttons;
      }
      if(button === 2) {
        return;
      }
      const zero = 0;
      const seriesNo = series.no;
      const transparentOpacity = this.get('_settingTransparentOpacity');
      const normalOpacity = this.get('_settingNormalOpacity');
      const selectedLegendRect = this.get('_selectedLegendRect');

      if(selectedLegendRect.includes(seriesNo) === true) {
        return;
      }

      const currentOpacity = parseFloat(this.$('.timeline.legendText.series' + seriesNo).css('opacity'));
      const selectedLegendRectForNormal = this.get('_selectedLegendRectForNormal');

      let isUpdated = false;

      for(let i = 0; i < selectedLegendRectForNormal.length; i++ ) {
        if(selectedLegendRectForNormal[i].seriesNo === seriesNo) {
          isUpdated = true;
          selectedLegendRectForNormal[i].opacity = currentOpacity;
          break;
        }
      }

      if(isUpdated === false) {
        selectedLegendRectForNormal.pushObject({ seriesNo: seriesNo, opacity: currentOpacity});
      }

      this._setSeriesOpacity(seriesNo, normalOpacity);

      if(selectedLegendRect.length === zero) {
        const allSeries = this.get('_timelineData').series;

        for(let i=0; i < allSeries.length; i++) {
          if(allSeries[i].no !== seriesNo) {
            this._setSeriesOpacity(allSeries[i].no, transparentOpacity);
          }
        }
      }

      if(series.isCustomYAxis === true) {
        // y 축 변경
        this._setCurrentYAxis(series, true);
      }
    },

    mouseoutSeries(series) {
      const zero = 0;
      const seriesNo = series.no;
      const normalOpacity = this.get('_settingNormalOpacity');
      let opacity = normalOpacity;
      const selectedLegendRect = this.get('_selectedLegendRect');

      if(selectedLegendRect.includes(seriesNo) === true) {
        return;
      }

      this._onlyOneChecked();

      const selectedLegendRectForNormal = this.get('_selectedLegendRectForNormal');

      for(let i = 0; i < selectedLegendRectForNormal.length; i++ ) {
        if(selectedLegendRectForNormal[i].seriesNo === seriesNo) {
          opacity = selectedLegendRectForNormal[i].opacity;
          break;
        }
      }

      this._setSeriesOpacity(seriesNo, opacity);

      if(selectedLegendRect.length === zero) {
        const allSeries = this.get('_timelineData').series;

        for(let i=0; i < allSeries.length; i++) {
          this._setSeriesOpacity(allSeries[i].no, normalOpacity);
        }
      }

      if(series.isCustomYAxis === true) {
        const currentYAxis = this.get('_currentYAxis');

        // y 축 변경
        this._replaceYAxisText(currentYAxis);
      }
    },

    selectLegendRect(series) {
      this._selectLegendRect(series);
    },

    selectLegendSymbol(series) {
      this._selectSeriesSymbol(series);
    },

    clickRemoveSeries(sereisNo) {
      this._raiseEvents('onRemoveSeriesClick', sereisNo);
    },

    changeCollapsibleLegend(isCollapsed) {

      const timelineData = this.get('_timelineData');
      const isCollapsibleLegend = timelineData.isCollapsibleLegend;

      if(isCollapsibleLegend) {
        timelineData.isCollapseLegendPane = isCollapsed;
      }
      // 스크롤바 처리
      if (!isCollapsed) {
        this.set('legendWidth', timelineData.collapsibleLegendWidth || this.get('_groupLegendWidth'));
        this.$('.scroll-area').addClass('scrollbar-macosx');
        this.$('.scrollbar-macosx').scrollbar();
      } else {
        this.set('legendWidth', this.get('_settingPaddingRight') - 10);
        // this.$('.scroll-area').removeClass('scrollbar-macosx');
        this.$('.scrollbar-macosx').scrollbar('destroy');

      }
      this._raiseEvents('onLegendCollapse', isCollapsed);
    },

    clickData(obj) {
      this._raiseEvents('onDataSelect', obj);
    },
    dblclickData(obj) {
      this._raiseEvents('onDataDoubleClick', obj);
    }
  },

});