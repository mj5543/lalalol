import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';
import ContextMenuMixin from '../../mixins/contextmenu-mixin';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

// TabControl
export default Control.extend(ContextMenuMixin, StatefulComponentMixin, {

  // == Component properties ================
  attributeBindings: [
    'getSelectedTabName:data-name',
    'getSortableInfo:data-sortable',
    'getTabClass:data-classname',
    'getTabMode:data-tab-mode',
    'getTabChange:data-tab-change'
  ],
  classNames: ['c-tabs'],
  layout,
  tagName: 'div',
  // == Public Properties ====================
  enableTabClose : false,
  nameMemberPath : 'id',
  displayMemberPath : 'header',
  isDataBind : false,
  tabClassType : 'oneDepth',
  postTabItemContent : '',
  tabItemCloseButtonVisibility : false,
  tabClosing : null,
  tabClosed : null,
  tabStripPlacement : '',
  sortable: false,
  selectedTabName : null,
  canUseHeaderTemplate : false,
  isColllectionOpen : false,
  isTabCollection:false,
  enableTabAdd:false,
  tabAdding: false,
  hasLoaded: false,
  isTabList: false,
  placeInArea: true,

  //== Private Properties ==================
  _internalItemsSource : null,
  _positionSource : null,
  _tabCollectionSource: null,
  _tabControlClass : null,
  _tabAddFix:null,
  _tabAdd:null,
  _isTabOverflow: false,
  _isStackMode: false,
  _oldItemsSource: null,


  //== Computed Properties ==================
  getSelectedTabName: Ember.computed('selectedTabName', function() {
    const tabid = this.get('selectedTabName') ;
    if ( Ember.isEmpty(tabid) ) {
      return '';
    }
    return tabid;
  }).readOnly(),
  getSortableInfo: Ember.computed('sortable', function() {
    if (this.get('sortable')) {
      Ember.run.once(this, () => {
        this._enableSort();
      });
      return true;
    } else {
      Ember.run.once(this, () => {
        this._disableSort();
      });
      return false;
    }
  }).readOnly(),
  getTabClass: Ember.computed('tabClassType', function() {
    const className = this.get('tabClassType') ;
    if ( Ember.isEmpty(className) ) {
      return '';
    } else {
      Ember.run.once(() => this._changeTabClass());
    }
    return className;
  }).readOnly(),
  getTabMode: Ember.computed('tabViewMode', function() {
    const tab = this.get('tabViewMode') ;
    if(tab === 'stack') {
      this.set('_isTabOverflow', false);
    } else {
      Ember.run.debounce(() => {
        this._detectTabOverflow();
      });
    }

    return tab;
  }).readOnly(),
  getTabChange: Ember.computed('itemsSource.length', function() {
    this._detectTabOverflow();
    const items = this.get('itemsSource');
    const old = this.get('_oldItemsSource');

    if(old && (items.length > old.length)) {
      this._addTab(items, old);
    }
    if(items) {
      Ember.run.debounce(() => this.set('_oldItemsSource', items.slice()));
    }
    return true;
  }).readOnly(),

  // == Private Methods =======================
  _getInternalItemsSource(){
    if (!Ember.isEmpty(this.get('itemsSource'))) {
      return this.get('itemsSource') ;
    }
    const _internalSource = this.get('_internalItemsSource') ;
    if ( Ember.isEmpty(_internalSource)) {
      this.set('_internalItemsSource', []);
    }
    return this.get('_internalItemsSource') ;
  },
  // == Life Cycle Event =======================
  onPropertyInit() {
    this._super(...arguments);
    // this.setStateProperties(['selectedTabName']);
    Ember.run.once(() => this._changeTabClass());

  },
  _changeTabClass() {
    switch (this.get('tabClassType')) {
      case "twoDepth" :
        this.set('_tabControlClass', 'tab-2dep');
        break;
      case "threeDepth" :
        this.set('_tabControlClass', 'tab-3dep');
        break;
      case "customStyle" :
        this.set('_tabControlClass', '');
        break;
      default :
        this.set('_tabControlClass', 'tab-default');
        break;
    }
  },
  _addTab(items, old) {
    let tabindex;
    const addTab = items.filter((obj, idx) => {
      if(!~old.indexOf(obj)) {
        tabindex = idx;
      }
      return !~old.indexOf(obj);
    });

    const tabid = Ember.get(addTab[0], this.get('nameMemberPath'));
    Ember.run.debounce(() => {
      this._detectTabOverflow();
      this.set('selectedTabName', tabid);
      if(tabindex === 0) {
        this.$('.tabscroll').animate({ scrollLeft: '-=110' }, 300);
      } else {
        this.$('.tabscroll').animate({ scrollLeft: '+=110' }, 300);
      }

    });
    // this.set('_oldItemsSource', this.get('itemsSource'));
  },
  _detectTabOverflow() {
    const tabnav = this.$('.c-tabs-nav');
    if(tabnav && tabnav.length) {
      const tab = this.$('.tab');

      const tabli = tabnav.find('li');
      const arr = [];

      tabli.each(function() {
        arr.push(parseFloat(Ember.$(this).width()));
      });

      const tabwid = arr.reduce(function(accumulator, currentValue) {
        return accumulator + currentValue;
      }, 0);


      if(this.get('tabViewMode') === 'list') {
        if(tabwid > parseFloat(tab.width())) {
          this.set('_isTabOverflow', true);
        } else {
          this.set('_isTabOverflow', false);
        }
      }
    }
  },
  _sortArray({array, order, sort}) {
    const result = order.map(function(item) {
      return array.filter(function(arr) {
        return arr[sort] === item;
      })[0];
    });
    return result;
  },

  _enableSort() {
    this.$('.tabscroll').sortable({
      disabled: false,
      start: ( event, ui ) => {
        ui.helper[0].style.cursor = 'grabbing';
      },
      update: function () {
        const order = this.$('.tabscroll').sortable('toArray').map(function (id) { return this.$(`#${id}`).attr('name'); }.bind(this));
        const newArr = this._sortArray({
          array: this.get('itemsSource'),
          order: order,
          sort: this.get('nameMemberPath')
        });
        this._raiseEvents('onTabSorted', {
          'source' : this,
          'originalSource': this,
          'oldItemSource': this.get('itemsSource'),
          'newItemSource': newArr
        });
        this.set('itemsSource', newArr);
      }.bind(this)
    });
  },
  _disableSort() {
    this.$('.tabscroll').sortable({
      disabled: true
    });
  },
  didRender(){
    this._super(...arguments);
    this.set('_isStackMode', this.get('tabViewMode') === 'stack' || false);
  },
  didInsertElement(){
    this._super(...arguments);

    this._tabAddFix = this.$().find('.tab-add-fix').first();
    this._tabAdd = this.$().find('.tab-add').first();

    if(this.enableTabAdd){
      this._tabAdd.addClass('active');
    }

    this.set('_tabCollectionSource', []);

    switch ( this.tabStripPlacement){
      case "left" :
        this.$().addClass('left') ;
        break;
    }

    const _internalSource = this._getInternalItemsSource();
    if (!Ember.isEmpty(_internalSource)) {
      let tabid = this.get('selectedTabName') ;

      const item = this._getInternalItemsSource().findBy(this.get('nameMemberPath'), tabid) ;
      if ( Ember.isEmpty(item)) {
        tabid = null ;
      }

      if (Ember.isEmpty(tabid)) {
        this.set('selectedTabName', Ember.get(_internalSource.objectAt(0), this.get('nameMemberPath')));
      } else {
        this.set('selectedTabName', tabid);
      }
    }

    this._detectTabOverflow();
    // Ember.run.once(() => this.set('_oldItemsSource', this.get('itemsSource')));
    this.set('hasLoaded', true);
  },
  actions: {
    onOpenTabList() {
      this.set('isTabList', true);
    },
    onTabChangedAction(e){
      const tabid = Ember.get(e, this.get('nameMemberPath'));
      this.set('selectedTabName', tabid);
    },
    onCollction(){
      // alert('onCollection');
    },
    increaseScrollLeftStart(left, event) {
      let currentDelay = 300, repeat = true, increaseScrollLeft = function() {
        if (!this.get('isDestroying') && !this.get('isDestroyed')) {
          this.$('.tabscroll').animate({ scrollLeft: `+=${left}` }, 300);
          Ember.run.later(this, function () {
            if (!this.get('isDestroying') && !this.get('isDestroyed') && repeat) {
              increaseScrollLeft();
            } else {
              repeat = null;
              increaseScrollLeft = null;
            }
          }, currentDelay);
        }
      }.bind(this);

      this.$(event.currentTarget).on('mouseup mouseleave', function () {
        repeat = false;
        currentDelay = null;
        this.$(event.currentTarget).off('mouseup mouseleave');
      }.bind(this));
      increaseScrollLeft();
    },
    onTabAdd(){
      this._raiseEvents('onTabAdding', { 'source' : null, 'originalSource': this, 'addTabId': undefined });
      // this._addTab();
    },
    onRenderAction(item) {
      this._getInternalItemsSource().pushObject(item);
    },
    onGoSelectTab(e) {
      const tabid = Ember.get(e, this.get('nameMemberPath'));
      this.set('selectedTabName', tabid);
    },
    onSelectedAction(e) {
      if (!this.hasLoaded ) {
        return ;
      }
      if(this.get('itemsSource')) {
        const index = this.get('itemsSource').indexOf(e.dataItem);
        const active = this.$('.tabscroll').children().eq(index);
        const start = this.$('.tabscroll').scrollLeft();
        const end = this.$('.tabscroll').scrollLeft() + this.$('.tabscroll').width();
        const current = active.position().left + start;

        if(current > end || current < start){
          this.$('.tabscroll').animate({ scrollLeft: current }, 300);
        }
      }

      Ember.set(e, 'source', this);
      this.set('selectedItem', e.dataItem);
      this._raiseEvents('onSelectionChanged', e);
    },

    onTabClosingAction(e) {
      this._raiseEvents('onTabClose', e);
      // this._tapCollectionOpening();

      if ( e.cancel === false) {

        const _item = e.originalSource.dataItem;
        let _name = null;

        if ( !Ember.isEmpty(_item)) {

          if ( Ember.isEmpty(this.itemsSource)) {
            this.get('_internalItemsSource').removeObject(_item);

            if (!Ember.isEmpty(this.get('_internalItemsSource'))) {
              _name = Ember.get(this.get('_internalItemsSource').objectAt(0), this.get('nameMemberPath'));
            }

          } else {
            this.get('itemsSource').removeObject(_item) ;

            if (!Ember.isEmpty(this.get('itemsSource'))) {
              _name = Ember.get(this.get('itemsSource').objectAt(0), this.get('nameMemberPath'));
            }
          }
        }

        this.set('selectedTabName', _name);

        this._raiseEvents('onTabClosed', { source : null, originalSource : this});
      }

      Ember.run.debounce(() => {
        this._detectTabOverflow();
      });
    }
  }
});