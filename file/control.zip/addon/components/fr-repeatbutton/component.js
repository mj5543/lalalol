import Ember from 'ember';
import layout from './template';
import ButtonBase from '../fr-buttonbase/component';
import ContextMenuMixin from '../../mixins/contextmenu-mixin';

//RepeatButton
export default ButtonBase.extend(ContextMenuMixin, {
  _intervalId: null,
  classNames: ['fr-repeatbutton', 'btn', 'btn-xxsm', 'btn-unit'],
  layout,
  delay: 100,
  tagName: 'div',
  click: null,
  _onClick(e) {
    e.preventDefault();
    e.stopPropagation();

    return false;
  },
  _onCaptureMouse(e) {
    if (!Ember.isEmpty(this._intervalId)) {
      window.clearInterval(this._intervalId);
    }

    if (e.which === 1) {
      this._intervalId = window.setInterval(function () {
        this._raiseEvents('click', e);
      }.bind(this), this.get('delay'));
    }
  },
  _onReleaseMouse() {
    if (!Ember.isEmpty(this._intervalId)) {
      window.clearInterval(this._intervalId);
    }
    this._intervalId = null;
  },
  didInsertElement() {
    this._super(...arguments);

    this.$()
      .on('click', this._onClick.bind(this))
      .on('mousedown', this._onCaptureMouse.bind(this))
      .on('mouseup', this._onReleaseMouse.bind(this))
      .on('mouseleave', this._onReleaseMouse.bind(this));
  },
  willDestroyElement() {
    this._super(...arguments);

    this._onReleaseMouse();
    this.$()
      .off('click')
      .off('mousedown')
      .off('mouseup')
      .off('mouseleave');
  }
});