import Ember from 'ember';
import layout from './template';

export default Ember.Component.extend({
  layout,
  tagName: 'i',
  tip: null,
  currentElement: null,
  target: null,
  isDisabled: false,
  placement: 'up',
  didInsertElement() {
    this._super(...arguments);
    this.$().parent().on(`mouseenter.tipster-${Ember.guidFor(this)}`, function () {
      if(!this.get('isDisabled') && this.get('text')) {
        this._show(this.$().parent().get(0), this.get('placement'));
      }
    }.bind(this));
    this.$().parent().on(`mouseleave.tipster-${Ember.guidFor(this)}`, function () {
      this._hide();
    }.bind(this));
  },
  willDestroyElement() {
    this._hide();
    this.$().parent().off(`mouseenter.tipster-${Ember.guidFor(this)}`);
    this.$().parent().off(`mouseleave.tipster-${Ember.guidFor(this)}`);
    this._super(...arguments);
  },
  offset(el) {
    const box = el.getBoundingClientRect();
    return {
      top: box.top + window.pageYOffset,
      left: box.left + window.pageXOffset,
      width: box.width,
      height: box.height
    };
  },
  _show(target, position) {
    const text = this.get('text').string || this.get('text'), tip =  Ember.$(`<div class="tipster tipster-${Ember.guidFor(this)}"></div>`).append(text);

    Ember.$('#max-wormhole-parent').append(tip);
    const coords = this.offset(target), targetWidth = target.offsetWidth, tipWidth = tip.width(), tipHeight = tip.height(), gap = 10, padding = 2;

    switch(position) {
      case 'down':
        tip.css({
            top: coords.top + target.offsetHeight + gap - padding + 'px',
            left: coords.left - (tipWidth / 2) -gap + (targetWidth / 2) + 'px'
          })
          .addClass('tipster-arrow-bottom');
        break;
      case 'up':
        tip.css({
            top: coords.top - tipHeight - gap - padding + 'px',
            left: coords.left - (tipWidth / 2) -gap + (targetWidth / 2) + 'px'
          })
          .addClass('tipster-arrow-top');
        break;
      case 'left':
        tip.css({
            top: coords.top + (target.offsetHeight / 2) - (tipHeight / 2) - padding + 'px',
            left: coords.left - tipWidth - (gap * 3) + 'px'
          })
          .addClass('tipster-arrow-left');
        break;
      case 'right':
        tip.css({
            top: coords.top + (target.offsetHeight / 2) - (tipHeight / 2) - padding + 'px',
            left: coords.left + targetWidth + gap + 'px'
          })
          .addClass('tipster-arrow-right');
        break;
      default:
        tip.css({
            top: coords.top - tipHeight - gap - padding + 'px',
            left: coords.left - (tipWidth / 2) -gap + (targetWidth / 2) + 'px'
          })
          .addClass('tipster-arrow-top');
    }
    tip.css({ opacity: 1, pointerEvents: 'none' });
  },
  _hide() {
    Ember.$(`.tipster-${Ember.guidFor(this)}`).remove();
  }
});