import Ember from 'ember';
import Control from '../fr-control/component';

export default Control.extend({
  tagName: 'div',
  classNames: ['fr-codesnippet', 'hljs'],
  text: '',
  isHtml: true,
  isBreaks: true,
  resize: null,
  onInserted: null,
  _onResize(e) {
    this._raiseEvents('resize', { source: this, originalEvent: e });
  },
  didInsertElement() {
    this._super(...arguments);

    let code = this.text;

    if (Ember.isEmpty(code)) {
      return;
    }

    Ember.$(window).on('resize.' + this.elementId, this._onResize.bind(this));

    var md = new Remarkable('full', {
      html: this.isHtml,        // Enable HTML tags in source
      xhtmlOut: true,        // Use '/' to close single tags (<br />)
      breaks: this.isBreaks,        // Convert '\n' in paragraphs into <br>
      langPrefix: 'language-',  // CSS language prefix for fenced blocks
      linkify: true,         // autoconvert URL-like texts to links
      linkTarget: '',           // set target to open link in

      // Enable some language-neutral replacements + quotes beautification
      typographer: false,

      // Double + single quotes replacement pairs, when typographer enabled,
      // and smartquotes on. Set doubles to '«»' for Russian, '„“' for German.
      quotes: '“”‘’',

      // Highlighter function. Should return escaped HTML,
      // or '' if input not changed
      highlight: function (str, lang) {
        if (lang && hljs.getLanguage(lang)) {
          try {
            return hljs.highlight(lang, str).value;
          } catch (e) {
            Ember.Logger.error(e);
          }
        }

        try {
          return hljs.highlightAuto(str).value;
        } catch (e) {
          Ember.Logger.error(e);
        }

        return ''; // use external default escaping
      }
    });

    this.$().html(md.render(code));

    this._raiseEvents('onInserted', { source : this}) ;
  },
  willDestroyElement() {
    this._super(...arguments);
    Ember.$(window).off('resize.' + this.elementId);
    this.set('text', null);
    this.$().empty();
  }
});
