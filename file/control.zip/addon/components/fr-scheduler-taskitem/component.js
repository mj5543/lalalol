import Ember from 'ember';
import GlobalServiceContainerMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';
import ToolTipMixin from '../../mixins/tooltip-mixin';
import DragMixin from '../../mixins/scheduler-drag-move-helper';
import ResizeMixin from '../../mixins/scheduler-drag-resize-helper';

export default Ember.Component.extend(GlobalServiceContainerMixin, ToolTipMixin, DragMixin, ResizeMixin, {
  layout: Ember.computed(function () {
    return Ember.HTMLBars.compile('<div class="fr-schedule-taskitem-content" title="' + this.get(`_owner.toolTipTemplate`) + '">' + this.get(`_owner.itemTemplate`) + '</div>');
  }),
  tagName: 'div',
  classNames: ['fr-scheduler-taskitem', 'scheduler-on'],
  datacontext: null,
  _owner: null,
  width: 0,
  height: 0,
  x: 0,
  y: 0,
  // == Draw ======================================
  contains(x, y) {
    return this.x <= x && x <= this.x + this.width && this.y <= y && y <= this.y + this.height;
  },
  split(left, width) {
    this.$().css({ 'width': width, 'left': left });
  },
  getTimeSet() {
    const i18n = this.get('fr_I18nService');
    const stdt = Ember.get(this.datacontext, this._owner.mappingFromDatePath);
    const eddt = Ember.get(this.datacontext, this._owner.mappingToDatePath);

    const sminute = Math.floor(stdt.getMinutes() / 10) * 10;
    const eminute = Math.floor(eddt.getMinutes() / 10) * 10;

    const newstdt = new Date(stdt.getFullYear(), stdt.getMonth(), stdt.getDate(), stdt.getHours(), sminute, 0);
    const neweddt = new Date(eddt.getFullYear(), eddt.getMonth(), eddt.getDate(), eddt.getHours(), eminute, 0);

    const day = i18n.formatDate(stdt, 'w');
    const stime = i18n.formatDate(newstdt, 't');
    const etime = i18n.formatDate(neweddt, 't');

    return {
      day: day,
      baseDate: newstdt,
      startTime: stime,
      endTime: etime
    };
  },
  calculatePosition() {

    const timeset = this.getTimeSet();

    const weekday = this.get('fr_I18nService').formatDate(timeset.baseDate, 'w');

    const str = this._owner.$('.fr-scheduler-body > table > tbody > tr[data-time="' + timeset.startTime + '"]');
    const etr = this._owner.$('.fr-scheduler-body > table > tbody > tr[data-time="' + timeset.endTime + '"]');
    const td = str.find('td[data-weekday="' + weekday + '"]');
    const strAt = str.position().top;
    const endAt = etr.position().top;

    if (td.length === 0) {
      this.width = 0;
      this.height = 0;
      this.x = 0;
      this.y = 0;

      this.$().css({ 'top': this.y, 'left': this.x, 'width': this.width, 'height': this.height }).hide();
    } else {
      this.width = td.outerWidth();
      this.height = endAt - strAt;
      this.x = td.position().left;
      this.y = strAt;

      this.$().css({ 'top': this.y, 'left': this.x, 'width': this.width, 'height': this.height }).show();
    }

  },
  _onDragStart() {
    return this._owner._onDragStart(this);
  },
  _onDragComplete() {
    // ignored
  },
  _onReSizeEnd(e, option) {

    const stdt = Ember.get(this.datacontext, this._owner.mappingFromDatePath);
    const eddt = Ember.get(this.datacontext, this._owner.mappingToDatePath);
    const time = option.currentTime.split(':');

    if (option.resizeWith === 'top') {

      const newValue = new Date(stdt.getFullYear(), stdt.getMonth(), stdt.getDate(), time[0], time[1]);

      Ember.set(this.datacontext, this._owner.mappingFromDatePath, newValue);

    } else if (option.resizeWith === 'bottom') {

      const newValue = new Date(eddt.getFullYear(), eddt.getMonth(), eddt.getDate(), time[0], time[1]);

      Ember.set(this.datacontext, this._owner.mappingToDatePath, newValue);
    }

    this._owner._schedulerTaskItemChanged(this);
  },
  _onDragEnd(e, option) {

    const date = new Date(option.currentCell.data('date'));
    let stdt = Ember.get(this.datacontext, this._owner.mappingFromDatePath);
    let eddt = Ember.get(this.datacontext, this._owner.mappingToDatePath);

    const timelag = stdt.Subtract(eddt, 'minute');

    const stime = option.currentCell.closest('tr').data('time').split(':');

    stdt = new Date(date.getFullYear(), date.getMonth(), date.getDate(), stime[0], stime[1], 0);
    eddt = stdt.addMinutes(timelag);

    Ember.set(this.datacontext, this._owner.mappingFromDatePath, stdt);
    Ember.set(this.datacontext, this._owner.mappingToDatePath, eddt);
    this._owner._schedulerTaskItemChanged(this);
  },
  _getMousePos(e) {

    const pos = { x: 0, y: 0, width: 0, height: 0, bottom: 0 };

    if (typeof e.clientX === 'number') {
      pos.x = e.clientX;
      pos.y = e.clientY;
    } else if (e.originalEvent.touches) {
      pos.x = e.originalEvent.touches[0].clientX;
      pos.y = e.originalEvent.touches[0].clientY;
    } else {
      return null;
    }

    return pos;
  },
  _getHandle(selector, el) {

    if (selector && selector.trim()[0] === ">") {
      return el.find(selector.trim().replace(/^>\s*/, ""));
    }

    return selector ? this.$(selector) : el;
  },
  // == Life Cylces ===============================
  didInsertElement() {
    this._super(...arguments);

    this._owner._addItem(this);

    this.$().attr('tabindex', -1);

    this.title = this.$('.fr-schedule-taskitem-content')
      .on('mouseleave', this._onmouseLeave.bind(this))
      .on('mouseenter', this._onmouseEnter.bind(this));
  },
  didRender() {

    this._super(...arguments);

    this.title = this.$('.fr-schedule-taskitem-content').attr('title');

    this.$('.fr-schedule-taskitem-content').attr("title", "");
  },
  willDestroyElement() {
    this._super(...arguments);

    this.$('.fr-schedule-taskitem-content')
      .off('mouseleave')
      .off('mouseenter');

    this.destory();

    Ember.$(document).off('mousedown.scheduletask');

  },
  click(e) {
    this._owner._onSelectedChanged(this, e);

    if (this._owner.get('canUseChageTask') === false) {
      return;
    }

    this.destory();

    this._canUseResize(this.$(), {
      containment: this._owner,
      minimumHeight: this._owner.timeAreaHeight,
      resizeBottom: true,
      resizeTop: true,
      resizeLeft: false,
      resizeRight: false,
      onDragStart: null,
      onDragEnd: this._onReSizeEnd.bind(this),
      onDragComplete: null,
      touchActionNone: false
    });

    this._canUseDrag();

    Ember.$(document).on('mousedown.scheduletask', this._releaseMouse.bind(this));
  },
  _releaseMouse(e) {
    const taskitem = this.$(e.target).closest('.fr-scheduler-taskitem');

    if (Ember.isEmpty(taskitem) || taskitem.attr('id') != this.elementId) {
      this.destory();
    }
  },
  destory() {
    Ember.$(document).off('mousedown.scheduletask');
    this._resizeDestroy();
    this._dragDestroy();
  },
  doubleClick(e) {
    this._owner._onSchedulerTaskItemDoubleClick(this, e);
  },
  actions: {
  }
});