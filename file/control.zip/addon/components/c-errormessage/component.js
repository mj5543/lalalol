import Ember from 'ember';
import Control from '../c-control/component';
import layout from './template';

export default Control.extend({
  layout,
  tagName: 'div',
  targetElement: null,
  targetAttachment: 'top right',
  attachment: 'bottom right',
  placeInArea: false,
  useParentWormhole: true,
  offsetTop: -5,
  offsetLeft: 0,
  didInsertElement() {
    this._super(...arguments);
  },
  willDestroyElement() {
    this._super(...arguments);
  },
});