import Ember from 'ember';
import layout from './template';

export default Ember.Component.extend({
  layout,
  classNameBindings: ['accessableClassName'],
  attributeBindings: [
    'htmlSafeStyle:style', 'type', 'id', 'name', 'tabindex', 'checked', 'value', 'disabled', 'readonly', 'accept', 'multiple', 'flow',
    'placeholder', 'autocomplete', 'autocorrect', 'autocapitalize', 'autofocus', 'spellcheck', 'tooltip', 'draggable',
    'data-body-row-index', 'data-item', 'data-body-row-state', 'data-day', 'data-toggle',
  ],
  accessableElements: null,
  htmlSafeStyle: Ember.computed('style', function () {
    if (!Ember.isNone(this.get('style'))) {
      return Ember.String.htmlSafe(this.get('style'));
    }
  }).readOnly(),
  accessableClassName: Ember.computed('disabled', function () {
    const disabled = this.get('disabled'), accessableElements = this.get('accessableElements');

    if (disabled) {
      (this.$().is(':focus') ? this.$() : this.$(':focus')).blur();
      (this.$().is(':tabbable') ? this.$().add(this.$(':tabbable')) : this.$(':tabbable')).each(function (index, element) {
        accessableElements.addObject({ element: element, tabindex: Ember.$(element).attr('tabindex') });
        Ember.$(element).attr('tabindex', '-1');
      });

      return 'disabled';
    } else {
      accessableElements.forEach(function (o) {
        Ember.isNone(o.tabindex) ? Ember.$(o.element).removeAttr('tabindex') : Ember.$(o.element).attr('tabindex', o.tabindex);
      });
      accessableElements.clear();
    }
  }).readOnly(),
  init() {
    this._super(...arguments);
    this.set('accessableElements', Ember.A());
  },
  mouseDown(event) {
    this._raiseEvents('onmousedown', event);
  },
  mouseUp(event) {
    this._raiseEvents('onmouseup', event);
  },
  mouseEnter(event) {
    this._raiseEvents('onmouseenter', event);
  },
  mouseLeave(event) {
    this._raiseEvents('onmouseleave', event);
  },
  click(event) {
    this._raiseEvents('onclick', event);
  },
  doubleClick(event) {
    this._raiseEvents('ondblclick', event);
  },
  change(event) {
    this._raiseEvents('onchange', event);
  },
  _raiseEvents(name, args) {
    if (!Ember.isNone(this.get(name))) {
      if (Ember.isArray(args)) {
        return this.get(name)(...args);
      } else {
        return this.get(name)(args);
      }
    }
  },
});