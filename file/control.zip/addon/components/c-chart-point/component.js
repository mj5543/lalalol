import Ember from 'ember';
import layout from './template';
//import CHIS from 'framework/chis-framework';
import Control from '../c-control/component';
import GlobalServiceContainerMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';
import SVGIconMixin from '../../mixins/svg-icon-mixin';

export default Control.extend(SVGIconMixin, GlobalServiceContainerMixin, StatefulComponentMixin, {
  layout,
  tagName: 'g',
  //attributeBindings:['_isTrendChart'],
  classNames: ['c-chart-point'],

  chartData: null,
  reload: null,
  height: null,
  parentType: null,
  seriesData: null,
  trace: null,
  width: null,
  xAxis: null,
  xScale: null,
  yAxis: null,
  yScale: null,
  setting: null,

  _distance: null,

  _chartData: Ember.computed.alias('chartData').readOnly(),
  _reload: Ember.computed.alias('reload').readOnly(),
  _height: Ember.computed.alias('height').readOnly(),
  _parentType: Ember.computed.alias('parentType').readOnly(),
  _seriesData: Ember.computed.alias('seriesData').readOnly(),
  _trace: Ember.computed.alias('trace').readOnly(),
  _width: Ember.computed.alias('width').readOnly(),
  _xAxis: Ember.computed.alias('xAxis').readOnly(),
  _xScale: Ember.computed.alias('xScale').readOnly(),
  _yAxis: Ember.computed.alias('yAxis').readOnly(),
  _yScale: Ember.computed.alias('yScale').readOnly(),

  _isTrendChart: Ember.computed('_chartData', function () {
    return false;
  }),

  _settingPaddingTop: Ember.computed('_setting', function () {
    return this.get('_setting').paddingTop;
  }),
  _settingPaddingRight: Ember.computed('setting', function () {
    return this.get('setting').paddingRight;
  }),
  _settingPaddingLeft: Ember.computed('setting', function () {
    return this.get('setting').paddingLeft;
  }),
  _settingPaddingBottom: Ember.computed('setting', function () {
    return this.get('setting').paddingBottom;
  }),
  _settingNormalOpacity: Ember.computed('setting', function () {
    return this.get('setting').normalOpacity;
  }),
  _settingDarkOpacity: Ember.computed('setting', function () {
    return this.get('setting').darkOpacity;
  }),
  _settingTransparentOpacity: Ember.computed('setting', function () {
    return this.get('setting').transparentOpacity;
  }),
  _settingGlyphiconPrefix: Ember.computed('setting', function () {
    return this.get('setting').glyphiconPrefix;
  }),

  onPropertyInit() {
    this._super(...arguments);
    this._logTrace('c-chart-point.onPropertyInit()');

    this.setStateProperties([]);
  },

  init() {
    this._super(...arguments);
    this._logTrace('c-chart-point.init()');

    const one = 1;

    this.set('_distance', one);
  },

  didInsertElement() {
    this._super(...arguments);
    this._logTrace('c-chart-point.didInsertElement()');
  },

  didRender() {
    this._super(...arguments);
    this._logTrace('c-chart-point.didRender()');

    this.setDATA();
  },
  setDATA() {
    const zero = 0;
    const one = 1;
    if (Ember.isEmpty(this.get('_chartData')) === true) {
      return;
    }
    this._initProperty();
    if (this.get('_parentType') === 'timeline') {
      this._createTimelineSeries();
    } else {
      // x축 경계를 넘지 않게 ( line 시리즈 특성상)
      const valueDomain = this.get('_chartData').valueDomain;

      if (Ember.isEmpty(valueDomain) === false) {
        const series = this.get('_seriesData');
        const data = series.data;

        series.data = data.filter(function (d) {
          const val = d[series.config.xAxisProperty];

          return val >= valueDomain[zero] && val <= valueDomain[one];
        });
      }
      this._createChartSeries();
    }
    this._findIntersection();
  },


  willDestroyElement() {
    this._super(...arguments);
    this._logTrace('c-chart-point.willDestroyElement()');

    // 이벤트 리스너 해제
    this._removeEventListener();

    // dom 삭제
    if (this.get('_parentType') === 'timeline') {
      this._removeTimelineDom();
    } else {
      this._removeChartDom();
    }

    // 클로저 해제
    this._logTrace = null;
    this._convertDateFormat = null;
  },

  _logTrace(text) {
    if (this.get('_trace') === true) {
      Ember.Logger.log(text);
    }
  },

  _initProperty() {
    const ten = 10;
    const half = 0.5;
    const minusOne = -1;
    const series = this.get('_seriesData');
    const toBeSymbolSize = series.config.symbolSize + ten;

    this.set('_distance', toBeSymbolSize * minusOne * half);
  },

   // date타입 체크 후 변경
   _convertDateFormat(date, isTimeXAxis) {
    if (isTimeXAxis) {
      if (date instanceof Date && date.valueOf() && !Number.isNaN(date.valueOf())) {
        return date;
      } else {
        return new Date(date);
      }
    } else {
      return date;
    }
  },

  _convertDateString(date, format) {
    return this.get('fr_I18nService').formatDate(date, format);
  },

  _createChartSeries() {
    const zero = 0;
    const half = 0.5;
    const adjustSymbolSize = 10;
    const isTimeXAxis = this.get('chartData').isTimeXAxis;

    this._removeEventListener();
    this._removeChartDom();

    const series = this.get('_seriesData');

    if (series.data.length === zero) {
      return;
    }

    const xScaleFunction = this.get('_xScale');
    if (Ember.isEmpty(xScaleFunction)) {
      return;
    }
    const yScaleFunction = this.get('_yScale');
    const isTrendChart = this.get('_isTrendChart');
    const glyphiconPrefix = this.get('_settingGlyphiconPrefix');

    const toBeSymbolSize = series.config.symbolSize + adjustSymbolSize;
    const tooltipTemplate = series.config.tooltipTemplate;
    const idProperty = series.config.idProperty;
    const dateFormat = this.get('_chartData').timeFormat.dataFormat;

    // tooltipTemplate 을 위한 svg 의 sibling 개체
    const p = this.$().parent().parent();

    if (p.children('div.chartTooltipTemplate').length === zero) {
      p.append('<div class=\'chartTooltipTemplate\'></div>');
    }

    const toolTip = d3.select(p[zero]).selectAll('div.chartTooltipTemplate');
    let el, seriesRootG;

    if (isTrendChart === true) {
      el = this.$().parent().get(zero);
      seriesRootG = d3.select(el)
        .select('.main')
        .select('.chartRoot')
        .append('g')
        .attr('class', 'chart seriesRoot' + series.no)
        .attr('data-id', 'seriesRoot' + series.no);
    } else {
      el = this.$().get(zero);
      seriesRootG = d3.select(el);
    }

    // point
    seriesRootG.selectAll('.chart.point.series' + series.no)
      .data(series.data)
      .enter()
      .append('svg:foreignObject')
      .attr('class', 'chart foreignObject series' + series.no)
      .attr('x', d => {
        const tempX = toBeSymbolSize * half;

        let xAxisProperty = this._convertDateFormat(d[series.config.xAxisProperty], isTimeXAxis);
        if (typeof xAxisProperty === 'string') {
          xAxisProperty = new Date(xAxisProperty);
        }

        const w = xScaleFunction(xAxisProperty) - tempX;

        return w;
      })
      .attr('y', function (d) {
        const tempY = toBeSymbolSize * half;
        const w = yScaleFunction(d[series.config.yAxisProperty]) - tempY;

        return w;
      })
      // [COMPATIBILITY-EDGE]
      .attr('width', toBeSymbolSize)
      .attr('height', toBeSymbolSize)
      .append('xhtml:i')
      .attr('class', 'chart point series' + series.no + ' ' + glyphiconPrefix + ' md-' + toBeSymbolSize)
      .style('color', series.config.symbolColor)
      .text(series.config.symbolType.replace(glyphiconPrefix + '-', ''))
      .on('click', d => {
        const id = d[idProperty];
        const obj = {
          series: series,
          id: id
        };

        this._raiseEvents('clickDataCB', obj);
        d3.event.stopPropagation();
      })
      .on('mouseover', () => {
        this._logTrace('c-chart-point.point.mouseover()');
        this._raiseEvents('mouseoverSeriesCB', series);
        d3.event.stopPropagation();
      })
      .on('mouseout', () => {
        this._logTrace('c-chart-point.point.mouseout()');
        this._raiseEvents('mouseoutSeriesCB', series);
        toolTip.style('display', 'none');
        d3.event.stopPropagation();
      })
      .on('mousemove', d => {
        this._logTrace('c-chart-point.point.mousemove()');

        let button = null;
        if(Ember.isEmpty(d3.event.sourceEvent)) {
          button = d3.event.buttons;
        } else {
          button = d3.event.sourceEvent.buttons;
        }
        if(button === 2) {
          return;
        }

        const adjustX = 10;
        const adjustY = 20;
        const x = d3.event.x + adjustX;
        const y = d3.event.y + adjustY;

        toolTip.style('left', x + 'px');
        toolTip.style('top', y + 'px');
        toolTip.style('display', 'inline-block');

        if (Ember.isEmpty(tooltipTemplate) || Ember.isBlank(tooltipTemplate)) {
          let val = d[series.config.tooltipProperty];

          if (typeof val === 'object' && val instanceof Date) {
            val = this._convertDateString(val, dateFormat);
          }
          toolTip.html(val);
        } else {
          let result = tooltipTemplate;

          for (const name in d) {
            let val = d[name];

            if (typeof val === 'object' && val instanceof Date) {
              val = this._convertDateString(val, dateFormat);
            }

            const regexp = new RegExp('{{' + name + '}}', 'gi');

            result = result.replace(regexp, val);
          }
          toolTip.html(result);
        }
      });
  },

  _removeEventListener() {
    const zero = 0;
    const series = this.get('_seriesData');
    const seriesNo = series.no;
    const click = ['.' + this.get('_parentType') + '.point.series' + seriesNo];
    const mouseOverOut = ['.' + this.get('_parentType') + '.point.series' + seriesNo];
    const mouseMove = ['.' + this.get('_parentType') + '.point.series' + seriesNo];
    const el = this.$().parent().get(zero);
    const thisObj = d3.select(el).select('.seriesRoot' + seriesNo);

    for (let i = 0; i < click.length; i++) {
      thisObj.selectAll(click[i]).on('click', null);
    }

    for (let i = 0; i < mouseOverOut.length; i++) {
      thisObj.selectAll(mouseOverOut[i]).on('mouseover', null).on('mouseout', null);
    }

    for (let i = 0; i < mouseMove.length; i++) {
      thisObj.selectAll(mouseMove[i]).on('mousemove', null);
    }
  },

  _removeChartDom() {
    this.$().children().remove();
  },

  _removeTimelineDom() {
    const zero = 0;
    const series = this.get('_seriesData');
    const el = this.$().parent().get(zero);
    const target = d3.select(el).select('.main >.timelineRoot > .seriesRoot' + series.no);

    Array.from(target.selectAll('g')).forEach(() => node.remove());
    target.remove();

  },

  _createTimelineSeries() {
    const zero = 0;
    const half = 0.5;
    const adjustSymbolSize = 10;

    this._removeEventListener();
    this._removeTimelineDom();

    const series = this.get('_seriesData');

    if (series.data.length === zero) {
      return;
    }

    const xScaleFunction = this.get('_xScale');
    const yScaleFunction = this.get('_yScale');
    const glyphiconPrefix = this.get('_settingGlyphiconPrefix');
    const toBeSymbolSize = series.config.symbolSize + adjustSymbolSize;
    const tooltipTemplate = series.config.tooltipTemplate;
    const idProperty = series.config.idProperty;
    const dateFormat = this.get('_chartData').timeFormat.dataFormat;
    const isTimeXAxis = this.get('_chartData').isTimeXAxis;

    // tooltipTemplate 을 위한 svg 의 sibling 개체
    const p = this.$().parent().parent();

    if (p.children('div.chartTooltipTemplate').length === zero) {
      p.append('<div class=\'chartTooltipTemplate\'></div>');
    }

    const toolTip = d3.select(p[zero]).selectAll('div.chartTooltipTemplate');
    const el = this.$().parent().get(zero);
    const seriesRootG = d3.select(el)
      .select('.main')
      .select('.timelineRoot')
      .append('g')
      .attr('class', 'chart-type-point timeline seriesRoot' + series.no)
      .attr('data-id', 'seriesRoot' + series.no);


    const that = this;
    //point
    seriesRootG
      .selectAll('.timeline.series' + series.no)
      .data(series.data)
      .enter()
      .append('g')
      .attr('class', 'timeline series' + series.no)
      .attr('transform', d => {
        const tempX = toBeSymbolSize * half;
        const tempY = toBeSymbolSize * half;
        const x = xScaleFunction(this._convertDateFormat(d[series.config.xAxisProperty], isTimeXAxis)) - tempX;
        const y = yScaleFunction(d[series.config.yAxisProperty]) - tempY;
        return 'translate(' + x + ', ' + y + ')';
      })
      .append(function (d) {

        const rect = d3.select(this).append('g');
        rect.append('rect').style('fill', 'transparent')
          .attr('width', toBeSymbolSize)
          .attr('height', toBeSymbolSize);


        // json에서 값을 불러와서 object를 만들어야 한다.
        const keyword = series.config.symbolType.replace(glyphiconPrefix + '-', '');
        if (that._getChartIcon(keyword)) {
          rect.append('path')
          .attr('d', that._getChartIcon(keyword))
          .attr("transform", `translate(-3, -3)`);
        } else {
          rect.append('svg:foreignObject')
            .attr('width', 20)
            .attr('height', 20)
            .append('xhtml:i')
            // symbolSize 고정
            .attr('class', `${series.config.symbolType} point-icon`)
            .style('color', series.config.symbolColor)
            .style('display', series.config.symbolColor)
            .text(' ');
          }
        return rect.node();
      })

      // [COMPATIBILITY-EDGE]
      .attr('width', toBeSymbolSize)
      .attr('height', toBeSymbolSize)
      .attr('class', 'timeline point series' + series.no + ' ' + glyphiconPrefix + ' md-' + toBeSymbolSize)
      .style('fill', series.config.symbolColor)
      .on('click', d => {
        const id = d[idProperty];
        const obj = {
          series: series,
          id: id
        };

        this._raiseEvents('clickDataCB', obj);
        d3.event.stopPropagation();
      })
      .on('dblclick', d => {
        const id = d[idProperty];
        const obj = {
          series: series,
          id: id,
          data: d
        };
        this._raiseEvents('dblclickSeriesCB', obj);
        d3.event.stopPropagation();
      })
      .on('mouseover', () => {
        this._logTrace('c-chart-point.point.mouseover()');
        this._raiseEvents('mouseoverSeriesCB', series);
        d3.event.stopPropagation();
      })
      .on('mouseout', () => {
        this._logTrace('c-chart-point.point.mouseout()');
        this._raiseEvents('mouseoutSeriesCB', series);
        toolTip.style('display', 'none');
        d3.event.stopPropagation();
      })
      .on('mousemove', d => {
        this._logTrace('c-chart-point.point.mousemove()');

        let button = null;
        if(Ember.isEmpty(d3.event.sourceEvent)) {
          button = d3.event.buttons;
        } else {
          button = d3.event.sourceEvent.buttons;
        }
        if(button === 2) {
          return;
        }

        const tempX = 10;
        const tempY = 20;

        const x = d3.event.x + tempX;
        const y = d3.event.y + tempY;

        toolTip.style('left', x + 'px');
        toolTip.style('top', y + 'px');
        toolTip.style('display', 'inline-block');

        if (Ember.isEmpty(tooltipTemplate) || Ember.isBlank(tooltipTemplate)) {
          let val = d[series.config.tooltipProperty];

          if (typeof val === 'object' && val instanceof Date) {
            val = this._convertDateString(val, dateFormat);
          }
          toolTip.html(val);
        } else {
          let result = tooltipTemplate;

          for (const name in d) {
            let val = d[name];

            if (typeof val === 'object' && val instanceof Date) {
              val = this._convertDateString(val, dateFormat);
            }

            const regexp = new RegExp('{{' + name + '}}', 'gi');

            result = result.replace(regexp, val);
          }
          toolTip.html(result);
        }
      });

  },

  _findIntersection() {
    // timeline 과 chart 위치 다름!!
    const zero = 0;
    const one = 1;
    const two = 2;
    let series = this.get('_seriesData');
    let el = null;
    let rectDom = null;

    if (this.get('_parentType') === 'timeline') {
      series = this.get('_seriesData');
      el = this.$().parent().get(0);
      rectDom = d3.select(el)
        .select('.main')
        .select('.timelineRoot')
        .selectAll('.timeline.foreignObject.series' + series.no);
    } else {
      series = this.get('_seriesData');
      el = this.$().parent().get(0);

      rectDom = d3.select(el)
        .select('.main')
        .select('.chartRoot')
        .selectAll('.chart.foreignObject.series' + series.no);
    }

    const rects = [];
    const distance = this.get('_distance');

    if (!rectDom._groups.length) {
      return;
    }

    if (Ember.isNone(rectDom._groups[0])) {
      return;
    }

    const posy = this.$(rectDom._groups[zero][zero]).css('transform').replace(/[^0-9\-.,]/g, '').split(',');
    const seriesTop = posy[13] || posy[5];

    for (let i = 0; i < rectDom._groups[zero].length; i++) {
      const currentDom = rectDom._groups[zero][i];
      const pos = this.$(rectDom._groups[zero][zero]).css('transform').replace(/[^0-9\-.,]/g, '').split(',');
      const transX = pos[12] || pos[4];
      rects.push({
        x: parseFloat(transX),
        width: parseFloat(this.$(currentDom).find('rect').attr('width'))
      });
    }
    rects.sort(function (a, b) {
      if (a.x == b.x) {
        return 0;
      } else if (a.x < b.x) {
        return -1;
      } else {
        return 1;
      }
    });

    const results = [];

    for (let i = 0; i < rects.length; i++) {
      if (i === rects.length - one) {
        break;
      }

      const current = rects[i];
      const next = rects[i + 1];

      if (current.x + current.width + distance > next.x) {
        results.push((current.x + next.x) / two);
      }
    }

    this._createIntersectionImage(results, seriesTop);
  },
  // 중복되는 영역에 아이콘 표시
  _createIntersectionImage(target, seriesTop) {
    const zero = 0;
    const series = this.get('_seriesData');
    const glyphiconPrefix = this.get('_settingGlyphiconPrefix');
    const toBeSymbolSize = series.config.symbolSize + 10;
    if (Ember.isEmpty(target) || !target.length) {
      return;
    }

    let el = null;
    let seriesRoot = null;


    if (this.get('_parentType') === 'timeline') {
      el = this.$().parent().get(zero);
      seriesRoot = d3.select(el)
        .select('.main')
        .select('.timelineRoot')
        .select('.timeline.seriesRoot' + series.no);

      seriesRoot
        .selectAll('.timeline.foreignObject.intersect.series' + series.no)
        .data(target)
        .enter()
        .append('svg:foreignObject')
        .attr('class', 'timeline foreignObject intersect series' + series.no)
        .attr('x', function (d) {
          const w = d;

          return w;
        })
        .attr('y', function () {
          const w = seriesTop - toBeSymbolSize;

          return w;
        })
        // [COMPATIBILITY-EDGE]
        .attr('width', toBeSymbolSize)
        .attr('height', toBeSymbolSize)
        .append('xhtml:i')
        .attr('class', 'timeline intersect series' + series.no + ' ' + glyphiconPrefix + ' md-' + toBeSymbolSize)
        .style('color', '#FF4000')
        .text('toll');
    } else {
      el = this.$().parent().get(0);

      seriesRoot = d3.select(el)
        .select('.main')
        .select('.chartRoot')
        .select('.chart.seriesRoot' + series.no);

      seriesRoot
        .selectAll('.chart.foreignObject.intersect.series' + series.no)
        .data(target)
        .enter()
        .append('svg:foreignObject')
        .attr('class', 'chart foreignObject intersect series' + series.no)
        .attr('x', function (d) {
          const w = d;

          return w;
        })
        .attr('y', function () {
          const w = seriesTop - toBeSymbolSize;

          return w;
        })
        // [COMPATIBILITY-EDGE]
        .attr('width', toBeSymbolSize)
        .attr('height', toBeSymbolSize)
        .append('xhtml:i')
        .attr('class', 'chart intersect series' + series.no + ' ' + glyphiconPrefix + ' md-' + toBeSymbolSize)
        .style('color', '#FF4000')
        .text('toll');
    }
  },

  actions: {},
});
