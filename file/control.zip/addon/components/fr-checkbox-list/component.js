import Ember from 'ember';
import Selector from '../fr-selector/component';
import ContextMenuMixin from '../../mixins/contextmenu-mixin';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

export default Selector.extend(ContextMenuMixin, StatefulComponentMixin, {
  layout: Ember.computed(function () {

    let _itemTemplate = this.get('itemTemplate');

    if (Ember.isEmpty(_itemTemplate)) {
      _itemTemplate = "<span class='alink'>{{get dataItem displayMemberPath }}</span>";
    }

    const template = `<ul>
                      {{#each itemsSource as |dataItem index|}}
                      <li class='fr-checkbox-list-item {{itemClass}}' >
                        <span class='fr-checkbox inp-chk'>
                          <input type='checkbox' tabindex={{tabindex}} id='{{itemGroupName}}_{{index}}' name='{{itemGroupName}}' value='{{get dataItem selectedValuePath}}' disabled={{disabled}} checked={{get dataItem checkValuePath}} onchange={{action 'changedAction' dataItem}} />
                          <label for='{{itemGroupName}}_{{index}}'>${_itemTemplate}</label>
                        </span>
                      </li>
                      {{/each}}
                    </ul>` ;

    return Ember.HTMLBars.compile(template);
  }),
  tagName: 'div',
  classNames: ['fr-checkbox-list'],
  attributeBindings: ['disabled', 'getSelectedItem:data-value'],
  checkValuePath: '',
  internalItemChanged: false,
  internalSelectedItems: null,
  internalisAllChecked: false,
  hasSelectorContextMenu: true,
  itemGroupName: '',
  itemClass: '',
  itemTemplate: null,
  isEnableHighlight: false,
  orientation : 'horizontal', // vertical
  useSelectedValue: false,
  //== Computed Properties ==============================
  selectedItems: Ember.computed.oneWay('internalSelectedItems').readOnly(),
  isAllChecked: Ember.computed.oneWay('internalisAllChecked').readOnly(),
  getSelectedItem: Ember.computed('selectedValue', 'selectedItem', function () {

    const _selectedValue = this.get('selectedValue');
    const _selectedItem = this.get('selectedItem');
    let _newValue = '';

    if (this.useSelectedValue === true) {
      _newValue = _selectedValue;
    } else if (!Ember.isEmpty(_selectedItem) && !Ember.isEmpty(this.selectedValuePath)) {
      _newValue = Ember.get(_selectedItem, this.selectedValuePath);
    }

    if (this.internalItemChanged === true) {
      this.internalItemChanged = false;
    } else {

      if (!Ember.isEmpty(_selectedItem) || !Ember.isEmpty(_selectedValue)) {
        if (!Ember.isEmpty(this.checkValuePath) && !Ember.isEmpty(this.get('itemsSource'))) {
          this.get('itemsSource').forEach(function (item) {
            Ember.set(item, this.checkValuePath, false);
          }.bind(this));

          if (this.useSelectedValue === false) {
            if (!Ember.isEmpty(_selectedItem)) {
              Ember.set(_selectedItem, this.checkValuePath, true);
            }
          }
        }
      }

      if (this.hasLoaded) {
        this._getcheckboxs().prop('checked', false);
        if (!Ember.isEmpty(_newValue)) {
          this._getcheckbox(_newValue).prop('checked', true);
        }
        Ember.run.once(this, function () {
          this._onSelectedChanged(_selectedItem);
        }.bind(this));
      }
    }

    return _newValue;

  }).readOnly(),
  //== Public Events ====================================
  selectedChanged: null,
  //== Private Method ===================================
  _onSelectedChanged(data) {

    const items = Ember.A([]);

    if (!Ember.isEmpty(this.checkValuePath)) {
      this.get('itemsSource').forEach((item) => {
        if (Ember.get(item, this.checkValuePath) === true) {
          items.pushObject(item);
        }
      });
    } else if (!Ember.isEmpty(this.selectedValuePath)) {
      this.get('itemsSource').forEach((item) => {
        const val = Ember.get(item, this.selectedValuePath);

        if (this._getcheckbox(val).is(":checked") === true) {
          items.pushObject(item);
        }
      });
    }

    this.set('internalSelectedItems', items);

    this.set('internalisAllChecked', this._getcheckcount() === this._getcheckboxs().length);

    this._raiseEvents('selectedChanged', { 'source': this, 'data': data, 'selectedItems': this.get('internalSelectedItems'), 'isAllCheck': this.get('internalisAllChecked') });
  },
  _getcheckbox(val) {
    return this.$(`> ul > li > .inp-chk > input:checkbox[value='${val}']`);
  },
  _getcheckboxs() {
    return this.$('> ul > li > .inp-chk > input:checkbox');
  },
  _getcheckcount() {
    return this.$('> ul > li > .inp-chk > input:checkbox:checked').length;
  },
  _getlabels() {
    return this.$('> ul > li > .inp-chk > label');
  },
  //== Public Method ====================================
  selectAll() {

    this._getcheckboxs().prop('checked', true);

    if (!Ember.isEmpty(this.get('itemsSource')) && !Ember.isEmpty(this.checkValuePath)) {
      this.get('itemsSource').forEach((item) => {
        Ember.set(item, this.checkValuePath, true);
      });
    }

    this._onSelectedChanged(null);
  },
  unSelectAll() {

    this.set('selectedValue', null);
    this.set('selectedItem', null);

    this._getcheckboxs().prop('checked', false);

    if (!Ember.isEmpty(this.get('itemsSource')) && !Ember.isEmpty(this.checkValuePath)) {
      this.get('itemsSource').forEach((item) => {
        Ember.set(item, this.checkValuePath, false);
      });
    }

    this._onSelectedChanged(null);
  },
  contextmenu: Ember.computed('hasSelectorContextMenu', function () {
    const contextmenu = Ember.A();

    if (this.get('hasSelectorContextMenu')) {
      contextmenu.addObject({ action: this.selectAll.bind(this), text: '전체 선택', disabled: false, display: true });
      contextmenu.addObject({ action: this.unSelectAll.bind(this), text: '전체 해제', disabled: false, display: true });
    }

    return contextmenu;
  }),
  //== Life Cycle =======================================
  init() {
    this._super(...arguments);
  },
  onPropertyInit() {
    this._super(...arguments);

    this.setStateProperties(['internalSelectedItems']);

    if (!this.hasState()) {
      this.set('internalSelectedItems', Ember.A([]));
    }
  },
  didInsertElement() {
    this._super(...arguments);

    this.$().attr('tabindex', -1);

    let _selectedItem = this.get('selectedItem');
    let _selectedValue = this.get('selectedValue');
    let _selectedItems = this.get('internalSelectedItems');

    // if (!Ember.isEmpty(this.isEnableHighlight)) {
    //   this.$().addClass('fr-checkbox-list-highlight') ;
    // }

    if (Ember.isEmpty(_selectedValue) && !Ember.isEmpty(_selectedItem) && this._hasSelectedValuePath()) {
      _selectedValue = Ember.get(_selectedItem, this.selectedValuePath);
    }

    if (!Ember.isEmpty(_selectedValue)) {
      this._getcheckbox(_selectedValue).prop('checked', true);
    }

    if (!Ember.isEmpty(_selectedItems) && !this._hasCheckValuePath() && this._hasSelectedValuePath()) {
      _selectedItems.forEach((item) => {
        this._getcheckbox(Ember.get(item, this.selectedValuePath)).prop('checked', true);
      });
    }

    this._getlabels().on('click', this._onLabelClick.bind(this));

    if ( this.get('orientation') === 'vertical') {
      this.$().addClass('vertical') ;
    }
  },
  willDestroyElement() {
    this._super(...arguments);
    this._getlabels().off('click');
  },
  _onLabelClick(e) {
    e.stopPropagation();
  },
  _hasItemsSource() {
    return !Ember.isEmpty(this.get('itemsSource'));
  },
  _hasCheckValuePath() {
    return !Ember.isEmpty(this.checkValuePath);
  },
  _hasSelectedValuePath() {
    return !Ember.isEmpty(this.selectedValuePath);
  },
  actions: {
    changedAction(addItem, e) {

      if (Ember.isEmpty(e) || Ember.isEmpty(e.target)) {
        return;
      }

      const checked = this.$(e.target).is(':checked');

      if (!Ember.isEmpty(this.checkValuePath)) {
        Ember.set(addItem, this.checkValuePath, checked);
      }

      this.internalItemChanged = true;

      if (this.useSelectedValue === true) {
        this.set('selectedValue', Ember.get(addItem, this.selectedValuePath));
      } else {
        this.set('selectedItem', addItem);
      }

      this._onSelectedChanged(addItem);
    }
  }
});