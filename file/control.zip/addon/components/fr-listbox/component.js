import Ember from 'ember';
import Selector from '../fr-selector/component';
import ContextMenuMixin from '../../mixins/contextmenu-mixin';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

// ListBox
export default Selector.extend(ContextMenuMixin, StatefulComponentMixin, {
  layout: Ember.computed(function () {
    let _itemTemplate = this.get('itemTemplate');

    if (Ember.isEmpty(_itemTemplate)) {
      _itemTemplate = "{{get dataItem displayMemberPath }}";
    }

    return Ember.HTMLBars.compile(`{{_observedProperty1}}<div class="scrollbar-macosx"><ul>{{#each _itemsSource as |dataItem index|}}
                                    <li class="{{fr-html-safe-helper itemClass (if (fr-array-includes-helper _computedSelectedItems dataItem) selectedClass '')}}" style="{{fr-html-safe-helper itemStyle}}" onclick={{action 'itemClick' dataItem}}>
                                      ${_itemTemplate}
                                    </li>
                                  {{/each}}</ul></div>`);
  }),
  tagName: 'div',
  classNames: [ 'fr-listbox' ],
  //== Public Properties =====================================
  disabled: false,
  itemTemplate: '',
  selectionMode: 'single',
  itemClass: null,
  itemStyle: null,
  selectedClass: 'fr-listbox-select',
  useSelectedValue: false,
  displayMemberPath: null,
  selectedValuePath: null,
  selectedItems: Ember.computed.oneWay('_selectedItems').readOnly(),
  //relativeSource: null,
  // == Computed Properties ==================================
  //_internalItems: null,
  _selectedItems: null,

  _computedSelectedItems: Ember.computed('_selectedItems.[]', function () {
    return this.get('_selectedItems').map(function (data) {
      return data;
    });
  }).readOnly(),
  _itemsSource: Ember.computed('itemsSource.[]', function () {
    const itemsSource = this.get('itemsSource');

    if (Ember.isArray(itemsSource)) {
      Ember.run.once(this, '_itemsSourceChange', itemsSource);

      return itemsSource;
    }
    Ember.run.once(this, '_itemsSourceChange', Ember.A());

    return Ember.A();
  }).readOnly(),
  _observedProperty1: Ember.computed('useSelectedValue', 'selectedValuePath', 'selectedValue', 'selectionMode', 'selectedItem', function () {
    const _itemsSource = this.get('_itemsSource'), lastSelectedItem = this.get('_selectedItems.lastObject');
    let selectedItem = this.get('selectedItem');

    if (this.get('useSelectedValue')) {
      if (!Ember.isNone(this.get('selectedValue'))) {
        selectedItem = _itemsSource.findBy(this.get('selectedValuePath'), this.get('selectedValue'));
      } else {
        selectedItem = null;
      }
    }
    if ((lastSelectedItem && selectedItem && lastSelectedItem !== selectedItem) || (!lastSelectedItem && selectedItem)) {
      this._selectItem(_itemsSource.indexOf(selectedItem), this.get('selectionMode') === 'single');
    } else if (lastSelectedItem && !selectedItem) {
      this._deselectItem(_itemsSource.indexOf(lastSelectedItem));
    }

    return null;
  }).readOnly(),
  _itemsSourceChange(_itemsSource) {
    const _selectedItems = this.get('_selectedItems'), selectedItemsGarbage = Ember.A();

    if (Ember.isEmpty(_itemsSource) && !Ember.isEmpty(_selectedItems)) {
      _selectedItems.clear();
      Ember.run.once(this, '_selectionChange');
    } else {
      _selectedItems.forEach(function (item) {
        if (!_itemsSource.includes(item)) {
          selectedItemsGarbage.addObject(item);
        }
      });
      if (!Ember.isEmpty(selectedItemsGarbage)) {
        _selectedItems.removeObjects(selectedItemsGarbage);
        Ember.run.once(this, '_selectionChange');
      }
    }
  },
  _selectItem(index, clear) {
    const _itemsSource = this.get('_itemsSource'), _selectedItems = this.get('_selectedItems'), item = _itemsSource.objectAt(index);

    if (!Ember.isNone(item) && !_selectedItems.includes(item)) {
      if (clear) {
        _selectedItems.clear();
      }
      _selectedItems.addObject(item);
      Ember.run.once(this, '_selectionChange');
    }
  },
  _deselectItem(index) {
    const _itemsSource = this.get('_itemsSource'), _selectedItems = this.get('_selectedItems'), item = _itemsSource.objectAt(index);

    if (!Ember.isNone(item) && _selectedItems.includes(item)) {
      _selectedItems.removeObject(item);
      Ember.run.once(this, '_selectionChange');
    }
  },
  _selectionChange() {
    const _itemsSource = this.get('_itemsSource'), lastSelectedItem = this.get('_selectedItems.lastObject');
    let selectedItem = this.get('selectedItem');

    if (this.get('useSelectedValue')) {
      if (!Ember.isNone(this.get('selectedValue'))) {
        selectedItem = _itemsSource.findBy(this.get('selectedValuePath'), this.get('selectedValue'));
      } else {
        selectedItem = null;
      }
    }
    if ((selectedItem && lastSelectedItem && selectedItem !== lastSelectedItem) || (!selectedItem && lastSelectedItem)) {
      if (this.get('useSelectedValue')) {
        this.set('selectedValue', Ember.get(lastSelectedItem, this.get('selectedValuePath')));
      } else {
        this.set('selectedItem', lastSelectedItem);
      }
    } else if (selectedItem && !lastSelectedItem) {
      if (this.get('useSelectedValue')) {
        this.set('selectedValue', null);
      } else {
        this.set('selectedItem', null);
      }
    }

    if (this.hasLoaded === true) {
      this._raiseEvents('selectedChanged', { source: this, addItems: this.get('selectedItems') });
    }
  },
  /*
  _selectedItem: Ember.computed('useSelectedValue', 'selectedItem', 'selectedValue', function () {
    let _selectedItem = this.get('selectedItem');

    if (this.get('useSelectedValue')) {
      _selectedItem = this.get('_itemsSource').findBy(this.get('selectedValuePath'), this.get('selectedValue'));
    }
    Ember.run.once(this, this._selectedItemChange, _selectedItem);

    return _selectedItem;

    this.set('_internalItems', Ember.A([]));

    if (!Ember.isEmpty(this.selectedClass)) {
      this._getlis().removeClass(this.selectedClass);
    }

    this._addItem(dataItem);

    if (this.hasLoaded === true) {
      if (this.get('_isEventBubbling') === true) {
        this._raiseSelectedEventChanged(this._getInternalItems());
      }
    }

    this.set('_isEventBubbling', true);

    return '';
  }).readOnly(),
  */
  // == Public Methods =======================================
  scrollIntoView(dataItem) {
    const itemsSource = this.get('itemsSource');

    if (itemsSource.includes(dataItem)) {
      let $target = this.$(`div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx > ul > li`).eq(itemsSource.indexOf(dataItem)),
      $scrollable = this.$('div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx');

      if ($target.length > 0) {
        $scrollable.scrollTop($scrollable.scrollTop() + $target.offset().top - $scrollable.offset().top);
      }
      $target = null;
      $scrollable = null;
    }
  },
  // == Private Methods ======================================
  /*
  _getlis() {
    return this.$('> ul > li');
  },
  _getli(indexAt) {
    return this.$(`> ul > li[data-idx='${indexAt}']`);
  },
  _addItem(dataItem) {
    if (!Ember.isEmpty(dataItem) && !Ember.isEmpty(this.itemsSource)) {

      const indexAt = this.itemsSource.indexOf(dataItem);

      if (this._getInternalItems().indexOf(dataItem) > -1) {
        if (!Ember.isEmpty(this.selectedClass)) {
          this._getli(indexAt).removeClass(this.selectedClass);
        }
        this._getInternalItems().removeObject(dataItem);
      } else {
        if (!Ember.isEmpty(this.selectedClass)) {
          this._getli(indexAt).addClass(this.selectedClass);
        }
        this._getInternalItems().pushObject(dataItem);
      }
    }
  },
  _getInternalItems() {

    const items = this.get('_internalItems');

    if (Ember.isNone(items)) {
      this.set('_internalItems', Ember.A([]));
    }

    return this.get('_internalItems');
  },
  _raiseSelectedEventChanged(items) {
    Ember.run.once(this, function () {
      this._raiseEvents('selectedChanged', { 'source': this, 'addItems': items });
    }.bind(this));
  },
  _selectionMode() {
    return this.get('selectionMode');
  },
  _isSingleMode() {
    return this._selectionMode() === 'single';
  },
  _isMultipleMode() {
    return this._selectionMode() === 'multiple';
  },
  _isExtendedMode() {
    return this._selectionMode() === 'extended';
  },
  _hasSelectedValue() {
    return this.get('useSelectedValue');
  },
  _getItem() {

    if (this._hasSelectedValue() === true) {
      const source = this.get('itemsSource');

      if (Ember.isEmpty(source)) {
        return null;
      }

      return this.get('itemsSource').findBy(this.selectedValuePath, this.get('selectedValue'));
    }

    return this.get('selectedItem');
  },
  _setItem(newValue) {
    this.set('selectedItem', newValue);
  },
  _getValue() {
    return this.get('selectedValue');
  },
  _setValue(newValue) {
    this.set('selectedValue', newValue);
  },
  */
  // == Lifecycle Hooks ======================================
  onPropertyInit() {
    this._super(...arguments);

    this.setStateProperties([ '_selectedItems' ]);

    if (!this.hasState()) {
      this.set('_selectedItems', Ember.A());
    }
  },
  didInsertElement() {
    this._super(...arguments);

    this.$('.scrollbar-macosx:not(.scroll-content)').scrollbar();
    /*
    const source = this.get('itemsSource');
    const items = this.get('_internalItems');

    if (!Ember.isEmpty(this.selectedClass) && !Ember.isEmpty(items) && !Ember.isEmpty(source)) {
      items.forEach((item) => {
        this._getli(this.itemsSource.indexOf(item)).addClass(this.selectedClass);
      });
    }

    this.$().on('scrollintoview', this.actions.onScrollIntoViewAction.bind(this));
    */
  },
  willDestroyElement() {
    this._super(...arguments);

    this.$('.scrollbar-macosx.scroll-content').scrollbar('destroy');
    /*
    this.set('relativeSource', null);
    this.$().empty().scrollbar('destroy').off('scrollintoview');
    */
  },
  /*
  _onMulitpleSelected(item) {
    this._addItem(item);

    this._raiseSelectedEventChanged(this._getInternalItems());
  },
  _onSingleSelected(item) {
    if (this._hasSelectedValue() === true) {
      this._setValue(Ember.get(item, this.selectedValuePath));
    } else {
      this._setItem(item);
    }
  },
  */
  // == Actions ============================================================
  actions: {
    itemClick(dataItem, event) {
      const selectionMode = this.get('selectionMode'), _itemsSource = this.get('_itemsSource'), _selectedItems = this.get('_selectedItems');

      if (selectionMode === 'single') {
        this._selectItem(_itemsSource.indexOf(dataItem), true);
      } else if (selectionMode === 'multiple') {
        if (_selectedItems.includes(dataItem)) {
          this._deselectItem(_itemsSource.indexOf(dataItem));
        } else {
          this._selectItem(_itemsSource.indexOf(dataItem), false);
        }
      } else if (selectionMode === 'extended') {
        if (event.ctrlKey) {
          if (_selectedItems.includes(dataItem)) {
            this._deselectItem(_itemsSource.indexOf(dataItem));
          } else {
            this._selectItem(_itemsSource.indexOf(dataItem), false);
          }
        } else {
          this._selectItem(_itemsSource.indexOf(dataItem), true);
        }
      }
    },
    /*
    onScrollIntoViewAction(e, data) {

      let item = null;

      if (typeof data === 'object') {
        item = data;
      } else {
        item = this.get('itemsSource').findBy(this.selectedValuePath, data);
      }

      this.scrollIntoView(item);
    },
    onSelectedAction(item, e) {
      const isExtendedMode = this._isExtendedMode() === true && e.ctrlKey === true ;

      if (this._isMultipleMode() === true || isExtendedMode === true) {
        this._onMulitpleSelected(item);
      } else {
        this._onSingleSelected(item);
      }
    }
    */
  }
});
