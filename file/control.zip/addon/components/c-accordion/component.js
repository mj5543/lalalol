import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';
import ContextMenuMixin from '../../mixins/contextmenu-mixin';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

// Accordion
export default Control.extend(ContextMenuMixin, StatefulComponentMixin, {
  layout,
  tagName: 'div',
  classNames: ['c-accordion', 'wrap-accordion'],
  // == Private Properties=====================================================
  _wasAccordionItem: null,
  _expandedItems: null,
  // == Public Properties======================================================
  selectedName: null,
  collapsible: true,
  // == Public Events =========================================================
  onActivate: null,
  beforeActivate: null,
  _accordionGuid: Ember.computed.readOnly('componentGuid'),
  _observedProperty: Ember.computed('selectedName', function () {
    Ember.run.scheduleOnce('afterRender', this, '_activateSelectedItem');
  }).readOnly(),
  _activateSelectedItem() {
    if (!Ember.isNone(this.get('selectedName'))) {
      const $target = this.$(`> div[name="${this.get('selectedName')}"]`);

      if ($target.length > 0) {
        let component = this._getComponent($target);
  
        Ember.set(component, 'hasContentLoaded', true);
        this._activate(component);
        component = null;
      }
    }
  },
  _wasStateUpdate() {
    if (!Ember.isNone(this._wasAccordionItem)) {
      this._wasAccordionItem.$().removeClass('on');
      // this._wasAccordionItem.$('.c-accordionitem-content').slideUp(300);
      this._wasAccordionItem.$('.c-accordionitem-content').css('height', '0');
      this._wasAccordionItem.set('hasExpanded', false);
    }
  },
  _close(component) {
    // sender.$('.c-accordionitem-content').slideUp(300);
    component.$('.c-accordionitem-content').css('height', '0');
  },
  _open(component) {
    component.$().addClass('on');
    component.set('hasExpanded', true);
    // sender.$('.c-accordionitem-content').slideDown(duration);
    Ember.run.next(this, function () {
      if (!this.get('isDestroying') && !this.get('isDestroyed')) {
        if(component.get('hasContentLoaded')) {
          component.$('.c-accordionitem-content').css('height', component.$('.c-accordionitem-content').prop('scrollHeight'));
        }
        this.get('_expandedItems').addObject(Ember.get(component, 'getName'));
      }
      component = null;
    });
  },
  _activate(component) {
    let args = { source: this, originalSource: component, cancel: false };

    this._raiseEvents('onBeforeActivate', args);
    if (!args.cancel) {
      const isActive = component.$().hasClass('on');
  
      if (this.collapsible && isActive) {
        this._wasStateUpdate();
        this.get('_expandedItems').clear();
      } else if (this.collapsible && !isActive) {
        this._wasStateUpdate();
        this.get('_expandedItems').clear();
        this._open(component);
      } else if (!this.collapsible && isActive) {
        component.$().removeClass('on');
        component.set('hasExpanded', false);
        // component.$('.c-accordionitem-content').slideUp(300);
        component.$('.c-accordionitem-content').css('height', '0');
        this.get('_expandedItems').removeObject(Ember.get(component, 'getName'));
      } else {
        this._open(component);
      }
      this.set('_wasAccordionItem', component);
      this._raiseEvents('onActivate', { source: this, originalSource: component });
    }
    this._releaseObjectProperty(args);
    args = null;
  },
  onPropertyInit() {
    this._super(...arguments);
    this.setStateProperties(['_expandedItems']);

    if (!this.hasState()) {
      this.set('_expandedItems', Ember.A());
    }
  },
  click(event) {
    const $target = this.$(event.target).closest(`.${this.get('_accordionGuid')}-accordionitem-header`);

    if ($target.length > 0) {
      let component = this._getComponent($target);

      if (this.get('selectedName') === Ember.get(component, 'getName')) {
        this._activate(component);
      } else {
        this.set('selectedName', Ember.get(component, 'getName'));
      }
      component = null;
    }
  },
  actions: {
    itemLoaded(event) {
      if (this.get('_expandedItems').includes(Ember.get(event.source, 'getName'))) {
        Ember.set(event.source, 'hasContentLoaded', true);
        this._open(event.source);
      }
    },
  }
});