import Ember from 'ember';
import layout from './template';

export default Ember.Component.extend({
  layout,
  classNames: ['c-positioned-container', 'scroll-observer-contents'],
  attributeBindings: ['_internalHtmlSafeStyle:style'],
  ownerElement: null,
  targetElement: null,
  targetAttachment: 'middle center',
  attachment: 'middle center',
  placeInArea: false,
  popContains: false,
  offsetTop: 0,
  offsetLeft: 0,
  width: 0,
  height: 0,
  componentGuid: Ember.computed(function () {
    return Ember.guidFor(this);
  }).readOnly(),
  _internalHtmlSafeStyle: Ember.String.htmlSafe('display:none !important;'),
  _observedProperty01: Ember.computed('targetElement', 'targetAttachment', 'attachment', 'width', 'height', 'offsetTop', 'offsetLeft', function() {
    Ember.run.once(this, '_updateTargetAttachment');
  }),
  didInsertElement() {
    this._super(...arguments);
    this.$().on('_getComponent', function (event, param) {
      param.component = this;
      event.stopPropagation();
      event.preventDefault();
    }.bind(this));
    Ember.$(window).on(`scroll.c-positioned-container-${Ember.guidFor(this)}`, this._updateTargetAttachment.bind(this))
      .on(`resize.c-positioned-container-${Ember.guidFor(this)}`, this._updateTargetAttachment.bind(this))
      .on(`orientationchange.c-positioned-container-${Ember.guidFor(this)}`, this._updateTargetAttachment.bind(this))
      .on(`update.c-positioned-container-${Ember.guidFor(this)}`, this._updateTargetAttachment.bind(this));
    Ember.$(document).on(`mousedown.c-positioned-container-${Ember.guidFor(this)}`, this._handleRootMouseDown.bind(this));
    this.$('> .wormhole-parent > .scrollbar-macosx:not(.scroll-content)').scrollbar({
      'onUpdate': function(el) {
        Ember.run.once(this, '_updateLayout', el.prop('clientWidth'), el.prop('clientHeight'));
      }.bind(this),
    });
    this.$('.scrollbar-macosx:not(.scroll-content)').scrollbar();
    if (this.get('popContains')) {
      Ember.run.once(this, '_activate');
    }
  },
  willDestroyElement() {
    this.$().off('_getComponent');
    Ember.$(window).off(`scroll.c-positioned-container-${Ember.guidFor(this)}`)
      .off(`resize.c-positioned-container-${Ember.guidFor(this)}`)
      .off(`orientationchange.c-positioned-container-${Ember.guidFor(this)}`)
      .off(`update.c-positioned-container-${Ember.guidFor(this)}`);
    Ember.$(document).off(`mousedown.c-positioned-container-${Ember.guidFor(this)}`);
    this.$('.scrollbar-macosx').scrollbar('destroy');
    this._super(...arguments);
  },
  mouseDown(event) {
    if (this.get('popContains')) {
      Ember.run.once(this, '_activate');
    }
  },
  keyDown(event) {
    this._raiseEvents('onInternalKeyDown', {
      source: this,
      originalEvent: event
    });
    this._raiseEvents('onKeyDown', {
      source: this,
      originalEvent: event
    });
  },
  focusOut(event) {
    this._raiseEvents('onInternalFocusOut', {
      source: this,
      originalEvent: event
    });
    this._raiseEvents('onFocusOut', {
      source: this,
      originalEvent: event
    });
  },
  _activate() {
    let wormholeParent = this.$().closest('.wormhole-parent'), zIndex = 10001;

    if (wormholeParent.attr('data-top-index')) {
      zIndex = parseInt(wormholeParent.attr('data-top-index')) + 1;
    }
    this.$('> .wormhole-parent').css('z-index', zIndex);
    wormholeParent.attr('data-top-index', zIndex);
    wormholeParent = null;
  },
  _updateLayout(width, height) {
    if (width !== this.width) {
      this.set('width', width);
    }
    if (height !== this.height) {
      this.set('height', height);
    }
  },
  /* _updateScrollableAncestors() {
    const targetElement = this.get('targetElement'), _beforeTargetElement = this.get('_beforeTargetElement');

    if (!Ember.$(targetElement).is(Ember.$(_beforeTargetElement))) {
      this._getScrollableAncestors(_beforeTargetElement).forEach((el) => {
        Ember.$(el).off(`scroll.c-positioned-container-${Ember.guidFor(this)}`);
      });
      this._getScrollableAncestors(targetElement).forEach((el) => {
        Ember.$(el).on(`scroll.c-positioned-container-${Ember.guidFor(this)}`, this._updateTargetAttachment.bind(this));
      });
      this.set('_beforeTargetElement', targetElement);
    }
  }, */
  _calculatePosition(targetElement, targetAttachment, attachment, top, left, width, height, targetWidth, targetHeight) {
    const placeInArea = this.get('placeInArea'), targetOffset = Ember.$(targetElement).offset(), wormholeOffset = this.$().closest('.wormhole-parent').offset(),
      scrollLeft = targetOffset.left - Ember.$(window).scrollLeft() - wormholeOffset.left, scrollTop = targetOffset.top - Ember.$(window).scrollTop() - wormholeOffset.top,
      fullWidth = !placeInArea ? Ember.$(window).width() : this.$().closest('.wormhole-parent').width() - 3, fullHeight = !placeInArea ? Ember.$(window).height() : this.$().closest('.wormhole-parent').height() - 3,
      minTop = !placeInArea ? Math.min(0, wormholeOffset.top * -1) : 0, minLeft = !placeInArea ? Math.min(0, wormholeOffset.left * -1) : 0;
    let targetAttachmentTop = targetAttachment.split(' ')[0], attachmentTop = attachment.split(' ')[0], targetAttachmentLeft = targetAttachment.split(' ')[1],
      attachmentLeft = attachment.split(' ')[1], positionTop = top, positionLeft = left;

    if (targetAttachmentTop === 'bottom' && attachmentTop === 'top' && fullHeight < scrollTop + top + targetHeight + height && top + height < scrollTop) {
      targetAttachmentTop = 'top';
      attachmentTop = 'bottom';
    }
    switch (targetAttachmentTop) {
      case 'top': positionTop += scrollTop;
        break;
      case 'middle': positionTop += scrollTop + targetHeight / 2;
        break;
      case 'bottom': positionTop += scrollTop + targetHeight;
        break;
    }
    switch (targetAttachmentLeft) {
      case 'left': positionLeft += scrollLeft;
        break;
      case 'center': positionLeft += scrollLeft + targetWidth / 2;
        break;
      case 'right': positionLeft += scrollLeft + targetWidth;
        break;
    }
    switch (attachmentTop) {
      case 'top': positionTop -= 0;
        break;
      case 'middle': positionTop -= height / 2;
        break;
      case 'bottom': positionTop -= height;
        break;
    }
    switch (attachmentLeft) {
      case 'left': positionLeft -= 0;
        break;
      case 'center': positionLeft -= width / 2;
        break;
      case 'right': positionLeft -= width;
        break;
    }

    return `top:${Math.max(minTop, Math.min(fullHeight - height, positionTop))}px;left:${Math.max(minLeft, Math.min(fullWidth - width, positionLeft))}px;`;
  },
  /* _getScrollableAncestors(targetElement) {
    const scrollableAncestors = [];

    if (document.body.contains(targetElement)) {
      let nextScrollable = this._getScrollParent(targetElement);

      while (nextScrollable && nextScrollable.tagName.toUpperCase() !== 'BODY' && nextScrollable.tagName.toUpperCase() !== 'HTML') {
        scrollableAncestors.push(nextScrollable);
        nextScrollable = this._getScrollParent(nextScrollable.parentNode);
      }
    }
    return scrollableAncestors;
  }, */
  /* _getScrollParent(targetElement) {
    let style = window.getComputedStyle(targetElement);
    const excludeStaticParent = style.position === "absolute", overflowRegex = /(auto|scroll)/;

    if (style.position === "fixed") {
      return document.body;
    }
    for (let parent = targetElement; parent = parent.parentElement;) {
      style = window.getComputedStyle(parent);
      if (excludeStaticParent && style.position === "static") {
        continue;
      }
      if (overflowRegex.test(style.overflow + style.overflowY + style.overflowX)) {
        return parent;
      }
    }

    return document.body;
  }, */
  _updateTargetAttachment() {
    if (!this.get('isDestroying') && !this.get('isDestroyed')) {
      const targetElement = this.get('targetElement');

      if (document.body.contains(targetElement)) {
        const targetAttachment = this.get('targetAttachment'), attachment = this.get('attachment'), offsetTop = this.get('offsetTop'), offsetLeft = this.get('offsetLeft'),
        width = this.get('width'), height = this.get('height'), targetWidth = Ember.$(targetElement).outerWidth(), targetHeight = Ember.$(targetElement).outerHeight();
        let _internalHtmlSafeStyle = this._calculatePosition(targetElement, targetAttachment, attachment, offsetTop ? offsetTop : 0,
        offsetLeft ? offsetLeft : 0, width, height, targetWidth, targetHeight);

        if (!this.get('_rendered')) {
          Ember.run.cancel(this.get('_changeRendered'));
          this.set('_internalHtmlSafeStyle', Ember.String.htmlSafe(`visibility:hidden !important;${_internalHtmlSafeStyle}`));
          this.set('_changeRendered', Ember.run.later(this, function () {
            if (!this.get('isDestroying') && !this.get('isDestroyed')) {
              this.set('_rendered', true);
              this.set('_internalHtmlSafeStyle', Ember.String.htmlSafe(`${_internalHtmlSafeStyle}`));
              Ember.run.schedule('afterRender', this, function () {
                this._raiseEvents('onInternalShown', { source: this, });
              });
            }
            _internalHtmlSafeStyle = null;
          }, 200));
        } else {
          this.set('_internalHtmlSafeStyle', Ember.String.htmlSafe(_internalHtmlSafeStyle));
        }
      }
    }
  },
  _handleRootMouseDown(event) {
    if (!this.element.contains(event.target)) {
      this._raiseEvents('onMouseDownToOutside', event);
    }
  },
  _raiseEvents(name, args) {
    if (!Ember.isNone(this.get(name))) {
      if (Ember.isArray(args)) {
        return this.get(name)(...args);
      } else {
        return this.get(name)(args);
      }
    }
  },
});
