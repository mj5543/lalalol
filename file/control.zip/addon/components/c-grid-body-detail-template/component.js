import Ember from 'ember';
import layout from './template';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

const { computed } = Ember;

export default Ember.Component.extend(StatefulComponentMixin, {
  layout,
  tagName: 'tr',
  classNameBindings: ['_gridBodyDetailClass'],
  attributeBindings: ['rowIndex:data-body-detail-row-index'],
  _gridBodyDetailClass: computed(function () {
    return `${this.get('_gridGuid')}-body-detail detail`;
  }).readOnly(),
  didInsertElement() {
    this._super(...arguments);
    this.$().on('_getComponent', function (event, param) {
      param.component = this;
      event.stopPropagation();
      event.preventDefault();
    }.bind(this));
  },
  willDestroyElement() {
    this.$().off('_getComponent');
    this._super(...arguments);
  },
});