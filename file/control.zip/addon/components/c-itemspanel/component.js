import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';

export default Control.extend({
  layout,
  tagName: 'div',
  classNames: ['c-itemspanel'],
  classNameBindings: ['itemspanelClass'],
  itemspanelClass: Ember.computed('parentGuid', function () {
    return `${this.get('parentGuid')}-itemspanel`;
  }).readOnly(),
  _observedProperty01: Ember.computed('targetElement', 'maxDropDownHeight', function () {
    Ember.run.schedule('afterRender', this, function () {
      this.$().css('min-width', `${Ember.$(this.get('targetElement')).outerWidth()}px`);
      if (!Ember.isNone(this.get('maxDropDownWidth'))) {
        this.$().css('max-width', `${this.get('maxDropDownWidth')}px`);
      }
      if (!Ember.isNone(this.get('maxDropDownHeight'))) {
        this.$('.items-panel').css('max-height', `${this.get('maxDropDownHeight')}px`);
      }
    });
  }).readOnly(),
  didInsertElement() {
    this._super(...arguments);
    this.$('.scrollbar-macosx:not(.scroll-content)').scrollbar();
  },
  willDestroyElement() {
    this.$('.scrollbar-macosx').scrollbar('destroy');
    this._super(...arguments);
  },
  mouseDown(event) {
    if (!this.element.contains(this.$(event.target).closest(':focusable').get(0))) {
      event.preventDefault();
    }
  },
});