import Ember from 'ember';
import layout from './template';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';
import ContextMenuMixin from '../../mixins/contextmenu-mixin';

const { computed, guidFor } = Ember;

export default Ember.Component.extend(StatefulComponentMixin, ContextMenuMixin, {
  tagName: 'div',
  classNames: [ 'fr-grid', 'tbl-grid' ],
  attributeBindings: [ 'htmlSafeStyle:style', 'tabindex' ],
  layout,

  //public Properties

  columns: null,
  itemsSource: null,
  width: null,
  height: null,
  selectedItem: null,
  groupOption: null,
  style: null,
  showRowIndex: false,
  editable: false,
  sortable: false,
  showHead: true,
  reorderingColumn: false,
  reorderingRow: false,
  useDetailRow: false,
  useUiVirtualization: true,
  autoRowHeight: false,
  fillLastColumn: false,
  selectionType: 'row',
  selectionMode: 'single',
  sortingType: 'single',
  detailRowExpandType: 'single',
  groupRowExpandType: 'single',
  columnResizeType: 'fit',
  basicWidth: 35,
  headLineHeight: 30,
  bodyLineHeight: 35,
  footLineHeight: 35,
  detailRowHeight: 35,

  //public readonly Properties

  bindingColumns: computed.oneWay('_bindingColumns').readOnly(),
  selectedItems: computed.oneWay('_sortedSelectedItems').readOnly(),
  selectedCells: computed.oneWay('_sortedSelectedCells').readOnly(),
  detailRowItems: computed.oneWay('_sortedDetailRowItems').readOnly(),
  groupRowValues: computed.oneWay('_sortedgroupRowValues').readOnly(),
  items: computed.oneWay('_items').readOnly(),

  //public Methods

  getCurrentCell: function () {
    return this._getCurrentCell();
  },

  getItemIndex: function (item) {
    if (typeof item === 'object') {
      return this._getItemIndex(item);
    }

    return -1;
  },

  getColumnIndex: function (column) {
    if (typeof column === 'object') {
      return this._getColumnIndex(column);
    }

    return -1;
  },

  getItem: function (rowIndex) {
    if (typeof rowIndex === 'number') {
      return this._getItem(rowIndex);
    }

    return null;
  },

  getColumn: function (cellIndex) {
    if (typeof cellIndex === 'number') {
      return this._getColumn(cellIndex);
    }

    return null;
  },

  focusCell: function (itemParam, columnParam) {
    return this._focusCell(typeof itemParam === 'object' ? this._getItemIndex(itemParam) :
      typeof itemParam === 'number' ? itemParam : -1,
        typeof columnParam === 'object' ? this._getColumnIndex(columnParam) :
          typeof columnParam === 'number' ? columnParam : -1);
  },

  editingCell: function (itemParam, columnParam) {
    return this._editingCell(typeof itemParam === 'object' ? this._getItemIndex(itemParam) :
      typeof itemParam === 'number' ? itemParam : -1,
        typeof columnParam === 'object' ? this._getColumnIndex(columnParam) :
          typeof columnParam === 'number' ? columnParam : -1);
  },

  selectRow: function (itemParam) {
    this._selectRow(typeof itemParam === 'object' ? this._getItemIndex(itemParam) :
      typeof itemParam === 'number' ? itemParam : -1);
  },

  selectRows: function (itemsParam) {
    if (Ember.isArray(itemsParam)) {
      this._selectRows(itemsParam.map(function (itemParam) {
        return typeof itemParam === 'object' ? this._getItemIndex(itemParam) :
          typeof itemParam === 'number' ? itemParam : -1;
      }.bind(this)));
    }
  },

  deselectRow: function (itemParam) {
    this._deselectRow(typeof itemParam === 'object' ? this._getItemIndex(itemParam) :
      typeof itemParam === 'number' ? itemParam : -1);
  },

  deselectRows: function (itemsParam) {
    if (Ember.isArray(itemsParam)) {
      this._deselectRows(itemsParam.map(function (itemParam) {
        return typeof itemParam === 'object' ? this._getItemIndex(itemParam) :
          typeof itemParam === 'number' ? itemParam : -1;
      }.bind(this)));
    }
  },

  selectCell: function (itemParam, columnParam) {
    return this._selectCell(typeof itemParam === 'object' ? this._getItemIndex(itemParam) :
      typeof itemParam === 'number' ? itemParam : -1,
        typeof columnParam === 'object' ? this._getColumnIndex(columnParam) :
          typeof columnParam === 'number' ? columnParam : -1);
  },

  deselectCell: function (itemParam, columnParam) {
    return this._deselectCell(typeof itemParam === 'object' ? this._getItemIndex(itemParam) :
      typeof itemParam === 'number' ? itemParam : -1,
        typeof columnParam === 'object' ? this._getColumnIndex(columnParam) :
          typeof columnParam === 'number' ? columnParam : -1);
  },

  selectAll: function () {
    this._selectAll();
  },

  deselectAll: function () {
    this._deselectAll();
  },

  setScrollLeft: function (x) {
    this._setScrollLeft(x);
  },

  setScrollTop: function (y) {
    this._setScrollTop(y);
  },

  expandGroupRowByGroupValue: function (groupValue) {
    this._expandGroupRowByGroupValue(groupValue);
  },

  expandGroupRowByGroupIndex: function (groupIndex) {
    const groupItem = this.get('_groupItems').objectAt(groupIndex);

    if (!Ember.isNone(groupItem)) {
      this._expandGroupRowByGroupValue(Ember.get(groupItem, 'groupValue'));
    }
  },

  expandAllGroupRows: function () {
    this._expandAllGroupRows();
  },

  collapseGroupRowByGroupValue: function (groupValue) {
    this._collapseGroupRowByGroupValue(groupValue);
  },

  collapseGroupRowByGroupIndex: function (groupIndex) {
    const groupItem = this.get('_groupItems').objectAt(groupIndex);

    if (!Ember.isNone(groupItem)) {
      this._collapseGroupRowByGroupValue(Ember.get(groupItem, 'groupValue'));
    }
  },

  collapseAllGroupRows: function () {
    this._collapseAllGroupRows();
  },

  expandDetailRow: function (itemParam) {
    this._expandDetailRow(typeof itemParam === 'object' ? this._getItemIndex(itemParam) :
      typeof itemParam === 'number' ? itemParam : -1);
  },

  expandAllDetailRows: function () {
    this._expandAllDetailRows();
  },

  collapseDetailRow: function (itemParam) {
    this._collapseDetailRow(typeof itemParam === 'object' ? this._getItemIndex(itemParam) :
      typeof itemParam === 'number' ? itemParam : -1);
  },

  collapseAllDetailRows: function () {
    this._collapseAllDetailRows();
  },

  closeHeadMenu: function () {
    this._closeHeadMenu();
  },

  copyToClipboard: function() {
    return this._copyToClipboard();
  },

  exportToExcel: function () {
    return this._exportToExcel();
  },

  getOriginalSource: function (originalEvent) {
    return this._getOriginalSource(originalEvent);
  },

  //public events

  onLoad: null,
  onUnload: null,
  onEditingStart: null,
  onEditingEnd: null,
  onSelectionChange: null,
  onCellClick: null,
  onCellDoubleClick: null,
  onDetailRowItemsChange: null,
  onGroupRowValuesChange: null,
  onColumnDragStart: null,
  onColumnDragEnd: null,
  onItemDragStart: null,
  onItemDragEnd: null,
  onScroll: null,
  onBeforeKeyDown: null,
  onBeforeMouseDown: null,
  onBeforeClick: null,
  onBeforeDoubleClick: null,
  onBeforeFocusIn: null,
  onBeforeFocusOut: null,

  //private contents

  _startedCell: null,
  _selectedItems: null,
  _selectedCells: null,
  _detailRowItems: null,
  _groupRowValues: null,
  _sortingColumns: null,
  _targetElement: null,
  _virtualizationRowChangeQueue: null,
  _virtualizationColumnChangeQueue: null,
  _beforeKeyEvent: null,
  _hasHeadTemplate: true,
  _hasBodyTemplate: true,
  _hasFootTemplate: true,
  _isSyncingUnlockBodyScroll: false,
  _isSyncingLockBodyScroll: false,
  _isSyncingUnlockHeadScroll: false,
  _isSyncingUnlockFootScroll: false,
  _keySpeed: 50,
  _scrollLeft: 0,
  _scrollTop: 0,
  _bodyUnlockBlockWidth: 0,
  _bodyUnlockBlockHeight: 0,
  _destinationElementId: 'fr-wormhole-container',

  _i18n: computed.oneWay('fr_I18nService').readOnly(),
  _columns: computed.oneWay('columns').readOnly(),
  _itemsSource: computed.oneWay('itemsSource').readOnly(),
  _rowSelectionType: computed.equal('selectionType', 'row').readOnly(),
  _checkboxSelectionType: computed.equal('selectionType', 'checkbox').readOnly(),
  _itemSelectionType: computed.or('_rowSelectionType', '_checkboxSelectionType').readOnly(),
  _singleSelectionMode: computed.equal('selectionMode', 'single').readOnly(),
  _multiSelectionMode: computed.equal('selectionMode', 'multi').readOnly(),
  _checkboxMultiSelectionType: computed.and('_checkboxSelectionType', '_multiSelectionMode').readOnly(),
  _itemSingleSelectionType: computed.and('_itemSelectionType', '_singleSelectionMode').readOnly(),
  _useSelectedItem: computed.and('_itemSingleSelectionType', '_isAttrsSelectedItem').readOnly(),
  _fixedRowHeight: computed.not('autoRowHeight').readOnly(),
  _hasNotGroupOption: computed.not('_hasGroupOption').readOnly(),
  _fixedAndNotGroupGrid: computed.and('_fixedRowHeight', '_hasNotGroupOption').readOnly(),
  _activeUiVirtualization: computed.and('useUiVirtualization', '_fixedAndNotGroupGrid').readOnly(),
  _sortedItems: computed.sort('_unsortedItems', '_sortingParams').readOnly(),

  htmlSafeStyle: computed('style', 'width', 'height', function () {
    if (Ember.isNone(this.get('style'))) {
      return Ember.String.htmlSafe((Ember.isNone(this.get('width')) ? `width:100%;` : `width:${this.get('width')}px;`)
      + (Ember.isNone(this.get('height')) ? `height:auto;` : `height:${this.get('height')}px;`));
    }

    return Ember.String.htmlSafe(this.get('style'));
  }),

  _gridGuid: computed(function () {
    return guidFor(this);
  }).readOnly(),

  _isAttrsSelectedItem: computed(function () {
    return !Ember.isNone(this.attrs.selectedItem);
  }).readOnly(),

  _headHeight: computed('showHead', 'headLineHeight', '_headRows.[]', function () {
    if (this.get('showHead')) {
      const headLineHeight = this.get('headLineHeight'), rowCount = this.get('_headRows.length');

      if (rowCount > 0) {
        return headLineHeight * rowCount;
      }

      return headLineHeight;
    }

    return 0;
  }).readOnly(),

  _footHeight: computed('_hasFootTemplate', 'footLineHeight', function () {
    if (this.get('_hasFootTemplate')) {
      return this.get('footLineHeight');
    }

    return 0;
  }).readOnly(),

  _handleWidth: computed('_checkboxSelectionType', 'showRowIndex', 'reorderingRow', 'useDetailRow', 'basicWidth', function () {
    const basicWidth = this.get('basicWidth');

    return (this.get('_checkboxSelectionType') ? basicWidth : 0) + (this.get('showRowIndex') ? basicWidth : 0) +
    (this.get('reorderingRow') ? basicWidth : 0) + (this.get('useDetailRow') ? basicWidth : 0);
  }).readOnly(),

  _isMinWidthAllColumns: computed('_bindingColumns.[]', '_bindingColumns.@each.width', function () {
    return this.get('_bindingColumns').rejectBy('width', 10).length === 0;
  }).readOnly(),

  _showHandle: computed('_handleWidth', function () {
    return this.get('_handleWidth') > 0;
  }).readOnly(),

  _isAllChecked: computed('_items.[]', '_selectedItems.[]', function () {
    return this.get('_items.length') === this.get('_selectedItems.length') && this.get('_items.length') > 0;
  }).readOnly(),

  _menuOpen: computed('_targetElement', function () {
    return !Ember.isNone(this.get('_targetElement'));
  }).readOnly(),

  _targetColumn: computed('_targetElement', function () {
    const _targetElement = this.get('_targetElement');

    if (!Ember.isNone(_targetElement)) {
      return this.get('_headRows').objectAt(parseInt(this.$(_targetElement).parent('tr').attr('data-head-row-index')))
      .columns.objectAt(parseInt(this.$(_targetElement).attr('data-head-cell-index')));
    }

    return null;
  }).readOnly(),

  _hasGroupOption: computed('groupOption', function () {
    return !Ember.isNone(this.get('groupOption'));
  }).readOnly(),

  _sortingParams: computed('_sortingColumns.[]', function () {
    return this.get('_sortingColumns').map(function (data) {
      return `${data.column.field}:${data.direction}`;
    });
  }).readOnly(),

  _computedDetailRowItems: computed('_detailRowItems.[]', function () {
    return this.get('_detailRowItems').map(function (data) {
      return data;
    });
  }).readOnly(),

  _sortedDetailRowItems: computed('_detailRowItems.[]', '_items.[]', function () {
    const _detailRowItems = this.get('_detailRowItems'), _items = this.get('_items'), _sortedDetailRowItems = Ember.A();
    let index = -1;

    _detailRowItems.forEach(function (item) {
      index = _items.indexOf(item);
      if (_items.indexOf(Ember.get(_sortedDetailRowItems, 'lastObject')) < index) {
        _sortedDetailRowItems.addObject(item);
      } else {
        for (let i = 0; i < _sortedDetailRowItems.length; i++) {
          if (index < _items.indexOf(_sortedDetailRowItems[i])) {
            _sortedDetailRowItems.insertAt(i, item);
            break;
          }
        }
      }
    });

    return _sortedDetailRowItems;
  }).readOnly(),

  _computedgroupRowValues: computed('_groupRowValues.[]', function () {
    return this.get('_groupRowValues').map(function (data) {
      return data;
    });
  }).readOnly(),

  _sortedgroupRowValues: computed('_groupRowValues.[]', '_groupItems.[]', function () {
    const _groupRowValues = this.get('_groupRowValues'), _groupItems = this.get('_groupItems'), _sortedgroupRowValues = Ember.A();
    let index = -1;

    _groupRowValues.forEach(function (groupValue) {
      index = _groupItems.indexOf(_groupItems.findBy('groupValue', groupValue));
      if (_groupItems.indexOf(_groupItems.findBy('groupValue', Ember.get(_sortedgroupRowValues, 'lastObject'))) < index) {
        _sortedgroupRowValues.addObject(groupValue);
      } else {
        for (let i = 0; i < _sortedgroupRowValues.length; i++) {
          if (index < _groupItems.indexOf(_groupItems.findBy('groupValue', _sortedgroupRowValues[i]))) {
            _sortedgroupRowValues.insertAt(i, groupValue);
            break;
          }
        }
      }
    });

    return _sortedgroupRowValues;
  }).readOnly(),

  _computedSelectedItems: computed('_selectedItems.[]', function () {
    return this.get('_selectedItems').map(function (data) {
      return data;
    });
  }).readOnly(),

  _sortedSelectedItems: computed('_selectedItems.[]', '_items.[]', function () {
    const _selectedItems = this.get('_selectedItems'), _items = this.get('_items'), _sortedSelectedItems = Ember.A();
    let index = -1;

    _selectedItems.forEach(function (item) {
      index = _items.indexOf(item);
      if (_items.indexOf(Ember.get(_sortedSelectedItems, 'lastObject')) < index) {
        _sortedSelectedItems.addObject(item);
      } else {
        for (let i = 0; i < _sortedSelectedItems.length; i++) {
          if (index < _items.indexOf(_sortedSelectedItems[i])) {
            _sortedSelectedItems.insertAt(i, item);
            break;
          }
        }
      }
    });

    return _sortedSelectedItems;
  }).readOnly(),

  _computedSelectedCells: computed('_selectedCells.[]', function () {
    return this.get('_selectedCells').map(function (data) {
      return data;
    });
  }).readOnly(),

  _sortedSelectedCells: computed('_selectedCells.[]', '_items.[]', '_bindingColumns.[]', function () {
    const _selectedCells = this.get('_selectedCells'), _items = this.get('_items'), _bindingColumns = this.get('_bindingColumns'), _sortedSelectedCells = Ember.A(), _tempArray1 = Ember.A(), _tempArray2 = Ember.A();
    let index = -1;

    _selectedCells.uniqBy('item').forEach(function (cell) {
      index = _items.indexOf(cell.item);
      if (_items.indexOf(_tempArray1.get('lastObject.item')) < index) {
        _tempArray1.addObject(cell);
      } else {
        for (let i = 0; i < _tempArray1.length; i++) {
          if (index < _items.indexOf(_tempArray1[i].item)) {
            _tempArray1.insertAt(i, cell);
            break;
          }
        }
      }
    });
    _tempArray1.forEach(function (cell) {
      _tempArray2.clear();
      _selectedCells.filterBy('item', cell.item).forEach(function (filteredCell) {
        index = _bindingColumns.indexOf(filteredCell.column);
        if (_tempArray2.length === 0 || _bindingColumns.indexOf(_tempArray2.get('lastObject.column')) < index) {
          _tempArray2.addObject(filteredCell);
        } else {
          for (let i = 0; i < _tempArray2.length; i++) {
            if (index < _bindingColumns.indexOf(_tempArray2[i].column)) {
              _tempArray2.insertAt(i, filteredCell);
              break;
            }
          }
        }
      });
      _sortedSelectedCells.addObjects(_tempArray2);
    });

    return _sortedSelectedCells;
  }).readOnly(),

  _unsortedItems: computed('_itemsSource.[]', function () {
    const _itemsSource = this.get('_itemsSource');

    if (Ember.isArray(_itemsSource)) {
      this._runOnceItemsSourceChange(_itemsSource);

      return _itemsSource;
    } else {
      this._runOnceItemsSourceChange(Ember.A());

      return Ember.A();
    }
  }).readOnly(),

  _groupSortedValues: computed('_itemsSource.[]', '_hasGroupOption', 'groupOption', function () {
    const _itemsSource = this.get('_itemsSource');

    if (Ember.isArray(_itemsSource) && this.get('_hasGroupOption')) {
      const groupOption = this.get('groupOption'), groupField = Ember.get(groupOption.split(':'), 'firstObject');

      if (groupOption.includes(':') && Ember.get(groupOption.split(':'), 'lastObject') === 'desc') {
        return _itemsSource.uniqBy(groupField).getEach(groupField).sort().reverse();
      }

      return _itemsSource.uniqBy(groupField).getEach(groupField).sort();
    }

    return Ember.A();
  }).readOnly(),

  _items: computed('_unsortedItems.[]', '_sortingParams.[]', '_groupSortedValues.[]', 'groupOption', function () {
    const _sortingParams = this.get('_sortingParams'), _groupSortedValues = this.get('_groupSortedValues');

    if (!Ember.isEmpty(_sortingParams)) {
      const _sortedItems = this.get('_sortedItems');

      if (!Ember.isEmpty(_groupSortedValues)) {
        const _items = Ember.A(), groupField = Ember.get(this.get('groupOption').split(':'), 'firstObject');

        _groupSortedValues.forEach(function (groupVaue) {
          _items.addObjects(_sortedItems.filterBy(groupField, groupVaue));
        });

        return _items;
      }

      return _sortedItems;
    }
    const _unsortedItems = this.get('_unsortedItems');

    if (!Ember.isEmpty(_groupSortedValues)) {
      const _items = Ember.A(), groupField = Ember.get(this.get('groupOption').split(':'), 'firstObject');

      _groupSortedValues.forEach(function (groupVaue) {
        _items.addObjects(_unsortedItems.filterBy(groupField, groupVaue));
      });

      return _items;
    }

    return _unsortedItems;
  }).readOnly(),

  _groupItems: computed('_items.[]', '_groupSortedValues.[]', '_hasGroupOption', 'groupOption', function () {
    if (this.get('_hasGroupOption')) {
      const _items = this.get('_items'), groupField = Ember.get(this.get('groupOption').split(':'), 'firstObject');
      let tempArray, tempIndex;

      const _groupItems = this.get('_groupSortedValues').map(function (groupValue) {
        tempArray = _items.filterBy(groupField, groupValue);
        tempIndex = _items.indexOf(Ember.get(tempArray, 'firstObject'));

        return { groupField: groupField, groupValue: groupValue, startIndex: tempIndex, items: tempArray };
      });

      tempArray = null;
      tempIndex = null;

      return _groupItems;
    }

    return Ember.A();
  }).readOnly(),

  _startDetailRowIndex: computed('_sortedDetailRowItems.[]', '_items.[]', function () {
    return this.get('_items').indexOf(this.get('_sortedDetailRowItems.firstObject'));
  }).readOnly(),

  _startItemIndex: computed('_scrollTop', 'bodyLineHeight', '_startDetailRowIndex', function () {
    const _scrollTop = this.get('_scrollTop'), bodyLineHeight = this.get('bodyLineHeight'), _startDetailRowIndex = this.get('_startDetailRowIndex');

    if (0 <= _startDetailRowIndex) {
      if (_startDetailRowIndex < parseInt(_scrollTop / bodyLineHeight) - 1) {
        return Math.max(0, _startDetailRowIndex);
      }
    }

    return Math.max(0, parseInt(_scrollTop / bodyLineHeight) - 1);
  }).readOnly(),

  _beforeVirtualizationRow: computed('_startItemIndex', 'bodyLineHeight', function () {
    const _startItemIndex = this.get('_startItemIndex'), bodyLineHeight = this.get('bodyLineHeight');

    if (0 < _startItemIndex) {
      return Ember.String.htmlSafe(`<tr><td><div style="height:${(bodyLineHeight * _startItemIndex)}px;"></div></td></tr>`);
    }

    return Ember.String.htmlSafe('<!---->');
  }).readOnly(),

  _endItemIndex: computed('_scrollTop', '_bodyUnlockBlockHeight', 'bodyLineHeight', function () {
    return parseInt((this.get('_scrollTop') + this.get('_bodyUnlockBlockHeight')) / this.get('bodyLineHeight')) + 1;
  }).readOnly(),

  _afterVirtualizationRow: computed('_items.[]', '_endItemIndex', 'bodyLineHeight', function () {
    const items = this.get('_items'), _endItemIndex = this.get('_endItemIndex'), bodyLineHeight = this.get('bodyLineHeight');

    if (_endItemIndex < items.length) {
      return Ember.String.htmlSafe(`<tr><td><div style="height:${bodyLineHeight * (items.length - _endItemIndex)}px;"></div></td></tr>`);
    }

    return Ember.String.htmlSafe('<!---->');
  }).readOnly(),

  _virtualizationItems: computed('_items.[]', '_startItemIndex', '_endItemIndex', '_scrollTop', function () {
    Ember.run.schedule('afterRender', this, this._virtualizationRowChange, this.get('_scrollTop'));

    return this.get('_items').slice(this.get('_startItemIndex'), this.get('_endItemIndex'));
  }).readOnly(),

  _headRows: computed('_columns.[]', '_columns.@each.hidden', function () {
    const _headRows = Ember.A(), _columns = this.get('_columns');

    if (Ember.isArray(_columns)) {
      const maxDepth = this._headDepth(_columns);

      this._initializeColumns(_columns, maxDepth, maxDepth, _headRows);
    }

    return _headRows;
  }).readOnly(),

  _lockHeadRows: computed('_headRows.[]', '_lockBindingColumns.[]', function () {
    const _lockHeadRows = Ember.A(), _headRows = this.get('_headRows'), _uniqTopKeys = this.get('_lockBindingColumns').getEach('topKey').uniq();
    let _lockHeadRow;

    _headRows.forEach(function (headRow) {
      _lockHeadRow = Object.create({ columns: Ember.A(), startIndex: 0 });
      _uniqTopKeys.forEach(function (topKey) {
        _lockHeadRow.columns.addObjects(headRow.columns.filterBy('topKey', topKey));
      });
      _lockHeadRows.addObject(_lockHeadRow);
    });
    _lockHeadRow = null;

    return _lockHeadRows;
  }).readOnly(),

  _virtualizationHeadRows: computed('_headRows.[]', '_virtualizationBindingColumns.[]', function () {
    const _virtualizationHeadRows = Ember.A(), _headRows = this.get('_headRows'), _uniqTopKeys = this.get('_virtualizationBindingColumns').getEach('topKey').uniq();
    let _virtualizationHeadRow;

    _headRows.forEach(function (headRow) {
      _virtualizationHeadRow = Object.create({ columns: Ember.A(), startIndex: 0 });
      _uniqTopKeys.forEach(function (topKey) {
        _virtualizationHeadRow.columns.addObjects(headRow.columns.filterBy('topKey', topKey));
      });
      _virtualizationHeadRow.startIndex = headRow.columns.indexOf(Ember.get(_virtualizationHeadRow.columns, 'firstObject'));
      _virtualizationHeadRows.addObject(_virtualizationHeadRow);
    });
    _virtualizationHeadRow = null;

    return _virtualizationHeadRows;
  }).readOnly(),

  _bindingColumns: computed('_columns.[]', '_columns.@each.hidden', function () {
    const _bindingColumns = Ember.A(), _columns = this.get('_columns');

    if (Ember.isArray(_columns)) {
      const maxDepth = this._headDepth(_columns);

      this._initializeBindingColumns(_columns, maxDepth, maxDepth, _bindingColumns);
      //this._frozenValidation(_columns, _bindingColumns);
      this._runOnceBindingColumnsChange(_bindingColumns);
    }

    return _bindingColumns;
  }).readOnly(),

  _lastBindingColumnKey: computed('_bindingColumns.[]', function () {
    const _lastBindingColumn = this.get('_bindingColumns.lastObject');

    if (!Ember.isNone(_lastBindingColumn)) {
      return Ember.get(_lastBindingColumn, 'key');
    }

    return null;
  }).readOnly(),

  _lockBindingColumns: computed('_bindingColumns.[]', function () {
    return this.get('_bindingColumns').filterBy('locked', true);
  }).readOnly(),

  _lastLockBindingColumnKey: computed('_lockBindingColumns.[]', function () {
    const _lastLockBindingColumn = this.get('_lockBindingColumns.lastObject');

    if (!Ember.isNone(_lastLockBindingColumn)) {
      return Ember.get(_lastLockBindingColumn, 'key');
    }

    return null;
  }).readOnly(),

  _startColumnIndex: computed('_bindingColumns.@each.width', '_scrollLeft', function () {
    const _bindingColumns = this.get('_bindingColumns'), _unlockBindingColumns = _bindingColumns.rejectBy('locked', true), _scrollLeft = this.get('_scrollLeft');
    let sum = 0;

    for (let i = 0; i < _unlockBindingColumns.length; i++) {
      sum += _unlockBindingColumns[i].width;
      if (_scrollLeft < sum) {
        return _bindingColumns.indexOf(_unlockBindingColumns.findBy('topKey', _unlockBindingColumns.objectAt(i).topKey));
      }
    }

    return _bindingColumns.length - _unlockBindingColumns.length;
  }).readOnly(),

  _beforeVirtualizationCol: computed('_bindingColumns.@each.width', '_startColumnIndex', function () {
    const _startColumnIndex = this.get('_startColumnIndex'), _bindingColumns = this.get('_bindingColumns'), _unlockBindingColumns = _bindingColumns.rejectBy('locked', true),
      startColumn = _bindingColumns.objectAt(_startColumnIndex), startUnlockColumnIndex = _unlockBindingColumns.indexOf(startColumn);
    let sum = 0;

    for (let i = 0; i < startUnlockColumnIndex; i++) {
      sum += _unlockBindingColumns[i].width;
    }
    if (sum > 0) {
      return Ember.String.htmlSafe(`<col style="width:${sum}px;max-width:${sum}px;">`);
    }

    return Ember.String.htmlSafe(`<col style="width:0px;max-width:0px;">`);
  }).readOnly(),

  _endColumnIndex: computed('_bindingColumns.@each.width', '_scrollLeft', '_bodyUnlockBlockWidth', function () {
    const _bindingColumns = this.get('_bindingColumns'), _unlockBindingColumns = _bindingColumns.rejectBy('locked', true), _scrollLeft = this.get('_scrollLeft'), _bodyUnlockBlockWidth = this.get('_bodyUnlockBlockWidth');
    let sum = 0;

    for (let i = 0; i < _unlockBindingColumns.length; i++) {
      sum += _unlockBindingColumns[i].width;
      if (_scrollLeft + _bodyUnlockBlockWidth < sum) {
        return _bindingColumns.indexOf(_bindingColumns.rejectBy('locked', true).reverse().findBy('topKey', _unlockBindingColumns.objectAt(i).topKey)) + 1;
      }
    }

    return _bindingColumns.length;
  }).readOnly(),

  _afterVirtualizationCol: computed('_bindingColumns.@each.width', '_endColumnIndex', function () {
    const _endColumnIndex = this.get('_endColumnIndex');

    if (_endColumnIndex < this.get('_bindingColumns.length')) {
      const _bindingColumns = this.get('_bindingColumns'), _unlockBindingColumns = _bindingColumns.rejectBy('locked', true), endColumn = _bindingColumns.objectAt(_endColumnIndex), endUnlockColumnIndex = _unlockBindingColumns.indexOf(endColumn);
      let sum = 0;

      for (let i = endUnlockColumnIndex; i < _unlockBindingColumns.length; i++) {
        sum += _unlockBindingColumns[i].width;
      }

      return Ember.String.htmlSafe(`<col style="width:${sum}px;max-width:${sum}px;">`);
    } else {
      return Ember.String.htmlSafe('<col>');
    }
  }).readOnly(),

  _virtualizationBindingColumns: computed('_bindingColumns.[]', '_startColumnIndex', '_endColumnIndex', '_scrollLeft', function () {
    Ember.run.schedule('afterRender', this, this._virtualizationColumnChange, this.get('_scrollLeft'));

    return this.get('_bindingColumns').slice(this.get('_startColumnIndex'), this.get('_endColumnIndex'));
  }).readOnly(),

  _hasMultiHeader: computed('_headRows.[]', function () {
    return 2 <= this.get('_headRows.length');
  }).readOnly(),

  _hasFrozen: computed('_bindingColumns.[]', function () {
    return !Ember.isEmpty(this.get('_bindingColumns').filterBy('locked', true));
  }).readOnly(),

  _hasMerge: computed('_bindingColumns.[]', function () {
    return !Ember.isEmpty(this.get('_bindingColumns').filterBy('merge', true));
  }).readOnly(),

  _mergeColumns: computed('_bindingColumns.[]', function () {
    return this.get('_bindingColumns').filterBy('merge', true).map(function (column) {
      return column;
    });
  }).readOnly(),

  _lockTableWidth: computed('_bindingColumns.@each.width', '_showHandle', '_hasFrozen', '_handleWidth', function () {
    let _lockTableWidth = 0;

    this.get('_bindingColumns').forEach(function (column) {
      if (column.locked) {
        _lockTableWidth += column.width;
      }
    });
    if (this.get('_showHandle') && this.get('_hasFrozen')) {
      _lockTableWidth += this.get('_handleWidth');
    }

    return _lockTableWidth;
  }).readOnly(),

  _unlockTableWidth: computed('_bindingColumns.@each.width', '_showHandle', '_hasFrozen', '_handleWidth', function () {
    let _unlockTableWidth = 0;

    this.get('_bindingColumns').forEach(function (column) {
      if (!column.locked) {
        _unlockTableWidth += column.width;
      }
    });
    if (this.get('_showHandle') && !this.get('_hasFrozen')) {
      _unlockTableWidth += this.get('_handleWidth');
    }

    return _unlockTableWidth;
  }).readOnly(),

  _htmlSafeHandleWidth: computed('_handleWidth', function () {
    return Ember.String.htmlSafe(`width:${this.get('_handleWidth')}px;max-width:${this.get('_handleWidth')}px;`);
  }).readOnly(),

  _htmlSafeBasicWidth: computed('basicWidth', function () {
    return Ember.String.htmlSafe(`width:${this.get('basicWidth')}px;max-width:${this.get('basicWidth')}px;`);
  }).readOnly(),

  _htmlSafeHeadLineHeight: computed('headLineHeight', function () {
    return Ember.String.htmlSafe(`height:${this.get('headLineHeight')}px;min-height:${this.get('headLineHeight')}px;`);
  }).readOnly(),

  _htmlSafeBodyLineHeight: computed('bodyLineHeight', function () {
    return Ember.String.htmlSafe(`height:${this.get('bodyLineHeight')}px;min-height:${this.get('bodyLineHeight')}px;`);
  }).readOnly(),

  _htmlSafeFootLineHeight: computed('footLineHeight', function () {
    return Ember.String.htmlSafe(`height:${this.get('footLineHeight')}px;min-height:${this.get('footLineHeight')}px;`);
  }).readOnly(),

  _htmlSafeDetailRowHeight: computed('detailRowHeight', function () {
    return Ember.String.htmlSafe(`min-height:${this.get('detailRowHeight')}px;white-space:normal !important;`);
  }).readOnly(),

  _htmlSafeHeadBlock: computed('_headHeight', function () {
    return Ember.String.htmlSafe(`width:100%;height:${this.get('_headHeight')}px;`);
  }).readOnly(),

  _htmlSafeFootBlock: computed('_footHeight', function () {
    return Ember.String.htmlSafe(`width:100%;height:${this.get('_footHeight')}px;`);
  }).readOnly(),

  _htmlSafeBodyBlock: computed('_headHeight', '_footHeight', function () {
    return Ember.String.htmlSafe(`width:100%;height:calc(100% - ${this.get('_headHeight') + this.get('_footHeight')}px);`);
  }).readOnly(),

  _htmlSafeHeadLockBlock: computed('_lockTableWidth', function () {
    return Ember.String.htmlSafe(`width:${this.get('_lockTableWidth')}px;height:100%;`);
  }).readOnly(),

  _htmlSafeHeadUnlockBlock: computed('_lockTableWidth', function () {
    return Ember.String.htmlSafe(`width:calc(100% - ${this.get('_lockTableWidth')}px);height:100%;`);
  }).readOnly(),

  _htmlSafeFootLockBlock: computed('_lockTableWidth', function () {
    return Ember.String.htmlSafe(`width:${this.get('_lockTableWidth')}px;height:100%;`);
  }).readOnly(),

  _htmlSafeFootUnlockBlock: computed('_lockTableWidth', function () {
    return Ember.String.htmlSafe(`width:calc(100% - ${this.get('_lockTableWidth')}px);height:100%;`);
  }).readOnly(),

  _htmlSafeBodyLockBlock: computed('_lockTableWidth', function () {
    return Ember.String.htmlSafe(`width:${this.get('_lockTableWidth')}px;height:100%;`);
  }).readOnly(),

  _htmlSafeBodyUnlockBlock: computed('_lockTableWidth', function () {
    return Ember.String.htmlSafe(`width:calc(100% - ${this.get('_lockTableWidth')}px);height:100%;`);
  }).readOnly(),

  _htmlSafeLockTable: computed('_lockTableWidth', function () {
    return Ember.String.htmlSafe(`width:${this.get('_lockTableWidth')}px;min-width:100%;`);
  }).readOnly(),

  _htmlSafeUnlockTable: computed('_unlockTableWidth', function () {
    return Ember.String.htmlSafe(`width:${this.get('_unlockTableWidth')}px;min-width:100%;`);
  }).readOnly(),

  _observedProperty1: computed('selectedItem', function () {
    if (this.get('_useSelectedItem')) {
      const selectedItem = this.get('selectedItem'), lastSelectedItem = this.get('_selectedItems.lastObject');

      if ((lastSelectedItem && selectedItem && lastSelectedItem !== selectedItem) || (!lastSelectedItem && selectedItem)) {
        this._selectRow(this._getItemIndex(selectedItem));
      } else if (lastSelectedItem && !selectedItem) {
        this._deselectRow(this._getItemIndex(lastSelectedItem));
      }
    }

    return null;
  }).readOnly(),

  _observedProperty2: computed('_itemsSource', function () {
    if (!this.get('isDestroying') && !this.get('isDestroyed')) {
      this.$('> div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx').scrollTop(0).scrollLeft(0);
    }

    return null;
  }).readOnly(),

  onPropertyInit() {
    this._super(...arguments);

    this.setStateProperties([ '_sortingColumns', '_selectedItems', '_selectedCells', '_detailRowItems', '_groupRowValues' ]);
    if (!this.hasState()) {
      this.set('_sortingColumns', Ember.A());
      this.set('_selectedItems', Ember.A());
      this.set('_selectedCells', Ember.A());
      this.set('_detailRowItems', Ember.A());
      this.set('_groupRowValues', Ember.A());
    }
    this.set('_virtualizationColumnChangeQueue', Ember.A());
    this.set('_virtualizationRowChangeQueue', Ember.A());
  },

  didInsertElement() {
    this._super(...arguments);

    this.set('_hasHeadTemplate', this.$('> div.fr-grid-head-container > div > table').children('thead').length > 0 ? true : false);
    this.set('_hasBodyTemplate', this.$('> div.fr-grid-body-container > div.lock > table, > div.fr-grid-body-container > div.unlock > div.scrollbar-macosx > table').children('tbody').length > 0 ? true : false);
    this.set('_hasFootTemplate', this.$('> div.fr-grid-foot-container > div > table').children('tfoot').length > 0 ? true : false);
    this.$().on('_getComponent', function (event, param) {
      param.component = this;
      event.stopPropagation();
      event.preventDefault();
    }.bind(this));
    this.$('> div.fr-grid-body-container > div.unlock > div.scrollbar-macosx').scrollbar({
      'onScroll': function(y, x) {
        if (!this.get('_isSyncingUnlockBodyScroll')) {
          this.set('_isSyncingUnlockHeadScroll', true);
          this.set('_isSyncingUnlockFootScroll', true);
          this.set('_isSyncingLockBodyScroll', true);
          this.$('> div.fr-grid-head-container > div.unlock').scrollLeft(x.scroll);
          this.$('> div.fr-grid-foot-container > div.unlock').scrollLeft(x.scroll);
          this.$('> div.fr-grid-body-container > div.lock').scrollTop(y.scroll);
          this._runScrollChange();
        }
        this.set('_isSyncingUnlockBodyScroll', false);
      }.bind(this),
      'onUpdate': function(el) {
        this._runOnceBodyUnlockBlockSizeChange(el.prop('clientWidth'), el.prop('clientHeight'));
      }.bind(this),
    });
    this.$('> div.fr-grid-body-container > div.lock').on('scroll', function () {
      if (!this.get('_isSyncingLockBodyScroll')) {
        this.set('_isSyncingUnlockBodyScroll', true);
        const y = this.$('> div.fr-grid-body-container > div.lock').scrollTop();

        this.$('> div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx').scrollTop(y);
        this._runScrollChange();
      }
      this.set('_isSyncingLockBodyScroll', false);
    }.bind(this));
    this.$('> div.fr-grid-head-container > div.unlock').on('scroll', function () {
      if (!this.get('_isSyncingUnlockHeadScroll')) {
        this.set('_isSyncingUnlockFootScroll', true);
        this.set('_isSyncingUnlockBodyScroll', true);
        const x = this.$('> div.fr-grid-head-container > div.unlock').scrollLeft();

        this.$('> div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx').scrollLeft(x);
        this.$('> div.fr-grid-foot-container > div.unlock').scrollLeft(x);
        this._runScrollChange();
      }
      this.set('_isSyncingUnlockHeadScroll', false);
    }.bind(this));
    this.$('> div.fr-grid-foot-container > div.unlock').on('scroll', function () {
      if (!this.get('_isSyncingUnlockFootScroll')) {
        this.set('_isSyncingUnlockHeadScroll', true);
        this.set('_isSyncingUnlockBodyScroll', true);
        const x = this.$('> div.fr-grid-foot-container > div.unlock').scrollLeft();

        this.$('> div.fr-grid-head-container > div.unlock').scrollLeft(x);
        this.$('> div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx').scrollLeft(x);
        this._runScrollChange();
      }
      this.set('_isSyncingUnlockFootScroll', false);
    }.bind(this));
    this._tryAction('onLoad', { source: this });
  },

  didRender() {
    this._super(...arguments);

    this._updateLayout();
  },

  willDestroyElement() {
    this._super(...arguments);

    this.$().off('_getComponent');
    this.$('> div.fr-grid-body-container > div.lock').off('scroll');
    this.$('> div.fr-grid-head-container > div.unlock').off('scroll');
    this.$('> div.fr-grid-foot-container > div.unlock').off('scroll');
    this.$('> div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx').scrollbar('destroy');
    this._tryAction('onUnload', { source: this });
  },

  click(event) {
    const args = { source: this, originalEvent: event, type: this._getEventType(event), cancel: false };

    if (this._tryAction('onBeforeClick', args) !== false && !args.cancel && this.get('element').contains(event.target)) {
      if (args.type.includes('head')) {
        if (args.type.includes('cell')) {
          if (args.type.includes('menu')) {
            this._headCellMenuClick(event);
          } else if (!args.type.includes('resizer')) {
            this._headCellClick(event);
          }
        } else if (args.type.includes('handle')) {
          if (args.type.includes('checkbox')) {
            this._headHandleCheckboxClick(event);
          }
        }
      } else if (args.type.includes('body')) {
        if (args.type.includes('cell')) {
          if (args.type.includes('boolean')) {
            this._bodyCellBooleanClick(event);
          }
          this._bodyCellClick(event);
        } else if (args.type.includes('handle')) {
          if (args.type.includes('checkbox')) {
            this._bodyHandleCheckboxClick(event);
          } else if (args.type.includes('expander')) {
            this._bodyHandleExpanderClick(event);
          }
        } else if (args.type.includes('ghead')) {
          if (args.type.includes('expander')) {
            this._bodyGheadExpanderClick(event);
          }
        }
      }
    }
    this._releaseObjectProperty(args);
  },

  doubleClick(event) {
    const args = { source: this, originalEvent: event, type: this._getEventType(event), cancel: false };

    if (this._tryAction('onBeforeDoubleClick', args) !== false && !args.cancel && this.get('element').contains(event.target)) {
      if (args.type.includes('body')) {
        if (args.type.includes('cell')) {
          this._bodyCellDoubleClick(event);
        }
      }
    }
    this._releaseObjectProperty(args);
  },

  keyDown(event) {
    const _beforeKeyEvent = this.get('_beforeKeyEvent');

    if (Ember.isNone(_beforeKeyEvent) || _beforeKeyEvent.key !== event.keyCode ||
      _beforeKeyEvent.shiftKey !== event.shiftKey || _beforeKeyEvent.ctrlKey !== event.ctrlKey) {
      this.set('_beforeKeyEvent', { key: event.keyCode, shiftKey: event.shiftKey, ctrlKey: event.ctrlKey });
      const args = { source: this, originalEvent: event, type: this._getEventType(event), cancel: false };

      if (this._tryAction('onBeforeKeyDown', args) !== false && !args.cancel && this.get('element').contains(event.target)) {
        if (args.type.includes('body')) {
          if (args.type.includes('cell')) {
            this._bodyCellKeyDown(event);
          }
        } else {
          this._gridKeyDown(event);
        }
      }
      Ember.run.later(this, function () {
        this.set('_beforeKeyEvent', null);
      }, this.get('_keySpeed'));
      this._releaseObjectProperty(args);
    } else {
      event.stopPropagation();
      event.preventDefault();
    }
  },

  mouseDown(event) {
    const args = { source: this, originalEvent: event, type: this._getEventType(event), cancel: false };

    if (this._tryAction('onBeforeMouseDown', args) !== false && !args.cancel && this.get('element').contains(event.target)) {
      if (args.type.includes('head')) {
        if (args.type.includes('cell')) {
          if (args.type.includes('resizer')) {
            this._headResizerMouseDown(event);
          } else if (!args.type.includes('menu')) {
            this._headCellMouseDown(event);
          }
        }
      } else if (args.type.includes('body')) {
        if (args.type.includes('cell')) {
          this._bodyCellMouseDown(event);
        } else if (args.type.includes('handle')) {
          if (args.type.includes('reorder')) {
            this._bodyHandleReorderMouseDown(event);
          }
        }
      }
    }
    this._releaseObjectProperty(args);
  },

  focusIn(event) {
    const args = { source: this, originalEvent: event, type: this._getEventType(event), cancel: false };

    if (this._tryAction('onBeforeFocusIn', args) !== false && !args.cancel && this.get('element').contains(event.target)) {
    }
    this._releaseObjectProperty(args);
  },

  focusOut(event) {
    const args = { source: this, originalEvent: event, type: this._getEventType(event), cancel: false };

    if (this._tryAction('onBeforeFocusOut', args) !== false && !args.cancel && this.get('element').contains(event.target)) {
      if (args.type.includes('body')) {
        if (args.type.includes('cell')) {
          this._bodyCellFocusOut(event);
        }
      }
    }
    this._releaseObjectProperty(args);
  },

  _getEventType(event) {
    const type = [], _gridGuid = this.get('_gridGuid'), $target = this.$(event.target), gridElement = this.get('element');

    if ($target.closest(`.${_gridGuid}-head`, gridElement).length > 0) {
      type.push('head');
      if ($target.closest(`.${_gridGuid}-head-cell`, gridElement).length > 0) {
        type.push('cell');
        if ($target.closest(`.${_gridGuid}-head-cell-menu`, gridElement).length > 0) {
          type.push('menu');
        } else if ($target.closest(`.${_gridGuid}-head-cell-resizer`, gridElement).length > 0) {
          type.push('resizer');
        }
      } else if ($target.closest(`.${_gridGuid}-head-handle-checkbox`, gridElement).length > 0) {
        type.push('handle');
        type.push('checkbox');
      } else if ($target.closest(`.${_gridGuid}-head-handle-empty`, gridElement).length > 0) {
        type.push('handle');
        type.push('empty');
      }
    } else if ($target.closest(`.${_gridGuid}-body`, gridElement).length > 0) {
      type.push('body');
      if ($target.closest(`.${_gridGuid}-body-cell`, gridElement).length > 0) {
        type.push('cell');
        if ($target.closest(`.${_gridGuid}-body-cell-boolean`, gridElement).length > 0) {
          type.push('boolean');
        }
      } else if ($target.closest(`.${_gridGuid}-body-handle-checkbox`, gridElement).length > 0) {
        type.push('handle');
        type.push('checkbox');
      } else if ($target.closest(`.${_gridGuid}-body-handle-index`, gridElement).length > 0) {
        type.push('handle');
        type.push('index');
      } else if ($target.closest(`.${_gridGuid}-body-handle-reorder`, gridElement).length > 0) {
        type.push('handle');
        type.push('reorder');
      } else if ($target.closest(`.${_gridGuid}-body-handle-expander`, gridElement).length > 0) {
        type.push('handle');
        type.push('expander');
      } else if ($target.closest(`.${_gridGuid}-body-handle-empty`, gridElement).length > 0) {
        type.push('handle');
        type.push('empty');
      } else if ($target.closest(`.${_gridGuid}-body-ghead`, gridElement).length > 0) {
        type.push('ghead');
        if ($target.closest(`.${_gridGuid}-body-ghead-expander`, gridElement).length > 0) {
          type.push('expander');
        }
      } else if ($target.closest(`.${_gridGuid}-body-gfoot`, gridElement).length > 0) {
        type.push('gfoot');
      } else if ($target.closest(`.${_gridGuid}-body-detail`, gridElement).length > 0) {
        type.push('detail');
      }
    } else if ($target.closest(`.${_gridGuid}-foot`, gridElement).length > 0) {
      type.push('foot');
      if ($target.closest(`.${_gridGuid}-foot-cell`, gridElement).length > 0) {
        type.push('cell');
      } else if ($target.closest(`.${_gridGuid}-foot-handle-checkbox`, gridElement).length > 0) {
        type.push('handle');
        type.push('checkbox');
      } else if ($target.closest(`.${_gridGuid}-foot-handle-empty`, gridElement).length > 0) {
        type.push('handle');
        type.push('empty');
      }
    }

    return type;
  },

  _headCellMenuClick(event) {
    const $target = this.$(event.target).closest(`.${this.get('_gridGuid')}-head-cell`);

    if (!this.$(this.get('_targetElement')).is($target)) {
      this.set('_targetElement', $target.get(0));
    } else {
      this.set('_targetElement', null);
    }
  },

  _headCellClick(event) {
    if (this.get('sortable')) {
      const $target = this.$(event.target).closest(`.${this.get('_gridGuid')}-head-cell`), column = this.get('_headRows').objectAt(parseInt($target.parent('tr').attr('data-head-row-index'))).columns.objectAt(parseInt($target.attr('data-head-cell-index')));

      if (column && column.field) {
        const _sortingColumns = this.get('_sortingColumns'), sortingColumn = _sortingColumns.findBy('column', column), sortingType = this.get('sortingType');

        if (sortingColumn) {
          if (sortingType === 'single') {
            _sortingColumns.clear();
            if (sortingColumn.direction === 'asc') {
              _sortingColumns.addObject({ column: column, direction: 'desc' });
            }
          }
          if (sortingType === 'multi') {
            const index = _sortingColumns.indexOf(sortingColumn);

            _sortingColumns.removeObject(sortingColumn);
            if (sortingColumn.direction === 'asc') {
              _sortingColumns.insertAt(index, { column: column, direction: 'desc' });
            }
          }
        } else {
          if (sortingType === 'single') {
            _sortingColumns.clear();
            _sortingColumns.addObject({ column: column, direction: 'asc' });
          }
          if (sortingType === 'multi') {
            _sortingColumns.addObject({ column: column, direction: 'asc' });
          }
        }
      }
    }
  },

  _headHandleCheckboxClick() {
    if (this.get('_isAllChecked')) {
      this._deselectAll();
    } else {
      this._selectAll();
    }
  },

  _bodyCellBooleanClick(event) {
    let $target = this.$(event.target).closest(`.${this.get('_gridGuid')}-body-cell`), component = this._getComponent($target);

    if (Ember.get(component, '_allowEditing')) {
      Ember.set(component, '_dataValue', !Ember.get(component, '_dataValue'));
    }
    $target = null;
    component = null;
  },

  _bodyCellClick(event) {
    let $target = this.$(event.target).closest(`.${this.get('_gridGuid')}-body-cell`), selectionType = this.get('selectionType'), selectionMode = this.get('selectionMode'),
      rowIndex = parseInt($target.parent('tr').attr('data-body-row-index')), cellIndex = parseInt($target.attr('data-body-cell-index'));

    if ($target.is(':focusable')) {
      if ((selectionType === 'row' || selectionType === 'checkbox') && selectionMode === 'single') {
        this._rowSingleClick(event, rowIndex, cellIndex);
      } else if ((selectionType === 'row' || selectionType === 'checkbox') && selectionMode === 'multi') {
        this._rowMultiClick(event, rowIndex, cellIndex);
      } else if (selectionType === 'cell' && selectionMode === 'single') {
        this._cellSingleClick(event, rowIndex, cellIndex);
      } else if (selectionType === 'cell' && selectionMode === 'multi') {
        this._cellMultiClick(event, rowIndex, cellIndex);
      }
      this._cellEditingStart($target);
    }
    let component = this._getComponent($target);

    this._tryAction('onCellClick', {
      source: this,
      originalSource: component,
      item: Ember.get(component, 'item'),
      column: Ember.get(component, 'column')
    });
    $target = null;
    component = null;
  },

  _bodyHandleCheckboxClick(event) {
    const $target = this.$(event.target).closest(`.${this.get('_gridGuid')}-body-handle-checkbox`), selectionMode = this.get('selectionMode'), _items = this.get('_items'), _selectedItems = this.get('_selectedItems'), item = _items.objectAt(parseInt($target.parent('tr').attr('data-body-row-index')));

    if (!_selectedItems.includes(item)) {
      if (selectionMode === 'single') {
        _selectedItems.clear();
      }
      _selectedItems.addObject(item);
    } else {
      _selectedItems.removeObject(item);
    }
    this._runOnceSelectionChange();
  },

  _bodyHandleExpanderClick(event) {
    const $target = this.$(event.target).closest(`.${this.get('_gridGuid')}-body-handle-expander`), _items = this.get('_items'), _detailRowItem = _items.objectAt(parseInt($target.parent('tr').attr('data-body-row-index'))),
      _detailRowItems = this.get('_detailRowItems'), detailRowExpandType =this.get('detailRowExpandType');

    if (_detailRowItems.includes(_detailRowItem)) {
      _detailRowItems.removeObject(_detailRowItem);
    } else {
      if (detailRowExpandType === 'single') {
        _detailRowItems.clear();
        _detailRowItems.addObject(_detailRowItem);
      }
      if (detailRowExpandType === 'multi') {
        _detailRowItems.addObject(_detailRowItem);
      }
    }
    this._runOnceDetailRowItemsChange();
  },

  _bodyGheadExpanderClick(event) {
    const $target = this.$(event.target).closest(`.${this.get('_gridGuid')}-body-ghead-expander`), _groupItems = this.get('_groupItems'), _groupValue = Ember.get(_groupItems.objectAt(parseInt($target.closest('tr').attr('data-body-ghead-row-index'))), 'groupValue'),
      _groupRowValues = this.get('_groupRowValues'), groupRowExpandType = this.get('groupRowExpandType');

    if (_groupRowValues.includes(_groupValue)) {
      _groupRowValues.removeObject(_groupValue);
    } else {
      if (groupRowExpandType === 'single') {
        _groupRowValues.clear();
        _groupRowValues.addObject(_groupValue);
      }
      if (groupRowExpandType === 'multi') {
        _groupRowValues.addObject(_groupValue);
      }
    }
    this._runOnceGroupRowValuesChange();
  },

  _bodyCellDoubleClick(event) {
    let $target = this.$(event.target).closest(`.${this.get('_gridGuid')}-body-cell`), component = this._getComponent($target);

    this._tryAction('onCellDoubleClick', {
      source: this,
      originalSource: component,
      item: Ember.get(component, 'item'),
      column: Ember.get(component, 'column')
    });
    $target = null;
    component = null;
  },

  _bodyCellKeyDown(event) {
    const key = event.keyCode;
    let $target = this.$(event.target).closest(`.${this.get('_gridGuid')}-body-cell`), bubblingEvent = true;

    if (key === 9) {
      if (event.shiftKey) {
        bubblingEvent = this._movePrevCell($target);
      } else {
        bubblingEvent = this._moveNextCell($target);
      }
    } else if (key === 13) {
      bubblingEvent = this._moveNextLineCell($target);
    } else if (key === 37) {
      if (!Ember.get(this._getComponent($target), '_editing') && !$target.find(':focus').is(':input')) {
        bubblingEvent = this._moveLeftCell($target);
      }
    } else if (key === 38) {
      if (!Ember.get(this._getComponent($target), '_editing') && !$target.find(':focus').is(':input')) {
        bubblingEvent = this._moveUpCell($target);
      }
    } else if (key === 39) {
      if (!Ember.get(this._getComponent($target), '_editing') && !$target.find(':focus').is(':input')) {
        bubblingEvent = this._moveRightCell($target);
      }
    } else if (key === 40) {
      if (!Ember.get(this._getComponent($target), '_editing') && !$target.find(':focus').is(':input')) {
        bubblingEvent = this._moveDownCell($target);
      }
    } else if (key === 27) {
      if (Ember.get(this._getComponent($target), 'editing')) {
        bubblingEvent = this._cancelEditingCell($target);
      }
    } else if (key === 67) {
      if (event.ctrlKey && !Ember.get(this._getComponent($target), '_editing') && !$target.find(':focus').is(':input')) {
        bubblingEvent = this._copyToClipboard();
      }
    }
    if (!bubblingEvent) {
      event.stopPropagation();
      event.preventDefault();
    }
    $target = null;
  },

  _gridKeyDown(event) {
    const key = event.keyCode;
    let bubblingEvent = true;

    if (key === 9) {
      if (!event.shiftKey) {
        bubblingEvent = this._moveFirstCell();
      }
    }
    if (!bubblingEvent) {
      event.stopPropagation();
      event.preventDefault();
    }
  },

  _headCellMouseDown(event) {
    if (this.get('reorderingColumn')) {
      const topKey = this.$(event.target).closest(`.${this.get('_gridGuid')}-head-cell`).attr('data-column-top-key'), args = {};

      Ember.$(document).on(`dragstart.fr-grid-reordering-column-${this.get('_gridGuid')}`, function (dragstartEvent) {
        const $topCell = this.$('> div.fr-grid-head-container > div > table > thead').children('tr[data-head-row-index]').children('th[data-head-cell-index]').filter(`[data-column-key=${topKey}]`);

        args.source = this;
        args.columns = this.get('_columns');
        args.originalEvent = dragstartEvent;
        args.dragColumns = Ember.A([ args.columns.findBy('key', topKey) ]);
        args.dragTag = `<div style="width:${$topCell.outerWidth()}px;height:${this.get('_headHeight')}px;"></div>`;
        this._tryAction('onColumnDragStart', args);
        args.$dragImage = Ember.$(`<div class="grid-drag-move" style="position:absolute;left:${dragstartEvent.clientX}px;top:${dragstartEvent.clientY}px;z-index:10000;pointer-events:none;"><div>`).append(args.dragTag).appendTo('body');
        args.$ghostImage = Ember.$(`<span style="position:absolute;display:block;top:0;left:0;width:0;height:0;"></span>`).appendTo('body');
        args.$pointer = Ember.$(`<div class="grid-drag-point" style="position:absolute;top:${$topCell.offset().top}px;height:${this.get('_headHeight')}px;pointer-events:none;"><span></span></div>`);
        args.$switch = args.$pointer;
        args.indexArray = args.dragColumns.map(function (column) {
          return args.columns.indexOf(column);
        }).sort(function (a, b) {
          return a - b;
        }).uniq();
        args.startIndex = Ember.get(args.indexArray, 'firstObject');
        dragstartEvent.dataTransfer.setDragImage(args.$ghostImage.get(0), 0, 0);
        const action = function () {
          args.$headCells = this.$('> div.fr-grid-head-container > div > table > thead').children('tr[data-head-row-index]').children('th[data-head-cell-index]');
          const $startCells = args.$headCells.not('.draggable').filter(function () {
            return args.indexArray.map(function (index) {
              return Ember.get(args.columns.objectAt(index), 'key');
            }).includes(Ember.$(this).attr('data-column-top-key'));
          });

          if ($startCells.length > 0) {
            $startCells.prepend(`<div class="grid-drag-off"></div>`);
            $startCells.addClass('draggable');
          }
          args.$headCells.not('.draggable').not('.droppable').addClass('droppable').on('dragover', function (dragoverEvent) {
            dragoverEvent.stopPropagation();
            dragoverEvent.preventDefault();
          }).on('dragenter', function (dragenterEvent) {
            dragenterEvent.stopPropagation();
            dragenterEvent.preventDefault();
            const enterTopKey = this.$(dragenterEvent.currentTarget).attr('data-column-top-key'), $enterCells = args.$headCells.filter(`[data-column-top-key=${enterTopKey}]`),
              $enterTopCell = $enterCells.filter(`[data-column-key=${enterTopKey}]`), enterIndex = parseInt($enterTopCell.attr('data-head-cell-index'));

            args.$pointer.css({ 'left': `${args.startIndex < enterIndex ? $enterTopCell.offset().left + $enterTopCell.outerWidth() : $enterTopCell.offset().left}px` });
            $enterCells.prepend(`<div class="grid-drag-on"></div>`);
            if (args.$switch) {
              args.$switch.appendTo('body');
              args.$switch = null;
            } else {
              args.$switch = args.$pointer.detach();
            }
          }.bind(this)).on('dragleave', function (dragleaveEvent) {
            dragleaveEvent.stopPropagation();
            dragleaveEvent.preventDefault();
            const leaveTopKey = this.$(dragleaveEvent.currentTarget).attr('data-column-top-key'), $leaveCells = args.$headCells.filter(`[data-column-top-key=${leaveTopKey}]`);

            $leaveCells.children(`.grid-drag-on:first-child`).remove();
            if (args.$switch) {
              args.$switch.appendTo('body');
              args.$switch = null;
            } else {
              args.$switch = args.$pointer.detach();
            }
          }.bind(this)).on('drop', function (dropEvent) {
            dropEvent.stopPropagation();
            dropEvent.preventDefault();
            const originColumns = args.columns.objectsAt(args.indexArray), dropIndex = args.columns.indexOf(args.columns.findBy('key', this.$(dropEvent.target).closest(`.${this.get('_gridGuid')}-head-cell`).attr('data-column-top-key'))), dropColumn = args.columns.objectAt(dropIndex);

            args.columns.removeObjects(originColumns);
            const insertIndex = args.startIndex < dropIndex ? args.columns.indexOf(dropColumn) + 1 : args.columns.indexOf(dropColumn);

            originColumns.reverse().forEach(function (column) {
              args.columns.insertAt(insertIndex, column);
            });
          }.bind(this));
        }.bind(this);

        this.get('_virtualizationColumnChangeQueue').addObject({ key: 'reorder', action: action });
        action();
      }.bind(this)).on(`drag.fr-grid-reordering-column-${this.get('_gridGuid')}`, function (dragEvent) {
        args.$dragImage.css({ 'left': `${dragEvent.originalEvent.clientX}px`, 'top': `${dragEvent.originalEvent.clientY}px` });
      }).on(`dragend.fr-grid-reordering-column-${this.get('_gridGuid')}`, function (dragendEvent) {
        this.get('_virtualizationColumnChangeQueue').removeObjects(this.get('_virtualizationColumnChangeQueue').filterBy('key','reorder'));
        args.$headCells.filter('.droppable').children(`.grid-drag-on`).remove();
        args.$headCells.filter('.droppable').removeClass('droppable').off('dragover').off('dragenter').off('dragleave').off('drop');
        args.$headCells.filter('.draggable').removeClass('draggable').children(`.grid-drag-off`).remove();
        args.$dragImage.remove();
        args.$ghostImage.remove();
        args.$pointer.remove();
        this._releaseObjectProperty(args);
        this._tryAction('onColumnDragEnd', { source: this, originalEvent: dragendEvent });
        Ember.$(document).off(`dragstart.fr-grid-reordering-column-${this.get('_gridGuid')}`).off(`drag.fr-grid-reordering-column-${this.get('_gridGuid')}`)
        .off(`dragend.fr-grid-reordering-column-${this.get('_gridGuid')}`).off(`mouseup.fr-grid-reordering-column-${this.get('_gridGuid')}`);
        this.$().removeAttr('draggable');
      }.bind(this)).on(`mouseup.fr-grid-reordering-column-${this.get('_gridGuid')}`, function () {
        Ember.$(document).off(`dragstart.fr-grid-reordering-column-${this.get('_gridGuid')}`).off(`drag.fr-grid-reordering-column-${this.get('_gridGuid')}`)
        .off(`dragend.fr-grid-reordering-column-${this.get('_gridGuid')}`).off(`mouseup.fr-grid-reordering-column-${this.get('_gridGuid')}`);
        this.$().removeAttr('draggable');
      }.bind(this));
      this.$().attr('draggable', true);
    }
  },

  _headResizerMouseDown(event) {
    const _bindingColumns = this.get('_bindingColumns'), $target = this.$(event.target).filter(`.${this.get('_gridGuid')}-head-cell-resizer`);
    let originColumn = _bindingColumns.findBy('key', $target.attr('data-target-column')), nextColumn = _bindingColumns.objectAt(_bindingColumns.indexOf(originColumn) + 1), originX = event.pageX;

    Ember.$(document).on(`mousemove.fr-grid-resizer-${this.get('_gridGuid')}`, function (mousemoveEvent) {
      let x = mousemoveEvent.pageX - originX;

      originX = mousemoveEvent.pageX;
      x = Math.max(x, 10 - originColumn.width);
      if (originColumn.locked) {
        if (!nextColumn || !nextColumn.locked) {
          return;
        }
        const max = nextColumn ? nextColumn.width - 10 : 0;

        x = Math.min(x, max);
        if (!nextColumn) {
          return;
        }
      }
      if (this.get('columnResizeType') === 'fit') {
        const max = nextColumn ? nextColumn.width - 10 : 0;

        x = Math.min(x, max);
        if (!nextColumn) {
          return;
        }
      }
      Ember.set(originColumn, 'width', originColumn.width + x);
      Ember.set(originColumn, 'originWidth', Ember.get(originColumn, 'width'));
      Ember.set(originColumn, 'autoWidth', false);
      if (originColumn.locked || this.get('columnResizeType') === 'fit') {
        Ember.set(nextColumn, 'width', nextColumn.width - x);
        Ember.set(nextColumn, 'originWidth', Ember.get(nextColumn, 'width'));
        Ember.set(nextColumn, 'autoWidth', false);
      }
    }.bind(this))
    .on(`mouseup.fr-grid-resizer-${this.get('_gridGuid')}`, function () {
      originX = null;
      originColumn = null;
      nextColumn = null;
      Ember.$(document).off(`mousemove.fr-grid-resizer-${this.get('_gridGuid')}`)
      .off(`mouseup.fr-grid-resizer-${this.get('_gridGuid')}`);
    }.bind(this));
  },

  _bodyCellMouseDown(event) {
    const $target = this.$(event.target).closest(`.${this.get('_gridGuid')}-body-cell`), args = {};

    args.startItemIndex = parseInt($target.parent('tr').attr('data-body-row-index'));
    args.startColumnIndex = parseInt($target.attr('data-body-cell-index'));
    args.selectionType = this.get('selectionType');
    args.selectionMode = this.get('selectionMode');
    args.beforeEndItemIndex = -1;
    args.beforeSelection = null;
    const action = function () {
      args.$rows = this.$('> div.fr-grid-body-container > div.lock > table > tbody, > div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx > table > tbody').children('tr[data-body-row-index]');
      args.$rows.children('td[data-body-cell-index]').not('.selectable').addClass('selectable').on('mouseover', function (mouseoverEvent) {
        if (mouseoverEvent.buttons === 1) {
          const $moveCell = this.$(mouseoverEvent.currentTarget), moveColumnIndex = parseInt($moveCell.attr('data-body-cell-index')), moveItemIndex = parseInt($moveCell.parent('tr').attr('data-body-row-index'));

          $moveCell.focus();
          if (args.selectionType === 'row' || args.selectionType === 'checkbox') {
            const _items = this.get('_items'), _selectedItems = this.get('_selectedItems');

            if (args.beforeEndItemIndex !== moveItemIndex) {
              args.beforeEndItemIndex = moveItemIndex;
              if (args.selectionMode === 'single') {
                if (Ember.isNone(args.beforeSelection)) {
                  args.beforeSelection = Ember.A();
                  args.beforeSelection.addObjects(_selectedItems);
                }
                _selectedItems.clear();
                _selectedItems.addObject(_items.objectAt(moveItemIndex));
              }
              if (args.selectionMode === 'multi') {
                if (mouseoverEvent.ctrlKey) {
                  _items.slice(Math.min(args.startItemIndex, moveItemIndex), Math.max(args.startItemIndex, moveItemIndex) + 1).forEach(function (item) {
                    if (!_selectedItems.includes(item)) {
                      if (Ember.isNone(args.beforeSelection)) {
                        args.beforeSelection = Ember.A();
                        args.beforeSelection.addObjects(_selectedItems);
                      }
                      _selectedItems.addObject(item);
                    }
                  });
                } else {
                  if (Ember.isNone(args.beforeSelection)) {
                    args.beforeSelection = Ember.A();
                    args.beforeSelection.addObjects(_selectedItems);
                  }
                  _selectedItems.clear();
                  _selectedItems.addObjects(_items.slice(Math.min(args.startItemIndex, moveItemIndex), Math.max(args.startItemIndex, moveItemIndex) + 1));
                }
              }
            }
          }
          if (args.selectionType === 'cell') {
            const _items = this.get('_items'), _bindingColumns = this.get('_bindingColumns'), _selectedCells = this.get('_selectedCells');

            if (args.selectionMode === 'single') {
              if (Ember.isNone(args.beforeSelection)) {
                args.beforeSelection = Ember.A();
                args.beforeSelection.addObjects(_selectedCells);
              }
              _selectedCells.clear();
              _selectedCells.addObject({ item: _items.objectAt(moveItemIndex), column: _bindingColumns.objectAt(moveColumnIndex) });
            }
            if (args.selectionMode === 'multi') {
              if (mouseoverEvent.ctrlKey) {
                _items.slice(Math.min(args.startItemIndex, moveItemIndex), Math.max(args.startItemIndex, moveItemIndex) + 1).forEach(function (item) {
                  _bindingColumns.slice(Math.min(args.startColumnIndex, moveColumnIndex), Math.max(args.startColumnIndex, moveColumnIndex) + 1).forEach(function (column) {
                    if (Ember.isNone(_selectedCells.filterBy('item', item).findBy('column', column))) {
                      if (Ember.isNone(args.beforeSelection)) {
                        args.beforeSelection = Ember.A();
                        args.beforeSelection.addObjects(_selectedCells);
                      }
                      _selectedCells.addObject({ item: item, column: column });
                    }
                  });
                });
              } else {
                if (Ember.isNone(args.beforeSelection)) {
                  args.beforeSelection = Ember.A();
                  args.beforeSelection.addObjects(_selectedCells);
                }
                _selectedCells.clear();
                _items.slice(Math.min(args.startItemIndex, moveItemIndex), Math.max(args.startItemIndex, moveItemIndex) + 1).forEach(function (item) {
                  _bindingColumns.slice(Math.min(args.startColumnIndex, moveColumnIndex), Math.max(args.startColumnIndex, moveColumnIndex) + 1).forEach(function (column) {
                    _selectedCells.addObject({ item: item, column: column });
                  });
                });
              }
            }
          }
        }
      }.bind(this));
    }.bind(this);

    this.get('_virtualizationRowChangeQueue').addObject({ key: 'mousedown', action: action });
    action();
    Ember.$(document).on(`mouseup.fr-grid-range-${this.get('_gridGuid')}`, function () {
      let isChange = false;

      if (!Ember.isNone(args.beforeSelection)) {
        if (args.selectionType === 'row' || args.selectionType === 'checkbox') {
          const _selectedItems = this.get('_selectedItems');

          if (args.beforeSelection.length === _selectedItems.length) {
            args.beforeSelection.removeObjects(_selectedItems);
            isChange = !Ember.isEmpty(args.beforeSelection);
          } else {
            isChange = true;
          }
        }
        if (args.selectionType === 'cell') {
          const _selectedCells = this.get('_selectedCells');

          if (args.beforeSelection.length === _selectedCells.length) {
            for (let i = 0; i < _selectedCells.length; i++) {
              if (!args.beforeSelection.filterBy('item', _selectedCells[i].item)
              .findBy('column', _selectedCells[i].column)) {
                isChange = true;
                break;
              }
            }
          } else {
            isChange = true;
          }
        }
      }
      this.get('_virtualizationRowChangeQueue').removeObjects(this.get('_virtualizationRowChangeQueue').filterBy('key','mousedown'));
      args.$rows.children('td[data-body-cell-index]').filter('.selectable').removeClass('selectable').off('mouseover');
      Ember.$(document).off(`mouseup.fr-grid-range-${this.get('_gridGuid')}`);
      this._releaseObjectProperty(args);
      if (isChange) {
        this._runOnceSelectionChange();
      }
    }.bind(this));
  },

  _bodyHandleReorderMouseDown(event) {
    if (this.get('reorderingRow')) {
      const downIndex = parseInt(this.$(event.target).closest(`.${this.get('_gridGuid')}-body-handle-reorder`).parent('tr').attr('data-body-row-index')), args = {};

      Ember.$(document).on(`dragstart.fr-grid-reordering-row-${this.get('_gridGuid')}`, function (dragstartEvent) {
        const $downRow = this.$('> div.fr-grid-body-container > div.lock > table > tbody, > div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx > table > tbody').children('tr[data-body-row-index]').filter(`[data-body-row-index=${downIndex}]`);

        args.source = this;
        args.items = this.get('_items');
        args.originalEvent = dragstartEvent;
        args.dragItems = Ember.A([ args.items.objectAt(downIndex) ]);
        args.dragTag = `<div style="width:${$downRow.outerWidth()}px;height:${$downRow.outerHeight()}px;"></div>`;
        this._tryAction('onItemDragStart', args);
        args.$ghostImage = Ember.$(`<span style="position:absolute;display:block;top:0;left:0;width:0;height:0;"></span>`).appendTo('body');
        args.$dragImage = Ember.$(`<div class="grid-drag-move" style="position:absolute;left:${dragstartEvent.clientX}px;top:${dragstartEvent.clientY}px;z-index:10000;pointer-events:none;"><div>`).append(args.dragTag).appendTo('body');
        args.$pointer = Ember.$(`<div class="grid-drag-point row" style="position:absolute;left:${$downRow.offset().left}px;width:${$downRow.outerWidth()}px;pointer-events:none;"><span></span></div>`);
        args.$switch = args.$pointer;
        args.indexArray = args.dragItems.map(function (item) {
          return args.items.indexOf(item);
        }).sort(function (a, b) {
          return a - b;
        }).uniq();
        args.startIndex = Ember.get(args.indexArray, 'firstObject');
        dragstartEvent.dataTransfer.setDragImage(args.$ghostImage.get(0), 0, 0);
        const action = function () {
          args.$rows = this.$('> div.fr-grid-body-container > div.lock > table > tbody, > div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx > table > tbody').children('tr[data-body-row-index]');
          const $startRows = args.$rows.not('.draggable').filter(function () {
            return args.indexArray.includes(parseInt(Ember.$(this).attr('data-body-row-index')));
          });

          if ($startRows.length > 0) {
            $startRows.children('td').prepend(`<div class="grid-drag-off"></div>`);
            $startRows.addClass('draggable');
          }
          args.$rows.not('.draggable').not('.droppable').addClass('droppable').on('dragover', function (dragoverEvent) {
            dragoverEvent.stopPropagation();
            dragoverEvent.preventDefault();
          }).on('dragenter', function (dragenterEvent) {
            dragenterEvent.stopPropagation();
            dragenterEvent.preventDefault();
            const enterIndex = parseInt(this.$(dragenterEvent.currentTarget).attr('data-body-row-index')), $enterRow = args.$rows.filter(`[data-body-row-index=${enterIndex}]`);

            args.$pointer.css({ 'top': `${args.startIndex < enterIndex ? $enterRow.offset().top + $enterRow.outerHeight() - 12 : $enterRow.offset().top - 12}px` });
            $enterRow.children('td').prepend(`<div class="grid-drag-on"></div>`);
            if (args.$switch) {
              args.$switch.appendTo('body');
              args.$switch = null;
            } else {
              args.$switch = args.$pointer.detach();
            }
          }.bind(this)).on('dragleave', function (dragleaveEvent) {
            dragleaveEvent.stopPropagation();
            dragleaveEvent.preventDefault();
            const leaveIndex = parseInt(this.$(dragleaveEvent.currentTarget).attr('data-body-row-index')), $leaveRow = args.$rows.filter(`[data-body-row-index=${leaveIndex}]`);

            $leaveRow.children('td').children(`.grid-drag-on:first-child`).remove();
            if (args.$switch) {
              args.$switch.appendTo('body');
              args.$switch = null;
            } else {
              args.$switch = args.$pointer.detach();
            }
          }.bind(this)).on('drop', function (dropEvent) {
            dropEvent.stopPropagation();
            dropEvent.preventDefault();
            const originItems = args.items.objectsAt(args.indexArray), dropIndex = parseInt(this.$(dropEvent.currentTarget).attr('data-body-row-index')), dropItem = args.items.objectAt(dropIndex);

            args.items.removeObjects(originItems);

            const insertIndex = args.startIndex < dropIndex ? args.items.indexOf(dropItem) + 1 : args.items.indexOf(dropItem);

            originItems.reverse().forEach(function (item) {
              args.items.insertAt(insertIndex, item);
            });
          }.bind(this));
        }.bind(this);

        this.get('_virtualizationRowChangeQueue').addObject({ key: 'reorder', action: action });
        action();
      }.bind(this)).on(`drag.fr-grid-reordering-row-${this.get('_gridGuid')}`, function (dragEvent) {
        args.$dragImage.css({ 'left': `${dragEvent.originalEvent.clientX}px`, 'top': `${dragEvent.originalEvent.clientY}px` });
      }).on(`dragend.fr-grid-reordering-row-${this.get('_gridGuid')}`, function (dragendEvent) {
        this.get('_virtualizationRowChangeQueue').removeObjects(this.get('_virtualizationRowChangeQueue').filterBy('key','reorder'));
        args.$rows.filter('.droppable').children('td').children(`.grid-drag-on`).remove();
        args.$rows.filter('.droppable').removeClass('droppable').off('dragover').off('dragenter').off('dragleave').off('drop');
        args.$rows.filter('.draggable').removeClass('draggable').children('td').children(`.grid-drag-off`).remove();
        args.$dragImage.remove();
        args.$ghostImage.remove();
        args.$pointer.remove();
        this._releaseObjectProperty(args);
        this._tryAction('onItemDragEnd', { source: this, originalEvent: dragendEvent });
        Ember.$(document).off(`dragstart.fr-grid-reordering-row-${this.get('_gridGuid')}`).off(`drag.fr-grid-reordering-row-${this.get('_gridGuid')}`)
        .off(`dragend.fr-grid-reordering-row-${this.get('_gridGuid')}`).off(`mouseup.fr-grid-reordering-row-${this.get('_gridGuid')}`);
        this.$().removeAttr('draggable');
      }.bind(this)).on(`mouseup.fr-grid-reordering-row-${this.get('_gridGuid')}`, function () {
        Ember.$(document).off(`dragstart.fr-grid-reordering-row-${this.get('_gridGuid')}`).off(`drag.fr-grid-reordering-row-${this.get('_gridGuid')}`)
        .off(`dragend.fr-grid-reordering-row-${this.get('_gridGuid')}`).off(`mouseup.fr-grid-reordering-row-${this.get('_gridGuid')}`);
        this.$().removeAttr('draggable');
      }.bind(this));
      this.$().attr('draggable', true);
    }
  },

  _bodyCellFocusOut(event) {
    let $target = this.$(event.target).closest(`.${this.get('_gridGuid')}-body-cell`);

    if (!this.get('element').contains(event.relatedTarget) || !this.$(event.relatedTarget).closest(`.${this.get('_gridGuid')}-body-cell`).is($target)) {
      this._cellEditingStop($target);
    }
    $target = null;
  },

  _rowSingleClick(event, rowIndex, cellIndex) {
    if (event.ctrlKey) {
      this._rowSingleCtrlClick(rowIndex, cellIndex);
    } else if (event.shiftKey) {
      this._rowSingleShiftClick(rowIndex, cellIndex);
    } else {
      this._rowDefaultClick(rowIndex, cellIndex);
    }
  },

  _rowMultiClick(event, rowIndex, cellIndex) {
    if (event.ctrlKey) {
      this._rowMultiCtrlClick(rowIndex, cellIndex);
    } else if (event.shiftKey) {
      this._rowMultiShiftClick(rowIndex, cellIndex);
    } else {
      this._rowDefaultClick(rowIndex, cellIndex);
    }
  },

  _cellSingleClick(event, rowIndex, cellIndex) {
    if (event.ctrlKey) {
      this._cellSingleCtrlClick(rowIndex, cellIndex);
    } else if (event.shiftKey) {
      this._cellSingleShiftClick(rowIndex, cellIndex);
    } else {
      this._cellDefaultClick(rowIndex, cellIndex);
    }
  },

  _cellMultiClick(event, rowIndex, cellIndex) {
    if (event.ctrlKey) {
      this._cellMultiCtrlClick(rowIndex, cellIndex);
    } else if (event.shiftKey) {
      this._cellMultiShiftClick(rowIndex, cellIndex);
    } else {
      this._cellDefaultClick(rowIndex, cellIndex);
    }
  },

  _rowSingleCtrlClick(rowIndex, cellIndex) {
    const _items = this.get('_items'), _bindingColumns = this.get('_bindingColumns'), _selectedItems = this.get('_selectedItems'), item = _items.objectAt(rowIndex), column = _bindingColumns.objectAt(cellIndex);

    this.set('_startedCell', { item: item, column: column });
    if (!_selectedItems.includes(item)) {
      _selectedItems.clear();
      _selectedItems.addObject(item);
    } else {
      _selectedItems.clear();
    }
    this._runOnceSelectionChange();
  },

  _rowMultiCtrlClick(rowIndex, cellIndex) {
    const _items = this.get('_items'), _bindingColumns = this.get('_bindingColumns'), _selectedItems = this.get('_selectedItems'), item = _items.objectAt(rowIndex), column = _bindingColumns.objectAt(cellIndex);

    this.set('_startedCell', { item: item, column: column });
    if (!_selectedItems.includes(item)) {
      _selectedItems.addObject(item);
    } else {
      _selectedItems.removeObject(item);
    }
    this._runOnceSelectionChange();
  },

  _cellSingleCtrlClick(rowIndex, cellIndex) {
    const _items = this.get('_items'), _bindingColumns = this.get('_bindingColumns'), _selectedCells = this.get('_selectedCells'), item = _items.objectAt(rowIndex), column = _bindingColumns.objectAt(cellIndex);

    this.set('_startedCell', { item: item, column: column });
    if (!Ember.isEmpty(_selectedCells.filterBy('column', column).filterBy('item', item))) {
      _selectedCells.clear();
    } else {
      _selectedCells.clear();
      _selectedCells.addObject({ item: item, column: column });
    }
    this._runOnceSelectionChange();
  },

  _cellMultiCtrlClick(rowIndex, cellIndex) {
    const _items = this.get('_items'), _bindingColumns = this.get('_bindingColumns'), _selectedCells = this.get('_selectedCells'), item = _items.objectAt(rowIndex), column = _bindingColumns.objectAt(cellIndex), selectedCell = _selectedCells.filterBy('column', column).findBy('item', item);

    this.set('_startedCell', { item: item, column: column });
    if (selectedCell) {
      _selectedCells.removeObject(selectedCell);
    } else {
      _selectedCells.addObject({ item: item, column: column });
    }
    this._runOnceSelectionChange();
  },

  _rowSingleShiftClick(rowIndex, cellIndex) {
    this._rowDefaultClick(rowIndex, cellIndex);
  },

  _rowMultiShiftClick(rowIndex, cellIndex) {
    const _startedCell = this.get('_startedCell');

    if (_startedCell) {
      const _items = this.get('_items'), startItemIndex = _items.indexOf(_startedCell.item);

      if (0 <= startItemIndex) {
        const beforeSelection = Ember.A(), _selectedItems = this.get('_selectedItems');
        let isChange = false;

        beforeSelection.addObjects(_selectedItems);
        _selectedItems.clear();
        _selectedItems.addObjects(_items.slice(Math.min(startItemIndex, rowIndex), Math.max(startItemIndex, rowIndex) + 1));
        if (beforeSelection.length === _selectedItems.length) {
          beforeSelection.removeObjects(_selectedItems);
          isChange = !Ember.isEmpty(beforeSelection);
        } else {
          isChange = true;
        }
        if (isChange) {
          this._runOnceSelectionChange();
        }
      } else {
        this._rowDefaultClick(rowIndex, cellIndex);
      }
    } else {
      this._rowDefaultClick(rowIndex, cellIndex);
    }
  },

  _cellSingleShiftClick(rowIndex, cellIndex) {
    this._cellDefaultClick(rowIndex, cellIndex);
  },

  _cellMultiShiftClick(rowIndex, cellIndex) {
    const _startedCell = this.get('_startedCell');

    if (_startedCell) {
      const _items = this.get('_items'), _bindingColumns = this.get('_bindingColumns'), startItemIndex = _items.indexOf(_startedCell.item), startColumnIndex = _bindingColumns.indexOf(_startedCell.column);

      if (0 <= startItemIndex && 0 <= startColumnIndex) {
        const beforeSelection = Ember.A(), _selectedCells = this.get('_selectedCells');
        let isChange = false;

        beforeSelection.addObjects(_selectedCells);
        _selectedCells.clear();
        _items.slice(Math.min(startItemIndex, rowIndex), Math.max(startItemIndex, rowIndex) + 1).forEach(function (item) {
          _bindingColumns.slice(Math.min(startColumnIndex, cellIndex), Math.max(startColumnIndex, cellIndex) + 1).forEach(function (column) {
            _selectedCells.addObject({ item: item, column: column });
          });
        });
        if (beforeSelection.length === _selectedCells.length) {
          for (let i = 0; i < _selectedCells.length; i++) {
            if (!beforeSelection.filterBy('item', _selectedCells[i].item)
            .findBy('column', _selectedCells[i].column)) {
              isChange = true;
              break;
            }
          }
        } else {
          isChange = true;
        }
        if (isChange) {
          this._runOnceSelectionChange();
        }
      } else {
        this._cellDefaultClick(rowIndex, cellIndex);
      }
    } else {
      this._cellDefaultClick(rowIndex, cellIndex);
    }
  },

  _rowDefaultClick(rowIndex, cellIndex) {
    const _items = this.get('_items'), _bindingColumns = this.get('_bindingColumns'), _selectedItems = this.get('_selectedItems'), item = _items.objectAt(rowIndex), column = _bindingColumns.objectAt(cellIndex);

    this.set('_startedCell', { item: item, column: column });
    if (!_selectedItems.includes(item) || 2 <= _selectedItems.length) {
      _selectedItems.clear();
      _selectedItems.addObject(item);
      this._runOnceSelectionChange();
    }
  },

  _cellDefaultClick(rowIndex, cellIndex) {
    const _items = this.get('_items'), _bindingColumns = this.get('_bindingColumns'), _selectedCells = this.get('_selectedCells'),
      item = _items.objectAt(rowIndex), column = _bindingColumns.objectAt(cellIndex);

    this.set('_startedCell', { item: item, column: column });
    if (_selectedCells.filterBy('column', column).filterBy('item', item).length === 0 || 2 <= _selectedCells.length) {
      _selectedCells.clear();
      _selectedCells.addObject({ item: item, column: column });
      this._runOnceSelectionChange();
    }
  },

  _moveFirstCell() {
    if (this.get('_bindingColumns.length') === 0 || this.get('_items.length') === 0) {
      return true;
    }
    this._editingCell(0, 0);
    Ember.run.schedule('afterRender', this, function () {
      if (this.$('> div.fr-grid-body-container > div.lock > table > tbody, > div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx > table > tbody').children('tr[data-body-row-index]')
      .filter(`[data-body-row-index=0]`).children(`td[data-body-cell-index=0]`).is(':focusable')) {
        this._moveSelectedCell(0, 0);
      }
    });
  },

  _movePrevCell($cell) {
    let cellIndex = parseInt($cell.attr('data-body-cell-index')) - 1, rowIndex = parseInt($cell.parent('tr').attr('data-body-row-index'));

    if (cellIndex < 0) {
      rowIndex = rowIndex - 1;
      if (rowIndex < 0) {
        return true;
      }
      cellIndex = Math.max(this.get('_bindingColumns.length') - 1, 0);
    }
    this._editingCell(rowIndex, cellIndex);
    Ember.run.schedule('afterRender', this, function () {
      if (this.$('> div.fr-grid-body-container > div.lock > table > tbody, > div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx > table > tbody').children('tr[data-body-row-index]')
      .filter(`[data-body-row-index=${rowIndex}]`).children(`td[data-body-cell-index=${cellIndex}]`).is(':focusable')) {
        this._moveSelectedCell(rowIndex, cellIndex);
      }
    });
  },

  _moveNextCell($cell) {
    let cellIndex = parseInt($cell.attr('data-body-cell-index')) + 1, rowIndex = parseInt($cell.parent('tr').attr('data-body-row-index'));

    if (this.get('_bindingColumns.length') <= cellIndex) {
      cellIndex = 0;
      rowIndex = rowIndex + 1;
      if (this.get('_items.length') <= rowIndex) {
        return true;
      }
    }
    this._editingCell(rowIndex, cellIndex);
    Ember.run.schedule('afterRender', this, function () {
      if (this.$('> div.fr-grid-body-container > div.lock > table > tbody, > div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx > table > tbody').children('tr[data-body-row-index]')
      .filter(`[data-body-row-index=${rowIndex}]`).children(`td[data-body-cell-index=${cellIndex}]`).is(':focusable')) {
        this._moveSelectedCell(rowIndex, cellIndex);
      }
    });
  },

  _moveNextLineCell($cell) {
    const cellIndex = parseInt($cell.attr('data-body-cell-index')), rowIndex = parseInt($cell.parent('tr').attr('data-body-row-index')) + 1;

    if (this.get('_items.length') <= rowIndex) {
      return;
    }
    this._editingCell(rowIndex, cellIndex);
    Ember.run.schedule('afterRender', this, function () {
      if (this.$('> div.fr-grid-body-container > div.lock > table > tbody, > div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx > table > tbody').children('tr[data-body-row-index]')
      .filter(`[data-body-row-index=${rowIndex}]`).children(`td[data-body-cell-index=${cellIndex}]`).is(':focusable')) {
        this._moveSelectedCell(rowIndex, cellIndex);
      }
    });
  },

  _moveLeftCell($cell) {
    const cellIndex = parseInt($cell.attr('data-body-cell-index')) - 1, rowIndex = parseInt($cell.parent('tr').attr('data-body-row-index'));

    if (cellIndex < 0) {
      return;
    }
    this._focusCell(rowIndex, cellIndex);
    Ember.run.schedule('afterRender', this, function () {
      if (this.$('> div.fr-grid-body-container > div.lock > table > tbody, > div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx > table > tbody').children('tr[data-body-row-index]')
      .filter(`[data-body-row-index=${rowIndex}]`).children(`td[data-body-cell-index=${cellIndex}]`).is(':focusable')) {
        this._moveSelectedCell(rowIndex, cellIndex);
      }
    });
  },

  _moveUpCell($cell) {
    const cellIndex = parseInt($cell.attr('data-body-cell-index')), rowIndex = parseInt($cell.parent('tr').attr('data-body-row-index')) - 1;

    if (rowIndex < 0) {
      return;
    }
    this._focusCell(rowIndex, cellIndex);
    Ember.run.schedule('afterRender', this, function () {
      if (this.$('> div.fr-grid-body-container > div.lock > table > tbody, > div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx > table > tbody').children('tr[data-body-row-index]')
      .filter(`[data-body-row-index=${rowIndex}]`).children(`td[data-body-cell-index=${cellIndex}]`).is(':focusable')) {
        this._moveSelectedCell(rowIndex, cellIndex);
      }
    });
  },

  _moveRightCell($cell) {
    const cellIndex = parseInt($cell.attr('data-body-cell-index')) + 1, rowIndex = parseInt($cell.parent('tr').attr('data-body-row-index'));

    if (this.get('_bindingColumns.length') <= cellIndex) {
      return;
    }
    this._focusCell(rowIndex, cellIndex);
    Ember.run.schedule('afterRender', this, function () {
      if (this.$('> div.fr-grid-body-container > div.lock > table > tbody, > div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx > table > tbody').children('tr[data-body-row-index]')
      .filter(`[data-body-row-index=${rowIndex}]`).children(`td[data-body-cell-index=${cellIndex}]`).is(':focusable')) {
        this._moveSelectedCell(rowIndex, cellIndex);
      }
    });
  },

  _moveDownCell($cell) {
    const cellIndex = parseInt($cell.attr('data-body-cell-index')), rowIndex = parseInt($cell.parent('tr').attr('data-body-row-index')) + 1;

    if (this.get('_items.length') <= rowIndex) {
      return;
    }
    this._focusCell(rowIndex, cellIndex);
    Ember.run.schedule('afterRender', this, function () {
      if (this.$('> div.fr-grid-body-container > div.lock > table > tbody, > div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx > table > tbody').children('tr[data-body-row-index]')
      .filter(`[data-body-row-index=${rowIndex}]`).children(`td[data-body-cell-index=${cellIndex}]`).is(':focusable')) {
        this._moveSelectedCell(rowIndex, cellIndex);
      }
    });
  },

  _cancelEditingCell($cell) {
    this._cellEditingStop($cell);
    $cell.focus();
  },

  _cellEditingStart($cell) {
    let component = this._getComponent($cell), isEditing = false;

    if (Ember.get(component, '_editing')) {
      isEditing = true;
    }
    if (!Ember.get(component, 'editing')) {
      Ember.set(component, 'editing', true);
    }
    if (!isEditing && Ember.get(component, '_editing')) {
      this._tryAction('onEditingStart', {
        source: this,
        originalSource: component,
        item: Ember.get(component, 'item'),
        column: Ember.get(component, 'column')
      });
      Ember.run.next(this, function() {
        if (!Ember.get(component, 'isDestroying') && !Ember.get(component, 'isDestroyed')) {
          if (!Ember.isNone(Ember.get(component, 'column.focusableIndex'))) {
            component.$(`:focusable:eq(${Ember.get(component, 'column.focusableIndex')})`).focus();
          } else {
            component.$(`:focusable`).focus();
          }
          component = null;
        }
      });
    }
  },

  _cellEditingStop($cell) {
    let component = this._getComponent($cell), isEditing = false;

    if (Ember.get(component, '_editing')) {
      isEditing = true;
    }
    if (Ember.get(component, 'editing')) {
      Ember.set(component, 'editing', false);
    }
    if (isEditing && !Ember.get(component, '_editing')) {
      this._tryAction('onEditingEnd', {
        source: this,
        originalSource: component,
        item: Ember.get(component, 'item'),
        column: Ember.get(component, 'column')
      });
    }
    component = null;
  },

  _moveSelectedCell(rowIndex, cellIndex) {
    const selectionType = this.get('selectionType');

    if (selectionType === 'row' || selectionType === 'checkbox') {
      this._rowDefaultClick(rowIndex, cellIndex);
    }
    if (selectionType === 'cell') {
      this._cellDefaultClick(rowIndex, cellIndex);
    }
  },

  _updateLayout() {
    const columnResizeType = this.get('columnResizeType'), fillLastColumn = this.get('fillLastColumn');

    if (columnResizeType === 'flex' && fillLastColumn) {
      const _unlockTableWidth = parseFloat(this.get('_unlockTableWidth').toFixed(3)), _bodyUnlockBlockWidth = parseFloat(this.get('_bodyUnlockBlockWidth').toFixed(3));

      if (parseInt(_bodyUnlockBlockWidth - _unlockTableWidth) > 0) {
        this._fillLastColumn(_unlockTableWidth, _bodyUnlockBlockWidth);
      }
    }
    if (columnResizeType === 'fit') {
      const _isMinWidthAllColumns = this.get('_isMinWidthAllColumns'), _tableWidth = parseFloat(this.get('_lockTableWidth').toFixed(3)) + parseFloat(this.get('_unlockTableWidth').toFixed(3)),
        _allBlockWidthWithoutScroll = parseFloat(this.get('_lockTableWidth').toFixed(3)) + parseFloat(this.get('_bodyUnlockBlockWidth').toFixed(3));

      if (parseInt(_tableWidth - _allBlockWidthWithoutScroll + 1) < 0 || (!_isMinWidthAllColumns && parseInt(_tableWidth - _allBlockWidthWithoutScroll - 1) > 0)) {
        this._fitAllColumns(_tableWidth, _allBlockWidthWithoutScroll);
      }
    }
  },

  _headDepth(_columns) {
    const result = 1;
    let max = 0, visibleColumns;

    for (let i = 0; i < _columns.length; i++) {
      if (_columns[i].hidden) {
        continue;
      }
      visibleColumns = Ember.A(_columns[i].columns).rejectBy('hidden', true);
      if (!Ember.isEmpty(visibleColumns)) {
        const temp = this._headDepth(visibleColumns);

        if (temp > max) {
          max = temp;
        }
      }
    }

    return result + max;
  },

  _initializeColumns(_columns, maxDepth, depth, _headRows) {
    if (_headRows.length <= maxDepth - depth) {
      _headRows.addObject(Object.create({ columns: Ember.A(), startIndex: 0 }));
    }
    for (let i = 0; i < _columns.length; i++) {
      if (_columns[i].hidden) {
        continue;
      }
      const visibleColumns = Ember.A(_columns[i].columns).rejectBy('hidden', true);

      if (!Ember.isEmpty(visibleColumns)) {
        this._initializeColumns(visibleColumns, maxDepth, depth - 1, _headRows);
      }
      _headRows[maxDepth - depth].columns.addObject(_columns[i]);
    }
  },

  _initializeBindingColumns(_columns, maxDepth, depth, _bindingColumns, topKey, locked) {
    for (let i = 0; i < _columns.length; i++) {
      if (_columns[i].hidden) {
        continue;
      }
      if (Ember.isEmpty(_columns[i].key)) {
        Ember.set(_columns[i], 'key', '_' + Math.floor((1 + Math.random()) * 0x1000000).toString(16).substring(1));
      }
      if (maxDepth === depth) {
        locked = _columns[i].locked;
        topKey = _columns[i].key;
      }
      Ember.set(_columns[i], 'locked', locked);
      Ember.set(_columns[i], 'topKey', topKey);
      const visibleColumns = Ember.A(_columns[i].columns).rejectBy('hidden', true);

      if (!Ember.isEmpty(visibleColumns)) {
        this._initializeBindingColumns(visibleColumns, maxDepth, depth - 1, _bindingColumns, topKey, locked);
        let colspan = 0;

        for (let j = 0; j < visibleColumns.length; j++) {
          colspan += visibleColumns[j].colspan;
          if (Ember.get(visibleColumns, 'lastObject') === visibleColumns[j]) {
            if (visibleColumns[j].styleOwner) {
              Ember.set(_columns[i], 'styleOwner', visibleColumns[j].styleOwner);
            } else {
              Ember.set(_columns[i], 'styleOwner', visibleColumns[j].key);
            }
          }
        }
        Ember.set(_columns[i], 'rowspan', 1);
        Ember.set(_columns[i], 'colspan', colspan);
      } else {
        if (Ember.isNone(_columns[i].autoWidth)) {
          if (Ember.isNone(_columns[i].width)) {
            Ember.set(_columns[i], 'autoWidth', true);
            Ember.set(_columns[i], 'width', 10);
          } else {
            Ember.set(_columns[i], 'autoWidth', false);
            Ember.set(_columns[i], 'originWidth', _columns[i].width);
          }
        }
        Ember.set(_columns[i], 'width', Math.max(10, _columns[i].width));
        Ember.set(_columns[i], 'styleOwner', _columns[i].key);
        Ember.set(_columns[i], 'rowspan', depth);
        Ember.set(_columns[i], 'colspan', 1);
        if (Ember.get(_columns[i], 'locked')) {
          _bindingColumns.insertAt(_bindingColumns.filterBy('locked', true).length, _columns[i]);
        } else {
          _bindingColumns.addObject(_columns[i]);
        }
      }
    }
  },

  _frozenValidation(_columns, _bindingColumns) {
    if (!Ember.isEmpty(_bindingColumns) && Ember.isEmpty(_bindingColumns.rejectBy('locked', true))) {
      Ember.A(_columns).filterBy('topKey', _bindingColumns.get('lastObject.topKey')).forEach(function (column) {
        Ember.set(column, 'locked', false);
      });
    }
  },

  _virtualizationColumnChange(scrollLeft) {
    const _virtualizationColumnChangeQueue = this.get('_virtualizationColumnChangeQueue'), garbage = Ember.A();

    _virtualizationColumnChangeQueue.forEach(function (queue) {
      if (queue.key === 'focus' && scrollLeft === queue.scrollLeft) {
        garbage.addObject(queue);
        queue.action();
      } else if (queue.key === 'reorder') {
        queue.action();
      }
    });
    _virtualizationColumnChangeQueue.removeObjects(garbage);
  },

  _virtualizationRowChange(scrollTop) {
    const _virtualizationRowChangeQueue = this.get('_virtualizationRowChangeQueue'), garbage = Ember.A();

    _virtualizationRowChangeQueue.forEach(function (queue) {
      if (queue.key === 'focus' && scrollTop === queue.scrollTop) {
        garbage.addObject(queue);
        queue.action();
      } else if (queue.key === 'reorder' || queue.key === 'mousedown') {
        queue.action();
      }
    });
    _virtualizationRowChangeQueue.removeObjects(garbage);
  },

  _fillLastColumn(_unlockTableWidth, _bodyUnlockBlockWidth) {
    const _bindingColumns = this.get('_bindingColumns'), lastColumn = Ember.get(_bindingColumns.rejectBy('locked', true), 'lastObject');

    if (lastColumn) {
      Ember.set(lastColumn, 'width', Math.max(10, Ember.get(lastColumn, 'width') + _bodyUnlockBlockWidth - _unlockTableWidth));
    }
  },

  _fitAllColumns(_tableWidth, _bodyBlockWidth) {
    const _bindingColumns = this.get('_bindingColumns');

    if (!Ember.isEmpty(_bindingColumns)) {
      const fixedWidthColumns = _bindingColumns.filterBy('autoWidth', false), autoWidthColumns = _bindingColumns.filterBy('autoWidth', true);
      let remainWidth = _bodyBlockWidth - _tableWidth, columnWidth = 0, originWidth = 0;

      for (let i = 0; i < fixedWidthColumns.length; i++) {
        columnWidth = Ember.get(fixedWidthColumns.objectAt(i), 'width');
        originWidth = Ember.get(fixedWidthColumns.objectAt(i), 'originWidth');
        Ember.set(fixedWidthColumns.objectAt(i), 'width', Math.max(10, originWidth));
        remainWidth = remainWidth + columnWidth - Math.max(10, originWidth);
      }
      if (remainWidth !== 0) {
        remainWidth = this._adjustColumnsWidth(remainWidth, autoWidthColumns);
      }
      if (remainWidth !== 0) {
        remainWidth = this._adjustColumnsWidth(remainWidth, fixedWidthColumns);
      }
    }
  },

  _adjustColumnsWidth(remainWidth, remainColumns) {
    if (!Ember.isEmpty(remainColumns)) {
      const add = parseInt(remainWidth / remainColumns.length);
      let columnWidth = 0;

      if (add === 0) {
        if (remainWidth > 0) {
          for (let i = remainColumns.length - 1; i >= 0; i--) {
            if (remainWidth === 0) {
              break;
            }
            columnWidth = Ember.get(remainColumns.objectAt(i), 'width');
            Ember.set(remainColumns.objectAt(i), 'width', Math.max(10, columnWidth + Math.min(1, remainWidth)));
            remainWidth = remainWidth + columnWidth - Math.max(10, columnWidth + Math.min(1, remainWidth));
          }
        } else {
          for (let i = remainColumns.length - 1; i >= 0; i--) {
            if (remainWidth === 0) {
              break;
            }
            columnWidth = Ember.get(remainColumns.objectAt(i), 'width');
            Ember.set(remainColumns.objectAt(i), 'width', Math.max(10, columnWidth - Math.max(1, remainWidth)));
            remainWidth = remainWidth + columnWidth - Math.max(10, columnWidth - Math.max(1, remainWidth));
            if (Math.max(10, columnWidth - Math.max(1, remainWidth)) === 10) {
              remainColumns.removeObject(remainColumns.objectAt(i));
            }
          }
          if (remainWidth !== 0) {
            remainWidth = this._adjustColumnsWidth(remainWidth, remainColumns);
          }
        }
      } else {
        for (let i = remainColumns.length - 1; i >= 0; i--) {
          columnWidth = Ember.get(remainColumns.objectAt(i), 'width');
          Ember.set(remainColumns.objectAt(i), 'width', Math.max(10, columnWidth + add));
          remainWidth = remainWidth + columnWidth - Math.max(10, columnWidth + add);
          if (Math.max(10, columnWidth + add) === 10) {
            remainColumns.removeObject(remainColumns.objectAt(i));
          }
        }
        remainWidth = this._adjustColumnsWidth(remainWidth, remainColumns);
      }
    }

    return remainWidth;
  },

  _runOnceItemsSourceChange(_itemsSource) {
    Ember.run.once(this, this._itemsSourceChange, _itemsSource);
  },

  _itemsSourceChange(_itemsSource) {
    const selectionType = this.get('selectionType');

    if (selectionType === 'row' || selectionType === 'checkbox') {
      const _selectedItems = this.get('_selectedItems'), selectedItemsGarbage = Ember.A();

      if (Ember.isEmpty(_itemsSource) && !Ember.isEmpty(_selectedItems)) {
        _selectedItems.clear();
        this._runOnceSelectionChange();
      } else {
        _selectedItems.forEach(function (item) {
          if (!_itemsSource.includes(item)) {
            selectedItemsGarbage.addObject(item);
          }
        });
        if (!Ember.isEmpty(selectedItemsGarbage)) {
          _selectedItems.removeObjects(selectedItemsGarbage);
          this._runOnceSelectionChange();
        }
      }
    }
    if (selectionType === 'cell') {
      const _selectedCells = this.get('_selectedCells');

      if (Ember.isEmpty(_itemsSource) && !Ember.isEmpty(_selectedCells)) {
        _selectedCells.clear();
        this._runOnceSelectionChange();
      } else {
        let changed = false;

        _selectedCells.uniqBy('item').forEach(function (cell) {
          if (!_itemsSource.includes(cell.item)) {
            _selectedCells.removeObjects(_selectedCells.filterBy('item', cell.item));
            changed = true;
          }
        });
        if (changed) {
          this._runOnceSelectionChange();
        }
      }
    }
    const _detailRowItems = this.get('_detailRowItems'), detailRowsGarbage = Ember.A();

    if (!this.get('useDetailRow') || (Ember.isEmpty(_itemsSource) && !Ember.isEmpty(_detailRowItems))) {
      _detailRowItems.clear();
      this._runOnceDetailRowItemsChange();
    } else {
      _detailRowItems.forEach(function (item) {
        if (!_itemsSource.includes(item)) {
          detailRowsGarbage.addObject(item);
        }
      });
      if (!Ember.isEmpty(detailRowsGarbage)) {
        _detailRowItems.removeObjects(detailRowsGarbage);
        this._runOnceDetailRowItemsChange();
      }
    }
    const _groupRowValues = this.get('_groupRowValues'), groupRowGarbage = Ember.A();

    if (!this.get('_hasGroupOption') || (Ember.isEmpty(_itemsSource) && !Ember.isEmpty(_groupRowValues))) {
      _groupRowValues.clear();
      this._runOnceGroupRowValuesChange();
    } else {
      const groupField = Ember.get(this.get('groupOption').split(':'), 'firstObject');

      _groupRowValues.forEach(function (item) {
        if (Ember.isEmpty(_itemsSource.filterBy(groupField, item))) {
          groupRowGarbage.addObject(item);
        }
      });
      if (!Ember.isEmpty(groupRowGarbage)) {
        _groupRowValues.removeObjects(groupRowGarbage);
        this._runOnceGroupRowValuesChange();
      }
    }
  },

  _runOnceBindingColumnsChange(_bindingColumns) {
    Ember.run.once(this, this._bindingColumnsChange, _bindingColumns);
  },

  _bindingColumnsChange(_bindingColumns) {
    const selectionType = this.get('selectionType');

    if (selectionType === 'cell') {
      const _selectedCells = this.get('_selectedCells');

      if (Ember.isEmpty(_bindingColumns) && !Ember.isEmpty(_selectedCells)) {
        _selectedCells.clear();
        this._runOnceSelectionChange();
      } else {
        let changed = false;

        _selectedCells.uniqBy('column').forEach(function (cell) {
          if (!_bindingColumns.includes(cell.column)) {
            _selectedCells.removeObjects(_selectedCells.filterBy('column', cell.column));
            changed = true;
          }
        });
        if (changed) {
          this._runOnceSelectionChange();
        }
      }
    }
  },

  _getCurrentCell() {
    let cellComponent = null;
    const $currentCell = this.$('> div.fr-grid-body-container > div.lock > table > tbody, > div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx > table > tbody').find(':focus').closest(`.${this.get('_gridGuid')}-body-cell`);

    if ($currentCell.length > 0) {
      cellComponent = this._getComponent($currentCell);
    } else {
      cellComponent = {};
    }

    return { cellComponent: cellComponent, item: Ember.get(cellComponent, 'item'), column: Ember.get(cellComponent, 'column') };
  },

  _getItemIndex(item) {
    return this.get('_items').indexOf(item);
  },

  _getColumnIndex(column) {
    return this.get('_bindingColumns').indexOf(column);
  },

  _getItem(rowIndex) {
    return this.get('_items').objectAt(rowIndex);
  },

  _getColumn(cellIndex) {
    return this.get('_bindingColumns').objectAt(cellIndex);
  },

  _focusCell(rowIndex, cellIndex) {
    const action = function () {
      let $cell = this.$('> div.fr-grid-body-container > div.lock > table > tbody, > div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx > table > tbody')
        .children('tr[data-body-row-index]').filter(`[data-body-row-index=${rowIndex}]`).children('td[data-body-cell-index]').filter(`[data-body-cell-index=${cellIndex}]`);
        if($cell.is(':focusable')) {
          $cell.focus();
        }
        $cell = null;
    }.bind(this);

    if (this.get('_activeUiVirtualization') && !this.get('_virtualizationItems').includes(this.get('_items').objectAt(rowIndex))) {
      this.get('_virtualizationRowChangeQueue').addObject({ key: 'focus', scrollTop: this.$('> div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx').scrollTop(rowIndex * this.get('bodyLineHeight')).scrollTop(), action: action });
    }
    if (this.get('columnResizeType') === 'flex') {
      const _bindingColumns = this.get('_bindingColumns'), _unlockBindingColumns = _bindingColumns.rejectBy('locked', true), targetColumn = _bindingColumns.objectAt(cellIndex);

      if (_unlockBindingColumns.includes(targetColumn) && !this.get('_virtualizationBindingColumns').includes(targetColumn)) {
        let sum = 0;

        for (let i = 0; i < _unlockBindingColumns.indexOf(targetColumn); i++) {
          sum += _unlockBindingColumns[i].width;
        }
        this.get('_virtualizationColumnChangeQueue').addObject({ key: 'focus', scrollLeft: this.$('> div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx').scrollLeft(sum).scrollLeft(), action: action });
      }
    }
    if (Ember.isEmpty(this.get('_virtualizationRowChangeQueue').filterBy('key', 'focus'))
      && Ember.isEmpty(this.get('_virtualizationColumnChangeQueue').filterBy('key', 'focus'))) {
      action();
    }
  },

  _editingCell(rowIndex, cellIndex) {
    const action = function () {
      let $cell = this.$('> div.fr-grid-body-container > div.lock > table > tbody, > div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx > table > tbody')
        .children('tr[data-body-row-index]').filter(`[data-body-row-index=${rowIndex}]`).children('td[data-body-cell-index]').filter(`[data-body-cell-index=${cellIndex}]`);
      if($cell.is(':focusable')) {
        $cell.focus();
        this._cellEditingStart($cell);
      }
      $cell = null;
    }.bind(this);

    if (this.get('_activeUiVirtualization') && !this.get('_virtualizationItems').includes(this.get('_items').objectAt(rowIndex))) {
      this.get('_virtualizationRowChangeQueue').addObject({ key: 'focus', scrollTop: this.$('> div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx').scrollTop(rowIndex * this.get('bodyLineHeight')).scrollTop(), action: action });
    }
    if (this.get('columnResizeType') === 'flex') {
      const _bindingColumns = this.get('_bindingColumns'), _unlockBindingColumns = _bindingColumns.rejectBy('locked', true), targetColumn = _bindingColumns.objectAt(cellIndex);

      if (_unlockBindingColumns.includes(targetColumn) && !this.get('_virtualizationBindingColumns').includes(targetColumn)) {
        let sum = 0;

        for (let i = 0; i < _unlockBindingColumns.indexOf(targetColumn); i++) {
          sum += _unlockBindingColumns[i].width;
        }
        this.get('_virtualizationColumnChangeQueue').addObject({ key: 'focus', scrollLeft: this.$('> div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx').scrollLeft(sum).scrollLeft(), action: action });
      }
    }
    if (Ember.isEmpty(this.get('_virtualizationRowChangeQueue').filterBy('key', 'focus'))
      && Ember.isEmpty(this.get('_virtualizationColumnChangeQueue').filterBy('key', 'focus'))) {
      action();
    }
  },

  _selectRow(rowIndex) {
    const selectionType = this.get('selectionType'), selectionMode = this.get('selectionMode');

    if (selectionType === 'row' || selectionType === 'checkbox') {
      const _items = this.get('_items'), _selectedItems = this.get('_selectedItems'), item = _items.objectAt(rowIndex);

      if (!Ember.isNone(item) && !_selectedItems.includes(item)) {
        if (selectionMode === 'single') {
          _selectedItems.clear();
        }
        _selectedItems.addObject(item);
        this._runOnceSelectionChange();
      }
    }
  },

  _selectRows(rowIndexs) {
    const selectionType = this.get('selectionType'), selectionMode = this.get('selectionMode');

    if (selectionType === 'row' || selectionType === 'checkbox') {
      const _items = this.get('_items'), _selectedItems = this.get('_selectedItems');
      let item = null, isChanged = false;

      rowIndexs.forEach(function (rowIndex) {
        item = _items.objectAt(rowIndex);
        if (!Ember.isNone(item) && !_selectedItems.includes(item)) {
          if (selectionMode === 'single') {
            _selectedItems.clear();
          }
          _selectedItems.addObject(item);
          isChanged = true;
        }
      });
      if (isChanged) {
        this._runOnceSelectionChange();
      }
    }
  },

  _deselectRow(rowIndex) {
    const selectionType = this.get('selectionType');

    if (selectionType === 'row' || selectionType === 'checkbox') {
      const _items = this.get('_items'), _selectedItems = this.get('_selectedItems'), item = _items.objectAt(rowIndex);

      if (!Ember.isNone(item) && _selectedItems.includes(item)) {
        _selectedItems.removeObject(item);
        this._runOnceSelectionChange();
      }
    }
  },

  _deselectRows(rowIndexs) {
    const selectionType = this.get('selectionType');

    if (selectionType === 'row' || selectionType === 'checkbox') {
      const _items = this.get('_items'), _selectedItems = this.get('_selectedItems');
      let item = null, isChanged = false;

      rowIndexs.forEach(function (rowIndex) {
        item = _items.objectAt(rowIndex);
        if (!Ember.isNone(item) && _selectedItems.includes(item)) {
          _selectedItems.removeObject(item);
          isChanged = true;
        }
      });
      if (isChanged) {
        this._runOnceSelectionChange();
      }
    }
  },

  _selectCell(rowIndex, cellIndex) {
    const selectionType = this.get('selectionType'), selectionMode = this.get('selectionMode');

    if (selectionType === 'cell') {
      const _items = this.get('_items'), _bindingColumns = this.get('_bindingColumns'), _selectedCells = this.get('_selectedCells'), item = _items.objectAt(rowIndex), column = _bindingColumns.objectAt(cellIndex);

      if (!Ember.isNone(item) && !Ember.isNone(column)) {
        const cell = _selectedCells.filterBy('column', column).findBy('item', item);

        if (Ember.isNone(cell)) {
          if (selectionMode === 'single') {
            _selectedCells.clear();
          }
          _selectedCells.addObject({ item: item, column: column });
          this._runOnceSelectionChange();
        }
      }
    }
  },

  _deselectCell(rowIndex, cellIndex) {
    const selectionType = this.get('selectionType');

    if (selectionType === 'cell') {
      const _items = this.get('_items'), _bindingColumns = this.get('_bindingColumns'), _selectedCells = this.get('_selectedCells'), item = _items.objectAt(rowIndex), column = _bindingColumns.objectAt(cellIndex);

      if (!Ember.isNone(item) && !Ember.isNone(column)) {
        const cell = _selectedCells.filterBy('column', column).findBy('item', item);

        if (!Ember.isNone(cell)) {
          _selectedCells.removeObject(cell);
          this._runOnceSelectionChange();
        }
      }
    }
  },

  _selectAll() {
    const selectionMode = this.get('selectionMode');

    if (selectionMode === 'multi') {
      const selectionType = this.get('selectionType'), _items = this.get('_items');

      if (selectionType === 'cell') {
        const _selectedCells = this.get('_selectedCells'), _bindingColumns = this.get('_bindingColumns');

        if (_bindingColumns.length * _items.length !== _selectedCells.length) {
          _selectedCells.clear();
          _items.forEach(function (item) {
            _bindingColumns.forEach(function (column) {
              _selectedCells.addObject({ item: item, column: column });
            });
          });
          this._runOnceSelectionChange();
        }
      }
      if (selectionType === 'row' || selectionType === 'checkbox') {
        const _selectedItems = this.get('_selectedItems');

        if (_items.length !== _selectedItems.length) {
          _selectedItems.clear();
          _selectedItems.addObjects(_items);
          this._runOnceSelectionChange();
        }
      }
    }
  },

  _deselectAll() {
    const selectionType = this.get('selectionType');

    if (selectionType === 'cell') {
      const _selectedCells = this.get('_selectedCells');

      if (!Ember.isEmpty(_selectedCells)) {
        this.get('_selectedCells').clear();
        this._runOnceSelectionChange();
      }
    }
    if (selectionType === 'row' || selectionType === 'checkbox') {
      const _selectedItems = this.get('_selectedItems');

      if (!Ember.isEmpty(_selectedItems)) {
        this.get('_selectedItems').clear();
        this._runOnceSelectionChange();
      }
    }
  },

  _onContextMenuOpening(e) {
    e.originalSource = this._getOriginalSource(e.originalEvent);
    e.dataItem = {
      item: Ember.get(e.originalSource, 'item'),
      column: Ember.get(e.originalSource, 'column')
    };
  },

  _setScrollLeft(x) {
    this.$('> div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx').scrollLeft(x);
  },

  _setScrollTop(y) {
    this.$('> div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx').scrollTop(y);
  },

  _expandGroupRowByGroupValue(groupValue) {
    if (this.get('_hasGroupOption')) {
      const _groupRowValues = this.get('_groupRowValues'), _groupItems = this.get('_groupItems');

      if (!_groupRowValues.includes(groupValue) && _groupItems.findBy('groupValue', groupValue)) {
        if (this.get('groupRowExpandType') === 'single') {
          _groupRowValues.clear();
        }
        _groupRowValues.addObject(groupValue);
        this._runOnceGroupRowValuesChange();
      }
    }
  },

  _expandAllGroupRows() {
    if (this.get('_hasGroupOption') && this.get('groupRowExpandType') === 'multi') {
      const _groupItems = this.get('_groupItems'), _groupRowValues = this.get('_groupRowValues');

      if (_groupItems.length !== _groupRowValues.length) {
        _groupRowValues.clear();
        _groupRowValues.addObjects(this.get('_groupItems').map(function (groupItem) {
          return Ember.get(groupItem, 'groupValue');
        }));
        this._runOnceGroupRowValuesChange();
      }
    }
  },

  _collapseGroupRowByGroupValue(groupValue) {
    if (this.get('_hasGroupOption')) {
      const _groupRowValues = this.get('_groupRowValues');

      if (_groupRowValues.includes(groupValue)) {
        _groupRowValues.removeObject(groupValue);
        this._runOnceGroupRowValuesChange();
      }
    }
  },

  _collapseAllGroupRows() {
    const _groupRowValues = this.get('_groupRowValues');

    if (!Ember.isEmpty(_groupRowValues)) {
      _groupRowValues.clear();
      this._runOnceGroupRowValuesChange();
    }
  },

  _expandDetailRow(rowIndex) {
    if (this.get('useDetailRow')) {
      const _items = this.get('_items'), _detailRowItems = this.get('_detailRowItems'), item = _items.objectAt(rowIndex);

      if (!Ember.isNone(item) && !_detailRowItems.includes(item)) {
        if (this.get('detailRowExpandType') === 'single') {
          _detailRowItems.clear();
        }
        _detailRowItems.addObject(item);
        this._runOnceDetailRowItemsChange();
      }
    }
  },

  _expandAllDetailRows() {
    if (this.get('useDetailRow') && this.get('detailRowExpandType') === 'multi') {
      const _items = this.get('_items'), _detailRowItems = this.get('_detailRowItems');

      if (_items.length !== _detailRowItems.length) {
        _detailRowItems.clear();
        _detailRowItems.addObjects(_items);
        this._runOnceDetailRowItemsChange();
      }
    }
  },

  _collapseDetailRow(rowIndex) {
    if (this.get('useDetailRow')) {
      const _items = this.get('_items'), _detailRowItems = this.get('_detailRowItems'), item = _items.objectAt(rowIndex);

      if (!Ember.isNone(item) && _detailRowItems.includes(item)) {
        _detailRowItems.removeObject(item);
        this._runOnceDetailRowItemsChange();
      }
    }
  },

  _collapseAllDetailRows() {
    const _detailRowItems = this.get('_detailRowItems');

    if (!Ember.isEmpty(_detailRowItems)) {
      _detailRowItems.clear();
      this._runOnceDetailRowItemsChange();
    }
  },

  _closeHeadMenu() {
    this.set('_targetElement', null);
  },

  _copyToClipboard() {
    const selectionType = this.get('selectionType'), $textarea = Ember.$('<textarea>').appendTo('body'), $focus = this.$().find(':focus');
    let content = '';

    if (selectionType === 'row' || selectionType === 'checkbox') {
      const _bindingColumns = this.get('_bindingColumns');

      this.get('_sortedSelectedItems').forEach(function (item) {
        _bindingColumns.forEach(function (column) {
          content += Ember.get(item, column.field) + '\t';
        });
        content = content.substring(0, content.length - 1) + '\r\n';
      });
      content = content.substring(0, content.length - 2);
    }
    if (selectionType === 'cell') {
      let tempItem = null;

      this.get('_sortedSelectedCells').forEach(function (cell) {
        if (tempItem !== cell.item) {
          tempItem = cell.item;
          if (content.length > 0) {
            content = content.substring(0, content.length - 1) + '\r\n';
          }
        }
        content += Ember.get(cell.item, cell.column.field) + '\t';
      });
      content = content.substring(0, content.length - 1);
    }
    $textarea.val(content).select();
    document.execCommand('copy');
    $textarea.remove();
    $focus.focus();
  },

  _exportToExcel() {
    const _items = this.get('_items'), _headRows = this.get('_headRows'), _bindingColumns = this.get('_bindingColumns'), _i18n = this.get('_i18n');
    let content = ``;

    content += `<table>
                  <thead>`;
    _headRows.forEach(function (row) {
      content += `<tr>`;
      row.columns.forEach(function (column) {
        content += `<th style="border: 1px solid black;" colspan="${column.colspan}" rowspan="${column.rowspan}">${column.title}</th>`;
      });
      content += `</tr>`;
    });
    content += `</thead>
              <tbody>`;
    _items.forEach(function (item) {
      content += `<tr>`;
      _bindingColumns.forEach(function (column) {
        if (column.type === 'date') {
          content += `<td style="width: ${column.width}px; border: 1px solid black;">${_i18n.formatDate(Ember.get(item, column.field), column.format)}</td>`;
        } else {
          content += `<td style="width: ${column.width}px; border: 1px solid black;">${Ember.get(item, column.field)}</td>`;
        }
      });
      content += `</tr>`;
    });
    content += `</tbody>
              </table>`;

    return window.open('data:application/vnd.ms-excel,' + encodeURIComponent(content));
  },

  _runOnceBodyUnlockBlockSizeChange(width, height) {
    Ember.run.once(this, this._bodyUnlockBlockSizeChange, width, height);
  },

  _bodyUnlockBlockSizeChange(width, height) {
    this.set('_bodyUnlockBlockWidth', width);
    this.set('_bodyUnlockBlockHeight', height);
  },

  _runScrollChange() {
    const $unlockBody = this.$('> div.fr-grid-body-container > div.unlock > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx');
    let x = $unlockBody.scrollLeft(), y = $unlockBody.scrollTop();

    if (this.get('_scrollLeft') !== x || this.get('_scrollTop') !== y) {
      Ember.run(this, function () {
        this.set('_scrollLeft', x);
        this.set('_scrollTop', y);
        this._tryAction('onScroll', { source: this, left: x, top: y });
      });
    }
    x = null;
    y = null;
  },

  _runOnceSelectionChange() {
    Ember.run.once(this, this._selectionChange);
  },

  _selectionChange() {
    if (this.get('_useSelectedItem')) {
      const selectedItem = this.get('selectedItem'), lastSelectedItem = this.get('_selectedItems.lastObject');

      if ((selectedItem && lastSelectedItem && selectedItem !== lastSelectedItem) || (!selectedItem && lastSelectedItem)) {
        this.set('selectedItem', lastSelectedItem);
      } else if (selectedItem && !lastSelectedItem) {
        this.set('selectedItem', null);
      }
    }
    this._tryAction('onSelectionChange', {
      source: this,
      selectedItems: this.get('selectedItems'),
      selectedCells: this.get('selectedCells')
    });
  },

  _runOnceDetailRowItemsChange() {
    Ember.run.once(this, this._detailRowItemsChange);
  },

  _detailRowItemsChange() {
    this._tryAction('onDetailRowItemsChange', {
      source: this,
      detailRowItems: this.get('detailRowItems')
    });
  },

  _runOnceGroupRowValuesChange() {
    Ember.run.once(this, this._groupRowValuesChange);
  },

  _groupRowValuesChange() {
    this._tryAction('onGroupRowValuesChange', {
      source: this,
      groupRowValues: this.get('groupRowValues')
    });
  },

  _getOriginalSource(originalEvent) {
    const _gridGuid = this.get('_gridGuid'), $target = this.$(originalEvent.target), gridElement = this.get('element');

    if ($target.closest(`.${_gridGuid}-head`, gridElement).length > 0) {
      if ($target.closest(`.${_gridGuid}-head-cell`, gridElement).length > 0) {
        return this._getComponent($target.closest(`.${_gridGuid}-head-cell`, gridElement));
      } else if ($target.closest(`.${_gridGuid}-head-handle-checkbox`, gridElement).length > 0) {
        return {
          element: $target.closest(`.${_gridGuid}-head-handle-checkbox`, gridElement).get(0)
        };
      } else if ($target.closest(`.${_gridGuid}-head-handle-empty`, gridElement).length > 0) {
        return {
          element: $target.closest(`.${_gridGuid}-head-handle-empty`, gridElement).get(0)
        };
      }

      return {
        element: $target.closest(`.${_gridGuid}-head`, gridElement).get(0)
      };
    } else if ($target.closest(`.${_gridGuid}-body`, gridElement).length > 0) {
      if ($target.closest(`.${_gridGuid}-body-cell`, gridElement).length > 0) {
        return this._getComponent($target.closest(`.${_gridGuid}-body-cell`, gridElement));
      } else if ($target.closest(`.${_gridGuid}-body-handle-checkbox`, gridElement).length > 0) {
        return {
          element: $target.closest(`.${_gridGuid}-body-handle-checkbox`, gridElement).get(0),
          item: this.get('_items').objectAt($target.closest(`.${_gridGuid}-body-handle-checkbox`, gridElement).parent('tr').attr('data-body-row-index'))
        };
      } else if ($target.closest(`.${_gridGuid}-body-handle-index`, gridElement).length > 0) {
        return {
          element: $target.closest(`.${_gridGuid}-body-handle-index`, gridElement).get(0),
          item: this.get('_items').objectAt($target.closest(`.${_gridGuid}-body-handle-index`, gridElement).parent('tr').attr('data-body-row-index'))
        };
      } else if ($target.closest(`.${_gridGuid}-body-handle-reorder`, gridElement).length > 0) {
        return {
          element: $target.closest(`.${_gridGuid}-body-handle-reorder`, gridElement).get(0),
          item: this.get('_items').objectAt($target.closest(`.${_gridGuid}-body-handle-reorder`, gridElement).parent('tr').attr('data-body-row-index'))
        };
      } else if ($target.closest(`.${_gridGuid}-body-handle-expander`, gridElement).length > 0) {
        return {
          element: $target.closest(`.${_gridGuid}-body-handle-expander`, gridElement).get(0),
          item: this.get('_items').objectAt($target.closest(`.${_gridGuid}-body-handle-expander`, gridElement).parent('tr').attr('data-body-row-index'))
        };
      } else if ($target.closest(`.${_gridGuid}-body-ghead`, gridElement).length > 0) {
        return this._getComponent($target.closest(`.${_gridGuid}-body-ghead`, gridElement));
      } else if ($target.closest(`.${_gridGuid}-body-gfoot`, gridElement).length > 0) {
        return this._getComponent($target.closest(`.${_gridGuid}-body-gfoot`, gridElement));
      } else if ($target.closest(`.${_gridGuid}-body-detail`, gridElement).length > 0) {
        return this._getComponent($target.closest(`.${_gridGuid}-body-detail`, gridElement));
      }

      return {
        element: $target.closest(`.${_gridGuid}-body`, gridElement).get(0)
      };
    } else if ($target.closest(`.${_gridGuid}-foot`, gridElement).length > 0) {
      if ($target.closest(`.${_gridGuid}-foot-cell`, gridElement).length > 0) {
        return this._getComponent($target.closest(`.${_gridGuid}-foot-cell`, gridElement));
      } else if ($target.closest(`.${_gridGuid}-foot-handle-empty`, gridElement).length > 0) {
        return {
          element: $target.closest(`.${_gridGuid}-foot-handle-empty`, gridElement).get(0)
        };
      }

      return {
        element: $target.closest(`.${_gridGuid}-foot`, gridElement).get(0)
      };
    }

    return {};
  },

  _getComponent($target) {
    let param = { component: {} }, component = null;

    $target.trigger('_getComponent', param);
    component = param.component;
    param.component = null;
    param = null;

    return component;
  },

  _tryAction(name, args) {
    const action = this.get(name);

    if (action) {
      if (Ember.isArray(args)) {
        return action(...args);
      } else {
        return action(args);
      }
    }
  },

  _releaseObjectProperty(obj) {
    Object.getOwnPropertyNames(obj).forEach(function (prop) {
      obj[prop] = null;
    });
    obj = null;
  },

  actions: {
    mouseDownToOutside(event) {
      if (!this.get('element').contains(event.target) || this.$(event.target).closest(`.${this.get('_gridGuid')}-head-cell-menu`).length === 0) {
        this.set('_targetElement', null);
      }
    },
  },
});