import Ember from 'ember';
import Control from '../fr-control/component';
import maskinput from '../maskHelper';
//import InputMixin from '../../mixins/input-mixin';

export default Control.extend(/*InputMixin, */{
  tagName: 'input',
  attributeBindings: [ '_watchPropertyChanged:data-mask', '_watchValueChanged:data-value', '_observedAttribute', 'autocomplete', 'autocorrect', 'autocapitalize', 'spellcheck', 'disabled:disabled',
    'readonly:readonly', 'required:required', 'tabindex', 'name', 'type', 'title', 'placeholder', 'autofocus',
    'value', 'pattern', 'min', 'max', 'maxlength', 'pattern', 'size', 'step' ],
  autocomplete: 'off',
  autocorrect: 'off',
  autocapitalize: 'off',
  spellcheck: false,
  mask : '',
  value : '',
  definitions : '',
  type: 'text',
  autoclear: true,
  maskPlaceholder: '_',
  _observedAttribute: Ember.computed('clearButtonVisibility', 'searchButtonVisibility', 'isDataSucess', 'isDataError', 'disabled', 'readonly', function () {
    Ember.run.schedule('afterRender', this, function () {
      if (!this.get('isDestroying') && !this.get('isDestroyed')) {
        if (this.get('clearButtonVisibility')) {
          this.$().closest('.inp-txt').addClass('focus');
        } else {
          this.$().closest('.inp-txt').removeClass('focus');
        }
        if (this.get('searchButtonVisibility')) {
          this.$().closest('.inp-txt').addClass('inp-search');
          if ( this.$().closest('.inp-txt').children('span.search').length === 0) {
            this.$().closest('.inp-txt').children('button.del').after(`<span class='search'><span class='blind'>search</span></span>`);
            this.$().closest('.inp-txt').children('span.search').on('mousedown', this._onTextSearch.bind(this));
          }
        } else {
          this.$().closest('.inp-txt').removeClass('inp-search');
          this.$().closest('.inp-txt').children('span.search').remove();
          this.$().closest('.inp-txt').children('span.search').off('mousedown');
        }
        if (this.get('isDataSucess')) {
          this.$().closest('.inp-txt').addClass('ok');
        } else {
          this.$().closest('.inp-txt').removeClass('ok');
        }
        if (this.get('isDataError')) {
          this.$().closest('.inp-txt').addClass('error');
        } else {
          this.$().closest('.inp-txt').removeClass('error');
        }
        if (this.get('disabled')) {
          this.$().closest('.inp-txt').addClass('disabled');
        } else {
          this.$().closest('.inp-txt').removeClass('disabled');
        }
        if (this.get('readonly')) {
          this.$().closest('.inp-txt').addClass('readonly');
        } else {
          this.$().closest('.inp-txt').removeClass('readonly');
        }
      }
    });

    return null;
  }),
  init() {
    this._super(...arguments);

    this._maskinput = new maskinput();
    this._maskinput.textCancel = this._onTextCancel.bind(this);
    this._maskinput.textCommit = this._onTextCommit.bind(this) ;
    this._maskinput.autoclear = this.autoclear;
    this._maskinput.mask = this.mask;
    this._maskinput.definitions = this.definitions;
    this._maskinput.maskPlaceholder = this.maskPlaceholder;
    this._maskinput.partialModify = this.partialModify;
  },
  didInsertElement() {
    this._super(...arguments);

    this.$().addClass('fr-input');
    this.$().wrap(`<div class="inp-txt"></div>`);
    this.$().after(`<button class='del'><span class='blind'>delete</span></button>`);
    this.$().closest('.inp-txt').css('width', this.$().prop('style')['width']);
    if (Ember.isArray(this.get('classNames'))) {
      this.get('classNames').forEach(function (className) {
        this.$().closest('.inp-txt').addClass(className);
        this.$().removeClass(className);
      }.bind(this));
    }
    this.$().closest('.inp-txt').children('button.del').on('mousedown', this._onTextClear.bind(this));
    this._maskinput._$element = this.$();
    this._maskinput.setMask(this.get('value'));
  },
  willDestroyElement() {
    this._super(...arguments);

    this.$().closest('.inp-txt').children('button.del').off('mousedown');
    this.$().closest('.inp-txt').children('span.search').off('mousedown');
    this._maskinput.destroy();
    this._maskinput = null;
  },
  _watchPropertyChanged: Ember.computed('autoclear', 'partialModify','mask', 'clearButtonVisibility', 'definitions', 'maskPlaceholder', function() {
    this._maskinput.autoclear = this.get('autoclear');
    this._maskinput.partialModify = this.get('partialModify');
    this._maskinput.mask = this.get('mask');
    this._maskinput.definitions = this.get('definitions');
    this._maskinput.maskPlaceholder = this.get('maskPlaceholder');
    this._maskinput.clear();
    this._maskinput.setMask();
    Ember.run.once(this, function(){
      this.set('value', '');
    }.bind(this));

    return this._maskinput.mask;
  }),
  _watchValueChanged: Ember.computed('value', function() {
    const _val = this.get('value'), _unmaskValue = this._maskinput.unMaskedValue();

    if ( _unmaskValue !== _val ) {
      this._maskinput.setMask(_val);
    }

    return _unmaskValue;
  }),
  text : Ember.computed('value', {
    get() {
      return this.$().val();
    },
  }),
  _onTextSearch(e) {
    e.preventDefault();
  },
  _onTextClear(e) {
    this.set('value', '');
    this._maskinput.clear();
    this._raiseEvents('textCleared', {'source' : this, 'originalEvent' : e} ) ;
  },
  _onInternalCommit() {
    this.set('value', this._maskinput.unMaskedValue()) ;
  },
  _onTextCancel() {
    if ( this.autoclear === false) {
      return ;
    }
    this.set('value', '');
  },
  _onTextCommit(){
    this._onInternalCommit();
    this._raiseEvents('textCommit', {'source' : this, 'value' : this.get('value'), 'text' : this.get('text') } ) ;
  },
  /*
  // == Component Properties ==============================
  type : 'text',
  classNames: ['inp-txt'],
  tagName : 'input',
  attributeBindings: ['_watchPropertyChanged:data-mask', '_watchValueChanged:data-value', 'name', 'type', 'required', 'title', 'placeholder', 'autofocus', 'onblur'],
  // == Private Properties ================================
  _maskinput : null,
  // == Public Properties =================================
  mask : '',
  clearButtonVisibility : false,
  value : '',
  definitions : '',
  textCleared : null,
  textCommit : null,
  autoclear: true,
  partialModify : false,
  maskPlaceholder: '_',
  // == Computed Properties =================================
  text : Ember.computed('value', {
    get()
    {
      return this.$().val();
    }
  }),
  _watchPropertyChanged: Ember.computed('autoclear', 'partialModify','mask', 'clearButtonVisibility', 'definitions', 'maskPlaceholder', function() {

    this._maskinput.autoclear = this.get('autoclear');
    this._maskinput.partialModify = this.get('partialModify');
    this._maskinput.mask = this.get('mask');
    this._maskinput.definitions = this.get('definitions');
    this._maskinput.maskPlaceholder = this.get('maskPlaceholder');
    this._maskinput.clear();
    this._maskinput.setMask();

    this.$().parent().removeClass('focus').removeClass('readonly').removeClass('disabled') ;

    this._onStateChanged();

    Ember.run.once(this, function(){
      this.set('value', '');
    }.bind(this));

    return this._maskinput.mask;
  }),
  _watchValueChanged: Ember.computed('value', function() {

    const _val = this.get('value') ;
    const _unmaskValue = this._maskinput.unMaskedValue() ;

    if ( _unmaskValue !== _val ) {
      this._maskinput.setMask(_val);
    }

    return _unmaskValue;
  }),
  // == Private Methods  ==================================
  _onTextSearch(e) {
    e.preventDefault();
  },
  _onTextClear(e) {
    this.set('value', '');
    this._maskinput.clear();
    this._raiseEvents('textCleared', {'source' : this, 'originalEvent' : e} ) ;
  },
  _onInternalCommit() {
    this.set('value', this._maskinput.unMaskedValue()) ;
  },
  _onTextCancel() {
    if ( this.autoclear === false) {
      return ;
    }

    this.set('value', '');
  },
  _onTextCommit(){
    this._onInternalCommit();
    this._raiseEvents('textCommit', {'source' : this, 'value' : this.get('value'), 'text' : this.get('text') } ) ;
  },
  init() {

    this._super(...arguments);

    this._maskinput = new maskinput();
    this._maskinput.textCancel = this._onTextCancel.bind(this);
    this._maskinput.textCommit = this._onTextCommit.bind(this) ;
    this._maskinput.autoclear = this.autoclear;
    this._maskinput.mask = this.mask;
    this._maskinput.definitions = this.definitions;
    this._maskinput.maskPlaceholder = this.maskPlaceholder;
    this._maskinput.partialModify = this.partialModify;
  },
  // == Life Cycle  =======================================
  didInsertElement() {
    this._super(...arguments);

    this._initializeTextBox() ;

    this._maskinput._$element = this.$();
    this._maskinput.setMask(this.get('value'));

    this._onStateChanged();
  },
  willDestroyElement() {
    this._super(...arguments);

    this._destroy();

    this._maskinput.destroy();
    this._maskinput = null;
  }
  */
});
