import Ember from 'ember';

const { computed } = Ember;

export default Ember.Component.extend({
  tagName: 'td',
  classNameBindings: ['_gridFootCellClass','_gridColumnAlignClass'],
  attributeBindings: ['cellIndex:data-foot-cell-index','tabindex'],
  layout: computed(function () {
    return Ember.HTMLBars.compile(`{{observedProperty}}<div style={{_htmlSafeFooterLineHeight}} tabindex="-1"><div>
      {{yield (hash ${this.get('column.footerTemplateName')}=(component 'c-grid-foot-cell-template'computedGroupValues=_computedGroupValues))}}</div></div>`);
  }).readOnly(),
  tabindex: -1,
  _gridFootCellClass: computed('_gridGuid', function () {
    return `${this.get('_gridGuid')}-foot-cell`;
  }).readOnly(),
  _gridColumnAlignClass: computed('column.align', function () {
    const _align = this.get('column.align');

    return Ember.isNone(_align) ? 'left' : _align;
  }).readOnly(),
  init() {
    this._super(...arguments);
    const _init = this.get('column.onFooterCellInit');

    if (Ember.typeOf(_init) === 'function') {
      _init.call(this, { cellComponent: this, column: this.get('column'), });
    }
    if (this.get('column.field')) {
      Ember.defineProperty(this, '_computedGroupValues', computed(`_items.@each.${this.get('column.field')}`, function () {
        const _items = this.get('_items');

        if (Ember.isArray(_items)) {
          return _items.mapBy(this.get('column.field'));
        }

        return Ember.A();
      }).readOnly());
    } else {
      Ember.defineProperty(this, '_computedGroupValues', Ember.A());
    }
  },
  didInsertElement() {
    this._super(...arguments);
    const _render = this.get('column.onFooterCellRender');

    if (Ember.typeOf(_render) === 'function') {
      _render.call(this, { cellComponent: this, column: this.get('column'), });
    }
    this.$().on('_getComponent', function (event, param) {
      param.component = this;
      event.stopPropagation();
      event.preventDefault();
    }.bind(this));
  },
  willDestroyElement() {
    this.$().off('_getComponent');
    this._super(...arguments);
  },
});