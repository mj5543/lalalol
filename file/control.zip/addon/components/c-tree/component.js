import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';
import ContextMenuMixin from '../../mixins/context-menu-mixin';

export default Control.extend(StatefulComponentMixin, ContextMenuMixin, {
  layout,
  tagName: 'div',
  classNames: ['c-tree'],
  attributeBindings: ['tabindex'],
  //public properties
  style: null,
  itemsSource: null,
  displayMemberPath: null,
  selectedValuePath: null,
  checkBoxPath: null,
  leafNodeMemberPath: null,
  childrenMemberPath: 'children',
  editable: false,
  draggable: false,
  showCheckBox: false,
  disableContextmenuNodeSelection: false,
  expandDepth: 1,
  selectedItem: null,
  contextMenuSource: null,
  tabindex: -1,
  disabled: false,
  //public methods
  focusNodeByItem(item) {
    this._getParentsItems(item).forEach(function (parentItem) {
      this.expandNodeByItem(parentItem);
    }.bind(this));
    let itemPath = this._getItemPath(item);
    
    if (!Ember.isEmpty(itemPath)) {
      Ember.run.next(this, function () {
        if (!this.get('isDestroying') && !this.get('isDestroyed')) {
          this.$(`li[data-item-path="${itemPath}"]`).find(':focusable').focus();
        }
        itemPath = null;
      });
    }
  },
  editNodeByItem(item) {
    this._getParentsItems(item).forEach(function (parentItem) {
      this.expandNodeByItem(parentItem);
    }.bind(this));
    let itemPath = this._getItemPath(item);

    if (!Ember.isEmpty(itemPath)) {
      Ember.run.next(this, function () {
        if (!this.get('isDestroying') && !this.get('isDestroyed')) {
          let component = this._getComponent(this.$(`li[data-item-path="${itemPath}"]`)),
          args = { source: this, originalSource: component, cancel: false };

          this._raiseEvents('onEditModeStart', args);
          if (!args.cancel) {
            component.changeEditMode();
          }
          this._releaseObjectProperty(args);
          component = null;
          args = null;
        }
        itemPath = null;
      });
    }
  },
  getParentItem(item) {
    const mapItem = this.get('_mapItems').findBy('item', item);

    if (!Ember.isNone(mapItem)) {
      return Ember.get(mapItem, 'parentItem');
    }

    return null;
  },
  findItemByValue(value) {
    return this.get('_items').findBy(this.get('selectedValuePath'), value);
  },
  collapseAll() {
    const _expandedItems = this.get('_expandedItems');

    if (!Ember.isEmpty(_expandedItems)) {
      _expandedItems.clear();
    }
  },
  expandAll() {
    const _expandedItems = this.get('_expandedItems'), _items = this.get('_items');

    _expandedItems.clear();
    _expandedItems.addObjects(_items);
  },
  expandAllToDepth(depth) {
    const _expandedItems = this.get('_expandedItems');

    _expandedItems.clear();
    _expandedItems.addObjects(this._getChilrenItemsWithDepth(this.get('itemsSource'), depth));
  },
  expandNodeByItem(item) {
    const _expandedItems = this.get('_expandedItems');

    if (!_expandedItems.includes(item)) {
      _expandedItems.addObject(item);
    }
  },
  collapseNodeByItem(item) {
    const _expandedItems = this.get('_expandedItems');

    if (_expandedItems.includes(item)) {
      _expandedItems.removeObject(item);
    }
  },
  updateTree() {
    this.set('_items', this._getChilrenItems(this.get('_itemsSource')));
    this.set('_mapItems', this._getChilrenMapItems(null, this.get('_itemsSource')));
    this.$(`.${this.get('_treeItemClass')}`).trigger('_treeitemupdate');
  },
  //public events
  onLoaded: null,
  onUnload: null,
  onDoubleClick: null,
  onChecked: null,
  onUnchecked: null,
  onEditModeStart: null,
  onEditModeEnded: null,
  onCollapse: null,
  onExpand: null,
  onDragStart: null,
  onDragEnd: null,
  onDragEnter: null,
  onDrop: null,
  onContextMenuOpen: null,
  onSelectionChanged: null,
  onItemsSourceChanged: null,
  //public readonly Properties
  items: Ember.computed.readOnly('_items'),

  _treeGuid: Ember.computed.readOnly('componentGuid'),
  _treeItemClass: Ember.computed('_treeGuid', function () {
    return `${this.get('_treeGuid')}-tree-item`;
  }).readOnly(),
  _itemsSource: Ember.computed('itemsSource.[]', function () {
    let itemsSource = this.get('itemsSource');

    if (!Ember.isArray(itemsSource)) {
      itemsSource = Ember.A();
    }
    Ember.run.once(this, '_itemsSourceChange');

    return itemsSource;
  }).readOnly(),
  _items: Ember.computed('_itemsSource.[]', {
    get (key) {
      return this._getChilrenItems(this.get('_itemsSource'));
    },
    set (key, value) {
      return value;
    },
  }),
  _mapItems: Ember.computed('_itemsSource.[]', {
    get (key) {
      return this._getChilrenMapItems(null, this.get('_itemsSource'));
    },
    set (key, value) {
      return value;
    }
  }),
  _observedProperty1: Ember.computed('selectedItem', function () {
    const _items = this.get('_items'), _selectedItem = this.get('_selectedItem'), selectedItem = this.get('selectedItem');

    if ((_selectedItem && selectedItem && _selectedItem !== selectedItem) || (!_selectedItem && selectedItem)) {
      this._selectItem(_items.indexOf(selectedItem));
    } else if (_selectedItem && !selectedItem) {
      this._deselectItem(_items.indexOf(_selectedItem));
    }
  }).readOnly(),
  onPropertyInit() {
    this._super(...arguments);
    this.setStateProperties([ '_expandedItems' ]);
    if (!this.hasState()) {
      const _expandedItems = Ember.A(), expandDepth = this.get('expandDepth');

      if (!Ember.isNone(expandDepth) && !isNaN(expandDepth)) {
        _expandedItems.addObjects(this._getChilrenItemsWithDepth(this.get('itemsSource'), this.get('expandDepth')));
      }
      this.set('_expandedItems', _expandedItems);
    }
  },
  didInsertElement() {
    this._super(...arguments);
    this.$('.scrollbar-macosx:not(.scroll-content)').scrollbar();
  },
  willDestroyElement() {
    this.$('.scrollbar-macosx').scrollbar('destroy');
    this._super(...arguments);
  },
  keyDown(event) {
    if (this.get('editable') && event.keyCode === 13) {
      const $target = this.$(event.target).closest(`.${this.get('_treeItemClass')}`);

      if ($target.length > 0) {
        let component = this._getComponent($target), args = { 'source': this, 'originalSource': component, 'cancel': false };

        this._raiseEvents('onEditModeStart', args);
        if (!args.cancel) {
          component.changeEditMode();
        }
        this._releaseObjectProperty(args);
        component = null;
        args = null;
      }
    }
  },
  _itemsSourceChange() {
    const _items = this.get('_items'), _expandedItems = this.get('_expandedItems'), _selectedItem = this.get('_selectedItem'), expandedItemsGarbage = Ember.A();

    if (!Ember.isNone(_selectedItem) && !_items.includes(_selectedItem)) {
      this.set('_selectedItem', null);
      Ember.run.once(this, '_selectionChange');
    }
    if (Ember.isEmpty(_items) && !Ember.isEmpty(_expandedItems)) {
      _expandedItems.clear();
    } else {
      _expandedItems.forEach(function (item) {
        if (!_items.includes(item)) {
          expandedItemsGarbage.addObject(item);
        }
      });
      if (!Ember.isEmpty(expandedItemsGarbage)) {
        _expandedItems.removeObjects(expandedItemsGarbage);
      }
    }
    this._raiseEvents('onItemsSourceChanged', {
      source: this,
      itemsSource: this.get('itemsSource'),
    });
  },
  _getChilrenMapItems(parentItem, items) {
    const childrenItems = Ember.A(), childrenMemberPath = this.get('childrenMemberPath');

    if (Ember.isArray(items)) {
      items.forEach(function (child) {
        childrenItems.addObject({ parentItem: parentItem, item: child });
        childrenItems.addObjects(this._getChilrenMapItems(child, Ember.get(child, childrenMemberPath)));
      }.bind(this));
    }

    return childrenItems;
  },
  _getParentsItems(item) {
    const parentsItems = Ember.A(), mapItem = this.get('_mapItems').findBy('item', item);

    if (!Ember.isNone(mapItem)) {
      const parentItem = Ember.get(mapItem, 'parentItem');

      parentsItems.addObjects(this._getParentsItems(parentItem));
      parentsItems.addObject(parentItem);
    }

    return parentsItems;
  },
  _getChilrenItems(childrenItems) {
    const items = Ember.A();

    if (Ember.isArray(childrenItems)) {
      childrenItems.forEach(function (child) {
        items.addObjects(this._getChilrenItems(Ember.get(child, this.get('childrenMemberPath'))));
      }.bind(this));
      items.addObjects(childrenItems);
    }

    return items;
  },
  _getChilrenItemsWithDepth(childrenItems, depth) {
    const items = Ember.A();

    if (0 < depth && Ember.isArray(childrenItems)) {
      childrenItems.forEach(function (child) {
        items.addObjects(this._getChilrenItemsWithDepth(Ember.get(child, this.get('childrenMemberPath')), depth - 1));
      }.bind(this));
      items.addObjects(childrenItems);
    }

    return items;
  },
  _internalContextMenuOpen(e) {
    const $target = this.$(e.originalEvent.target).closest(`.${this.get('_treeItemClass')}`);

    if ($target.length > 0) {
      let component = this._getComponent($target), parentComponent = component.getParent(), item = Ember.get(component, 'item');

      e.originalSource = component;
      e.parent = parentComponent;
      e.item = item;
      if (!this.get('disableContextmenuNodeSelection')) {
        this.set('_selectedItem', item);
        Ember.run.once(this, '_selectionChange');
      }
      component = null;
      parentComponent = null;
      item = null;
    }
  },
  _getItemPath(item) {
    const itemsSource = this.get('itemsSource');
    let path = '';

    if (!Ember.isNone(item) && Ember.isArray(itemsSource)) {
      for (let i = 0; i < itemsSource.length; i++) {
        path = this._getItemSubPath(item, itemsSource[i], i);
        if (!Ember.isEmpty(path)) {
          path = this.get('_treeGuid') + '-' + path;
          break;
        }
      }
    }

    return path;
  },
  _getItemSubPath(item, sourceItem, index) {
    let subPath = '';

    if (item === sourceItem) {
      subPath = index.toString();
    } else {
      const childrenItems = Ember.get(sourceItem, this.get('childrenMemberPath'));

      if (Ember.isArray(childrenItems)) {
        for (let i = 0; i < childrenItems.length; i++) {
          subPath = this._getItemSubPath(item, childrenItems[i], i);
          if (!Ember.isEmpty(subPath)) {
            subPath = index.toString() + '-' + subPath;
            break;
          }
        }
      }
    }

    return subPath;
  },
  _selectItem(index) {
    const _items = this.get('_items'), _selectedItem = this.get('_selectedItem'), item = _items.objectAt(index);

    if (!Ember.isNone(item) && _selectedItem !== item) {
      this.set('_selectedItem', item);
      Ember.run.once(this, '_selectionChange');
    }
  },
  _deselectItem(index) {
    const _items = this.get('_items'), _selectedItem = this.get('_selectedItem'), item = _items.objectAt(index);

    if (!Ember.isNone(item) && _selectedItem === item) {
      this.set('_selectedItem', null);
      Ember.run.once(this, '_selectionChange');
    }
  },
  _selectionChange() {
    const _selectedItem = this.get('_selectedItem'), selectedItem = this.get('selectedItem');
    let parentItem = null;

    if ((selectedItem && _selectedItem && selectedItem !== _selectedItem) || (!selectedItem && _selectedItem)) {
      this.set('selectedItem', _selectedItem);
    } else if (selectedItem && !_selectedItem) {
      this.set('selectedItem', null);
    }
    const mapItem = this.get('_mapItems').findBy('item', _selectedItem);

    if (!Ember.isNone(mapItem)) {
      parentItem = Ember.get(mapItem, 'parentItem');
    }
    this._raiseEvents('onSelectionChanged', {
      source: this,
      selectedItem: this.get('selectedItem'),
      parentItem: parentItem
    });
  },
});