
import Ember from 'ember';
import layout from './template';
import Control from '../fr-control/component';

// fr-fileupload
export default Control.extend({
  layout,
  tagName: 'div',
  classNames: ['fr-fileupload', 'fileadd-area'],
  //== Public Properties ==============================
  accept : null,
  readonly : true,
  files : null,
  multiple : false,
  onchange : null,
  onclear : null,
  text : null,
  /*
  getClassNames: Ember.computed('disabled', 'readonly', 'multiple', function() {

    this._propertyChanged();

    if ( this.get('disabled') === true) {
      return 'disabled' ;
    }

    return '' ;

  }).readOnly(),
  _propertyChanged(){
    if ( this.get('readonly') === true) {
      this.$('input[type=text]').prop('readonly', true);
    } else {
      this.$('input[type=text]').prop('readonly', false);
    }

    if ( this.get('multiple') === true) {
      this.$('input[type=file]').prop('multiple', true);
    } else {
      this.$('input[type=file]').prop('multiple', false);
    }
  },
  */
  didInsertElement() {
    this._super(...arguments);

    //this._propertyChanged();
  },
  // == Action Handler ================================
  actions: {
    onChangeAction(e){
      const len = e.target.files.length;

      if ( len < 1 ) {
        return ;
      }

      const title = len > 1 ? len + ' files selected' : e.target.files[0].name;

      this.set('text', title) ;
      this.set('files', e.target.files) ;
      this.$().addClass('focus');
      this._raiseEvents('onchange', {'source' : this, 'originalEvent' : e, 'files' : e.target.files} );
    },
    onRemoveClick(){
      this.set('text', '') ;
      this.set('files', null) ;
      this.$().removeClass('focus');
      this._raiseEvents('onclear', {'source' : this } );
    }
  }
});
