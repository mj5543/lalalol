

import Ember from 'ember';
import layout from './template';
import GlobalServiceContainerMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';
//import SVGMixin from '../../mixins/rulebase-rule-control-svg-new-mixin';
import SVGMixin from '../../mixins/svg-mixin';

const { computed } = Ember;

export default Ember.Component.extend(SVGMixin, GlobalServiceContainerMixin, StatefulComponentMixin, {
  tagName: 'div',
  classNames: ['fr-family-tree'],
  attributeBindings: ['_style:style', 'watchSource:data-value', '_changePushObject', '_reRenderAll'],
  layout,
  selectedItem: null,
  overItem: null,
  linesDictionary: null,
  linesCollection: null,
  isHeader: null,
  dragActive: null,
  draglineActive: null,
  canvas:null,
  svg:null,
  nodeMasters:null,
  contextMenu:null,
  previousNodeDATA:null,
  lineData:[{ x: 0, y: 0 }, { x: 0, y: 0 }],

  _itemsSource: computed.alias('itemsSource').readOnly(),

  _style: computed('width', 'height', function () {
    const width = this.get('width'), height = this.get('height');
    const html = `width: ${width}px; height: ${height}px;`;

    return Ember.String.htmlSafe(html);
  }).readOnly(),

  watchSource: computed('_itemsSource.[]', function () {
    this.initSource();
    return null;
  }).readOnly(),

  initSource() {
    const _itemsSource = this.get('_itemsSource');

    console.log(' _itemsSource',  _itemsSource);
    if (!Ember.isEmpty(_itemsSource)) {
      this.clearSVG();
      this.setSVG('svgCanvas');
      this.initObject(_itemsSource);
    }
  },

  didInsertElement() {
    this._super(...arguments);
  },

  didRender() {
    this._super(...arguments);
  },

  willDestroyElement() {
    this._super(...arguments);
  },

  _raiseEvents(eventName, arg) {
    const events = this.get(eventName);

    if (events) {
      events(arg);
    }
  },

  setSVG(id) {
    const zoom = d3.zoom()
      .scaleExtent([0.3, 50])
      .on('zoom', () => {
        this.canvas.attr('transform', `translate(${d3.event.transform.x}, ${d3.event.transform.y})scale(${d3.event.transform.k})`);
      });

    this.set('svg', d3.select(`#${id}`));
    this.svg.call(zoom).on("dblclick.zoom", null);
    this.set('canvas', this.svg.append('g'));

    this.canvas.nodeCanvas = this.canvas.append('g');
    this.canvas.lineCanvas = this.canvas.append('g');
    this.canvas.master = this.canvas.append('g');
    this.canvas.context = this.canvas.append('g');

    const source =
    {
      "geometryModel": {
        "width": 200,
        "height": 44,
        "x": 30,
        "y": 30
      },
      "headerModel": {
        "content": "Main Context",
        "background": "black",
        "smallIcons": []
      },
      "mainContentModel": {
        "isVisible": true,
        "content": ""
      }
    };

 

  this.makeMaster(this.canvas.context, source, this.contextMenu);
  },
  
  mainContextSelectedItem(target, item) {
    this.masterNodeHide(d3.select(target.node().parentNode));
    this._raiseEvents('contextMenuClicked', {commandName:item.label, node:this.selectedItem.source});
  },

  clearSVG() {
    d3.select('#svgCanvas').on('zoom', null).selectAll('*').on('click', null).remove();
  },

  createGroupWithEvent(target, id = null, position = { x: 0, y: 0 }, event = null, argument = null, isOver = false, isDisabled = false) {

    const group = target.append('g')
      .attr('transform', `translate(${position.x}, ${position.y})`)
      .on('click', () => { 
        if(!isDisabled) {
          event(target, argument) 
        }
      });

      if (isOver) {
        group.on('mouseleave', () => {
          group.rect.attr('fill', '#434343');
          group.text.attr('fill', '#EAEAEA');
        })
          .on('mouseover', () => {
            group.rect.attr('fill', '#8C8C8C');
            group.text.attr('fill', 'black');
          })
      }

    if (id != null) {
      group.attr('id', id);
    }
    return group;
  },

  createGroupSelect(target, id = null, position = { x: 0, y: 0 }, isEvent = true) {

    const group = target.append('g')
      .attr('transform', `translate(${position.x}, ${position.y})`);
      if (isEvent) {
        group.on('mouseleave', () => {
        if(this.draglineActive){
          if(this.selectedItem != group){
            group.layout.attr('stroke', 'black');
            this.overItem = null;
          }
        }
      })
      .on('mouseover', () => {
        if(this.draglineActive){
          if(this.selectedItem != group){
            this.overItem = group;
            group.layout.attr('stroke', '#0054FF');
            this.canvas.nodeCanvas.node().appendChild(group.node());
          }
        }
      })
      .on("contextmenu", () => { 
        this.clickContext(group)
        d3.event.preventDefault();
        d3.event.stopPropagation();
      })
      .on('click', () => { this.clickGroup(group) })
      .on('dblclick',() => this.dbClickGroup(group));
    }
    if (id != null) {
      group.attr('id', id);
    }

    return group;
  },


  createPinsSelect(target, data) {

    const group = target.append('g')
      .attr('transform', `translate(${0}, ${0})`)
      .style('cursor', 'pointer')
    
    if(!Ember.isEmpty(data)){
      group.on('mouseleave', () => {
        if(!data.HasRelation){
          group.circle.attr('stroke-width', 0);
        }
      })
      .on('mouseover', () => {
        if(!data.HasRelation){
          group.circle.attr('stroke-width', 3);
        }
      })
      .on('click', () => {
        alert('pin click')
        d3.event.stopPropagation();
      });
    }

    return group;
  },


  createGroupOver(target, id = null, position = { x: 0, y: 0 }) {

    const group = target.append('g')
      .attr('transform', `translate(${position.x}, ${position.y})`)
      .style('cursor', 'pointer')
      .on('mouseleave', () => {
        if (!this.dragActive) {
          this.isHeader = false;
        }
      })
      .on('mouseover', () => { this.isHeader = true });

    if (id != null) {
      group.attr('id', id);
    }

    return group;
  },

  clickContext(target){
    this.setSelected(target);
    this.showMaster(target, this.canvas.context.item, false);
  },

  dbClickGroup(target){
    
    this._raiseEvents('nodeDoubleClicked', {node:target.source});
  },

  clickGroup(target) {
    this.setSelected(target);

    if(!Ember.isEmpty(target.source)){
      this._raiseEvents('nodeClicked', {node:target.source});
    }
  },

  setSelected(target) {
    if (this.selectedItem != null) {
      this.selectedItem.layout.attr('stroke', 'black');
    }
    this.selectedItem = target;
    this.canvas.nodeCanvas.node().appendChild(target.node());
    target.layout.attr('stroke', 'red');
  },

  initObject(nodeData) {
    this.linesDictionary = [];
    this.linesCollection = [];

    nodeData.forEach((d, index) => {
      this.makeNode(this.canvas.nodeCanvas, index, d);
    });

    const source =
    {
      "geometryModel": {
        "width": 360,
        "height": 40,
        "x": 30,
        "y": 30
      },
      "headerModel": {
        "content": "Master Nodes",
        "background": "black",
        "smallIcons": []
      },
      "mainContentModel": {
        "isVisible": true,
        "content": ""
      }
    };

    this.makeMaster(this.canvas.master, source, this.nodeMasters);
    this.connectLines();
  },

  connectLines() {
    this.linesCollection.forEach(d => {
      this.makeBezierLine([d.position, this.getPosition(d.endKey)]);
    });

    this.canvas.node().appendChild(this.canvas.nodeCanvas.node());
  },


  getPosition(index) {
    return this.linesDictionary.find(d => d.key === index).position;
  },

  makeBezierLine(lineData) {
    this.canvas.lineCanvas.line = this.bezierCurve(this.canvas.lineCanvas, lineData, '#EAEAEA');
  },

  makeMaster(target, source, nodeData) {
    const group = this.createGroupSelect(target, source.headerModel.content, { x: source.geometryModel.x, y: source.geometryModel.y }, false);
    group.header = this.makeContextHeader(group, source);
    group.main = this.makeContextMain(group, source, nodeData);
    group.layout = this.createRect(group, { x: 0, y: 0 }, { width: source.geometryModel.width, height: source.geometryModel.height }, 5, 'none', 5, 'black');
    this.popdrag(group, source, 80, true);
    target.item = group;
    target.item.style('display', 'none');
  },

  makeContextMain(target, source, nodeMasters) {
    if (source.mainContentModel.isVisible) {
      target.main = this.createGroup(target, { x: 1, y: 40 });
      target.main.rect = this.createRect(target.main, { x: 0, y: -1 }, { width: source.geometryModel.width, height: source.geometryModel.height - 40 }, 0, '#D5D5D5', 0, 'black', 0.8);
      target.main.items = [];
      const itemSize = { width: source.geometryModel.width - 8, height: 40 };

      if(nodeMasters.Categories != null){
        nodeMasters.Categories.forEach((data, index) => {
          const ceil = Math.ceil(data.nodes.length / 3);
          itemSize.height = (ceil * 65) + 40;
          source.geometryModel.height += itemSize.height;
          this.makeCategoryItem(target.main, data, { x: 3, y: (itemSize.height * index) }, itemSize)
        })
      }else{
        nodeMasters.nodes.forEach((data, index) => {
          source.geometryModel.height += itemSize.height;
          this.makeContextItem(target.main, data, { x: 3, y: (itemSize.height * index) }, itemSize)
        })
      }
      return target.main;
    }
  },


  makeContextItem(target, content, position, size) {
    const item = this.createGroupWithEvent(target, content.label, { x: position.x, y: position.y }, this.mainContextSelectedItem.bind(this), content, !content.disabled).style('cursor', 'pointer');
    item.rect = this.createRect(item, { x: 0, y: 0 }, { width: size.width, height: size.height }, 0, '#434343', 3, '#434343', 1);
    item.text = this.createText(item, { x: 0, y: size.height / 2 }, content.label, 18, !content.disabled ? 'white' : 'gray');
    this.setTextCenter(item.text, item, 0, 25);
    target.items.push(item);
  },

  makeCategoryItem(target, content, position, size) {
    const item = this.createGroup(target, { x: position.x, y: position.y });
    item.nodes = [];
    item.rect = this.createRect(item, { x: 0, y: 0 }, { width: size.width, height: size.height }, 0, '#5D5D5D', 3, '#434343', 1);
    item.text = this.createText(item, { x: 0, y: size.height / 2 }, content.name, 18, 'black');
    this.setTextCenter(item.text, item, 0, 25);
      content.nodes.forEach((element, index) => {
        let quotient = index % 3;
        let floor = Math.floor(index / 3);
      this.makeNodeItem(item, element, { x: (110 * quotient) + 18, y: (60 * floor) + 40 });
    });

    target.items.push(item);
  },

  // makeMasterMain(target, source) {
  //   if (source.mainContentModel.isVisible) {

  //     target.main = this.createGroup(target, { x: 1, y: 40 });
  //     target.main.rect = this.createRect(target.main, { x: 0, y: -1 }, { width: source.geometryModel.width, height: source.geometryModel.height - 40 }, 0, '#D5D5D5', 0, 'black', 0.8);
  //     target.main.items = [];

  //     this.nodeMasters.forEach((data, index) => {
  //       let quotient = index % 3;
  //       let floor = Math.floor(index / 3);
  //       this.makeNodeItem(target.main, data, { x: (90 * quotient) + 18, y: (90 * floor) + 10 })
  //     })

  //     return target.main;
  //   }
  // },

  // makeMasterHeader(target, source) {

  //   target.header = this.createGroupOver(target);
  //   target.header.rect = this.roundedRectPath(target.header, 2.3, 2, source.geometryModel.width, 37, 3, 'top', '#1b1b1b');

  //   if (source.mainContentModel.isVisible) {
  //     target.header.icon = this.setIconSportMode(target.header, { x: 10, y: 10 }, 0.5);
  //   }
  //   else {
  //     target.header.icon = this.setIconExpression(target.header, { x: 10, y: 8 }, 0.5);
  //   }

  //   this.makeClose(target);
  //   target.header.title = this.createText(target.header, { x: 0, y: 27 }, source.headerModel.content, 18, '#EAEAEA');
  //   this.setTextCenter(target.header.title, target.header, 5, 27);
  //   return target.header;
  // },

  makeContextHeader(target, source) {
    target.header = this.createGroupOver(target);
    target.header.rect = this.roundedRectPath(target.header, 2.3, 2, source.geometryModel.width, 37, 3, 'top', '#1b1b1b');

    if (source.mainContentModel.isVisible) {
      target.header.icon = this.setIconSportMode(target.header, { x: 10, y: 10 }, 0.5);
    }
    else {
      target.header.icon = this.setIconExpression(target.header, { x: 10, y: 8 }, 0.5);
    }

    this.makeClose(target, source.geometryModel.width - 35, this.masterNodeHide.bind(this));
    target.header.title = this.createText(target.header, { x: 0, y: 27 }, source.headerModel.content, 18, '#EAEAEA');
    this.setTextCenter(target.header.title, target.header, 0, 27);
    return target.header;
  },

  makeNodeItem(target, content, position) {
    const item = this.createGroupWithEvent(target, content.label, { x: position.x, y: position.y }, this.masterNodeSelectedItem.bind(this),
      {
        previousNode: null,
        previousRelation: null,
        masterItem: content
      }
      , !content.disabled, content.disabled).style('cursor', 'pointer');
    item.rect = this.createRect(item, { x: 0, y: 0 }, { width: 100, height: 50 }, 10, '#434343', 3, '#434343', 0.9);
    item.text = this.createText(item, { x: 0, y: 20 }, content.label, 15, !content.disabled ? 'white' : 'gray');
    item.icon = this.setIconSportMode(item, { x: 40, y: 8 }, 0.4, content.disabled);

    this.setTextCenter(item.text, item, 0, 40);
    target.nodes.push(item);
  },


  showMaster(base, target, isD3event= true) {
    const string = base.attr('transform');
    const translate = string.substring(string.indexOf("(") + 1, string.indexOf(")")).split(",");
    this.masterNodesShow({ x: Number(translate[0]) + (isD3event ? d3.event.x : 50), y: Number(translate[1]) + (isD3event ? d3.event.y : 50) }, target);
  },

  masterNodesShow(positon, target) {
    target.style('display', 'inline-block');
    target.attr('transform', `translate(${positon.x}, ${positon.y})`);
    this.canvas.nodeCanvas.node().appendChild(target.node());
  },


  masterNodeHide(target) {
    target.style('display', 'none');
  },

  masterNodeSelectedItem(item){

    item.previousNode = this.previousNodeDATA.node;
    item.previousRelation = this.previousNodeDATA.relation;

    this._raiseEvents('newNodeSelected', item);
    this.canvas.master.item.style('display', 'none');
  },

  makeClose(target, x, event) {
    target.header.close = this.createGroupWithEvent(target, "close", { x: x, y: 5 }, event);
    target.header.close.rect = this.createCircle(target.header.close, 12, { x: 15, y: 15 }, 0, 'transparent');
    target.header.close.icon = this.setIconClose(target.header.close, { x: 0, y: 0 }, 1.5);
  },

  makeNode(target, id, source) {
    const group = this.createGroupSelect(target, id, { x: source.geometryModel.x, y: source.geometryModel.y });
    group.header = this.makeHeader(group, source);
    group.pins = this.makePins(group, source);
    group.main = this.makeMain(group, source);
    group.submain = this.makeSubmain(group, source);
    group.memo = this.makeMemo(group, source);
    group.layout = this.createRect(group, { x: 0, y: 0 }, { width: source.geometryModel.width, height: source.geometryModel.height }, 5, 'none', 5);

    group.node().appendChild(group.header.node());
    this.drag(group, source, 80, true);
  },


  drag(group, source, center, direction) {
    group.call(d3.drag()
      .on("start", () => {
        if (this.isHeader) {
          this.dragActive = true;
        }
      })
      .on("drag", () => {
        if (this.isHeader) {
          const x = d3.event.x - center, y = d3.event.y - 20;
          group.attr('transform', `translate(${x}, ${y})`);
          this.canvas.lineCanvas.selectAll("*").remove();;
          const myinfo = this.linesDictionary.find(d => d.key === source.nodeKey);
          myinfo.position = { x: x + 20, y: y + 50 };
          group.pins.outtextinfo.forEach(d => {
            d.position = { x: x + d.margin.x, y: y + d.margin.y };
          });
          this.connectLines();
        }
      })
      .on("end", () => {
        if (this.isHeader) {
          this.dragActive = false;
        }
      }));
  },

  popdrag(group, source, center, direction) {
    group.call(d3.drag()
      .on("start", () => {
        if (this.isHeader) {
          this.dragActive = true;
        }
      })
      .on("drag", () => {
        if (this.isHeader) {
          const x = d3.event.x - center, y = d3.event.y - 20;
          group.attr('transform', `translate(${x}, ${y})`);
        }
      })
      .on("end", () => {
        if (this.isHeader) {
          this.dragActive = false;
        }
      }));
  },

  pinDrag(base, group, target, data) {
    group.call(d3.drag()
      .on("start", () => {
        this.draglineActive = true;
        group.circle.attr('fill', '#0054FF');

        this.setSelected(base);

        this.previousNodeDATA = {
          node: base.source,
          relation: data
        };

        this._raiseEvents('nextRelationDragStarting', this.previousNodeDATA);
        
      })
      .on("drag", () => {
        const x = d3.event.x, y = d3.event.y, position = [{ x: 0, y: 0 }, { x: x - 19, y: y }];
        if (target.line != null) {
          target.line.remove();
        }

        target.line = this.bezierCurve(target, position, '#0054FF', 4, 2);
        
      })
      .on("end", () => {
        this.draglineActive = false;

        if (this.overItem != null) {
          if(this.overItem.layout.attr('stroke') === '#0054FF'){

          const item = {
            previousNode:this.previousNodeDATA.node,
            previousRelation:this.previousNodeDATA.relation,
            selectedNode:this.overItem.source
          }

           this._raiseEvents('existingNodeSelected', item)
          }else{
            //this.showMaster(base);
            this.showMaster(base, this.canvas.master.item);
          }
          this.overItem.layout.attr('stroke', 'black');
        }else{
          this.showMaster(base, this.canvas.master.item);
        }
       
        group.circle.attr('fill', '#EAEAEA');

        if (target.line != null) {
          target.line.remove();
        }
      }
      ));
  },

  setMultiText(text, width){
    const words = text.text().split(/\s+/).reverse();
    let word, line = [], lineNumber = 0,lineHeight = 1.1;
    let tspan = text.text(null).append("tspan");
    while (word = words.pop()) {
        line.push(word);
        tspan.text(line.join(" "));
        var textWidth = tspan.node().getComputedTextLength();
        if (tspan.node().getComputedTextLength() > width) {
            line.pop();
            tspan.text(line.join(" "));
            line = [word];
            lineNumber++;
            tspan = text.append("tspan").attr("x",0).attr("y", 0).attr("dy","1.5em").text(word);
        }
    }
},



  cutTextLength(target, text, width) {
    if (width - 15 < target.node().getBoundingClientRect().width) {
      const eachWidth = target.node().getBoundingClientRect().width / text.length,
        realCount = (width - 20) / eachWidth;
      target.text(`${text.substring(0, realCount)}..`);
    }
  },

  makeSubmain(target, source) {
    if (source.subContentModel.isVisible) {
      target.sub = this.createGroup(target, { x: 1, y: source.geometryModel.height });
      target.sub.rect = this.createRect(target.sub, { x: 0, y: -2 }, { width: source.geometryModel.width, height: 30 }, 0, '#434343', 0);
      target.sub.title = this.createText(target.sub, { x: 0, y: 20 }, source.subContentModel.content, 15, 'white');
      this.cutTextLength(target.sub.title, source.subContentModel.content, 158);
      this.setTextCenter(target.sub.title, target.sub, 0, 20);
      source.geometryModel.height += 30;
      return target.sub;
    }
  },
  
  makeMemo(target, source) {
    if (source.memoModel.content != null) {
      target.menu = this.createGroup(target, { x: 1, y: source.geometryModel.height + 10 });
      target.menu.rect = this.createRect(target.menu, { x: 0, y: -1 }, { width: source.geometryModel.width, height: 60 }, 8, '#434343', 0, 'black', 0.6);
      target.menu.title = this.createText(target.menu, { x: 10, y: 20 }, source.memoModel.content, 15, '#EAEAEA');
      //this.cutTextLength(target.menu.title, source.memoModel.content, 140);
      this.setMultiText(target.menu.title, source.geometryModel.width);
      return target.menu;
    }
  },


  makeMain(target, source) {
    if (source.mainContentModel.isVisible) {
      target.main = this.createGroup(target, { x: 1, y: source.geometryModel.height });
      target.main.rect = this.createRect(target.main, { x: 0, y: -1 }, { width: source.geometryModel.width, height: 30 }, 0, '#434343', 0);
      target.main.title = this.createText(target.main, { x: 0, y: 20 }, source.mainContentModel.content, 15, 'white');
      this.setTextCenter(target.main.title, target.main, 0, 20);
      source.geometryModel.height += 30;
      return target.main;
    }
  },

  makePins(target, source) {
    target.pins = this.createGroup(target, { x: 1, y: source.geometryModel.height });
    target.pins.rect = this.createRect(target.pins, { x: 1, y: -1 }, { width: source.geometryModel.width, height: (source.nexts.length * 22) }, 0, '#434343', 0, 'black', 0.6);
    this.linesDictionary.push({ key: source.nodeKey, position: { x: this.getFromSVGPositionX(target.pins) + 10, y: this.getFromSVGPositionY(target.pins) + 5 } });
    this.setPinPosition(target, source);
    source.geometryModel.height += (source.nexts.length * 22);
    return target.pins;
  },

  setPinPosition(target, source) {
    const pinInputPin = this.createPinsSelect(target.pins);
    pinInputPin.circle = this.createCircle(pinInputPin, 5, { x: 18, y: 10 }, 0, '#EAEAEA');

    target.source = source;

    target.pins.outgroup = this.createGroup(target.pins, { x: source.geometryModel.width - 40, y: 10 });
    target.pins.outtextinfo = [];
    source.nexts.forEach((d, index) => {
      const pinOutputPins = this.createPinsSelect(target.pins.outgroup);
      pinOutputPins.circle = this.createCircle(pinOutputPins, 5, { x: 20, y: (20 * index) }, 0, '#EAEAEA');
      pinOutputPins.text = this.createText(target.pins.outgroup, { x: 9, y: (20 * index + 4) }, d.Label, 11, '#EAEAEA', true);
      pinOutputPins.line = this.createGroup(target.pins.outgroup, { x: 20, y: (20 * index) });
      this.pinDrag(target, pinOutputPins, pinOutputPins.line);
      if (d.nodeKey != null) {
        const info = {
          lable: d.Label,
          startkey: source.nodeKey,
          position: { x: this.getFromSVGPositionX(target.pins) + source.geometryModel.width - 20, y: this.getFromSVGPositionY(target.pins) + 5 + (20 * index) },
          endKey: d.nodeKey,
          margin: { x: source.geometryModel.width - 20, y: 48 + (20 * index) }
        }

        this.linesCollection.push(info);
        target.pins.outtextinfo.push(info);
      }
    });
  },

  getFromSVGPositionX(target) {
    return target.node().getBoundingClientRect().x - this.svg.node().getBoundingClientRect().x;
  },

  getFromSVGPositionY(target) {
    return target.node().getBoundingClientRect().y - this.svg.node().getBoundingClientRect().y;
  },

  makeHeader(target, source) {
    target.header = this.createGroupOver(target);
    target.header.rect = this.roundedRectPath(target.header, 2.3, 2, source.geometryModel.width - 4.8, 37, 3, 'top', '#1b1b1b');

    if (source.mainContentModel.isVisible) {
      target.header.icon = this.setIconSportMode(target.header, { x: 10, y: 10 }, 0.5);
    }
    else {
      target.header.icon = this.setIconExpression(target.header, { x: 10, y: 8 }, 0.5);
    }

    target.header.call = this.createGroupWithEvent(target.header, "rulecall", { x:  source.geometryModel.width - 35, y: 7 }, this.rulecall.bind(this)).style('cursor', 'pointer');
    target.header.call.rect = this.createCircle(target.header.call, 16, { x: 13, y: 12 }, 0, 'transparent');
    target.header.call.icon = this.setIconShare(target.header.call, { x: 0, y: 0 }, 0.4);

    target.header.title = this.createText(target.header, { x: 0, y: 27 }, source.headerModel.content, 18, '#EAEAEA');
    this.setTextCenter(target.header.title, target.header, 0, 27);
    source.geometryModel.height = 40;
    return target.header;
  },

  rulecall() {
    alert('rulecall')
  },

  setTextCenter(target, base, x, y) {
    const textWidth = target.node().getBoundingClientRect().width / 2,
      baseWidth = base.node().getBoundingClientRect().width / 2,
      myWidth = baseWidth - textWidth;
    target.attr('transform', `translate(${myWidth + x}, ${y})`);
  },

  actions: {

  },
});



