import Ember from 'ember';
import layout from './template';
import Control from '../fr-control/component';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

export default Control.extend(StatefulComponentMixin, {
  classNameBindings : ['propertyChangedCallback'],
  classNames : ['fr-panel'],
  tagName : 'div',
  layout,
  visibility : true,
  hasVisibility : true,
  propertyChangedCallback: Ember.computed('visibility', function() {

    if ( this.get('visibility') === true && this.get('hasVisibility') === false) {
      this.set('hasVisibility', true);
      Ember.run.schedule('afterRender', this, function () {
        this.$('.scrollbar-macosx:not(.scroll-content)').scrollbar();
      });
    }

    if ( this.get('visibility') === false) {
      return 'hide'
    }

    return '' ;

  }).readOnly(),
  init() {
    this._super(...arguments);

    if ( this.get('visibility') === false) {
      this.set('hasVisibility', false);
    }
  },
  didInsertElement() {
    this._super(...arguments);
  },
  willDestroyElement(){
    this._super(...arguments);
    
    this.$('.scrollbar-macosx.scroll-content').scrollbar('destroy');
  },
});