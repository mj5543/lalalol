import Ember from 'ember';
import layout from './template';
import ValidationControl from '../c-validationcontrol/component';

export default ValidationControl.extend({
  layout,
  classNames: ['c-codevalue', 'c-inp-txt'],
  tagName: 'div',
  //public properties
  style: null,
  codeName: null,
  codeValue: null,
  codeID: null,
  itemsSource: null,
  maxDropDownWidth: null,
  maxDropDownHeight: null,
  codeNamePath: 'codeName',
  codeValuePath: 'codeValue',
  codeIDPath: 'ID',
  showCodeValue: false,
  showDropDownLoader: false,
  tabindex: null,
  placeHolder: 'Enter keyword',
  disabled: false,
  readOnly: false,
  enableGotFocusAutoSelect: false,
  showClearButton: false,
  required: false,
  showValidationSuccess: false,
  externalErrorMessage: null,
  validationRules: null,
  useParentWormhole: true,
  placeInArea: false,
  //public events
  onLoaded: null,
  onUnload: null,
  onClick: null,
  onFocusIn: null,
  onFocusOut: null,
  onKeyPress: null,
  onKeyUp: null,
  onKeyDown: null,
  onChanged: null,
  onTextCleared: null,
  onFilterChanged: null,
  //public readonly Properties
  filterValue: Ember.computed.readOnly('_filterValue'),

  _beforeCodeValue: null,
  _ignoreChange: false,
  _debounceImmediate: null,
  _codevalueGuid: Ember.computed.readOnly('componentGuid'),
  _notReadOnly: Ember.computed.not('readOnly'),
  _showClearButtonAndNotReadOnly: Ember.computed.and('showClearButton', '_notReadOnly'),
  _internalValue: Ember.computed('codeName', {
    get (key) {
      const codeName = this.get('codeName');

      return Ember.isNone(codeName) ? '' : codeName;
    },
    set (key, value) {
      if (!this.get('_ignoreChange')) {
        this.set('_debounceImmediate', Ember.run.debounce(this, '_filterChange', value, 250));
      }

      return value;
    },
  }),
  _observedProperty1: Ember.computed('itemsSource.[]', function () {
    let itemsSource = this.get('itemsSource');

    if (!Ember.isArray(itemsSource)) {
      itemsSource = Ember.A();
    }
    this.set('_itemsSource', itemsSource);
  }).readOnly(),
  _filteredItemsSource: Ember.computed('_itemsSource.[]', '_internalValue', function () {
    const _itemsSource = this.get('_itemsSource'), _internalValue = this.get('_internalValue'), codeNamePath = this.get('codeNamePath'), codeValuePath = this.get('codeValuePath');
    let filteredItemsSource = null;

    if (typeof _internalValue === 'string') {
      try {
        filteredItemsSource = _itemsSource.filter(function (item) {
          return new RegExp(_internalValue.split('').join('[, ]*'), 'gi').test(Ember.get(item, codeNamePath))
            || new RegExp(_internalValue.split('').join('[, ]*'), 'gi').test(Ember.get(item, codeValuePath));
        });
      } catch (exception) {}
    }

    return filteredItemsSource;
  }).readOnly(),
  click(event) {
    this._raiseEvents('onClick', {
      source: this,
      originalEvent: event
    });
  },
  focusIn(event) {
    if (this.get('enableGotFocusAutoSelect')) {
      this.$('input:eq(0)').select();
    }
    this._raiseEvents('onFocusIn', {
      source: this,
      originalEvent: event
    });
  },
  focusOut(event) {
    this._syncDataValue(this.get('_internalValue'));
    this._raiseEvents('onFocusOut', {
      source: this,
      originalEvent: event,
    });
  },
  keyPress(event) {
    if (event.keyCode === 13) {
      event.preventDefault();
      this._syncDataValue(this.get('_internalValue'));
    }
    this._raiseEvents('onKeyPress', {
      source: this,
      originalEvent: event,
    });
  },
  keyUp(event) {
    this._raiseEvents('onKeyUp', {
      source: this,
      originalEvent: event
    });
  },
  keyDown(event) {
    if (event.keyCode === 40) {
      if (this.get('isOpen')) {
        event.stopPropagation();
        event.preventDefault();
        const $items = Ember.$(`.${this.get('_codevalueGuid')}-itemspanel:not(.disabled) li[data-item]`);

        if ($items.length > 0) {
          const index = $items.index($items.filter('.on')) + 1;

          if (index < $items.length) {
            $items.removeClass('on');
            $items.eq(index).addClass('on');
            if ($items.eq(index).prev().length > 0) {
              this._setItemspanelScrollTop($items.eq(index).prev().offset().top + $items.eq(index).closest('div.scrollbar-macosx').scrollTop() - $items.eq(index).closest('div.scrollbar-macosx').offset().top);
            }
          }
        }
      } else {
        event.stopPropagation();
        event.preventDefault();
        this.set('isOpen', true);
      }
    }
    if (event.keyCode === 38) {
      if (this.get('isOpen')) {
        event.stopPropagation();
        event.preventDefault();
        const $items = Ember.$(`.${this.get('_codevalueGuid')}-itemspanel:not(.disabled) li[data-item]`);

        if ($items.length > 0) {
          const index = $items.index($items.filter('.on')) - 1;

          if (0 <= index) {
            $items.removeClass('on');
            $items.eq(index).addClass('on');
            if ($items.eq(index).prev().length > 0) {
              this._setItemspanelScrollTop($items.eq(index).prev().offset().top + $items.eq(index).closest('div.scrollbar-macosx').scrollTop() - $items.eq(index).closest('div.scrollbar-macosx').offset().top);
            }
          }
        }
      }
    }
    if (event.keyCode === 13) {
      if (this.get('isOpen')) {
        event.stopPropagation();
        event.preventDefault();
        const $items = Ember.$(`.${this.get('_codevalueGuid')}-itemspanel:not(.disabled) li[data-item]`), $currentItem = $items.filter('.on');

        if ($currentItem.length > 0) {
          $currentItem.trigger('click');
        } else {
          const currentText = this.get('_internalValue');
          
          if ($items.length === 1 && !Ember.isEmpty(currentText)) {
            $items.trigger('click');
          } else {
            this._syncDataValue(currentText);
          }
        }
      }
    }
    this._raiseEvents('onKeyDown', {
      source: this,
      originalEvent: event
    });
  },
  _setItemspanelScrollTop(y) {
    const $itemspanel = Ember.$(`.${this.get('_codevalueGuid')}-itemspanel > div.scroll-wrapper.scrollbar-macosx > div.scrollbar-macosx`);
    if ($itemspanel.length > 0) {
      $itemspanel.scrollTop(y);
    }
  },
  _syncDataValue(currentText, currentValue) {
    const codeNamePath = this.get('codeNamePath'), codeValuePath = this.get('codeValuePath'), codeIDPath = this.get('codeIDPath'), item = this._findMatchItem(currentText, currentValue);
    let beforeCodeValue = null, afterCodeName = null, afterCodeValue = null, afterCodeID = null;

    beforeCodeValue = this.get('codeValue');
    this.set('_ignoreChange', true);
    Ember.run.cancel(this.get('_debounceImmediate'));
    this.set('isOpen', false);
    if (!Ember.isNone(item)) {
      this.set('codeName', Ember.get(item, codeNamePath));
      this.set('codeValue', Ember.get(item, codeValuePath));
      if (!Ember.isNone(codeIDPath)) {
        this.set('codeID', Ember.get(item, codeIDPath));
      }
    } else {
      if (Ember.isEmpty(currentText)) {
        this.set('codeName', null);
        this.set('codeValue', null);
        this.set('codeID', null);
      }
    }
    afterCodeName = this.get('codeName');
    afterCodeValue = this.get('codeValue');
    afterCodeID = this.get('codeID');
    Ember.run.schedule('afterRender', this, function () {
      if (!this.get('isDestroying') && !this.get('isDestroyed')) {
        this.$('input:eq(0)').val(afterCodeName);
      }
      afterCodeName = null;
    });
    Ember.run.next(this, function () {
      if (!this.get('isDestroying') && !this.get('isDestroyed')) {
        this.set('_ignoreChange', false);
      }
    });
    if (beforeCodeValue !== afterCodeValue) {
      this._raiseEvents('onChanged', {
        source: this,
        originalEvent: event,
        codeName: afterCodeName,
        codeValue: afterCodeValue,
        codeID: afterCodeID,
      });
    }
  },
  _findMatchItem(currentText, currentValue) {
    const _itemsSource = this.get('_itemsSource'), codeNamePath = this.get('codeNamePath'), codeValuePath = this.get('codeValuePath');
    let item = null;

    if (!Ember.isNone(currentValue)) {
      item = _itemsSource.findBy(codeValuePath, currentValue);
    } else if (!Ember.isEmpty(currentText)) {
      item = _itemsSource.findBy(codeNamePath, currentText);
      if (Ember.isNone(item)) {
        item = _itemsSource.findBy(codeValuePath, currentText);
      }
    }

    return item;
  },
  _filterChange(value) {
    if (!this.get('isDestroying') && !this.get('isDestroyed')) {
      this.set('isOpen', true);
      this.set('_filterValue', value);
      this._raiseEvents('onFilterChanged', {
        source: this,
        filterValue: this.get('filterValue'),
      });
    }
  },
  actions: {
    delMouseDown(event) {
      event.preventDefault();
      this.set('_internalValue', '');
      this._raiseEvents('onTextCleared', {
        source: this,
        originalEvent: event
      });
    },
    itemClick(item) {
      this._syncDataValue(Ember.get(item, this.get('codeNamePath')), Ember.get(item, this.get('codeValuePath')));
    },
  },
});