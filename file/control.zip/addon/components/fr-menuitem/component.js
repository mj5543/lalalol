import Ember from 'ember';
import layout from './template';

// menuItem
export default Ember.Component.extend({
  layout,
  init() {
    this._super(...arguments);
  },
  didInsertElement(){
    this._super(...arguments);

    Ember.Logger.log(this.get('text'));
    Ember.Logger.log(this.get('action'));

    const events = this.get('onWillRender');

    if (events) {
      events( { id : this.id, header : this.header, content : this.content, source : this });
    }
  }
});

