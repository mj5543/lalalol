import Ember from 'ember';
import layout from './template';

const { computed } = Ember;

export default Ember.Component.extend({
  layout,
  tagName: 'th',
  classNameBindings: ['_gridHeadCellClass','_nolineAfter:noline-after'],
  attributeBindings: ['cellIndex:data-head-cell-index','_rowspan:rowspan','_colspan:colspan','_key:data-column-key','_topKey:data-column-top-key','tabindex'],
  tabindex: -1,
  _rowspan: computed.readOnly('column.rowspan'),
  _colspan: computed.readOnly('column.colspan'),
  _key: computed.readOnly('column.key'),
  _topKey: computed.readOnly('column.topKey'),
  _title: computed.readOnly('column.title'),
  _styleOwner: computed.readOnly('column.styleOwner'),
  _hideColumnResizer: computed.and('_hideLastColumnResizer', '_isLastColumn').readOnly(),
  _nolineAfter: computed.and('_hideLastColumnLine', '_isLastColumn').readOnly(),
  _gridHeadCellClass: computed('_gridGuid', function () {
    return `${this.get('_gridGuid')}-head-cell`;
  }).readOnly(),
  _isLastColumn: computed('_styleOwner', '_lastBindingColumnKey', function () {
    return this.get('_styleOwner') === this.get('_lastBindingColumnKey');
  }).readOnly(),
  _sortingTag: computed('_sortingColumns.[]', 'column',function () {
    const _sortingColumns = this.get('_sortingColumns'), column = this.get('column'),
      sortingColumn = _sortingColumns.findBy('column', column);

    if (!Ember.isNone(sortingColumn)) {
      if (sortingColumn.direction === 'asc') {
        return Ember.String.htmlSafe('<span class="sorting on"><span class="blind">sortint</span></span>');
      }

      return Ember.String.htmlSafe('<span class="sorting"><span class="blind">sortint</span></span>');
    }

    return Ember.String.htmlSafe('<!---->');
  }).readOnly(),
  _menuTag: computed('column.menuTemplateName',function () {
    if (this.get('column.menuTemplateName')) {
      return Ember.String.htmlSafe(`<span class="head-menu ${this.get('_gridGuid')}-head-cell-menu"></span>`);
    }

    return Ember.String.htmlSafe('<!---->');
  }).readOnly(),
  init() {
    this._super(...arguments);
    const _init = this.get('column.onHeaderCellInit');

    if (Ember.typeOf(_init) === 'function') {
      _init.call(this, { cellComponent: this, column: this.get('column') });
    }
    if (this.get('column.headerTemplateName')) {
      Ember.defineProperty(this, 'layout', computed(function () {
        return Ember.HTMLBars.compile(`{{observedProperty}}<div style={{_htmlSafeHeaderLineHeight}} tabindex="-1"><div>{{yield (hash ${this.get('column.headerTemplateName')}=(component 'c-grid-head-cell-template' column=column))}}</div></div>{{_menuTag}}
          {{#unless _hideColumnResizer}}<div class="${this.get('_gridGuid')}-head-cell-resizer resizer" data-target-column={{_styleOwner}}></div>{{/unless}}`);
      }).readOnly());
    }
  },
  didInsertElement() {
    this._super(...arguments);
    const _render = this.get('column.onHeaderCellRender');

    if (Ember.typeOf(_render) === 'function') {
      _render.call(this, { cellComponent: this, column: this.get('column'), });
    }
    this.$().on('_getComponent', function (event, param) {
      param.component = this;
      event.stopPropagation();
      event.preventDefault();
    }.bind(this));
  },
  willDestroyElement() {
    this.$().off('_getComponent');
    this._super(...arguments);
  },
});