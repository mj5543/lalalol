import Ember from 'ember';
import Control from '../fr-control/component';
//import InputMixin from '../../mixins/input-mixin';

export default Control.extend(/*InputMixin, */{
  tagName: 'input',
  attributeBindings: [ '_observedAttribute', 'autocomplete', 'autocorrect', 'autocapitalize', 'spellcheck', 'disabled:disabled',
    'readonly:readonly', 'required:required', 'tabindex', 'name', 'type', 'title', 'placeholder', 'autofocus',
    'value', 'pattern', 'min', 'max', 'maxlength', 'pattern', 'size', 'step' ],
  autocomplete: 'off',
  autocorrect: 'off',
  autocapitalize: 'off',
  updateSourceTrigger: false,
  spellcheck: false,
  textMode: 'number',
  type: 'number',
  _observedAttribute: Ember.computed('clearButtonVisibility', 'searchButtonVisibility', 'isDataSucess', 'isDataError', 'disabled', 'readonly', function () {
    Ember.run.schedule('afterRender', this, function () {
      if (!this.get('isDestroying') && !this.get('isDestroyed')) {
        if (this.get('clearButtonVisibility')) {
          this.$().closest('.inp-txt').addClass('focus');
        } else {
          this.$().closest('.inp-txt').removeClass('focus');
        }
        if (this.get('searchButtonVisibility')) {
          this.$().closest('.inp-txt').addClass('inp-search');
          if ( this.$().closest('.inp-txt').children('span.search').length === 0) {
            this.$().closest('.inp-txt').children('button.del').after(`<span class='search'><span class='blind'>search</span></span>`);
            this.$().closest('.inp-txt').children('span.search').on('mousedown', this._onTextSearch.bind(this));
          }
        } else {
          this.$().closest('.inp-txt').removeClass('inp-search');
          this.$().closest('.inp-txt').children('span.search').remove();
          this.$().closest('.inp-txt').children('span.search').off('mousedown');
        }
        if (this.get('isDataSucess')) {
          this.$().closest('.inp-txt').addClass('ok');
        } else {
          this.$().closest('.inp-txt').removeClass('ok');
        }
        if (this.get('isDataError')) {
          this.$().closest('.inp-txt').addClass('error');
        } else {
          this.$().closest('.inp-txt').removeClass('error');
        }
        if (this.get('disabled')) {
          this.$().closest('.inp-txt').addClass('disabled');
        } else {
          this.$().closest('.inp-txt').removeClass('disabled');
        }
        if (this.get('readonly')) {
          this.$().closest('.inp-txt').addClass('readonly');
        } else {
          this.$().closest('.inp-txt').removeClass('readonly');
        }
      }
    });

    return null;
  }),
  didInsertElement() {
    this._super(...arguments);

    this.$().addClass('fr-input').addClass('fr-numericupdown');
    this.$().wrap(`<div class="inp-txt"></div>`);
    this.$().after(`<button class='del'><span class='blind'>delete</span></button>`);
    this.$().closest('.inp-txt').children('button.del').on('mousedown', this._onTextClear.bind(this));
    this.$().closest('.inp-txt').css('width', this.$().prop('style')['width']);
    if (Ember.isArray(this.get('classNames'))) {
      this.get('classNames').forEach(function (className) {
        this.$().closest('.inp-txt').addClass(className);
        this.$().removeClass(className);
      }.bind(this));
    }
    this.$().on('focus', this._onFocus.bind(this)).on('change', this._onChange.bind(this));
    if (this.updateSourceTrigger === true) {
      this.$().on('input propertychange', this._onChange.bind(this));
    }
  },
  willDestroyElement() {
    this._super(...arguments);

    this.$().off('focus').off('change').off('input propertychange');
    this.$().closest('.inp-txt').children('button.del').off('mousedown');
    this.$().closest('.inp-txt').children('span.search').off('mousedown');
  },
  _onChange(e) {
    const minVlue = this.get('min'), maxVlue = this.get('max');
    let newValue = parseInt(e.target.value);

    if (this.get('textMode') === 'decimal') {
      newValue = parseFloat(e.target.value)
    }
    if (!Ember.isEmpty(minVlue) && minVlue > newValue) {
      this._raiseEvents('minVaildAction', minVlue);
      this.$().val(minVlue);
      this.set('value', minVlue);
    } else if (!Ember.isEmpty(maxVlue) && maxVlue < newValue) {
      this._raiseEvents('maxVaildAction', maxVlue);
      this.$().val(maxVlue);
      this.set('value', maxVlue);
    } else {
      this.set('value', newValue);
    }
    this._raiseEvents('changed', { 'source': this, 'value': this.get('value') });
  },
  _onFocus(e) {
    if (this.get('isGotFocusAutoSelect')) {
      this.$(e.currentTarget).select();
    }
  },
  _onTextClear(e) {
    e.preventDefault();
  },
  _onTextSearch(e) {
    e.preventDefault();
  },
/*
  attributeBindings: ['_propertyChangedCallback:data-somevalue','type', 'name', 'disabled', 'readonly', 'required', 'title', 'placeholder', 'autofocus', 'value', 'pattern', 'onblur', 'min', 'max', 'maxlength', 'pattern', 'size', 'step'],
  classNames: ['inp-txt'],
  tagName: 'input',
  isGotFocusAutoSelect: false,
  updateSourceTrigger: false,
  min: null,
  max: null,
  type: 'number',
  changed: null,
  _propertyChangedCallback: Ember.computed('readonly', 'disabled', function() {

    this._onStateChanged();

    const val = this.get('value') ;

    if ( Ember.isEmpty(val)) {
      return 0 ;
    }

    return val.length ;
  }),
  _onChange(e) {

    const minVlue = this.get('min') ;
    const maxVlue = this.get('max') ;
    const newValue = parseInt(e.target.value) ;
    let isSucess = true ;

    if (!Ember.isEmpty(minVlue) && minVlue > newValue) {
      this._raiseEvents('minVaildAction', minVlue);
      this.set('value', minVlue);
      isSucess = false ;
    }

    if (!Ember.isEmpty(maxVlue) && maxVlue < newValue) {
      this._raiseEvents('maxVaildAction', maxVlue);
      this.set('value', maxVlue);
      isSucess = false ;
    }

    if ( isSucess === true) {
      this.set('value', newValue);
    }
    this._raiseEvents('changed', { 'source': this, 'value': this.get('value') });

  },
  _onFocus(e) {
    if (this.get('isGotFocusAutoSelect') === true && this.$().is('[readonly]') !== true) {
      this.$(e.currentTarget).select();
    }
  },
  _onTextClear(e) {
    e.preventDefault();
  },
  _onTextSearch(e) {
    e.preventDefault();
  },
  didInsertElement() {
    this._super(...arguments);

    this._initializeTextBox();

    this.$().addClass('fr-numericupdown')
      .on('focus', this._onFocus.bind(this))
      .on('change', this._onChange.bind(this));

    if (this.updateSourceTrigger === true) {
      this.$().on('input propertychange', this._onChange.bind(this));
    }

    this._onStateChanged();
  },
  willDestroyElement() {
    this._super(...arguments);

    this.$().off('change').off('focus').off('input propertychange');
  }
*/
});