import layout from './template';
import Control from '../c-control/component';

export default Control.extend({
  tagName: 'div',
  layout,
  classNames: ['panel-primary'],
  ratio: null,
  isCloseButton: null,
  onPropertyInit(){
    this._super(...arguments);
    if (this.hasState() === false) {
      this.set('isCloseButton', false);
    }
  },
  didInsertElement() {
    this._super(...arguments);
    const ratio = JSON.parse(this.get('ratio'));

    if(this.get('direction') === 'horizontal') {
      this.$().css({
        width: `${ratio[0] * 10}%`
      });
    } else {
      this.$().css({
        height: `${ratio[0] * 10}%`
      });
    }
  },
  actions: {
    colapsePanel() {
      this.$().toggleClass('collapse');
    }
  }
});