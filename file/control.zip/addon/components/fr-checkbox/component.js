import Ember from 'ember';
import Togglebase from '../fr-togglebase/component';
export default Togglebase.extend({
  attributeBindings: ['type', 'value', 'checked', '_watchIndeterminate:data-indeterminate'],
  tagName: 'input',
  type: 'checkbox',
  indeterminate : false,
  _watchIndeterminate: Ember.computed('indeterminate', function() {
    return this.get('indeterminate') === true ? 'y' : 'n';
  }).readOnly(),
  _onCheckChanged(){
    this.$().next().html( this.get('content')) ;
    this._onRaiseChanged(this.get('checked') ) ;
  },
  _onInputChange(){
    this.set('checked', this.$().is(':checked'));
  },
  _onLabelMouseDown() {
    //this._raiseEvents('mouseDown', e);
  },
  _onLabelClick(e) {
    e.stopPropagation();
  },
  didInsertElement(){
    this._super(...arguments);
    const tabIndex = this.$().attr('tabindex') ;

    if ( Ember.isEmpty(tabIndex) || Number.isNaN(tabIndex)) {
      this.$().wrap(`<span class='fr-checkbox inp-chk ${this.classNames.join(' ')}'></span>`);
    } else {
      this.$().wrap(`<span tabindex='${-1}' class='fr-checkbox inp-chk ${this.classNames.join(' ')}'></span>`);
    }

    this.$()
       .on('change.checkbox', this._onInputChange.bind(this))
        //.attr('tabindex', -1)
       .after(`<label for='${this.id}'>${this.content}</label>`)
       .next()
       .on('mousedown', this._onLabelMouseDown.bind(this))
       .on('click', this._onLabelClick.bind(this));
  },
  willDestroyElement(){
    this._super(...arguments);
    this.$().off('change.checkbox')
      .next()
      .off('mousedown')
      .off('click');
  },
});