import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

export default Control.extend(StatefulComponentMixin, {
  layout,
  classNames: ['c-panel'],
  classNameBindings: ['visiblityClass'],
  tagName: 'div',
  skipState: true,
  visibility: true,
  _visibility: true,
  visiblityClass: Ember.computed('visibility', function() {
    if (this.get('visibility') === true && !this.get('_visibility')) {
      this.set('_visibility', true);
      Ember.run.schedule('afterRender', this, function () {
        this.$('.scrollbar-macosx:not(.scroll-content)').scrollbar();
      });
    }

    return !this.get('visibility') ? 'hide' : null;
  }).readOnly(),
  init() {
    this._super(...arguments);
    if (!this.get('visibility')) {
      this.set('_visibility', false);
    }
  },
  willDestroyElement(){
    this.$('.scrollbar-macosx').scrollbar('destroy');
    this._super(...arguments);
  },
});