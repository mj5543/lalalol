import Ember from 'ember';
import ToolTipMixin from '../../mixins/tooltip-mixin';

export default Ember.Component.extend(ToolTipMixin, {
  delay: 2,
  _internalOnMouseEnter(e) {
    e.data.source._onmouseEnter(e);
  },
  _internalOnMouseLeave(e) {
    e.data.source._onmouseLeave();
  },
  didInsertElement() {
    this._super(...arguments);

    this.$().parent().on('mouseenter', { 'source': this }, this._internalOnMouseEnter)
    this.$().parent().on('mouseleave', { 'source': this }, this._internalOnMouseLeave)
    //this.$().remove();
  },
  willDestroyElement() {
    this._super(...arguments);

    this.$().parent().off('mouseenter', this._internalOnMouseEnter)
    this.$().parent().off('mouseleave', this._internalOnMouseLeave)
  },
});

