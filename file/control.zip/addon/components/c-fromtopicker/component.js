import Ember from 'ember';
import moment from 'moment';
import layout from './template';
import ValidationControl from '../c-validationcontrol/component';

export default ValidationControl.extend({
  layout,
  classNames: ['c-fromtopicker', 'c-inp-txt'],
  tagName: 'div',
  useParentWormhole: true,
  i18nService: Ember.inject.service('i18n-service'),
  //public properties
  style: null,
  pickerType: 'date',
  displayFromDate: null,
  displayToDate: null,
  selectedFromDate: null,
  selectedToDate: null,
  oldSelectedFromDate: null,
  oldSelectedToDate: null,
  openSelectedFromDate: null,
  openSelectedToDate: null,
  patternDays: null,
  eventDays: null,
  holidays: null,
  disabledDates: null,
  minDate: null,
  maxDate: null,
  navigationMode: 'date',
  navigationInterval: 1,
  showCalendarButton: true,
  showNavigation: false,
  showTodayNavigation: false,
  enableGotFocusAutoSelect: true,
  tabindex: null,
  placeHolderFrom: null,
  placeHolderTo: null,
  disabled: false,
  readOnly: false,
  required: false,
  showValidationSuccess: false,
  showValidationError: false,
  externalErrorMessage: null,
  validationRules: null,
  toDay: null,
  toDayName: null,
  isTimepadEmbeded: true,
  placeInArea: false,
  showTodayButton: false,
  //public events
  onChanged: null,
  onTextCommit: null,
  onTextSearch: null,
  onTextCleared: null,
  _hasLoaded: false,
  _currentTime: null,
  _timer: 0,
  _baseTime: null,
  _notReadOnly: Ember.computed.not('readOnly'),
  _showClearButtonAndNotReadOnly: Ember.computed.and('showClearButton', '_notReadOnly'),
  _pickerFormats: Ember.computed('pickerType', function () {
    return this._createFormat(this.get('i18nService.currentLocale'), this.get('pickerType'));
  }).readOnly(),
  _currentTime: Ember.computed('_timer', '_baseTime', function () {
    if (!this.get('isDestroying') && !this.get('isDestroyed')) {
      let _baseTime = this.get('_baseTime'), _timer = this.get('_timer');

      if (Ember.isNone(_baseTime) || 180 < _timer) {
        _baseTime = moment(this.get('co_CommonService').getNow());
        this.set('_baseTime', _baseTime);
        _timer = 0;
      }
      Ember.run.later(this, function () {
        if (!this.get('isDestroying') && !this.get('isDestroyed')) {
          _baseTime.add(1, 'seconds');
          this.set('_timer', _timer + 1);
        } else {
          _baseTime = null;
          _timer = null;
        }
      }, 1000);

      return _baseTime.toDate();
    }
  }).readOnly(),
  watchIsOpen: Ember.computed('isOpen', function () {
    if(this.get('_hasLoaded')) {
      Ember.run.once(this, '_isOpenChanged');
    }

    return this.get('isOpen');
  }).readOnly(),
  showCalendar: Ember.computed('pickerType', function () {
    const pickerType = this.get('pickerType');

    return pickerType === 'date' || pickerType === 'dateTime' || pickerType === 'dateLongTime' || pickerType === 'year' || pickerType === 'yearMonth';
  }),
  showTimepad: Ember.computed('pickerType', function () {
    const pickerType = this.get('pickerType');

    return pickerType === 'dateTime' || pickerType === 'dateLongTime' || pickerType === 'time' || pickerType === 'longTime';
  }),
  _onlyTimepad: Ember.computed('pickerType', function () {
    const pickerType = this.get('pickerType');

    if (pickerType === 'time' || pickerType === 'dateLongTime') {
      this.set('isTimepadEmbeded', false);
    } else {
      this.set('isTimepadEmbeded', true);
    }
    Ember.run.once(this, '_setCalendarMode', pickerType);

    return pickerType === 'time' || pickerType === 'longTime';
  }),
  _onlyDateTime: Ember.computed('pickerType', function () {
    const pickerType = this.get('pickerType');

    return pickerType === 'dateTime';
  }),
  minFromDate: Ember.computed.alias('minDate'),
  maxFromDate: Ember.computed('maxDate', 'selectedToDate', function () {
    const maxDate = this.get('maxDate'), selectedToDate = this.get('selectedToDate');
    let newMaxdate = null;

    if (this._isDateInstance(maxDate)) {
      newMaxdate = maxDate;
    }
    if (this._isDateInstance(selectedToDate)) {
      if (Ember.isNone(newMaxdate) || selectedToDate < newMaxdate) {
        newMaxdate = selectedToDate;
      }
    }

    return newMaxdate;
  }),
  minToDate: Ember.computed('minDate', 'selectedFromDate', function () {
    const minDate = this.get('minDate'), selectedFromDate = this.get('selectedFromDate');
    let newMindate = null;

    if (this._isDateInstance(minDate)) {
      newMindate = minDate;
    }
    if (this._isDateInstance(selectedFromDate)) {
      if (Ember.isNone(newMindate) || newMindate < selectedFromDate) {
        newMindate = selectedFromDate;
      }
    }

    return newMindate;
  }),
  maxToDate: Ember.computed.alias('maxDate'),
  internalFromValue: Ember.computed('selectedFromDate', '_datetimeFromOptions', {
    get (key) {
      if (this._isDateInstance(this.get('selectedFromDate'))) {
        return Inputmask.unmask(moment(this.get('selectedFromDate')).format('YYYY-MM-DD HH:mm:ss'), {
          alias: 'datetime',
          inputFormat: 'yyyy-mm-dd HH:MM:ss',
          outputFormat: this.get('_datetimeFromOptions').inputFormat,
        });
      }
    },
    set (key, value) {
      return value;
    },
  }),
  internalToValue: Ember.computed('selectedToDate', '_datetimeToOptions', {
    get (key) {
      if (this._isDateInstance(this.get('selectedToDate'))) {
        return Inputmask.unmask(moment(this.get('selectedToDate')).format('YYYY-MM-DD HH:mm:ss'), {
          alias: 'datetime',
          inputFormat: 'yyyy-mm-dd HH:MM:ss',
          outputFormat: this.get('_datetimeToOptions').inputFormat,
        });
      }
    },
    set (key, value) {
      return value;
    },
  }),
  _datetimeFromOptions: Ember.computed('pickerType', 'minFromDate', 'maxFromDate', function () {
    const formats = this.get('_pickerFormats'), minDate = this.get('minFromDate'), maxDate = this.get('maxFromDate');
    let min = null, max = null;

    if (this._isDateInstance(minDate)) {
      min = Inputmask.unmask(moment(minDate).format('YYYY-MM-DD HH:mm:ss'), { alias: 'datetime', inputFormat: 'yyyy-mm-dd HH:MM:ss', outputFormat: formats.inputFormat });
    }
    if (this._isDateInstance(maxDate)) {
      max = Inputmask.unmask(moment(maxDate).format('YYYY-MM-DD HH:mm:ss'), { alias: 'datetime', inputFormat: 'yyyy-mm-dd HH:MM:ss', outputFormat: formats.inputFormat });
    }
    if (this.$ && this.$('input:eq(0)').inputmask) {
      this.$('input:eq(0)').inputmask('remove');
      this.$('input:eq(0)').val('');
    }

    return { alias: 'datetime', min: min, max: max, inputFormat: formats.inputFormat, outputFormat: formats.outputFormat, };
  }),
  _datetimeToOptions: Ember.computed('pickerType', 'minToDate', 'maxToDate', function () {
    const formats = this.get('_pickerFormats'), minDate = this.get('minToDate'), maxDate = this.get('maxToDate');
    let min = null, max = null;

    if (this._isDateInstance(minDate)) {
      min = Inputmask.unmask(moment(minDate).format('YYYY-MM-DD HH:mm:ss'), { alias: 'datetime', inputFormat: 'yyyy-mm-dd HH:MM:ss', outputFormat: formats.inputFormat });
    }
    if (this._isDateInstance(maxDate)) {
      max = Inputmask.unmask(moment(maxDate).format('YYYY-MM-DD HH:mm:ss'), { alias: 'datetime', inputFormat: 'yyyy-mm-dd HH:MM:ss', outputFormat: formats.inputFormat });
    }
    if (this.$ && this.$('input:eq(1)').inputmask) {
      this.$('input:eq(1)').inputmask('remove');
      this.$('input:eq(1)').val('');
    }
    
    return { alias: 'datetime', min: min, max: max, inputFormat: formats.inputFormat, outputFormat: formats.outputFormat, };
  }),
  observedProperty1: Ember.computed('_datetimeFromOptions', function () {
    Ember.run.scheduleOnce('afterRender', this, '_initFromInputmask');
  }),
  observedProperty2: Ember.computed('_datetimeToOptions', function () {
    Ember.run.scheduleOnce('afterRender', this, '_initToInputmask');
  }),
  observedProperty3: Ember.computed('selectedFromDate', 'selectedToDate', function () {
    Ember.run.once(this, '_selectedDateChanged');
  }),
  init() {
    this._super(...arguments);
  },
  didInsertElement() {
    this._super(...arguments);
    this.set('_hasLoaded', true);
    this.set('toDayName', this.get('fr_I18nService').getRegional().dayNamesShort[this.get('co_CommonService').getNow().getDay()]);
  },
  willDestroyElement() {
    this.$('input').each(function (idx, el) { if (el.inputmask) { el.inputmask.remove(); } });
    this._super(...arguments);
  },
  _isDateInstance(date) {
    return date instanceof Date && !Number.isNaN(date.valueOf());
  },
  _createFormat(lang, picker) {
    let inputFormat, outputFormat, momentFormat;

    if (lang === 'ko-kr') {
      switch (picker) {
        case 'date':
          inputFormat = 'yyyy-mm-dd';
          outputFormat = 'yyyy-mm-dd';
          momentFormat = 'YYYY-MM-DD';
          break;
        case 'dateTime':
          inputFormat = 'yyyy-mm-dd HH:MM';
          outputFormat = 'yyyy-mm-dd HH:MM';
          momentFormat = 'YYYY-MM-DD HH:mm';
          break;
        case 'time':
          inputFormat = 'HH:MM';
          outputFormat = 'HH:MM';
          momentFormat = 'HH:mm';
          break;
        case 'year':
          inputFormat = 'yyyy';
          outputFormat = 'yyyy';
          momentFormat = 'YYYY';
          break;
        case 'yearMonth':
          inputFormat = 'yyyy-mm';
          outputFormat = 'yyyy-mm';
          momentFormat = 'YYYY-MM';
          break;
      }
    } else {
      switch (picker) {
        case 'date':
          inputFormat = 'mm/dd/yyyy';
          outputFormat = 'yyyy-mm-dd';
          momentFormat = 'MM/DD/YYYY';
          break;
        case 'dateTime':
          inputFormat = 'mm/dd/yyyy HH:MM';
          outputFormat = 'yyyy-mm-dd HH:MM';
          momentFormat = 'MM/DD/YYYY HH:mm';
          break;
        case 'time':
          inputFormat = 'HH:MM';
          outputFormat = 'HH:MM';
          momentFormat = 'HH:mm';
          break;
        case 'year':
          inputFormat = 'yyyy';
          outputFormat = 'yyyy';
          momentFormat = 'YYYY';
          break;
        case 'yearMonth':
          inputFormat = 'mm/yyyy';
          outputFormat = 'yyyy-mm';
          momentFormat = 'MM/YYYY';
          break;
      }
    }

    return { inputFormat: inputFormat, outputFormat: outputFormat, momentFormat: momentFormat };
  },
  _initFromInputmask() {
    const date = this.get('selectedFromDate'), options = this.get('_datetimeFromOptions');

    Inputmask(options).mask(this.$('input:eq(0)'));
    if (this._isDateInstance(date)) {
      this.$('input:eq(0)').val(Inputmask.unmask(moment(date).format('YYYY-MM-DD HH:mm:ss'), { alias: 'datetime', inputFormat: 'yyyy-mm-dd HH:MM:ss', outputFormat: options.inputFormat }));
    }
  },
  _initToInputmask() {
    const date = this.get('selectedToDate'), options = this.get('_datetimeToOptions');

    Inputmask(options).mask(this.$('input:eq(1)'));
    if (this._isDateInstance(date)) {
      this.$('input:eq(1)').val(Inputmask.unmask(moment(date).format('YYYY-MM-DD HH:mm:ss'), { alias: 'datetime', inputFormat: 'yyyy-mm-dd HH:MM:ss', outputFormat: options.inputFormat }));
    }
  },
  _syncDataValue() {
    const formats = this.get('_pickerFormats');
    let changed = false;

    if (this.$('input:eq(0)').inputmask('isComplete')) {
      if (this.get('pickerType') === 'time') {
        if (!this._isDateInstance(this.get('selectedFromDate'))) {
          this.set('selectedFromDate', moment(`${moment(this.get('co_CommonService').getNow()).format('YYYY-MM-DD')} ${moment(this.get('internalFromValue'), formats.momentFormat).format(formats.momentFormat)}`, 'YYYY-MM-DD HH:mm').toDate());
          changed = true;
        } else if (moment(this.get('selectedFromDate')).format(formats.momentFormat) !== moment(this.get('internalFromValue'), formats.momentFormat).format(formats.momentFormat)) {
          this.set('selectedFromDate', moment(`${moment(this.get('selectedFromDate')).format('YYYY-MM-DD')} ${moment(this.get('internalFromValue'), formats.momentFormat).format(formats.momentFormat)}`, 'YYYY-MM-DD HH:mm').toDate());
          changed = true;
        }
      } else {
        if (!this._isDateInstance(this.get('selectedFromDate')) || moment(this.get('selectedFromDate')).format(formats.momentFormat) !== moment(this.get('internalFromValue'), formats.momentFormat).format(formats.momentFormat)) {
          this.set('selectedFromDate', moment(this.get('internalFromValue'), formats.momentFormat).toDate());
          changed = true;
        }
      }
    } else {
      if (!Ember.isNone(this.get('selectedFromDate'))) {
        this.set('selectedFromDate', null);
        changed = true;
      }
      Ember.run.schedule('afterRender', this, function () {
        if (!this.get('isDestroying') && !this.get('isDestroyed')) {
          this.$('input:eq(0)').val('');
        }
      });
    }
    if (this.$('input:eq(1)').inputmask('isComplete')) {
      if (this.get('pickerType') === 'time') {
        if (!this._isDateInstance(this.get('selectedToDate'))) {
          this.set('selectedToDate', moment(`${moment(this.get('co_CommonService').getNow()).format('YYYY-MM-DD')} ${moment(this.get('internalToValue'), formats.momentFormat).format(formats.momentFormat)}`, 'YYYY-MM-DD HH:mm').toDate());
          changed = true;
        } else if (moment(this.get('selectedToDate')).format(formats.momentFormat) !== moment(this.get('internalToValue'), formats.momentFormat).format(formats.momentFormat)) {
          this.set('selectedToDate', moment(`${moment(this.get('selectedToDate')).format('YYYY-MM-DD')} ${moment(this.get('internalToValue'), formats.momentFormat).format(formats.momentFormat)}`, 'YYYY-MM-DD HH:mm').toDate());
          changed = true;
        }
      } else {
        if (!this._isDateInstance(this.get('selectedToDate')) || moment(this.get('selectedToDate')).format(formats.momentFormat) !== moment(this.get('internalToValue'), formats.momentFormat).format(formats.momentFormat)) {
          this.set('selectedToDate', moment(this.get('internalToValue'), formats.momentFormat).toDate());
          changed = true;
        }
      }
    } else {
      if (!Ember.isNone(this.get('selectedToDate'))) {
        this.set('selectedToDate', null);
        changed = true;
      }
      Ember.run.schedule('afterRender', this, function () {
        if (!this.get('isDestroying') && !this.get('isDestroyed')) {
          this.$('input:eq(1)').val('');
        }
      });
    }
    if (changed) {
      this._selectedDateUpdated();
    }
  },
  _isOpenChanged() {
    this._raiseEvents('onIsOpenChanged', {
      source: this,
      selectedFromDate: this.get('selectedFromDate'),
      selectedToDate: this.get('selectedToDate'),
    });
    if(!this.get('isOpen') && 
    (
      (this._isDateInstance(this.get('openSelectedFromDate')) && !this._isDateInstance(this.get('selectedFromDate'))) || (!this._isDateInstance(this.get('openSelectedFromDate')) && this._isDateInstance(this.get('selectedFromDate'))) ||
      (this._isDateInstance(this.get('openSelectedToDate')) && !this._isDateInstance(this.get('selectedToDate'))) || (!this._isDateInstance(this.get('openSelectedToDate')) && this._isDateInstance(this.get('selectedToDate'))) ||
      moment(this.get('openSelectedFromDate')).format('YYYY-MM-DD HH:mm:ss') !== moment(this.get('selectedFromDate')).format('YYYY-MM-DD HH:mm:ss') ||
      moment(this.get('openSelectedToDate')).format('YYYY-MM-DD HH:mm:ss') !== moment(this.get('selectedToDate')).format('YYYY-MM-DD HH:mm:ss')
    )) {
      this._selectedDateUpdated();
    }
    this.set('openSelectedFromDate', this.get('selectedFromDate'));
    this.set('openSelectedToDate', this.get('selectedToDate'));
  },
  _setCalendarMode(pickerType) {
    switch (pickerType) {
      case 'date':
        this.set('calendarFromMode', 'month');
        this.set('calendarToMode', 'month');
        break;
      case 'dateTime':
        this.set('calendarFromMode', 'month');
        this.set('calendarToMode', 'month');
        break;
      case 'year':
        this.set('calendarFromMode', 'decade');
        this.set('calendarToMode', 'decade');
        break;
      case 'yearMonth':
        this.set('calendarFromMode', 'year');
        this.set('calendarToMode', 'year');
        break;
      default:
        this.set('calendarFromMode', 'month');
        this.set('calendarToMode', 'month');
        break;
    }
  },
  _constructorDateParam(fromDt, toDt) {
    const result = {};

    if (this._isDateInstance(fromDt)) {
      const md = moment(fromDt);

      Ember.$.extend(result, { source: this, selectedFromDate: fromDt, fromYear: md.get('year'), fromMonth: md.get('month'), fromDate: md.get('date'), fromDay: md.get('day'), fromHour: md.get('hour'), fromMinute: md.get('minute') });
    } else {
      Ember.$.extend(result, { source: this, selectedFromDate: fromDt, fromYear: null, fromMonth: null, fromDate: null, fromDay: null, fromHour: null, fromMinute: null });
    }
    if (this._isDateInstance(toDt)) {
      const md = moment(toDt);

      Ember.$.extend(result, { selectedToDate: toDt, toYear: md.get('year'), toMonth: md.get('month'), toDate: md.get('date'), toDay: md.get('day'), toHour: md.get('hour'), toMinute: md.get('minute') });
    } else {
      Ember.$.extend(result, { selectedToDate: toDt, toYear: null, toMonth: null, toDate: null, toDay: null, toHour: null, toMinute: null });
    }

    return result;
  },
  _selectedDateChanged() {
    this.set('_internalValue', this._isDateInstance(this.get('selectedFromDate')) && this._isDateInstance(this.get('selectedToDate')));
    if (this.get('_hasLoaded')) {
      const params = this._constructorDateParam(this.get('selectedFromDate'), this.get('selectedToDate'));

      this._raiseEvents('onSelectionChanged', params);
    }
  },
  _selectedDateUpdated() {
    const params = this._constructorDateParam(this.get('selectedFromDate'), this.get('selectedToDate'));

    this._raiseEvents('onDateUpdated', params);
  },
  /*_complexTime({date, time}) {
    if(date && time) {
      const newDate = new Date(
        date.getFullYear(),
        date.getMonth(),
        date.getDate(),
        time.getHours(),
        time.getMinutes(),
        0);
      return newDate;
    } else if(date && !time) {
      return date;
    } else if(!date && time) {
      return time;
    } else {
      return false;
    }
  },*/
  /*_getPickerTypeDate({pickerType, date}) {
    if (Ember.isEmpty(date)) {
      return null;
    }
    switch (pickerType) {
      case 'date':
        return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 0, 0);
      case 'dateTime':
        return new Date(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), 0);
      case 'time':
        return new Date(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), 0);
      case 'year':
        return new Date(date.getFullYear(), 0, 1, 0, 0, 0);
      case 'yearMonth':
        return new Date(date.getFullYear(), date.getMonth(), 1, 0, 0, 0);
      default:
        return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 0, 0);
    }
  },
  _setDate({seq, val}) {
    this.set(seq, val);
    const now = this.get('co_CommonService').getNow();

    if(seq === 'selectedFromDate' && Ember.isEmpty(this.get('selectedToDate'))) {
      if(val > now) {
        this.set('selectedToDate', val);
      } else {
        this.set('selectedToDate', now);
      }
    } else if(seq === 'selectedToDate' && Ember.isEmpty(this.get('selectedFromDate'))) {
      if(val < now) {
        this.set('selectedFromDate', val);
      } else {
        this.set('selectedFromDate', now);
      }
    }

    if (!this._isDateInstance(val)) {
      this._maskinput.clear();
    }
  },*/
  _setFromNow() {
    const now = this.get('co_CommonService').getNow(), pickerType = this.get('pickerType');

    if (pickerType === 'year') {
      this.set('calendarFromMode', 'decade');
    } else if (pickerType === 'yearMonth') {
      this.set('calendarFromMode', 'year');
    } else {
      this.set('calendarFromMode', 'month');
    }
    this.set('selectedFromDate', moment(now).toDate());
    this.set('displayFromDate', moment(now).toDate());
  },
  _setToNow() {
    const now = this.get('co_CommonService').getNow(), pickerType = this.get('pickerType');

    if (pickerType === 'year') {
      this.set('calendarToMode', 'decade');
    } else if (pickerType === 'yearMonth') {
      this.set('calendarToMode', 'year');
    } else {
      this.set('calendarToMode', 'month');
    }
    this.set('selectedToDate', moment(now).toDate());
    this.set('displayToDate', moment(now).toDate());
  },
  focusIn(event) {
    let eventName;
    if(event.target.name === 'daterangepicker-from') {
      eventName = 'onFromDateFocus';
    } else {
      eventName = 'onToDateFocus';
    }
    this._raiseEvents(eventName, {
      source: this,
      originalEvent: event
    });
  },
  focusOut(event) {
    this._syncDataValue();
    let eventName;
    if(event.target.name === 'daterangepicker-from') {
      eventName = 'onFromDateBlur';
    } else {
      eventName = 'onToDateBlur';
    }
    this._raiseEvents(eventName, {
      source: this,
      originalEvent: event
    });
  },
  keyPress(event) {
    if (event.keyCode === 13) {
      event.preventDefault();
      this._syncDataValue();
    }
  },
  keyDown(event) {
    let eventName;
    if(event.target.name === 'daterangepicker-from') {
      eventName = 'onFromDateKeyDown';
    } else {
      eventName = 'onToDateKeyDown';
    }
    this._raiseEvents(eventName, {
      source: this,
      originalEvent: event
    });
  },
  actions: {
    currentTimeDoubleClick() {
      this.set('isOpen', false);
    },
    onFromTodayClickAction() {
      this._setFromNow();
    },
    onToTodayClickAction() {
      this._setToNow();
    },
    onTodayButtonClick() {
      this._setFromNow();
      this._setToNow();
    },
    /*
    onSelectedFromDatesChanged() {
      this._selectedFromDate();
    },
    onSelectedToDatesChanged() {
      this._selectedToDate();
    },
    onSelectedFromTimeChanged() {
      const newDate = this._complexTime({
        date: this._convertDate(this.get('selectedFromDate')),
        time: this.get('selectedFromTime')
      });
      this.set('selectedFromDate', newDate);
    },
    onSelectedToTimeChanged() {
      const newDate = this._complexTime({
        date: this._convertDate(this.get('selectedToDate')),
        time: this.get('selectedToTime')
      });
      this.set('selectedToDate', newDate);
    },
    */
    calendarDoubleClick(e) {
      //this._selectedFromDate();
      //this._selectedToDate();
      if (this.$(':focus').length === 0) {
        this.$('input').focus();
      }
      // if(e !== 'date') {
      //   if(e === this.get('pickerType')) {
      //     this.set('isOpen', false);
      //   }
      // } else {
      //   this.set('isOpen', false);
      // }
      switch(e) {
        case 'year':
          if (picker === 'year') {
            this.set('isOpen', false);
          }
          break;
        case 'month':
          if (picker === 'yearMonth') {
            this.set('isOpen', false);
          }
          break;
        case 'date':
          this.set('isOpen', false);
          break;
        default: this.set('isOpen', true);
      }
    },
    searchMouseDown(event) {
      event.preventDefault();
      if (this.$(':focus').length === 0) {
        this.$('input').focus();
      }
      this.toggleProperty('isOpen');
      this.set('toDay', this.get('co_CommonService').getNow());
    },
    delMouseDown(event) {
      event.preventDefault();
      this.set('_internalValue', '');
      this._raiseEvents('onTextCleared', {
        source: this,
        originalEvent: event
      });
    },
    mouseDownCancel(event) {
      event.preventDefault();
    },
    mouseDownActionCancel(event) {
      event.originalEvent.preventDefault();
    },
    mouseDownToOutside(event) {
      if (this.element && !this.element.contains(event.target) &&
      !document.getElementById('max-wormhole-parent').contains(event.target)) {
        this.set('isOpen', false);
      }
    },
    preNavigationClick(event) {
      const date = this.get('selectedFromDate');

      if (date instanceof Date && !isNaN(date.valueOf())) {
        const navigationMode = this.get('pickerType'), navigationInterval = this.get('navigationInterval');

        // switch (navigationMode) {
        //   case 'year': this.set('selectedDate', moment(date).add(-1*navigationInterval, 'y').toDate()); break;
        //   case 'month': this.set('selectedDate', moment(date).add(-1*navigationInterval, 'M').toDate()); break;
        //   case 'date': this.set('selectedDate', moment(date).add(-1*navigationInterval, 'd').toDate()); break;
        //   case 'hours': this.set('selectedDate', moment(date).add(-1*navigationInterval, 'h').toDate()); break;
        //   case 'minutes': this.set('selectedDate', moment(date).add(-1*navigationInterval, 'm').toDate()); break;
        //   case 'seconds': this.set('selectedDate', moment(date).add(-1*navigationInterval, 's').toDate()); break;
        // }
        switch (navigationMode) {
          case 'year': this.set('selectedFromDate', moment(date).add(-1*navigationInterval, 'y').toDate());
            break;
          case 'yearMonth': this.set('selectedFromDate', moment(date).add(-1*navigationInterval, 'M').toDate());
            break;
          case 'date': this.set('selectedFromDate', moment(date).add(-1*navigationInterval, 'd').toDate());
            break;
          case 'dateTime': this.set('selectedFromDate', moment(date).add(-1*navigationInterval, 'd').toDate());
            break;
          case 'time': this.set('selectedFromDate', moment(date).add(-1*navigationInterval, 'h').toDate());
            break;
          default: this.set('selectedFromDate', moment(date).add(-1*navigationInterval, 'd').toDate());
        }
      }
    },
    nextNavigationClick(event) {
      const date = this.get('selectedToDate');

      if (date instanceof Date && !isNaN(date.valueOf())) {
        const navigationMode = this.get('pickerType'), navigationInterval = this.get('navigationInterval');

        // switch (navigationMode) {
        //   case 'year': this.set('selectedDate', moment(date).add(navigationInterval, 'y').toDate()); break;
        //   case 'month': this.set('selectedDate', moment(date).add(navigationInterval, 'M').toDate()); break;
        //   case 'date': this.set('selectedDate', moment(date).add(navigationInterval, 'd').toDate()); break;
        //   case 'hours': this.set('selectedDate', moment(date).add(navigationInterval, 'h').toDate()); break;
        //   case 'minutes': this.set('selectedDate', moment(date).add(navigationInterval, 'm').toDate()); break;
        //   case 'seconds': this.set('selectedDate', moment(date).add(navigationInterval, 's').toDate()); break;
        // }
        switch (navigationMode) {
          case 'year': this.set('selectedToDate', moment(date).add(navigationInterval, 'y').toDate()); break;
          case 'yearMonth': this.set('selectedToDate', moment(date).add(navigationInterval, 'M').toDate()); break;
          case 'date': this.set('selectedToDate', moment(date).add(navigationInterval, 'd').toDate()); break;
          case 'dateTime': this.set('selectedToDate', moment(date).add(navigationInterval, 'd').toDate()); break;
          case 'time': this.set('selectedToDate', moment(date).add(navigationInterval, 'h').toDate()); break;
          default: this.set('selectedToDate', moment(date).add(navigationInterval, 'd').toDate());
        }
      }
    },
    change(event) {
      this._raiseEvents('onChanged', {
        source: this,
        originalEvent: event
      });
    },
    onClosePicker() {
      if (this.$(':focus').length === 0) {
        this.$('input').focus();
      }
      this.set('isOpen', false);
    }
  }
});
