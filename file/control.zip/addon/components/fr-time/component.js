import Ember from 'ember';
import layout from './template';

export default Ember.TextField.extend({
  layout,

  type: 'time',

  classNames:['fr-time']
});
