import Ember from 'ember';
import layout from './template';
import Togglebase from '../fr-togglebase/component';
import ContextMenuMixin from '../../mixins/contextmenu-mixin';

// == ToggleButton
export default Togglebase.extend(ContextMenuMixin, {
  layout,
  tagName: 'div',
  classNameBindings: ['selectedClassName'],
  classNames: ['fr-togglebutton', 'btn', 'btn-smd', 'btn-default', 'btn-line', 'bti'],
  selectedClass: null,
  selectedClassName: Ember.computed('checked', 'selectedClass', function () {
    const checked = this.get('checked'), selectedClass = this.get('selectedClass');

    if (checked) {
      if (!Ember.isNone(selectedClass)) {
        return selectedClass;
      }
      return null;
    }

    return 'off';
  }).readOnly(),
  /*
  getClassNames: Ember.computed('checked', function () {
    return this.get('checked') === true ? '' : 'off';
  }).readOnly(),
  */
  _onCheckChanged() {
    this._onRaiseChanged(this.get('checked'));
  },
  click() {
    this.set('checked', !this.get('checked'));
  },
  didInsertElement() {
    this._super(...arguments);

    if (Ember.isEmpty(this.id)) {
      this.id = this.elementId;
    }
  }
});