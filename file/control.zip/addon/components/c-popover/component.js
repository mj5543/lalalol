import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';

export default Control.extend({
  layout,
  classNames: ['c-popover'],
  isOpen: false,
  showCloseButton: true,
  placement: 'bottom',
  placeInArea: false,
  width: null,
  height: null,
  top: 0,
  left: 0,
  destroyOnHide: true,
  hasLoaded: false,
  useParentWormhole: true,
  _hide: false,
  _hasOpen: false,
  _hasTitle: Ember.computed('title', function () {
    return !Ember.isEmpty(this.get('title'));
  }),
  _containerClassName: Ember.computed('_hide', '_hasTitle', function () {
    return `c-popover-container ${this.get('_hide') ? 'hide' : ''} ${this.get('_hasTitle') ? 'has-title' : ''}`;
  }),
  _targetAttachment: Ember.computed('placement', function () {
    const placement = this.get('placement');

    if (placement === 'top') {
      return 'top left';
    } else if (placement === 'left') {
      return 'top left';
    } else if (placement === 'right') {
      return 'top right';
    }

    return 'bottom left';
  }),
  _attachment: Ember.computed('placement', function () {
    const placement = this.get('placement');

    if (placement === 'top') {
      return 'bottom left';
    } else if (placement === 'left') {
      return 'top right';
    } else if (placement === 'right') {
      return 'top left';
    }

    return 'top left';
  }),
  _htmlSafeContentStyle: Ember.computed('width', 'height', function () {
    let style = '';

    if (!Ember.isNone(this.get('width'))) {
      style += `width:${this.get('width')}px;`;
    }
    if (!Ember.isNone(this.get('height'))) {
      style += `height:${this.get('height')}px;`;
    }
    if (!Ember.isEmpty(style)) {
      return Ember.String.htmlSafe(style);
    }
  }),
  _observedProperty: Ember.computed('isOpen', 'destroyOnHide', function () {
    if (this.get('isOpen')) {
      if (!this.get('_hasOpen')) {
        Ember.run.once(this, '_changeVisible', false);
        this.set('_hasOpen', true);
      } else {
        Ember.run.once(this, '_changeVisible', false);
        if (this.get('hasLoaded')) {
          Ember.run.once(this, '_onShown');
        }
      }
    } else {
      Ember.run.once(this, '_changeVisible', true);
      if (this.get('destroyOnHide')) {
        this.set('_hasOpen', false);
      }
      if (this.get('hasLoaded')) {
        Ember.run.once(this, '_onHidden');
      }
    }
  }),
  didInsertElement() {
    this._super(...arguments);
    this.set('hasLoaded', true);
  },
  _onShown() {
    this._raiseEvents('onShown', { 'source': this, 'isOpened': true });
  },
  _onHidden() {
    this._raiseEvents('onHidden', { 'source': this, 'isOpened': false });
  },
  _changeVisible(hide) {
    this.set('_hide', hide);
  },
  actions: {
    mouseDownToOutside(event) {
      if (this.element && !this.element.contains(event.target) &&
      !document.getElementById('max-wormhole-parent').contains(event.target)) {
        this.set('isOpen', false);
      }
    },
    closePopover() {
      this.set('isOpen', false);
    },
    togglePopover() {
      this.toggleProperty('isOpen');
    },
    containerShown() {
      this._raiseEvents('onShown', { 'source': this, 'isOpened': true });
    },
  }
});