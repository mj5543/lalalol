import Ember from 'ember';
import Selector from '../fr-selector/component';
import ContextMenuMixin from '../../mixins/contextmenu-mixin';
import { v4 } from 'uuid';

// ComboBox
export default Selector.extend(ContextMenuMixin, {
  attributeBindings: ['autofocus'],
  layout: Ember.computed(function () {

    let _itemTemplate = this.get('itemTemplate');
    let _headerTemplate = this.get('headerTemplate');

    if (Ember.isEmpty(_itemTemplate)) {
      _itemTemplate = "<span class='alink'>{{ get item displayMemberPath }}</span>";
    }

    if (Ember.isEmpty(_headerTemplate)) {

      if (this.get('useSelectedValue') === true) {
        _headerTemplate = '{{ watchSelectedValue }}';
      } else {
        _headerTemplate = '{{ watchSelectedItem }}';
      }
    }

    const template = `<div class='wrap-drop drop-down'>
                    {{#if useHeaderTemplate}}
                      <div  tabindex={{tabindex}} class='fr-combobox-toggle btn btn-md btn-basic btn-line'><span class='fr-combobox-header'>{{yield (hash headerTemplate=(component 'fr-combobox-header'  ) )}}</span></div>
                    {{else}}
                      <div  tabindex={{tabindex}} class='fr-combobox-toggle btn btn-md btn-basic btn-line'><span class='fr-combobox-header'>${_headerTemplate}</span></div>
                    {{/if}}
                    </div>
                    {{#if isOpen }}
                      {{#fr-wormhole to=_destinationElementId}}
                        {{#fr-positioned-container targetElement=_targetElement targetAttachment='bottom left' attachment='top left'}}
                        {{#if useItemsPanelTemplate}}
                          {{yield (hash itemsPanelTemplate=(component 'fr-combobox-itemspanel' itemsSource=watchItemsSource tabindex='-1' classNames='list-box scrollbar-macosx' owner=this scrollIndex=_scrollIndex ) )}}
                        {{else}}
                        {{#fr-combobox-itemspanel isAutoScroll=true isDesignScroll=true tabindex='-1' classNames='drop-list scrollbar-macosx' panelId=panelId owner=this scrollIndex=_scrollIndex}}
                        <ul>
                            {{#if _hasLoaded }}
                              {{#each watchItemsSource as |item index|}}
                              <li data-val='{{get item selectedValuePath}}' onclick={{action 'onSelectAction' item}} class='fr-combobox-option'>
                              ${_itemTemplate}
                              </li>
                              {{/each}}
                            {{else}}
                              {{#if hasBlock}}
                                {{yield (hash comboboxitem=(component 'fr-comboboxitem' onrender=(action 'onRenderAction') ))}}
                              {{/if}}
                            {{/if}}
                          </ul>
                          {{/fr-combobox-itemspanel}}
                          {{/if}}
                        {{/fr-positioned-container}}
                      {{/fr-wormhole}}
                    {{/if}}` ;

    return Ember.HTMLBars.compile(template);
  }),
  tagName: 'div',
  classNames: ['fr-combobox'],
  _destinationElementId: 'fr-wormhole-container',
  _targetElement: null,
  _scrollIndex: 0,
  _hasLoaded: false,
  //== Public Properties =====================================
  panelId: null,
  disabled: false,
  editable: false,
  minDropDownHeight: 160,
  maxDropDownHeight: 350,
  dropDownHeight: 180,
  itemTemplate: '',
  headerTemplate: '',
  isOpen: true,
  isTyping : false,
  staysOpenOnEdit: false,
  displayMemberPath: 'content',
  selectedValuePath: 'value',
  searchWord:'',
  useSelectedValue: false,
  useHeaderTemplate: false,
  useItemsPanelTemplate: false,
  itemsSource: null,
  itemsPanelTemplate: null,
  dropDownClosed: null,
  dropDownOpened: null,
  // == Computed Properties ==================================
  watchItemsSource: Ember.computed('itemsSource.[]', function () {
    return this.get('itemsSource');
  }).readOnly(),
  watchSelectedItem: Ember.computed('selectedItem', 'itemsSource.[]', function () {
    if(this.get('editable') && this.isTyping) {
      this.isTyping = false;

      return this.searchWord;
    }

    const _val = this._getValue();
    const _item = this._watchComputed(_val);

    if (Ember.isEmpty(_item)) {
      return '';
    } else {

      this.set('selectedValue', _val);
      this._onRaiseEvents(_item);
    }

    return Ember.get(_item, this.displayMemberPath);

  }).readOnly(),
  watchSelectedValue: Ember.computed('selectedValue', 'itemsSource.[]', function () {
    if(this.get('editable') && this.isTyping) {
      this.isTyping = false;

      return this.searchWord;
    }

    const _val = this._getValue();
    const _item = this._watchComputed(_val);

    if (Ember.isEmpty(_item)) {
      return '';
    } else {
      this.set('selectedItem', _item);
      this._onRaiseEvents(_item);
    }

    return Ember.get(_item, this.displayMemberPath);

  }).readOnly(),
  // == Private Methods ============================================
  _onRaiseEvents(item) {
    // Auto Complete에서 editable인 경우 이벤트가 발생되면 안됨
    if (this.get('editable') === false) {
      this._raiseEvents('selectedChanged', { 'source': this, 'data': item });
    }
  },
  _onDocumentMousDown(e) {

    if (this.get('isDestroyed') || this.get('isDestroying')) {
      Ember.$('body').off('mousedown.combobox');

      return;
    }
    let parentId = '';

    if (!Ember.isEmpty(e.target)) {

      if (this.get('editable') === true) {
        parentId = Ember.$(e.target).closest('.fr-autocomplete').eq(0).attr('id');
      } else {
        parentId = Ember.$(e.target).closest('.fr-combobox').eq(0).attr('id');
      }
    }

    if (this.$().attr('id') === parentId) {
      return;
    }

    if (Ember.$(e.target).closest('.fr-combobox-options').length === 1) {
      e.preventDefault();

      return;
    }

    this._onDropDownClosed();
  },
  _watchComputed(value) {
    const _item = this._findItem(value);

    return _item;
  },
  _findItem(value) {

    if (Ember.isEmpty(value)) {
      return null;
    }

    if (Ember.isEmpty(this.get('itemsSource'))) {
      return null;
    }

    return this.get('itemsSource').findBy(this.selectedValuePath, value);
  },
  _getValue() {
    if (this.useSelectedValue === true) {
      return this.get('selectedValue');
    }

    if (!Ember.isEmpty(this.selectedItem)) {
      return Ember.get(this.selectedItem, this.selectedValuePath);
    }

    return null;
  },
  _onDropDownToggle() {

    if (this.get('isOpen') === false) {
      this._onDropDownOpened();
    } else {
      this._onDropDownClosed();
    }
  },
  _onDropDownClosed() {
    this.set('isOpen', false);
    Ember.$('body').off('mousedown.combobox');
    this._raiseEvents('dropDownClosed', { source: this });
  },
  _onDropDownOpened() {
    Ember.$('body').on('mousedown.combobox', this._onDocumentMousDown.bind(this));
    this.set('isOpen', true);
    this._raiseEvents('dropDownOpened', { source: this });
    //this.set('_scrollIndex', 0);
    // Ember.run.debounce(this, function () {
    //   // TODO ASH : List가 열릴때 마다 새로 생성됨으로 이전 상태 값을 스크롤 위치와 선택된 스타일을 지정해줘야 한다.
    //   // 웜홀이 위치를 잡기 위해 여러번 랜더링 되기 떄문에 DidRender에서 구현하지 않았다. 웜홀의 EndedEvent를 생성해서 개선해야 할 듯 하다.
    //   if(Ember.isEmpty(this.selectedItem)){
    //     return;
    //   }
    //   let index = "";
    //   if(this.useSelectedValue){
    //     index = this.itemsSource.indexOf(this.itemsSource.findBy(this.get('selectedValuePath'), this.selectedValue))
    //   }else{
    //     index = this.itemsSource.indexOf(this.itemsSource.findBy(this.get('displayMemberPath'), this.selectedItem[this.get('displayMemberPath')]))
    //   }

    //   this.set('_scrollIndex', index);
    //   Ember.$('.fr-combobox-options').find('.fr-combobox-option').eq(index).addClass('select')
    // }, 300);
  },


  _onkeydown(e) {
    const keyCode = e.which;

    if (keyCode === 9) {
      return;
    }

    const hasText = this.$(e.target).is(':text');

    if (keyCode === 40 && this.get('isOpen') === false) {
      this._onDropDownOpened();
      e.stopImmediatePropagation();
      e.preventDefault();

      return;
    }

    const options = Ember.$('.fr-combobox-options');

    let _active = options.find('.select');

    if (!hasText) {
      e.stopImmediatePropagation();
      e.preventDefault();
    }

    const lis = options.find('.fr-combobox-option');

    if (keyCode === 40) {
      const curIndex = lis.index(_active);

      if (curIndex === lis.length - 1) {
        e.stopImmediatePropagation();
        e.preventDefault();

        return;
      }
    }

    switch (keyCode) {
      case 13:
        if (!Ember.isEmpty(_active)) {
          _active.trigger('click');
        } else if (hasText) {
          this._onTextCommit(e);
        }
        return;
      case 27:
        this._onDropDownClosed();
        return;
      case 38:
        lis.removeClass('select');

        if (Ember.isEmpty(_active)) {
          return;
        }

        const curIndex = lis.index(_active);

        if (curIndex === 0) {
          this._onDropDownClosed();
          this.$('.fr-combobox-button').focus();
          e.stopImmediatePropagation();
          e.preventDefault();
          return;
        }

        _active.prev().addClass('select');

        break;
      case 40:
        lis.removeClass('select');

        if (Ember.isEmpty(_active)) {
          _active = options.find('.on');

          if (_active.length === 0) {
            _active = lis.eq(0);
          }

        } else {
          _active = _active.next();
        }

        _active.addClass('select');
        break;
      default:
        return;
    }
    const index = lis.index(_active);

    this.set('_scrollIndex', index);
    e.stopImmediatePropagation();
    e.preventDefault();

  },
  _onSelected(item){

    if ( this.get('editable') === true) {
      this._onValueUpdate(item);
    } else {
      if (this.useSelectedValue === true) {
        this.set('selectedValue', Ember.get(item, this.selectedValuePath));
      } else {
        this.set('selectedItem', item);
      }
      this._onDropDownClosed();
    }
  },
  // == Life Cycle =========================================================
  click(e) {
    //e.stopImmediatePropagation();
    e.preventDefault();

    if (this.get('editable') === false) {
      this._onDropDownToggle();
    }
  },
  init() {
    this._super(...arguments);

    this.set('panelId', v4());

    if (Ember.isEmpty(this.get('itemsSource'))) {
      this.set('itemsSource', Ember.A([]));
    }
  },
  didInsertElement() {
    this._super(...arguments);

    if (this.get('editable') === false) {
      this.$().on('keydown.combobox', this._onkeydown.bind(this));
      this.$().attr('tabindex', -1);
    }

    this.set('_targetElement', this.$().get(0));

    const wasValue = this.get('selectedValue');

    if (!Ember.isEmpty(wasValue)) {
      this.set('selectedValue', null);
      this.set('selectedValue', wasValue);
    }
    this.set('isOpen', false);

    const tabindex = this.$().attr('tabindex');

    if (Ember.isEmpty(tabindex)) {
      this.$().attr('tabindex', 1);
    }

    this.set('_hasLoaded', true);
  },
  didRender() {
    this._super(...arguments);

    const value = this._getValue();

    if (!Ember.isEmpty(value)) {
      Ember.$('#' + this.panelId).find('li[data-val="' + value + '"]').addClass('on');
    }

  },
  willDestroyElement() {
    this._super(...arguments);

    this.$().empty().off('keydown.combobox');
    Ember.$('body').off('mousedown.combobox');
  },
  // == Actions ============================================================
  actions: {
    onSelectAction(item, e) {

      if (Ember.isEmpty(e.target)) {
        return;
      }

      const touchobject = Ember.$(e.target);

      if (touchobject.is('checkbox', 'radio') === true) {
        return;
      }

      if (touchobject.parent().hasClass('fr-checkbox')) {
        return;
      }

      if (touchobject.parent().hasClass('fr-radio')) {
        return;
      }

      this._onSelected(item);
    },
    onRenderAction(item, isSelected) {
      this.itemsSource.pushObject(item);

      if (isSelected) {
        if (this.useSelectedValue === true) {
          this.set('selectedValue', Ember.get(item, this.selectedValuePath));
        } else {
          this.set('selectedItem', item);
        }
      }
    }
  }
});
