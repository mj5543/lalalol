import Ember from 'ember';
import Control from '../c-control/component';

export default Control.extend({
  contextMenuService: Ember.inject.service('contextmenuService'),
  contextMenuSource: null,
  onContextMenuOpen: null,

  _contextMenuGuid: Ember.computed.readOnly('componentGuid'),
  didInsertElement(){
    this._super(...arguments);
    this.$().parent().on(`contextmenu.c-contextmenu-${this.get('_contextMenuGuid')}`, function (event) {
      if (!Ember.isNone(this.get('contextMenuSource'))) {
        let args = { source: this, originalSource: null, originalEvent: event, dataItem: null, cancel: false };
  
        this._raiseEvents('onContextMenuOpen', args);
        if (!args.cancel) {
          this.get('contextMenuService').show({
            source: this,
            originalEvent: event,
            contextmenu: this.get('contextMenuSource'),
            args: args,
          });
        }
        args = null;
        event.stopPropagation();
      }
      event.preventDefault();
    }.bind(this));
  },
  willDestroyElement(){
    this.get('contextMenuService').close();
    this.$().parent().off(`contextmenu.c-contextmenu-${this.get('_contextMenuGuid')}`);
    this._super(...arguments);
  },
});