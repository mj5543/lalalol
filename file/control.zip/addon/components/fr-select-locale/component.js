import Ember from 'ember';
import layout from './template';
import GlobalServiceContainerMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';

export default Ember.Component.extend(GlobalServiceContainerMixin, {
    layout,    
    options: null,
    value:null,
    init(){
        this._super(...arguments);
        this.set('options', this.get('fr_I18nService').getSupportedLocales());
    },
    actions:{
        change(){
            let selectedEl = this.$('select')[0];
            let selectedIndex = selectedEl.selectedIndex;
            let options=this.get('options');
            let value = options[selectedIndex];
            this.get('fr_I18nService').changeLocale(value);   
        }
    }
});
