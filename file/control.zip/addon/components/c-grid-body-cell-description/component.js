import Ember from 'ember';
import ToolTipMixin from '../../mixins/tooltip-mixin';

export default Ember.Component.extend(ToolTipMixin, {
  tagName: 'label'
});