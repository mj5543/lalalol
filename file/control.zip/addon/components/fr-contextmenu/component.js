import Ember from 'ember';
import Control from '../fr-control/component';

export default Control.extend({
  contextmenuService : Ember.inject.service('contextmenuService'),
  contextmenuOpening : null,
  contextmenu : null,
  tagName: 'div',
  classNames: [''],
  _onContextMenu(e) {
    e.preventDefault() ;

    if ( this.$().parent().is(':disabled') ) {
      return false;
    }

    if ( this.$().parent().attr('disabled') == 'disabled' ) {
      return false;
    }

    let arg = {
      'source' : this,
      'dataItem' : null,
      'originalSource' : this,
      'originalEvent' : e,
      'cancel':false,
    } ;

    this._raiseEvents('contextmenuOpening', arg);

    if(arg.cancel === false) {
      this.get('contextmenuService').show( {
        source : this,
        originalEvent : e,
        contextmenu : this.contextmenu,
        arg : arg
      });
    }
  },
  didInsertElement(){
    this._super(...arguments);

    this.$().parent().on('contextmenu', this._onContextMenu.bind(this));
  },
  willDestroyElement(){
    this._super(...arguments);
    this.$().parent().off('contextmenu', this._onContextMenu);
  },
});