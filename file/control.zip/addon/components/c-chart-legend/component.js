import Ember from 'ember';
import layout from './template';
//import CHIS from 'framework/chis-framework';
import Control from '../c-control/component';
import GlobalServiceContainerMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

export default Control.extend(GlobalServiceContainerMixin, StatefulComponentMixin, {
  layout,

  tagName: 'g',
  classNames: ['c-chart-legend'],

  chartData: null,
  show: null,
  height: null,
  parentType: null,
  trace: null,
  width: null,
  xAxis: null,
  xScale: null,
  yAxis: null,
  yScale: null,
  setting: null,
  isValidData: null,

  _clickedLegendRect: null,
  // 현재 활성화된 y 축
  _currentYAxis: null,
  // 차트 데이터의 기본 y 축
  _defaultYAxis: null,
  _groupArrowImageSize: null,
  // 그룹 레전 일 경우에 그룹명까지 포함된 데이터
  _groupLegend: null,
  _groupLegendWidth: null,
  _isCollapsed: null,
  _legendTextSize: null,
  _lineLeading: null,
  _onlyOne: null,
  _selectedLegendRect: null,
  _selectedLegendRectForNormal: null,
  _selectedLegendRectForYAxis: null,
  _selectedLegendSymbol: null,
  _symbolMulple: null,
  _utilityService: null,
  _lineHeight: null,
  _browserType: null,
  _legendTextColor: null,
  _scrollGap: null,

  _chartData: Ember.computed.alias('chartData').readOnly(),
  _parentType: Ember.computed.alias('parentType').readOnly(),
  _trace: Ember.computed.alias('trace').readOnly(),
  _width: Ember.computed.alias('width').readOnly(),
  _xAxis: Ember.computed.alias('xAxis').readOnly(),
  _xScale: Ember.computed.alias('xScale').readOnly(),
  _yAxis: Ember.computed.alias('yAxis').readOnly(),
  _yScale: Ember.computed.alias('yScale').readOnly(),
  _isValidData: Ember.computed.alias('isValidData').readOnly(),

  _height: Ember.computed('height', 'setting', function() {
    return this.get('height');
  }),
  _settingPaddingTop: Ember.computed('setting', function() {
    return this.get('setting').paddingTop;
  }),
  _settingPaddingRight: Ember.computed('setting', function() {
    return this.get('setting').paddingRight;
  }),
  _settingPaddingLeft: Ember.computed('setting', function() {
    return this.get('setting').paddingLeft;
  }),
  _settingPaddingBottom: Ember.computed('setting', function() {
    return this.get('setting').paddingBottom;
  }),
  _settingNormalOpacity: Ember.computed('setting', function() {
    return this.get('setting').normalOpacity;
  }),
  _settingDarkOpacity: Ember.computed('setting', function() {
    return this.get('setting').darkOpacity;
  }),
  _settingTransparentOpacity: Ember.computed('setting', function() {
    return this.get('setting').transparentOpacity;
  }),
  _settingGlyphiconPrefix: Ember.computed('setting', function() {
    return this.get('setting').glyphiconPrefix;
  }),

  onPropertyInit() {
    this._super(...arguments);
    this._logTrace('c-chart-legend.onPropertyInit()');

    this.setStateProperties(['_browserType']);

    this.set('_clickedLegendRect', false);
    this.set('_groupArrowImageSize', 20);
    this.set('_groupLegendWidth', 150);
    this.set('_isCollapsed', true);
    this.set('_legendTextSize', 13);
    this.set('_lineLeading', 10);
    this.set('_onlyOne', false);
    this.set('_selectedLegendRect', Ember.A());
    this.set('_selectedLegendRectForNormal', Ember.A());
    this.set('_selectedLegendRectForYAxis', Ember.A());
    this.set('_selectedLegendSymbol', Ember.A());
    this.set('_symbolMulple', 10);
    this.set('_utilityService', Ember.computed.alias('fr_Utility'));
    this.set('_lineHeight', 40);
    this.set('_browserType', this._getBrowserType());
    this.set('_legendTextColor', '#000000');
    this.set('_scrollGap', 2);
  },

  didInsertElement() {
    this._super(...arguments);
    this._logTrace('c-chart-legend.didInsertElement()');
  },

  didRender() {
    this._super(...arguments);
    this._logTrace('c-chart-legend.didRender()');
    if(Ember.isEmpty(this.get('_chartData')) === true) {
      return;
    }

    if(this.get('_isValidData') === false) {
      return;
    }

    this._removeEventListener();
    this._removeDom();

    this._initProperties();
    this._drawLegendRoot();
    this._drawLegendAll();

    const dataId = this.$().attr('data-id');

    this._raiseEvents('completeProcessingCB', dataId);
  },

  willDestroyElement() {
    this._super(...arguments);
    this._logTrace('c-chart-legend.willDestroyElement()');

    // 이벤트 리스너 해제
    this._removeEventListener();
    this._removeDom();

    // 클로저 해제
    this._logTrace = null;
    this._initProperties = null;
    this._removeEventListener = null;
    this._removeDom = null;
    this._drawLegendRoot = null;
    this._drawLegendAll = null;
  },

  _logTrace(text) {
    if(this.get('_trace') === true) {
      Ember.Logger.log(text);
    }
  },

  _getBrowserType() {
    const browserName = this.get('fr_GlobalSystemService').browserName;

    return browserName.toLowerCase();
  },

  _initProperties() {
    const chartData = this.get('_chartData');
    const isCollapsibleLegend = chartData.isCollapsibleLegend;

    if(isCollapsibleLegend === true) {
      this.set('_groupLegendWidth', parseInt(chartData.collapsibleLegendWidth));
      this.set('_isCollapsed', chartData.isCollapseLegendPane);
    }

    for(let i=0; i < chartData.series.length; i++) {
      const current = chartData.series[i];

      if(current.config.isSelectSymbol === true) {
        this.get('_selectedLegendSymbol').push(current.no);
      }

      if(current.config.isSelectLegend === true) {
        this.get('_selectedLegendRect').push(current.no);
      }
    }
  },

  _drawLegendRoot() {
    const parentType = this.get('_parentType');
    const className = parentType + ' legendRootG';
    const el = this.$().get(0);
    const legendTextColor = this.get('_legendTextColor');
    const legendRootG = d3.select(el)
      .attr('class', className)
      .attr('data-id', 'legendRoot');

    const isCollapsibleLegend = this.get('_chartData').isCollapsibleLegend;

    if(isCollapsibleLegend === true) {
      const imageSize = this.get('_groupArrowImageSize');
      const strokeWidth = 1;

      legendRootG.append('rect')
        .attr('class', 'legend-content-area')
        .attr('x', 0)
        .attr('y', 0)
        // [DESIGN] 120
        .attr('width', parseInt(this.get('_groupLegendWidth'), 10))
        .attr('height', parseInt(this.get('_height'), 10) - (strokeWidth * 2));

      // arrow image
      legendRootG.append('svg:foreignObject')
        .attr('x', -1)
        .attr('y', parseInt(this.get('_height')) / 2)
        // [COMPATIBILITY-EDGE]
        .attr('width', imageSize)
        .attr('height', imageSize)
        .attr('class', parentType + ' legendRootG foreignObject')
        .on('click', () => {
          this._logTrace('legendRootG.foreignObject.click');
          // toggle image / transition
          this._toggleCollapsibleLegend();
          d3.event.stopPropagation();
        })
        .append('xhtml:i')
        // symbolSize 고정 25 -> 20 => x => -1
        .attr('class', parentType + ' legendRootGImage material-icons md-20')
        .style('color', legendTextColor)
        .text('chevron_left');


      // transform 설정 - 열림 상태 설정
      this._resetCollapsibleLegend();
    }
  },

  _toggleCollapsibleLegend() {
    const zero = 0;
    let x = 0;
    let glyphicon = '';
    const parentType = this.get('_parentType');
    const groupLegendWidth = this.get('_groupLegendWidth');
    let width = parseInt(this.get('width'));
    if(parentType === 'timeline') {
      width = groupLegendWidth;
    }
    const imageSize = this.get('_groupArrowImageSize');
    const duration = 300;


    if(this.get('_isCollapsed') === true) {
      // 670
      x = width - groupLegendWidth;
      glyphicon = 'chevron_right';
    } else {
      // 780
      x = width - imageSize;
      glyphicon = 'chevron_left';
    }

    const el = this.$().get(zero);

    if(parentType !== 'timeline') {
      d3.select(el)
        .transition()
        .attr('transform', 'translate(' + x + ', 0)')
        .duration(duration);
    }

    this.$('.' + parentType + '.legendRootGImage').text(glyphicon);
    this.set('_isCollapsed', !this.get('_isCollapsed'));
    this._raiseEvents('changeCollapsibleLegendCB', this.get('_isCollapsed'));
  },

  _resetCollapsibleLegend() {
    const zero = 0;
    let x = 0;
    let glyphicon = '';
    const parentType = this.get('_parentType');
    const groupLegendWidth = this.get('_groupLegendWidth');
    let width = parseInt(this.get('width'));
    if(parentType === 'timeline') {
      width = groupLegendWidth;
    }
    const imageSize = this.get('_groupArrowImageSize');

    if(this.get('_isCollapsed') === true) {
      // 780
      x = width - imageSize;
      glyphicon = 'chevron_left';
    } else {
      // 670
      x = width - groupLegendWidth;
      glyphicon = 'chevron_right';
    }

    const el = this.$().get(zero);

    if(parentType !== 'timeline') {
      d3.select(el)
        .attr('transform', 'translate(' + x + ', 0)');
    }


    this.$('.' + parentType + '.legendRootGImage').text(glyphicon);
  },

  _drawLegendAll() {
    const el = this.$().get(0);
    const chartData = this.get('_chartData');
    const isGroupLegend = chartData.isGroupLegend;
    const minusOne = -1;
    const one = 1;
    const zero = 0;

    this.set('_currentYPosition', -10);

    if(isGroupLegend) {
      const groupLegend = chartData.groupLegend;
      const tempLegend = Ember.A();
      const series = chartData.series;

      // series 정렬 by no
      series.sort(function(a, b) {
        if(a.no == b.no) {
          return zero;
        } else if (a.no < b.no) {
          return minusOne;
        } else {
          return one;
        }
      });

      // 그룹 라벨을 고려하여 순서 조정
      for(let i = 0; i < groupLegend.length; i++) {
        tempLegend.pushObject({
          groupNo: groupLegend[i].no,
          name: groupLegend[i].name
        });

        for(let j = 0; j < series.length; j++) {
          if(series[j].config.groupLegendNo === groupLegend[i].no) {
            tempLegend.pushObject(this.get('_utilityService').getCopy(chartData.series[j]) );
          }
        }
      }

      this.set('_groupLegend', tempLegend);
      this.set('_groupCount', 0);

      // 업데이트 된 데이터로 순차적으로 그리기
      for(let i = 0; i < tempLegend.length; i++) {
        const hasProperty = tempLegend[i].hasOwnProperty('groupNo');

        this._drawLegend(tempLegend[i], i, hasProperty);
      }
    } else {
      const series = chartData.series;
      for(let i = 0; i < series.length; i++) {
        this._drawLegend(series[i], i, false);
      }
    }
    // 스크롤 영역 설정
    const scrollHeight = d3.select(el).node().getBBox().height;
    d3.select(el)
      .select('.legend-content-area')
      .attr('height', scrollHeight);
    this.set('contentHeightCB', scrollHeight - this.get('_scrollGap'));
  },

  _drawLegend(series, index, isGroupName) {

    let gClassName = '';
    const parentType = this.get('_parentType');
    const glyphiconPrefix = this.get('_settingGlyphiconPrefix');
    let legendTextColor;
    const browserType = this.get('_browserType');
    let added = 0;
    let legendSymbolY = 0;
    let currentYPosition = this.get('_currentYPosition');
    let groupCount = this.get('_groupCount');
    const zero = 0;
    // const isCollapsibleLegend = this.get('_chartData').isCollapsibleLegend;

    if(isGroupName === true) {
      gClassName = parentType + ' legendG groupLegendG seriesGroup' + series.groupNo;

      if(browserType === 'edge' || browserType === 'firefox') {
        added = 38;
      } else {
        added = 30;
      }

      groupCount++;
      this.set('_groupCount', groupCount);

      added = added + (groupCount * 10);
    } else {
      gClassName = parentType + ' legendG series' + series.no;

      if(browserType === 'edge' || browserType === 'firefox') {
        added = 23;
      } else {
        added = 25;
      }
    }

    if(browserType === 'edge' || browserType === 'firefox') {
      legendSymbolY = 2;
    } else {
      legendSymbolY = 4;
    }

    currentYPosition = currentYPosition + added;
    this.set('_currentYPosition', currentYPosition);

    const el = this.$().get(zero);

    // legendG
    const legendG = d3.select(el)
    .append('g')
    .attr('data-seq', index)
    .attr('class', gClassName)
    .attr('transform', 'translate(' + 20 + ',' + currentYPosition + ')');

    if(isGroupName === true) {
      // groupLegendText
      legendG.append('text')
        .attr('x', 0)
        .attr('y', 0)
        .attr('fill', legendTextColor)
        .attr('class', 'chart groupLegendText seriesGroup' + series.groupNo)
        .attr('text-anchor', 'left')
        .style('dominant-baseline', 'central')
        .text(series.name);

      return;
    }

    // legendSymbol
    if(series.config.symbolType.startsWith(glyphiconPrefix)) {

      legendG.append('svg:foreignObject')
        .attr('x', 0)
        .attr('y', legendSymbolY)
        // [COMPATIBILITY-EDGE]
        .attr('width', 20)
        .attr('height', 20)
        .attr('class', parentType + ' foreignObject series' + series.no )
        .style('cursor', 'point')
        .on('click', () => {
          this._logTrace('legend.foreignObject.click');
          this._raiseEvents('selectLegendSymbolCB', series);
          d3.event.stopPropagation();
        })
        .append('xhtml:i')
        // symbolSize 고정
        .attr('class', parentType + ' legendSymbol series' + series.no + ' ' + glyphiconPrefix + ' md-10')
        .style('color', series.config.symbolColor)
        .text(series.config.symbolType.replace(glyphiconPrefix + '-',''));
    } else {
      // bar 차트는 square, pie 는 circle 표시
      legendG.append('path')
        // class 주의
        .attr('class', parentType + ' legendSymbol series' + series.no)
        .style('fill', series.config.symbolColor)
        .style('stroke', series.config.symbolColor)
        .style('cursor', 'point')
        .attr('d', d3.symbol().size(series.config.symbolSize * this.get('_symbolMulple')).type(series.config.symbolType))
        .on('click', () => {
          this._logTrace('legendSymbol.click');
          this._raiseEvents('selectLegendSymbolCB', series);
          d3.event.stopPropagation();
        });
    }

    let legendTextY = 0;

    if(browserType === 'edge' || browserType === 'firefox') {
      legendTextY = -2;
    }

    const group = legendG.append('g')
      .attr('class', 'chart legendText series' + series.no)
      .attr('transform', `translate(${20}, ${legendTextY})`)
      .on('mouseover', () => {
        this._logTrace('legendText.mouseover');
        this._raiseEvents('mouseoverSeriesCB', series);
        this.$('.' + parentType + '.legendCloseImage.series' + series.no).show();
        d3.event.stopPropagation();
      })
      .on('mouseout', () => {
        this._logTrace('legendText.mouseout');
        this._raiseEvents('mouseoutSeriesCB', series);
        this.$('.' + parentType + '.legendCloseImage.series' + series.no).hide();
        d3.event.stopPropagation();
      })
      .on('click', () => {
        this._logTrace('legendText.click');
        this.set('_clickedLegendRect', true);
        this._raiseEvents('selectLegendRectCB', series);
        d3.event.stopPropagation();
      });

    group.append('rect').style('fill', 'transparent').attr('height', 20).attr('width', parseInt(this.get('_groupLegendWidth')) -30);
    group.append('text').attr('y', 14).style('fill', legendTextColor).text(series.name);


    if(this.get('_chartData').readOnly !== true) {
      // legendCloseImage
      legendG.append('svg:foreignObject')
        .attr('class', parentType + ' legendCloseImage series' + series.no)
        .attr('x', 80)
        .attr('y', legendSymbolY)
        // [COMPATIBILITY-FIREFOX]
        .attr('width', 20)
        .attr('height', 20)
        .style('display', 'none')
        .on('mouseover', () => {
          this._logTrace('image.mouseover');
          this.$('.' + parentType + '.legendCloseImage.series' + series.no).show();
          this._raiseEvents('mouseoverSeriesCB', series);
          d3.event.stopPropagation();
        })
        .on('mouseout', () => {
          this._logTrace('image.mouseout');
          this.$('.' + parentType + '.legendCloseImage.series' + series.no).hide();
          this._raiseEvents('mouseoutSeriesCB', series);
          d3.event.stopPropagation();
        })
        .on('click', () => {
          this._logTrace('closeImage.click');

          this._raiseEvents('clickRemoveSeriesCB', series.no);
          d3.event.stopPropagation();
        })
        .append('xhtml:i')
        // md-15
        .attr('class', glyphiconPrefix + ' md-13')
        // 디자인
        .style('color', legendTextColor)
        .text('close');
    }
  },

  _removeEventListener() {
    const parentType = this.get('_parentType');
    const mouseOverOut = [
      '.' + parentType + '.legendText',
      '.' + parentType + '.legendCloseImage'
    ];
    const click = [
      '.' + parentType + '.legendText',
      '.' + parentType + '.legendCloseImage',
      '.' + parentType + '.legendRootG.foreignObject',
      '.' + parentType + '.foreignObject',
      '.' + parentType + '.legendSymbol'
    ];

    const el = this.$().get(0);
    const thisObj = d3.select(el);

    for(let i=0; i < mouseOverOut.length; i++) {
      thisObj.selectAll(mouseOverOut[i]).on('mouseover', null).on('mouseout', null);
    }

    for(let i=0; i < click.length; i++) {
      thisObj.selectAll(click[i]).on('click', null);
    }
  },

  _removeDom() {
    this.$().children().remove();
  },

  actions: {
  },

});