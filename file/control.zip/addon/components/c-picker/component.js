import Ember from 'ember';
import moment from 'moment';
import layout from './template';
import ValidationControl from '../c-validationcontrol/component';
// import DatePickerMixin from '../../mixins/datepicker-mixin';

export default ValidationControl.extend({
  layout,
  classNames: ['c-picker', 'c-inp-txt'],
  tagName: 'div',
  attributeBindings: ['_watchIsOpen:data-calendar-open'],
  classNameBindings: ['navigationVisibility:inp-control'],
  useParentWormhole: true,
  i18nService: Ember.inject.service('i18n-service'),
  //public properties
  style: null,
  pickerType: 'date',
  displayDate: null,
  selectedDate: null,
  selectedTime: null,
  oldSelectedDate: null,
  openSelectedDate: null,
  patternDays: null,
  eventDays: null,
  holidays: null,
  disabledDates: null,
  minDate: null,
  maxDate: null,
  navigationMode: 'date',
  navigationInterval: 1,
  showCalendarButton: true,
  showNavigation: false,
  showTodayNavigation: false,
  enableGotFocusAutoSelect: true,
  tabindex: null,
  placeHolder: null,
  disabled: false,
  readOnly: false,
  required: false,
  showValidationRequired: false,
  showValidationSuccess: false,
  showValidationError: false,
  externalErrorMessage: null,
  validationRules: null,
  istimeEmbed: false,
  toDay: null,
  toDayName: null,
  isToday: false,
  isTimepadEmbeded: true,
  targetAttachment: 'bottom left',
  attachment: 'top left',
  placeInArea: false,
  showTodayButton: false,

  hasLoaded: false,
  _timer: 0,
  _baseTime: null,
  _maskinput: null,
  _currentTime: null,
  _notReadOnly: Ember.computed.not('readOnly'),
  _showClearButtonAndNotReadOnly: Ember.computed.and('showClearButton', '_notReadOnly'),
  _pickerFormats: Ember.computed('pickerType', function () {
    return this._createFormat(this.get('i18nService.currentLocale'), this.get('pickerType'));
  }).readOnly(),
  _currentTime: Ember.computed('_timer', '_baseTime', function () {
    if (!this.get('isDestroying') && !this.get('isDestroyed')) {
      let _baseTime = this.get('_baseTime'), _timer = this.get('_timer');

      if (Ember.isNone(_baseTime) || 180 < _timer) {
        _baseTime = moment(this.get('co_CommonService').getNow());
        this.set('_baseTime', _baseTime);
        _timer = 0;
      }
      Ember.run.later(this, function () {
        if (!this.get('isDestroying') && !this.get('isDestroyed')) {
          _baseTime.add(1, 'seconds');
          this.set('_timer', _timer + 1);
        } else {
          _baseTime = null;
          _timer = null;
        }
      }, 1000);

      return _baseTime.toDate();
    }
  }).readOnly(),
  _watchIsOpen: Ember.computed('isOpen', function () {
    if(this.get('hasLoaded')) {
      Ember.run.once(this, '_isOpenChanged');
    }

    return this.get('isOpen');
  }).readOnly(),
  showCalendar: Ember.computed('pickerType', function () {
    const pickerType = this.get('pickerType');
    Ember.run.once(() => this._setCalendarMode(pickerType));

    return pickerType === 'date'
      || pickerType === 'dateTime'
      || pickerType === 'dateLongTime'
      || pickerType === 'year'
      || pickerType === 'yearMonth';
  }),
  showTimepad: Ember.computed('pickerType', function () {
    const pickerType = this.get('pickerType');

    return pickerType === 'dateTime'
      || pickerType === 'dateLongTime'
      || pickerType === 'time'
      || pickerType === 'longTime';
  }),
  onlyTimepad: Ember.computed('pickerType', function () {
    const pickerType = this.get('pickerType');

    if(pickerType === 'time' || pickerType === 'dateLongTime') {
      this.set('isTimepadEmbeded', false);
    } else {
      this.set('isTimepadEmbeded', true);
    }

    return pickerType === 'time' || pickerType === 'longTime';
  }),
  _onlyDateTime: Ember.computed('pickerType', function () {
    const pickerType = this.get('pickerType');

    return pickerType === 'dateTime';
  }),
  _navigationInterval: Ember.computed('navigationInterval', function () {
    const interval = this.get('navigationInterval');

    return interval;
  }),
  internalValue: Ember.computed('selectedDate', '_datetimeOptions', {
    get () {
      if (this.get('selectedDate') instanceof Date && !isNaN(this.get('selectedDate').valueOf())) {
        return Inputmask.unmask(moment(this.get('selectedDate')).format('YYYY-MM-DD HH:mm:ss'), {
          alias: 'datetime',
          inputFormat: 'yyyy-mm-dd HH:MM:ss',
          outputFormat: this.get('_datetimeOptions').inputFormat,
        });
      }
    },
    set (key, value) {
      return value;
    },
  }),
  _datetimeOptions: Ember.computed('pickerType', 'minDate', 'maxDate', function () {
    const formats = this.get('_pickerFormats'), minDate = this.get('minDate'), maxDate = this.get('maxDate');
    let min = null, max = null;

    if (this._isDateInstance(minDate)) {
      min = Inputmask.unmask(moment(minDate).format('YYYY-MM-DD HH:mm:ss'), { alias: 'datetime', inputFormat: 'yyyy-mm-dd HH:MM:ss', outputFormat: formats.inputFormat });
    }
    if (this._isDateInstance(maxDate)) {
      max = Inputmask.unmask(moment(maxDate).format('YYYY-MM-DD HH:mm:ss'), { alias: 'datetime', inputFormat: 'yyyy-mm-dd HH:MM:ss', outputFormat: formats.inputFormat });
    }
    if (this.$ && this.$('input').inputmask) {
      this.$('input').inputmask('remove');
      this.$('input').val('');
    }

    return { alias: 'datetime', min: min, max: max, inputFormat: formats.inputFormat, outputFormat: formats.outputFormat, };
  }),
  observedProperty1: Ember.computed('_datetimeOptions', function () {
    Ember.run.scheduleOnce('afterRender', this, '_initInputmask');
  }),
  observedProperty2: Ember.computed('selectedDate', function () {
    Ember.run.once(this, '_selectedDateChanged');
  }),
  didInsertElement() {
    this._super(...arguments);
    this.set('hasLoaded', true);
    this.set('toDayName', this.get('fr_I18nService').getRegional().dayNamesShort[this.get('co_CommonService').getNow().getDay()]);
  },
  willDestroyElement() {
    this.$('input').each(function (idx, el) { if (el.inputmask) { el.inputmask.remove(); } });
    this._super(...arguments);
  },
  _createFormat(lang, picker) {
    let inputFormat, outputFormat, momentFormat;

    if (lang === 'ko-kr') {
      switch (picker) {
        case 'date':
          inputFormat = 'yyyy-mm-dd';
          outputFormat = 'yyyy-mm-dd';
          momentFormat = 'YYYY-MM-DD';
          break;
        case 'dateTime':
          inputFormat = 'yyyy-mm-dd HH:MM';
          outputFormat = 'yyyy-mm-dd HH:MM';
          momentFormat = 'YYYY-MM-DD HH:mm';
          break;
        case 'time':
          inputFormat = 'HH:MM';
          outputFormat = 'HH:MM';
          momentFormat = 'HH:mm';
          break;
        case 'year':
          inputFormat = 'yyyy';
          outputFormat = 'yyyy';
          momentFormat = 'YYYY';
          break;
        case 'yearMonth':
          inputFormat = 'yyyy-mm';
          outputFormat = 'yyyy-mm';
          momentFormat = 'YYYY-MM';
          break;
      }
    } else {
      switch (picker) {
        case 'date':
          inputFormat = 'mm/dd/yyyy';
          outputFormat = 'yyyy-mm-dd';
          momentFormat = 'MM/DD/YYYY';
          break;
        case 'dateTime':
          inputFormat = 'mm/dd/yyyy HH:MM';
          outputFormat = 'yyyy-mm-dd HH:MM';
          momentFormat = 'MM/DD/YYYY HH:mm';
          break;
        case 'time':
          inputFormat = 'HH:MM';
          outputFormat = 'HH:MM';
          momentFormat = 'HH:mm';
          break;
        case 'year':
          inputFormat = 'yyyy';
          outputFormat = 'yyyy';
          momentFormat = 'YYYY';
          break;
        case 'yearMonth':
          inputFormat = 'mm/yyyy';
          outputFormat = 'yyyy-mm';
          momentFormat = 'MM/YYYY';
          break;
      }
    }

    return { inputFormat: inputFormat, outputFormat: outputFormat, momentFormat: momentFormat };
  },
  /*_detectToday(selectedDate) {
    const now = this.get('co_CommonService').getNow();

    if (this._isDateInstance(selectedDate)) {
      return selectedDate;
    }
    if(
      selectedDate
      && selectedDate.getFullYear() === now.getFullYear()
      && selectedDate.getMonth() === now.getMonth()
      && selectedDate.getDate() === now.getDate()) {
      this.set('isToday', true);
    } else {
      this.set('isToday', false);
    }
  },*/
  _setCalendarMode(pickerType) {
    switch (pickerType) {
      case 'date':
        this.set('calendarMode', 'month');
        break;
      case 'dateTime':
        this.set('calendarMode', 'month');
        break;
      case 'year':
        this.set('calendarMode', 'decade');
        break;
      case 'yearMonth':
        this.set('calendarMode', 'year');
        break;
      default:
        this.set('calendarMode', 'month');
    }
  },
  _isDateInstance(date) {
    return date instanceof Date && date.valueOf() && !Number.isNaN(date.valueOf());
  },
  _initInputmask() {
    const date = this.get('selectedDate'), options = this.get('_datetimeOptions');

    Inputmask(options).mask(this.$('input'));
    if (this._isDateInstance(date)) {
      this.$('input').val(Inputmask.unmask(moment(date).format('YYYY-MM-DD HH:mm:ss'), { alias: 'datetime', inputFormat: 'yyyy-mm-dd HH:MM:ss', outputFormat: options.inputFormat }));
    }
  },
  _syncDataValue() {
    const formats = this.get('_pickerFormats');
    let changed = false;

    if (this.$('input').inputmask('isComplete')) {
      if (this.get('pickerType') === 'time') {
        if (!this._isDateInstance(this.get('selectedDate'))) {
          this.set('selectedDate', moment(`${moment(this.get('co_CommonService').getNow()).format('YYYY-MM-DD')} ${moment(this.get('internalValue'), formats.momentFormat).format(formats.momentFormat)}`, 'YYYY-MM-DD HH:mm').toDate());
          changed = true;
        } else if (moment(this.get('selectedDate')).format(formats.momentFormat) !== moment(this.get('internalValue'), formats.momentFormat).format(formats.momentFormat)) {
          this.set('selectedDate', moment(`${moment(this.get('selectedDate')).format('YYYY-MM-DD')} ${moment(this.get('internalValue'), formats.momentFormat).format(formats.momentFormat)}`, 'YYYY-MM-DD HH:mm').toDate());
          changed = true;
        }
      } else {
        if (!this._isDateInstance(this.get('selectedDate')) || moment(this.get('selectedDate')).format(formats.momentFormat) !== moment(this.get('internalValue'), formats.momentFormat).format(formats.momentFormat)) {
          this.set('selectedDate', moment(this.get('internalValue'), formats.momentFormat).toDate());
          changed = true;
        }
      }
    } else {
      if (!Ember.isNone(this.get('selectedDate'))) {
        this.set('selectedDate', null);
        changed = true;
      }
      Ember.run.schedule('afterRender', this, function () {
        if (!this.get('isDestroying') && !this.get('isDestroyed')) {
          this.$('input').val('');
        }
      });
    }
    if (changed) {
      this._selectedDateUpdated();
    }
  },
  _isOpenChanged() {
    this._raiseEvents('onIsOpenChanged', { 'source': this, 'selectedDate': this.get('selectedDate'), 'isOpen': this.get('isOpen') });
    if(!this.get('isOpen') && ((this._isDateInstance(this.get('openSelectedDate')) && !this._isDateInstance(this.get('selectedDate'))) || (!this._isDateInstance(this.get('openSelectedDate')) && this._isDateInstance(this.get('selectedDate'))) ||
    moment(this.get('openSelectedDate')).format('YYYY-MM-DD HH:mm:ss') !== moment(this.get('selectedDate')).format('YYYY-MM-DD HH:mm:ss'))) {
      this._selectedDateUpdated();
    }
    this.set('openSelectedDate', this.get('selectedDate'));
  },
  _calendarOpen() {
    this.set('isOpen', true);
  },
  _constructorDateParam(date) {
    if (this._isDateInstance(date)) {
      const md = moment(date);

      return { source: this, selectedDate: date, Year: md.get('year'), Month: md.get('month'), Date: md.get('date'), Day: md.get('day'), Hour: md.get('hour'), Minute: md.get('minute') };
    } else {
      return { source: this, selectedDate: date, Year: null, Month: null, Date: null, Day: null, Hour: null, Minute: null };
    }
  },
  _selectedDateChanged() {
    this.set('_internalValue', this._isDateInstance(this.get('selectedDate')));
    if (this.get('hasLoaded')) {
      const params = this._constructorDateParam(this.get('selectedDate'));

      this._raiseEvents('onSelectionChanged', params);
    }
  },
  _selectedDateUpdated() {
    const params = this._constructorDateParam(this.get('selectedDate'));

    this._raiseEvents('onDateUpdated', params);
  },
  /*_complexTime({date, time}) {
    if(date && time) {
      const newDate = new Date(
        date.getFullYear(),
        date.getMonth(),
        date.getDate(),
        time.getHours(),
        time.getMinutes(),
        0);
      return newDate;
    } else if(date && !time) {
      return date;
    } else if(!date && time) {
      return time;
    } else {
      return false;
    }
  },*/
  /*_getPickerTypeDate({pickerType, date}) {
    if (Ember.isEmpty(date)) {
      return null;
    }

    switch (pickerType) {
      case 'date':
        return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 0, 0);
      case 'dateTime':
        return new Date(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), 0);
      case 'time':
        return new Date(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), 0);
      case 'year':
        return new Date(date.getFullYear(), 0, 1, 0, 0, 0);
      case 'yearMonth':
        return new Date(date.getFullYear(), date.getMonth(), 1, 0, 0, 0);
      default:
        return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 0, 0);
    }
  },
  _setDate(newValue) {
    this.set('selectedDate', newValue);
    this.set('displayDate', newValue);
    // this.set('selectedTime', newValue);
    if (!this._isDateInstance(newValue)) {
      this._maskinput.clear();
    }
  },*/
  _setNow(now) {
    const pickerType = this.get('pickerType');

    if (pickerType === 'year') {
      this.set('calendarMode', 'decade');
    } else if (pickerType === 'yearMonth') {
      this.set('calendarMode', 'year');
    } else {
      this.set('calendarMode', 'month');
    }
    this.set('selectedDate', moment(now).toDate());
    this.set('displayDate', moment(now).toDate());
  },
  /*_selectedDate() {
    const date = this._complexTime({
      date: this.get('selectedDate'),
      //time: this.get('selectedTime')
    });
    const newDate = this._getPickerTypeDate({
      pickerType: this.get('pickerType'),
      date: date
    });
    this._setDate(newDate);
    if (this.get('enableAutoClose') && (this.get('pickerType') === 'date' || this.get('pickerType') === 'year' || this.get('pickerType') === 'yearMonth')) {
      if (this.$(':focus').length === 0) {
        this.$('input').focus();
      }
      this.set('isOpen', false);
    }
  },*/
  focusIn(event) {
    if (this.get('enableGotFocusAutoSelect')) {
      this.$('input').select();
    }
    this._raiseEvents('onDateFocus', {
      source: this,
      originalEvent: event
    });
  },
  focusOut(event) {
    this._syncDataValue();
    this._raiseEvents('onFocusOut', {
      source: this,
      originalEvent: event
    });
  },
  keyPress(event) {
    if (event.keyCode === 13) {
      event.preventDefault();
      this._syncDataValue();
    }
    this._raiseEvents('onDateKeyDown', {
      source: this,
      originalEvent: event
    });
  },
  actions: {
    currentTimeDoubleClick() {
      this.set('isOpen', false);
    },
    onTodayClickAction() {
      this._setNow(this.get('co_CommonService').getNow());
    },
    calendarDoubleClick(e) {
      const pickerType = this.get('pickerType');
      if (this.$(':focus').length === 0) {
        this.$('input').focus();
      }
      switch(e) {
        case 'year':
          if (pickerType === 'year') {
            this.set('isOpen', false);
          }
          break;
        case 'month':
          if (pickerType === 'yearMonth') {
            this.set('isOpen', false);
          }
          break;
        case 'date':
          this.set('isOpen', false);
          break;
        default: this.set('isOpen', true);
      }
    },
    searchMouseDown(event) {
      event.preventDefault();
      if (this.$(':focus').length === 0) {
        this.$('input').focus();
      }
      this.toggleProperty('isOpen');
      this.set('toDay', this.get('co_CommonService').getNow());
    },
    delMouseDown(event) {
      event.preventDefault();
      this.set('internalValue', '');
    },
    mouseDownCancel(event) {
      event.preventDefault();
    },
    mouseDownActionCancel(event) {
      event.originalEvent.preventDefault();
    },
    mouseDownToOutside(event) {
      if (this.element && !this.element.contains(event.target) &&
      !document.getElementById('max-wormhole-parent').contains(event.target)) {
        this.set('isOpen', false);
      }
    },
    preNavigationClick() {
      const date = this.get('selectedDate');

      if (date instanceof Date && !isNaN(date.valueOf())) {
        const navigationMode = this.get('pickerType'), navigationInterval = this.get('navigationInterval');

        switch (navigationMode) {
          case 'year':
            this.set('selectedDate', moment(date).add(-1*navigationInterval, 'y').toDate());
            break;
          case 'yearMonth':
            this.set('selectedDate', moment(date).add(-1*navigationInterval, 'M').toDate());
            break;
          case 'date':
            this.set('selectedDate', moment(date).add(-1*navigationInterval, 'd').toDate());
            break;
          case 'dateTime':
            this.set('selectedDate', moment(date).add(-1*navigationInterval, 'd').toDate());
            break;
          case 'time':
            this.set('selectedDate', moment(date).add(-1*navigationInterval, 'h').toDate());
            break;
          default:
            this.set('selectedDate', moment(date).add(-1*navigationInterval, 'd').toDate());
        }
      }
    },
    nextNavigationClick() {
      const date = this.get('selectedDate');

      if (date instanceof Date && !isNaN(date.valueOf())) {
        const navigationMode = this.get('pickerType'), navigationInterval = this.get('navigationInterval');

        switch (navigationMode) {
          case 'year':
            this.set('selectedDate', moment(date).add(navigationInterval, 'y').toDate());
            break;
          case 'yearMonth':
            this.set('selectedDate', moment(date).add(navigationInterval, 'M').toDate());
            break;
          case 'date':
            this.set('selectedDate', moment(date).add(navigationInterval, 'd').toDate());
            break;
          case 'dateTime':
            this.set('selectedDate', moment(date).add(navigationInterval, 'd').toDate());
            break;
          case 'time':
            this.set('selectedDate', moment(date).add(navigationInterval, 'h').toDate());
            break;
          default:
            this.set('selectedDate', moment(date).add(navigationInterval, 'd').toDate());
        }
      }
    },
    onChange(event) {
      this._raiseEvents('onChanged', {
        source: this,
        originalEvent: event
      });
    },
    onClosePicker() {
      if (this.$(':focus').length === 0) {
        this.$('input').focus();
      }
      this.set('isOpen', false);
    }
  },
});
