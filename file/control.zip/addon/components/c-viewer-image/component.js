import Ember from 'ember';
import layout from './template';
// import CHIS from 'framework/chis-framework';
import Control from '../c-control/component';

export default Control.extend({
  layout,
  tagName: 'div',
  classNames: ['c-viewer'],
  style: null,
  width: null,
  height: null,
  _radian: null,
  _canvas: null,
  _scale: null,
  _startX: null,
  _startY: null,
  _imageX: null,
  _imageY: null,
  _canMouseX: null,
  _canMouseY: null,
  _isDragging: null,
  _targetImg: null,
  _resizeRate: null,
  _y: null,
  _x: null,
  _zoomIntensity: Ember.computed('zoomIntensity', function() {
    return !Ember.isEmpty(this.get('zoomIntensity')) ? this.get('zoomIntensity') : 0.2;
    // return this.get('zoomIntensity')
  }).readOnly(),
  _itemSource: Ember.computed('itemSource', function() {
    const data = this.get('itemSource');
    if (!Ember.isEmpty(data)) {
      Ember.run.debounce(() => this._resetCanvas());
    }

    return data;
  }),
  onPropertyInit(){
    this._super(...arguments);
    this.setStateProperties(['']);
    if (this.hasState() === false) {
      this.set('_radian', 0);
      this.set('_scale', 1);
      this.set('_x', 1);
      this.set('_y', 1);
      this.set('_isDragging', false);
    }
  },

  didInsertElement(){
    this._super(...arguments);
    const canvas = document.querySelector('.canvas-viewer');
    this.set('_canvas', canvas);

    this.set('width', this.$().width());
    this.set('height', this.$().height());

    if (!Ember.isEmpty(this.get('_itemSource'))) {
      this._createCanvas();
    }

    canvas.addEventListener('mousedown', e => this._handleMouseDown(e));
    canvas.addEventListener('mousemove', e => this._handleMouseMove(e));
    canvas.addEventListener('mouseup', e => this._handleMouseUp(e));
    canvas.addEventListener('mouseout', e => this._handleMouseOut(e));
  },
  willDestroyElement() {
    // this.element.removeChild(this.get('_canvas'));
    this.set('_canvas', null);
    this.$().off('keydown');
    this._super(...arguments);
  },

  _createCanvas() {
    const canvas = this.get('_canvas') || document.querySelector('.canvas-viewer');
    const ctx = canvas.getContext('2d');
    const clientWidth = this.$().width();
    const clientHeight = this.$().height();

    if (!this.get('_canvas')) {
      this.set('width', clientWidth);
      this.set('height', clientHeight);
    }
    if (!this.get('_scale')) {
      this.set('_scale', 1);
    }

    const img = new Image();

    // img.crossOrigin = "Anonymous";

    img.onload = () => {
      // let rate = null;
      const rate = img.width > img.height ? img.height / img.width
        : img.width < img.height ? img.width / img.height
        : 1;
      const scale = img.width > clientWidth ? clientWidth / img.width
        : img.height > clientHeight ? clientHeight / img.height
        : this.get('_scale') || 1;
      ctx.save();
      ctx.clearRect(0, 0, clientWidth, clientHeight);
      ctx.translate(clientWidth / 2, clientHeight / 2);
      ctx.rotate(this.get('_radian') * Math.PI / 180);
      ctx.scale(this.get('_y'), this.get('_x'));
      // ctx.scale(scale, scale);

      img.width > clientWidth ? ctx.drawImage(img, -clientWidth/2, -clientWidth * rate / 2, clientWidth, clientWidth * rate)
        : img.height > clientHeight ? ctx.drawImage(img, -clientHeight * rate / 2, -clientHeight / 2, clientHeight * rate, clientHeight)
        : ctx.drawImage(img, -img.width / 2, -img.height / 2);
      ctx.restore();
      this.set('_targetImg', img);
      this.set('_resizeRate', scale);

      if (!this.get('_imageX') && img.width >= canvas.width) {
        this.set('_imageX', canvas.width / 2);
      }
      if (!this.get('_imageY') && img.height >= canvas.height) {
        this.set('_imageY', canvas.height / 2);
      }
    };

    img.src = Array.isArray(this.get('itemSource')) ? this.get('itemSource')[0].src : this.get('itemSource').src;
  },

  _getMousePosition(e) {
    const offsetX = this.get('_canvas').getBoundingClientRect().left;
    const offsetY = this.get('_canvas').getBoundingClientRect().top;
    this.set('_startX', parseInt(e.clientX - offsetX, 10));
    this.set('_startY', parseInt(e.clientY - offsetY, 10));
  },

  // _hitImage() {
  //   console.log('_hitImage', this.get('_startX'), this.get('_imageX'), this.get('_targetImg').width * this.get('_scale') * this.get('_resizeRate'));
  //   return (
  //     this.get('_startX') > this.get('_imageX')
  //     && this.get('_startX') < this.get('_imageX') + (this.get('_targetImg').width * this.get('_scale') * this.get('_resizeRate'))
  //     && this.get('_startY')  > this.get('_imageY')
  //     && this.get('_startY') < this.get('_imageY')  + (this.get('_targetImg').height * this.get('_scale') * this.get('_resizeRate'))
  //   );
  // },

  _handleMouseDown(e){
    // console.log('_handleMouseDown');
    this._getMousePosition(e);
    this.set('_isDragging', true);
  },

  _handleMouseUp(e) {
    // console.log('_handleMouseUp');
    this._getMousePosition(e);
    this.set('_isDragging', false);
    this.$().css('cursor', 'context-menu');
  },

  _handleMouseOut(e){
    // console.log('_handleMouseOut');
    this._getMousePosition(e);
    this.set('_isDragging', false);
  },

  _handleMouseMove(e){
    // this._getMousePosition(e);
    const canvas = this.get('_canvas');
    const ctx = canvas.getContext('2d');
    const scale = this.get('_scale');
    const resizeRate = this.get('_resizeRate') || 1;
    const startX = this.get('_startX');
    const startY = this.get('_startY');
    const img = this.get('_targetImg');

    // ctx.rotate(this.get('_radian') * Math.PI / 180);
    // console.log(this.get('_targetImg').width * scale * resizeRate, canvas.width);
    if (
        this.get('_isDragging')
        && (this.get('_targetImg').width * scale * resizeRate > canvas.width || this.get('_targetImg').height * scale * resizeRate > canvas.height)
        && !this.get('_radian')
      ) {

      this.$().css('cursor', 'grabbing');
      const offsetX = canvas.getBoundingClientRect().left;
      const offsetY = canvas.getBoundingClientRect().top;
      this.set('_canMouseX', parseInt(e.clientX - offsetX, 10));
      this.set('_canMouseY', parseInt(e.clientY - offsetY, 10));

      const dx = this.get('_canMouseX') - startX;
      const dy = this.get('_canMouseY') - startY;

      this._imageX += dx;
      this._imageY += dy;

      this.set('_imageX', Math.max(0, this.get('_imageX')));
      this.set('_imageY', Math.max(0, this.get('_imageY')));

      // console.log(this.get('_imageX'), this.get('_imageY'));

      this.set('_startX', this.get('_canMouseX'));
      this.set('_startY', this.get('_canMouseY'));

      ctx.clearRect(0,0, this.get('width'), this.get('height'));
      ctx.drawImage(
        img,
        this.get('_imageX') - ((img.width * scale * resizeRate) / 2),
        this.get('_imageY') - ((img.height * scale * resizeRate) / 2),
        img.width * scale * resizeRate,
        img.height * scale * resizeRate
      );
    }
  },

  _setScale(wheel) {
    const zoom = Math.exp(wheel * this.get('_zoomIntensity'));
    const scale = this.get('_scale') || 1;

    this.set('_x', scale * zoom);
    this.set('_y', scale * zoom);
    this.set('_scale', scale * zoom);
    this._createCanvas();
  },
  _resetCanvas() {
    this.set('_radian', 0);
    this.set('_scale', 1);
    this.set('_x', 1);
    this.set('_y', 1);
    this._createCanvas();
  },
  actions: {
    clearCanvas() {
      const ctx = this.get('_canvas').getContext('2d');
      const clientWidth = this.width;
      const clientHeight = this.height;
      this.set('itemSource', null);
      ctx.clearRect(0, 0, clientWidth, clientHeight);
      ctx.restore();
    },
    rotate(e) {
      // 90도 회전
      this.set('_radian', Number(this.get('_radian')) + e);
      this._createCanvas();
    },
    mouseWheel(e) {
      e.preventDefault();
      const wheel = e.deltaY < 0 ? 1 : -1;

      this._setScale(wheel);
    },
    // 캔버스 reset
    resetCanvas() {
      this._resetCanvas();
    },
    // 확대
    zoomIn() {
      this._setScale(1);
    },
    // 축소
    zoomOut() {
      this._setScale(-1);
    },
    // 100%
    zoomFit() {
      this.set('_scale', 1);
      this.set('_x', 1);
      this.set('_y', 1);
      this._createCanvas();
    },
    // 저장
    saveCanvas() {
      const canvasData = document.querySelector('.canvas-viewer').toDataURL('image/png');
      this._raiseEvents('onSaveImage', {
        source: this,
        imgBase64: canvasData
      });
    }
  }
});