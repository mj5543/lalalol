import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';

export default Control.extend({
  layout,
  tagName: 'button',
  classNames: ['c-buttondividers'],
  attributeBindings: ['tabindex'],
  useParentWormhole: true,
  //public properties
  style: null,
  title: null,
  content: null,
  maxDropDownWidth: null,
  maxDropDownHeight: null,
  showDropDownLoader: false,
  disabled: false,
  placeInArea: false,
  //public events
  onLoaded: null,
  onUnload: null,
  onClick: null,
  onFocusIn: null,
  onFocusOut: null,
  onKeyPress: null,
  onKeyUp: null,
  onKeyDown: null,
  click(event) {
    if (this.$(event.target).hasClass('content-area')) {
      this.toggleProperty('isOpen');
    } else {
      this._raiseEvents('onClick', {
        source: this,
        originalEvent: event
      });
    }
  },
  focusIn(event) {
    this._raiseEvents('onFocusIn', {
      source: this,
      originalEvent: event
    });
  },
  focusOut(event) {
    if (!this.get('element').contains(event.relatedTarget)) {
      const $relatedContainer = this.$(event.relatedTarget).closest('.c-positioned-container');

      if ($relatedContainer.length > 0) {
        let containerComponent = this._getComponent($relatedContainer);

        if (this.get('element').contains(Ember.get(containerComponent, 'ownerElement'))) {
          this.set('isOpen', false);
        }
        containerComponent = null;
      } else {
        this.set('isOpen', false);
      }
    }
    this._raiseEvents('onFocusOut', {
      source: this,
      originalEvent: event
    });
  },
  keyPress(event) {
    this._raiseEvents('onKeyPress', {
      source: this,
      originalEvent: event
    });
  },
  keyUp(event) {
    this._raiseEvents('onKeyUp', {
      source: this,
      originalEvent: event
    });
  },
  keyDown(event) {
    this._raiseEvents('onKeyDown', {
      source: this,
      originalEvent: event
    });
  },
  actions: {
    containerFocusOut(event) {
    },
  },
});