import Ember from 'ember';
import layout from './template';
import Control from '../fr-control/component';
import ContextMenuMixin from '../../mixins/contextmenu-mixin';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

// Accordion
export default Control.extend(ContextMenuMixin, StatefulComponentMixin, {
  layout,
  tagName: 'div',
  attributeBindings: ['getSelectedName:data-name'],
  classNames: ['fr-accordion', 'wrap-accordion'],
  // == Private Properties=====================================================
  _wasAccordionItem: null,
  _expandedItems: null,
  // == Public Properties======================================================
  selectedName: null,
  collapsible: true,
  // == Public Events =========================================================
  activate: null,
  beforeActivate: null,
  getSelectedName: Ember.computed('selectedName', function () {
    const nm = this.get('selectedName');

    if (Ember.isEmpty(nm)) {
      return '';
    }

    this.$('> div[name="' + nm + '"]').trigger('onactivate', {});

    return nm;
  }).readOnly(),
  _wasStateUpdate(newState) {
    if ( !Ember.isEmpty(this._wasAccordionItem)) {
      this._wasAccordionItem.$().removeClass('on');
      this._wasAccordionItem.$('.fr-accordionitem-content').slideUp(300);
      this._wasAccordionItem.set('hasExpanded', newState);
    }
  },
  _close(sender) {
    sender.$('.fr-accordionitem-content').slideUp(300);
  },
  _open(sender, duration = 300) {
    sender.$().addClass('on');
    sender.set('hasExpanded', true);
    sender.$('.fr-accordionitem-content').slideDown(duration);
    this._expandedItems.addObject(Ember.get(sender, 'getName'));
  },
  _activate(item) {
    const args = { 'source': this, 'originalSource': item, 'cancel': false };

    this._raiseEvents('beforeActivate', args);

    if (args.cancel === true) {
      return;
    }

    const isActive = item.$().is('.on');

    if (this.collapsible === true && isActive === true) {
      this._wasStateUpdate(false);
      this._expandedItems.clear();
    } else if (this.collapsible === true && isActive == false) {
      this._wasStateUpdate(false);
      this._expandedItems.clear();
      this._open(item);
    } else if (this.collapsible === false && isActive === true) {
      item.$().removeClass('on');
      item.set('hasExpanded', false);
      item.$('.fr-accordionitem-content').slideUp(300);
      this._expandedItems.removeObject(Ember.get(item, 'getName'));
    } else {
      this._open(item);
    }

    this._wasAccordionItem = item;

    this._raiseEvents('activate', { 'source': this, 'originalSource': item });
  },
  onPropertyInit() {
    this._super(...arguments);
    this.setStateProperties(['_expandedItems']);

    if (!this.hasState()) {
      this.set('_expandedItems', Ember.A([]));
    }
  },
  actions: {
    renderAction(sender) {
      if (this.get('_expandedItems').includes(Ember.get(sender, 'getName')) === true) {
        sender.set('hasContentLoaded', true);
        this._open(sender, 0);
      }
    },
    selectAction(sender) {
      if (this.get('selectedName') === Ember.get(sender, 'getName')) {
        this._activate(sender);

        return;
      }

      this.set('selectedName', Ember.get(sender, 'getName'));
    },
    activateAction(sender) {
      this._activate(sender);
    }
  }
});