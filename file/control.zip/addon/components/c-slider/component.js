import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';

export default Control.extend({
  layout,
  tagName: 'div',
  classNames: ['c-slider'],
  classNameBindings: ['orientation'],
  //attributeBindings: ['_watchValue:data-value'],
  labelPropertyPath: 'label',
  _oldTicks: null,

  _hasLoaded: false,
  /*
  _watchValue: Ember.computed('lowerValue', 'area', function () {
    Ember.run.once(() => this._makeSlider(this._getVal()));
    // this._makeSlider(this._getVal());
    return Number(this.get('lowerValue'));
  }),
  */
  watchTicks: Ember.computed('range', 'area', 'ticks', function () {
    Ember.run.scheduleOnce('afterRender', this, '_makeSlider');
  }).readOnly(),
  didInsertElement() {
    this._super(...arguments);
    this.set('_hasLoaded', true);
  },
  _detectEnable(val) {
    return val !== null && typeof val !== 'undefined';
  },
  _makeSlider() {
    const range = this.get('range'), sliderVal = Number(this.get('value')), low = Number(this.get('lowerValue')),
    high = Number(this.get('highValue')), area = Number(this.get('area')), ticks = this.get('ticks');
    let min, max, step = 1;

    if(ticks) {
      // const ticks = this.get('ticks');
      min = ticks[0].value;
      max = ticks[ticks.length - 1].value;
      step = (ticks[ticks.length - 1].value - ticks[0].value) / (ticks.length - 1);

    } else if(this.get('min') || this.get('max')) {
      this.get('min') ? min = this.get('min') : min = 0;
      this.get('max') ? max = this.get('max') : max = 100;
    }

    const asyncSlider = ({index, start, end, handle}) => {
      let arr = [];
      if(index === 0) {
        if(area >= 0) {
          arr = [start, start + area];
        } else {
          arr = [start, start - area];
        }
        // arr = [start, start + area];
      } else if(area >= 0) {
        arr = [end, end + area];
      } else {
        arr = [end, end - area];
      }
      Ember.run.debounce(() => {
        this.$().slider('values', arr);
      });
      Ember.$.each(handle, function(idx, item) {
        item.setAttribute('tooltip', arr[idx]);
      });
    };
    this.$().slider({
      disabled: false,
      range: range,
      orientation: this.get('orientation'),
      min: min,
      max: max,
      step: step,
      classes: {
        'ui-slider': !range ? 'simple-slider' : ''
      },
      create: ( event ) => {
        const val = `${((sliderVal - min)/(max - min)) * 100}%`;

        if(event.target.classList.contains('simple-slider')) {
          event.target.insertAdjacentHTML('beforeend', '<span class="bg-slider"></span>');
        }
        const handle = this.$('.ui-slider-handle');
        const target = this.$('.bg-slider')[0];
        // const ticks = this.get('ticks');

        this._slideValue({
          value: val,
          element: target
        });

        if(!range && sliderVal) {
          handle[0].setAttribute('tooltip', sliderVal);
        } else if(range && this._detectEnable(low) && !area) {
          handle[0].setAttribute('tooltip', low);
          handle[1].setAttribute('tooltip', high);
        } else if (this._detectEnable(low) && area) {
          if(area >= 0) {
            handle[0].setAttribute('tooltip', low);
            handle[1].setAttribute('tooltip', low + area);
          } else {
            handle[0].setAttribute('tooltip', low + area);
            handle[1].setAttribute('tooltip', low);
          }
          handle[1].classList.add('not-allow');
        }
        if(this.get('orientation') === 'vertical') {
          event.target.style.height = `${this.get('height')}px`;
        }
      },
      slide: ( event, ui ) => {
        const val = `${((ui.value - min)/(max - min)) * 100}%`;
        const target = this.$('.bg-slider')[0];
        const handle = this.$('.ui-slider-handle');
        this._slideValue({
          value: val,
          element: target
        });

        if(area) {
          asyncSlider({
            index: ui.handleIndex,
            start: ui.values[0],
            end: ui.values[1],
            handle: handle
          });
        }

        if (!range && sliderVal) {
          ui.handle.setAttribute('tooltip', ui.value);
        } else if (range && !area) {
          Ember.$.each(handle, function(index, item) {
            item.setAttribute('tooltip', ui.values[index]);
          });
        }
      },
      stop: (event, ui) => {
        let val;
        if(!range && sliderVal) {
          val = ui.value;
        } else if (range) {
          if(this._detectEnable(low) && this._detectEnable(high)) {
            val = ui.values;
          }
        }
        if(this.get('_hasLoaded')) {
          Ember.run.once(() => this._raiseEvents('onValueChanged', { 'source': this, value: val }));
        }
      }
    });
    this._initSlideVal({ sliderVal: sliderVal, low: low, high: high, area: area });
  },
  _initSlideVal({sliderVal, low, high, area}) {
    if(sliderVal) {
      this.$().slider( {
        value: sliderVal
      });
    } else if (!area && this._detectEnable(low) && this._detectEnable(high)) {
      this.$().slider({
        values: [low, high]
      });
    } else if (area && this._detectEnable(low)) {
      if(area >= 0) {
        this.$().slider({
          values: [low, low + area ]
        });
      } else {
        this.$().slider({
          values: [low + area, low]
        });
      }
    }
  },
  _slideValue({value, element}) {
    if(!this.get('range')) {
      if(this.get('orientation') === 'horizontal') {
        element.style.width = value;
      } else if(this.get('orientation') === 'vertical') {
        element.style.height = value;
      }
    }
  }
});