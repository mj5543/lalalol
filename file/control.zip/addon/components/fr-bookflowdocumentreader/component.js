import Control from '../fr-control/component';
import layout from './template';

//https://github.com/blasten/turn.js
export default Control.extend({
  layout,
  classNames: ['fr-bookflowdocumentreader'],
  // == Private Properties ==========================================
  _flipbook: null,
  // == Public Properties ===========================================
  acceleration: true,
  autoCenter: true,
  direction: 'ltr',
  display: 'double',
  duration: 600,
  gradients: true,
  height: null,
  width: null,
  elevation: 0,
  page: 1,
  pages: null,
  isTurning: false,
  turnCorners: 'bl,br',
  when: null,
  animating: false,
  // == Public Events ===========================================
  onstart: null,
  onend: null,
  onturning: null,
  onturned: null,
  onfirst: null,
  onlast: null,
  onmissing: null,
  onzooming: null,
  // == Public Methods ==========================================
  // == Event Hooks =============================================
  didInsertElement() {
    this._super(...arguments);

    this._flipbook = this.$().turn({
      acceleration: this.get('acceleration'),
      autoCenter: this.get('autoCenter'),
      direction: this.get('direction'),
      display: this.get('display'),
      duration: this.get('duration'),
      gradients: this.get('gradients'),
      height: this.get('height'),
      width: this.get('width'),
      elevation: this.get('elevation'),
      page: this.get('page'),
      turnCorners: this.get('turnCorners'),
      pages: this.get('pages'),
      when: this.get('when'),
      animating: this.get('animating')
    })
    .on('start', function (event, pageObject, corner) {
      this._raiseEvents('onstart', { 'source': this.$(), 'originalEvent': event, 'pageObject': pageObject, 'corner': corner });
    }.bind(this))
    .on('turning', function (event, page, view) {
      this._raiseEvents('onturning', { 'source': this.$(), 'originalEvent': event, 'page': page, 'view': view });
    }.bind(this))
    .on('turned', function (event, page, view) {
      this._raiseEvents('onturned', { 'source': this.$(), 'originalEvent': event, 'page': page, 'view': view });
    }.bind(this))
    .on('end', function (event, pageObject, turned) {
      this._raiseEvents('onend', { 'source': this.$(), 'originalEvent': event, 'pageObject': pageObject, 'turned': turned });
    }.bind(this))
    .on('first', function (event) {
      this._raiseEvents('onfirst', { 'source': this.$(), 'originalEvent': event });
    }.bind(this))
    .on('last', function (event) {
      this._raiseEvents('onlast', { 'source': this.$(), 'originalEvent': event });
    }.bind(this))
    .on('missing', function (event, pages) {
      this._raiseEvents('onmissing', { 'source': this.$(), 'originalEvent': event, 'pages': pages });
    }.bind(this))
    .on('zooming', function (event, newZoomValue, currentZoomValue) {
      this._raiseEvents('onzooming', { 'source': this.$(), 'originalEvent': event, 'newZoomValue': newZoomValue, 'pages': currentZoomValue });
    }.bind(this));
  },
  willDestroyElement() {
    this._super(...arguments);

    this._flipbook
      .off('start')
      .off('turning')
      .off('turned')
      .off('end')
      .off('first')
      .off('last')
      .off('missing')
      .off('zooming')
      .turn('destroy');
  },
});
