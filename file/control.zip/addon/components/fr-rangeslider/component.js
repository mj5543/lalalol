import Ember from 'ember';
import layout from './template';
import Control from '../fr-control/component';
import SlderMixin from '../../mixins/slider-mixin';

// == RangeSlider
export default Control.extend(SlderMixin, {
  // == Component Properties ========================
  attributeBindings: ['getLowerValue:data-value'],
  classNames: ['fr-slider', 'fr-rangeslider'],
  layout,
  tagName: 'div',
  // == Public Properties ===========================
  lowerValue: 0,
  highValue:0,
  lowerValueChanged: null,
  highValueChanged: null,
  getLowerValue: Ember.computed('lowerValue', 'highValue', function () {
    const _lowValue = this._inergerValue(this.get('lowerValue'));
    const _highValue = this._inergerValue(this.get('highValue'));

    if (this.hasLoaded) {
      Ember.run.once(this, function () {
        this._raiseValueChanged();
      }.bind(this));
    }

    Ember.run.next(this, function () {
      this._setPositionFromLowerValue(_lowValue);
      this._setPositionFromHighValue(_highValue);
    }.bind(this));

    return _lowValue + "-" + _highValue;
  }).readOnly(),
  _getLowerThumbPosition() {
    return parseInt(this._sliderThumb('.thumbA').css('left'), 10);
  },
  _getHighThumbPosition() {
    return parseInt(this._sliderThumb('.thumbB').css('left'), 10);
  },
  _getValueFromPosition() {
    // ignored
  },
  _getPositionFromValue() {
    // ignored
  },
  _setPositionFromLowerValue(newValue) {

    let newLeft = 0;

    if (this._isSnapToTickEnabled() === true) {

      let indexAt = this._getIndexOfByTickValue(newValue);

      if (indexAt > -1) {

        const tmp = this._getDistancePixel() * indexAt ;

        if ( tmp > 0) {
          newLeft = tmp - this._thumbWidth();
        } else {
          newLeft = tmp;
        }
      }
    } else {
      const absValue = Math.abs(this._minimumValue()) + newValue;

      newLeft = this._getPixelByTick() * absValue;
    }

    this._sliderThumb('.thumbA').css('left', newLeft);
    this._sliderSelection().css('left', newLeft + this._thumbWidth());
  },
  _setPositionFromHighValue(newValue) {

    let newLeft = 0;

    if (this._isSnapToTickEnabled() === true) {

      let indexAt = this._getIndexOfByTickValue(newValue);

      if (indexAt > -1) {

        const tmp = this._getDistancePixel() * indexAt ;

        if ( tmp > 0) {
          newLeft = tmp - this._thumbWidth();
        } else {
          newLeft = tmp;
        }
      }
    } else {
      const absValue = Math.abs(this._minimumValue()) + newValue;

      newLeft = this._getPixelByTick() * absValue;
    }

    this._sliderThumb('.thumbB').css('left', newLeft);
    this._sliderSelection().width(newLeft - this._getLowerThumbPosition() );
  },
  _setLowValueFromPosition() {

    let _newValue = 0;

    if (this._isSnapToTickEnabled() === true) {
      const position = this._getLowerThumbPosition();

      if (position !== 0) {
        const idx = Math.ceil(position / this._getDistancePixel());

        _newValue = Ember.get(this._getTicks().objectAt(idx), this.valuePropertyPath);
      }
    } else {
      const tmp = this._getLowerThumbPosition() / this._getPixelByTick() ;

      _newValue = Math.round(this._minimumValue() + tmp);
    }

    this.setLowerValue(_newValue);
  },
  _setHighValueFromPosition() {

    let _newValue = 0;

    if (this._isSnapToTickEnabled() === true) {
      const position = this._getHighThumbPosition();

      if (position !== 0) {
        const idx = Math.ceil(position / this._getDistancePixel());

        _newValue = Ember.get(this._getTicks().objectAt(idx), this.valuePropertyPath);
      }
    } else {
      const tmp = this._getHighThumbPosition() / this._getPixelByTick() ;

      _newValue = Math.round(this._minimumValue() + tmp);
    }

    this.setHighValue(_newValue);
  },
  _raiseValueChanged() {
    this._raiseEvents('valueChanged', { 'source': this, lowerValue : this._inergerValue(0), highValue: this._inergerValue(0) });
  },
  _onhorizontalmove(e) {
    e.preventDefault();

    const rect = this._trackRect(e.pageX);

    const thumbRadius = this._thumbWidth() / 2;
    let newLeft = rect.relativeX - thumbRadius;

    if (e.pageX >= rect.right) {
      newLeft = rect.width;
    } else if (e.pageX < rect.left) {
      newLeft = 0 ;
    }

    if ( e.data.handle.hasClass('thumbA')) {
      if ( newLeft > this._getHighThumbPosition() - this._thumbWidth() ) {
       newLeft = this._getHighThumbPosition() ;
      }
      this._sliderThumb('.thumbA').css('zIndex', 10);
      this._sliderThumb('.thumbB').css('zIndex', 1);
    } else {
      if (  this._getLowerThumbPosition() + this._thumbWidth() > newLeft ) {
        newLeft =  this._getLowerThumbPosition() ;
      }
      this._sliderThumb('.thumbA').css('zIndex', 1);
      this._sliderThumb('.thumbB').css('zIndex', 10);
    }


    e.data.handle.css('left', newLeft);




    this._sliderSelection().css('left', this._getLowerThumbPosition() + this._thumbWidth());
    this._sliderSelection().css('width', this._getHighThumbPosition() - this._getLowerThumbPosition());
  },
  _onhorizontaltickmove(e) {
    e.preventDefault();

    const rect = this._trackRect(e.pageX);
    const thumbWidth = this._thumbWidth();
    const distance = this._getDistancePixel();
    const pos = Math.round(rect.relativeX / distance);
    let newLeft = pos * distance;

    if (e.pageX >= rect.right) {
      newLeft = rect.width;
    } else if (e.pageX < rect.left) {
      newLeft = 0;
    } else if (pos === 0) {
      newLeft = newLeft;
    } else {
      newLeft = newLeft - thumbWidth;
    }

    if ( e.data.handle.hasClass('thumbA')) {
      if ( newLeft > this._getHighThumbPosition() - this._thumbWidth() ) {
       newLeft = this._getHighThumbPosition() ;
      }
      this._sliderThumb('.thumbA').css('zIndex', 10);
      this._sliderThumb('.thumbB').css('zIndex', 1);
    } else {
      if (  this._getLowerThumbPosition() + this._thumbWidth() > newLeft ) {
        newLeft =  this._getLowerThumbPosition() ;
      }
      this._sliderThumb('.thumbA').css('zIndex', 1);
      this._sliderThumb('.thumbB').css('zIndex', 10);
    }

    e.data.handle.css('left', newLeft);

    this._sliderSelection().css('left', this._getLowerThumbPosition() + this._thumbWidth());
    this._sliderSelection().css('width', this._getHighThumbPosition() - this._getLowerThumbPosition());
  },
  _onverticalltickmove(e) {
    e.preventDefault();

    return false;
  },
  _onverticallmove(e) {
    e.preventDefault();

    return false;
  },
  _onmouseup(e) {
    e.preventDefault();

    this._destory();

    this._setLowValueFromPosition();
    this._setHighValueFromPosition();
  },
  // == Public Methods ==============================
  setLowerValue(value) {
    this.set('lowerValue', value);
  },
  setHighValue(value) {
    this.set('highValue', value);
  },
  actions: {
  }
});