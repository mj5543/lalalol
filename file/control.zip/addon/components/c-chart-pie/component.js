import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';
import GlobalServiceContainerMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

export default Control.extend(GlobalServiceContainerMixin, StatefulComponentMixin, {
  layout,

  tagName: 'g',
  classNames: ['c-chart-pie'],

  chartData: null,
  height: null,
  seriesData: null,
  trace: null,
  width: null,
  xAxis: null,
  xScale: null,
  yAxis: null,
  yScale: null,
  setting: null,
  isValidData: null,

  _colorList: null,
  _chartData: Ember.computed.alias('chartData').readOnly(),
  _seriesData: Ember.computed.alias('seriesData').readOnly(),
  _trace: Ember.computed.alias('trace').readOnly(),
  _width: Ember.computed.alias('width').readOnly(),
  _xAxis: Ember.computed.alias('xAxis').readOnly(),
  _xScale: Ember.computed.alias('xScale').readOnly(),
  _yAxis: Ember.computed.alias('yAxis').readOnly(),
  _yScale: Ember.computed.alias('yScale').readOnly(),
  _isValidData: Ember.computed.alias('isValidData').readOnly(),

  _height: Ember.computed('height', 'setting', function() {
    return this.get('height') - this.get('_settingPaddingBottom');
  }),
  _settingPaddingTop: Ember.computed('setting', function() {
    return this.get('setting').paddingTop;
  }),
  _settingPaddingRight: Ember.computed('setting', function() {
    return this.get('setting').paddingRight;
  }),
  _settingPaddingLeft: Ember.computed('setting', function() {
    return this.get('setting').paddingLeft;
  }),
  _settingPaddingBottom: Ember.computed('setting', function() {
    return this.get('setting').paddingBottom;
  }),
  _settingNormalOpacity: Ember.computed('setting', function() {
    return this.get('setting').normalOpacity;
  }),
  _settingDarkOpacity: Ember.computed('setting', function() {
    return this.get('setting').darkOpacity;
  }),
  _settingTransparentOpacity: Ember.computed('setting', function() {
    return this.get('setting').transparentOpacity;
  }),
  _settingGlyphiconPrefix: Ember.computed('setting', function() {
    return this.get('setting').glyphiconPrefix;
  }),

  onPropertyInit() {
    this._super(...arguments);
    this._logTrace('c-chart-pie.onPropertyInit()');

    this.setStateProperties([]);

  },

  _colorFunction(n) {
    // #f24965, #ff9c66, #a66fd1, #32aedc, #4dd6d6, #ffd333, #6e3699, #3f66b1, #006466, #ff5b2e
    const colorList = [];

    colorList.push('#f24965');
    colorList.push('#ff9c66');
    colorList.push('#a66fd1');
    colorList.push('#32aedc');
    colorList.push('#4dd6d6');
    colorList.push('#ffd333');
    colorList.push('#6e3699');
    colorList.push('#3f66b1');
    colorList.push('#006466');
    colorList.push('#ff5b2e');

    return colorList[ n % colorList.length];
  },

  init() {
    this._super(...arguments);
    this._logTrace('c-chart-pie.init()');
  },

  didInsertElement() {
    this._super(...arguments);
    this._logTrace('c-chart-pie.didInsertElement()');
  },

  didRender() {
    this._super(...arguments);
    this._logTrace('c-chart-pie.didRender()');

    if(Ember.isEmpty(this.get('_chartData')) === true) {
      return;
    }

    if(this.get('_isValidData') === false) {
      return;
    }

    this._createSeries();
  },

  willDestroyElement() {
    this._super(...arguments);
    this._logTrace('c-chart-pie.willDestroyElement()');

    // 이벤트 리스너 해제
    this._removeEventListener();

    // 클로저 해제
    this._logTrace = null;
  },

  _logTrace(text) {
    if(this.get('_trace') === true) {
      Ember.Logger.log(text);
    }
  },

  _convertDateString(date, format) {
    return this.get('fr_I18nService').formatDate(date, format);
  },

  _createSeries() {
    const zero = 0;

    this._removeEventListener();
    this._removeDom();

    const series = this.get('_seriesData');

    if(series.data.length === zero) {
      return;
    }

    const tooltipTemplate = series.config.tooltipTemplate;
    const width = this.get('_width') / 2;
    const height = (this.get('_height')+this.get('_settingPaddingBottom')) / 2;
    const color = this._colorFunction;
    ////d3.scale.category20c();
    const r = series.config.radious;
    const dateFormat = this.get('_chartData').timeFormat.dataFormat;

    const arc = d3.arc()
      .outerRadius(height - (height/5))
      .innerRadius(height / 3)
      .padAngle(0.03)
      .cornerRadius(0)

    const pie = d3.pie()
      .sort(null)
      .value(function(d) {
        return d[series.config.yAxisProperty];
      });

    const el = this.$().get(zero);
    const seriesRootG = d3.select(el)
      .attr('class', 'chart seriesRoot' + series.no)
      .attr('data-id', 'seriesRoot' + series.no);

    const g = seriesRootG
      .selectAll('.chart.pie.series' + series.no)
      .data(pie(series.data))
      .enter()
      .append('g')
      .attr('class', 'chart pieG series' + series.no)
      .attr('transform', 'translate(' + width + ', ' + height + ')');

    // pie tooltip 을 위한 svg 의 sibling 개체
    const p = this.$().parent().parent();

    if(p.children('div.chartTooltipTemplate').length === zero) {
      p.append('<div class=\'chartTooltipTemplate\'></div>');
    }

    const toolTip = d3.select(p[zero]).selectAll('div.chartTooltipTemplate');

    // pie => path
    g.append('path')
      .attr('class', 'chart pie series' + series.no)
      .attr('d', arc)
      .attr('fill', function(d, i) {
        return color(i);
      })
      .on('mouseover', () => {
        this._logTrace('c-chart-line.pie.mouseover()');
        this._raiseEvents('mouseoverSeriesCB', series);
        d3.event.stopPropagation();
      })
      .on('mouseout', () => {
        this._logTrace('c-chart-line.pie.mouseout()');
        this._raiseEvents('mouseoutSeriesCB', series);
        toolTip.style('display', 'none');
        d3.event.stopPropagation();
      })
      .on('mousemove', d => {
        this._logTrace('c-chart-line.pie.mousemove()');
        const adjustX = 10;
        const adjustY = 20;
        const x = d3.event.x + adjustX;
        const y = d3.event.y + adjustY;

        toolTip.style('left', x + 'px');
        toolTip.style('top', y + 'px');
        toolTip.style('display', 'inline-block');

        if(Ember.isEmpty(tooltipTemplate) || Ember.isBlank(tooltipTemplate) ) {
          let val = d[series.config.tooltipProperty];

          if( typeof val === 'object' && val instanceof Date) {
            val = this._convertDateString(val, dateFormat);
          }
          toolTip.html(val);
        } else {
          let result = tooltipTemplate;

          for(const name in d.data) {
            let val = d.data[name];

            if( typeof val === 'object' && val instanceof Date) {
              val = this._convertDateString(val, dateFormat);
            }

            const regexp = new RegExp('{{' + name + '}}', 'gi');

            result = result.replace(regexp, val);
          }
          toolTip.html(result);
        }
      });

    g.append('text')
    .attr('transform', function(d) {
      d.innerRadius = r / 2;
      d.outerRadius = r;

      return 'translate(' + arc.centroid(d) + ')';
    })
    .attr('class', 'chart pieText series' + series.no)
    .style('text-anchor', 'middle')
    .text(function(d) {
      // console.log('차트 데이터 모양', d, series);
      return d.data[series.config.xAxisProperty];
    })
    .on('mouseover', () => {
      this._logTrace('c-chart-line.pieText.mouseover()');
      this._raiseEvents('mouseoverSeriesCB', series);
      d3.event.stopPropagation();
    })
    .on('mouseout', () => {
      this._logTrace('c-chart-line.pieText.mouseout()');
      this._raiseEvents('mouseoutSeriesCB', series);
      d3.event.stopPropagation();
    });
  },

  _removeEventListener() {
    const zero = 0;
    const series = this.get('_seriesData');
    const seriesNo = series.no;
    const mouseOverOut = [
      '.chart.pie.series' + seriesNo,
      '.chart.pieText.series' + seriesNo
    ];
    const mouseMove = ['.chart.pie.series' + seriesNo];
    const el = this.$().get(zero);
    const thisObj = d3.select(el);

    for(let i=0; i < mouseOverOut.length; i++) {
      thisObj.selectAll(mouseOverOut[i]).on('mouseover', null).on('mouseout', null);
    }

    for(let i=0; i < mouseMove.length; i++) {
      thisObj.selectAll(mouseMove[i]).on('mousemove', null);
    }
  },

  _removeDom() {
    this.$().children().remove();
  },

  actions: {
  },
});