import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

export default Control.extend(StatefulComponentMixin, {
  attributeBindings: ['getName:name'],
  classNames: ['c-accordionitem', 'accordion-list', 'wrap-check-view'],
  layout,
  tagName: 'div',
  hasExpanded: false,
  onActivate: null,
  onRender: null,
  onSelect: null,
  hasContentLoaded: false,
  accordionHeaderClassName: Ember.computed('_accordionGuid', function () {
    return `${this.get('_accordionGuid')}-accordionitem-header c-accordionitem-header accordion-tit`;
  }).readOnly(),
  getName: Ember.computed('name', function () {
    const nm = this.get('name') ;

    if (Ember.isEmpty(nm)) {
      return this.get('elementId');
    }

    return nm;
  }).readOnly(),
});