import Ember from 'ember';
import layout from './template';
import ValidationControl from '../c-validationcontrol/component';

export default ValidationControl.extend({
  layout,
  classNames: ['c-fileupload', 'c-fileadd-area', 'c-inp-txt'],
  tagName: 'div',
  //public properties
  style: null,
  files: null,
  accept: null,
  multiple: false,
  tabindex: null,
  placeHolder: null,
  disabled: false,
  readOnly: false,
  showClearButton: false,
  required: false,
  showValidationSuccess: false,
  externalErrorMessage: null,
  validationRules: null,
  //public events
  onLoaded: null,
  onUnload: null,
  onClick: null,
  onFocusIn: null,
  onFocusOut: null,
  onKeyPress: null,
  onKeyUp: null,
  onKeyDown: null,
  onChanged: null,
  onCleared: null,

  _fileuploadGuid: Ember.computed.readOnly('componentGuid'),
  _notReadOnly: Ember.computed.not('readOnly'),
  _showClearButtonAndNotReadOnly: Ember.computed.and('showClearButton', '_notReadOnly'),
  _internalValue: Ember.computed('files', function () {
    Ember.run.scheduleOnce('afterRender', this, '_filesChange');
    const files = this.get('files');

    if (files && 0 < files.length) {
      if (1 === files.length) {
        return files[0].name;
      }

      return `${files.length} files selected`;
    }
  }),
  click(event) {
    if (this.$(event.target).closest('label[for]').length === 0) {
      this._raiseEvents('onClick', {
        source: this,
        originalEvent: event,
      });
    }
  },
  focusIn(event) {
    this._raiseEvents('onFocusIn', {
      source: this,
      originalEvent: event,
    });
  },
  focusOut(event) {
    this.$('input[type=text]').val(this.get('_internalValue'));
    this._raiseEvents('onFocusOut', {
      source: this,
      originalEvent: event,
    });
  },
  keyPress(event) {
    this._raiseEvents('onKeyPress', {
      source: this,
      originalEvent: event,
    });
  },
  keyUp(event) {
    this._raiseEvents('onKeyUp', {
      source: this,
      originalEvent: event,
    });
  },
  keyDown(event) {
    this._raiseEvents('onKeyDown', {
      source: this,
      originalEvent: event,
    });
  },
  _filesChange() {
    if (Ember.isNone(this.get('files'))) {
      this.$('input[type=file]').val('');
    }
  },
  actions: {
    delMouseDown(event) {
      event.preventDefault();
      this.set('files', null);
      this._raiseEvents('onCleared', {
        source: this,
        originalEvent: event,
      });
    },
    change(event) {
      this.set('files', event.target.files);
      this._raiseEvents('onChanged', {
        source: this,
        originalEvent: event,
        files: this.get('files'),
      });
    },
  },
});