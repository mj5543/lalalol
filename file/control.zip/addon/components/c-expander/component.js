import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

//Expander
export default Control.extend(StatefulComponentMixin, {
  layout,
  tagName: 'div',
  classNames: ['c-expander', 'wrap-expander'],
  classNameBindings: [ 'expandDirectionClassName', 'expandedClassName' ],
  hasContentLoaded: false,
  // == Public Properties ==============================
  duration: 250,
  expanderSize: 35,
  isExpanded: false,
  expandDirection: 'down',
  holeSize: null,
  showHeader: true,
  // == Public Events ==================================
  onExpanded: null,
  onCollapsed: null,
  targetElement: null,
  _hasLoaded: false,
  // == Computed Properties ============================
  isUpExpandDirection: Ember.computed.equal('expandDirection', 'up'),
  expandDirectionClassName: Ember.computed('expandDirection', function () {
    const direction = this.get('expandDirection');

    if (direction === 'left') {
      return 'left';
    } else if (direction === 'right') {
      return 'right';
    } else if (direction === 'up') {
      return 'up';
    } else {
      return 'down';
    }
  }),
  expandedClassName: Ember.computed('isExpanded', function () {
    Ember.run.once(this, '_expandedChange');
    if (this.get('isExpanded')) {
      return 'on';
    }
  }),
  _expandedChange() {
    if (this.get('targetElement') && this.get('_hasLoaded')) {
      if (this.get('isExpanded')) {
        this._onExpanded();
      } else {
        this._onCollapsed();
      }
    }
  },
  // == Private Properties =============================
  _expanderGuid: Ember.computed.readOnly('componentGuid'),
  expanderHeaderClassName: Ember.computed('_expanderGuid', function () {
    return `${this.get('_expanderGuid')}-expander-header expander-tit`;
  }).readOnly(),
  _onCollapsed() {
    const direction = this.get('expandDirection');
    let content = this.get('targetElement').find('> div.expander-view');

    content.css('overflow-y', 'hidden');
    this.get('targetElement').removeClass('active');
    if(direction === 'left' || direction === 'right') {
      content.css({
        width: 0
      });
    } else {
      content.css({
        height: 0
      });
      this.$().css({
        height: this.get('showHeader') ? this.get('expanderSize') : 0
      });
      content = null;
    }
    if(this.get('_hasLoaded')) {
      this._raiseEvents('onCollapsed', { 'source': this, 'isExpanded': false });
    }
  },
  _setSize({obj, seq, size}) {
    obj.forEach(element => {
      element.css(seq, size);
    });
  },
  _onExpanded() {
    if (this.get('targetElement')) {
      const direction = this.get('expandDirection');
      let content = this.get('targetElement').find('> div.expander-view'), curton = content.find('> .expander-curton');

      this.get('targetElement').addClass('active');
      this.set('hasContentLoaded', true);
      if (direction === 'left' || direction === 'right') {
        this._setSize({
          obj: [curton, content],
          seq: 'width',
          size: this.get('width') ? this.get('width') - this.get('expanderSize') - 5 : 'auto'
        });
        this._setSize({
          obj: [content, curton],
          seq: 'height',
          size: this.get('height') || content.prop('scrollHeight')
        });
      } else {
        this._setSize({
          obj: [curton],
          seq: 'width',
          size: this.get('width') - 2
        });
        Ember.run.next(this, function () {
          if (!this.get('isDestroying') && !this.get('isDestroyed')) {
            let content = this.get('targetElement').find('> div.expander-view'),
            curton = content.find('> .expander-curton'), height = this.get('holeSize');
  
            if (this.get('height')) {
              if (height < this.get('height')) {
                height = this.get('height');
              }
            } else {
              if (height < content.prop('scrollHeight')) {
                height = content.prop('scrollHeight');
              }
            }
            this._setSize({
              obj: [content, curton],
              seq: 'height',
              size: height
            });
            this._setSize({
              obj: [this.$()],
              seq: 'height',
              size: this.get('showHeader') ? height + this.get('expanderSize') : height
            });
            content = null;
            curton = null;
            height = null;
          }
        });
      }
      content = null;
      curton = null;
      this._raiseEvents('onExpanded', { 'source': this, 'isExpanded': true });
    }
  },
  didInsertElement() {
    this._super(...arguments);
    const direction = this.get('expandDirection');
    this.set('targetElement', this.$('.expander-list'));
    this.set('_hasLoaded', true);
    if (this.get('showHeader')) {
      this.set('holeSize', this.$().height() - this.get('expanderSize'));
    } else {
      this.set('holeSize', this.$().height());
    }
    if (direction === 'left' || direction === 'right') {
      this.$('> div.expander-list').css({
        height: this.get('height') || 'auto'
      });
    } else {
      if (!this.get('isExpanded')) {
        this.$().css({
          height: this.get('showHeader') ? this.get('expanderSize') : 0
        });
      }
      this.$('> div.expander-list').css({
        width: this.get('width') || '100%'
      });
    }
    if (this.get('isExpanded')) {
      this.set('hasContentLoaded', true);
    }
  },
  _toggleExpand() {
    this.toggleProperty('isExpanded');
  },
  click(event) {
    const $target = this.$(event.target).closest(`.${this.get('_expanderGuid')}-expander-header`);

    if ($target.length > 0) {
      this._toggleExpand();
    }
  },
});