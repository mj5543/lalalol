import Ember from 'ember';

export default Ember.Component.extend({
  tagName: 'div',
  classNames: ['c-grid-menu'],
  init() {
    this._super(...arguments);
    if (this.get('_targetColumn.menuTemplateName')) {
      Ember.defineProperty(this, 'layout', Ember.computed(function () {
        return Ember.HTMLBars.compile(`{{yield (hash ${this.get('_targetColumn.menuTemplateName')}=(component 'c-grid-menu-template' targetColumn=_targetColumn))}}`);
      }));
    }
  },
});