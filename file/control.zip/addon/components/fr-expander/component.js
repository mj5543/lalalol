import Ember from 'ember';
import Control from '../fr-control/component';
import StatefulComponentMixin from 'framework-cross-cutting/mixins/stateful-component-mixin';

//Expander
export default Control.extend(StatefulComponentMixin, {
  layout: Ember.computed(function () {

    let template = null;

    switch (this.get('expandDirection')) {
      case 'up' :
        template = `<div class='expender-list'>
                      <div class='expender-view'>
                        {{#if hasContentLoaded}}
                        {{yield (hash content=(component 'fr-expander-content')) }}
                        {{/if}}
                      </div>
                      <div class='expender-tit'>
                        <div class='expender-tit-in'>
                          {{yield (hash header=(component 'fr-expander-header')) }}
                        </div>
                        <div class='expender-tit-func'>
                          <div class='bt-arr' onclick={{action 'toggleAction'}}><span class='bt-arr-in'></span><span class='blind'>fold</span></div>
                        </div>
                      </div>
                    </div>` ;
        break;
      default:
        template = `<div class='expender-list'>
                      <div class='expender-tit'>
                        <div class='expender-tit-in'>
                          {{yield (hash header=(component 'fr-expander-header')) }}
                        </div>
                        <div class='expender-tit-func'>
                          <div class='bt-arr' onclick={{action 'toggleAction'}}><span class='bt-arr-in'></span><span class='blind'>fold</span></div>
                        </div>
                      </div>
                      <div class='expender-view'>
                        {{#if hasContentLoaded}}
                        {{yield (hash content=(component 'fr-expander-content')) }}
                        {{/if}}
                      </div>
                    </div>` ;
        break;
    }

    return Ember.HTMLBars.compile(template);
  }),
  tagName: 'div',
  classNames: ['fr-expander', 'wrap-expender'],
  classNameBindings: [ 'expandDirectionClassName', 'expandedClassName' ],
  hasContentLoaded: false,
  // == Public Properties ==============================
  duration: 300,
  isExpanded: false,
  expandDirection: 'down',
  // == Public Events ==================================
  expanded: null,
  collapsed: null,
  // == Computed Properties ============================
  expandDirectionClassName: Ember.computed('expandDirection', function () {
    const direction = this.get('expandDirection');

    if (direction === 'left') {
      return 'left';
    } else if (direction === 'right') {
      return 'right';
    } else if (direction === 'up') {
      return 'up';
    }

    return null;
  }),
  expandedClassName: Ember.computed('isExpanded', function () {
    const isExpanded = this.get('isExpanded');

    if (isExpanded) {
      this._onExpanded();

      return 'on';
    }
    this._onCollapsed();

    return null;
  }),
  /*
  getClassNames: Ember.computed('disabled', 'readonly', 'isExpanded', function() {

    let rtn = '' ;

    const direction = this.get('expandDirection');
    const isExpanded = this.get('isExpanded');

    if (direction === 'left') {
      rtn += 'left ';
    } else if (direction === 'right') {
      rtn += 'right ';
    } else if (direction === 'up') {
      rtn += 'up ';
    }

    if ( this.get('disabled') === true) {
      rtn += 'disabled '
    }

    if ( this.get('readonly') === true) {
      rtn += 'readonly '
    }

    if (isExpanded === true) {
      this._onExpanded();
      rtn += 'on'
    } else {
      this._onCollapsed();
    }

    return rtn ;

  }).readOnly(),
  */
  // == Private Properties =============================
  _onCollapsed() {

    const direction = this.get('expandDirection');

    switch (direction) {
      case 'left':
        this.$('> div.expender-list').animate({ width: this._getMinWidth() }, {
          duration: this.duration,
          start: function () {
          }.bind(this),
          complete: function () {
            // ignored
          }
        });
        break;
      default:
        this._getContent().slideUp({
          duration: this.duration,
          start: function () {
          }.bind(this),
          complete: function () {
            // ignored
          }
        });
        break;
    }

    this._raiseEvents('collapsed', { 'source': this, 'isExpanded': false });
  },
  _onExpanded() {

    const direction = this.get('expandDirection');

    switch (direction) {
      case 'left':
        this.$('> div.expender-list').animate({ width: this._getMaxWidth() }, {
          duration: this.duration,
          start: function () {
          }.bind(this),
          complete: function () {
            if (this.get('hasContentLoaded') === false) {
              this.set('hasContentLoaded', true);
            }
          }.bind(this)
        });
        break;
      case 'right':
        break;
      default:
        this._getContent().slideDown({
          duration: this.duration,
          start: function () {
          }.bind(this),
          complete: function () {
            if (this.get('hasContentLoaded') === false) {
              this.set('hasContentLoaded', true);
            }
          }.bind(this)
        });
        break;
    }

    this._raiseEvents('expanded', { 'source': this, 'isExpanded': true });
  },
  _getHeader() {
    return this.$('> div.expender-list > div.expender-tit');
  },
  _getContent() {
    return this.$('> div.expender-list > div.expender-view');
  },
  _getMaxWidth() {
    return parseInt(this.$().css('max-width'), 10);
  },
  _getMinWidth() {
    return parseInt(this._getHeader().width(), 10);
  },
  //== Life Cycle ======================================
  onPropertyInit() {
    this._super(...arguments);

    this.setStateProperties(['isExpanded']);
  },
  didInsertElement() {
    this._super(...arguments);

    const direction = this.get('expandDirection');

    if (this.get('isExpanded') === true) {
      if (direction === 'left' || direction === 'right') {
        this.$('> div.expender-list').css('width', this._getMaxWidth());
      }
      this.set('hasContentLoaded', true);
    }
  },
  //== Actions =========================================
  actions: {
    toggleAction() {
      this.toggleProperty('isExpanded');
    }
  }
});