import Ember from 'ember';
import layout from './template';
import Control from '../fr-control/component';
import DatePickerMixin from '../../mixins/datepicker-mixin';
import GlobalServiceContainerMixin from 'framework-cross-cutting/mixins/global-service-container-mixin';
import maskHelper from '../maskHelper';

export default Control.extend(GlobalServiceContainerMixin, DatePickerMixin, {
  layout,
  tagName: 'div',
  classNames: ['fr-fromtodatepicker'],
  attributeBindings: [ '_observedAttribute' ],
  //== Private Properties ===============================================
  _fromMask: null,
  _toMask: null,
  //== Public Properties =============================================
  isFromDataSucess:null,
  isFromDataError:null,
  isToDataSucess:null,
  isToDataError:null,
  isPartialModify : false,
  displayFromDate: null,
  displayToDate: null,
  selectedFromDate: null,
  selectedToDate: null,
  _selectedFromDate: null,
  _selectedFromTime: null,
  _selectedToDate: null,
  _selectedToTime: null,
  //== Public Events =================================================
  fromDateKeyDown: null,
  fromDateFocus: null,
  fromDateBlur: null,
  toDateKeyDown: null,
  toDateFocus: null,
  toDateBlur: null,
  //== Private Methods ==============================================
  calendarButtonClassName: Ember.computed('calendarButtonVisibility', 'pickerType', function () {
    if (this.get('calendarButtonVisibility')) {
      if (this.get('pickerType') === 'time') {
        return 'inp-time';
      } else {
        return 'inp-date';
      }
    }

    return null;
  }),
  _observedAttribute: Ember.computed('_wasPickerType', 'pickerType', 'isPartialModify', function () {
    Ember.run.schedule('afterRender', this, function () {
      const wasPickerType = this.get('_wasPickerType');

      if (!Ember.isEmpty(wasPickerType) && wasPickerType !== this.get('pickerType')) {
        this._fromMask._$element.val('');
        this._toMask._$element.val('');
      }
      this.set('_wasPickerType', this.get('pickerType'));
      this._fromMask.mask = this._getMaskFormat();
      this._fromMask.partialModify = this.get('isPartialModify');
      this._fromMask.setMask();
      this._toMask.mask = this._getMaskFormat();
      this._toMask.partialModify = this.get('isPartialModify');
      this._toMask.setMask();
    });

    return null;
  }),
  minFromDate: Ember.computed('minDate', function () {
    const minDate = this.get('minDate');
    let minFromDate = null;

    if (!Ember.isNone(minDate)) {
      minFromDate = new Date(minDate);
    }

    return minFromDate;
  }),
  maxFromDate: Ember.computed('maxDate', '_selectedToDate', function () {
    const maxDate = this.get('maxDate'), _selectedToDate = this.get('_selectedToDate');
    let maxFromDate = null;

    if (!Ember.isNone(maxDate)) {
      maxFromDate = new Date(maxDate);
    }
    if (!Ember.isNone(_selectedToDate)) {
      if (Ember.isNone(maxFromDate) || new Date(_selectedToDate) < maxFromDate) {
        maxFromDate = new Date(_selectedToDate);
      }
    }

    return maxFromDate;
  }),
  minToDate: Ember.computed('minDate', '_selectedFromDate', function () {
    const minDate = this.get('minDate'), _selectedFromDate = this.get('_selectedFromDate');
    let minToDate = null;

    if (!Ember.isNone(minDate)) {
      minToDate = new Date(minDate);
    }
    if (!Ember.isNone(_selectedFromDate)) {
      if (Ember.isNone(minToDate) || minToDate < new Date(_selectedFromDate)) {
        minToDate = new Date(_selectedFromDate)
      }
    }

    return minToDate;
  }),
  maxToDate: Ember.computed('maxDate', function () {
    const maxDate = this.get('maxDate');
    let maxToDate = null;

    if (!Ember.isNone(maxDate)) {
      maxToDate = new Date(maxDate);
    }

    return maxToDate;
  }),
  _getFromDate() {
    return this.get('selectedFromDate');
  },
  _getToDate() {
    return this.get('selectedToDate');
  },
  _onFromTextChanged(text, value) {
    const newDate = this._formatTextToDate(text, value);

    if (!this._isDateInstance(newDate)) {
      this._setFromDate(null);
    } else {
      this._setFromDate(newDate);
    }
  },
  /*
  _onPropertyChanged() {
    const wasPickerType = this.get('_wasPickerType');

    this._onStateChanged(this.$('.fr-fromtext'), this.get('isFromDataSucess'), this.get('isFromDataError'));
    this._onStateChanged(this.$('.fr-totext'), this.get('isToDataSucess'), this.get('isToDataError'));
    if (!Ember.isEmpty(wasPickerType) && wasPickerType !== this.get('pickerType')) {
      this._fromMask._$element.val('');
      this._toMask._$element.val('');
    }
    this.set('_wasPickerType', this.get('pickerType'));
    this._fromMask.mask = this._getMaskFormat();
    this._fromMask.partialModify = this.get('isPartialModify');
    this._fromMask.setMask();
    this._toMask.mask = this._getMaskFormat();
    this._toMask.partialModify = this.get('isPartialModify');
    this._toMask.setMask();

    return '';
  },
  */
  _onToTextChanged(text, value) {
    const newDate = this._formatTextToDate(text, value);

    if (!this._isDateInstance(newDate)) {
      this._setToDate(null);
    } else {
      this._setToDate(newDate);
    }
  },
  _raiseSelectedDateChanged() {
    const _selectedFromDate = this._getPickerTypeDate(this.pickerType, this.get('_selectedFromDate'), this.get('_selectedFromTime')),
    _selectedToDate = this._getPickerTypeDate(this.pickerType, this.get('_selectedToDate'), this.get('_selectedToTime'));

    this.set('selectedFromDate', _selectedFromDate);
    this.set('selectedToDate', _selectedToDate);
  },
  _setFromDate(newValue) {
    this.set('selectedFromDate', newValue);
    if (!this._isDateInstance(newValue)) {
      this._fromMask.clear();
    }
  },
  _setFromToday() {
    this.set('displayFromDate', this.toDay);
    this.set('_selectedFromDate', this.toDay);
    this.set('_selectedFromTime', this.toDay);
    this.set('calendarMode', 'month');
  },
  _setToDate(newValue) {
    this.set('selectedToDate', newValue);
    if (!this._isDateInstance(newValue)) {
      this._toMask.clear();
    }
  },
  _setToToday() {
    this.set('displayToDate', this.toDay);
    this.set('_selectedToDate', this.toDay);
    this.set('_selectedToTime', this.toDay);
    this.set('calendarMode', 'month');
  },
  _isOpenChanged() {
    if (Ember.isNone(this.attrs.displayFromDate) && this.get('isOpen')) {
      if (!Ember.isNone(this.get('selectedFromDate'))) {
        this.set('displayFromDate', new Date(this.get('selectedFromDate')));
      } else {
        this.set('displayFromDate', this.get('co_CommonService').getNow());
      }
    }
    if (Ember.isNone(this.attrs.displayToDate) && this.get('isOpen')) {
      if (!Ember.isNone(this.get('selectedToDate'))) {
        this.set('displayToDate', new Date(this.get('selectedToDate')));
      } else {
        this.set('displayToDate', this.get('co_CommonService').getNow());
      }
    }
    this._raiseEvents('isOpenChanged', { 'source': this, 'selectedFromDate': this.get('selectedFromDate'), 'selectedToDate': this.get('selectedToDate') });
  },
  _selectedDateChanged() {
    const fromDt = this.get('selectedFromDate'), toDt = this.get('selectedToDate');

    this._raiseEvents('selectedDateChanged', {
      'source': this,
      'selectedFromDate': fromDt,
      'selectedToDate': toDt,
      'fromYear': this._isDateInstance(fromDt) ? fromDt.getFullYear() : null,
      'fromMonth': this._isDateInstance(fromDt) ? fromDt.getMonth() : null,
      'fromDate': this._isDateInstance(fromDt) ? fromDt.getDate() : null,
      'fromDay': this._isDateInstance(fromDt) ? fromDt.getDay() : null,
      'fromHour': this._isDateInstance(fromDt) ? fromDt.getHours() : null,
      'fromMinute': this._isDateInstance(fromDt) ? fromDt.getMinutes() : null,
      'toYear': this._isDateInstance(toDt) ? toDt.getFullYear() : null,
      'toMonth': this._isDateInstance(toDt) ? toDt.getMonth() : null,
      'toDate': this._isDateInstance(toDt) ? toDt.getDate() : null,
      'toDay': this._isDateInstance(toDt) ? toDt.getDay() : null,
      'toHour': this._isDateInstance(toDt) ? toDt.getHours() : null,
      'toMinute': this._isDateInstance(toDt) ? toDt.getMinutes() : null
    });
  },
  _isDateInstance(date) {
    return date instanceof Date && !isNaN(date.valueOf());
  },
  // == Public Methods =============================================
  displayFromText() {
    return this._getDisplayText(this.dateFormat, this.get('selectedFromDate'));
  },
  displayToText() {
    return this._getDisplayText(this.dateFormat, this.get('selectedToDate'));
  },
  calendarOpen() {
    const fromDt = this.get('selectedFromDate'), toDt = this.get('selectedToDate');

    if (!this._isDateInstance(fromDt)) {
      this.set('_selectedFromDate', fromDt);
      this.set('_selectedFromTime', fromDt);
    }
    if (!this._isDateInstance(toDt)) {
      this.set('_selectedToDate', toDt);
      this.set('_selectedToTime', toDt);
    }
    this.set('isOpen', true);
  },
  // == Computed Properties=========================================
  /*
  getClassNames: Ember.computed('disabled', 'readonly', 'isPartialModify', 'isFromDataSucess', 'isFromDataError', 'isToDataSucess', 'isToDataError', 'validationResult', 'calendarButtonVisibility', 'pickerType', function() {
    return this._onPropertyChanged();
  }).readOnly(),
  */
  _watchSelectedFromDate: Ember.computed('selectedFromDate', function () {
    if (this.hasLoaded) {
      Ember.run.once(this, this._selectedDateChanged);
    }

    return this._getDisplayText(this.dateFormat, this.get('selectedFromDate'));
  }).readOnly(),
  _datePickerFromValue: Ember.computed.oneWay('_watchSelectedFromDate').readOnly(),
  _watchSelectedToDate: Ember.computed('selectedToDate', function () {
    if (this.hasLoaded) {
      Ember.run.once(this, this._selectedDateChanged);
    }

    return this._getDisplayText(this.dateFormat, this.get('selectedToDate'));
  }).readOnly(),
  _datePickerToValue: Ember.computed.oneWay('_watchSelectedToDate').readOnly(),
  //== Life cycle =================================================
  init() {
    this._super(...arguments);

    this._trySetToday();

    this._setFromToday();
    this._setToToday();

    this._fromMask = maskHelper.create();
    this._fromMask.textCancel = this.actions.onFromTextCancelAction.bind(this);
    this._fromMask.textCommit = this.actions.onFromTextCommitAction.bind(this);
    this._fromMask.partialModify = this.isPartialModify;
    this._fromMask.autoclear = true;

    this._toMask = maskHelper.create();
    this._toMask.textCancel = this.actions.onToTextCancelAction.bind(this);
    this._toMask.textCommit = this.actions.onToTextCommitAction.bind(this);
    this._toMask.partialModify = this.isPartialModify;
    this._toMask.autoclear = true;
  },
  didInsertElement() {
    this._super(...arguments);

    this.$().attr('tabindex', -1);
    this.set('_targetElement', this.$().get(0));
    this._fromMask._$element = this.$('.datepicker-input').eq(0);
    this._toMask._$element = this.$('.datepicker-input').eq(1);
    //this._onPropertyChanged();
  },
  willDestroyElement() {
    this._super(...arguments);

    this._fromMask.destroy();
    this._fromMask = null;
    this._toMask.destroy();
    this._toMask = null;
  },
  //== Event Handler============================================
  actions: {
    selectedFromDatesChanged() {
      this._setFromDate(this._getPickerTypeDate(this.pickerType, this.get('_selectedFromDate'), this.get('_selectedFromTime')));
      //if (this.isAutoClose === true && (this.pickerType === 'date' || this.pickerType === 'year' || this.pickerType === 'yearMonth')) {
        //this.calendarClose();
      //}
    },
    selectedToDatesChanged() {
      this._setToDate(this._getPickerTypeDate(this.pickerType, this.get('_selectedToDate'), this.get('_selectedToTime')));
      //if (this.isAutoClose === true && (this.pickerType === 'date' || this.pickerType === 'year' || this.pickerType === 'yearMonth')) {
        //this.calendarClose();
      //}
    },
    selectedFromTimeChanged() {
      this._setFromDate(this._getPickerTypeDate(this.pickerType, this.get('_selectedFromDate'), this.get('_selectedFromTime')));
    },
    selectedToTimeChanged() {
      this._setToDate(this._getPickerTypeDate(this.pickerType, this.get('_selectedToDate'), this.get('_selectedToTime')));
    },
    timepadDoubleClick() {
      this.calendarClose();
    },
    calendarDoubleClick() {
      this.calendarClose();
    },
    onFromTextCancelAction() {
      if (!this._isDateInstance(this.get('selectedFromDate'))) {
        this._setFromDate(null);
      }
    },
    onFromTextCommitAction(e) {
      this._onFromTextChanged(e.text, e.value);
    },
    onToTextCancelAction() {
      if (!Ember.isEmpty(this.get('selectedToDate'))) {
        this._setToDate(null);
      }
    },
    onToTextCommitAction(e) {
      this._onToTextChanged(e.text, e.value);
    },
    onToggleAction() {
      if (this.get('isOpen') === false) {
        this.calendarOpen();
      } else {
        this.calendarClose();
      }
    },
    onFromDateKeydownAction(e) {
      this._raiseEvents('fromDateKeyDown', { 'source': this, 'originalEvent': e });
    },
    onFromDateFocusAction(e) {
      if (this.isGotFocusAutoSelect === true) {
        this.$(e.currentTarget).select();
      }
      this._raiseEvents('fromDateFocus', { 'source': this, 'originalEvent': e });
    },
    onFromDateBlurAction(e) {
      this._raiseEvents('fromDateBlur', { 'source': this, 'originalEvent': e });
    },
    onToDateKeydownAction(e) {
      this._raiseEvents('toDateKeyDown', { 'source': this, 'originalEvent': e });
    },
    onToDateFocusAction(e) {
      if (this.isGotFocusAutoSelect === true) {
        this.$(e.currentTarget).select();
      }
      this._raiseEvents('toDateFocus', { 'source': this, 'originalEvent': e });
    },
    onToDateBlurAction(e) {
      this._raiseEvents('toDateBlur', { 'source': this, 'originalEvent': e });
    },
    onMouseDoubleClickAction(e) {
      e.preventDefault();
      e.stopPropagation();
      this._raiseEvents('mouseDoubleClick', { 'source': this, 'originalEvent': e });
    },
    onFromTodayClickAction() {
      this._setFromToday();
    },
    onToTodayClickAction() {
      this._setToToday();
    }
  }
});