import Ember from 'ember';
import layout from './template';
import Control from '../c-control/component';

export default Control.extend({
  attributeBindings: ['_watchValueChanged:data-valuechanged'],
  layout,
  tagName : 'div',
  classNames: ['c-progressbar', 'c-wrap-progress'],
  classNameBindings: [ 'mode' ],
  value : 0,
  mode: null,
  unit : '%',
  duration : 1000,
  _watchValueChanged: Ember.computed('value', function() {
    this._onValueChanged();
  }),
  onPropertyInit(){
    this._super(...arguments);
    // this.setStateProperties(['property1', 'property2']);
    if (this.hasState() === false) {
      // this.set('mode', this.get('mode'));
    }
  },
  _onValueChanged() {
    const getPercent = parseFloat(this.get('value') / 100);
    const getProgressWrapWidth = parseFloat(this.$('.c-progress-area').width());
    const progressTotal = parseInt(getPercent * getProgressWrapWidth);
    // const animationLength = parseInt(this.get('duration'));
    this.$('.c-progress-area').css({
      width: this.get('width')
    });
    this.$('.progress-bar').css({
      width: progressTotal
    });
  },

  didInsertElement() {
    this._super(...arguments);
    this._onValueChanged();
  }
});
