import Ember from 'ember';

const Control = Ember.Namespace.create({});
export default Control;
