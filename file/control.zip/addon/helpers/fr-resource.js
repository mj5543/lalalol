import Ember from 'ember';

export default Ember.Helper.extend({
  i18nService : Ember.inject.service(),

  compute(params, hash) {
    let key = null;
    let resType = 'F';
    let mountedResource = null;

    if(Ember.isEmpty(params[0])){
      return 'Resource key does not specify.';
    } else {
      key = params[0];
    }

    //key is tempkey, return description
    if(Ember.isEqual(key, 'tempkey')){
      return Ember.String.htmlSafe(hash.description).toString();
    }

    if(!Ember.isEmpty(params[1])){
      resType = params[1];
    }

    if(Ember.isEmpty(hash.target)){
      return `[key:${key}] target does not specify.`;
    } else {
      mountedResource = Ember.get(hash.target, 'mountedResource');
    }

    return Ember.String.htmlSafe(this.get('i18nService').getResourceValue(mountedResource, key, resType, hash.paramValues)).toString();
  }
});