import Ember from 'ember';

export function frFormatResultHelper(params) {
  const suggestion = params.objectAt(0) ;
  const currentValue = params.objectAt(1) ;

  if ( Ember.isEmpty(currentValue)) {
    return suggestion ;
  }

  const pattern = '(' + currentValue.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&") + ')';

  return Ember.String.htmlSafe(
    suggestion
      .replace(new RegExp(pattern, 'gi'), '<strong>$1<\/strong>')
      // .replace(/&/g, '&amp;')
      // .replace(/</g, '&lt;')
      // .replace(/>/g, '&gt;')
      // .replace(/"/g, '&quot;')
      .replace(/&lt;(\/?strong)&gt;/g, '<$1>')
  ) ;
}

export default Ember.Helper.helper(frFormatResultHelper);