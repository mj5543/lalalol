import Ember from 'ember';

export function frIsodateformatHelper(params) {

  let date = params.objectAt(0) ;

  return date.toStandardDateString() + 'T' + date.getHours().toString().padLeft(2, '0') + ':' + date.getMinutes().toString().padLeft(2, '0') + ':' + date.getSeconds().toString().padLeft(2, '0') + '.' + (date.getMilliseconds() / 1000).toFixed(3).slice(2, 5) ;
}

export default Ember.Helper.helper(frIsodateformatHelper);

