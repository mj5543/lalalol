import Ember from 'ember';

export function frTemplateSelectHelper(params) {
  if ( Ember.isEmpty(params) || params.length === 0) {
    return '' ;
  }

  return params[0];
}

export default Ember.Helper.helper(frTemplateSelectHelper);
