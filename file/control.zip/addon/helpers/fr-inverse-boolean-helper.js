import Ember from 'ember';

export function frInverseBooleanHelper(params) {
  return !params[0];
}

export default Ember.Helper.helper(frInverseBooleanHelper);