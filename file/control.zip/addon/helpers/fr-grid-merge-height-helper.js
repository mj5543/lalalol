import { helper } from '@ember/component/helper';

export function frGridMergeHeightHelper(params) {
  const param0 = params[0], param1 = params[1], param2 = params[2];
  if (param0) {
    return Ember.String.htmlSafe(`height:auto;min-height:${param1*param2}px;white-space:normal;`);
  }
  return Ember.String.htmlSafe(`height:${param1*param2}px;min-height:${param1*param2}px;`);
}

export default helper(frGridMergeHeightHelper);
