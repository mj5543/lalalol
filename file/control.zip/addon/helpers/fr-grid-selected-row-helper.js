import Ember from 'ember';

export function frGridSelectedRowHelper(params) {
  const param0 = params[0], param1 = params[1];
  return param0.includes(param1);
}

export default Ember.Helper.helper(frGridSelectedRowHelper);