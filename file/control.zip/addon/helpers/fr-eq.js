import Ember from 'ember';

const frEq = (params) => params[0] === params[1];
export default Ember.Helper.helper(frEq);
