import Ember from 'ember';

export function frArray(params) {
  return Ember.A(params.slice());
}

export default Ember.Helper.helper(frArray);
