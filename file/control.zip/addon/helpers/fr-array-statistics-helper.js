import Ember from 'ember';

export function frArrayStatisticsHelper(params) {
  const param0 = params[0], param1 = params[1], param2 = params[2];
  let value = null, temp = null;
  switch (param0) {
    case 'sum':
      value = 0;
      for (let i = 0; i < param1.length; i++) {
        temp = Ember.isNone(param2) ? param1.objectAt(i) : Ember.get(param1.objectAt(i), param2);
        if (!Ember.isNone(temp) && !isNaN(temp)) {
          value += temp;
        }
      }
      break;
    case 'avg':
      value = 0;
      for (let i = 0; i < param1.length; i++) {
        temp = Ember.isNone(param2) ? param1.objectAt(i) : Ember.get(param1.objectAt(i), param2);
        if (!Ember.isNone(temp) && !isNaN(temp)) {
          value += temp;
        }
      }
      if (param1.length > 0) {
        value = (value / param1.length).toFixed(2);
      }
      break;
    case 'min':
      for (let i = 0; i < param1.length; i++) {
        temp = Ember.isNone(param2) ? param1.objectAt(i) : Ember.get(param1.objectAt(i), param2);
        if (value === null || value > temp) {
          value = temp;
        }
      }
      break;
    case 'max':
      for (let i = 0; i < param1.length; i++) {
        temp = Ember.isNone(param2) ? param1.objectAt(i) : Ember.get(param1.objectAt(i), param2);
        if (value === null || value < temp) {
          value = temp;
        }
      }
      break;
  }
  return value;
}

export default Ember.Helper.helper(frArrayStatisticsHelper);
