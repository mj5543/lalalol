import Ember from 'ember';

export function frNumericAdditionHelper(params) {
  return params.reduce(function (a, b) {
    return a + b;
  });
}

export default Ember.Helper.helper(frNumericAdditionHelper);