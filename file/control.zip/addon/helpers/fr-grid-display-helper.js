import Ember from 'ember';

export function frGridDisplayHelper(params) {
  const param0 = params[0], param1 = params[1], param2 = params[2], param3 = params[3];
  if (!Ember.isEmpty(param1)) {
    const selectedItem = param1.findBy(param2, param0);
    if (!Ember.isNone(selectedItem)) {
      return Ember.get(selectedItem, param3);
    }
  }
  return param0;
}

export default Ember.Helper.helper(frGridDisplayHelper);
