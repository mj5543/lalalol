import Ember from 'ember';

export function frGridMergeRenderHelper(params) {
  const param0 = params[0], param1 = params[1], param2 = params[2], param3 = params[3], index = param0.indexOf(param2);
  let a, b;

  if (index > 0) {
    for (let i = 0; i <= param1.indexOf(param3); i++) {
      a = Ember.get(param0.objectAt(index), Ember.get(param1.objectAt(i), 'field'));
      b = Ember.get(param0.objectAt(index - 1), Ember.get(param1.objectAt(i), 'field'));
      if (Ember.get(param1.objectAt(i), 'type') === 'date') {
        if (a && b && !(a < b || a > b)) {
          continue;
        }
      }
      if (a !== b) {
        return true;
      }
    }
    return false;
  }
  return true;
}

export default Ember.Helper.helper(frGridMergeRenderHelper);
