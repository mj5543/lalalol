import Ember from 'ember';

export function frDataCompareHelper(params) {
  const param0 = params[0], param1 = params[1], param2 = params[2];
  let value = false;
  switch (param0) {
    case 'eq':
      value = (param1 === param2);
      break;
    case 'not-eq':
      value = (param1 !== param2);
      break;
    case 'not':
      value = (!param1);
      break;
    case 'and':
      value = (param1 && param2);
      break;
    case 'or':
      value = (param1 || param2);
      break;
    case 'xor':
      value = ((param1 && !param2) || (!param1 && param2));
      break;
    case 'gt':
      value = (param1 > param2);
      break;
    case 'gte':
      value = (param1 >= param2);
      break;
    case 'lt':
      value = (param1 < param2);
      break;
    case 'lte':
      value = (param1 <= param2);
      break;
  }
  return value;
}

export default Ember.Helper.helper(frDataCompareHelper);
