import Ember from 'ember';

export function frBlankConvertHelper(params) {
  return Ember.String.htmlSafe(Ember.Handlebars.Utils.escapeExpression(params.join('')).replace(/ /g, '&nbsp;'));
}

export default Ember.Helper.helper(frBlankConvertHelper);
