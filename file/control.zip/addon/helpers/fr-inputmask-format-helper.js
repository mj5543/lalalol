import { helper } from '@ember/component/helper';

export function frInputmaskFormatHelper(params) {
  const param0 = params[0], param1 = params[1];
  return Inputmask.format(param1, param0);
}

export default helper(frInputmaskFormatHelper);
