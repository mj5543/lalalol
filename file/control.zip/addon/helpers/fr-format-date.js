import Ember from 'ember';
import formatDate from 'ember-intl/helpers/format-date';

export default formatDate.extend({
  i18nService: Ember.inject.service('i18n-service'),
  lang: null,
  compute(params, hash) {
    const val = this._super(params, hash);
    let result = val;
    this.set('lang',this.get('i18nService.currentLocale'));
    if(typeof val !== 'undefined' && typeof params[0] !== 'undefined' && this.get('lang') === 'ko-kr'){
      let temp = '';
      let dateInfo = '';

      switch(hash.format) {
        case 'c':
        case 'd':
        case 'Y':
        case 'M':
          temp = val.replace(/\./g,'');
          temp = temp.split(' ');
          result = temp.slice(0).join('-');
          break;
        case 'D':
        case 'g':
        case 'G':
        case 'u':
        case 'U':
          temp = val.split('. ');
          dateInfo = temp.slice(0, temp.length - 1).join('-');
          result = dateInfo + ' ' + temp[temp.length - 1];
          break;
        default: result = val;
          break;
      }
    }
    return result;
  }
});