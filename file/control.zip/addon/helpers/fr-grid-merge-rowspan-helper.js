import Ember from 'ember';

export function frGridMergeRowspanHelper(params) {
  const param0 = params[0], param1 = params[1], param2 = params[2], param3 = params[3], index = param0.indexOf(param2);
  let a, b, value = 1, size = Ember.get(param0, 'length');

  for (let i = 0; i <= param1.indexOf(param3); i++) {
    value = 1;
    for (let j = index + 1; j < size; j++) {
      a = Ember.get(param0.objectAt(index), Ember.get(param1.objectAt(i), 'field'));
      b = Ember.get(param0.objectAt(j), Ember.get(param1.objectAt(i), 'field'));
      if (Ember.get(param1.objectAt(i), 'type') === 'date') {
        if (a && b && !(a < b || a > b)) {
          value++;
          continue;
        }
      }
      if (a === b) {
        value++;
        continue;
      }
      break;
    }
    size = index + value;
  }
  return value;
}

export default Ember.Helper.helper(frGridMergeRowspanHelper);
