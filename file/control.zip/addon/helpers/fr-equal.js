import Ember from 'ember';

export function frEqual([leftSide, rightSide]) {
  return leftSide === rightSide;
}
export default Ember.Helper.helper(frEqual);