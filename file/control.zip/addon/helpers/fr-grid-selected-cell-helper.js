import Ember from 'ember';

export function frGridSelectedCellHelper(params) {
  const param0 = params[0], param1 = params[1], param2 = params[2],
    columnContainCells = param0.filterBy('column', param2);
  if (columnContainCells.length > 0) {
    return !Ember.isNone(columnContainCells.findBy('item', param1));
  }
  return false;
}

export default Ember.Helper.helper(frGridSelectedCellHelper);