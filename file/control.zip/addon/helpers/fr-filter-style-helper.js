import Ember from 'ember';
import { helper } from '@ember/component/helper';

export function frFilterStyleHelper(params) {
  const param0 = params[0], param1 = params[1], param2 = params[2];
  if (typeof param1 === 'string') {
    try {
      if (!Ember.isNone(param2)) {
        return Ember.String.htmlSafe(param0.replace(new RegExp(param1.split('').join('[, ]*'), 'gi'), param2));
      }

      return Ember.String.htmlSafe(param0.replace(new RegExp(param1.split('').join('[, ]*'), 'gi'), '<font style="font-weight:bold;color:#000;">$&</font>'));
    } catch (exception) {}
  }
}

export default helper(frFilterStyleHelper);
