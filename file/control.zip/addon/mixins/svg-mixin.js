import Ember from 'ember';

export default Ember.Mixin.create({
  createGroup(target, position = { x: 0, y: 0 }, id = null) {
    const group = target.append('g')
      .attr('transform', `translate(${position.x}, ${position.y})`);
    if (id !== null) {
      group.attr('id', id);
    }
    return group;
  },
  roundedRectPath(group, x, y, width, height, radius, mode = 'top', color ='black'){
    var rect = group.append("path").attr("fill", color);
    if(mode === 'top'){
      rect.attr("d", topPath(x, y, width, height, radius));
    }else{
      rect.attr("d", bottomPath(x, y, width, height, radius));
    }
    function topPath(x, y, width, height, radius) {
      return `M${x+radius},${y}
        L${x + width - radius},${y}
        C${x + width - (radius / 2)},${y} ${x+width},${y+(radius / 2)} ${x+width},${y+radius}
        L${x+width},${y+height}
        L${x},${y+height}
        L${x},${y+radius}
        C${x},${y+(radius /2)} ${x+(radius /2)},${y} ${x+radius},${y}
        Z`;
    }
    function bottomPath(x, y, width, height, radius) {
      return `M${x},${y}
        h${(width - radius)}
        v${(height - 2 * radius)}
        a${radius},${radius} 0 0 1 ${-radius},${radius}
        h${(radius - width + 2 * radius)}
        a${radius},${radius} 0 0 1 ${-radius},${-radius}
        z`;
    }

    return rect;
  },

  createText(group, position, txt, size, color = 'black', isLeft = false) {
    const rect = group.append('text')
      .attr('fill', color)
      .attr('font-size', size)
      .text(txt)
      .attr('transform', `translate(${position.x}, ${position.y})`);

    if(isLeft){
      this.setTextLeft(rect, position.x, position.y);
    }

    return rect;
  },

  createLeftText(group, position, txt, size, index, color = 'black') {
    const rect = group.append('text')
      .attr('fill', color)
      .attr('font-size', size)
      .text(txt)
      .attr('transform', `translate(${position.x}, ${position.y})`);

    return rect;
  },

  setTextLeft(target, x, y) {
    const textWidth = target.node().getBoundingClientRect().width;
    target.attr('transform', `translate(${-textWidth + x}, ${y})`);
  },

  createRect(group, position, size, radius, color = 'transparent', strokeWidth = 3, strokecolor = 'black', opacity = 1, dasharray = 0, rotate = 0) {
    const rect = group.append('rect')
      .attr("rx", radius)
      .attr("ry", radius)
      .attr('width', size.width)
      .attr('height', size.height)
      .attr('fill', color)
      .attr('stroke', strokecolor)
      .attr('stroke-dasharray', dasharray)
      .attr('stroke-width', strokeWidth)
      .attr('opacity', opacity)
      .attr('transform', `translate(${position.x}, ${position.y}) rotate(${rotate})`);

    return rect;
  },

  createCircle(group, r, position, strokeWidth = 1, color = 'transparent') {
    const circle = group.append('circle')
      .attr("r", r)
      .attr('fill', color)
      .attr('stroke', 'black')
      .attr('stroke-width', strokeWidth)
      .attr('transform', `translate(${position.x}, ${position.y})`);
    return circle;
  },

  bezierCurve(target, lineData, color = "black", strokeWidth = 3, dasharray = 0) {
    const lineFunction = d3.line()
      .x(function (d) { return d.x; })
      .y(function (d) { return d.y; })
      .curve(d3.curveBasis);
      //var interpolateTypes = [d3.curveLinear,d3.curveStepBefore,d3.curveStepAfter,d3.curveBasis,d3.curveBasisOpen, d3.curveBasisClosed, d3.curveBundle,d3.curveCardinal,d3.curveCardinal,d3.curveCardinalOpen,d3.curveCardinalClosed,d3.curveNatural];
      //.interpolate("cardinal"); //cardinal //linear //basis //monotone

    const lineGraph = target.append("path")
      .attr("d", lineFunction(lineData))
      .attr("stroke", color)
      .attr("stroke-width", strokeWidth)
      .attr('stroke-dasharray', dasharray)
      .attr("fill", "none");

    return lineGraph;
  },

  setIconShare(group, position, scale, isBefore = false){
    const iconSVG = group.append('g').attr("transform", `translate(${position.x}, ${position.y})scale(${scale})`);
    iconSVG.append('path').attr('d', 'M39.927,41.929c-0.524,0.524-0.975,1.1-1.365,1.709l-17.28-10.489c0.457-1.144,0.716-2.388,0.716-3.693  c0-1.305-0.259-2.549-0.715-3.693l17.284-10.409C40.342,18.142,43.454,20,46.998,20c5.514,0,10-4.486,10-10s-4.486-10-10-10  s-10,4.486-10,10c0,1.256,0.243,2.454,0.667,3.562L20.358,23.985c-1.788-2.724-4.866-4.529-8.361-4.529c-5.514,0-10,4.486-10,10  s4.486,10,10,10c3.495,0,6.572-1.805,8.36-4.529L37.661,45.43c-0.43,1.126-0.664,2.329-0.664,3.57c0,2.671,1.04,5.183,2.929,7.071  c1.949,1.949,4.51,2.924,7.071,2.924s5.122-0.975,7.071-2.924c1.889-1.889,2.929-4.4,2.929-7.071s-1.04-5.183-2.929-7.071  C50.169,38.029,43.826,38.029,39.927,41.929z M46.998,2c4.411,0,8,3.589,8,8s-3.589,8-8,8s-8-3.589-8-8S42.586,2,46.998,2z   M11.998,37.456c-4.411,0-8-3.589-8-8s3.589-8,8-8s8,3.589,8,8S16.409,37.456,11.998,37.456z M52.654,54.657  c-3.119,3.119-8.194,3.119-11.313,0c-1.511-1.511-2.343-3.521-2.343-5.657s0.832-4.146,2.343-5.657  c1.56-1.56,3.608-2.339,5.657-2.339s4.097,0.779,5.657,2.339c1.511,1.511,2.343,3.521,2.343,5.657S54.166,53.146,52.654,54.657z').attr('fill', '#90CAF9');
  },

  setIconSportMode(group, position, scale, disable = false) {
    const iconSVG = group.append('g').attr("transform", `translate(${position.x}, ${position.y})scale(${scale})`);

    iconSVG.append('circle').attr('cx', 28).attr('cy', 9).attr('r', 5).attr('fill', disable ? 'gray' : '#FF9800');

    iconSVG.append('path').attr('d', 'M29,27.3l-9.2-4.1c-1-0.5-1.5,1-2,2c-0.5,1-4.1,7.2-3.8,8.3c0.3,0.9,1.1,1.4,1.9,1.4c0.2,0,0.4,0,0.6-0.1 L28.8,31c0.8-0.2,1.4-1,1.4-1.8C30.2,28.4,29.7,27.6,29,27.3z').attr('fill', disable ? 'gray' : '#00796B');
    iconSVG.append('path').attr('d', 'M26.8,15.2l-2.2-1c-1.3-0.6-2.9,0-3.5,1.3L9.2,41.1c-0.5,1,0,2.2,1,2.7c0.3,0.1,0.6,0.2,0.9,0.2 c0.8,0,1.5-0.4,1.8-1.1c0,0,9.6-13.3,10.4-14.9s4.9-9.3,4.9-9.3C28.7,17.4,28.2,15.8,26.8,15.2z').attr('fill', disable ? 'gray' : '#009688');
    iconSVG.append('path').attr('d', 'M40.5,15.7c-0.7-0.8-2-1-2.8-0.3l-5,4.2l-6.4-3.5c-1.1-0.6-2.6-0.4-3.3,0.9c-0.8,1.3-0.4,2.9,0.8,3.4 l8.3,3.4c0.3,0.1,0.6,0.2,0.9,0.2c0.5,0,0.9-0.2,1.3-0.5l6-5C41.1,17.8,41.2,16.6,40.5,15.7z').attr('fill', disable ? 'gray' : '#FF9800');
    iconSVG.append('path').attr('d', 'M11.7,23.1l3.4-5.1l4.6,0.6l1.5-3.1c0.4-0.9,1.2-1.4,2.1-1.5c-0.1,0-0.2,0-0.2,0h-9c-0.7,0-1.3,0.3-1.7,0.9 l-4,6c-0.6,0.9-0.4,2.2,0.6,2.8C9.2,23.9,9.6,24,10,24C10.6,24,11.3,23.7,11.7,23.1z').attr('fill', disable ? 'gray' : '#FF9800');

    return iconSVG;
  },

  setIconExpression(group, position, scale, disable = false) {
    const iconSVG = group.append('g').attr("transform", `translate(${position.x}, ${position.y})scale(${scale})`);

    iconSVG.append('path').attr('d', 'M10,10v28h28V10H10z M34,34H14V14h20V34z').attr('fill', disable ? 'gray' : '#90CAF9');
    iconSVG.append('rect').attr('x', 6).attr('y', 6).attr('width', 12).attr('height', 12).attr('fill', disable ? 'gray' : '#D81B60');
    iconSVG.append('rect').attr('x', 30).attr('y', 6).attr('width', 12).attr('height', 12).attr('fill', disable ? 'gray' : '#2196F3');
    iconSVG.append('rect').attr('x', 6).attr('y', 30).attr('width', 12).attr('height', 12).attr('fill', disable ? 'gray' : '#2196F3');
    iconSVG.append('rect').attr('x', 30).attr('y', 30).attr('width', 12).attr('height', 12).attr('fill', disable ? 'gray' : '#2196F3');

    return iconSVG;
  },

  setIconClose(group, position, scale, disable = false) {
    const iconSVG = group.append('g').attr("transform", `translate(${position.x}, ${position.y})scale(${scale})`);
    iconSVG.append('path').attr('d', 'M10.185,1.417c-4.741,0-8.583,3.842-8.583,8.583c0,4.74,3.842,8.582,8.583,8.582S18.768,14.74,18.768,10C18.768,5.259,14.926,1.417,10.185,1.417 M10.185,17.68c-4.235,0-7.679-3.445-7.679-7.68c0-4.235,3.444-7.679,7.679-7.679S17.864,5.765,17.864,10C17.864,14.234,14.42,17.68,10.185,17.68 M10.824,10l2.842-2.844c0.178-0.176,0.178-0.46,0-0.637c-0.177-0.178-0.461-0.178-0.637,0l-2.844,2.841L7.341,6.52c-0.176-0.178-0.46-0.178-0.637,0c-0.178,0.176-0.178,0.461,0,0.637L9.546,10l-2.841,2.844c-0.178,0.176-0.178,0.461,0,0.637c0.178,0.178,0.459,0.178,0.637,0l2.844-2.841l2.844,2.841c0.178,0.178,0.459,0.178,0.637,0c0.178-0.176,0.178-0.461,0-0.637L10.824,10z').attr('fill', disable ? 'gray' : '#90CAF9');
    return iconSVG;
  }

});
