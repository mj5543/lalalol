import Ember from 'ember';

export default Ember.Mixin.create({
  title: '',
  _timeout: null,
  _onmouseLeave() {
    Ember.$('body').find('#toolTip').remove();
  },
  _onmouseEnter(e) {
    const self = Ember.$(e.currentTarget), body = Ember.$('body'), offset = self.offset();
    let offsetTop = offset.top + self.outerHeight() + 5, offsetLeft = offset.left + e.offsetX, el = Ember.$(`<div id='toolTip' class='fr-tooltip'>${this.get('title')}</div>`);

    body.find('#toolTip').remove();
    body.append(el);
    if ((Ember.$(window).width() - offsetLeft) < el.outerWidth()) {
      offsetLeft = offsetLeft + self.outerWidth() - el.outerWidth();
    }else if (offsetLeft - 5 < 0) {
      offsetLeft = 5;
    }else {
      offsetLeft = offsetLeft - 5;
    }

    if ( offsetLeft + el.outerWidth() + 10 >= Ember.$(window).width()) {
      offsetLeft += Ember.$(window).width() - (offsetLeft + el.outerWidth() + 10);
    }
    el.offset({ top: offsetTop, left: offsetLeft });
    el.show();
    el = null;
  },
  _showToolTip(event) {
    this.set('title', event.data.title);
    this._onmouseEnter(event);
  },
  mouseLeave() {
    this._onmouseLeave();
  },
  mouseEnter(event) {
    if (!Ember.isEmpty(this.get('title'))) {
      this._onmouseEnter(event);
    }
  },
  willDestroyElement() {
    this._onmouseLeave();
    this._super(...arguments);
  },
});