import Ember from 'ember';

export default Ember.Mixin.create({

  // Global Variables
  clipReportUrl: null,
  options: null,
  fieldParameters: null,
  files: null,
  itemsSource: null,
  report: null,
  styleList: null,
  jsonGuid: null,
  bigType: null,

  // Properties Bindings
  // classNameBindings: [ '' ],
  attributeBindings: [ 'language' ],

  // Computed Properties
  jsonGuidComputed: Ember.computed('jsonGuid', function() {
    if (Ember.isEmpty(this.get('jsonGuid'))) {
      return '';
    }

    this._createClipReport(this.get('targetTag'), this.get('jsonGuid'));
    if (this.get('bigType') === 'view') {
      this.get('report').view();
    } else if (this.get('bigType') === 'print') {
      const _options = this.get('options');
      if (_options.isDirect === true) {
        this.get('report').exeDirectPrint (
          _options.isPopUp,
          _options.printName,
          _options.tray,
          _options.startNumber,
          _options.endNumber,
          _options.copies,
          _options.option
        );
      } else if (_options.isDirect === false) {
        this.get('report').setDirectPrint(true);
        this.get('report').view();
      }
    }

    return '';
  }),

  // Life Cycle
  init() {
    this._super(...arguments);

    this.set('clipReportUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'clipReportServerUrl'));
    //this.set('styleList', Ember.Object.create());
  },
  willDestroyElement() {
    this._super(...arguments);

    const report = this.get('report');
    if ( !Ember.isEmpty(report) ) {
      report.closeReport();
    }
    this.set('report', null);
    this.set('clipReportUrl', null);
  },

  // Public Function
  setJsonData(jsonData) {
    this.set('jsonData', jsonData);
  },
  setLanguage(language) {
    this.set('language', language);
  },
  setTargetTag(targetTag) {
    this.set('targetTag', targetTag);
  },
  setPrintOptions(newOptions) {
    this._createDefaultPrintOptions (
      newOptions.isDirect,
      newOptions.isPopUp,
      newOptions.printName,
      newOptions.tray,
      newOptions.startNumber,
      newOptions.endNumber,
      newOptions.copies,
      newOptions.option
    );
  },
  setItemsSource(itemsSource) {
    const itemSourceJSON = JSON.stringify(itemsSource);
    this.set('itemsSource', itemSourceJSON);
  },
  setFiles(files) {
    this.set('files', files);
  },
  setFieldParameters(fieldParameters) {
    this.set('fieldParameters', fieldParameters);
  },
  viewReport(targetTag = this.get('targetTag')) {
    this._recallTargetStyle(targetTag);
    /*
    if (this.get('report') !== null) {
      this.get('report').deleteToReport();
      this.set('report', null);
    }
    */
    this._createClipReport(targetTag);
    //this.get('report').exportView();
    this.get('report').view();
  },
  viewBigReport(targetTag = this.get('targetTag')) {
    this.set('bigType', 'view');
    this.setTargetTag(targetTag);
    this._recallTargetStyle(targetTag);
    this._uploadJsonData(this.get('jsonData'));
  },
  printReport(newOptions, targetTag = this.get('targetTag')) {
    this._parseTargetStyle(targetTag);
    /*
    if (this.get('report') !== null) {
      this.get('report').deleteToReport();
      this.set('report', null);
    }
    */
    this._createClipReport(targetTag);
    this.setPrintOptions(newOptions);

    const _options = this.get('options');
    if (_options.isDirect === true) {
      this.get('report').exeDirectPrint (
        _options.isPopUp,
        _options.printName,
        _options.tray,
        _options.startNumber,
        _options.endNumber,
        _options.copies,
        _options.option
      );
    } else if (_options.isDirect === false) {
      this.get('report').setDirectPrint(true);
      this.get('report').view();
    }
  },
  printBigReport(newOptions, targetTag = this.get('targetTag')) {
    this.set('bigType', 'print');
    this.setTargetTag(targetTag);
    this.setPrintOptions(newOptions);
    this._parseTargetStyle(targetTag);
    this._uploadJsonData(this.get('jsonData'));
  },

  // Private Function
  _parseReportFiles(oof) {
    const reportFiles = [];

    const filelist = this.get('files').split(';');
    if (!Ember.isEmpty(filelist)) {
      filelist.forEach((file) => {
        var extension = file.split('.')[1];

        if(extension === 'crf'){
          reportFiles.push(file);
        }
      });
    }
    reportFiles.forEach((file)=>{
      oof.addFile('crf.root', '%root%/crf/' + file);
    });
    return oof;
  },
  _parseFieldParameters(oof) {
    if (!Ember.isEmpty(this.get('fieldParameters'))) {
      var _fieldParameters = this.get('fieldParameters');

      for (var item in _fieldParameters) {
        oof.addField(item, _fieldParameters[item]);
      }
    }
    return oof;
  },
  _parseTargetStyle(targetTag) {
    if (Ember.isEmpty(targetTag)) {
      return;
    }
    const _styleList = Ember.Object.create();
    // "position:absolute;width:100%;height:100%;overflow:auto;"
    const _targetStyle = this.$(targetTag).attr('style').split(';');
    _targetStyle.forEach((item) => {
      if (!Ember.isEmpty(item)) {
        const temp = item.split(':');
        const key = temp[0].trim();
        const val = temp[1].trim();

        if (key === "height") {
          _styleList[key] = this.$(targetTag).height();
        } else if (key === "width") {
          _styleList[key] = this.$(targetTag).width();
        } else {
          _styleList[key] = val;
        }
      }
    });
    _styleList.visibility = '';
    _styleList.opacity = '';

    this.set('styleList', _styleList);
  },
  _recallTargetStyle(targetTag) {
    const _styleList = this.get('styleList');
    if (Ember.isEmpty(_styleList)) {
      return;
    }

    for (var key in _styleList) {
      if (_styleList.hasOwnProperty(key)) {
        Ember.Logger.log('Style', "Key : " + key + " / Value : " + _styleList[key]);
        this.$(targetTag).css(key, _styleList[key]);
      }
    }
  },
  _createDefaultPrintOptions (
    isDirect = false,
    isPopUp = false,
    printName = '',
    tray = '',
    startNumber = 1,
    endNumber = -1,
    copies = 1,
    option = '') {
    const _options = Ember.Object.create();
    _options.isDirect = isDirect;
    _options.isPopUp = isPopUp;
    _options.printName = printName;
    _options.tray = tray;
    _options.startNumber = startNumber;
    _options.endNumber = endNumber;
    _options.copies = copies;
    _options.option = option;

    this.set('options', _options);
  },
  _createClipReport(targetTag = "#tempTag", jsonGuid = false) {
    const _language = Ember.isEmpty(this.get('language')) ? "en-us" : this.get('language');

    let _oof = new OOFDocument();
    _oof = this._parseFieldParameters(_oof);
    _oof = this._parseReportFiles(_oof);
    _oof.setExtendOptionFile(_language);

    const conn = jsonGuid === false ? _oof.addConnectionMemo('*', this.get('itemsSource')) : _oof.addConnectionFile("*","%root%/" + jsonGuid);
    conn.addContentParamJSON('*', 'utf-8', '{%dataset.json.root%}');

    var _report = createReport(this.get('clipReportUrl') + 'Clip.jsp', _oof.toString(), Ember.$(targetTag)[0]);
    _report.setStyle('reportInfo_button', 'visibility:hidden');
    _report.setStyle('close_button', 'visibility:hidden');

    _report.setCrossChromePDFPrint(true);
    _report.setOOFEncoding(true);
    //_report.setDebug(true);

    this.set('report', _report);
    //this.set('language', null);
  },
  _uploadJsonData(jsonData) {
    const _formData = new FormData();

    const _str = JSON.stringify(jsonData);
    const _blob = new Blob([_str], { type: 'application/json' });
    const _file = new File([ _blob ], 'FileName.json');

    _formData.append('file', _file, 'FileName.json');

    Ember.$.ajax(this.get('clipReportUrl') + "FileUpLoad.jsp", {
      method: "POST",
      contentType: false,
      processData: false,
      async: false,
      data: _formData,
      success: function (response) {
        this.set('jsonGuid', JSON.parse(response).fileName)
        Ember.Logger.log('jsonfile upload is success', response);
      }.bind(this),
      error: function (jqXHR) {
        Ember.Logger.log('jsonfile upload is failed', jqXHR);
      }
    });
  },
});