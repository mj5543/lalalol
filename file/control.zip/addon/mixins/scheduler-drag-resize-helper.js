import Ember from 'ember';

export default Ember.Mixin.create({
  _resizeHandler : null,
  _resizebles : null,
  _resizableOptions : null,
  _startResize(e) {

    e.stopPropagation();
    e.preventDefault();

    if ( this.$(e.target).is('.ui-resizable-handle') === false) {
      return ;
    }

    if ( this._onDragStart(e) === true ) {
      return ;
    }


    this._resizebles = {
      startCursor : null,
      currentTime : null,
      currentCell : null,
      resizeWith : e.data.resizeWith,
      timeSet : this.getTimeSet(),
      X : e.clientX,
      Y : e.clientY
    } ;

    if ( this._resizebles.resizeWith === 'left') {
      this._resizableOptions.containment.$().css('cursor', 'w-resize') ;
    } else if ( this._resizebles.resizeWith === 'top') {
      this._resizableOptions.containment.$().css('cursor', 's-resize') ;
    } else if ( this._resizebles.resizeWith === 'right') {
      this._resizableOptions.containment.$().css('cursor', 'w-resize') ;
    } else if ( this._resizebles.resizeWith === 'bottom') {
      this._resizableOptions.containment.$().css('cursor', 's-resize') ;
    }

    this._resizebles.startCursor = this._resizeHandler.css('cursor') ;

    Ember.$(document).bind('mousemove.rsz', this._doResize.bind(this));
    Ember.$(document).bind('mouseup.rsz', this._stopResize.bind(this));

    if (window.Touch || navigator.maxTouchPoints) {
      Ember.$(document).bind('touchmove.rsz', this._doResize.bind(this));
      Ember.$(document).bind('touchend.rsz', this._stopResize.bind(this));
    }
  },
  _doResize(e) {

    if ( e.which !== 1) {
      return ;
    }

    const $td = Ember.$(e.target);

    if ( $td.is('.fr-schedule-cell') === false) {
      return ;
    }

    if ( this._isResizeGesture(e) ) {
      const $tr = $td.closest('tr') ;

      if ( this.$().hasClass('fr-scheduler-taskitem-drag') === false){
        this.$().addClass('fr-scheduler-taskitem-drag');
      }

      if (this._resizebles.resizeWith === 'bottom' ) {


        const strAt = this._resizableOptions.containment.$('tr[data-time="' + this._resizebles.timeSet.startTime + '"]').position().top ;
        const endAt = $tr.position().top ;
        const newHeight = endAt - strAt ;

        if ( newHeight < this._resizableOptions.minimumHeight ) {
          return ;
        }

        this._resizeHandler.height( endAt - strAt);

      } else if (this._resizebles.resizeWith === 'top') {

        const strAt = $tr.offset().top ;
        const endAt = this._resizableOptions.containment.$('tr[data-time="' + this._resizebles.timeSet.endTime + '"]').offset().top ;
        const newHeight = endAt - strAt ;

        if ( newHeight < this._resizableOptions.minimumHeight ) {
          return ;
        }

        this._resizeHandler.offset({
          top : strAt
        }).height(endAt - strAt);

      }

      this._resizebles.currentTime = $tr.data('time') ;
      this._resizebles.currentCell = $td ;
    }
  },
  _stopResize(e) {
    e.stopPropagation();
    e.preventDefault();

    this.$().removeClass('fr-scheduler-taskitem-drag');

    Ember.$(document).unbind('mousemove.rsz');
    Ember.$(document).unbind('mouseup.rsz');

    if (window.Touch || navigator.maxTouchPoints) {
      Ember.$(document).unbind('touchmove.rsz');
      Ember.$(document).unbind('touchend.rsz');
    }

    if ( this._isResizeGesture(e) && !Ember.isEmpty( this._resizebles.currentCell) ) {
      this._resizableOptions.onDragEnd(e, this._resizebles);
    }

    this._resizableOptions.containment.$().css('cursor', 'default') ;

    this._resizebles = null;
    return false;
  },
  _isResizeGesture(e){
    return Math.abs(this._resizebles.X - e.clientX) >= 8 || Math.abs(this._resizebles.Y - e.clientY) >= 8 ;
  },
  _resizeDestroy() {
    this._getHandle('.ui-resizable-top', this._resizeHandler).off('mousedown.rsz');
    this._getHandle('.ui-resizable-bottom', this._resizeHandler).off('mousedown.rsz');

    this.$('.ui-resizable-handle').remove();
  },
  _canUseResize(el, option) {

    this._resizableOptions = option ;

    el.append('<div class="ui-resizable-handle ui-resizable-w ui-resizable-left" style="z-index: 90;cursor:' + ( option.resizeLeft === true ? "w-resize" : "default" ) + '" ></div>');
    el.append('<div class="ui-resizable-handle ui-resizable-s ui-resizable-top" style="z-index: 90;cursor:' + ( option.resizeTop === true ? "s-resize" : "default" ) + '"></div>');
    el.append('<div class="ui-resizable-handle ui-resizable-w ui-resizable-right" style="z-index: 90;cursor:' + ( option.resizeRight === true ? "w-resize" : "default" ) + '"></div>');
    el.append('<div class="ui-resizable-handle ui-resizable-s ui-resizable-bottom" style="z-index: 90;cursor:' + ( option.resizeBottom === true ? "s-resize" : "default" ) + '"></div>');

    if ( option.resizeTop === true) {
      this._getHandle('.ui-resizable-top', el).on('mousedown.rsz', { resizeWith : 'top'}, this._startResize.bind(this));
    }

    if ( option.resizeBottom === true) {
      this._getHandle('.ui-resizable-bottom', el).on('mousedown.rsz', { resizeWith : 'bottom'}, this._startResize.bind(this));
    }

    this._resizeHandler = el ;
  }
});
