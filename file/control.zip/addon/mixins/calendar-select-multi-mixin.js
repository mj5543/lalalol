import Ember from 'ember';

export default Ember.Mixin.create({
  _setCanUseMultiDrag() {
    this._internalCalendarItems = this.$('.fr-calendar-cell');

    this._internalCalendarItems
      .on('mousedown.calendar', this._onMultiRangeMouseDown.bind(this));
  },
  _onMultiRangeMouseDown(e) {
    if (this._isRightClick(e)) {
      return false;
    } else {

      this._internalCalendarItems
        .on('mouseup.calendar', this._onMultiRangeMouseUp.bind(this))
        .on('mousemove.calendar', this._onMultiRangeMouseMove.bind(this));

      Ember.$(document).on('mouseup.calendar', this._onWindowMouseUp.bind(this));

      this._dragStart = this._internalCalendarItems.index(this.$(e.currentTarget));
      this._isDragging = true;

      if (typeof e.preventDefault != 'undefined') {
        e.preventDefault();
      }
      document.documentElement.onselectstart = function () {
        return false;
      };
    }
  },
  _onMultiRangeMouseMove(e) {
    if (this._isDragging) {
      this._dragEnd = this._internalCalendarItems.index(this.$(e.currentTarget));

      this._onMultiRangeSelect(e);
    }
  },
  _onMultiRangeMouseUp(e) {

    this._internalCalendarItems
      .off('mouseup.calendar')
      .off('mousemove.calendar');

    if (this._isRightClick(e)) {
      return false;
    } else {
      this._dragEnd = this._internalCalendarItems.index(this.$(e.currentTarget));

      this._isDragging = false;
      if (this._dragEnd != 0) {
        this._onMultiRangeSelect(e);
      }

      const selectedCells = Ember.A([]);

      for (let i = 0; i < this._internalCalendarItems.length; i++) {
        const $e = this.$(this._internalCalendarItems.eq(i));

        if ($e.hasClass('calendar_day_rangesel') === true) {
          selectedCells.pushObject($e.data('day'));
        }
      }

      this._wasSelectedCells = selectedCells;

      this._onDateSelected(null);
    }
  },
  _onMultiRangeSelect(e) {

    if (e.ctrlKey === false) {
      this._internalCalendarItems.removeClass('calendar_day_rangesel');
      this._wasSelectedCells = null;
    }

    let items = null;

    if (this._dragEnd + 1 < this._dragStart) {
      items = this._internalCalendarItems.slice(this._dragEnd, this._dragStart + 1);
    } else {
      items = this._internalCalendarItems.slice(this._dragStart, this._dragEnd + 1);
    }

    for (let j = 0; j < items.length; j++) {
      let $e = this.$(items.eq(j));

      if ($e.hasClass('cal-d-disabled') === false) {
        if (!Ember.isEmpty(this._wasSelectedCells) && this._wasSelectedCells.indexOf($e.data("day")) > -1) {
          $e.removeClass('calendar_day_rangesel');
        } else {
          $e.addClass('calendar_day_rangesel');
        }
      }
    }
  },
  _wasSelectedCells: null,
});
