import Ember from 'ember';

export default Ember.Mixin.create({
  contextMenuService: Ember.inject.service('contextmenuService'),
  onContextMenuOpen: null,
  willDestroyElement() {
    this.get('contextMenuService').close();
    this._super(...arguments);
  },
  contextMenu(event) {
    if (!Ember.isNone(this.get('contextMenuSource'))) {
      let args = { source: this, originalSource: null, originalEvent: event, dataItem: null, cancel: false };

      this._internalContextMenuOpen(args);
      this._raiseEvents('onContextMenuOpen', args);
      if (!args.cancel) {
        this.get('contextMenuService').show({
          source: this,
          originalEvent: event,
          contextmenu: this.get('contextMenuSource'),
          args: args,
        });
      }
      args = null;
      event.stopPropagation();
    }
    event.preventDefault();
  },
  _raiseEvents(name, args) {
    const action = this.get(name);

    if (!Ember.isNone(this.get(name))) {
      if (Ember.isArray(args)) {
        return action(...args);
      } else {
        return action(args);
      }
    }
  },
});