import Ember from 'ember';

export default Ember.Mixin.create({
  _hasClearButton() {
    return this.get('clearButtonVisibility') == true;
  },
  _hasInputSearch() {
    return this.get('searchButtonVisibility') === true;
  },
  _getStyleWidth(){
    const width = this.$().prop('style')['width'] ;

    if (!Ember.isEmpty(width)) {
      return 'width:' + width;
    }

    return '';
  },
  _onStateChanged() {

    this.$().parent().removeClass('inp-search').removeClass('focus') ;

    if ( this._hasInputSearch() ) {
      this.$().parent().addClass('inp-search');
    }

    if ( this._hasClearButton() ) {
      this.$().parent().addClass('focus');
    }
  },
  _initializeTextBox() {
    this.$().attr('autocomplete', 'off').attr('autocorrect', 'off').attr('autocapitalize', 'off').attr('spellcheck', 'false');

    let wrapClass = '' ;
    let wrapStyle = '' ;

    this.get('classNames').forEach((css) =>{
      this.$().removeClass(css);
      wrapClass += css + ' ' ;
    });

    if ( this._hasInputSearch() ) {
      wrapClass += 'inp-search';
    }

    if(this.$().attr('disabled')){
      wrapClass += ' disabled';
    }

    this.$()
      .addClass('fr-input')
      .wrap(`<div class='${wrapClass}' style='${this._getStyleWidth()}'></div>`);

    if ( this._hasInputSearch() ) {
      this.$().after(`<span class='search'><span class='blind'>search</span></span>`) ;
    }

    this.$().after(`<button type='button' class='del'><span class='blind'>delete</span></button>`) ;

    this.$().parent().find('> .search').on('mousedown', this._onTextSearch.bind(this));
    this.$().parent().find('> .del').on('mousedown', this._onTextClear.bind(this));
  },
  _destroy() {
    this.$().off('focus')
      .off('blur')
      .off('keydown')
      .off('keypress')
      .off('keyup')
      .off('input propertychange') ;

    this.$().parent().find('> .search').off('mousedown');
    this.$().parent().find('> .del').off('mousedown');
  }
});
