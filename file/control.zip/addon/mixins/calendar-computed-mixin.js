import Ember from 'ember';
// import { debounce } from '@ember/runloop';

export default Ember.Mixin.create({
  _watchOptions: Ember.computed('selectionMode', 'pickerType', 'maxDate', 'minDate', 'disabledDates.[]', 'eventDays.[]', 'memoDatas.[]', 'holiDays.[]', 'patternDays.[]', 'itemsSource.[]', 'cols', 'rows', 'calendarMode', 'minCalendarMode', 'displayDate', 'dayofWeek', 'todayNavigationVisibility', function () {
    this._destroy();
    const rtn = {
      isMonth: this.get('calendarMode') === 'month',
      isYear: this.get('calendarMode') === 'year',
      isDecade: this.get('calendarMode') === 'decade',
      isMinCalendarisMonth: this.get('minCalendarMode') === 'month',
      isMinCalendarisYear: this.get('minCalendarMode') === 'year'
    };
    if (rtn.isMonth) {
      this._onDisplayDateChanged();
    }

    if (rtn.isYear) {
      const relativeTime = this._getRelativeTime();

      const tmp = {
        'year': this.get('displayDate').getFullYear(),
        'months': [
          [
            { value: 0, text: relativeTime.months[0], on: this.displayDate.getMonth() === 0 },
            { value: 1, text: relativeTime.months[1], on: this.displayDate.getMonth() === 1 },
            { value: 2, text: relativeTime.months[2], on: this.displayDate.getMonth() === 2 },
            { value: 3, text: relativeTime.months[3], on: this.displayDate.getMonth() === 3 }
          ],
          [
            { value: 4, text: relativeTime.months[4], on: this.displayDate.getMonth() === 4 },
            { value: 5, text: relativeTime.months[5], on: this.displayDate.getMonth() === 5 },
            { value: 6, text: relativeTime.months[6], on: this.displayDate.getMonth() === 6 },
            { value: 7, text: relativeTime.months[7], on: this.displayDate.getMonth() === 7 }
          ],
          [
            { value: 8, text: relativeTime.months[8], on: this.displayDate.getMonth() === 8 },
            { value: 9, text: relativeTime.months[9], on: this.displayDate.getMonth() === 9 },
            { value: 10, text: relativeTime.months[10], on: this.displayDate.getMonth() === 10 },
            { value: 11, text: relativeTime.months[11], on: this.displayDate.getMonth() === 11 }
          ]
        ]
      };

      this.set('_years', tmp);
    }

    if (rtn.isDecade) {

      let relativeTime = this._getRelativeTime();
      let year = Math.floor(parseFloat(this.displayDate.getFullYear()) / 10.0) * 10;

      let tmp = {
        'decade': year + relativeTime.y + '-' + (year + 9) + relativeTime.y,
        'years': [
          [
            { value: year - 1, text: relativeTime.y, on: false },
            { value: year + 0, text: relativeTime.y, on: false },
            { value: year + 1, text: relativeTime.y, on: false },
            { value: year + 2, text: relativeTime.y, on: false },
          ],
          [
            { value: year + 3, text: relativeTime.y, on: false },
            { value: year + 4, text: relativeTime.y, on: false },
            { value: year + 5, text: relativeTime.y, on: false },
            { value: year + 6, text: relativeTime.y, on: false },
          ],
          [
            { value: year + 7, text: relativeTime.y, on: false },
            { value: year + 8, text: relativeTime.y, on: false },
            { value: year + 9, text: relativeTime.y, on: false },
            { value: year + 10, text: relativeTime.y, on: false }
          ]
        ]
      };


      this.set('_decade', tmp);
    }
    return rtn;

  }).readOnly(),
  getSelectedDate: Ember.computed('selectedDate', function () {
    const date = this.get('selectedDate');

    if (this.hasLoaded) {
      Ember.run.once(this, function () {
        this._onRaiseSelectedDatesChanged(date);
      }.bind(this));
    }

    if (Ember.isEmpty(date)) {
      return '';
    } else {
      return date.toStandardDateString();
    }
  }).readOnly(),

  getDisplayDate: Ember.computed('displayDate', function () {
    const newDisplayDate = new Date(this.get('displayDate'));
    const firstDay = new Date(newDisplayDate.getFullYear(), newDisplayDate.getMonth(), 1, 0, 0, 0);
    const lastDay = new Date(newDisplayDate.getFullYear(), newDisplayDate.getMonth() + 1, 0, 0, 0, 0);


    if (this.hasLoaded) {
      /*
      if(this.isInternal) {
        this.isInternal = false;
        return;
      }
      */
      Ember.run.once(this, function () {
        this._raiseEvents('displayDateChanged', { 'source': this, 'displayDate': newDisplayDate, 'firstDay': firstDay, 'lastDay': lastDay, 'selectedDate': this.get('selectedDate') });
      }.bind(this));
    }

  }).readOnly(),
  _onDisplayDateChanged() {

    let _displayDate = this.get('displayDate');

    if (Ember.isEmpty(_displayDate)) {
      _displayDate = this.get('selectedDate');
    }

    if (Object.prototype.toString.call(_displayDate) === "[object Date]") {
      if (isNaN(_displayDate.getTime())) {
        _displayDate = this.get('co_CommonService').getNow();
      }
    }else {
      _displayDate = this.get('co_CommonService').getNow();
    }

    const calendars = [];

    let index = 0;

    for (var row = 0; row < this.rows; row++) {
      const calendar = [];

      for (var col = 0; col < this.cols; col++) {
        const monthDays = this._getMonthDays({
          id: '#' + this.elementId + '_month_' + index,
          displayDate: _displayDate.addMonths(index),
        });

        calendar.push(monthDays);

        index++;
      }

      calendars.push(calendar);
    }

    this.set('_calendars', calendars);
  },
  _getMonthDays(option) {

    const weeks = [];

    const daysShort = this.get('fr_I18nService').getRegional().dayNamesShort;
    const daysMin = this.get('fr_I18nService').getRegional().dayNamesMin;
    const weekdays = this._getWeekDays(daysShort);
    const weekdaysMin = this._getWeekDays(daysMin);
    const source = this.get('itemsSource');
    const thisDate = {
      year: option.displayDate.getFullYear(),
      month: option.displayDate.getMonth(),
      firstDate: new Date(option.displayDate.getFullYear(), option.displayDate.getMonth(), 1, 0, 0, 0),
      lastDate: new Date(option.displayDate.getFullYear(), option.displayDate.getMonth() + 1, 0, 0, 0, 0)
    };
    const addDay = this._getStartDay(thisDate.firstDate.getDay());

    let displayday = null;
    let hasDisabled = false;
    let dataItem = null;
    let date = new Date(thisDate.year, thisDate.month, 1).addDays(addDay);

    for (let week = 0; week < 6; week++) {

      const days = [];

      for (let dw = 0; dw < 7; dw++) {

        displayday = date.toStandardDateString();
        hasDisabled = false;

        if (!Ember.isEmpty(source)) {
          dataItem = source.find(function (item) {
            return Ember.get(item, this.datePropertyPath).toStandardDateString() === displayday;
          }.bind(this));
        }

        if (!Ember.isEmpty(this.maxDate)) {
          if (date > this.maxDate) {
            hasDisabled = true;
          }
        }

        if (!Ember.isEmpty(this.minDate)) {
          if (date < this.minDate) {
            hasDisabled = true;
          }
        }

        if (!Ember.isEmpty(this.disabledDates)) {

          const isExists = this.disabledDates.find(function (item) {
            return item.toStandardDateString() === displayday;
          }.bind(this));

          if (isExists) {
            hasDisabled = true;
          }
        }

        days.push({
          'hasDisabled': hasDisabled,
          'hasThisMonth': date.getMonth() === thisDate.month,
          'displayday': displayday,
          'day': date.getDate(),
          'date': date,
          'dataItem': dataItem
        });

        date = date.addDays(1);
      }

      weeks.push(days);
    }

    const _tmp = this.get('fr_I18nService').getRegional().monthNames;

    return {
      'year': option.displayDate.getFullYear(),
      'month_name': this.get('fr_I18nService').getRegional().monthNames[option.displayDate.getMonth()],
      'month_name_short': this.get('fr_I18nService').getRegional().monthNamesShort[option.displayDate.getMonth()],
      'month_n': option.displayDate.getMonth() + 1,
      'month': this.get('fr_I18nService').formatDate(option.displayDate, 'Y'),
      'day': option.displayDate.getDate(),
      'weekdays': weekdays,
      'weekdays_min': weekdaysMin,
      'weeks': weeks,
      'getday': weekdays[option.displayDate.getDay()]
    };

  },
  _getWeekDays(_tmp) {
    // const _tmp = this.get('fr_I18nService').getRegional().dayNamesShort;
    const rtn = [];
    const startdw = this._getStartDayofWeek();

    for (let i = 0; i < _tmp.length; i++) {
      const index = startdw + parseInt(i, 10);

      if (index > 6) {
        rtn.pushObject({ name: _tmp[index - 7] });
      }else {
        rtn.pushObject({ name: _tmp[index] });
      }
    }

    return rtn;
  },
  _getStartDayofWeek() {

    switch (this.get('dayofWeek')) {
      case 'monday': return 1;
      case 'tuesday': return 2;
      case 'wednesday': return 3;
      case 'thursday': return 4;
      case 'friday': return 5;
      case 'saturday': return 6;
      default:
        return 0;
    }
  },
  _getStartDay(monthDayofWeek) {
    const startDayofWeek = this._getStartDayofWeek();
    let addDay = 0;

    for (let k = 0; k < 7; k++) {
      let _index = startDayofWeek + k;

      if (_index > 6) {
        _index = _index - 7;
      }

      if (_index === monthDayofWeek) {
        addDay = k * -1;
        break;
      }
    }

    return addDay;
  },
  _getRelativeTime() {

    const regional = this.get('fr_I18nService').getRegional();

    return {
      d: regional.d,
      m: regional.m,
      y: regional.y,
      months: regional.monthNamesShort
    };
  }
});
