import Ember from 'ember';

export default Ember.Mixin.create({
  _watchOptions: Ember.computed('maxDate', 'minDate', '_displayDate', 'cols', 'rows', 'disabledDates.[]', 'calendarMode', 'minCalendarMode', 'dayofWeek', 'todayNavigationVisibility', function () {
    const rtn = {
      isMonth: this.get('calendarMode') === 'month',
      isYear: this.get('calendarMode') === 'year',
      isDecade: this.get('calendarMode') === 'decade',
      isMinCalendarisMonth: this.get('minCalendarMode') === 'month',
      isMinCalendarisYear: this.get('minCalendarMode') === 'year'
    };
    if (rtn.isMonth) {
      this._onDisplayDateChanged();
    }
    if (rtn.isYear) {
      const relativeTime = this._getRelativeTime();
      const _md = moment(this.get('_displayDate'));
      const tmp = {
        'year': _md.get('year'),
        'months': [
          [
            { value: 0, text: relativeTime.months[0], on: _md.get('month') === 0 },
            { value: 1, text: relativeTime.months[1], on: _md.get('month') === 1 },
            { value: 2, text: relativeTime.months[2], on: _md.get('month') === 2 },
            { value: 3, text: relativeTime.months[3], on: _md.get('month') === 3 }
          ],
          [
            { value: 4, text: relativeTime.months[4], on: _md.get('month') === 4 },
            { value: 5, text: relativeTime.months[5], on: _md.get('month') === 5 },
            { value: 6, text: relativeTime.months[6], on: _md.get('month') === 6 },
            { value: 7, text: relativeTime.months[7], on: _md.get('month') === 7 }
          ],
          [
            { value: 8, text: relativeTime.months[8], on: _md.get('month') === 8 },
            { value: 9, text: relativeTime.months[9], on: _md.get('month') === 9 },
            { value: 10, text: relativeTime.months[10], on: _md.get('month') === 10 },
            { value: 11, text: relativeTime.months[11], on: _md.get('month') === 11 }
          ]
        ]
      };
      this.set('_years', tmp);
    }
    if (rtn.isDecade) {
      const year = moment(this.get('_displayDate')).get('year');
      const num = { start: -100, end: 100 };
      const tmp = { decade: year, years: [] };

      for(let i = num.start; i< num.end; i++) {
        let is;
        i === 0 ? is = true : is = false;
        tmp.years.push({ value: year - i, text: this._getRelativeTime().y, on: is });
      }
      this.set('_decade', tmp);
    }

    return rtn;
  }).readOnly(),
  _onDisplayDateChanged() {
    const _displayDate = this.get('_displayDate');
    const calendars = [];
    let index = 0;

    for (var row = 0; row < this.rows; row++) {
      const calendar = [];

      for (var col = 0; col < this.cols; col++) {
        const monthDays = this._getMonthDays({
          id: '#' + this.elementId + '_month_' + index,
          displayDate: _displayDate.addMonths(index),
        });
        calendar.push(monthDays);
        index++;
      }
      calendars.push(calendar);
    }
    this.set('_calendars', calendars);
  },
  _getMonthDays(option) {
    const weeks = [];
    let days = this.get('fr_I18nService').getRegional().dayNames;
    const daysShort = this.get('fr_I18nService').getRegional().dayNamesShort;
    const daysMin = this.get('fr_I18nService').getRegional().dayNamesMin;
    const weekdaysLong = this._getWeekDays(days);
    const weekdays = this._getWeekDays(daysShort);
    const weekdaysMin = this._getWeekDays(daysMin);
    const source = this.get('itemsSource');
    const thisDate = {
      year: option.displayDate.getFullYear(),
      month: option.displayDate.getMonth(),
      firstDate: new Date(option.displayDate.getFullYear(), option.displayDate.getMonth(), 1, 0, 0, 0),
      lastDate: new Date(option.displayDate.getFullYear(), option.displayDate.getMonth() + 1, 0, 0, 0, 0)
    };
    const addDay = this._getStartDay(thisDate.firstDate.getDay());

    let displayday = null;
    let hasDisabled = false;
    let dataItem = null;
    let date = new Date(thisDate.year, thisDate.month, 1).addDays(addDay);

    for (let week = 0; week < 6; week++) {

      days = [];

      for (let dw = 0; dw < 7; dw++) {
        displayday = date.toStandardDateString();
        hasDisabled = false;

        if (!Ember.isEmpty(source)) {
          dataItem = source.find((item) => {
            return Ember.get(item, this.datePropertyPath).toStandardDateString() === displayday;
          });
        }
        if (!Ember.isEmpty(this.maxDate)) {
          if (date > moment(moment(this.maxDate).format('YYYY-MM-DD'), 'YYYY-MM-DD').toDate()) {
            hasDisabled = true;
          }
        }
        if (!Ember.isEmpty(this.minDate)) {
          if (date < moment(moment(this.minDate).format('YYYY-MM-DD'), 'YYYY-MM-DD').toDate()) {
            hasDisabled = true;
          }
        }
        if (!Ember.isEmpty(this.disabledDates)) {
          const isExists = this.disabledDates.find((item) => {
            return item.toStandardDateString() === displayday;
          });
          if (isExists) {
            hasDisabled = true;
          }
        }
        days.push({
          'hasDisabled': hasDisabled,
          'hasThisMonth': date.getMonth() === thisDate.month,
          'displayday': displayday,
          'day': date.getDate(),
          'date': date,
          'dataItem': dataItem
        });

        date = date.addDays(1);
      }
      weeks.push(days);
    }

    return {
      'year': option.displayDate.getFullYear(),
      'month_name': this.get('fr_I18nService').getRegional().monthNames[option.displayDate.getMonth()],
      'month_name_en': ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'][option.displayDate.getMonth()],
      'month_name_short': this.get('fr_I18nService').getRegional().monthNamesShort[option.displayDate.getMonth()],
      'month_n': option.displayDate.getMonth() + 1,
      'month': this.get('fr_I18nService').formatDate(option.displayDate, 'Y'),
      'day': option.displayDate.getDate(),
      'weekdays': weekdays,
      'weekdays_min': weekdaysMin,
      'weeks': weeks,
      'getday': weekdaysLong[option.displayDate.getDay()]
    };

  },
  _getWeekDays(_tmp) {
    // const _tmp = this.get('fr_I18nService').getRegional().dayNamesShort;
    const rtn = [];
    const startdw = this._getStartDayofWeek();

    for (let i = 0; i < _tmp.length; i++) {
      const index = startdw + parseInt(i, 10);

      if (index > 6) {
        rtn.pushObject({ name: _tmp[index - 7] });
      }else {
        rtn.pushObject({ name: _tmp[index] });
      }
    }

    return rtn;
  },
  _getStartDayofWeek() {

    switch (this.get('dayofWeek')) {
      case 'monday': return 1;
      case 'tuesday': return 2;
      case 'wednesday': return 3;
      case 'thursday': return 4;
      case 'friday': return 5;
      case 'saturday': return 6;
      default:
        return 0;
    }
  },
  _getStartDay(monthDayofWeek) {
    const startDayofWeek = this._getStartDayofWeek();
    let addDay = 0;

    for (let k = 0; k < 7; k++) {
      let _index = startDayofWeek + k;

      if (_index > 6) {
        _index = _index - 7;
      }

      if (_index === monthDayofWeek) {
        addDay = k * -1;
        break;
      }
    }

    return addDay;
  },
  _getRelativeTime() {
    const regional = this.get('fr_I18nService').getRegional();

    return { d: regional.d, m: regional.m, y: regional.y, months: regional.monthNamesShort };
  }
});
