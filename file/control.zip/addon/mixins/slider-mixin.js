import Ember from 'ember';

export default Ember.Mixin.create({
  minimum: 0,
  maximum: 100,
  tickPlacement: '',
  ticks: null,
  isSnapToTickEnabled: false,
  orientation: 'horizontal',
  valuePropertyPath: 'value',
  labelPropertyPath: 'label',
  isFirstLabel: false,
  _isTickPlacementIsBottom: false,
  _isTickPlacementIsTop: false,
  _isTickPlacementIsLeft: false,
  _isTickPlacementIsRight: false,
  _internalId: null,
  _attachedHorizontalMove(handle) {
    if (this._isSnapToTickEnabled() === true) {
      Ember.$(window).on('mousemove.slider', { handle: handle }, this._onhorizontaltickmove.bind(this));
    } else {
      Ember.$(window).on('mousemove.slider', { handle: handle }, this._onhorizontalmove.bind(this));
    }
  },
  _attachedVerticallMove(handle) {
    if (this._isSnapToTickEnabled() === true) {
      Ember.$(window).on('mousemove.slider', { handle: handle }, this._onverticalltickmove.bind(this));
    } else {
      Ember.$(window).on('mousemove.slider', { handle: handle }, this._onverticallmove.bind(this));
    }
  },
  _destory() {
    Ember.$('body').removeClass('fr-slider-move');
    Ember.$(window).off('mousemove.slider')
      .off('mousemove.slider')
      .off('mousemove.slider')
      .off('mouseup.slider');
  },
  _getDistanceValue() {
    let distinceValue = 0;

    if (0 <= this._minimumValue()) {
      distinceValue = this._maximumValue() - this._minimumValue();
    } else {
      distinceValue = Math.abs(this._minimumValue()) + Math.abs(this._maximumValue());
    }

    return distinceValue;
  },
  _getDistancePixel() {

    let _length = this._getTicks().length -1;

    if (_length === 0) {
      return 0;
    }

    return this._trackWidth() / _length;
  },
  _getIndexOfByTickValue(value) {
    const _ticks = this._getTicks();
    const item = _ticks.findBy(this.valuePropertyPath, value);

    return _ticks.indexOf(item);
  },
  _getPixelByTick() {
    const distanceValue = this._getDistanceValue();

    return (this._trackWidth() - this._thumbWidth()) / distanceValue;
  },
  _getTicks() {
    const _ticks = this.get('ticks');

    if (Ember.isEmpty(_ticks)) {
      return [];
    }

    return _ticks;
  },
  _inergerValue(newValue) {
    let _newValue = newValue;

    if (Ember.isEmpty(_newValue)) {
      return this._maximumValue();
    }

    if (_newValue > this._maximumValue()) {
      _newValue = this._maximumValue();
    } else if (_newValue < this._minimumValue()) {
      _newValue = this._minimumValue();
    }

    return parseInt(_newValue);
  },
  _isSnapToTickEnabled() {
    return this.get('isSnapToTickEnabled');
  },
  _isVerticalSlider() {
    return this._isHorizontalSlider() === false;
  },
  _isHorizontalSlider() {
    const _orientation = this.get('orientation');

    if (Ember.isEmpty(_orientation)) {
      return true;
    }

    return _orientation === 'horizontal';
  },
  _layoutChanged() {
    const distance = this._getDistancePixel();
    const labels = this.$('.slider-tick-label');

    labels.each(function (index, element) {

      const child = this.$(element).children();

      if (index === 0) {
        this.$(element).css('left', 0);
      } else if (index === labels.length - 1) {
        this.$(element).css('right', 0);
      } else {
        const distanceWidth = index * distance;
        const labelWidth = child.width() / 2;
        this.$(element).css('left', distanceWidth - labelWidth - this._thumbWidth());
      }

    }.bind(this));
  },
  _minimumValue() {
    const _minimumValue = this.get('minimum');

    if (Ember.isEmpty(_minimumValue)) {
      return 0;
    }

    return parseInt(_minimumValue);
  },
  _maximumValue() {
    const _maximumValue = this.get('maximum');

    if (Ember.isEmpty(_maximumValue)) {
      return 0;
    }

    return parseInt(_maximumValue);
  },
  _sliderSelection() {
    return this.$('.slider-selection');
  },
  _sliderThumb(selector) {

    if (Ember.isEmpty(selector)) {
      return this.$('.fr-slider-thumb');
    }

    return this.$(selector);

  },
  _sliderTrac() {
    return this.$('.fr-slider-trac');
  },
  _thumbWidth() {
    return parseInt(this._sliderThumb().eq(0).width(), 10);
  },
  _trackWidth() {
    return parseInt(this._sliderTrac().width(), 10);
  },
  _trackHeight() {
    return parseInt(this._sliderTrac().height(), 10);
  },
  _trackRect(pageX) {
    const trackleft = this._sliderTrac().offset().left;
    const tracwidth = this._trackWidth() - this._thumbWidth();
    const trackheight = this._trackHeight();
    const tracright = trackleft + this._trackWidth();

    return {
      left: trackleft,
      right: tracright,
      width: tracwidth,
      height: trackheight,
      relativeX: pageX - trackleft
    };
  },
  init() {
    this._super(...arguments);
    this.set('internalId', this.get('elementId'));
    this.set('_isTickPlacementIsBottom', this.tickPlacement === 'bottom');
    this.set('_isTickPlacementIsTop', this.tickPlacement === 'top');
    this.set('_isTickPlacementIsLeft', this.tickPlacement === 'left');
    this.set('_isTickPlacementIsRight', this.tickPlacement === 'right');
  },
  didInsertElement() {
    this._super(...arguments);

    //this._layoutChanged();
  },
  didRender(){
    // Tab control에서의 ReRendering 때문에 didRender에서 Label 위치 재 정의
    this._super(...arguments);
    this._layoutChanged();
  },
  willDestroyElement() {
    this._super(...arguments);

    this._destory();
  },
  actions: {
    onMouseDownAction(e) {

      if (e.which !== 1) {
        e.preventDefault();

        return false;
      }

      Ember.$('body').addClass('fr-slider-move');

      if (this._isHorizontalSlider() === true) {
        this._attachedHorizontalMove(this.$(e.currentTarget));
      } else {
        this._attachedVerticallMove(this.$(e.currentTarget));
      }

      Ember.$(window).on('mouseup.slider', this._onmouseup.bind(this));
    }
  }
});
