import Ember from 'ember';

export default Ember.Mixin.create({
  _getIndicator() {
    return this.$('> .item-box > .item > .item-indicator');
  },
  _getPresenter(){
    return this.$('> .item-box > .item > .item-presenter');
  },
  _ondraggable(e){
    /*
    this._super(...arguments);

    if (this.get('draggable')) {
      this._getPresenter().attr('draggable', true)
        .fr_draggable({
          dragId : 'tvdnd',
          dragstart : this._dragStart.bind(this),
          dragend : this._dragEnd.bind(this)
      });
    }
    */
  },
  _dragStart(e) {
    this.get('treeview')._raiseEvents('dragStart', e.dragEvent);
    if (!e.dragEvent.isDefaultPrevented()) {
      Ember.set(this.get('treeview'), 'dragItem', this.get('dataItem'));
      e.effectAllowed = 'move';
      e.dragEvent.dataTransfer.setData('text/plain', JSON.stringify(this.dataItem));
    }
    /*
    if ( e.dragEvent.isDefaultPrevented() === true) {
      e.cancel = true;
      return ;
    }
    e.dragEvent.dataTransfer.setData('text/plain', JSON.stringify(this.dataItem));
    e.effectAllowed = 'move';
    this.getTreeview().set('isDrop', false);
    */
  },
  _onDragEnter(e){
    this.get('treeview')._raiseEvents('dragEnter', e.dragEvent) ;
    /*
    if ( e.dragEvent.isDefaultPrevented() === true) {
      e.cancel = true;
      return ;
    }
    */
  },
  _onDragLeave(e){
    this.get('treeview')._raiseEvents('dragLeave', e.dragEvent) ;
    /*
    if ( e.dragEvent.isDefaultPrevented() === true) {
      e.cancel = true;
      return;
    }
    */
  },
  _dragEnd(e) {
    this.get('treeview')._raiseEvents('dragEnd', e.dragEvent);
    this._destroyDraggable();
    Ember.set(this.get('treeview'), 'dragItem', null);
    /*
    // Todo :2018-02-22 자신 위로 Drop 할 때는 _onDrop 이벤트를 타지 않기 때문에 삭제가 되면 안되어서 추가 하였습니다.
    if(this.getTreeview().get('isDrop')){
      if (Ember.isEmpty(this.getParent())) {
        this.getTreeview().get('itemsSource').removeObject(this.get('dataItem')) ;
      } else {
        this.getParent().get(`dataItem.${this.childrenMemberPath}`).removeObject(this.get('dataItem')) ;
      }
    }
    */
  },
  _onDrop(e){
    this.get('treeview')._raiseEvents('drop', e.dragEvent);
    if (!e.dragEvent.isDefaultPrevented()) {
      const dataItem = this.get('dataItem'), childrenMemberPath = this.get('childrenMemberPath');
      let dragItem = Ember.get(this.get('treeview'), 'dragItem'), dataItemChildren = Ember.get(dataItem, childrenMemberPath);

      if (Ember.isNone(dragItem)) {
        dragItem = JSON.parse(e.dragEvent.dataTransfer.getData('text/plain'));
        if (Ember.isArray(dataItemChildren)){
          dataItemChildren.addObject(dragItem);
        } else {
          dataItemChildren = Ember.A();
          dataItemChildren.addObject(dragItem);
          Ember.set(dataItem, childrenMemberPath, dataItemChildren);
        }
        this.expand();
      } else if (!this._getChilrenItems(Ember.get(dragItem, childrenMemberPath)).includes(dataItem)) {
        const itemPath = this.get('treeview')._getItemPath(dragItem), component = this._getComponent(this.$().closest('.fr-treeview').find(`li[data-item-path="${itemPath}"]`)), parentComponent = component.getParent();

        if (!Ember.isNone(parentComponent)) {
          Ember.get(Ember.get(parentComponent, 'dataItem'), childrenMemberPath).removeObject(dragItem);
        } else {
          Ember.get(this.get('treeview'), 'itemsSource').removeObject(dragItem);
        }
        if (Ember.isArray(dataItemChildren)){
          dataItemChildren.addObject(dragItem);
        } else {
          dataItemChildren = Ember.A();
          dataItemChildren.addObject(dragItem);
          Ember.set(dataItem, childrenMemberPath, dataItemChildren);
        }
        this.expand();
      }
    }
    /*
    e.dragEvent.preventDefault();
    e.dragEvent.stopPropagation();

    if ( e.cancel === true) {
      return;
    }

    const plainText = e.dragEvent.dataTransfer.getData('text/plain');
    const data = JSON.parse(plainText);

    if (this._parentToChild(data)) {
      e.cancel = true;
      return false ;
    }
    const childrens = this.get(`dataItem.${this.childrenMemberPath}`) ;

    if ( Ember.isEmpty(childrens)){
      this.set(`dataItem.${this.childrenMemberPath}`, Ember.A([]));
    }

    this.get(`dataItem.${this.childrenMemberPath}`).pushObject(data);
    this.getTreeview().set('isDrop', true);
    this.expand();
    */
  },
  _onDropIndicator(e){
    this.get('treeview')._raiseEvents('drop', e.dragEvent);
    if (!e.dragEvent.isDefaultPrevented()) {
      const dataItem = this.get('dataItem'), childrenMemberPath = this.get('childrenMemberPath');
      let dragItem = Ember.get(this.get('treeview'), 'dragItem'), dataItemChildren = Ember.get(dataItem, childrenMemberPath);

      if (Ember.isNone(dragItem)) {
        dragItem = JSON.parse(e.dragEvent.dataTransfer.getData('text/plain'));
        if (Ember.isArray(dataItemChildren)){
          dataItemChildren.addObject(dragItem);
        } else {
          dataItemChildren = Ember.A();
          dataItemChildren.addObject(dragItem);
          Ember.set(dataItem, childrenMemberPath, dataItemChildren);
        }
        this.expand();
      } else if (!this._getChilrenItems(Ember.get(dragItem, childrenMemberPath)).includes(dataItem)) {
        const itemPath = this.get('treeview')._getItemPath(dragItem), component = this._getComponent(this.$().closest('.fr-treeview').find(`li[data-item-path="${itemPath}"]`)), parentComponent = component.getParent();

        if (!Ember.isNone(parentComponent)) {
          Ember.get(Ember.get(parentComponent, 'dataItem'), childrenMemberPath).removeObject(dragItem);
        } else {
          Ember.get(this.get('treeview'), 'itemsSource').removeObject(dragItem);
        }
        if (Ember.isArray(dataItemChildren)){
          dataItemChildren.addObject(dragItem);
        } else {
          dataItemChildren = Ember.A();
          dataItemChildren.addObject(dragItem);
          Ember.set(dataItem, childrenMemberPath, dataItemChildren);
        }
        this.expand();
      }
    }
    /*
    e.dragEvent.preventDefault();
    e.dragEvent.stopPropagation();

    if ( e.cancel === true) {
      return;
    }

    const plainText = e.dragEvent.dataTransfer.getData('text/plain');
    const data = JSON.parse(plainText);

    if (this._parentToChild(data)) {
      e.cancel = true ;
      return false;
    }

    let childrens = null ;
    if (Ember.isEmpty(this.getParent())) {
      childrens = this.getTreeview().get('itemsSource') ;
    } else {
      childrens = this.getParent().get(`dataItem.${this.childrenMemberPath}`) ;
    }

    const currentIndex = childrens.indexOf( this.get('dataItem')) + 1 ;
    childrens.insertAt(currentIndex, data );
    this.getTreeview().set('isDrop', true);
    */
  },
  /*
  _parentToChild(data) {

    let stringData = JSON.stringify(this.dataItem);

    if ( JSON.stringify(data).indexOf( stringData ) > -1 ) {
      return true ;
    }

    return false;
  },
  */
  didInsertElement(){
    this._super(...arguments);

    if (this.get('_draggable')) {
      this._getIndicator().fr_droppable({
        activeClass : 'drag-over-item-indicator',
        dragenter : this._onDragEnter.bind(this),
        dragleave : this._onDragLeave.bind(this),
        drop : this._onDropIndicator.bind(this)
      });
      this._getPresenter().fr_droppable({
        activeClass : 'drag-over-item',
        dragenter : this._onDragEnter.bind(this),
        dragleave : this._onDragLeave.bind(this),
        drop : this._onDrop.bind(this)
      });
    }
  },
  willDestroyElement(){
    this._super(...arguments);

    this._getPresenter().fr_droppable('destroy');
    this._getIndicator().fr_droppable('destroy');
  }
});
