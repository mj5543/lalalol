import Ember from 'ember';

export default Ember.Mixin.create({
  //== Public Properties ==========================================================
  contextmenuService: Ember.inject.service('contextmenuService'),
  hasContextMenu: false,
  contextmenuOpening: null,
  //== Override Methods  ==========================================================
  willDestroyElement() {
    this._super(...arguments);

    this.get('contextmenuService').close();
  },
  contextMenu(e) {

    if (this.disabled) {
      return false;
    }

    if (Ember.isEmpty(Ember.get(this, 'contextmenu'))) {
      return false;
    }

    const arg = {
      'source': this,
      'dataItem': null,
      'originalSource': null,
      'originalEvent': e,
      'cancel':false,
    };

    this._onContextMenuOpening(arg);

    const events = this.get('contextmenuOpening');

    if (events) {
      events(arg);
    }

    if(arg.cancel === false) {
      this.get('contextmenuService').show({
        source: this,
        originalEvent: e,
        contextmenu: Ember.get(this, 'contextmenu'),
        arg: arg
      });
    }

    return false;
  },
  _onContextMenuOpening() {
    return null;
  }
});