import Ember from 'ember';

export default Ember.Mixin.create({
  _setCanUseSingleDrag() {
    this._internalCalendarItems = this.$('.fr-calendar-cell') ;

    this._internalCalendarItems
      .on('mousedown.calendar', this._onSingleRangeMouseDown.bind(this)) ;

  },
  _onSingleRangeMouseDown(e) {
    if (this._isRightClick(e)) {
      return false;
    } else {

      this._internalCalendarItems
        .on('mouseup.calendar', this._onSingleRangeMouseUp.bind(this))
        .on('mousemove.calendar', this._onSingleRangeMouseMove.bind(this));

      Ember.$(document).on('mouseup.calendar', this._onWindowMouseUp.bind(this));

      this._dragStart = this._internalCalendarItems.index(this.$(e.currentTarget));
      this._isDragging = true;

      if (typeof e.preventDefault != 'undefined') {
        e.preventDefault();
      }
      document.documentElement.onselectstart = function () {
        return false;
      };
    }
  },
  _onSingleRangeMouseMove(e) {
    if (this._isDragging) {
      this._dragEnd = this._internalCalendarItems.index(this.$(e.currentTarget));

      this._onSingleRangeSelect();
    }
  },
  _onSingleRangeMouseUp(e) {

    Ember.$(window).off('mouseup.calendar');

    if (this._isRightClick(e)) {
      return false;
    } else {
      this._dragEnd = this._internalCalendarItems.index(this.$(e.currentTarget));

      this._isDragging = false;
      if (this._dragEnd != 0) {
        this._onSingleRangeSelect();
      }

      if (this._dragEnd == this._dragStart) {
        this._internalCalendarItems.removeClass('calendar_day_rangesel');
      }

      this._onDateSelected(null) ;
    }
  },
  _onSingleRangeSelect() {

    this._internalCalendarItems.removeClass('calendar_day_rangesel');

    let items = null ;

    if (this._dragEnd + 1 < this._dragStart) {
      items = this._internalCalendarItems.slice(this._dragEnd, this._dragStart + 1);
    } else {
      items = this._internalCalendarItems.slice(this._dragStart, this._dragEnd + 1);
    }

    for ( let j = 0; j < items.length ; j++) {
      let $e = this.$(items.eq(j));

      if ( $e.hasClass('cal-d-disabled') === false) {
        $e.addClass('calendar_day_rangesel');
      }
    }
  }
});
