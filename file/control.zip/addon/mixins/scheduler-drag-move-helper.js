import Ember from 'ember';

export default Ember.Mixin.create({
  _draggables : null,
  _dragStart(e){

    e.stopPropagation();
    e.preventDefault();

    if ( this.$(e.target).is('.ui-resizable-handle')) {
      return ;
    }

    if ( this._onDragStart(e) === true ) {
      return ;
    }

    this._draggables = {
      x : e.clientX,
      y : e.clientY,
      currentCell : null
    };

    Ember.$(document)
      .on('mousemove.drag', this._dragMove.bind(this))
      .on('mouseup.drag', this._dragStop.bind(this));
  },
  _dragMove(e) {

    if ( e.which !== 1) {
      return ;
    }

    const $td = Ember.$(e.target) ;

    if ( $td.is('.fr-schedule-cell') === false) {
      return ;
    }

    if ( this._isDragGesture(e)) {

      if ( this.$().hasClass('fr-scheduler-taskitem-drag') === false){
        this.$().addClass('fr-scheduler-taskitem-drag');
      }
      this.$().offset({
        top : Ember.$(e.target).closest('tr').offset().top,
        left : $td.offset().left
      }).width($td.outerWidth() -1);

      this._draggables.currentCell = $td ;
    }
  },
  _dragStop(e){

    e.stopPropagation();
    e.preventDefault();

    this.$().removeClass('fr-scheduler-taskitem-drag');

    Ember.$(document).off('mousemove.drag').off('mouseup.drag');

    if ( this._isDragGesture(e) && !Ember.isEmpty( this._draggables.currentCell)) {
      this._onDragEnd(e, this._draggables);
    }

    return false;
  },
  _isDragGesture(e){
    return Math.abs(this._draggables.x - e.clientX) >= 8 || Math.abs(this._draggables.y - e.clientY) >= 8 ;
  },
  _dragDestroy(){

    this.$().off('mousedown.drag');
  },
  _canUseDrag() {

    this.$().on('mousedown.drag', this._dragStart.bind(this));
  }
});
