import Ember from 'ember';

export default Ember.Mixin.create({
  _appendloadData() {
    const tbodyTag = this.$('.calendar-area table tbody');
    // const scrollHeight = 220;
    
    tbodyTag.find('td').removeClass('cal-d-select').removeClass('cal-d-today');
    tbodyTag.find(`[data-day='${this.toDay.toStandardDateString()}']`).addClass('cal-d-today');
    if (this.get('selectionMode') === 'singleDate' && !Ember.isEmpty(this.selectedDate)) {
      tbodyTag.find(`[data-day='${this.selectedDate.toStandardDateString()}']`).addClass('cal-d-select');
    }
    this._appendPatternDays(tbodyTag);
    this._appendEventDays(tbodyTag);
    this._appendHolidays(tbodyTag);
    this._appendMemoData(tbodyTag);
    if (this.get('calendarMode') === 'month') {
      switch (this.get('selectionMode')) {
        case 'singleDate':
          break;
        case 'singleRange':
          this._setCanUseSingleDrag();
          break;
        case 'multiRange':
          this._setCanUseMultiDrag();
          break;
      }
    }
  },
  _appendPatternDays(tbodyTag) {
    const patterns = this.get('patternDays');

    if (!Ember.isEmpty(patterns)) {
      for (let i = 0; i < patterns.length; i++) {
        const dt = patterns.objectAt(i);
        const tdtag = tbodyTag.find(`[data-day='${dt.toStandardDateString()}']`);

        if (tdtag.hasClass('cal-d-off') === false) {
          tdtag.addClass('cal-d-pattern');
        }
      }
    }
  },
  _appendEventDays(tbodyTag) {

    const eventday = this.get('eventDays');

    if (!Ember.isEmpty(eventday)) {
      for (let i = 0; i < eventday.length; i++) {
        const dt = eventday.objectAt(i);
        const tdtag = tbodyTag.find(`[data-day='${dt.toStandardDateString()}']`);

        if (tdtag.hasClass('cal-d-off') === false) {
          tdtag.addClass('cal-d-event');
        }
      }
    }
  },
  _appendHolidays(tbodyTag) {
    const holidays = this.get('holiDays');

    if (!Ember.isEmpty(holidays)) {
      for (let i = 0; i < holidays.length; i++) {
        const tdtag = tbodyTag.find(`[data-day='${holidays.objectAt(i).toStandardDateString()}']`);

        if (!tdtag.hasClass('cal-d-off')) {
          tdtag.addClass('cal-d-holiday');
        }
      }
    }
  },
  _appendMemoData(tbodyTag) {

    const memodata = this.get('memoDatas');

    if (!Ember.isEmpty(memodata)) {
      for (let i = 0; i < memodata.length; i++) {
        const item = memodata.objectAt(i);
        const dt = Ember.get(item, this.memoToolTipDatePropertyPath);
        const tdtag = tbodyTag.find(`[data-day='${dt.toStandardDateString()}']`);

        if (tdtag.hasClass('cal-d-off') === false) {
          tdtag
            .addClass('cal-d-memo')
            .append(`<span class='mark'></span>`);
          tdtag.find('> .mark')
            .on('mouseenter', { 'title': Ember.get(item, this.memoToolTipTextPropertyPath) }, this._showToolTip.bind(this))
            .on('mouseleave', this._onmouseLeave.bind(this));
        }
      }
    }
  },
  willDestroyElement() {
    this.$('.mark').off('mouseenter').off('mouseleave');
    this._super(...arguments);
  },
});
