import Ember from 'ember';

export default Ember.Mixin.create({
  _destinationElementId: 'fr-wormhole-container',
  _targetElement: null,
  _pickerType: 'month',
  _minCalendarMode: 'month',
  _isTime: false,
  _isDate: true,
  _wasPickerType: null,
  hasDate: false,
  toDay: null,
  isGotFocusAutoSelect: false,
  calendarMode: 'month',
  dayofWeek: 'sunday',
  isOpen: false,
  dateFormat: '',
  minCalendarMode: 'decade',
  pickerType: 'date',
  calendarButtonVisibility: true,
  todayNavigationVisibility: true,
  dayOfWeekHeaderVisibility: false,
  navigationVisibility: false,
  patternDays: null,
  holiDays: null,
  eventDays: null,
  maxDate: null,
  minDate: null,
  disabledDates: null,
  placeholder: '',
  selectedDateChanged: null,
  isOpenChanged: null,
  mouseDoubleClick: null,
  _watchIsOpen: Ember.computed('isOpen', function () {
    const _open = this.get('isOpen');

    if (this.hasLoaded) {
      if (_open === true) {
        Ember.run.once(this, this._onCalendarOpened);
      } else {
        Ember.run.once(this, this._onCalendarClosed);
      }
    }
    return _open;
  }).readOnly(),
  _onCalendarClosed() {
    this.set('isOpen', false);
    this._raiseEvents('isOpenChanged', { 'source': this, 'selectedDate': this.get('selectedDate') });
  },
  _onCalendarOpened() {
    Ember.$('body').on('mousedown.datePicker', this._onBodyClick.bind(this));

    switch (this.pickerType) {
      case 'date':
        this.set('calendarMode', 'month');
        this.set('_pickerType', 'month');
        this.set('_minCalendarMode', this.minCalendarMode);
        this.set('_isDate', true);
        this.set('_isTime', false);
        this.set('hasDate', true);
        break;
      case 'dateTime':
        this.set('calendarMode', 'month');
        this.set('_pickerType', 'month');
        this.set('_minCalendarMode', this.minCalendarMode);
        this.set('_isDate', true);
        this.set('_isTime', true);
        this.set('hasDate', true);
        break;
      case 'time':
        this.set('_isDate', false);
        this.set('_isTime', true);
        this.set('hasDate', false);
        break;
      case 'year':
        this.set('calendarMode', 'decade');
        this.set('_pickerType', 'decade');
        this.set('_minCalendarMode', 'decade');
        this.set('_isDate', true);
        this.set('_isTime', false);
        this.set('hasDate', false);
        break;
      case 'yearMonth':
        this.set('calendarMode', 'year');
        this.set('_pickerType', 'year');
        this.set('_minCalendarMode', 'year');
        this.set('_isDate', true);
        this.set('_isTime', false);
        this.set('hasDate', false);
        break;
    }
    this.set('_currentTime', this.get('co_CommonService').getNow());

    this.set('isOpen', true);

    this._isOpenChanged();
    this._raiseEvents('isOpenChanged', { 'source': this, 'selectedDate': this.get('selectedDate') });
  },
  _onBodyClick(e) {

    if (this._isDatePicker(e)) {
      return false;
    }else {
      Ember.$('body').off('mousedown.datePicker');
    }

    this.calendarClose();
  },
  _dateParseExtra(date, format) {
    let year, month, day, hour, minute, second;
    let i = 0;
    let len = format.length;
    let f;

    for (i; i < len; i++) {
      f = format[i];

      if (/M/.test(f)) {
        month = parseInt(date[i]);

        let isMonth = month > 0 && month < 13;

        if (isMonth === false) {
          return null;
        }
      }

      if (/d/.test(f)) {
        day = parseInt(date[i]);

        let isDay = day > 0 && day < 32;

        if (isDay === false) {
          return null;
        }
      }

      if (/y/.test(f)) {
        year = parseInt(date[i]);

        let isYear = year > 1970 && year <= 9999;

        if (isYear === false) {
          return null;
        }
      }

      if (/H/.test(f)) {
        hour = parseInt(date[i]);

        let isHour = hour >= 0 && hour < 24;

        if (isHour === false) {
          return null;
        }
      }

      if (/m/.test(f)) {
        minute = parseInt(date[i]);

        let isHour = minute >= 0 && minute < 60;

        if (isHour === false) {
          return null;
        }
      }

      if (/s/.test(f)) {
        second = parseInt(date[i]);

        let isSecond = second >= 0 && second < 60;

        if (isSecond === false) {
          return null;
        }
      }
    }

    let newDate = null;

    switch (this.pickerType) {
      case 'date':
        newDate = new Date(year, month - 1, day, 0, 0, 0);
        break;
      case 'dateTime':
        newDate = new Date(year, month - 1, day, hour, minute, 0);
        break;
      case 'time':
        newDate = new Date(1970, 0, 1, hour, minute, 0);
        break;
      case 'year':
        newDate = new Date(year, 0, 1, 0, 0, 0);
        break;
      case 'yearMonth':
        newDate = new Date(year, month - 1, 1, 0, 0, 0);
        break;
    }

    if (this.isValidDate(newDate)) {
      return newDate;
    }

    return null;
  },
  _formatTextToDate(text, value) {
    let userFormat = this._getRegionalFormat();
    let res = /[^MdyHms]/.exec(userFormat);
    let delimiter = Ember.isEmpty(res) ? '' : res[0];
    let separators = Ember.isEmpty(delimiter) ? [' ', ':'] : [delimiter, ' ', ':',];
    let regex = new RegExp(separators.join('|'), 'g');
    let theFormat = userFormat.split(regex);
    let theDate = text.split(regex);

    return this._dateParseExtra(theDate, theFormat);
  },
  _getNowDate() {
    let dt = this.get('co_CommonService').getNow();

    return new Date(dt.getFullYear(), dt.getMonth(), dt.getDate(), 0, 0, 0, 0);
  },
  _getPickerTypeDate(pickerType, date, time) {

    if (Ember.isEmpty(date) && pickerType !== 'time') {
      return null;
    }

    if (Ember.isEmpty(time)) {
      time = new Date(1900, 0, 1, 0, 0, 0);
    }

    switch (pickerType) {
      case 'date':
        return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 0, 0);
      case 'dateTime':
        return new Date(date.getFullYear(), date.getMonth(), date.getDate(), time.getHours(), time.getMinutes(), 0);
      case 'time':
        return new Date(time.getFullYear(), time.getMonth(), time.getDate(), time.getHours(), time.getMinutes(), 0);
      case 'year':
        return new Date(date.getFullYear(), 0, 1, 0, 0, 0);
      case 'yearMonth':
        return new Date(date.getFullYear(), date.getMonth(), 1, 0, 0, 0);
    }
  },
  _onStateChanged(element, isSucess, isError) {

    //this._inputClassChange(element, isSucess, isError);

    element.removeClass('inp-time').removeClass('inp-date').removeClass('inp-control');

    if (this.get('calendarButtonVisibility') === true) {

      if (this.get('pickerType') === 'time') {
        element.addClass('inp-time');
      } else {
        element.addClass('inp-date');
      }
    }

    if (this.get('navigationVisibility') === true) {
      element.addClass('inp-control');
    }
  },
  _getDisplayText(format, date) {

    if (Ember.isEmpty(date)) {
      return '';
    }

    const locale = this.get('fr_I18nService').get('currentLocale');

    if (Ember.isEmpty(format)) {
      if (this.pickerType === 'year') {
        return new Intl.DateTimeFormat(locale, { year: 'numeric' }).format(date);
      } else if (this.pickerType === 'yearMonth') {
        return new Intl.DateTimeFormat(locale, { year: 'numeric', month: '2-digit' }).format(date);
      } else if (this.pickerType === 'date') {
        return this.get('fr_I18nService').formatDate(date, 'd');
      } else if (this.pickerType === 'dateTime') {
        return this.get('fr_I18nService').formatDate(date, 'g');
      } else if (this.pickerType === 'time') {
        return this.get('fr_I18nService').formatDate(date, 't');
      }
    }

    return this.get('fr_I18nService').formatDate(date, this.dateFormat);
  },
  _getRegionalFormat() {
    const regional = this.get('fr_I18nService').getRegional();
    let format = '';

    switch (this.pickerType) {
      case 'year':
        format = Ember.get(regional, 'yearFormat');
        break;
      case 'yearMonth':
        format = Ember.get(regional, 'monthForamt');
        break;
      case 'date':
        format = Ember.get(regional, 'dateFormat');
        break;
      case 'dateTime':
        format = Ember.get(regional, 'dateTimeFormat');
        break;
      case 'time':
        format = Ember.get(regional, 'timeFormat');
        break;
    }

    return format;
  },
  _getMaskFormat(format) {
    return this._getRegionalFormat().replace(/yyyy/, '9999')
      .replace(/MM/, '99')
      .replace(/dd/, '99')
      .replace(/HH/, '99')
      .replace(/mm/, '99')
      .replace(/ss/, '99');
  },
  _isDatePicker(e) {

    let element = Ember.$(e.target);

    while (!Ember.isEmpty(element.get(0).tagName)) {
      if (element.get(0).tagName === "INPUT") {
        return false;
      }

      if (element.hasClass('fr-datepicker-calendar')) {
        return true;
      }

      if (element.hasClass('fr-datepicker') === true) {

        if (element.attr('id') === this.$().attr('id')) {
          return true;
        } else {
          return false;
        }
      }
      element = Ember.$(element).parent();
    }
    return false;
  },
  _trySetToday() {
    if (Ember.isEmpty(this.toDay)) {
      this.set('toDay', this._getNowDate());
    }
  },
  calendarClose() {
    this.set('isOpen', false);
  },
  isValidDate(date) {
    if (Object.prototype.toString.call(date) === '[object Date]') {
      if (isNaN(date.getTime())) {
        return false;
      }else {
        return true;
      }
    }

    return false;
  },
  willDestroyElement() {
    this._super(...arguments);

    Ember.$('body').off('mousedown.datePicker');
  },
});
