import Ember from 'ember';

export default Ember.Mixin.create({
  _handler : null,
  _draggable : null,
  _options : null,
  _getMousePos(e) {

    let pos = { x: 0, y: 0, width: 0, height: 0, relativeY : 0 };
    if (typeof e.clientX === "number") {
      pos.x = e.clientX;
      pos.y = e.clientY;
      pos.width = 0;
      pos.height = 0;
    } else if (e.originalEvent.touches) {
      pos.x = e.originalEvent.touches[0].clientX;
      pos.y = e.originalEvent.touches[0].clientY;
      pos.width = 0;
      pos.height = 0;
    } else {
      return null;
    }
    return pos;
  },
  _getHandle(selector, el) {
    if (selector && selector.trim()[0] === ">") {
      selector = selector.trim().replace(/^>\s*/, "");
      return el.find(selector);
    }
    return selector ? this.$(selector) : el;
  },
  _noop(e) {
    e.stopPropagation();
    e.preventDefault();
  },
  _startTopDragging(e) {

    this._draggable = {
      startPos : this._getMousePos(e),
      startTransition : null,
      startCursor : null,
      originalTop : null,
      resizeWith : 'top'
    } ;

    this._startDragging(e);
  },
  _startBottomDragging(e){

    this._draggable = {
      startPos : this._getMousePos(e),
      startTransition : null,
      startCursor : null,
      originalTop : null,
      resizeWith : 'bottom'
    } ;

    this._startDragging(e);
  },
  _startLeftDragging(e) {

    this._draggable = {
      startPos : this._getMousePos(e),
      startTransition : null,
      startCursor : null,
      originalTop : null,
      resizeWith : 'left'
    } ;

    this._startDragging(e);
  },
  _startRightDragging(e){

    this._draggable = {
      startPos : this._getMousePos(e),
      startTransition : null,
      startCursor : null,
      originalTop : null,
      resizeWith : 'bottom'
    } ;

    this._startDragging(e);
  },
  _startDragging(e) {
    if ( e.preventDefault ) {
      e.preventDefault();
    }

    this._draggable.startPos.width = this._dragHandler.width();
    this._draggable.startPos.height = this._dragHandler.height();

    this._draggable.startCursor = this._dragHandler.css('cursor') ;
    this._draggable.originalTop = parseFloat( this._dragHandler.css('top'), 10);

    if ( !Ember.isEmpty( this._options.onDragStart)) {
      if (this._options.onDragStart(e, this._dragHandler, this._draggable) === false) {
        return;
      }
    }

    this._options.dragFunc = this._doDrag;

    Ember.$(document).bind('mousemove.rsz', this._options.dragFunc.bind(this));
    Ember.$(document).bind('mouseup.rsz', this._stopDragging.bind(this));

    if (window.Touch || navigator.maxTouchPoints) {
      Ember.$(document).bind('touchmove.rsz', this._options.dragFunc.bind(this));
      Ember.$(document).bind('touchend.rsz', this._stopDragging.bind(this));
    }

    Ember.$(document).bind('selectstart.rsz', this._noop);
  },
  _doDrag(e) {
    let pos = this._getMousePos(e), newWidth, newHeight, newTop;

    if (this._draggable.resizeWith === 'left') {
      newWidth = this._draggable.startPos.width - pos.x + this._draggable.startPos.x;
    } else if (this._draggable.resizeWith === 'right') {
      newWidth = this._draggable.startPos.width + pos.x - this._draggable.startPos.x;
    }

    if (!this._options.onDrag || this._options.onDrag(e, this._dragHandler, newWidth, newHeight, this._options) !== false) {

      if (this._draggable.resizeWith === 'bottom' ) {
        const movedPosition = pos.y - this._draggable.startPos.y ;
        newHeight = this._draggable.startPos.height + movedPosition;
        newHeight = Math.floor( newHeight / 10) * 10 ;
        if ( newHeight % 20 === 0 && movedPosition > 0 ) {
          this._dragHandler.height(newHeight);
        }
      }

      if (this._draggable.resizeWith === 'top') {
        //newHeight = this._draggable.startPos.height - pos.y + this._draggable.startPos.y;
        const movedPosition = pos.y - this._draggable.startPos.y ;
        if ( movedPosition < 0 ) {
          if ( Math.abs(movedPosition) > 10 ) {
            const newTop = Math.floor( (this._draggable.originalTop + movedPosition ) / 10) * 10 ;
            const absMmovedPosition = Math.abs( Math.floor(movedPosition / 10) * 10 );
            newHeight = Math.floor( (this._draggable.startPos.height + absMmovedPosition) / 10 ) * 10 ;
            if ( newTop % 20 === 0 && newHeight % 20 === 0 ) {
              this._dragHandler.css( { 'top' : newTop, 'height' : newHeight });
            }
          }
        }
      }
      if ( this._draggable.resizeLeft === 'left' ) {
        this._dragHandler.width(newWidth);
      }

      if (this._draggable.resizeRight === 'right' ) {
        this._dragHandler.width(newWidth);
      }
    }
  },
  _stopDragging(e) {
    e.stopPropagation();
    e.preventDefault();

    Ember.$(document).unbind('mousemove.rsz');
    Ember.$(document).unbind('mouseup.rsz');

    if (window.Touch || navigator.maxTouchPoints) {
      Ember.$(document).unbind('touchmove.rsz');
      Ember.$(document).unbind('touchend.rsz');
    }
    Ember.$(document).unbind('selectstart.rsz', this._noop);

    if (!Ember.isEmpty(this._options.onDragEnd)){
      this._options.onDragEnd(e, this._dragHandler, this._options);
    }

    this._draggable = null;
    return false;
  },
  destroy() {
    this._getHandle('.ui-resizable-top', this._dragHandler).off('mousedown.rsz');
    this._getHandle('.ui-resizable-bottom', this._dragHandler).off('mousedown.rsz');
    this.$('.ui-resizable-handle').remove();
  },
  canUseResize(el, option) {

    this._options = option ;
    el.append('<div class="ui-resizable-handle ui-resizable-w ui-resizable-left" style="z-index: 90;cursor:' + ( option.resizeLeft === true ? "w-resize" : "default" ) + '" ></div>');
    el.append('<div class="ui-resizable-handle ui-resizable-s ui-resizable-top" style="z-index: 90;cursor:' + ( option.resizeTop === true ? "s-resize" : "default" ) + '"></div>');
    el.append('<div class="ui-resizable-handle ui-resizable-w ui-resizable-right" style="z-index: 90;cursor:' + ( option.resizeRight === true ? "w-resize" : "default" ) + '"></div>');
    el.append('<div class="ui-resizable-handle ui-resizable-s ui-resizable-bottom" style="z-index: 90;cursor:' + ( option.resizeBottom === true ? "s-resize" : "default" ) + '"></div>');

    if ( option.resizeTop === true) {
      this._getHandle('.ui-resizable-top', el).on('mousedown.rsz', this._startTopDragging.bind(this));
    }

    if ( option.resizeBottom === true) {
      this._getHandle('.ui-resizable-bottom', el).on('mousedown.rsz', this._startBottomDragging.bind(this));
    }

    this._dragHandler = el ;
  }
});
