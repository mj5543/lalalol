import Ember from 'ember';

export default Ember.Mixin.create({
  _calendarId: '',
  _calendars: null,
  _decade: null,
  _dragEnd: 0,
  _dragStart: 0,
  _isDragging: false,
  _isEmbedded: true,
  _isMouseDown: false,
  _internalCalendarItems: null,
  _years: null,
  _yyyymmddToDate(str) {
    const tmp = str.split('-');

    const year = parseInt(tmp[0]);
    const month = parseInt(tmp[1]) - 1;
    const day = parseInt(tmp[2]);

    return new Date(year, month, day);
  },
  _isRightClick(e) {
    if (e.which) {
      return e.which == 3;
    } else if (e.button) {
      return e.button == 2;
    } else{
      return false;
    }
  },
  _onWindowMouseUp() {

    this._isDragging = false;

    this._internalCalendarItems
      .off('mouseup.calendar')
      .off('mousemove.calendar');

    document.documentElement.onselectstart = function () {
      return true;
    };

    Ember.$(document).off('mouseup.calendar');
  },
  _getRangeFromTo() {
    let fromDate = this.$(this._internalCalendarItems.eq(this._dragStart)).data("day");
    let toDate = this.$(this._internalCalendarItems.eq(this._dragEnd)).data("day");

    if (this._dragEnd + 1 < this._dragStart) {
      fromDate = this.$(this._internalCalendarItems.eq(this._dragEnd)).data("day");
      toDate = this.$(this._internalCalendarItems.eq(this._dragStart)).data("day");

      if (fromDate == "") {
        for (let i = this._dragEnd; i < this._dragStart; i++) {
          fromDate = this.$(this._internalCalendarItems.eq(i)).data("day");

          if (fromDate != "") {
            break;
          }
        }
      }

      if (toDate == "") {
        for (let i = this._dragStart; i > 0; i--) {
          toDate = this.$(this._internalCalendarItems.eq(i)).data("day");

          if (toDate != "") {
            break;
          }
        }
      }

    } else {
      if (fromDate == "") {
        for (let i = this._dragStart; i < this._dragEnd; i++) {
          fromDate = this.$(this._internalCalendarItems.eq(i)).data("day");

          if (fromDate != "") {
            break;
          }
        }
      }

      if (toDate == "") {
        for (let i = this._dragEnd; i > 0; i--) {
          toDate = this.$(this._internalCalendarItems.eq(i)).data("day");

          if (toDate != "") {
            break;
          }
        }
      }
    }


    if (fromDate == "" || toDate == "") {
      this._internalCalendarItems.removeClass('calendar_day_rangesel');
      return false;
    }

    const from = this._yyyymmddToDate(fromDate);
    const to = this._yyyymmddToDate(toDate);

    const items = Ember.A([]);

    for (let d = from; d <= to; d.setDate(d.getDate() + 1)) {
      items.pushObject(new Date(d));
    }
  }
});
