import Ember from 'ember';

export default Ember.Service.extend({
  init(){
    this._super(...arguments);
  },
  show(options) {
    this.set('options', options);
  },
  close() {
    let options = this.get('options');

    this.set('options', null);
    this._releaseObjectProperty(options);
    options = null;
  },
  _releaseObjectProperty(obj) {
    if (obj instanceof Object) {
      Object.getOwnPropertyNames(obj).forEach(function (prop) {
        Ember.set(obj, prop, null);
      });
    }
  },
});