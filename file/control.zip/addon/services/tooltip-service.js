import Ember from 'ember';

export default Ember.Service.extend({
  selector: '.tip',
  position: null,
  tip: null,
  timer: null,
  currentElement: null,
  target: null,
  init() {
    this._super(...arguments);
    if(typeof this.get('selector') === 'string') {
      this.selector = selector;
      this.position = position || 'top';
      this.set('target', null);
      this.set('currentElement', null);
    }
  },
  popper() {
    const target = this.$('.tip');
    target.bind('mouseover', this._on(target));
  },
  offset(el) {
    const box = el.getBoundingClientRect();
    return {
      top: box.top + Ember.$(window).pageYOffset,
      left: box.left + Ember.$(window).pageXOffset,
      width: box.width,
      height: box.height
    };
  },
  _on(event) {
    // if(this.currentElement || this.tip) return;
    if (this.get('currentElement')) {
      return;
    }

    this.target = event.target.closest(this.get('selector'));
    if (!this.get('target')) {
      return;
    }
    event.preventDefault();

    // this.currentElement = this.target;
    this.set('currentElement', this.get('target'));
    this.set('target', event.target.closest(this.get('selector')));
    this.target = event.target.closest(this.get('selector'));
    this.show(this.get('target'), this.get('position'));
  },
  _off(event) {
    if (!this.currentElement || !this.tip) {
      return;
    }
    let relatedTarget = event.relatedTarget;
    if(relatedTarget) {
      while(relatedTarget) {
        if(relatedTarget === this.currentElement) {
          return;
        }
        relatedTarget = relatedTarget.parentNode;
      }
    }
    this.currentElement = null;
    this.hide();
  },
  show(target, position = 'bottom') {
    // if(this.tip) return;
    if (this.get('timer')) {
      clearTimeout(this.get('timer'));
    }
    if (!this.get('tip')) {
      // this.tip = Object.assign(document.createElement('div'), {
      //   'className': 'tipster',
      //   'innerHTML': target.getAttribute('data-tooltip')
      // });

      // document.body.appendChild(this.tip);
      this.tip = Ember.$('<div class="tipster"></div>').append(target.attr('data-tooltip'));
    } else {
      this.tip.className = 'tipster';
      this.tip.style.opacity = 0;
      this.tip.style.right = 'auto';
      this.tip.style.left = 'auto';
      this.tip.innerHTML = target.getAttribute('data-tooltip');
    }

    const coords = this.offset(target);
    const targetWidth = target.offsetWidth;
    const tipWidth = this.tip.offsetWidth;

    if(coords.left > document.body.clientWidth - targetWidth - 30) {
      this.tip.style.right = '15px';
      this.tip.classList.add('tipster--arrow-right');
    }else if(coords.left > (tipWidth / 2) ) {
      this.tip.style.left = coords.left - (tipWidth / 2) + (targetWidth / 2) + 'px';
      this.tip.classList.add('tipster--arrow-center');
    }else {
      this.tip.style.left = coords.left + 'px';
      this.tip.classList.add('tipster--arrow-left');
    }

    if(position === 'bottom') {
      this.tip.style.top = coords.top + target.offsetHeight + 10 + 'px';
    } else {
      this.tip.classList.add('tipster--arrow-top');
      this.tip.style.top = coords.top - this.tip.offsetHeight - 10 + 'px';
    }

    setTimeout(() => {
      this.tip.style.opacity = 1;
      this.tip.style.pointerEvents = 'none';
    }, 10);
  },
  hide() {
    if(!this.tip) {
      return;
    }

    if(this.timer) {
      clearTimeout(this.timer);
    }
    this.tip.style.opacity = 0;

    this.timer = setTimeout(() => {
      document.body.removeChild(this.tip);
      this.tip = null;
    }, 100);

  },
  destroy() {
    this.tip = null;
    this.timer = null;
    if(this.selector) {
      this.selector = null;
      this.position = null;
      this.target = null;
      this.currentElement = null;

      document.body.removeEventListener('mouseover', this.on.bind(this));
      document.body.removeEventListener('mouseout', this.off.bind(this));
    }
  }

});