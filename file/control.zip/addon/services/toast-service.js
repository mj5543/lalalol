import Ember from 'ember';

export default Ember.Service.extend({
  toastInfo: null,
  toast: null,
  listener: null,
  toastId: null,
  previousToast: null,
  container: null,
  init() {
    this._super(...arguments);
    this.set('toast', Ember.Object.create({
      clear: this.clear,
      remove: this.remove,
      getContainer: this.getContainer,
      options: {},
      subscribe: this.subscribe,
      save: this.save,
      load: this.load,
      message: this.message,
      error: this.error,
      notify: this.notify,
      delete: this.delete,
      new: this.new,
      refresh: this.refresh
    }));
    this.set('toastId', 0);
  },
  toastr({type, content, title, option}) {
    const toastType = {
      save: 'save',
      load: 'load',
      message: 'message',
      error: 'error',
      notify: 'notify',
      delete: 'delete',
      new: 'new',
      refresh: 'refresh'
    };
    return this.notify({
      type: toastType[type] ? toastType[type] : 'save',
      iconClass: this.getOptions().iconClasses[type],
      message: String(content),
      optionsOverride: option,
      title: String(title)
    });
  },
  getContainer(options, create) {
    let option = options;
    if (!option) {
      option = this.getOptions();
    }
    this.set('container', Ember.$('#' + options.containerId));
    if (this.get('container').length) {
      return this.get('container');
    }
    if (create) {
      this.set('container', this.createContainer(option));
    }
    return this.get('container');
  },
  subscribe(callback) {
    this.set('listener', callback);
  },
  clear(toastElement, clearOptions) {
    const options = this.getOptions();
    if (!this.get('container')) {
      this.getContainer(options);
    }
    if (!this.clearToast(toastElement, options, clearOptions)) {
      this.clearContainer(options);
    }
  },
  remove(toastElement) {
    const options = this.getOptions();
    if (!this.get('container')) {
      this.getContainer(options);
    }
    if (toastElement && this.$(':focus', toastElement).length === 0) {
      this.removeToast(toastElement);
      return;
    }
    if (this.get('container').children().length) {
      this.get('container').remove();
    }
  },
  clearContainer(options) {
    var toastsToClear = this.get('container').children();
    for (var i = toastsToClear.length - 1; i >= 0; i--) {
      this.clearToast(this.$(toastsToClear[i]), options);
    }
  },
  clearToast(toastElement, options, clearOptions) {
    const force = clearOptions && clearOptions.force ? clearOptions.force : false;
    if (toastElement && (force || this.$(':focus', toastElement).length === 0)) {
      toastElement[options.hideMethod]({
        duration: options.hideDuration,
        easing: options.hideEasing,
        complete: function () {
          this.removeToast(toastElement);
        }
      });
      return true;
    }
    return false;
  },
  createContainer(options) {
    this.set('container', Ember.$('<div/>').attr('id', options.containerId).addClass(options.positionClass));
    Ember.$(options.target).parent().append(this.get('container'));

    return this.get('container');
  },
  getOptions() {
    return Object.assign({}, this.getDefaults(), this.get('toast').options);
  },
  getDefaults() {
    return {
      tapToDismiss: true,
      toastClass: 'toast',
      containerId: 'toast-container',
      debug: false,
      showMethod: 'fadeIn',
      showDuration: 300,
      showEasing: 'swing',
      onShown: false,
      hideMethod: 'fadeOut',
      hideDuration: 500,
      hideEasing: 'swing',
      onHidden: false,
      closeMethod: false,
      closeDuration: false,
      closeEasing: false,
      closeOnHover: true,
      closeButton: false,
      extendedTimeOut: 1000,
      iconClasses: {
        save: 'toast-save',
        load: 'toast-load',
        message: 'toast-message',
        error: 'toast-error',
        notify: 'toast-notify',
        delete: 'toast-delete',
        new: 'toast-new',
        refresh: 'toast-refresh'
      },
      iconClass: 'toast-save',
      positionClass: 'toast-bottom-center',
      timeOut: 4000,
      titleClass: 'toast-title',
      messageClass: 'toast-contents',
      target: '#max-wormhole-container',
      closeHtml: '<button type="button">&times;</button>',
      closeClass: 'toast-close-button',
      newestOnTop: true,
      preventDuplicates: false,
      rtl: false
    };
  },
  removeToast(toastElement) {
    if (!this.get('container')) {
      this.set('container', this.getContainer());
      // container = this.getContainer();
    }
    if (toastElement.is(':visible')) {
      return;
    }
    toastElement.remove();
    // toastElement = null;
    if (this.get('container').children().length === 0) {
      this.get('container').remove();
      this.set('previousToast', null);
    }
  },
  publish(args) {
    if (!this.get('listener')) {
      return;
    }
    this.set('listener', args);
  },
  notify(map) {
    let options = this.getOptions();
    let iconClass = map.iconClass || options.iconClass;

    if (typeof map.optionsOverride !== 'undefined') {
      options = Object.assign(options, map.optionsOverride);
      iconClass = map.optionsOverride.iconClass || iconClass;
    }
    const shouldExit = (optionsParam, mapParam) => {
      if (optionsParam.preventDuplicates) {
        if (mapParam.message === this.get('previousToast')) {
          return true;
        } else {
          this.set('previousToast', mapParam.message);
        }
      }
      return false;
    };
    if (shouldExit(options, map)) {
      return;
    }
    this.toastId++;
    this.set('container', this.getContainer(options, true));
    // container = this.getContainer(options, true);
    //let intervalId = null;
    const toastElement = Ember.$('<div/>');
    const titleElement = Ember.$('<div/>');
    const messageElement = Ember.$('<div/>');
    const closeElement = Ember.$(options.closeHtml);
    const response = {
      toastId: this.get('toastId'),
      state: 'visible',
      startTime: new Date(),
      options: options,
      map: map
    };
    const setTitle = () => {
      if (map.title) {
        var suffix = map.title;
        titleElement.append(suffix).addClass(options.titleClass);
        toastElement.append(titleElement);
      }
    };
    const setSequence = () => {
      if (options.newestOnTop) {
        this.get('container').prepend(toastElement);
      } else {
        this.get('container').append(toastElement);
      }
    };
    const hideToast = (override) => {
      const method = override && options.closeMethod !== false ? options.closeMethod : options.hideMethod;
      const duration = override && options.closeDuration !== false ?
        options.closeDuration : options.hideDuration;
      const easing = override && options.closeEasing !== false ? options.closeEasing : options.hideEasing;
      if (Ember.$(':focus', toastElement).length && !override) {
        return;
      }
      return toastElement[method]({
        duration: duration,
        easing: easing,
        complete: () => {
          this.removeToast(toastElement);
          //clearTimeout(intervalId);
          if (options.onHidden && response.state !== 'hidden') {
            options.onHidden();
          }
          response.state = 'hidden';
          response.endTime = new Date();
          this.publish(response);
        }
      });
    };
    function setIcon() {
      if (map.iconClass) {
        toastElement.addClass(options.toastClass).addClass(iconClass);
      }
    }
    function setMessage() {
      if (map.message) {
        var suffix = `${map.message}`;
        messageElement.append(suffix).addClass(options.messageClass);
        toastElement.append(messageElement);
      }
    }
    function setCloseButton() {
      if (options.closeButton) {
        closeElement.addClass(options.closeClass).attr('role', 'button');
        toastElement.prepend(closeElement);
      }
    }
    function setRTL() {
      if (options.rtl) {
        toastElement.addClass('rtl');
      }
    }
    function setAria() {
      var ariaValue = '';
      switch (map.iconClass) {
        case 'toast-success':
        case 'toast-info':
          ariaValue = 'polite';
          break;
        default:
          ariaValue = 'assertive';
      }
      toastElement.attr('aria-live', ariaValue);
    }
    function displayToast() {
      toastElement.hide();
      toastElement[options.showMethod]({
        duration: options.showDuration,
        easing: options.showEasing,
        complete: options.onShown
      });
      if (options.timeOut > 0 && !options.closeButton) {
        Ember.run.later(hideToast, options.timeOut);
        //intervalId = setTimeout(hideToast, options.timeOut);
      }
    }
    function stickAround() {
      //clearTimeout(intervalId);
      toastElement.stop(true, true)[options.showMethod]({
        duration: options.showDuration,
        easing: options.showEasing
      });
    }
    function delayedHideToast() {
      if (options.timeOut > 0 || options.extendedTimeOut > 0) {
        Ember.run.later(hideToast, options.timeOut);
        //intervalId = setTimeout(hideToast, options.extendedTimeOut);
      }
    }
    function handleEvents() {
      if (options.closeOnHover) {
        if(!options.closeButton) {
          toastElement.hover(stickAround, delayedHideToast);
        }
      }
      if (!options.onclick && options.tapToDismiss) {
        toastElement.click(hideToast);
      }
      if (options.closeButton && closeElement) {
        closeElement.click(function (event) {
          if (event.stopPropagation) {
            event.stopPropagation();
          } else if (typeof event.cancelBubble !== 'undefined' && !event.cancelBubble) {
            event.cancelBubble = true;
          }

          if (options.onCloseClick) {
            options.onCloseClick(event);
          }

          hideToast(true);
        });
      }
      if (options.onclick) {
        toastElement.click(function (event) {
          options.onclick(event);
          hideToast();
        });
      }
    }
    function personalizeToast() {
      setIcon();
      setTitle();
      setMessage();
      setCloseButton();
      setRTL();
      setSequence();
      setAria();
    }
    personalizeToast();
    displayToast();
    handleEvents();
    this.publish(response);

    return toastElement;
  }
});
