import { inject as service } from '@ember/service';
import { isEmpty } from '@ember/utils';
import Mixin from '@ember/object/mixin';
import { A as emberA } from '@ember/array';

export default Mixin.create({
  model: null,
  isLotPopupOpen: false,
  isAddPopup: false,
  isNewPopup: false,
  isUpdatePopup: false,
  lotLevelCombobox: null,
  lotLevelSource: null,
  examinationRoomsEquipmentsList: null,
  isMaterialsShowLoader: false,
  lotGridData: null,
  qualityManagementService: service('laboratory-quality-management-service'),


  onPropertyInit() {
    this._super(...arguments);

    this.setStateProperties([
      'model',
      'examinationRoomList',
      'isMaterialsShowLoader',
      'lotLevelCombobox'

    ]);

    if(this.hasState()===false) {

      this.set('model', {
        selectedMaterialItem: null,
        selectedLotItem: null,
        lotEditItems: {
          lotNumber: null,
          lotTypeCode: null,
          effectiveDatetime: null,
          startDatetime: null,
          endDatetime: null,
          barcodeNumber: null,
        },
      });
      this.set('lotLevelSource', emberA());
    }
  },
  actions: {
    onLoadLotLevelCombobox(e) {
      this.set('lotLevelCombobox', e.source);
    },

    onNewLotPopupOpen() {
      this.set('model.lotEditItems.startDatetime', this.get('selectedFromDate'));
      this.set('isNewPopup', true);
      this.set('isLotPopupOpen', true);
    },

    onLotPopupOpenedAction() {
      if (this.get('isUpdatePopup') === true || this.get('isAddPopup') === true) {
        const selectedLotItem = this.get('model.selectedLotItem');
        this.set('model.lotEditItems.lotTypeCode', selectedLotItem.lotType.code);
      }
    },
    onAddLotPopupOpen() {
      const selectedLotItem = this.get('model.selectedLotItem');
      if (selectedLotItem) {
        this.set('isAddPopup', true);
        this.setLotEditItems(selectedLotItem);
        this.set('isLotPopupOpen', true);
      }
    },

    onLotPopupClosedAction() {
      this.set('isUpdatePopup', false);
      this.set('isAddPopup', false);
      this.set('isNewPopup', false);
      this.lotEditItemsReset();
    },

    onLotsSaveClick() {
      this.set('inputLotNumber', this.get('model.lotEditItems.lotNumber'));
      this._updateLotItem();
    },

    onDeleteLotItem() {
      if(isEmpty(this.get('model.selectedLotItem'))) {
        this.showWarningMessage(this.getLanguageResource('9260', 'F', '항목을 선택하세요.'), 2000);
        return;
      } else if(!isEmpty(this.get('examinationGridData'))) {
        this.showWarningMessage(this.getLanguageResource('9235', 'F', '', '삭제할 수 없습니다.'), 2000);
        return;
      }

      this._getLotDeleteConfirm();
      // this._deleteLotItem();
    }

  },

  getMateriasLotList() {
    //override
  },

  getLotTypeCodeList() {
    const param = {classificationCode: 'LotTypeCode'};
    this.get('qualityManagementService').getLaboratoryBusinessCode(param).then(result => {
      this.set('lotLevelSource', result);
    });

  },

  async _updateLotItem() {
    try {
      const param = this.getLotUpdateParam();
      if (isEmpty(param)) {
        return;
      }
      let promise = null;
      if (this.get('isAddPopup') === true || this.get('isNewPopup') === true) {
        promise = this.get('qualityManagementService').createControlMaterialsLots(param);
      } else {
        promise = this.get('qualityManagementService').updateControlMaterialsLots(param);
      }
      await promise;
      this.set('isLotPopupOpen', false);
      this.showToastSaved();
      this._reloadLotGrid();
    } catch(e) {
      this._showSaveError(e);
    }
  },

  async _deleteLotItem() {
    try {
      const selectedDeleteId = this.get('model.selectedLotItem.lotId');
      if (selectedDeleteId) {
        const param = {lotId: selectedDeleteId};
        await this.get('qualityManagementService').deleteControlMaterialsLots(param);
        this._showToastDeleted();
        this._reloadLotGrid();
      }
    } catch(e) {
      this._showSaveError(e);
    }
  },

  getLotUpdateParam() {
    const lotEditItems = this.get('model.lotEditItems');
    if(isEmpty(lotEditItems.lotNumber) || isEmpty(lotEditItems.lotTypeCode)) {
      this.showToastInputData();
      return;
    }
    return {
      lotId: this.get('model.selectedLotItem.lotId'),
      controlMaterialId: this.get('model.selectedMaterialItem.controlMaterialId'),
      lotNumber: lotEditItems.lotNumber,
      lotTypeCode: lotEditItems.lotTypeCode,
      effectiveDatetime: isEmpty(lotEditItems.effectiveDatetime) ? new Date('9999-12-31 00:00:00') : lotEditItems.effectiveDatetime,
      applyDatetime: {
        startDatetime: lotEditItems.startDatetime,
        endDatetime: isEmpty(lotEditItems.endDatetime) ? new Date('9999-12-31 00:00:00') : lotEditItems.endDatetime
      },
      barcodeNumber: lotEditItems.barcodeNumber
    };

  },

  lotEditItemsReset() {
    this.set('model.lotEditItems.lotNumber', null);
    this.set('model.lotEditItems.lotTypeCode', null);
    this.set('model.lotEditItems.effectiveDatetime', null);
    this.set('model.lotEditItems.startDatetime', null);
    this.set('model.lotEditItems.endDatetime', null);
    this.set('model.lotEditItems.barcodeNumber', null);
  },
  setLotEditItems(item) {
    this.set('model.lotEditItems.lotNumber', item.lotNumber);
    this.set('model.lotEditItems.lotTypeCode', isEmpty(item.lotType) ? null : item.lotType.code);
    this.set('model.lotEditItems.effectiveDatetime', item.effectiveDatetime);
    this.set('model.lotEditItems.startDatetime', item.applyDatetime.startDatetime);
    this.set('model.lotEditItems.endDatetime', item.applyDatetime.endDatetime);
    this.set('model.lotEditItems.barcodeNumber', item.barcodeNumber);
  },

  _showToastDeleted() {
    this.showToastDeleted();
    // this.get('qualityManagementService').showToast('delete', '', this.getLanguageResource('8944', 'F', '', '삭제되었습니다'));
    this.getMateriasLotList(this.get('model.selectedMaterialItem.controlMaterialId'));
  },

  _reloadLotGrid() {
    this.getMateriasLotList(this.get('model.selectedMaterialItem.controlMaterialId'));
  },

  _getLotDeleteConfirm() {
    this.showConfirmDelete().then(result => {
      if (result === 'Yes') {
        this._deleteLotItem();
      }
    });
  }


});