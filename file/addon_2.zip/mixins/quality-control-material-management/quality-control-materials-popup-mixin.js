import Mixin from '@ember/object/mixin';
import { isEmpty } from '@ember/utils';
import { inject as service } from '@ember/service';
// import { next } from '@ember/runloop';
import { A as emberA } from '@ember/array';

export default Mixin.create({
  model: null,
  isMaterialPopupOpen: false,
  isAddPopup: false,
  isUpdatePopup: false,
  equipmentsCombobox: null,
  examinationRoomsEquipmentsList: null,
  isMaterialsShowLoader: false,
  isMaterialsPopupShowLoader: false,
  savingScrollPosition: null,
  qualityManagementService: service('laboratory-quality-management-service'),


  onPropertyInit() {
    this._super(...arguments);

    this.setStateProperties([
      'model',
      'examinationRoomList',
      'isMaterialsShowLoader',
      'equipmentsCombobox'

    ]);

    if(this.hasState()===false) {

      this.set('model', {
        selectedMaterialItem: null,
        materialEditItems: {
          displayCode: null,
          name: null,
          groupName: null,
          equipmentsIds: null,
          companyName: null,
        },
      });
      this.set('examinationRoomsEquipmentsList', emberA());

    }
  },
  actions: {
    onLoadEquipmentsCombobox(e) {
      this.set('equipmentsCombobox', e.source);
    },

    onNewMaterialPopupOpen() {
      this.set('savingScrollPosition', null);
      this.set('isMaterialPopupOpen', true);
    },

    onMaterialPopupOpenedAction() {
      this._getEquipmentList();
      // this.get('model.isEntryPopupUpdated', false);
      // if (this.get('isUpdatePopup') === true || this.get('isAddPopup') === true) {
      //   const selectedMaterialItem = this.get('model.selectedMaterialItem');
      //   console.log('selectedMaterialItem---', selectedMaterialItem);
      //   selectedMaterialItem.applyEquipments.forEach(item => {
      //     const equipmentsList = this.get('examinationRoomsEquipmentsList');
      //     const equipmentIndex = equipmentsList.findIndex(eq => eq.id === item.id);
      //     this.get('equipmentsCombobox').selectItem(equipmentIndex);
      //   });
      // }
    },
    onAddMaterialPopupOpen() {
      const selectedMaterialItem = this.get('model.selectedMaterialItem');
      if (selectedMaterialItem) {
        this.set('isAddPopup', true);
        this.setMaterialEditItems(selectedMaterialItem);
        this.set('isMaterialPopupOpen', true);
      }
    },

    onMaterialPopupClosedAction() {
      this.set('isUpdatePopup', false);
      this.set('isAddPopup', false);
      this.materialEditItemsReset();
    },

  },

  getDataList() {
    //override
  },

  async _createMaterial() {
    try {
      this.set('isMaterialsPopupShowLoader', true);
      let createParam = {};
      const param = this.getMaterialUpdateParam();
      if (isEmpty(param)) {
        return;
      }
      createParam = param;
      createParam.displaySequence = 0;
      await this.get('qualityManagementService').createControlMaterials(param);
      this.set('isMaterialsPopupShowLoader', false);
      this.set('isMaterialPopupOpen', false);
      this._metarialRequestSuccess();
    } catch(e) {
      this._showSaveError(e);
      if(!this.get('isDestroyed')) {
        this.set('isMaterialsPopupShowLoader', false);
      }
    }

  },

  async _updateMaterial() {
    try {
      this.set('isMaterialsPopupShowLoader', true);
      let updateParam = {};
      const param = this.getMaterialUpdateParam();
      updateParam = param;
      updateParam.controlMaterialId = this.get('model.selectedMaterialItem.controlMaterialId');
      updateParam.displaySequence = this.get('model.selectedMaterialItem.displaySequence');
      await this.get('qualityManagementService').updateControlMaterials(updateParam);
      this.set('isMaterialPopupOpen', false);
      this.set('isMaterialsPopupShowLoader', false);
      this._metarialRequestSuccess();
    } catch(e) {
      this._showSaveError(e);
      if(!this.get('isDestroyed')) {
        this.set('isMaterialsPopupShowLoader', false);
      }
    }
  },

  _deleteMaterial() {
    const selectedDeleteId = this.get('model.selectedMaterialItem.controlMaterialId');
    if (selectedDeleteId) {
      const param = {controlMaterialId: selectedDeleteId};
      this.get('qualityManagementService').deleteControlMaterials(param).then(() => {
        this.showToastDeleted();
        this.getDataList();
      }).catch(() => {
        this.showToastDeleteFail();
      });
    }
  },

  getMaterialUpdateParam() {
    const editItems = this.get('model.materialEditItems');
    const equipmentsIds = [];
    if (isEmpty(editItems.equipmentsIds) || isEmpty(editItems.displayCode)|| isEmpty(editItems.name)) {
      this.showToastInputData();
      return;
    }
    if (!isEmpty(editItems.equipmentsIds)) {
      editItems.equipmentsIds.forEach(id => {
        equipmentsIds.push({equipmentId: id});
      });
    }
    return {
      displayCode: editItems.displayCode,
      name: editItems.name,
      groupName: editItems.groupName,
      equipments: equipmentsIds,
      companyName: editItems.companyName,
      // displaySequence: materialEditItems.displaySequence
    };
  },

  materialEditItemsReset() {
    this.set('model.materialEditItems.displayCode', null);
    this.set('model.materialEditItems.name', null);
    this.set('model.materialEditItems.groupName', null);
    this.set('model.materialEditItems.equipmentsIds', null);
    this.set('model.materialEditItems.companyName', null);
  },
  setMaterialEditItems(item) {
    this.set('model.materialEditItems.displayCode', item.displayCode);
    this.set('model.materialEditItems.name', item.name);
    this.set('model.materialEditItems.groupName', item.groupName);
    const equipmentsIds = this._pluck(item.applyEquipments, 'id');
    this.set('model.materialEditItems.equipmentitemsIds', equipmentsIds);
    // this.set('model.materialEditItems.equipmentsIds', item.applyEquipment.id);
    this.set('model.materialEditItems.companyName', item.companyName);
    // this.set('model.materialEditItems.displaySequence', item.displaySequence);
  },
  _getEquipmentList() {
    const param = {
      examinationRoomId: this.get('model.selectedExaminationRoom')
    };
    this.set('examinationRoomsEquipmentsList', emberA());
    this.get('qualityManagementService').getEquipments(param).then(result => {
      if (!isEmpty(result)) {
        this.set('examinationRoomsEquipmentsList', result);
        setTimeout(() => {
          if (this.get('isUpdatePopup') === true || this.get('isAddPopup') === true) {
            const selectedMaterialItem = this.get('model.selectedMaterialItem');
            selectedMaterialItem.applyEquipments.forEach(item => {
              const equipmentsList = this.get('examinationRoomsEquipmentsList');
              const equipmentIndex = equipmentsList.findIndex(eq => eq.id === item.id);
              this.get('equipmentsCombobox').selectItem(equipmentIndex);
            });
          }
        });
      }
    });

  },

  _metarialRequestSuccess() {
    this.showToastSaved();
    this.getDataList();
  },

  _getMaterialDeleteConfirm() {
    this.showConfirmDelete().then(result => {
      if (result === 'Yes') {
        this._deleteMaterial();
      }
    });
  }

});