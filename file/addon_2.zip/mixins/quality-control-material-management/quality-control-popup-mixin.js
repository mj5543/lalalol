/* eslint-disable no-console */
import Mixin from '@ember/object/mixin';
import { isEmpty } from '@ember/utils';
import { set } from '@ember/object';
import { inject as service } from '@ember/service';
// import { later } from '@ember/runloop';
import { A as emberA } from '@ember/array';
import { hash } from 'rsvp';

export default Mixin.create({
  model: null,
  examinationRoomList: null,
  controlMaterialListByPopup: null,
  controlMaterialsLotListByPopup: null,
  examinationListByPopup: null,
  equipmentListByPopup: null,
  isShowLoader: false,
  contentLoaderType: 'spinner',
  isQualityControlCheckComp: false,
  examinationSearchPopupData: null,
  examinationRoomsEquipmentsList: null,
  isExaminationListByPopupShowLoader: false,
  cumulativePopupData: null,
  isExaminationSearchOpen: false,
  isExaminationGridEditing: false,
  isCumulativeShowLoader: false,
  equipmentsCombobox: null,
  qualityManagementService: service('laboratory-quality-management-service'),


  onPropertyInit() {
    this._super(...arguments);

    this.setStateProperties([

    ]);

    if(this.hasState()===false) {

      this.set('model', {
        selectedExaminationRoomByPopup: null,
        selectedControlMaterialByPopup: null,
        selectedControlMaterialIdByPopup: null,
        selectedControlMaterialsLotByPopup: null,
        selectedControlMaterialsLotIdByPopup: null,
        selectedEquipmentByPopup: null,
        selectedEquipmentIdByPopup: null,
        selectedCompareEquipmentByPopup: null,
        selectedCompareEquipmentIdByPopup: null,
        selectedExaminationsByPopup: null,
        selectedExaminationIdByPopup: null,
        examinationEditItems: null,
        selectedExaminationItem: null,
        selectedExaminationPopupItems: null,
        selectedCumulativePopupItem: null,
        isEditingExaminationItems: false,
      });

      this.set('examinationSearchPopupData', emberA());
      this.set('cumulativePopupData', emberA());
      this.set('examinationRoomList', emberA());

    }
  },
  actions: {
    onPopupSearchData() {
      this.getExaminationList(this.get('model.selectedControlMaterialsLotIdByPopup'));
    },

    onExaminationRoomChangeByPopup(e) {
      this.set('examinationSearchPopupData', emberA());

      const selectedItems = e.selectedItems;
      if(selectedItems.length > 0) {
        this.getControlMaterials(selectedItems[0].id);
      } else {
        this.getControlMaterials(this.get('examinationRoomList')[0].id);
      }
    },
    onControlMaterialChangeByPopup(e) {
      const selectedItems = e.selectedItems;
      this.set('controlMaterialsLotListByPopup', emberA());
      if(selectedItems.length > 0) {
        this.getControlMateriasLot(selectedItems[0].controlMaterialId);
      }

    },
    onControlMaterialsLotChangeByPopup(e) {
      const selectedItems = e.selectedItems;
      this.set('equipmentListByPopup', emberA());
      if(selectedItems.length > 0) {
        this.getApplyEquipments(selectedItems[0].controlMaterialId);
      }
    },

    onEquipmentChangeByPopup() {
      // if (this.get('isEntriComp') === true) {
      //   this.getDataList();
      // }
    },

    onEquipmentsChangeByPopup(e) {
      const selectedItems = e.selectedItems;
      if (selectedItems.length > 0) {
        const selectedItemList = this._pluck(selectedItems, 'id');
        this.set('model.materialEditItems.equipmentsIds', selectedItemList);
      } else {
        this.set('model.materialEditItems.equipmentsIds', null);
      }
    },


    onPopupClosedAction() {
      this.set('model.editResultComment', null);
    },
    onResultUpdateClick() {
      this._resultCommentUpdate();
    },
    onResultCheckClick() {
      this._resultCheck();
    },
    onApplyExaminationItems() {
      this.addExaminationGridItems();
      //
    },
    onExaminationSearchPopupSelectedItem(e) {
      this.set('model.selectedExaminationPopupItems', e.selectedItems);

    },
    onCumulativePopupSeletctedItem(e) {
      this.set('model.selectedExaminationPopupItems', e.selectedItems);

    },

    onExaminationPopupClosedAction() {
      this.setExaminationsPopupReset();
      // this.set('examinationSearchPopupData', emberA());
      // this.set('model.selectedExaminationPopupItems', null);
    },

    onSdSearchPopupClosedAction() {
      this.set('cumulativePopupData', emberA());
      this.set('model.selectedExaminationPopupItems', null);
    },


  },

  getDataList() {
    //override
  },

  getControlMaterials(roomId) {
    const param = {
      examinationRoomId: roomId
    };

    this.get('qualityManagementService').getControlMaterials(param).then(result => {
      this.set('controlMaterialListByPopup', result);
      if (result.length > 0) {
        this.set('model.selectedControlMaterialIdByPopup', result[0].controlMaterialId);
      }
    });
  },

  getControlMateriasLot(materialId) {
    const param = {
      controlMaterialId: materialId
    };
    this.get('qualityManagementService').getControlMateriasLot(param).then(result => {
      if (!isEmpty(result)) {
        this.set('controlMaterialsLotListByPopup', result);
        this.set('model.selectedControlMaterialsLotIdByPopup', result[0].lotId);
        this.getExaminationList(result[0].lotId);
      } else {
        this.set('examinationSearchPopupData', emberA());
      }
    });

  },

  getApplyEquipments(materialId) {
    const materialList = this.get('controlMaterialListByPopup');
    // eslint-disable-next-line arrow-body-style
    const findSetItems = materialList.find((d) => {
      return d.controlMaterialId === materialId;
    });
    // const findedFirstId = findSetItems.applyEquipments[0].id;
    // if (this.get('model.selectedEquipmentIdByPopup') === findedFirstId) {
    //   return;
    // }
    this.set('equipmentListByPopup', findSetItems.applyEquipments);
    this.set('model.selectedEquipmentIdByPopup', findSetItems.applyEquipments[0].id);
    this.set('model.selectedCompareEquipmentIdByPopup', findSetItems.applyEquipments[0].id);
  },

  setExaminationsReset() {
    this.set('examinationGridData', emberA());
    this.set('model.isEditingExaminationItems', false);
  },

  setExaminationsPopupReset() {
    // this.set('controlMaterialListByPopup', emberA());
    this.set('examinationSearchPopupData', emberA());
    // this.set('model.isEditingExaminationItems', false);
    this.set('model.selectedControlMaterialIdByPopup', null);
    this.set('model.selectedEquipmentIdByPopup', null);
    this.set('model.selectedControlMaterialsLotIdByPopup', null);
    this.set('model.selectedExaminationPopupItems', null);
  },

  async getExaminationList(lotId) {
    try {
      if(isEmpty(lotId)) {
        return;
      }
      this.set('contentLoaderType', 'spinner');
      this.set('isExaminationListByPopupShowLoader', true);
      this.set('examinationSearchPopupData', emberA());
      this.set('examinationListByPopup', emberA());
      const param = {
        lotId: lotId
      };
      this.set('model.selectedExaminationIdByPopup', null);
      const result = await this.get('qualityManagementService').getControlMateriasLotItems(param);
      if (!isEmpty(result)) {
        const examinations = this.getExamination(result);
        this.set('examinationListByPopup', examinations);
        result.map(item => {
          // item.equipmentNameList = item.applyEquipments[0];
          item.id = item.lotItemId;
        });
        this.set('examinationSearchPopupData', result);
      }
      if (this.get('isCheckByLevelComp')) {
        this.set('model.selectedExaminationIdByPopup', this.get('examinationListByPopup')[0].id);
        // this.getDataList();
      } else {
        this.set('model.selectedExaminationIdByPopup', null);
      }
      this.set('isExaminationListByPopupShowLoader', false);
    } catch(e) {
      this.set('isExaminationListByPopupShowLoader', false);
      console.error(e);
    }
  },

  getExamination(res) {
    // const returnList = [{id: 'All', name: this.getLanguageResource('9702', 'F', '', '전체')}];
    const returnList = [];
    res.forEach(item => {
      returnList.push(item.examination);
    });
    return returnList;
  },

  async getCumulativeFactor() {
    try {
      this.set('isCumulativeShowLoader', true);
      this.set('cumulativePopupData', emberA());
      // const startDate = new Date(this.get('model.selectedLotItem.applyDatetime.startDatetime'));
      // const endDate = new Date(this.get('model.selectedLotItem.applyDatetime.endDatetime'));
      const startDate = this.get('model.sdSearchCondition.selectedFromDate');
      const endDate = isEmpty(this.get('model.sdSearchCondition.selectedToDate')) ? new Date('9999-12-31 00:00:00') : this.get('model.sdSearchCondition.selectedToDate');
      const param = {
        lotId: this.get('model.selectedLotItem.lotId'),
        fromDatetime: this.get('fr_I18nService').formatDate(startDate, 'd'),
        toDatetime: this.get('fr_I18nService').formatDate(endDate, 'd'),
      };
      const result = await this.get('qualityManagementService').getQualityControlResultsCumulativeFactor(param);
      if(!isEmpty(result)) {
        this.set('cumulativePopupData', result);
      }
      this.set('isCumulativeShowLoader', false);
      this.set('contentLoaderType', 'spinner');
    } catch(e) {
      console.error(e);
    }
  },

  addExaminationGridItems() {
    const applyItems = this.get('model.selectedExaminationPopupItems');
    if (isEmpty(applyItems)) {
      this.showWarningMessage(this.getLanguageResource('13026', 'F', '선택 항목이 없습니다.'), 0);
      return;
    }
    const examinationGridItems = this.get('examinationGridData');
    const aleadyItems = [];
    applyItems.forEach(data => {
      const findedSameObj = examinationGridItems.find(item => item.examination.id === data.examination.id);
      // let targetObj = {};
      if (findedSameObj) {
        // targetObj = findedSameObj;
        // set(targetObj , 'meanSD', data.meanSD);
        set(findedSameObj , 'meanSD', data.meanSD);
        // this.get('examinationGridData').removeObject(findedSameObj);
        // this.get('examinationGridData').addObject(targetObj);
        aleadyItems.push(data);
      } else {
        delete data.lotItemId;
        this.get('examinationGridData').addObject(data);
      }
    });
    if (applyItems.length === aleadyItems.length && this.get('isExaminationSearchOpen')) {
      this.showWarningMessage(this.getLanguageResource('9226', 'F', '선택 항목은 이미 모두 추가되어 있습니다.'), 0);
      return;
    }

    this.set('isExaminationSearchOpen', false);
    this.set('isSdSearchOpen', false);
    this.set('model.isEditingExaminationItems', true);
  },

  _updateLotsItems() {
    const {updateParams, createParams} = this.setExaminationUpdateParam();

    hash({
      createMaterialsLotsItems: this.get('qualityManagementService').createControlMaterialsLotsItems({lotItems: createParams}),
      uadateMaterialsLotsItems: this.get('qualityManagementService').updateControlMaterialsLotsItems({lotItems: updateParams})
    }).then(() => {
      this.showToastSaved();
      this.set('model.isEditingExaminationItems', false);
      this.set('isExaminationGridEditing', false);
      this.getLotsExaminationList(this.get('model.selectedLotItem.lotId'));

    }, () => {
      this.showToastSaveFail();
    });

  },

  setExaminationUpdateParam() {
    const updateParams = [];
    const createParams = [];
    const examinationGridDatas = this.get('examinationGridData');
    examinationGridDatas.forEach((data, index) => {
      let tempObj = {};
      const criteria = {
        meanValue: isEmpty(data.meanSD.meanValue) ? data.meanSD.meanValue : parseFloat(data.meanSD.meanValue),
        unitCode: data.unitCode,
        sdValue: isEmpty(data.meanSD.sdValue) ? data.meanSD.sdValue : parseFloat(data.meanSD.sdValue),
        cvLowValue: isEmpty(data.cv.lowValue) ? data.cv.lowValue : parseFloat(data.cv.lowValue),
        cvHighValue: isEmpty(data.cv.highValue) ? data.cv.highValue : parseFloat(data.cv.highValue),
      };
      if (data.lotItemId) {
        tempObj = {
          lotItemId: data.lotItemId,
          lotId: data.lotId,
          examinationId: data.examination.id,
          criteria,
          displaySequence: index
        };
        updateParams.push(tempObj);
      } else {
        tempObj = {
          lotId: this.get('model.selectedLotItem.lotId'),
          examinationId: data.examination.id,
          criteria,
          displaySequence: index
        };
        createParams.push(tempObj);

      }
    });
    return {updateParams, createParams};

  },

  // _deleteLotsItems() {
  //   let promise = null;
  //   if (this.get('model.isEditingExaminationItems')) {
  //     promise = this.showConfirmDeletNotSaved();
  //   } else {
  //     promise = this.showConfirmDelete();
  //   }
  //   promise.then(result => {
  //     if (result === 'Yes') {
  //       this._deleteExaminationItem();
  //     }
  //   });
  // },

  // _deleteExaminationItem() {
  //   const selectedDeleteId = this.get('model.selectedExaminationItem.lotItemId');
  //   if (selectedDeleteId) {
  //     const param = {lotItemIds: [selectedDeleteId]};
  //     this.get('qualityManagementService').deleteControlMaterialsLotsItems(param).then(() => {
  //       this.showToastDeleted();
  //       this.getLotsExaminationList(this.get('model.selectedLotItem.lotId'));
  //     }, () => {
  //       this.showToastDeleteFail();
  //     });
  //   } else {
  //     this.get('examinationGridData').removeObject(this.get('model.selectedExaminationItem'));
  //     this.showWarningMessage(this.getLanguageResource('tempkey', 'F', '', '저장 된 항목이 아닙니다.'), 2000);
  //   }
  // },
  _deleteLotsItems() {
    let promise = null;
    const gridControl = this.get('examinationGrid');
    const selectedItem = this.get('model.selectedExaminationItem');
    const selectedDeleteId = this.get('model.selectedExaminationItem.lotItemId');
    const gridItems = this.get('examinationGridData');
    if (selectedDeleteId && this.get('model.isEditingExaminationItems')) {
      promise = this.showConfirmDeletNotSaved();
    } else if(!selectedDeleteId && this.get('model.isEditingExaminationItems')) {
      const itemIndex = gridControl.getItemIndex(selectedItem);
      // this.get('deleteItems').addObject(selectedItem);
      gridItems.removeObject(selectedItem);
      if(!isEmpty(itemIndex) && itemIndex !== gridItems.length) {
        gridControl.selectRow(itemIndex);
      } else if(!isEmpty(gridItems)) {
        gridControl.selectRow(gridItems.length-1);
      }
      // this.get('examinationGridData').removeObject(this.get('model.selectedExaminationItem'));
    } else {
      promise = this.showConfirmDelete();
    }
    if (!isEmpty(promise)) {
      promise.then(result => {
        if (result === 'Yes') {
          this._deleteExaminationItem(selectedDeleteId);
        }
      });
    }
  },
  _deleteExaminationItem(selectedDeleteId) {
    if (selectedDeleteId) {
      const param = {lotItemIds: [selectedDeleteId]};
      this.get('qualityManagementService').deleteControlMaterialsLotsItems(param).then(() => {
        this.showToastDeleted();
        this.getLotsExaminationList(this.get('model.selectedLotItem.lotId'));
      }, () => {
        this.showToastDeleteFail();
      });
    }
  },

});