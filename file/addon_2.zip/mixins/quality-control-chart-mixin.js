/* eslint-disable max-lines-per-function */
/* eslint-disable no-console */
import Mixin from '@ember/object/mixin';
import { A as emberA } from '@ember/array';

export default Mixin.create({
  chart: null,
  actionMode: null,
  chartType: null,
  colorOptions: null,
  yAxisOptions: null,
  customYAxis: null,
  customYAxisOptions: null,
  data: null,
  reload: null,
  selectedItem: null,
  yAxisPosition: null,
  strokeColor: null,
  strokeWidth: null,
  symbolColor: null,
  symbolSize: null,
  symbolType: null,
  symbolTypeOptions: null,
  lineChartData: null,
  customYAxisValue: null,
  isYAxisSimpleColor: false,
  customYAxisColors: null,
  targetLineValue: null,
  chartName: null,
  showLegend: false,

  onPropertyInit() {
    this._super(...arguments);
    console.log('quality-control-chart-mixin.onPropertyInit()');
    this.setStateProperties([
      'actionMode', 'chartType', 'chartTypeOptions',
      'colorOptions', 'yAxisOptions', 'customYAxis', 'customYAxisOptions',
      'data', 'reload', 'selectedItem', 'strokeColor', 'strokeWidth', 'symbolColor', 'symbolSize',
      'symbolType', 'symbolTypeOptions', 'selectedExaminationData',
      'chartTimePointer', 'chart', 'lineChartData', 'size', 'legend', 'customYAxisValue', 'isYAxisLinesSimple', 'targetLineValue'
    ]);

    if (this.hasState()===false) {
      // this._setLineChart();
      // // this._setLineChartData();
      // this.set('actionMode', null);
      // this.set('chartType', 'line');
    }
  },

  actions: {

  },

  _setLineChart(){
    const lineChart = {};
    // const today = this.get('co_CommonService').getNow();
    lineChart.xAxisOrient = 'bottom';
    lineChart.yAxisOrient = 'left';
    lineChart.tooltipSize = 1;
    lineChart.isSortedData = false;
    lineChart.isGroupLegend = false;
    lineChart.isCollapsibleLegend = false;
    lineChart.isCollapseLegendPane = false;
    lineChart.isCustomYAxis = true;
    lineChart.isTimeXAxis = false;
    lineChart.readOnly = true;
    lineChart.timeFormat = emberA();
    lineChart.legendPosition = 'bottom';

    const format = {};
    format.dataFormat = 'f';
    let formatType = '';
    switch(this.get('periodType')) {
      case 'Daily':
        formatType = '%Y-%m-%d %H:%M:%S';
        break;
      case 'Monthly':
        formatType = '%Y-%m-%d';
        break;
      case 'Yearly':
        formatType = '%Y-%m';
        break;
      default:
        break;
    }
    this._getTimePointer();
    format.xAxisTickFormat= [
      {'type': 'year','format': formatType},
      {'type': 'month','format': formatType},
      {'type': 'day','format': formatType}];

    // 'timePointer' : [          // x축에 임의로 표시하는 날짜 표시선 지정.
    //   2018-10-29 22:32:19,
    //   2018-10-30 02:32:19
    // ],
    // lineChart.timePointer = [];
    lineChart.timeFormat = format;

    lineChart.series = emberA();
    lineChart.series.pushObject(this._lineSeries());
    this.set('lineData', lineChart);
  },

  _getTimePointer() {
    // const chartData = this.get('lineChartData');
    // const targetSize = 7;
    // const chartSize = chartData.length;
    // // let targetIndex = 0;
    // const aveSize = chartSize/targetSize;
    // console.log('aveSize-----', aveSize);
    // // const pointerList = [];
    // const pointerList = chartData.filter((d, i) => i % Math.ceil(aveSize) === 0);
    // console.log('pointerList-----', pointerList);


  },

  _lineSeries(){
    // console.log('lineChartData--', this.get('lineChartData'));
    // console.log('customYAxisValue--', this.get('customYAxisValue'));
    const {value1, value2, value3, meanValue} = this.colorMapping();
    const yAxisValues = this.get('customYAxisValue');
    let yAxixColors = [];
    let strokeColor = '#6495ED';
    const yAxisLines = [];
    if(this.get('isYAxisSimpleColor')) {
      yAxixColors = this.get('customYAxisColors');
      // yAxisLines = ['#e9ebea', '#e9ebea', '#f1260b', '#e9ebea', '#e9ebea'];
      yAxisValues.forEach((d) => {
        if (d === this.get('targetLineValue')) {
          yAxisLines.push({value: d, color: '#f1260b'});
        } else {
          yAxisLines.push({value: d, color: 'e9ebea'});
        }
      });

    } else {
      strokeColor = '#02c74a';
      yAxixColors = [value3, value2, value1, meanValue, value3, value2, value1];
      yAxisValues.forEach((d, ind) => {
        if (ind === 0 || ind === 4) {
          // yAxisLines.push({value: d, color: '#e9ebea'});
          yAxisLines.push({value: d, color: '#e00007'});
        } else {
          yAxisLines.push({value: d, color: yAxixColors[ind]});
        }
      });
    }
    // const tooltipTemplate = '<div style=\'text-align: center;padding: 2px;font: 12px sans-serif;background: lightsteelblue;border: 1px;border-radius: 8px;pointer-events: none;\'>{{chartDisplayResult}}</div>';
    const tooltipTemplate = '<div class=\'wrap-balloon type-btm\'><div class=\'balloon\'><div>검사일: {{qualityControlDatetime}}</div><div style=\'text-align: left;\'>검사결과: {{chartDisplayResult}}</div></div></div>';
    const lineSeriesConfig = {
      no: 1,
      name: this.get('chartName'),
      config: {
        type: 'line',
        xAxisProperty: 'qualityControlDatetime',
        // xAxisProperty: 'displayDate',
        yAxisProperty: 'chartDisplayResult',
        yAxisPosition: 1,
        strokeColor: strokeColor,
        strokeWidth: 3,
        symbolSize: 2,
        symbolColor: strokeColor,
        symbolType: 'material-icons-star',
        tooltipProperty: null,
        tooltipTemplate: tooltipTemplate,
        noDisplaySymbol: false,
        isSelectLegend: true,
        groupLegendNo: 1,
        isCustomYAxis: true,
        isSelectSymbol: false,
        yAxis: this.get('customYAxisValue'),
        yAxisColor: yAxixColors,
        yAxisLines: yAxisLines
        // 'radious':400,
      },
      data: this.get('lineChartData')
    };
    return lineSeriesConfig;
  },

  colorMapping() {
    const color = {
      meanValue: '#21103b',
      // meanValue: '#1b5ba5',
      // value1: '#c79110',
      // value2: '#ff6600',
      // value3: '#e00007',
      value1: '#f5ce0a',
      value2: '#0609c2',
      value3: '#f20f25',
    };
    return color;
  }

});