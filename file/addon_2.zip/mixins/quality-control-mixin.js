/* eslint-disable max-lines */
/* eslint-disable max-lines-per-function */
/* eslint-disable no-console */
import Mixin from '@ember/object/mixin';
import { isEmpty, isPresent } from '@ember/utils';
import { inject as service } from '@ember/service';
import { A as emberA } from '@ember/array';
import { get } from '@ember/object';

export default Mixin.create({
  model: null,
  selectedDate: null,
  selectedFromDate: null,
  selectedToDate: null,
  examinationRoomList: null,
  controlMaterialList: null,
  controlMaterialsLotList: null,
  examinationList: null,
  isShowLoader: false,
  contentLoaderType: 'spinner',
  isQualityControlCheckComp: false,
  examinationCombobox: null,
  isCheckByLevelComp: false,
  isEntriComp: false,
  isCVMonitoringComp: false,
  isChartShow: false,
  isResultDetailOpen: false,
  isDisabled: null,
  showHeader: null,
  isExpanded: null,
  isAnalysisComp: false,
  isRoomListDisabeld: true,
  isLoaderDimed: false,
  isMaterialsShowLoader: false,
  isExaminationsShowLoader: false,
  isButtonDisabled: true,
  isBottomButtonDisabled: true,
  isCurrentLocaleByKr: true,
  qualityManagementService: service('laboratory-quality-management-service'),


  onPropertyInit() {
    this._super(...arguments);

    this.setStateProperties([
      'model',
      'selectedDate',
      'examinationRoomList',
      'controlMaterialList',
      'examinationList',
      'isShowLoader',
      'contentLoaderType',
      'selectedFromDate',
      'selectedToDate',
      'isQualityControlCheckComp',
      'examinationCombobox',
      'isDisabled',
      'showHeader',
      'isExpanded',
      'userGlobalInformation',
      'patientGlobalInformation',
      'todayDate',
      'isExaminationsShowLoader',
    ]);

    if(this.hasState()===false) {

      this.set('model', {
        selectedExaminationRoom: null,
        selectedControlMaterial: null,
        selectedControlMaterialId: null,
        selectedControlMaterialsLot: null,
        selectedControlMaterialsLotId: null,
        selectedEquipment: null,
        selectedEquipmentId: null,
        selectedCompareEquipment: null,
        selectedCompareEquipmentId: null,
        selectedExamination: null,
        selectedExaminationId: null,
        selectedGridItem: null,
        editResultComment: null,
      });

      if(!isEmpty(this.get('co_CurrentUserService.user'))){
        this.set('userGlobalInformation', this.get('co_CurrentUserService.user'));
      }

      if(!isEmpty(this.get('co_PatientManagerService.selectedPatient'))){
        this.set('patientGlobalInformation', this.get('co_PatientManagerService.selectedPatient'));
      }
      const displayDate = new Date(this.get('co_CommonService').getNow());
      this.set('todayDate', displayDate);
      this.set('selectedDate', displayDate);
      this.set('selectedFromDate', this.get('co_CommonService').getNow().addDays(-7));
      // this.set('selectedFromDate', displayDate);
      this.set('selectedToDate', displayDate);
      this.set('examinationRoomList', emberA());
      this.set('isDisabled', false);
      this.set('isExpanded', false);
      this.set('showHeader', true);
      this.setComboboxReset();
    }
    if(this.get('fr_I18nService.currentLocale') !== 'ko-kr') {
      this.set('isCurrentLocaleByKr', false);
    }
  },
  actions: {
    onSearchData() {
      this.getDataList();
    },
    onFromToUpdated() {
      this.getDataList();
    },

    onSelectedExamination(e) {
      const selectedItem = e.selectedItems[0];
      if(selectedItem) {
        this.set('model.selectedExamination', selectedItem);
      }
    },
    onExaminationRoomChange(e) {
      const selectedItems = e.selectedItems;
      this._gridDataReset();
      this.setComboboxReset();
      if(selectedItems.length > 0) {
        this.getControlMaterials(selectedItems[0].id);
        this._setSettingRoomInfo();
      } else {
        this.getControlMaterials(this.get('examinationRoomList')[0].id);
      }
    },
    onControlMaterialChange(e) {
      const selectedItems = e.selectedItems;
      this.set('controlMaterialsLotList', emberA());
      if(selectedItems.length > 0) {
        this.getControlMateriasLot(selectedItems[0].controlMaterialId);
      }
    },
    onControlMaterialsLotChange(e) {
      const selectedItems = e.selectedItems;
      if(selectedItems.length > 0) {
        this.getApplyEquipments(selectedItems[0].controlMaterialId);
      }
    },

    onEquipmentChange() {
      if (this.get('isCheckByLevelComp')) {
        this.getDataList();
      } else {
        this.set('model.selectedExamination', null);

      }

    },

    onCompareEquipmentChange() {
      //
    },

    onExaminationChange(e) {
      const selectedItems = e.selectedItems;
      if (this.get('examinationList') === null) {
        return;
      }
      // if (this.get('examinationList').length === selectedItems.length) {
      //   // console.log('length same!!!!!');
      //   return;
      // }
      if (selectedItems.length > 0) {
        // this.get('examinationCombobox').deselectItem(0);
        const selectedItemList = this._pluck(selectedItems, 'id');
        // const isCheckedAll = selectedItemList.includes('All');
        // if (isCheckedAll) {
        //   // this.get('examinationCombobox').deselectAll();
        //   if (this.get('examinationList').length === selectedItems.length+1 && e.source.selectedItem.id !== 'All') {
        //     this.get('examinationCombobox').deselectItem(0);
        //     return;
        //   } else {
        //     this.get('examinationCombobox').selectAll();
        //     this.set('model.selectedExaminationId', 'All');

        //   }
        // } else {
        //   // this.get('examinationCombobox').deselectAll();
        //   if (this.get('examinationList').length === selectedItems.length+1) {
        //     this.get('examinationCombobox').deselectAll();
        //     this.set('model.selectedExaminationId', []);
        //     // this.get('examinationCombobox').deselectItem(0);
        //     return;
        //   }
        //   this.set('model.selectedExaminationId', selectedItemList);

        // }
        this.set('model.selectedExaminationId', selectedItemList);

      } else {
        this.set('model.selectedExaminationId', null);
      }
      if (!this.get('isAnalysisComp')) {
        this.getDataList();
      }
    },

    onLoadCombobox(e) {
      this.set('examinationCombobox', e.source);
    },

    onSwitchChange(e) {
      this.set('isChartShow', e.checked);
    },

    onPopupClosedAction() {
      this.set('model.editResultComment', null);
    },
    onResultUpdateClick() {
      this._resultCommentUpdate();
    },
    onResultCheckClick() {
      const message = this.getLanguageResource('8939', 'F', null, '저장 하시겠습니까?');
      this.showConfirmMessage(this.getLanguageResource('8387', 'F', null, '확인자'), message).then(result => {
        if (result === 'Yes') {
          this._resultCheck();
        }
      });
    }


  },

  getDataList() {
    //override
  },

  async getExaminationRoomList() {
    try {
      const result = await this.get('co_PersonalizationService').getSettingInfo(`laboratory-management-users-setting-info`);
      const roomList = await this.get('qualityManagementService').getExaminationRooms();
      if (!isEmpty(roomList)) {
        this.set('isRoomListDisabeld', false);
        this.set('isButtonDisabled', false);
        this.set('examinationRoomList', roomList);
        if(!isEmpty(result.settingValue)) {
          const settingValue = JSON.parse(get(result, 'settingValue'));
          if(!isEmpty(settingValue.conditionData)) {
            const settingOption = settingValue.conditionData[0];
            this.set('model.selectedExaminationRoom', settingOption.roomId);
          }
        } else {
          this.set('model.selectedExaminationRoom', roomList[0].id);
        }
      }
    } catch(e) {
      console.log(e);
    }
  },
  async _setSettingRoomInfo() {
    try {
      const settingData = {
        conditionData: [
          {
            roomId: this.get('model.selectedExaminationRoom'),
          }
        ]
      };
      await this.get('co_PersonalizationService').setSettingInfo(`laboratory-management-users-setting-info`, JSON.stringify(settingData), '검사결과조회 설정 저장');
    } catch(e) {
      console.log('_setSettingInfo Error::', e);
    }
  },
  async getControlMaterials(roomId) {
    try {
      const param = {
        examinationRoomId: roomId
      };
      this.set('controlMaterialList', emberA());
      const materials = await this.get('qualityManagementService').getControlMaterials(param);
      if (!isEmpty(materials)) {
        this.set('controlMaterialList', materials);
        // this.set('model.selectedControlMaterialId', materials[0].controlMaterialId);
        this.set('model.selectedControlMaterialId', this.get('parallelTestItem.controlMaterial.id'));
      }
    } catch(e) {
      console.log('getControlMaterials error ::', e);
    }
  },

  async getControlMateriasLot(materialId) {
    try {
      this.set('equipmentList', emberA());
      this.set('examinationList', emberA());
      const param = {
        controlMaterialId: materialId
      };
      const result = await this.get('qualityManagementService').getControlMateriasLot(param);
      if(isPresent(result)) {
        this.set('controlMaterialsLotList', result);
        this.set('model.selectedControlMaterialsLotId', result[0].lotId);
        this.set('examinationList', null);
        this.getExaminationList(result[0].lotId);
      }
    } catch(e) {
      console.log(e);
    }

  },

  setComboboxReset() {
    this.set('controlMaterialList', emberA());
    this.set('controlMaterialsLotList', emberA());
    this.set('equipmentList', emberA());
    this.set('examinationList', emberA());
  },

  getApplyEquipments(materialId) {
    const materialList = this.get('controlMaterialList');
    const findSetItems = materialList.find((d) => d.controlMaterialId === materialId);
    const findedFirstId = findSetItems.applyEquipments[0].id;
    if (this.get('model.selectedEquipmentId') === findedFirstId) {
      return;
    }
    this.set('equipmentList', findSetItems.applyEquipments);
    this.set('model.selectedEquipmentId', findSetItems.applyEquipments[0].id);
    this.set('model.selectedCompareEquipmentId', findSetItems.applyEquipments[0].id);
  },

  async getExaminationList(lotId) {
    try {
      if (isEmpty(lotId)) {
        return;
      }
      const param = {
        lotId: lotId
      };
      this.set('model.selectedExaminationId', null);
      this.set('examinationList', []);
      const result = await this.get('qualityManagementService').getControlMateriasLotItems(param);
      const examinations = this._getExaminationList(result);
      this.set('examinationList', examinations);
      if (this.get('isCheckByLevelComp')) {
        this.set('model.selectedExaminationId', this.get('examinationList')[0].id);
        // this.getDataList();
      } else {
        this.set('model.selectedExaminationId', null);
        // next(this, function(){
        //   if (this.get('examinationCombobox') !== null) {
        //     this.get('examinationCombobox').selectAll();
        //     this.getDataList();
        //   }
        // });
        if (!this.get('isAnalysisComp')) {
          // 상관분석 메뉴는 조회버튼으로 조회
          this.getDataList();
        }
      }
    } catch(e) {
      console.log(e);
    }
  },

  _getExaminationList(res) {
    // const returnList = [{id: 'All', name: this.getLanguageResource('9702', 'F', '', '전체')}];
    const returnList = [];
    res.forEach(item => {
      returnList.push(item.examination);
    });
    return returnList;
  },

  groupBy(list, keyGetter) {
    const map = new Map();
    list.forEach((item) => {
      const key = keyGetter(item);
      const collection = map.get(key);
      if (!collection) {
        map.set(key, [item]);
      } else {
        collection.push(item);
      }
    });
    return map;
  },

  _pluck(objs, name) {
    const sol = [];
    for(const i in objs){
      if(objs[i].hasOwnProperty(name)){
        sol.push(objs[i][name]);
      }
    }
    return sol;
  },

  _success() {
    this.showToastSaved();
    this.getDataList();
  },

  _fail() {
    this.showToastSaveFail();
    // this.get('qualityManagementService').showToast('error', '', this.getLanguageResource('9195', 'F', '', '저장에 실패하였습니다'));
  },

  _showToastDeleted() {
    this.showToastDeleted();
    // this.get('qualityManagementService').showToast('delete', '', this.getLanguageResource('8944', 'F', '', '삭제되었습니다'));
  },

  async _resultCommentUpdate() {
    try {
      const path = `${this.get('qualityManagementService').urlPrefix}/quality-control-results`;
      const updateParam = {
        qualityControlResults: [
          {
            qualityControlResultId: this.get('model.selectedGridItem.qualityControlResultId'),
            qualityControlDatetime: this.get('model.selectedGridItem.qualityControlDatetime'),
            specimenNumber: this.get('model.selectedGridItem.specimenNumber'),
            displaySequence: 0,
            examinationId: this.get('model.selectedGridItem.examination.id'),
            resultValue: this.get('model.selectedGridItem.resultValue'),
            resultValueContent: this.get('model.selectedGridItem.resultValueContent'),
            resultComment: this.get('model.editResultComment'),
            performDatetime: this.get('model.selectedGridItem.performDatetime'),
            isValidDataRow: true
          }
        ]
      };
      await this.update(path, null, false, updateParam, false);
      this.set('isResultDetailOpen', false);
      this._success();
    } catch(e) {
      this._showSaveError(e);
    }
  },
  async _resultCheck() {
    try {
      const path = `${this.get('qualityManagementService').urlPrefix}/quality-control-results/checks`;
      const checkDatetime = this.get('co_CommonService').getNow();
      let paramResultId = null;
      if (this.get('periodType') === 'Daily') {
        if(isPresent(this.get('model.cellDoubleClickItem'))) {
          paramResultId = this.get('model.cellDoubleClickItem.qualityControlResultId');
        } else {
          paramResultId = this.get('model.selectedGridItem.qualityControlResultId');
        }
      }
      const createParam = {
        checks: [
          {
            equipmentId: this.get('model.selectedGridItem.equipment.id'),
            lotId: this.get('model.selectedGridItem.lot.id'),
            examinationId: this.get('model.selectedGridItem.examination.id'),
            // checkTypeCode: this.get('model.selectedGridItem.qualityControlResultId'),
            // checkTypeCode: this.get('periodType'),
            checkTypeCode: 'QualityControlResultId',
            checkSequence: 0,
            qualityControlResultId: paramResultId,
            checkDatetime: {
              startDatetime: checkDatetime,
              endDatetime: checkDatetime,
            }
          }
        ]
      };
      await this.create(path, null, createParam, false);
      this.set('isResultDetailOpen', false);
      this._success();
    } catch(e) {
      this._showSaveError(e);
    }

  },

  setDisplaySequence(type, items) {
    this.set('contentLoaderType', 'progress');
    this.set('isLoaderDimed', true);
    const changedItemList = items;
    const newSequenceList = changedItemList.map((item, index) => {
      item.newDisplaySequence = index;
      return item;
    });
    // const changeList = [];
    // newSequenceList.forEach(d => {
    //   changeList.push({id: d.id, displaySequence: d.newDisplaySequence});
    // });
    const changeList = newSequenceList.map(function(d) {
      return {id: d.id, displaySequence: d.newDisplaySequence};
    });
    this.updateDisplaySequence(type, changeList);
  },

  async updateDisplaySequence(type, list) {
    try {
      const param = {
        changeDisplaySequences: list
      };
      let promise = null;
      switch(type) {
        case 'equipment':
          promise = this.get('qualityManagementService').equipmentsChangeDisplaySequence(param);
          break;
        case 'material':
          this.set('isMaterialsShowLoader', true);
          promise = this.get('qualityManagementService').controlMaterialsChangeDisplaySequence(param);
          break;
        case 'examination':
          this.set('isExaminationsShowLoader', true);
          promise = this.get('qualityManagementService').controlMaterialsLotsItemsChangeDisplaySequence(param);
          break;
        default:
          promise = null;
          break;
      }
      if(!isEmpty(promise)) {
        await promise;
        if (type === 'examination') {
          this.showToastSaved();
          // this.set('isExaminationGridEditing', false);
          this.getLotsExaminationList(this.get('model.selectedLotItem.lotId'));
        } else {
          this._success();
        }
      }
    } catch(e) {
      this._showSaveError(e);
    }

  },

  _getRulesColor() {
    const color = {
      '22S': '#e03ac3',
      '22S2': '#137cea',
      'R4S': '#ff6600',
      '41S': '#ff6600',
      '10X': '#c79110',
      '11S': '#f5ce0a',
      '12S': '#0609c2',
      '13S': '#f20f25',
      // '22S': '#e03ac3',
      // '22S2': '#137cea',
      // 'R4S': '#421eff',
      // '41S': '#421eff',
      // '10X': '#089420',
      // '11S': '#c79110',
      // '12S': '#ff6600',
      // '13S': '#e00007',
      // nocode: '#1b5ba5',
      // minus1SDValue: '#c79110',
      // minus2SDValue: '#ff6600',
      // minus3SDValue: '#e00007',
      // plus1SDValue: '#c79110',
      // plus2SDValue: '#ff6600',
      // plus3SDValue: '#e00007'
    };
    return color;
  },
  async _getRuleCodeList() {
    try {
      //2-2SD > 2-2SD(동일Level) > R-4SD -> 4-1SD > 10X (하나도 안걸린경우는 3SD, 2SD, 1SD에 걸리면 색상 표현)
      const param = {classificationCode: 'QualityControlRule'};
      const result = await this.get('qualityManagementService').getLaboratoryBusinessCode(param);
      console.log('_getRuleCodeList======', result);
    } catch(e) {
      //
    }

  },

  getMonitorFactor(examinationIds) {

    const monitoFactorParams = this.getParameters();
    monitoFactorParams.controlMaterialId = this.get('model.selectedControlMaterialId');
    monitoFactorParams.examinationIds = examinationIds;
    return this.get('qualityManagementService').getQualityControlResultsMonitorFactor(monitoFactorParams).then(result => {
      if (!isEmpty(result)) {
        this.set('monitorFactorList', result);
        this.set('model.monitorFactor', result[0].qualityControlFactor);
        this.set('model.displayExaminationName', result[0].examination.name);

      }
    });
  },

  getParameters() {
    const selectedFromDate = this.get('selectedFromDate');
    const selectedToDate = this.get('selectedToDate');
    const selectedDate = this.get('selectedDate');
    let paramFromDate = new Date(selectedFromDate.getFullYear(), selectedFromDate.getMonth(), selectedFromDate.getDate(), 0, 0, 0).toFormatString();
    let paramToDate = new Date(selectedToDate.getFullYear(),selectedToDate.getMonth(), selectedToDate.getDate(), 0, 0, 0).toFormatString();
    const searchMonthDate = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), 1, 0, 0, 0).toFormatString();
    const searchFromMonthDate = new Date(selectedFromDate.getFullYear(), selectedFromDate.getMonth(), 1, 0, 0, 0).toFormatString();
    const searchToMonthDate = new Date(selectedToDate.getFullYear(), selectedToDate.getMonth(), 1, 0, 0, 0).toFormatString();
    const searchYearDate = new Date(selectedDate.getFullYear(), 0, 1, 0, 0, 0).toFormatString();
    // const searchFromYearDate = new Date(selectedFromDate.getFullYear(), 0, 1, 0, 0, 0).toFormatString();
    // const searchToYearDate = new Date(selectedToDate.getFullYear(), 0, 1, 0, 0, 0).toFormatString();

    if (this.get('periodType') === 'Monthly') {
      paramFromDate = searchMonthDate;
      paramToDate = searchMonthDate;
    } else if(this.get('periodType') === 'Yearly') {
      paramFromDate = searchYearDate;
      paramToDate = searchYearDate;
      if(this.get('isCVMonitoringComp')) {
        paramFromDate = searchFromMonthDate;
        paramToDate = searchToMonthDate;
      }
    }
    return {
      qualityControlFindTypeCode: this.get('periodType'),
      lotId: this.get('model.selectedControlMaterialsLotId'),
      equipmentId: this.get('model.selectedEquipmentId'),
      fromDatetime: paramFromDate,
      toDatetime: paramToDate,
    };
  },
  getDateString(date) {
    return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 0, 0).toFormatString();
  },
  ruleList() {
    const ruleList = [
      {
        "code": "12S",
        "displayCode": "1-2SD",
        "name": "1-2SD",
        "abbreviation": "1-2SD"
      },
      {
        "code": "13S",
        "displayCode": "1-3SD",
        "name": "1-3SD",
        "abbreviation": "1-3SD"
      },
      {
        "code": "22S",
        "displayCode": "2-2SD_1",
        "name": "2-2SD",
        "abbreviation": "2-2SD"
      },
      {
        "code": "22S2",
        "displayCode": "2-2SD_2",
        "name": `2-2SD (${this.getLanguageResource('14857', 'F', '', '동일 Level')})`,
        "abbreviation": `2-2SD (${this.getLanguageResource('14857', 'F', '', '동일 Level')})`
      },
      {
        "code": "R4S",
        "displayCode": "R-4SD",
        "name": "R-4SD",
        "abbreviation": "R-4SD"
      },
      {
        "code": "41S",
        "displayCode": "4-1SD",
        "name": "4-1SD",
        "abbreviation": "4-1SD"
      },
      {
        "code": "10X",
        "displayCode": "10X",
        "name": "10X",
        "abbreviation": "10X"
      }
    ];
    return ruleList;
  },
  _getGUID() {
    function s4() {
      return Math.floor((1 + Math.random()) * 0x10000)
        .toString(16)
        .substring(1);
    }
    return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
  }

});