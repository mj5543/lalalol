/* eslint-disable max-lines */
/* eslint-disable max-lines-per-function */
/* eslint-disable no-undef */
/* eslint-disable no-console */
import Mixin from '@ember/object/mixin';
import { isEmpty, isPresent } from '@ember/utils';
import { inject as service } from '@ember/service';
import { A as emberA } from '@ember/array';

export default Mixin.create({
  model: null,
  printPopup: null,
  printConfig: null,
  printContent: null,
  multiPrintContent: null,
  qualityManagementService: service('laboratory-quality-management-service'),


  onPropertyInit() {
    this._super(...arguments);

    this.setStateProperties([
      'model',
      'printPopup',
      'printConfig',
      'printContent',
      'multiPrintContent'
    ]);

    if(this.hasState()===false) {

      this.set('model', {
        selectedMaterialItem: null,
        materialEditItems: {
          displayCode: null,
          name: null,
          groupName: null,
          equipmentsIds: null,
          companyName: null,
        },
      });
      this.set('examinationRoomsEquipmentsList', emberA());

    }
    this.set('globalCurrentUser', this.get('co_CurrentUserService.user'));
    this.set('fileuploadUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'technicalServiceUrl'));
    const userInfoSets = this.get('globalCurrentUser');
    let hospitalId = null;
    let tenantId=null;
    if(!isEmpty(userInfoSets)){
      hospitalId = userInfoSets.hospital.hospitalId;
      tenantId = userInfoSets.tenant.tenantId;
    }
    this.set('fileUrl', this.get('fileuploadUrl')+'file/v4/'+tenantId+'/'+hospitalId+'/view');
  },
  actions: {

  },
  parallelTestSendPrintMessage(list) {
    const resultInfo = [];
    list.forEach(item => {
      resultInfo.addObject({
        lotTypeCodeName: item.lotTypeCode.name,
        beforeChangeResult: item.beforeChangeResult,
        afterChangeResult: item.afterChangeResult,
        differenceRate: item.differenceRate,
        judgementResult: item.judgementResult
      });
    });
    const printContent = {};
    printContent.dataField = { 'parallelTestResults': resultInfo };
    const infoItems = this.get('model.registItem');
    printContent.parameterField = {
      oldLotNumber: infoItems.oldLotNumber,
      oldLotAvailableDatetime: infoItems.oldLotDate,
      newLotNumber: infoItems.newLotNumber,
      newLotAvailableDatetime: infoItems.newLotDate,
      parallelTestDatetime: infoItems.parallelTestDate,
      examinationRoomName: this.get('parallelTestItem.examinationRoom.name'),
      controlMaterialName: this.get('parallelTestItem.controlMaterial.name'),
      examinationName: this.get('parallelTestItem.examination.name'),
      registrationStaffName: this.get('parallelTestItem.registrationStaff.entryStaff.name'),
      registrationStaffNumber: this.get('parallelTestItem.registrationStaff.entryStaff.number'),
      confirmationStaffName: this.get('parallelTestItem.confirmationStaff.name'),
      confirmationStaffNumber: this.get('parallelTestItem.confirmationStaff.number')
    };
    this.set('printPopup', true);
    const printConfig ={
      'printType': 2,
      'printName': 'ParallelTest',
    };
    this.set('printConfig', printConfig);
    this.set('printContent', printContent);
  },

  async orderSetBarcodeSendPrintMessage(result){
    const printInfo = await this._getPrinterName();
    const qualityControlInfo = [];
    const barcodeList = result;
    barcodeList.forEach(item => {
      qualityControlInfo.addObject({
        specimenNumber : item.specimenNumber,
        orderDatetime : item.orderDatetime.toString(),
        lotNumber : item.lot.lotNumber,
        lotName : item.lot.lotType.name,
        equipmentName : item.equipment.name,
        controlMaterialName: item.controlMaterial.name
      });
    });
    const parameterField = {};
    const printContent = {};
    printContent.dataField = { "qualityControlInfo": qualityControlInfo };
    printContent.parameterField = parameterField;
    this.set('printPopup', false);
    const printConfig = {
      'printType': 1,
      'printName': 'QualityControlLabel',
    };
    if(isPresent(printInfo)) {
      if(isPresent(printInfo.printerG)) {
        printConfig.printerName = printInfo.printerG;
      } else if(isPresent(printInfo.printerDefault)) {
        printConfig.printerName = printInfo.printerDefault;
      }
      // console.log('printInfo--', printInfo);
    }
    // console.log('printConfig--', printConfig);
    this.set('printConfig', printConfig);
    this.set('printContent', printContent);
    this.auditPrint('orderSetBarcodeSendPrintMessage', 'QualityControlLabel', printContent);
  },

  async _getPrinterName() {
    try {
      let printerG = null;
      let printerD = null;
      let printerF = null;
      let printerDefault = null;
      const result = await this.get('co_PersonalizationService').getPersonalPrinterSetting('Laboratory', 'print');
      if(!isEmpty(result)) {
        const settingValue = JSON.parse(result.get('firstObject.settingValue'));
        const printerName = function (code) {
          return settingValue.item.findBy('printSettingCode', code).printerName;
        };
        if(!isEmpty(settingValue)) {
        // G: 일반검체, D: 당일검체, F: 응검검체, B: 배지라벨
          printerDefault = settingValue.defaultLabelPrinter;
          printerG = printerName('G');
          printerD = printerName('D');
          printerF = printerName('F');
        }
      }
      return {
        'printerDefault': printerDefault,
        'printerG' : printerG,
        'printerD' : printerD,
        'printerF' : printerF,
      };
    } catch(e) {
      console.log('_getPrinterName error::', e);
    }

  },

  analysisSendPrintMessage(list) {
    const analysisInfo = [];
    list.forEach(d => {
      analysisInfo.addObject({ "lotTypeName": d.lot.lotType.name,
        "examinationName": d.examination.name,
        "lotNumber" : d.lot.lotNumber,
        "targetMeanValue" : d.equipmentFactor.targetMeanSD.meanValue,
        "targetSdValue" : d.equipmentFactor.targetMeanSD.sdValue,
        "equipmentMeanValue" : d.equipmentFactor.meanSD.meanValue,
        "equipmentSdValue" : d.equipmentFactor.meanSD.sdValue,
        "equipmentCvValue" : d.equipmentFactor.cvValue,
        "equipmentBiasValue" : d.equipmentFactor.bias.biasValue,
        "equipmentBiasPercentValue" : d.equipmentFactor.bias.biasPercentValue,
        "comparisonEquipmentMeanValue" : d.comparisonEquipmentFactor.meanSD.meanValue,
        "comparisonEquipmentSdValue" : d.comparisonEquipmentFactor.meanSD.sdValue,
        "comparisonEquipmentCvValue" : d.comparisonEquipmentFactor.cvValue,
        "comparisonEquipmentBiasValue" : d.comparisonEquipmentFactor.bias.biasValue,
        "comparisonEquipmentBiasPercentValue" : d.comparisonEquipmentFactor.bias.biasPercentValue,
        "comparisonBiasPercentValue" : d.comparisonBias.biasPercentValue
      });
    });
    const parameterField = {
      "EQUIPMENTCODE1" : this.get('model.selectedEquipment.name'),
      "EQUIPMENTCODE2" : this.get('model.selectedCompareEquipment.name')
    };
    const printContent = {};
    printContent.dataField = { "analysisInfo": analysisInfo };
    printContent.parameterField = parameterField;

    this.set('printPopup', true);
    const printConfig ={
      'printType': 2,
      'printName': 'QualityControlCheckAnalysis'
    };
    this.set('printConfig', printConfig);
    this.set('printContent', printContent);
    this.auditPrint('analysisSendPrintMessage', 'QualityControlCheckAnalysis', printContent);

  },

  analysisPatientSpecimenSendPrintMessage(chartDataList) {
    const printContent = {};
    printContent.dataField = {};
    const multiPrintContent = [];
    const parameterField = {
      equipmentName : this.get('model.selectedEquipment.name'),
      compareEquipmentName : this.get('model.selectedCompareEquipment.name'),
      lotNumber: this.get('model.selectedControlMaterialsLot.lotNumber')
    };
    let targetInd = 0;
    chartDataList.forEach((datas, index) => {
      if (index % 6 === 0) {
        targetInd = 1;
        printContent.dataField = {};
      } else {
        targetInd++;
      }
      const indexObjName = `graphData${targetInd}`;
      const info = [];
      const lowValue = datas.customYAxis[3];
      const highValue = datas.customYAxis[4];
      datas.chartData.forEach(d => {
        info.addObject({
          qualityControlDatetime: this.get('fr_I18nService').formatDate(new Date(d.qualityControlDatetime), 'G'),
          referenceCVLowValue: lowValue,
          referenceCVHighValue: highValue,
          biasPercentValue: d.bias.biasPercentValue,
          examinationName: d.examination.name
        });
      });
      printContent.dataField[indexObjName] = info;
      if (index % 6 === 0) {
        const _elements = {
          "file" : "qualityControlAnalysisPatient",
          "parameterField" : parameterField,
          "dataField" : printContent.dataField
        };
        multiPrintContent.push(_elements);
      }

    });
    this.set('printPopup', true);
    const printConfig =
    {
      'printType': 2,
      'printName': 'qualityControlAnalysisPatient'
    };
    console.log('multiPrintContent--', multiPrintContent);
    this.set('printConfig', printConfig);
    this.set('multiPrintContent', multiPrintContent);
    this.auditPrint('analysisPatientSpecimenSendPrintMessage', 'qualityControlAnalysisPatient', multiPrintContent);
  },

  cvMonitoringSendPrintMessage(chartDataList) {
    const printContent = {};
    printContent.dataField = {};
    const parameterField = {
      equipmentName : this.get('model.selectedEquipment.name'),
      materialName : this.get('model.selectedControlMaterial.name'),
    };
    const multiPrintContent = [];
    let targetInd = 0;
    chartDataList.forEach((datas, index) => {
      if (index % 4 === 0) {
        targetInd = 1;
        printContent.dataField = {};
      } else {
        targetInd++;
      }
      const indexObjName = `graphData${targetInd}`;
      const info = [];
      datas.chartData.forEach(d => {
        info.addObject({
          qualityControlDatetime: d.qualityControlDatetime,
          referenceCVLowValue: d.referenceCV.lowValue,
          referenceCVHighValue: d.referenceCV.highValue,
          qualityControlFactorCvValue: d.qualityControlFactor.cvValue,
          examinationName: d.examination.name
        });
      });
      printContent.dataField[indexObjName] = info;
      if (index % 4 === 0) {
        const _elements = {
          "file" : "QualityControlCvMonitoring",
          "parameterField" : parameterField,
          "dataField" : printContent.dataField
        };
        multiPrintContent.push(_elements);
      }
    });
    this.set('printPopup', true);
    const printConfig =
    {
      'printType': 2,
      'printName': 'QualityControlCvMonitoring'
    };
    this.set('printConfig', printConfig);
    this.set('multiPrintContent', multiPrintContent);
    this.auditPrint('cvMonitoringSendPrintMessage', 'QualityControlCvMonitoring', multiPrintContent);
  },

  async checkSendPrintMessage(list) {
    try {
      let firstSignImageUrl = null;
      let lastSignImageUrl = null;
      let firstStaffName = null;
      let lastStaffName = null;
      const currentFactor = this.get('model.currentFactor');
      if(isPresent(currentFactor)) {
        if(isPresent(currentFactor.firstConfirmedStaff)) {
          firstStaffName = currentFactor.firstConfirmedStaff.name;
          const firstResult = await this.get('qualityManagementService').getEmployeeSignature(currentFactor.firstConfirmedStaff.id);
          if(isPresent(firstResult)) {
            firstSignImageUrl = `${this.get('fileUrl')}/${firstResult.imagePath}`;
          }
        }
        if(isPresent(currentFactor.lastConfirmedStaff)) {
          lastStaffName = currentFactor.lastConfirmedStaff.name;
          const lastResult = await this.get('qualityManagementService').getEmployeeSignature(currentFactor.lastConfirmedStaff.id);
          if(isPresent(lastResult)) {
            lastSignImageUrl = `${this.get('fileUrl')}/${lastResult.imagePath}`;
          }
        }
      }
      const qualityControlInfo = [];
      list.forEach(d => {
        qualityControlInfo.addObject({
          "resultDate" : d.qualityControlDatetime,
          "resultValue" : d.resultValue,
          "rules": d.ruleNameList,
          "comment": d.resultComment
        });
      });
      const fromDate = this.get('fr_I18nService').formatDate(new Date(this.get('selectedFromDate')), 'd');
      const toDate = this.get('fr_I18nService').formatDate(new Date(this.get('selectedToDate')), 'd');
      const parameterField = {
        "equipmentName" : this.get('model.selectedEquipment.name'),
        "materialName" : this.get('model.selectedControlMaterial.name'),
        "lotName" : this.get('model.selectedControlMaterialsLot.lotNumber'),
        "meanValue" : this.get('model.currentFactor.meanSD.meanValue'),
        "sdValue" : this.get('model.currentFactor.meanSD.sdValue'),
        "cvValue" : this.get('model.currentFactor.cvValue'),
        "printPeriod" : `${fromDate} ~ ${toDate}`,
        "testCode" : this.get('model.displayExaminationName'),
        firstSignImageUrl: firstSignImageUrl,
        lastSignImageUrl: lastSignImageUrl,
        firstStaffName: firstStaffName,
        lastStaffName: lastStaffName
      };
      const printContent = {};
      printContent.dataField = {"qualityControlInfo": qualityControlInfo};
      printContent.parameterField = parameterField;
      this.set('printPopup', true);
      const printConfig ={
        'printType': 2,
        'printName': 'qualityControlCheck'
      };
      this.set('printConfig', printConfig);
      this.set('printContent', printContent);
      this.auditPrint('checkSendPrintMessage', 'qualityControlCheck', printContent);
    } catch(e) {
      //
    }
  },

  checkGraphSendPrintMessage(list){
    const info = [];
    list.forEach(d => {
      info.addObject({
        date: this.get('fr_I18nService').formatDate(new Date(d.qualityControlDatetime), this.get('headerFormatType')),
        resultMean: d.resultValue,
        targetMean: d.targetMeanSD.meanValue,
        minus1SD: d.targetMeanSD.minus1SDValue,
        plus1SD: d.targetMeanSD.plus1SDValue,
        minus2SD: d.targetMeanSD.minus2SDValue,
        plus2SD: d.targetMeanSD.plus2SDValue,
        minus3SD: d.targetMeanSD.minus3SDValue,
        plus3SD: d.targetMeanSD.plus3SDValue

      });
    });
    const printContent = {};
    printContent.dataField = {graphData: info};
    const parameterField = {
      equipmentName : this.get('model.selectedEquipment.name'),
      materialName : this.get('model.selectedControlMaterial.name'),
      lotName : this.get('model.selectedControlMaterialsLot.lotNumber'),
      examinationName: list[0].examination.name
    };
    printContent.parameterField = parameterField;

    this.set('printPopup', true);
    const printConfig ={
      'printType': 2,
      'printName': 'qualityControlCheckGraph'};
    this.set('printConfig', printConfig);
    this.set('printContent', printContent);
    this.auditPrint('checkGraphSendPrintMessage', 'qualityControlCheckGraph', printContent);

  },
  checkByLevelSendPrintMessage(dataGroup, curruntFactors) {
    const chartDatas = [];
    dataGroup.forEach(datas => {
      chartDatas.push(datas.chartData);
    });
    const multiPrintContent = [];
    const qualityControlInfo = [];
    const printContent = {};
    let dataIndex = 0;
    let tempObj = {};
    let infoObj = {};
    let infoList = [];
    chartDatas.forEach((data, ind) => {
      if (ind % 3 === 0) {
        dataIndex = 1;
        printContent.dataField = {};
        tempObj = {};
        infoList = [];
      } else {
        dataIndex++;
      }
      const currentFactor = curruntFactors.findBy('id', data[0].lot.id);
      tempObj.equipmentName = data[0].equipment.name;
      tempObj.printPeriod = this.get('selectedDate');
      tempObj.testCode = data[0].examination.name;
      tempObj[`materialName${dataIndex}`] = data[0].controlMaterial.name;
      tempObj[`lotName${dataIndex}`] = data[0].lot.lotType.name;
      tempObj[`lotNumber${dataIndex}`] = data[0].lot.lotNumber;
      tempObj[`meanValue${dataIndex}`] = currentFactor.meanSD.meanValue;
      tempObj[`sdValue${dataIndex}`] = currentFactor.meanSD.sdValue;
      tempObj[`cvValue${dataIndex}`] = currentFactor.cvValue;

      data.forEach(d => {
        infoObj = {};
        infoObj.resultDate = d.qualityControlDatetime;
        if (!isEmpty(d.resultComment) || !isEmpty(d.rules)) {
          infoObj[`resultValue${dataIndex}`] = d.resultValue;
          infoObj[`rules${dataIndex}`] = d.ruleNameList;
          infoObj[`comment${dataIndex}`] = d.resultComment;
          infoList.push(infoObj);
        }

        qualityControlInfo.addObject(infoObj);
      });
      printContent.dataField = { "qualityControlInfo": infoList };

      if (ind % 3 === 0) {
        const _elements = {
          "file" : "QualityControlCheckByLevel",
          "parameterField" : tempObj,
          "dataField" : printContent.dataField
        };
        multiPrintContent.push(_elements);
      }

    });

    this.set('printPopup', true);
    const printConfig =
    {
      'printType': 2,
      'printName': 'QualityControlCheckByLevel'
    };
    this.set('printConfig', printConfig);
    this.set('multiPrintContent', multiPrintContent);
    this.auditPrint('checkByLevelSendPrintMessage', 'QualityControlCheckByLevel', multiPrintContent);
  },

  checkByLevelGraphSendPrintMessage(dataGroup, curruntFactors){
    const chartDatas = [];
    dataGroup.forEach(datas => {
      chartDatas.push(datas.chartData);
    });
    // console.log('dataGroup---', dataGroup);
    const qualityControlInfo = [];
    const printContent = {};
    printContent.dataField = { "qualityControlInfo": qualityControlInfo };
    chartDatas.forEach((data, ind) => {
      const indexObjName = `graphData${ind+1}`;
      data.forEach(d => {
        const currentFactor = curruntFactors.findBy('id', d.lot.id);
        if(!isEmpty(d.resultComment)) {
          qualityControlInfo.addObject({
            lotNo: d.lot.lotNumber,
            level : `${d.controlMaterial.name}${d.lot.lotType.name}`,
            resultDate: d.qualityControlDatetime,
            result: d.resultValue,
            comment: d.resultComment,
            controlRules: d.ruleNameList,
          });
        }
        let tempObj = {};
        tempObj = {
          lotNo: d.lot.lotNumber,
          date: d.qualityControlDatetime,
          resultMean: d.resultValue,
          targetMean: d.targetMeanSD.meanValue,
          minus1SD: d.targetMeanSD.minus1SDValue,
          plus1SD: d.targetMeanSD.plus1SDValue,
          minus2SD: d.targetMeanSD.minus2SDValue,
          plus2SD: d.targetMeanSD.plus2SDValue,
          minus3SD: d.targetMeanSD.minus3SDValue,
          plus3SD: d.targetMeanSD.plus3SDValue,
          targetSd: d.targetMeanSD.sdValue,
          currentMean: currentFactor.meanSD.meanValue,
          currentSd: currentFactor.meanSD.sdValue,
          currentCv: currentFactor.cvValue,
          lotType: d.lot.lotType.displayCode,
        };
        if (printContent.dataField[indexObjName]) {
          printContent.dataField[indexObjName].addObject(tempObj);
        } else {
          printContent.dataField[indexObjName] = [tempObj];
        }

      });
    });

    const parameterField = {
      "equipName" : this.get('model.selectedEquipment.name'),
      "testName" : this.get('model.selectedExamination.name'),
      "controlCode" : this.get('model.selectedControlMaterial.name')
    };
    printContent.parameterField = parameterField;

    this.set('printPopup', true);
    const printConfig ={
      'printType': 2,
      'printName': 'QualityControlCheckGraphByLevel'};
    this.set('printConfig', printConfig);
    this.set('printContent', printContent);
    this.auditPrint('checkByLevelGraphSendPrintMessage', 'QualityControlCheckGraphByLevel', printContent);

  },

  _getExportExcel(itemList, colInfo) {
    /* make the worksheet */
    const exportItemsWS = XLSX.utils.json_to_sheet(itemList, {cellDates: true, dateNF: 'YYYY-MM-DD HH:mm:ss'});
    if (!isEmpty(colInfo)) {
      exportItemsWS['!cols'] = colInfo;
    }
    /* add to workbook */
    const wb = XLSX.utils.book_new();

    XLSX.utils.book_append_sheet(wb, exportItemsWS, 'sheet1');
    const fileName = new Date(this.get('co_CommonService').getNow());
    /* generate an XLSX file */
    XLSX.writeFile(wb, `${fileName}.xlsx`);
    this.auditExcelExport('_getExportExcel', 'laboratoryqualitymanagement', itemList.get('firstObject'));
  },

  _getExportByArrayTypeExcel(initial, itemList) {
    /* Initial row */
    const exportItemsWS = XLSX.utils.aoa_to_sheet(initial);
    /* Write data starting at A2 */
    XLSX.utils.sheet_add_aoa(exportItemsWS, itemList, {origin: "A3"});
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, exportItemsWS, 'sheet1');
    const fileName = new Date(this.get('co_CommonService').getNow());
    XLSX.writeFile(wb, `${fileName}.xlsx`);
    this.auditExcelExport('_getExportByArrayTypeExcel', 'laboratoryqualitymanagement', itemList.get('firstObject'));
  },


});