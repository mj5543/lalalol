import CHIS from 'framework/chis-framework';
import config from '../app-config';

export default CHIS.FR.Core.ServiceBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, {

  urlPrefix: '',

  init() {
    this._super(...arguments);

    const defaultUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', 'laboratoryqualitymanagement') +
    `laboratory-quality-management/${config.version}`;

    this.set('urlPrefix', defaultUrl);
  },

  getQualityControlOrderSet(roomId) {
    const param = {
      examinationRoomId: roomId
    };

    return this.getList(`${this.get('urlPrefix')}/quality-control-order-sets`, param, null).then(res => res);
  },

});