import CHIS from 'framework/chis-framework';
import config from '../app-config';

export default CHIS.FR.Core.ServiceBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, {

  urlPrefix: '',
  userGlobalInformation: null,
  materialsPath: null,
  materialsLotsPath: null,
  materialsLotsItemsPath: null,
  equipmentsPath: null,

  init() {
    this._super(...arguments);

    const defaultUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', 'laboratoryqualitymanagement') +
      `laboratory-quality-management/${config.version}`;

    this.set('urlPrefix', defaultUrl);
    this.set('materialsPath', `${defaultUrl}/control-materials`);
    this.set('materialsLotsPath', `${defaultUrl}/control-materials/lots`);
    this.set('materialsLotsItemsPath', `${defaultUrl}/control-materials/lots/items`);
    this.set('equipmentsPath', `${defaultUrl}/equipments`);
    this.set('userGlobalInformation', this.get('co_CurrentUserService.user'));
    this.set('roiUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'roi') + `roi/v0/`);
  },
  getEmployeeSignature(employeeId) {
    return this.getList(this.get('roiUrl') + `codes/employee-signatures/${employeeId}`);
  },

  getExaminationRooms() {
    const param = {
      departmentId: this.get('userGlobalInformation.hospital.appointmentDepartmentId')
    };

    return this.getList(`${this.get('urlPrefix')}/examination-rooms`, param, null);
  },

  getControlMaterialsOrderList(param) {
    return this.getList(`${this.get('urlPrefix')}/control-materials/order-list`, param, null);
  },

  getControlMaterials(param) {
    return this.getList(this.get('materialsPath'), param, null);
  },

  updateControlMaterials(param) {
    return this.update(this.get('materialsPath'), null, false, param, false);
  },

  createControlMaterials(param) {
    return this.create(this.get('materialsPath'), null, param, false);
  },

  deleteControlMaterials(param) {
    return this.delete(this.get('materialsPath'), null, param, false);
  },

  controlMaterialsChangeDisplaySequence(param) {
    return this.update(`${this.get('materialsPath')}/change-display-sequence`, null, false, param, false);
  },

  getExaminationsUnits(id) {
    return this.getList(`${this.get('materialsPath')}/specimen-examinations/${id}/units`, null, null);
  },

  getControlMateriasLot(param) {
    return this.getList(this.get('materialsLotsPath'), param, null).then(res => res);
  },

  updateControlMaterialsLots(param) {
    return this.update(this.get('materialsLotsPath'), null, false, param, false);
  },

  createControlMaterialsLots(param) {
    return this.create(this.get('materialsLotsPath'), null, param, false);
  },

  deleteControlMaterialsLots(param) {
    return this.delete(this.get('materialsLotsPath'), null, param, false);
  },

  getControlMateriasLotItems(param) {
    return this.getList(this.get('materialsLotsItemsPath'), param, null).then(res => res);
  },

  updateControlMaterialsLotsItems(param) {
    return this.update(this.get('materialsLotsItemsPath'), null, false, param, false);
  },

  createControlMaterialsLotsItems(param) {
    return this.create(this.get('materialsLotsItemsPath'), null, param, false);
  },

  deleteControlMaterialsLotsItems(param) {
    return this.delete(this.get('materialsLotsItemsPath'), null, param, false);
  },

  controlMaterialsLotsItemsChangeDisplaySequence(param) {
    return this.update(`${this.get('materialsLotsItemsPath')}/change-display-sequence`, null, false, param, false);
  },

  // getEquipments(param) {
  //   return this.getList(this.get('equipmentsPath'), param, null);
  // },
  getEquipments(param) {
    const callUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', config.service);
    return this.getList(callUrl + 'laboratory-management/v0/equipments', param, null);
  },

  updateEquipments(param) {
    return this.update(this.get('equipmentsPath'), null, false, param, false);
  },

  createEquipments(param) {
    return this.create(this.get('equipmentsPath'), null, param, false);
  },

  deleteEquipments(param) {
    return this.delete(this.get('equipmentsPath'), null, param, false);
  },

  equipmentsChangeDisplaySequence(param) {
    return this.update(`${this.get('equipmentsPath')}/change-display-sequence`, null, false, param, false);
  },

  getQualityControlResultsSearch(param) {
    return this.getList(`${this.get('urlPrefix')}/quality-control-results/search`, null, param, false).then(res => res);
  },

  getQualityControlResultsChecksSearch(param) {
    return this.getList(`${this.get('urlPrefix')}/quality-control-results/checks/search`, null, param, false).then(res => res);
  },

  getQualityControlResultsMonitorFactor(param) {
    return this.getList(`${this.get('urlPrefix')}/quality-control-results/monitor-factor`, null, param, false).then(res => res);
  },

  getQualityControlResultsCurrentFactor(param) {
    return this.getList(`${this.get('urlPrefix')}/quality-control-results/current-factor`, null, param, false).then(res => res);
  },

  getQualityControlResultsCompareFactor(param) {
    return this.getList(`${this.get('urlPrefix')}/quality-control-results/compare-factor`, null, param, false).then(res => res);
  },

  getQualityControlResultsCompareSpecimen(param) {
    return this.getList(`${this.get('urlPrefix')}/quality-control-results/compare-specimen`, null, param, false).then(res => res);
  },

  getQualityControlResultsCumulativeFactor(param) {
    return this.getList(`${this.get('urlPrefix')}/quality-control-results/cumulative-factor`, param, null).then(res => res);
  },

  createRulesApply(param) {
    return this.create(`${this.get('urlPrefix')}/quality-control-results/rules/apply`, null, param, false);
  },

  getLaboratoryBusinessCode(param) {
    return this.getList(`${this.get('urlPrefix')}/business-codes/search`, param, null);
  },

  getParallelTest(param) {
    return this.getList(`${this.get('urlPrefix')}/parallel-test`, param, null);
  },

  createParallelTest(param) {
    return this.create(`${this.get('urlPrefix')}/parallel-test`, null, param, false);
  },

  updateParallelTest(param) {
    return this.update(`${this.get('urlPrefix')}/parallel-test`, null, false, param, false);
  },

  deleteParallelTest(param) {
    return this.delete(`${this.get('urlPrefix')}/parallel-test`, null, param, false);
  },

  getParallelTestResults(param) {
    return this.getList(`${this.get('urlPrefix')}/parallel-test/Results`, param, null);
  },

  getParallelTestLotTypes(param) {
    return this.getList(`${this.get('urlPrefix')}/parallel-test/LotTypes`, param, null);
  },

  createParallelTestCalculrateDiff(params) {
    return this.create(`${this.get('urlPrefix')}/parallel-test/calculrate-difference`, null, params, false);
  },
  getComfirm(param) {
    return this.getList(`${this.get('urlPrefix')}/quality-control-confirm`, param, null);
  },
  getComfirmItems(param) {
    return this.getList(`${this.get('urlPrefix')}/quality-control-confirm/items`, param, null);
  },
  createConfirm(param) {
    return this.create(`${this.get('urlPrefix')}/quality-control-confirm`, null, param, false);
  },
  cancelConfirm(param) {
    return this.update(`${this.get('urlPrefix')}/quality-control-confirm/cancel`, null, false, param, false);
  },
  lastConfirm(param) {
    return this.update(`${this.get('urlPrefix')}/quality-control-confirm/confirm`, null, false, param, false);
  },
  lastConfirmCancel(param) {
    return this.update(`${this.get('urlPrefix')}/quality-control-confirm/confirm-cancel`, null, false, param, false);
  },

});