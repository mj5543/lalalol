// import Ember from 'ember';
// import layout from './template';
// import CHIS from 'framework/chis-framework';
// //if needed, import config object
// import config from 'laboratoryqualitymanagement-module/app-config';
// //if needed, import model class
// //import Patient from 'laboratoryqualitymanagement-module/models/patient';

// export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
//   /* Only For Server-Call Component
//   CHIS.FR.CrossCutting.ServerCallMixin,
//   */
//   {
//     /* 1. Service define Area
//      testService:service(),
//     */
//     layout,
//     model: null,
//     selectedExaminationRoom: null,
//     qualityControlOrderSetList: emberA(),
//     controlOrderSetColumns: null,
//     controlOrderSetGridData: null,
//     controlOrderSetItemsColumns: null,
//     controlOrderSetItemsGridData: null,
//     controlOrderGeneralColumns: null,
//     controlOrderGeneralGridData: null,
//     controlOrderExaminationColumns: null,
//     controlOrderExaminationGridData: null,
//     popupGridData: null,
//     selectedDate: null,
//     isOrderSetOpen: null,
//     controlMaterialList: null,
//     controlMaterialsLotList: null,
//     equipmentList: null,
//     controlOrderSpecimenNumbers: null,
//     selectedControlOrderItems: null,
//     controlOrderBarcodeItmeList: null,
//     controlOrderService:service('laboratory-quality-management-order-service'),

//     onPropertyInit() {
//       this._super(...arguments);
//       this.set('viewId', 'laboratory-quality-management-quality-control-order-set');


//       this.setStateProperties([
//         'model',
//         'qualityControlOrderSetList',
//         'controlOrderSetColumns',
//         'controlOrderSetGridData',
//         'controlOrderSetItemsColumns',
//         'controlOrderSetItemsGridData',
//         'controlOrderExaminationColumns',
//         'controlOrderExaminationGridData',
//         'popupGridColumns',
//         'popupGridData',
//         'selectedDate',
//         'isOrderSetOpen',
//         'controlMaterialList',
//         'controlMaterialsLotList',
//         'equipmentList',
//         'selectedExaminationRoom',
//         'controlOrderSpecimenNumbers',
//         'selectedControlOrderItems',
//         'controlOrderBarcodeItmeList'
//       ]);

//       if(this.hasState()===false) {

//         this.set('model', {
//           selectedOrderSet: {
//             name: null,
//             id: null
//           },
//           orderSetItemSource: emberA(),
//           selectedControlMaterial: null,
//           selectedControlMaterialId: null,
//           selectedControlMaterialsLot: null,
//           selectedControlMaterialsLotId: null,
//           selectedEquipment: null,
//           selectedEquipmentId: null,
//           popupGridSelectedRows: null,
//         });

//         const displayDate = new Date(this.get('co_CommonService').getNow());
//         this.set('selectedDate', displayDate);
//         this.set('controlOrderSetColumns', [
//           { field: 'name', title: '세트명', width:120},
//         ]);
//         this.set('controlOrderSetGridData', emberA());

//         this.set('controlOrderSetItemsColumns', [
//           { field: 'orderItem.controlMaterial.name', title: '정도관리 물질', width:120},
//           { field: 'orderItem.lot.lotNumber', title: 'Lot 번호', width:120},
//           { field: 'equipment.name', title: '장비', width:120},
//         ]);
//         this.set('controlOrderSetItemsGridData', emberA());

//         this.set('popupGridColumns', [
//           { field: 'controlMaterial.name', title: '정도관리 물질', width:120},
//           { field: 'lot.lotNumber', title: 'Lot 번호', width:120},
//           { field: 'equipment.name', title: '장비', width:120},
//         ]);
//         this.set('popupGridData', emberA());
//         this.set('isOrderSetOpen', false);
//       }
//     },

//     onLoaded() {
//       this._super(...arguments);
//       console.log('aboratory-quality-management-order-');
//       // this.set('menuClass', 'w680');
//     },

//     actions: {
//       onSelectedOrderControlSet(e) {
//         console.log('e---', e);
//         const selectedItem = e.selectedItems[0];
//         if(selectedItem) {
//           this.set('model.selectedOrderSet.name', selectedItem.name);
//           this.set('model.selectedOrderSet.id', selectedItem.qualityControlOrderSetId);
//           this.getOrderItems(selectedItem);
//         }
//       },
//       onSelectedOrderControlGeneral(e) {
//         console.log('e---', e);
//         const selectedItem = e.selectedItems[0];
//         if(selectedItem) {
//           this.set('model.selectedOrderControlGeneralItem', selectedItem);
//           this.set('controlOrderExaminationGridData', selectedItem.lot.lotItems);
//         }
//       },

//       onOrderSetDelete() {
//         this._deleteOrderSet();
//         this.getGridData();
//       },

//       onOpenPopupAction() {
//         console.log('onOpenPopupAction-----');
//         this.set('isOrderSetOpen', true);
//       },
//       onPopupOpenedAction(e) {
//         console.log('onPopupOpenedAction---', e);
//         this.getControlMaterials();
//         this.setPopupGridData();
//       },
//       onControlMaterialChange(e) {
//         console.log('onControlMaterialChange---', e);
//         const selectedItems = e.selectedItems;
//         if(selectedItems.length > 0) {
//           this.getControlMateriasLot(selectedItems[0].controlMaterialId);
//         } else {
//           // this.set('model.selectedControlMaterialsLotId', this.get('controlMaterialList')[0].controlMaterialId);
//           this.getControlMateriasLot(this.get('controlMaterialList')[0].controlMaterialId);
//         }
//       },
//       onControlMaterialsLotChange(e) {
//         console.log('onControlMaterialChange---', e);
//         const selectedItems = e.selectedItems;
//         if(selectedItems.length > 0) {
//           this.getApplyEquipments(selectedItems[0].controlMaterialId);
//         }
//       },
//       onEquipmentChange(e) {
//         console.log('onEquipmentChange---', e);

//       },
//       deletePopupGridItem() {
//         const deleteItems = this.get('model.popupGridSelectedRows');
//         if (deleteItems) {
//           deleteItems.forEach((item) => {
//             this.get('popupGridData').removeObject(item);
//           });
//         }
//       },
//       addPopupGridItem() {
//         const material = this.get('model.selectedControlMaterial');
//         const lot = this.get('model.selectedControlMaterialsLot');
//         const equipment = this.get('model.selectedEquipment');
//         const obj = {
//           equipment: {
//             id: equipment.id,
//             name: equipment.name
//           },
//           controlMaterial: {
//             id: material.controlMaterialId,
//             name: material.name
//           },
//           lot: {
//             id: lot.lotId,
//             lotNumber: lot.lotNumber
//           }
//       };
//         this.get('popupGridData').addObject(obj);
//       },
//       onPopupMultiSelected(e) {
//         console.log('onPopupMultiSelected---', e);
//         this.set('model.popupGridSelectedRows', e.selectedItems);
//       },
//       onSave() {
//         this._controlSetSave();
//         this.getGridData();
//       },
//       popupReset() {
//         this.setPopupGridData();
//       },
//       onPopupClosedAction() {
//         this.set('popupGridData', emberA());
//       },
//       onSelectedChangedBarcodeItem(e) {
//         console.log('onSelectedChangedBarcodeItem---', e);
//         this.set('selectedControlOrderItems', e.selectedItems);
//       },
//       onBarcodeButtonClick() {
//         this.getControlOrderSpecimenNumbers();
//       }
//     },

//     _controlSetSave() {
//       const updateData = this.getUpdateData();
//       const path = `${this.get('controlOrderService').urlPrefix}/quality-control-order-sets`;
//       if (this.get('model.selectedOrderSet.id') === null) {
//         delete updateData.qualityControlOrderSetId;
//         console.log('updateData---', updateData);
//         this.create(path, null, updateData, false).then(this._success.bind(this));
//       } else {
//         this.update(path, null, false, updateData, false).then(this._success.bind(this));
//       }

//     },

//     _deleteOrderSet() {
//       const deleteSetId = this.get('model.selectedOrderSet.id');
//       const param = {
//         qualityControlOrderSetId: deleteSetId
//       };
//       const path = `${this.get('controlOrderService').urlPrefix}/quality-control-order-sets`;
//       this.delete(path, null, param, false).then(this._success.bind(this));
//     },

//     _success() {
//       alert('update success');
//     },

//     getGridData(){
//       this.set('model.selectedOrderSet.id', null);
//       this.set('model.selectedOrderSet.name', null);
//       this.get('getDataListCB')();
//     },
//     getUpdateData() {
//       const updatedData = this.get('popupGridData');
//       let orderItemArr = [];
//       updatedData.forEach((item) => {
//         orderItemArr.push({lotId: item.lot.id, equipmentId: item.equipment.id})
//       });

//       let returnData = {
//         qualityControlOrderSetId: this.get('model.selectedOrderSet.id'),
//         name: this.get('model.selectedOrderSet.name'),
//         examinationRoomId: this.get('selectedExaminationRoom'),
//         orderItems: orderItemArr
//       };
//       console.log('returnData---', returnData);

//       return returnData;

//     },

//     setPopupGridData() {
//       const targetGridData = this.get('controlOrderSetItemsGridData');
//       const tempArr = [];
//       const tempObj = {};
//       targetGridData.forEach((item) => {
//         tempArr.push({equipment: item.equipment, controlMaterial: item.orderItem.controlMaterial, lot: item.orderItem.lot});
//       });
//       this.set('popupGridData', tempArr);
//     },

//     getControlOrderSpecimenNumbers() {
//       let orderParams = [];
//       if(this.get('model.selectedTabName') === 'setOrder') {
//         orderParams = this.getSetBarcodeItem();
//       } else {
//         orderParams = this.getGeneralBarcodeItem();
//       }

//       const params = {
//         orderDatetime: new Date(this.get('selectedDate')),
//         qualityControlOrders: orderParams
//       };
//       const path = `${this.get('controlOrderService').urlPrefix}/quality-control-orders`;
//       this.getList(path, null, params, false).then(function(res){
//         console.log('getControlOrderSpecimenNumbers:::', res);
//         this.set('controlOrderSpecimenNumbers', res.specimenNumbers);
//         this.getControlOrdersSearch();
//       }.bind(this));
//     },

//     getSetBarcodeItem() {
//       const items = this.get('selectedControlOrderItems');
//       let orderList = [];
//       items.forEach((item) => {
//         orderList.push({equipmentId: item.equipment.id, lotId: item.orderItem.lot.id, observations: null});
//       });
//       return orderList;
//     },

//     getGeneralBarcodeItem() {
//       const items = this.get('selectedControlOrderItems');
//       const selectedItem = this.get('model.selectedOrderControlGeneralItem');
//       const lotItem = selectedItem.orederItem ? selectedItem.orederItem.lot : selectedItem.lot;
//       const orderList = [];
//       const examinationIds = [];
//       items.forEach((item) => {
//         examinationIds.push({examinationId: item.examination.id});
//       });
//       const observationParam = examinationIds.length > 0 ? examinationIds : null;
//       orderList.push({equipmentId: selectedItem.equipment.id, lotId: lotItem.id, observations: observationParam});
//       return orderList;
//     },

//     getControlOrdersSearch() {
//       const param = {
//         specimenNumbers: this.get('controlOrderSpecimenNumbers')
//       };
//       const path = `${this.get('controlOrderService').urlPrefix}/quality-control-orders/search`;
//       this.getList(path, null, param, false).then(function(res){
//         // console.log('getControlOrdersSearch:::', res);
//         this.set('controlOrderBarcodeItmeList', res);
//         this.get('sendPrintMessage')(res);
//       }.bind(this));
//     },

//     getControlMaterials() {
//       const param = {
//         examinationRoomId: this.get('selectedExaminationRoom')
//       };

//       this.getList(`${this.get('controlOrderService').urlPrefix}/control-materials`, param, null).then(function(result) {
//         this.set('controlMaterialList', result);
//         this.set('model.selectedControlMaterialId', result[0].controlMaterialId);
//         this.getControlMateriasLot();
//         console.log('controlMaterialList--', result);
//       }.bind(this));
//     },

//     getControlMateriasLot(materialId) {
//       const param = {
//         controlMaterialId: this.get('model.selectedControlMaterialId')
//       };

//       this.getList(`${this.get('controlOrderService').urlPrefix}/control-materials/lots`, param, null).then(function(result) {
//         this.set('controlMaterialsLotList', result);
//         this.set('model.selectedControlMaterialsLotId', result[0].lotId);
//         console.log('controlMaterialsLotList--', result);
//       }.bind(this));
//     },

//     getApplyEquipments(materialId) {
//       const materialList = this.get('controlMaterialList');
//       const findSetItems = materialList.find((d) => {
//         return d.controlMaterialId === materialId;
//       });
//       this.set('equipmentList', findSetItems.applyEquipments);
//       this.set('model.selectedEquipmentId', findSetItems.applyEquipments[0].id);
//     },

//     getOrderItems(orderSet) {
//       // const orderSetList = this.get('qualityControlOrderSetList');
//       // const findSetItems = orderSetList.find((d) => {
//       //   return d.qualityControlOrderSetId === orderSet.qualityControlOrderSetId;
//       // });
//       // this.set('controlOrderSetItemsGridData', findSetItems.orderItems);
//       this.set('controlOrderSetItemsGridData', orderSet.orderItems);

//     }

//   });