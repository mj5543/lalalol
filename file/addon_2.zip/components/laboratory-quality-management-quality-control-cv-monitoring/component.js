/* eslint-disable max-lines-per-function */
/* eslint-disable no-console */
import { next } from '@ember/runloop';
import { isEmpty } from '@ember/utils';
import layout from './template';
import CHIS from 'framework/chis-framework';
import QualityControlMixin from '../../mixins/quality-control-mixin';
import QualityControlPrintMixin from '../../mixins/quality-control-print-mixin';
import QualityControlMessageMixin from '../../mixins/quality-control-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  QualityControlMixin,
  QualityControlPrintMixin,
  QualityControlMessageMixin,
  {
    layout,
    selectedFromDate: null,
    selectedToDate: null,
    periodType: null,
    monitorFactorList: null,
    monitoringGridData: null,
    monitoringColumns: null,
    cvMonitorYAxisValue: null,
    cvCustomYAxisColors: null,
    cvTargetLineValue: null,
    isCVMonitoringComp: true,
    chartDataList: null,
    examinationGroupDatas: null,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'laboratory-quality-management-quality-control-cv-monitoring');

      this.setStateProperties([
        'model',
        'selectedFromDate',
        'selectedToDate',
        'periodType',
      ]);

      if(this.hasState()===false) {

        this.set('model', {
          selectedGridCellItem: null,
          displayExaminationName: null,
          selectedGridItem: null,
        });
        this.set('periodType', 'Yearly');
        this.set('monitorFactorList', []);
        this.set('monitoringGridData', []);
        this.set('monitoringColumns', []);
        this.set('chartDataList', []);

      }
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1450');
      this.getExaminationRoomList();

    },

    actions: {
      onExpandComplete() {
        //
      },
      onOpenExpander(e) {
        this.get(e) ? this.set(e, false) : this.set(e, true);
      },
      onDateChangedAction() {
        // this.getDataList();
      },
      onExaminationChangeByCvMonitor() {
        // this.getDataList();
      },
      onSelectedAction(e) {
        const selectedItems = e.selectedItems[0];
        if (!isEmpty(selectedItems)) {
          const selectedExamination = selectedItems.examination;
          // this.set('lineChartData', this._getChartData(selectedExamination.id));
          this.set('model.displayExaminationName', selectedExamination.name);
          // this.set('isChartShow', true);
        }
      },
      onCvMonitoringPrint() {
        this.cvMonitoringSendPrintMessage(this.get('chartDataList'));
      },
      onExportExcel() {
        this._getExcelData();
      }

    },
    _getExcelData() {
      const monitorFactorList = this.get('monitoringGridData');
      const monitoringColumns = this.get('monitoringColumns');
      const tempArr = [];

      monitorFactorList.forEach(datas => {
        const tempObj = {};
        monitoringColumns.forEach(column => {
          const title = column.title.toString();
          const partsField = column.field.split('.');
          tempObj[title] = null;
          let formatDate = null;
          if (partsField[0] === 'examination') {
            tempObj[title] = datas.examination.name;
          }
          if(!isEmpty(datas[partsField[0]]) && partsField[0] !== 'examination') {
            const itemsDateTime = datas[partsField[0]].qualityControlDatetime;
            formatDate = this.get('fr_I18nService').formatDate(new Date(itemsDateTime), 'Y');
          }
          const examLagResource = this.getLanguageResource('16920', 'F', '', '검사명');
          const targetObj = tempArr.find(d => d[examLagResource] === datas.examination.name);
          if(targetObj && tempObj[examLagResource] === datas.examination.name) {
            tempArr.map((obj) => {
              if(title === formatDate && obj[examLagResource] === datas.examination.name) {
                obj[title] = datas[partsField[0]].resultValue;
              }
            });
          } else {
            tempArr.push(tempObj);
          }
        });
      });
      const colInfo = [
        {wpx: 130},
      ];
      this._getExportExcel(tempArr, colInfo);
    },

    _gridDataReset() {
      this.set('monitorFactorList', []);
      this.set('monitoringGridData', []);
      this.set('monitoringColumns', []);
      this.set('lineChartData', []);
      this.set('chartDataList', []);
      this.set('isBottomButtonDisabled', true);
      this.set('model.displayExaminationName', null);
    },

    getDataList() {
      this.set('isShowLoader', true);
      this._gridDataReset();
      this.getMonitorFactor(this.get('model.selectedExaminationId')).then(() => {
        this.set('isBottomButtonDisabled', true);
        this._gridSettings();
        // this._getChartData();
        // this.set('chartDataList', this._getChartData());
        next(this, function(){
          this.set('isShowLoader', false);
          this.set('contentLoaderType', 'spinner');
        });

      });
    },

    _gridSettings(){
      const resultGridData = this._parseGridData();
      if(!isEmpty(resultGridData)) {
        this.set('isBottomButtonDisabled', false);
      }
      this.set('model.selectedGridItem', resultGridData[0]);
      this._setGridColumn();
      this.set('monitoringGridData', resultGridData);
    },

    _parseGridData(){
      const res = this.get('monitorFactorList');
      res.map(d => {
        d.examinationId = d.examination.id;
        d.chartDisplayResult = d.qualityControlFactor.cvValue;
        d.resultValue = d.qualityControlFactor.cvValue;
        d.displayDate = d.qualityControlDatetime;
        d.qualityControlDatetime = this.get('fr_I18nService').formatDate(new Date(d.qualityControlDatetime), 'Y');
        d.qualityControlDatetime = d.qualityControlDatetime.toString();
      });
      const resultList = res.sortBy('qualityControlDatetime');
      this.set('monitorFactorList', resultList);
      const uniqExaminationList = resultList.uniqBy('examinationId');
      const uniqDateTimeList = resultList.uniqBy('qualityControlDatetime');

      const grouped = this.groupBy(resultList, item => item.examinationId);
      const groupList = [];
      uniqExaminationList.forEach(item => {
        groupList.push(grouped.get(item.examinationId));
      });

      const dateTimeGrouped = this.groupBy(resultList, item => item.qualityControlDatetime);
      const dateTimeGroupList = [];
      uniqDateTimeList.forEach(item => {
        dateTimeGroupList.push(dateTimeGrouped.get(item.qualityControlDatetime));
      });
      const tempArr = [];
      this.set('examinationGroupDatas', groupList);
      this._setChartData(groupList);
      groupList.forEach((item) => {
        item.forEach((child)=> {
          const targetIndex = dateTimeGroupList.findIndex(d => d[0].qualityControlDatetime === child.qualityControlDatetime);
          const customColumn = `columnDate${targetIndex}`;
          const targetExamination = tempArr.find(d => d.examination.id === child.examination.id);
          if(targetExamination && targetExamination.examination.id === child.examination.id) {
            tempArr.map((obj) => {
              if(obj.examination.id === child.examination.id) {
                obj[customColumn] = child;
              }
            });
          } else {
            tempArr.push({
              [customColumn]: child,
              qualityControlDatetime: child.qualityControlDatetime,
              examination: child.examination,
              equipment: child.equipment,
              lot: child.lot,
              qualityControlFactor: child.qualityControlFactor,
              referenceCV: child.referenceCV
            });
          }
        });
      });

      return tempArr;
    },

    _setGridColumn() {
      const res = this.get('monitorFactorList');
      const uniqDateTimeList = res.uniqBy('qualityControlDatetime');
      const uniqControlDateList = [];
      uniqDateTimeList.forEach((item) => {
        uniqControlDateList.push(item.qualityControlDatetime);
      });
      const resultColumns = [];
      const columnWidth = 90;
      uniqControlDateList.forEach((date ,index) => {
        const customColumn = `columnDate${index}`;
        const columnDate = this.get('fr_I18nService').formatDate(new Date(date), 'Y');
        // const columnDate = new Date(date.getFullYear(), date.getMonth());
        resultColumns.push({ field: `${customColumn}.resultValue`, title: columnDate, align: 'right', width: columnWidth,
          onBodyCellRender: function (context) {
            const cellItem = context.item;
            if (!isEmpty(cellItem[customColumn])) {
              if (cellItem[customColumn].resultValue >= 5 && cellItem[customColumn].resultValue < 10 ){
                context.cellComponent.$().css('color', '#ff6600');
                context.cellComponent.$().css('font-weight', 'bold');
              } else if(cellItem[customColumn].resultValue > 10) {
                context.cellComponent.$().css('color', '#f1260b');
                context.cellComponent.$().css('font-weight', 'bold');
              }
            }
          },
        });
      });
      this.set('monitoringColumns', [
        { field: 'examination.name', title: this.getLanguageResource('16920', 'F', '', '검사명'), width: 120},
        ...resultColumns
      ]);
    },

    _getChartData() {
      this.set('chartDataList', []);
      // const resutList = this.get('monitorFactorList');
      const resutList = this.get('examinationGroupDatas');
      // const findExaminationsData = [];
      const chartDataList = [];
      resutList.forEach(d => {
        // if(d.examinationId === id) {
        //   d.qualityControlDatetime = this.get('fr_I18nService').formatDate(new Date(d.qualityControlDatetime), 'Y');
        //   findExaminationsData.push(d);
        // }
        d.qualityControlDatetime = this.get('fr_I18nService').formatDate(new Date(d.qualityControlDatetime), 'Y');
        let chartObj = {};
        chartObj = {
          chartData: d,
          cvMonitorYAxisValue: [0, d.referenceCV.lowValue, d.referenceCV.highValue],
          cvCustomYAxisColors: ['#000000', '#000000', '#000000'],
          cvTargetLineValue: d.referenceCV.lowValue,
          examinationName: d.examination.name
        };

        chartDataList.push(chartObj);
        this.get('chartDataList').addObject({
          chartData: [d],
          cvMonitorYAxisValue: [0, d.referenceCV.lowValue, d.referenceCV.highValue],
          cvCustomYAxisColors: ['#000000', '#000000', '#000000'],
          cvTargetLineValue: d.referenceCV.lowValue,
          examinationName: d.examination.name
        });

      });

      // const referenceCVObj = findExaminationsData[0].referenceCV;
      // this.set('cvMonitorYAxisValue', [0, referenceCVObj.lowValue, referenceCVObj.highValue]);
      // this.set('cvCustomYAxisColors', ['#000000', '#000000', '#000000']);
      // this.set('cvTargetLineValue', referenceCVObj.lowValue);
      // return chartDataList;
    },
    _setChartData(list) {
      list.forEach(d => {
        let chartObj = {};
        chartObj = {
          chartData: d,
          cvMonitorYAxisValue: [0, d[0].referenceCV.lowValue, d[0].referenceCV.highValue],
          cvCustomYAxisColors: ['#000000', '#000000', '#000000'],
          cvTargetLineValue: d[0].referenceCV.lowValue,
          examinationName: d[0].examination.name
        };
        this.get('chartDataList').addObject(chartObj);


      });

    },

  });