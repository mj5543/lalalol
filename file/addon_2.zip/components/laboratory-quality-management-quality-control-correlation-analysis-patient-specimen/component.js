/* eslint-disable max-lines-per-function */
/* eslint-disable no-console */
import { isEmpty } from '@ember/utils';
import layout from './template';
import CHIS from 'framework/chis-framework';
import QualityControlMixin from '../../mixins/quality-control-mixin';
import QualityControlPrintMixin from '../../mixins/quality-control-print-mixin';
import QualityControlMessageMixin from '../../mixins/quality-control-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  QualityControlMixin,
  QualityControlPrintMixin,
  QualityControlMessageMixin,
  {
    layout,
    selectedFromDate: null,
    selectedToDate: null,
    isDisabled: null,
    showHeader: null,
    isExpanded: null,
    isGroupSearch: false,
    deviationStandard: null,
    compareSpecimenColumns: null,
    compareSpecimenData: null,
    chartDataList: null,
    controlCVValues: null,
    compareTimeHourList: null,
    isAnalysisComp: true,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'laboratory-quality-management-quality-control-correlation-analysis-patient-specimen');

      this.setStateProperties([
        'model',
        'selectedFromDate',
        'selectedToDate',
        'isDisabled',
        'showHeader',
        'isExpanded',
        'chartDataList',
        'compareTimeHourList'

      ]);

      if(this.hasState()===false) {

        this.set('model', {
          selectedGridCellItem: null,
          selectedCompareHour: null,
        });
        this.set('isDisabled', false);
        this.set('isExpanded', false);
        this.set('showHeader', true);
        this.set('booleanItemsSource', [
          { content: 'True', value: true },
          { content: 'False', value: false }
        ]);
        this.set('compareSpecimenColumns', [
          {title: this.getLanguageResource('1587', 'F', '', '기준장비'), columns: [
            { field: 'examination.name', title: this.getLanguageResource('16920', 'F', null, '검사항목'), merge: true, width: 140},
            { field: 'lot.lotNumber', title: this.getLanguageResource('215', 'F', '', 'Lot번호'), width: 100, align: 'center'},
            { field: 'qualityControlDatetime', title: this.getLanguageResource('9946', 'F', '', '검사일시'), width: 160, align: 'center'},
            { field: 'resultValue', title: this.getLanguageResource('17028', 'F', '', '결과'), width: 80, align: 'center',
              onBodyCellRender: function (context) {
                const cellItem = context.item;
                const {lowValue, highValue} = cellItem.referenceCV;
                if (cellItem.bias.biasPercentValue >= lowValue && cellItem.resultValue < highValue ){
                  context.cellComponent.$().css('color', '#004df3');
                  context.cellComponent.$().css('font-weight', 'bold');
                } else if(cellItem.bias.biasPercentValue > highValue) {
                  context.cellComponent.$().css('color', '#f1260b');
                  context.cellComponent.$().css('font-weight', 'bold');
                }
              },
            }
          ]},
          {title: this.getLanguageResource('10010', 'F', '', '비교장비'), columns: [
            { field: 'compareResultValue', title: this.getLanguageResource('17028', 'F', '', '결과'), width: 80, align: 'center',
              onBodyCellRender: function (context) {
                const cellItem = context.item;
                if (cellItem.bias.biasPercentValue >= 5 && cellItem.compareResultValue < 10 ){
                  context.cellComponent.$().css('color', '#004df3');
                  context.cellComponent.$().css('font-weight', 'bold');
                // } else if(cellItem.compareResultValue > 10) {
                } else if(cellItem.bias.biasPercentValue > 10) {
                  context.cellComponent.$().css('color', '#f1260b');
                  context.cellComponent.$().css('font-weight', 'bold');
                }
              },
            },
          ]},
          {title: this.getLanguageResource('1588', 'F', '', '기준장비에 대한 비교'),
            columns: [
              { field: 'bias.biasValue', title: 'Differencial', width: 110, align: 'center'},
              // { field: 'bias.biasPercentValue', title: 'Differencial(%)', width: 110, align: 'center'},
              { field: 'bias.biasPercentValue', title: this.getLanguageResource('14856', 'F', '', 'Difference(%)'), width: 110, align: 'center'},
              { field: 'compareResultComment', title: this.getLanguageResource('3173', 'F', '', '비고'), width: 110, bodyTemplateName:'textTooltip'},
            ]}
        ]);
        this.set('compareSpecimenData', []);

        this.set('deviationStandard', 'inherence');
        this.set('chartDataList', []);
        this.set('compareTimeHourList', []);
      }
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1360');
      this.getExaminationRoomList();
      this.getQualityControlCVValue();
      this.getCompareHourList();

    },

    actions: {
      onDateChangedAction() {
        // this.getDataList();
      },
      onExpandComplete() {
        //
      },
      onOpenExpander(e) {
        this.get(e) ? this.set(e, false) : this.set(e, true);
      },
      onSearch() {
        this.getDataList();
      },
      onAnalysisPatientPrint() {
        this.analysisPatientSpecimenSendPrintMessage(this.get('chartDataList'));
      },
      onChangedCompareHour(e) {
        const selectedItem = e.selectedItems[0];
        if(!isEmpty(selectedItem)) {
          //
        }
      },
      onExportExcel() {
        this._getExportExcelData();
      }


    },
    _gridDataReset() {
      this.set('chartDataList', []);
      this.set('compareSpecimenData', []);
    },

    getDataList() {
      this.set('isShowLoader', true);
      this._gridDataReset();
      this.getQualityControlCompareSpecimen();
    },

    async getQualityControlCompareSpecimen() {
      try {
        this.set('isBottomButtonDisabled', true);
        const selectedExaminationId = this.get('model.selectedExaminationId');
        const paramFromDate = new Date(this.get('selectedFromDate').getFullYear(), this.get('selectedFromDate').getMonth(), this.get('selectedFromDate').getDate(), 0, 0, 0).toFormatString();
        const paramToDate = new Date(this.get('selectedToDate').getFullYear(), this.get('selectedToDate').getMonth(), this.get('selectedToDate').getDate(), 0, 0, 0).toFormatString();
        const params = {
          controlMaterialId: this.get('model.selectedControlMaterialId'),
          lotId: this.get('model.selectedControlMaterialsLotId'),
          // isGroupQuery: this.get('isGroupSearch'),
          equipmentId: this.get('model.selectedEquipmentId'),
          compareEquipmentId: this.get('model.selectedCompareEquipmentId'),
          fromDatetime: paramFromDate,
          toDatetime: paramToDate,
          examinationIds: selectedExaminationId,
          compareHour: parseFloat(this.get('model.selectedCompareHour.code'))
        };
        const result = await this.get('qualityManagementService').getQualityControlResultsCompareSpecimen(params);
        if(!isEmpty(result)) {
          this.set('compareSpecimenData', result.sortBy('examination.id'));
          this._setChartData();
          this.set('isBottomButtonDisabled', false);
        }
        this.set('isShowLoader', false);
      } catch(e) {
        if(this.isDestroyed || this.isDestroying) {
          return;
        }
        this.set('isShowLoader', false);
        this._showError(e);
        console.log('getQualityControlCompareSpecimen Error:::', e);
      }
    },

    _setChartData() {
      this.set('chartDataList', []);
      let resultDataList = null;
      resultDataList = this.get('compareSpecimenData');
      resultDataList.map(d => {
        d.examinationId = d.examination.id;
        d.chartDisplayResult = d.bias.biasPercentValue;
        d.qualityControlDatetime = this.get('fr_I18nService').formatDate(new Date(d.qualityControlDatetime), 'G');
      });
      const uniqExaminations = resultDataList.uniqBy('examinationId');
      const grouped = this.groupBy(resultDataList, item => item.examinationId);
      uniqExaminations.forEach(item => {
        const isInherence = this.get('deviationStandard') === 'inherence';
        const controlHigthValue = this.get('controlCVValues').findBy('code', 'High');
        const controlLowValue = this.get('controlCVValues').findBy('code', 'Low');
        const lowValue = isInherence ? item.referenceCV.lowValue : controlLowValue.name;
        const highValue = isInherence ? item.referenceCV.highValue : controlHigthValue.name;
        this.get('chartDataList').addObject({
          chartData: grouped.get(item.examinationId).sortBy('qualityControlDatetime'),
          chartTitle: item.examination.name,
          customYAxis: [highValue*-1, lowValue*-1, 0, lowValue, highValue],
          customYAxisColors: ['#f1260b', '#004df3', '#000000', '#004df3', '#f1260b']
        });
      });
    },
    getQualityControlCVValue() {
      const param = {classificationCode: 'QualityControlCVValue'};
      this.get('qualityManagementService').getLaboratoryBusinessCode(param).then(result => {
        this.set('controlCVValues', result);
      });
    },

    getCompareHourList() {
      const param = {classificationCode: 'CompareTimeHour'};
      this.get('qualityManagementService').getLaboratoryBusinessCode(param).then(result => {
        this.set('compareTimeHourList', result);
        this.set('model.selectedCompareHour', result[0]);
      });
    },
    _getExportExcelData() {
      const compareSpecimenData = this.get('compareSpecimenData');
      const firstRow = [];
      const secondRow = [];
      const compareSpecimenColumns = this.get('compareSpecimenColumns');
      compareSpecimenColumns.forEach(column => {
        column.columns.forEach((child, index) => {
          if (index === 0) {
            firstRow.push(column.title);
          } else {
            firstRow.push('');
          }
          secondRow.push(child.title);

        });
      });
      const initArr = [firstRow, secondRow];
      const resultArr = [];
      compareSpecimenData.forEach(datas => {
        resultArr.push([
          datas.examination.name,
          datas.lot.lotNumber,
          this.get('fr_I18nService').formatDate(new Date(datas.qualityControlDatetime), 'G'),
          datas.resultValue,
          datas.compareResultValue,
          datas.bias.biasValue,
          datas.bias.biasPercentValue,
          datas.compareResultComment,
        ]);
      });
      this._getExportByArrayTypeExcel(initArr, resultArr);
    }

  });