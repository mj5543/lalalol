/* eslint-disable max-lines */
/* eslint-disable no-console */
/* eslint-disable max-lines-per-function */
import { isEmpty, isPresent } from '@ember/utils';
import { A as emberA } from '@ember/array';
import { next } from '@ember/runloop';
import { set } from '@ember/object';
import layout from './template';
import CHIS from 'framework/chis-framework';
import QualityControlMixin from '../../mixins/quality-control-mixin';
// import QualityControlChartMixin from '../../mixins/quality-control-chart-mixin';
import QualityControlPrintMixin from '../../mixins/quality-control-print-mixin';
import QualityControlMessageMixin from '../../mixins/quality-control-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  QualityControlMixin,
  QualityControlPrintMixin,
  QualityControlMessageMixin,
  {
    layout,
    selectedFromDate: null,
    selectedToDate: null,
    periodType: null,
    qualityControlResultData: null,
    isResultDetailOpen: false,
    controlResultColumns: null,
    controlResultItemsSource: null,
    isQualityControlCheckComp: false,
    isChartShow: false,
    lineChartData: null,
    lineData: null,
    customYAxisValue: null,
    monitorFactorList: null,
    currentFactorList: null,
    headerFormatType: null,
    pickerType: null,
    chartName: null,
    controlResultGrid: null,
    isShowLoader: false,
    contentLoaderType: 'spinner',
    loaderDimed: false,
    examinationIds: null,
    exportExcelData: null,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'laboratory-quality-management-quality-control-check');

      this.setStateProperties([
        'model',
        'selectedFromDate',
        'selectedToDate',
        'periodType',
        'qualityControlResultData',
        'isResultDetailOpen',
        'controlResultItemsSource'
      ]);

      if(this.hasState()===false) {

        this.set('model', {
          selectedGridCellItem: null,
          monitorFactor: null,
          currentFactor: null,
          editResultComment: null,
          displayExaminationName: null,
          cellDoubleClickItem: null,
          checkStaffName: null,

        });
        this.set('periodType', 'Daily');
        this.set('pickerType', 'date');
        // this.set('controlResultColumns', [
        //   { field: 'examination.abbreviation', title: '검사명', width: 120},
        // ]);
        this.set('controlResultColumns', emberA());
        this.set('controlResultItemsSource', emberA());
        this.set('isQualityControlCheckComp', true);
        this.set('lineChartData', emberA());
      }
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1450');
      this.getExaminationRoomList();

    },

    actions: {
      onControlResultLoad(e) {
        this.set('controlResultGrid', e.source);
      },
      onDateChangedAction() {
        // this.getDataList();
      },
      onPopupClosedAction() {
        this.set('model.editResultComment', null);
        this.set('model.checkStaffName', null);
      },
      onSelectedAction(e) {
        this.set('isResultDetailOpen', false);
        const selectedCell = e.selectedCells[0];
        if(!isEmpty(selectedCell)) {
          this.set('model.displayExaminationName', selectedCell.item.examination.name);
          const filedArr = selectedCell.column.field.split('.');
          let selectedItem = selectedCell.item[filedArr[0]];
          if(selectedCell.column.index === 0) {
            selectedItem = selectedCell.item.checkinDate0;
          }
          if (!isEmpty(selectedItem)) {
            const preExaminationId = this.get('model.selectedGridItem.examination.id');
            const currentExaminationId = selectedCell.item.examination.id;
            if (!isEmpty(preExaminationId) && preExaminationId !== currentExaminationId) {
              if (this.get('monitorFactorList') !== null) {
                // this.set('model.monitorFactor', this.getMonitorFactorFieldItem(currentExaminationId));
                this.set('model.monitorFactor', selectedItem);
                // this.set('model.displayExaminationName', selectedCell.item.examination.name);
              }
              this.getcurrentFactor(currentExaminationId);
              this.set('model.selectedGridItem', selectedItem);
            }
            if(isEmpty(this.get('model.selectedGridItem'))) {
              this.getcurrentFactor(selectedCell.item.examination.id);
              this.set('model.monitorFactor', selectedItem);
              this.set('model.selectedGridItem', selectedItem);
            }
          } else {
            //checkinDate0.resultValue
            // this.set('model.displayExaminationName', null);
            this.set('model.selectedGridItem', null);
            this.set('model.monitorFactor', null);
            this.set('model.currentFactor', null);
          }
          this.set('actionMode', 'update');
          this.set('lineChartData', this._getChartData(selectedCell.item));
          this.set('chartName', selectedCell.item.examination.name);
        }

      },
      onCellDoubleClickAction(e) {
        this.set('model.cellDoubleClickItem', null);
        if (this.get('periodType') !== 'Daily') {
          return;
        }
        const filedArr = e.column.field.split('.');
        const selectedCellItem = e.item[filedArr[0]];
        if (!isEmpty(selectedCellItem)) {
          this.set('model.cellDoubleClickItem', selectedCellItem);
          this._getResultChecksSearch();
          this.set('model.editResultComment', selectedCellItem.resultComment);
          this.set('isResultDetailOpen', true);
        }
      },

      onSearchData() {
        this.getDataList();
      },

      onGraphPrintClick() {
        const chartData = this.get('lineChartData');
        if(isEmpty(chartData)) {
          return;
        }
        this.checkGraphSendPrintMessage(chartData);
      },

      onControlCheckPrint() {
        const chartData = this.get('lineChartData');
        if(isEmpty(chartData)) {
          return;
        }
        this.checkSendPrintMessage(chartData);
      },
      onRadioTypeChange(e) {
        let pickerType = '';
        switch(e.value) {
          case 'Daily':
            // colummnDate = new Date(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes());
            pickerType = 'date';
            break;
          case 'Monthly':
            pickerType = 'yearMonth';
            break;
          default:
            pickerType = 'year';
        }
        this.set('pickerType', pickerType);
      },
      onRulesApply() {
        if(isEmpty(this.get('examinationIds'))) {
          return;
        }
        this._getQCRulesApply();
      },
      onExportExcel() {
        if(isEmpty(this.get('controlResultItemsSource'))) {
          return;
        }
        this._parseExcelData();
      },

    },

    _parseExcelData() {
      const controlResultColumns = this.get('controlResultColumns');
      const itemsSource = this.get('controlResultItemsSource');
      const tempArr = [];
      const examinationTitle = this.getLanguageResource('16920', 'F', '', '검사명');
      itemsSource.forEach(datas => {
        const tempObj = {};
        controlResultColumns.forEach(column => {
          const title = column.title.toString();
          const partsField = column.field.split('.');
          tempObj[title] = null;
          let formatDate = null;
          if (partsField[0] === 'examination') {
            tempObj[title] = datas.examination.name;
          }
          if(!isEmpty(datas[partsField[0]]) && partsField[0] !== 'examination') {
            const itemsDateTime = datas[partsField[0]].qualityControlDatetime;
            formatDate = this.get('fr_I18nService').formatDate(new Date(itemsDateTime), this.get('headerFormatType'));
          }
          const targetObj = tempArr.find(d => d[examinationTitle] === datas.examination.name);
          if(targetObj && tempObj[examinationTitle] === datas.examination.name) {
            tempArr.map((obj) => {
              if(title === formatDate && obj[examinationTitle] === datas.examination.name) {
                obj[title] = datas[partsField[0]].resultValue;
              }
            });
          } else {
            tempArr.push(tempObj);
          }
        });
      });
      this._getExportExcel(tempArr, null);
    },
    _gridDataReset() {
      this.set('isChartShow', false);
      this.set('qualityControlResultData', emberA());
      this.set('controlResultItemsSource', emberA());
      this.set('controlResultColumns', emberA());
      this.set('lineChartData', emberA());
      this.set('examinationIds', emberA());
      this.set('monitorFactorList', emberA());
      this.set('currentFactorList', emberA());
      this.set('model.selectedGridItem', null);
      this.set('model.displayExaminationName', null);
      this.set('model.monitorFactor', null);
      this.set('model.currentFactor', null);
    },

    getDataList() {
      this._gridDataReset();
      this.getQualityControlResult();
    },

    async getQualityControlResult() {
      try {
        if(isEmpty(this.get('model.selectedExaminationRoom'))) {
          return;
        }
        this.set('contentLoaderType', 'spinner');
        this.set('isBottomButtonDisabled', true);
        this.set('loaderDimed', false);
        this.set('isShowLoader', true);
        let params = {};
        params = this._getParams();
        params.isGroupQuery = false;
        params.isValidDataRow = true;
        const result = await this.get('qualityManagementService').getQualityControlResultsSearch(params);
        if (!isEmpty(result)) {
          this.set('isBottomButtonDisabled', false);
          this.set('qualityControlResultData', result.sortBy('displaySequence'));
          this._gridSettings();
          this.set('isChartShow', true);
        }
        next(() => {
          this.get('controlResultGrid').selectCell(0, 1);
          this.set('isShowLoader', false);
        }, 1000);
      } catch(e) {
        this._showDataError(e);
      }
    },

    _getChartData(item){
      try {
        const dataList = this.get('qualityControlResultData');
        const targetData = emberA();
        const {meanValue, minus1SDValue, minus2SDValue, minus3SDValue, plus1SDValue, plus2SDValue, plus3SDValue} = item.targetMeanSD;
        const customYAxis = [minus3SDValue, minus2SDValue, minus1SDValue, meanValue, plus3SDValue, plus2SDValue, plus1SDValue];
        this.set('customYAxisValue', customYAxis);
        if (dataList && dataList.length > 0) {
          dataList.forEach(data => {
            if(data.examination && data.examination.id === item.examination.id && data.chartDisplayResult !== ''){
              if (this.get('periodType') === 'Daily') {
                data.qualityControlDatetime = this.get('fr_I18nService').formatDate(new Date(data.qualityControlDatetime), 'G');
              } else {
                data.qualityControlDatetime = this.get('fr_I18nService').formatDate(new Date(data.qualityControlDatetime), this.get('headerFormatType'));
              }
              targetData.pushObject(data);
            }
          });
        }
        this.set('isChartShow', isPresent(targetData));
        return targetData.sortBy('qualityControlDatetime');
      } catch(e) {
        console.error('_getChartData Error:: ', e);
        this.showToastErrorOccurred();
      }
    },

    async getcurrentFactor(examinationId) {
      try {
        const params = this._getParams();
        let currentFactorParams = {};
        currentFactorParams = params;
        currentFactorParams.examinationId = examinationId;
        const result = await this.get('qualityManagementService').getQualityControlResultsCurrentFactor(currentFactorParams);
        this.set('model.currentFactor', result);
      } catch(e) {
        this._showError(e);
        console.error('getcurrentFactor Error:::', e);
      }
    },

    getMonitorFactorFieldItem(examinationId) {
      const monitorFactorResult = this.get('monitorFactorList');
      const fieldItem = monitorFactorResult.find(d => d.examination.id === examinationId);
      this.set('model.displayExaminationName', fieldItem.examination.name);
      return fieldItem.qualityControlFactor;
    },

    _getParams() {
      return this.getParameters();
    },

    _gridSettings(){
      const resultGridData = this._parseGridData();
      this._setGridColumn();
      this.set('controlResultItemsSource', resultGridData);
      // let selectedItem = {};
      // selectedItem = resultGridData[0];
      // this.set('model.monitorFactor', selectedItem);
      // this.set('lineChartData', this._getChartData(selectedItem));
      // this.set('chartName', selectedItem.examination.name);
    },

    _parseGridData(){
      try{
        const res = this.get('qualityControlResultData');
        res.map(d => {
          d.examinationId = d.examination.id;
          d.chartDisplayResult = d.resultValue && d.resultValue !== null ? d.resultValue : '';
          d.lot.effectiveDatetime = d.lot.effectiveDatetime.toString() === '9999-12-31 00:00:00' ? null : d.lot.effectiveDatetime;
          let ruleNameList = null;
          if (d.rules !== null && d.rules.length > 0) {
            ruleNameList = d.rules.map(r => r.name);
            d.ruleNameList = ruleNameList.join(', ');
          } else {
            d.ruleNameList = [];
          }
          d.displayDate = d.qualityControlDatetime;
          d.qualityControlDatetime = d.qualityControlDatetime.toString();
        });
        const resultList = res.sortBy('qualityControlDatetime');
        const uniqExaminationList = resultList.uniqBy('examinationId');
        const uniqDateTimeList = resultList.uniqBy('qualityControlDatetime');
        const grouped = this.groupBy(resultList, item => item.examinationId);
        const groupList = [];
        const uniqExaminationIds = [];
        uniqExaminationList.forEach(item => {
          groupList.push(grouped.get(item.examinationId));
          uniqExaminationIds.push(item.examinationId);
        });
        this.set('examinationIds', uniqExaminationIds);
        // this.getMonitorFactor(uniqExaminationIds);
        const dateTimeGrouped = this.groupBy(resultList, item => item.qualityControlDatetime);
        const dateTimeGroupList = [];
        uniqDateTimeList.forEach(item => {
          dateTimeGroupList.push(dateTimeGrouped.get(item.qualityControlDatetime));
        });
        const tempArr = [];
        groupList.forEach((item) => {
          item.forEach((child)=> {
            const targetIndex = dateTimeGroupList.findIndex(d => d[0].qualityControlDatetime === child.qualityControlDatetime);
            const customColumn = `checkinDate${targetIndex}`;
            const targetExamination = tempArr.find(d => d.examination.id === child.examination.id);
            if(targetExamination && targetExamination.examination.id === child.examination.id) {
              tempArr.map((obj) => {
                if(obj.examination.id === child.examination.id) {
                  obj[customColumn] = child;
                }
              });
            } else {
              tempArr.push({
                [customColumn]: child,
                qualityControlDatetime: child.qualityControlDatetime,
                examination: child.examination,
                qualityControlResultId: child.qualityControlResultId,
                resultValue: child.resultValue,
                equipment: child.equipment,
                resultComment: child.resultComment,
                registrationStaff: child.registrationStaff,
                lot: child.lot,
                isValidDataRow: child.isValidDataRow,
                targetMeanSD: child.targetMeanSD
              });
            }
          });
        });
        return tempArr;
      } catch(e) {
        console.error('_parseGridData Error:: ', e);
        this.showToastErrorOccurred();
      }
    },

    _setGridColumn() {
      try {
        const res = this.get('qualityControlResultData');
        const uniqDateTimeList = res.uniqBy('qualityControlDatetime').sortBy('qualityControlDatetime');
        const uniqCheckInDateList = [];
        uniqDateTimeList.forEach((item) => {
          uniqCheckInDateList.push(item.qualityControlDatetime);
        });
        const resultColumns = [];
        const columnWidth = 110;
        let formatType = '';
        switch(this.get('periodType')) {
          case 'Daily':
            // colummnDate = new Date(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes());
            formatType = 'g';
            break;
          case 'Monthly':
            formatType = 'd';
            break;
          default:
            formatType = 'Y';
        }
        this.set('headerFormatType', formatType);
        this._getRuleCodeList();
        const ruleColors = this._getRulesColor();
        uniqCheckInDateList.forEach((date ,index) => {
          const customColumn = `checkinDate${index}`;
          const colummnDate = this.get('fr_I18nService').formatDate(new Date(date), formatType);
          let tooltipText = colummnDate;
          if (formatType === 'g') {
            tooltipText = this.get('fr_I18nService').formatDate(new Date(date), 'G');
          }
          resultColumns.push({ field: `${customColumn}.resultValue`, title: colummnDate, tooltipText: tooltipText, align: 'right', width: columnWidth, headerTemplateName: 'customHeaders',
            onBodyCellRender: function (context) {
              const cellItem = context.item;
              if (cellItem[customColumn]) {
                // if (cellItem[customColumn].resultValue && cellItem[customColumn].targetMeanSD.minus2SDValue > cellItem[customColumn].resultValue) {
                //   context.cellComponent.$().css('color', '#004df3');
                //   context.cellComponent.$().css('font-weight', 'bold');
                // } else if (cellItem[customColumn].resultValue && cellItem[customColumn].targetMeanSD.plus2SDValue < cellItem[customColumn].resultValue) {
                //   context.cellComponent.$().css('color', '#f1260b');
                //   context.cellComponent.$().css('font-weight', 'bold');
                // }
                if (isPresent(cellItem[customColumn].rules)){
                  // const colorRuleCode = `rule${cellItem[customColumn].rules[0].code}`;
                  let colorRuleCode = cellItem[customColumn].rules[0].code;
                  const rulecodeList = cellItem[customColumn].rules.map(d => d.code);
                  if(cellItem[customColumn].rules.length > 1) {
                    if(rulecodeList.includes('11S')){
                      colorRuleCode = '11S';
                    }
                    if(rulecodeList.includes('12S')){
                      colorRuleCode = '12S';
                    }
                    if(rulecodeList.includes('13S')){
                      colorRuleCode = '13S';
                    }
                    if(rulecodeList.includes('10X')) {
                      colorRuleCode = '10X';
                    }
                    if(rulecodeList.includes('R4S')) {
                      colorRuleCode = 'R4S';
                    }
                    if(rulecodeList.includes('41S')) {
                      colorRuleCode = '41S';
                    }
                    if(rulecodeList.includes('22S2')) {
                      colorRuleCode = '22S2';
                    }
                    if(rulecodeList.includes('22S')) {
                      colorRuleCode = '22S';
                    }
                  }
                  let cellColor = ruleColors[colorRuleCode];
                  if(isEmpty(cellColor)) {
                    // cellColor = '#'+Math.random().toString(16).substr(2,6);
                    cellColor = '#6F0F79';
                  }
                  // context.cellComponent.$().css('background-color', cellColor);
                  context.cellComponent.$().css('color', cellColor);
                  context.cellComponent.$().css('font-weight', 'bold');
                }
                if (!isEmpty(cellItem[customColumn].resultComment)){
                  set(context.cellComponent, 'description', cellItem[customColumn].resultComment);
                }
              }
            },
          });
        });
        this.set('controlResultColumns', [
          { field: 'examination.name', title: this.getLanguageResource('16920', 'F', '', '검사명'), width: 120, locked: true},
          ...resultColumns
        ]);
      } catch(e) {
        console.error('_setGridColumn Error:: ', e);
        this.showToastErrorOccurred();
      }
    },
    async _getQCRulesApply() {
      try {
        this.set('contentLoaderType', 'progress');
        this.set('loaderDimed', true);
        this.set('isShowLoader', true);
        const params = {
          lotId: this.get('model.selectedControlMaterialsLotId'),
          equipmentId: this.get('model.selectedEquipmentId'),
          fromDatetime: this.get('selectedFromDate'),
          toDatetime: this.get('selectedToDate'),
          examinationIds: this.get('examinationIds')
        };
        await this.get('qualityManagementService').createRulesApply(params);
        this.showToastSaved();
        this.getDataList();
        this.set('isShowLoader', false);
      } catch(e) {
        this._showDataError(e);
      }
    },

    async _getResultChecksSearch() {
      try {
        this.set('model.checkStaffName', null);
        const params = {
          checkTypeCode: 'QualityControlResultId',
          lotId: this.get('model.selectedControlMaterialsLotId'),
          equipmentId: this.get('model.selectedEquipmentId'),
          checkDatetime: this.get('todayDate'),
          examinationId: this.get('model.cellDoubleClickItem.examination.id'),
          qualityControlResultId: this.get('model.cellDoubleClickItem.qualityControlResultId')
        };
        const result = await this.get('qualityManagementService').getQualityControlResultsChecksSearch(params);
        if(!isEmpty(result)) {
          this.set('model.checkStaffName', result[0].checkStaff.name);
        }
      } catch(e) {
        this._showError(e);
        console.log('_getResultChecksSearch Error:::', e);
      }
    },
    _showDataError(e) {
      if(this.isDestroyed || this.isDestroying) {
        return;
      }
      this.set('isShowLoader', false);
      this._showError(e);
      console.log('_Error::', e);
    },
  });