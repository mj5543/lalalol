/* eslint-disable no-console */
/* eslint-disable max-lines-per-function */
import $ from 'jquery';
import layout from './template';
import { A as emberA } from '@ember/array';
import { isEmpty } from '@ember/utils';
import CHIS from 'framework/chis-framework';
import QualityControlMixin from '../../mixins/quality-control-mixin';
import QualityControlPrintMixin from '../../mixins/quality-control-print-mixin';
import QualityControlMessageMixin from '../../mixins/quality-control-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  QualityControlMixin,
  QualityControlPrintMixin,
  QualityControlMessageMixin,
  {
    layout,
    isCheckByLevelComp: true,
    selectedFromDate: null,
    selectedToDate: null,
    controlResultByLevelData: null,
    controlResultByLevelItemsSource: null,
    customAreaDatas: null,
    currentFactors: null,
    chartName: null,
    isRefreshDisabled: true,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'laboratory-quality-management-quality-control-check-by-level');

      this.setStateProperties([
        'model',
        'selectedFromDate',
        'selectedToDate',
        'customAreaDatas',
        'currentFactors',
      ]);

      if(this.hasState()===false) {

        this.set('model', {
          selectedGridCellItem: null,
          popupTagetId: null,
          selectedEquipment: null,
          checkStaffName: null,
        });

        this.set('customAreaDatas', emberA());
        this.set('currentFactors', emberA());

      }
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1360');
      this.getExaminationRoomList();

    },

    actions: {
      onDateChangedAction() {
        // this.getDataList();
      },
      onPopupOpenedAction() {
        this.set('model.checkStaffName', null);
        // this.get('model.isEntryPopupUpdated', false);
      },

      onExaminationChangeByLevel() {
        this.getDataList();
        this._setSettingRoomInfo();
      },

      onCustomGridSelectedAction(e) {
        // console.log('onCustomGridSelectedAction--', e);
        this.set('isResultDetailOpen', false);
        const selectedCell = e.selectedCells[0];
        if(selectedCell) {
          const targetId = selectedCell.item.gridId;
          this.set('model.popupTagetId', `#${targetId}`);
          const filedArr = selectedCell.column.field.split('.');
          const selectedItem = selectedCell.item[filedArr[0]];
          if (selectedItem) {
            this.set('model.selectedGridItem', selectedItem);
          } else {
            this.set('model.selectedGridItem', null);
          }
        }

      },

      onCustomGridCellDoubleClick() {
        if (this.get('model.selectedGridItem')) {
          this.set('model.editResultComment', this.get('model.selectedGridItem.resultComment'));
          this._getResultChecksSearch();
          this.set('isResultDetailOpen', true);
        }
      },
      onControlLevelPrint() {
        this.checkByLevelSendPrintMessage(this.get('customAreaDatas'), this.get('currentFactors'));
      },
      onControlLevelGraphPrint() {
        this.checkByLevelGraphSendPrintMessage(this.get('customAreaDatas'), this.get('currentFactors'));

      },
    },

    _gridDataReset() {
      this.set('controlResultByLevelData', emberA());
      this.set('customAreaDatas', emberA());
    },

    getDataList() {
      if (this.get('model.selectedExaminationId') === null) {
        return;
      }
      this._gridDataReset();
      this.getControlResultByLevelData();
    },

    async getControlResultByLevelData() {
      try {
        const selectedExaminationId = this.get('model.selectedExaminationId');
        if(isEmpty(selectedExaminationId)) {
          return;
        }
        this.set('isShowLoader', true);
        this.set('isBottomButtonDisabled', true);
        const paramFromDate = new Date(this.get('selectedFromDate').getFullYear(), this.get('selectedFromDate').getMonth(), this.get('selectedFromDate').getDate(), 0, 0, 0).toFormatString();
        const paramToDate = new Date(this.get('selectedToDate').getFullYear(), this.get('selectedToDate').getMonth(), this.get('selectedToDate').getDate(), 0, 0, 0).toFormatString();
        const params = {
          qualityControlFindTypeCode: "Daily",
          isGroupQuery: true,
          isValidDataRow: true,
          lotId: this.get('model.selectedControlMaterialsLotId'),
          equipmentId: this.get('model.selectedEquipmentId'),
          fromDatetime: paramFromDate,
          toDatetime: paramToDate,
          examinationIds: [selectedExaminationId]
        };
        const result = await this.get('qualityManagementService').getQualityControlResultsSearch(params);
        if (!isEmpty(result)) {
          this.set('controlResultByLevelData', result);
          this.set('isBottomButtonDisabled', false);
          this._gridSettings();
        }
        this.set('isShowLoader', false);
        this.set('isRefreshDisabled', false);
      } catch(e) {
        if(this.isDestroyed || this.isDestroying) {
          return;
        }
        this.set('isShowLoader', false);
        this.set('isRefreshDisabled', false);
        this._showError(e);
        console.log('getControlResultByLevelData Error:::', e);
      }

    },
    _gridSettings(){
      const grouped = this.groupBy(this.get('controlResultByLevelData'), item => item.lot.lotType.code);
      this._parseGridData(grouped);
    },

    _parseGridData(grouped){
      const resultList = [];
      const areaDatas = [];
      const res = this.get('controlResultByLevelData');
      const groupGridItems = [];
      const uniqLotItems = this.get('controlResultByLevelData').uniqBy('lot.lotType.code').sortBy('qualityControlDatetime');
      uniqLotItems.forEach((item) => {
        groupGridItems.push(grouped.get(item.lot.lotType.code));
        this.getcurrentFactor(item.lot.id);
      });
      res.map(d => {
        d.examinationId = d.examination.id;
        d.chartDisplayResult = d.resultValue && d.resultValue !== null ? d.resultValue : '';
        let ruleNameList = null;
        if (d.rules !== null && d.rules.length > 0) {
          ruleNameList = d.rules.map(r => r.name);
          d.ruleNameList = ruleNameList.join(', ');
        } else {
          d.ruleNameList = [];
        }
        d.displayDate = d.qualityControlDatetime;
        d.customItemValue = null;
        d.qualityControlDatetime = d.qualityControlDatetime.toString();
        resultList.push(d);
      });
      const uniqDateTimeList = resultList.uniqBy('qualityControlDatetime').sortBy('qualityControlDatetime');
      const dateTimeGrouped = this.groupBy(resultList, item => item.qualityControlDatetime);
      const dateTimeGroupList = [];
      uniqDateTimeList.forEach(item => {
        dateTimeGroupList.push(dateTimeGrouped.get(item.qualityControlDatetime));
      });
      groupGridItems.forEach((item, index) => {
        const tempArr = [];
        const gridIndexData = `levelGroupGrid${index}Data`;
        const gridIndexColumn = `lotGroup${index}Columns`;
        const gridTargetId = `levelGroupGrid${index}`;
        item.forEach((child)=> {
          const targetIndex = dateTimeGroupList.findIndex(d => d[0].qualityControlDatetime === child.qualityControlDatetime);
          const customColumn = `checkinDate${targetIndex}`;
          const targetLotType = tempArr.find(d => d.lot.lotType.code === child.lot.lotType.code);
          if(targetLotType && targetLotType.lot.lotType.code === child.lot.lotType.code) {
            tempArr.map((obj) => {
              if(obj.examination.id === child.examination.id) {
                obj[customColumn] = child;
              }
            });
          } else {
            const detailObj = {
              [customColumn]: child,
              gridId: gridTargetId,
              controlMaterial: child.controlMaterial,
              qualityControlDatetime: child.qualityControlDatetime,
              examination: child.examination,
              qualityControlResultId: child.qualityControlResultId,
              resultValue: child.resultValue,
              equipment: child.equipment,
              resultComment: child.resultComment,
              registrationStaff: child.registrationStaff,
              lot: child.lot,
              isValidDataRow: child.isValidDataRow,
              targetMeanSD: child.targetMeanSD
            };
            tempArr.push( $.extend({}, {rowSection: `${child.controlMaterial.name} ${child.lot.lotType.name}`}, detailObj),
              $.extend({}, {rowSection: '비고'}, detailObj),
              $.extend({}, {rowSection: 'QC Rules'}, detailObj));
          }
        });
        const gridColumns = this._setGridColumn();

        this.set(gridIndexColumn, gridColumns);
        this.set(gridIndexData, tempArr);
        console.log('item--', item);
        const {meanValue, minus1SDValue, minus2SDValue, minus3SDValue, plus1SDValue, plus2SDValue, plus3SDValue, sdValue} = tempArr[0].targetMeanSD;
        const customYAxis = [minus3SDValue, minus2SDValue, minus1SDValue, meanValue, plus3SDValue, plus2SDValue, plus1SDValue];
        areaDatas.addObject({
          column: gridColumns,
          itemsSource: tempArr,
          targetId: gridTargetId,
          chartData: item.filter(d => d.chartDisplayResult !== ''),
          chartName: this.get('model.selectedExamination.name'),
          customYAxis: customYAxis,
          isGridShow: false,
          lotNumber: tempArr[0].lot.lotNumber,
          tableItem: {
            areaSection: tempArr[0].rowSection,
            materialName: tempArr[0].controlMaterial.name,
            lotName: tempArr[0].lot.lotType.name,
            lotNumber: tempArr[0].lot.lotNumber,
            meanValue, minus1SDValue, minus2SDValue, minus3SDValue,
            plus1SDValue, plus2SDValue, plus3SDValue, sdValue}
        });
      });
      this.set('customAreaDatas', areaDatas.sortBy('lotNumber'));
    },

    async getcurrentFactor(lotId) {
      try {
        const params = this.getParameters();
        let currentFactorParams = {};
        currentFactorParams = params;
        currentFactorParams.examinationId = this.get('model.selectedExaminationId');
        currentFactorParams.lotId = lotId;
        const result = await this.get('qualityManagementService').getQualityControlResultsCurrentFactor(currentFactorParams);
        this.get('currentFactors').push($.extend({}, {id: lotId}, result));
      } catch(e) {
        this._showError(e);
      }
    },

    _setGridColumn() {
      const res = this.get('controlResultByLevelData');
      const uniqDateTimeList = res.uniqBy('qualityControlDatetime');
      const uniqCheckInDateList = [];
      uniqDateTimeList.forEach((item) => {
        uniqCheckInDateList.push(item.qualityControlDatetime);
      });
      const resultColumns = [];
      const columnWidth = 110;
      const ruleColors = this._getRulesColor();
      uniqCheckInDateList.forEach((date ,index) => {
        const customColumn = `checkinDate${index}`;
        const colummnDate = this.get('fr_I18nService').formatDate(new Date(date), 'g');

        resultColumns.push({ field: `${customColumn}.resultValue`, title: colummnDate, align: 'center', width: columnWidth, headerTemplateName: 'customHeaders',
          onBodyCellRender: function (context) {
            const cellItem = context.item;
            if (cellItem[customColumn] && !isEmpty(cellItem[customColumn].rules)){
              // const colorRuleCode = `rule${cellItem[customColumn].rules[0].code}`;
              let colorRuleCode = cellItem[customColumn].rules[0].code;
              const rulecodeList = cellItem[customColumn].rules.map(d => d.code);
              if(cellItem[customColumn].rules.length > 1) {
                if(rulecodeList.includes('11S')){
                  colorRuleCode = '11S';
                }
                if(rulecodeList.includes('12S')){
                  colorRuleCode = '12S';
                }
                if(rulecodeList.includes('13S')){
                  colorRuleCode = '13S';
                }
                if(rulecodeList.includes('10X')) {
                  colorRuleCode = '10X';
                }
                if(rulecodeList.includes('R4S')) {
                  colorRuleCode = 'R4S';
                }
                if(rulecodeList.includes('41S')) {
                  colorRuleCode = '41S';
                }
                if(rulecodeList.includes('22S2')) {
                  colorRuleCode = '22S2';
                }
                if(rulecodeList.includes('22S')) {
                  colorRuleCode = '22S';
                }
              }
              let cellColor = ruleColors[colorRuleCode];
              if(isEmpty(cellColor)) {
                // cellColor = '#'+Math.random().toString(16).substr(2,6);
                cellColor = '#6F0F79';
              }
              // context.cellComponent.$().css('background-color', cellColor);
              context.cellComponent.$().css('color', cellColor);
              context.cellComponent.$().css('font-weight', 'bold');
            }
            if (cellItem[customColumn] && context.cellComponent.rowIndex === 1) {
              let resultComment = cellItem[customColumn].resultComment;
              if(isEmpty(resultComment)) {
                resultComment = '';
              }
              const innerHtml = `<div class="c-gtd-line"><div class="c-gdt"><div class="c-gdc" title='${resultComment}'>${resultComment}</div></div></div>`;
              context.cellComponent.$().html(innerHtml);
              // context.cellComponent.$().text(cellItem[customColumn].resultComment);
            } else if(cellItem[customColumn] && context.cellComponent.rowIndex === 2) {
              let ruleNameList = '';
              if(!isEmpty(cellItem[customColumn].ruleNameList)) {
                ruleNameList = cellItem[customColumn].ruleNameList;
              }
              const innerHtml = `<div class="c-gtd-line"><div class="c-gdt"><div class="c-gdc" title='${ruleNameList}'>${ruleNameList}</div></div></div>`;
              context.cellComponent.$().html(innerHtml);
              // context.cellComponent.$().text(cellItem[customColumn].ruleNameList);
            }
          },
        });
      });
      return [
        // { field: 'rowSection', title: this.getLanguageResource('9698', 'F', '', '구분'), width: 120},
        { field: 'rowSection', title: this.getLanguageResource('9698', 'F', '', '구분'), width: 120, locked:true, bodyTemplateName: 'rowSection'},
        ...resultColumns
      ];
    },
    async _getResultChecksSearch() {
      try {
        const params = {
          checkTypeCode: 'QualityControlResultId',
          lotId: this.get('model.selectedControlMaterialsLotId'),
          equipmentId: this.get('model.selectedEquipmentId'),
          checkDatetime: this.get('todayDate'),
          examinationId: this.get('model.selectedGridItem.examination.id'),
          qualityControlResultId: this.get('model.selectedGridItem.qualityControlResultId')
        };
        const result = await this.get('qualityManagementService').getQualityControlResultsChecksSearch(params);
        console.log('_getResultChecksSearch--', result);
        if(!isEmpty(result)) {
          this.set('model.checkStaffName', result[0].checkStaff.name);
        }
      } catch(e) {
        console.log('_getResultChecksSearch Error:::', e);

      }
    }

  });