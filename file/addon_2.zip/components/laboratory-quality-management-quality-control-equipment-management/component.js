/* eslint-disable no-console */
import moment from 'moment';
import { next } from '@ember/runloop';
import { isEmpty } from '@ember/utils';
import layout from './template';
import CHIS from 'framework/chis-framework';
import QualityControlMixin from '../../mixins/quality-control-mixin';
import QualityControlMessageMixin from '../../mixins/quality-control-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  QualityControlMixin,
  QualityControlMessageMixin,
  {
    layout,
    selectedFromDate: null,
    selectedToDate: null,
    equipmentsData: null,
    equipmentsColumns: null,
    isEquipmentEditOpen: false,
    isUpdatePopup: false,
    changedItemsSource: null,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'laboratory-quality-management-quality-control-equipment-management');

      this.setStateProperties([
        'model',
        'selectedFromDate',
        'selectedToDate',
        'equipmentsData',
        'equipmentsColumns'
      ]);

      if(this.hasState()===false) {

        this.set('model', {
          selectedGridItem: null,
          selectedRowItem: null,
          editItems: {
            displayCode: null,
            name: null,
            examinationRoomId: null,
            startDatetime: null,
            endDatetime: null,
            displaySequence: null,
            remark: null
          },
        });

        this.set('equipmentsData', []);
        this.set('equipmentsColumns', [
          { field: 'displayCode', title: this.getLanguageResource('7674', 'F', '', '코드'), width: 120},
          { field: 'name', title: this.getLanguageResource('5930', 'F', '', '이름'), width: 130},
          { field: 'examinationRoom.name', title: this.getLanguageResource('17025', 'F', '', '검사실'), width: 130, align: 'center'},
          { field: 'applyDatetime.startDatetime', title: this.getLanguageResource('4404', 'F', '', '시작일'), width: 110, type: 'date', dataFormat: 'd', align: 'center'},
          { field: 'applyDatetime.endDatetime', title: this.getLanguageResource('6967', 'F', '', '종료일'), width: 110, type: 'date', dataFormat: 'd', align: 'center'},
        ]);
        this.set('changedItemsSource', []);
      }
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w800');
      this.getExaminationRoomList();

    },
    onAudit(){
      const selectedGridItem = this.get('model.selectedGridItem');
      console.log('onAudit--', selectedGridItem);
      if(!isEmpty(selectedGridItem)){
        this.set('aggregateKey', selectedGridItem.id);
        this.set('isOpenAuditTrail', true);
      }
    },

    actions: {
      onSearchData() {
        this.getDataList();
      },
      onExaminationRoomChangeByEquipment(e) {
        const selectedItems = e.selectedItems;
        if(!isEmpty(selectedItems)) {
          this.getDataList();
          this._setSettingRoomInfo();
        }
      },

      onExaminationRoomChangeByEditItem() {
        // console.log('onExaminationRoomChangeByEditItem--', e);

      },

      onAddClick() {
        this.set('isEquipmentEditOpen', true);
        this.set('model.editItems.examinationRoomId', this.get('model.selectedExaminationRoom'));
        this.set('model.editItems.startDatetime', this.get('selectedDate'));
        this.set('model.editItems.endDatetime', null);
      },
      onDeleteClick() {
        if (isEmpty(this.get('model.selectedRowItem'))) {
          this.showWarningMessage(this.getLanguageResource('9260', 'F', '항목을 선택하세요.'), 2000);
          return;
        }
        this._getEquipmentDeleteConfirm();
      },

      onSaveClick() {
        if (this.get('isUpdatePopup') === true) {
          this._updateEquipment();
        } else {
          this._createEquipment();
        }
      },
      onPopupClosedAction() {
        this.set('isUpdatePopup', false);
        this.set('model.editItems.displayCode', null);
        this.set('model.editItems.name', null);
        this.set('model.editItems.examinationRoomId', null);
        this.set('model.editItems.startDatetime', null);
        this.set('model.editItems.endDatetime', null);
        this.set('model.editItems.displaySequence', null);
        this.set('model.editItems.remark', null);
      },

      onGridSelectedAction(e) {
        this.set('isEquipmentEditOpen', false);
        const selectedItem = e.selectedItems[0];
        this.set('model.selectedRowItem', selectedItem);
      },
      onCustomGridCellDoubleClick() {
        if (this.get('model.selectedRowItem')) {
          this.set('model.editItems.displayCode', this.get('model.selectedRowItem.displayCode'));
          this.set('model.editItems.name', this.get('model.selectedRowItem.name'));
          this.set('model.editItems.examinationRoomId', this.get('model.selectedRowItem.examinationRoom.id'));
          this.set('model.editItems.startDatetime', this.get('model.selectedRowItem.applyDatetime.startDatetime'));
          this.set('model.editItems.endDatetime', this.get('model.selectedRowItem.applyDatetime.endDatetime'));
          this.set('model.editItems.displaySequence', this.get('model.selectedRowItem.displaySequence'));
          this.set('model.editItems.remark', this.get('model.selectedRowItem.remark'));
          this.set('isEquipmentEditOpen', true);
          this.set('isUpdatePopup', true);

        }
      },
      onRowItemDragEnd(e) {
        this.set('changedItemsSource', e.source.itemsSource);
      },
      onDisplaySequenceSave() {
        this.setDisplaySequence('equipment', this.get('changedItemsSource'));
      },

    },

    _gridDataReset() {
      this.set('equipmentsData', []);
      this.set('changedItemsSource', []);
    },


    getDataList() {
      this.set('isShowLoader', true);
      this._gridDataReset();
      this._getEquipmentList();
    },

    _getEquipmentList() {
      const param = {
        examinationRoomId: this.get('model.selectedExaminationRoom')
      };
      this.get('qualityManagementService').getEquipments(param).then(result => {
        if (result && result.length > 0) {
          result.forEach(data => {
            // data.applyDatetime.endDatetime = data.applyDatetime.endDatetime.toString() === '9999-12-31 00:00:00' ? null : data.applyDatetime.endDatetime;
            data.applyDatetime.endDatetime = moment(new Date(data.applyDatetime.endDatetime)).format('YYYY-MM-DD').toString() === '9999-12-31' ? null : data.applyDatetime.endDatetime;
          });
          this.set('equipmentsData', result);
        }
        next(this, function(){
          this.set('isShowLoader', false);
          this.set('contentLoaderType', 'spinner');
        });

      });

    },

    _createEquipment() {
      const changedItem = this.get('model.editItems');
      const param = this.getEquipmentUpdateParam(changedItem);
      if(isEmpty(param)) {
        return;
      }
      this.get('qualityManagementService').createEquipments(param).then(() => {
        this.set('isEquipmentEditOpen', false);
        this.showToastSaved();
        this.getDataList();
      }, () => {
        this.showToastSaveFail();
      });
    },

    _updateEquipment() {
      const changedItem = this.get('model.editItems');
      let updateParam = {};
      const param = this.getEquipmentUpdateParam(changedItem);
      if(isEmpty(param)) {
        return;
      }
      updateParam = param;
      updateParam.equipmentId = this.get('model.selectedRowItem.id');
      this.get('qualityManagementService').updateEquipments(updateParam).then(() => {
        this.set('isEquipmentEditOpen', false);
        this.showToastSaved();
        this.getDataList();
      }, () => {
        this.showToastSaveFail();
      });
    },

    getEquipmentUpdateParam() {
      const editItems = this.get('model.editItems');
      if(isEmpty(editItems.displayCode) || isEmpty(editItems.name) || isEmpty(editItems.displaySequence)) {
        this.showToastInputData();
        return;
      }
      return {
        displayCode: this.get('model.editItems.displayCode'),
        name: this.get('model.editItems.name'),
        examinationRoomId: this.get('model.editItems.examinationRoomId'),
        applyDatetime: {
          startDatetime: this.get('model.editItems.startDatetime'),
          endDatetime: isEmpty(editItems.endDatetime) ? new Date('9999-12-31 00:00:00') : editItems.endDatetime
        },
        displaySequence: this.get('model.editItems.displaySequence'),
        remark: this.get('model.editItems.remark')
      };
    },
    _deleteEquipment() {
      const selectedDeleteId = this.get('model.selectedRowItem.id');
      if (selectedDeleteId) {
        const param = {equipmentId: selectedDeleteId};
        this.get('qualityManagementService').deleteEquipments(param).then(() => {
          this.showToastDeleted();
          this.getDataList();
        }, () => {
          this.showToastDeleteFail();
        });
      }
    },

    _getEquipmentDeleteConfirm() {
      this.showConfirmDelete().then(result => {
        if (result === 'Yes') {
          this._deleteEquipment();
        }
      });
    }

  });