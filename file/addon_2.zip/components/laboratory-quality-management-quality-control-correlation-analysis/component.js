/* eslint-disable no-console */
import { A as emberA } from '@ember/array';
import { isEmpty } from '@ember/utils';
import layout from './template';
import CHIS from 'framework/chis-framework';
import QualityControlMixin from '../../mixins/quality-control-mixin';
import QualityControlPrintMixin from '../../mixins/quality-control-print-mixin';
import QualityControlMessageMixin from '../../mixins/quality-control-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  QualityControlMixin,
  QualityControlPrintMixin,
  QualityControlMessageMixin,
  {
    layout,
    selectedFromDate: null,
    selectedToDate: null,
    isGroupSearch: false,
    compareFactorData: null,
    compareFactorColumns: null,
    isApprovalInclude: false,
    isAnalysisComp: true,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'laboratory-quality-management-quality-control-correlation-analysis');

      this.setStateProperties([
        'model',
        'selectedFromDate',
        'selectedToDate',
      ]);

      if(this.hasState()===false) {

        this.set('model', {
          selectedGridCellItem: null,
        });
        this.set('compareFactorData', emberA());
        const columnWidth = 70;
        const gridColumns = [
          {title:  this.getLanguageResource('1587', 'F', null, '기준장비'), columns: [
            { field: 'examination.id', title: this.getLanguageResource('16920', 'F', null, '검사항목'), merge: true, width: 140, bodyTemplateName:'examinationName'},
            { field: 'lot.lotNumber', title: this.getLanguageResource('215', 'F', '', 'Lot 번호'), width: 100, align: 'center'},
            { field: 'lot.lotType.name', title: this.getLanguageResource('10008', 'F', '', 'Level'), width: 80, align:'center'},
            { field: 'equipmentFactor.targetMeanSD.meanValue', title: this.getLanguageResource('17026', 'F', '', 'Target Mean'), width: 80, align:'right'},
            { field: 'equipmentFactor.targetMeanSD.sdValue', title: 'Target SD', width: 80, align:'right'},
            { field: 'equipmentFactor.meanSD.meanValue', title: this.getLanguageResource('17027', 'F', '', 'Mean'), width: columnWidth, align: 'right'},
            { field: 'equipmentFactor.meanSD.sdValue', title: 'SD', width: columnWidth, align: 'right'},
            { field: 'equipmentFactor.cvValue', title: 'CV', width: columnWidth, align: 'right'},
            { field: 'equipmentFactor.bias.biasValue', title: 'Differencial', width: columnWidth, align: 'right'},
            { field: 'equipmentFactor.bias.biasPercentValue', title: this.getLanguageResource('14856', 'F', '', 'Difference(%)'), width: 85, align: 'right'},
          ]},
          {title: this.getLanguageResource('10010', 'F', null, '비교장비'), columns: [
            { field: 'comparisonEquipmentFactor.meanSD.meanValue', title: this.getLanguageResource('17027', 'F', '', 'Mean'), width: columnWidth, align: 'right'},
            { field: 'comparisonEquipmentFactor.meanSD.sdValue', title: 'SD', width: columnWidth, align: 'right'},
            { field: 'comparisonEquipmentFactor.cvValue', title: 'CV', width: columnWidth, align: 'right'},
            { field: 'comparisonEquipmentFactor.bias.biasValue', title: 'Differencial', width: columnWidth, align: 'right'},
            { field: 'comparisonEquipmentFactor.bias.biasPercentValue', title: this.getLanguageResource('14856', 'F', '', 'Difference(%)'), width: 85, align: 'right'},
          ]},
          {title: this.getLanguageResource('1588', 'F', '', '기준장비에 대한 비교'),
            columns: [{ field: 'comparisonBias.biasPercentValue', title:this.getLanguageResource('14856', 'F', '', 'Difference(%)'), width: 140, align: 'right'},]}

        ];
        this.set('compareFactorColumns', gridColumns);

      }
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1450');
      this.getExaminationRoomList();

    },

    actions: {
      onDateChangedAction() {
        // this.getDataList();
      },
      onAnalysisPrint() {
        this.analysisSendPrintMessage(this.get('compareFactorData'));
      },
      onExportExcel() {
        this._getExcelData();
      },
    },
    _getExcelData() {
      const compareFactorData = this.get('compareFactorData');
      const firstRow = [];
      const secondRow = [];
      const compareFactorColumns = this.get('compareFactorColumns');
      compareFactorColumns.forEach(column => {
        column.columns.forEach((child, index) => {
          if (index === 0) {
            firstRow.push(column.title);
          } else {
            firstRow.push('');
          }
          secondRow.push(child.title);

        });
      });
      const initArr = [firstRow, secondRow];
      const resultArr = [];
      compareFactorData.forEach(datas => {
        resultArr.push([
          datas.examination.name,
          datas.lot.lotNumber,
          datas.lot.lotType.name,
          datas.equipmentFactor.targetMeanSD.meanValue,
          datas.equipmentFactor.targetMeanSD.sdValue,
          datas.equipmentFactor.meanSD.meanValue,
          datas.equipmentFactor.meanSD.sdValue,
          datas.equipmentFactor.cvValue,
          datas.equipmentFactor.bias.biasValue,
          datas.equipmentFactor.bias.biasPercentValue,
          datas.comparisonEquipmentFactor.meanSD.meanValue,
          datas.comparisonEquipmentFactor.meanSD.sdValue,
          datas.comparisonEquipmentFactor.cvValue,
          datas.comparisonEquipmentFactor.bias.biasValue,
          datas.comparisonEquipmentFactor.bias.biasPercentValue,
          datas.comparisonBias.biasPercentValue
        ]);
      });
      this._getExportByArrayTypeExcel(initArr, resultArr);
    },

    _gridDataReset() {
      this.set('compareFactorData', emberA());
    },

    getDataList() {
      this.set('isShowLoader', true);
      this._gridDataReset();
      this.getQualityControlCompareFactor();
    },

    async getQualityControlCompareFactor() {
      try {
        this.set('isBottomButtonDisabled', true);
        const selectedExaminationId = this.get('model.selectedExaminationId');
        const paramFromDate = new Date(this.get('selectedFromDate').getFullYear(), this.get('selectedFromDate').getMonth(), this.get('selectedFromDate').getDate(), 0, 0, 0).toFormatString();
        const paramToDate = new Date(this.get('selectedToDate').getFullYear(), this.get('selectedToDate').getMonth(), this.get('selectedToDate').getDate(), 0, 0, 0).toFormatString();
        const params = {
          controlMaterialId: this.get('model.selectedControlMaterialId'),
          lotId: this.get('model.selectedControlMaterialsLotId'),
          isGroupQuery: this.get('isGroupSearch'),
          equipmentId: this.get('model.selectedEquipmentId'),
          compareEquipmentId: this.get('model.selectedCompareEquipmentId'),
          fromDatetime: paramFromDate,
          toDatetime: paramToDate,
          examinationIds: selectedExaminationId
        };
        const result = await this.get('qualityManagementService').getQualityControlResultsCompareFactor(params);
        if(!isEmpty(result)) {
          this.set('isBottomButtonDisabled', false);
          this.set('compareFactorData', result.sortBy('examination.id'));
        }
        this.set('isShowLoader', false);
      } catch(e) {
        if(this.isDestroyed || this.isDestroying) {
          return;
        }
        this.set('isShowLoader', false);
        this._showError(e);
        console.log('getQualityControlCompareFactor Error::::', e);
      }
    },

  });