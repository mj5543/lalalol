/* eslint-disable max-lines */
/* eslint-disable max-lines-per-function */
/* eslint-disable chis/avoid-memory-leak */
/* eslint-disable no-console */
import { isEmpty, isPresent } from '@ember/utils';
import { inject as service } from '@ember/service';
import { A as emberA } from '@ember/array';
import { later } from '@ember/runloop';
import layout from './template';
import CHIS from 'framework/chis-framework';
import QualityControlMessageMixin from '../../mixins/quality-control-message-mixin';
import QualityControlPrintMixin from '../../mixins/quality-control-print-mixin';
import { get } from '@ember/object';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  QualityControlMessageMixin,
  QualityControlPrintMixin,
  {
    layout,
    model: null,
    examinationRoomList: null,
    qualityControlOrderSetList: null,
    controlOrderSetColumns: null,
    controlOrderSetGridData: null,
    controlOrderSetItemsColumns: null,
    controlOrderSetItemsGridData: null,
    controlOrderGeneralColumns: null,
    controlOrderGeneralGridData: null,
    controlOrderExaminationColumns: null,
    controlOrderExaminationGridData: null,
    popupGridData: null,
    selectedDate: null,
    isOrderSetOpen: null,
    controlMaterialList: null,
    controlMaterialsLotList: null,
    equipmentList: null,
    controlOrderSpecimenNumbers: null,
    selectedControlOrderItems: null,
    controlOrderBarcodeItmeList: null,
    isShowLoader: false,
    barcodeServiceCode: null,
    contentLoaderType: 'spinner',
    isComboDisabled: true,
    loaderDimed: false,
    isButtonDisabled: true,
    isBarcodeDisabled: true,
    controlOrderService: service('laboratory-quality-management-order-service'),

    //print
    printPopup: null,
    printConfig: null,
    printContent: null,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'laboratory-quality-management-quality-control-order');

      this.setStateProperties([
        'model',
        'qualityControlOrderSetList',
        'controlOrderSetColumns',
        'controlOrderSetGridData',
        'controlOrderSetItemsColumns',
        'controlOrderSetItemsGridData',
        'controlOrderExaminationColumns',
        'controlOrderExaminationGridData',
        'popupGridColumns',
        'popupGridData',
        'selectedDate',
        'isOrderSetOpen',
        'controlMaterialList',
        'controlMaterialsLotList',
        'equipmentList',
        'controlOrderSpecimenNumbers',
        'selectedControlOrderItems',
        'controlOrderBarcodeItmeList',
        'isShowLoader',
        'contentLoaderType'
      ]);

      if(this.hasState()===false) {

        this.set('model', {
          selectedTabName: 'setOrder',
          orderSetTab: this.getLanguageResource('3730', 'S', null, '세트오더'),
          orderGeneralTab: this.getLanguageResource('17032', 'F', null, '일반'),
          selectedOrderSet: {
            name: null,
            id: null
          },
          examinationRoomList: emberA(),
          selectedExaminationRoom: null,
          selectedControlMaterial: null,
          selectedControlMaterialId: null,
          selectedControlMaterialName: null,
          selectedControlMaterialsLot: null,
          selectedControlMaterialsLotId: null,
          selectedEquipment: null,
          selectedEquipmentId: null,
          popupGridSelectedRows: null,
          selectedOrderControlGeneralItem: null,
          isPopupUpdated: false,
          isUpdatePopup: false,
          selectedOrdersetGridItem: null,
          selectedOrderGneralGridItem: null,
        });

        const displayDate = new Date(this.get('co_CommonService').getNow());
        this.set('selectedDate', displayDate);
        this.set('controlOrderSetColumns', [
          { field: 'name', title: this.getLanguageResource('3725', 'S', '', '세트명'), width:120},
        ]);
        this.set('controlOrderSetGridData', emberA());

        const gridColumns = [
          { field: 'controlMaterial.name', title: this.getLanguageResource('6814', 'S', '', '정도관리 물질'), width:130},
          { field: 'lot.lotNumber', title: this.getLanguageResource('215', 'S', '', 'Lot 번호'), width:120},
          { field: 'equipment.name', title: this.getLanguageResource('6513', 'S', '', '장비'), width:120},
        ];

        this.set('controlOrderSetItemsColumns', [
          { field: 'orderItem.controlMaterial.name', title: this.getLanguageResource('6814', 'S', '', '정도관리 물질'), width:130},
          { field: 'orderItem.lot.lotNumber', title: this.getLanguageResource('215', 'S', '', 'Lot 번호'), width:120},
          { field: 'equipment.name', title: this.getLanguageResource('6513', 'S', '', '장비'), width:120},
        ]);
        this.set('controlOrderSetItemsGridData', emberA());

        this.set('controlOrderGeneralColumns', gridColumns);
        this.set('controlOrderGeneralGridData', emberA());

        this.set('controlOrderExaminationColumns', [
          { field: 'examination.name', title: this.getLanguageResource('809', 'S', '', '검사항목명'), width:120},
        ]);
        this.set('controlOrderExaminationGridData', emberA());

        this.set('popupGridColumns', gridColumns);

        this.set('popupGridData', emberA());
        this.set('isOrderSetOpen', false);
        this.set('selectedControlOrderItems', null);
      }
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w800');

      this.getExaminationRoomList();
    },

    actions: {
      onSelectedOrderControlSet(e) {
        const selectedItem = e.selectedItems[0];
        this.set('controlOrderSetItemsGridData', emberA());
        if(!isEmpty(selectedItem)) {
          this.set('model.selectedOrderSet.name', selectedItem.name);
          this.set('model.selectedOrderSet.id', selectedItem.qualityControlOrderSetId);
          this.getOrderItems(selectedItem);
        }
      },
      onOrderDateChanged() {
        // this.getDataList();
      },
      onExaminationRoomChange(e) {
        if(!isEmpty(e.selectedItems)) {
          this.set('model.selectedExaminationRoom', e.selectedItems[0].id);
          // this.getControlMaterials();
          this.getDataList();
          this._setSettingRoomInfo();
          // this.getQualityControlOrderSet(e.selectedItems[0].id);
        }
      },
      onSelectionTabChanged() {
        let serviceCode = 'laboratoryqualitymanagement/print-barcode-quality-control-order-sets';
        if(this.get('model.selectedTabName') === 'general') {
          serviceCode = 'laboratoryqualitymanagement/print-barcode-quality-control-results';
        }
        this.set('barcodeServiceCode', serviceCode);
        this.set('isOrderSetOpen', false);
        this.getDataList();
      },
      onSearchData() {
        this.set('selectedDate', new Date(this.get('co_CommonService').getNow()));
        this.getDataList();
      },

      onControlOrderSetGridLoad(e) {
        this.set('controlOrderSetGrid', e.source);
      },

      onSelectedOrderControlGeneral(e) {
        const selectedItem = e.selectedItems[0];
        if(selectedItem) {
          this.set('model.selectedOrderControlGeneralItem', selectedItem);
          this.set('controlOrderExaminationGridData', selectedItem.lot.lotItems);
        }
      },

      onOrderSetDelete() {
        this._getDeleteOrderConfirm();
      },

      onOpenAddPopupAction() {
        this.set('isUpdatePopup', false);
        this.set('isOrderSetOpen', true);
        this.set('model.selectedEquipmentId', null);
        this.set('model.selectedOrderSet.id', null);
        this.set('model.selectedOrderSet.name', null);
      },
      onOpenPopupModifyAction(e) {
        this.set('isUpdatePopup', true);
        this.set('isOrderSetOpen', true);
        const selectedItem = e.item;
        if(selectedItem) {
          this.set('model.selectedOrderSet.name', selectedItem.name);
          this.set('model.selectedOrderSet.id', selectedItem.qualityControlOrderSetId);
        }
      },
      onPopupOpenedAction() {
        this.set('model.isPopupUpdated', false);
        this._getControlMaterials();
        if (this.get('isUpdatePopup') && isPresent(this.get('controlOrderSetItemsGridData'))) {
          this._setPopupGridData();
        }
      },
      onPopupClosedAction() {
        this.set('model.selectedControlMaterialId', null);
        this.set('model.selectedControlMaterialsLotId', null);
        this.set('model.selectedEquipmentId', null);
        this.set('model.selectedOrderSet.name', null);
        this.set('model.selectedOrderSet.id', null);
        this.set('model.selectedControlMaterial', null);
        this.set('isUpdatePopup', false);
        this.set('popupGridData', emberA());
        // if (this.get('model.isPopupUpdated') === true){
        //   this.getDataList();
        // }
      },

      onControlMaterialChange(e) {
        const selectedItems = e.selectedItems;
        this.set('isComboDisabled', true);
        if(!isEmpty(selectedItems)) {
          this.getControlMateriasLot(selectedItems[0].controlMaterialId);
          this.set('isComboDisabled', false);
        }
      },

      onControlMaterialsLotChange(e) {
        const selectedItems = e.selectedItems;
        if(selectedItems.length > 0) {
          this.getApplyEquipments(selectedItems[0].controlMaterialId);
        }
      },

      onEquipmentChange() {
        //
      },

      onDeletePopupGridItem() {
        const deleteItems = this.get('model.popupGridSelectedRows');
        if (deleteItems) {
          deleteItems.forEach((item) => {
            this.get('popupGridData').removeObject(item);
          });
        }
      },

      onAddPopupGridItem() {
        const material = this.get('model.selectedControlMaterial');
        const lot = this.get('model.selectedControlMaterialsLot');
        const equipment = this.get('model.selectedEquipment');
        if (isEmpty(material) || isEmpty(lot) || isEmpty(equipment)) {
          return;
        }
        const obj = {
          equipment: {
            id: equipment.id,
            name: equipment.name
          },
          controlMaterial: {
            id: material.controlMaterialId,
            name: material.name
          },
          lot: {
            id: lot.lotId,
            lotNumber: lot.lotNumber
          }
        };
        this.get('popupGridData').addObject(obj);
      },

      onPopupMultiSelected(e) {
        this.set('model.popupGridSelectedRows', e.selectedItems);
      },

      onSave() {
        this._controlSetSave();
      },

      onPopupReset() {
        this.set('popupGridData', emberA());
        this.set('model.selectedOrderSet.name', null);
      },

      onSelectedChangedBarcodeItem(e) {
        if (!isEmpty(e.selectedItems)) {
          this.set('isBarcodeDisabled', false);
          this.set('selectedControlOrderItems', e.selectedItems);
        } else {
          this.set('isBarcodeDisabled', true);
        }
      },

      onBarcodeButtonClick() {
        this._getBarcodePrintConfrim();
      },
      onSetNameInputLoaded(e) {
        this.set('setInputId', e.source.elementId);
      }
    },

    _gridDataReset() {
      this.set('controlOrderSetGridData', emberA());
      this.set('controlOrderSetItemsGridData', emberA());
      this.set('controlOrderGeneralGridData', emberA());
      this.set('controlOrderExaminationGridData', emberA());
      this.set('model.selectedOrderSet.id', null);
      this.set('model.selectedOrderSet.name', null);
    },

    async _controlSetSave() {
      try {
        if(isEmpty(this.get('model.selectedOrderSet.name'))) {
          this.showToastInputData();
          later(() => {
            let inputEl = document.getElementById(this.get('setInputId')).getElementsByTagName('input')[0];
            inputEl.select();
            inputEl.focus();
            inputEl = null;
          });
          return;
        }
        this.set('contentLoaderType', 'progress');
        this.set('loaderDimed', true);
        this.set('isShowLoader', true);
        const updateData = this.getUpdateData();
        const path = `${this.get('controlOrderService').urlPrefix}/quality-control-order-sets`;
        let promise = null;
        if (this.get('model.selectedOrderSet.id') === null) {
          delete updateData.qualityControlOrderSetId;
          promise = this.create(path, null, updateData, false);
        } else {
          promise = this.update(path, null, false, updateData, false);
        }
        await promise;
        this._saveSuccess();
        if (this.get('model.isPopupUpdated') === true){
          this.getDataList(updateData.name);
        }
        this.set('isShowLoader', false);
      } catch(e) {
        console.error(e);
        this._showSaveError(e);
        this.set('isShowLoader', false);
      }

    },

    async _deleteOrderSet() {
      try {
        this.set('contentLoaderType', 'progress');
        this.set('loaderDimed', true);
        this.set('isShowLoader', true);
        const deleteSetId = this.get('model.selectedOrderSet.id');
        const param = {
          qualityControlOrderSetId: deleteSetId
        };
        const path = `${this.get('controlOrderService').urlPrefix}/quality-control-order-sets`;
        await this.delete(path, null, param, false);
        this.showToastDeleted();
        this.getDataList();
        this.set('isShowLoader', false);
      } catch(e) {
        this.showToastDeleteFail();
        console.error(e);
      }
    },

    _saveSuccess() {
      this.showToastSaved();
      this.set('model.isPopupUpdated', true);
      this.set('isOrderSetOpen', false);
    },

    getUpdateData() {
      const updatedData = this.get('popupGridData');
      const updateItems = updatedData.map(function(item) {
        return {lotId: item.lot.id, equipmentId: item.equipment.id};
      });
      const returnData = {
        qualityControlOrderSetId: this.get('model.selectedOrderSet.id'),
        name: this.get('model.selectedOrderSet.name'),
        examinationRoomId: this.get('model.selectedExaminationRoom'),
        orderItems: updateItems
      };

      return returnData;
    },

    getDataList(setName) {
      if(isEmpty(this.get('model.selectedExaminationRoom'))) {
        return;
      }
      this._gridDataReset();
      this.set('loaderDimed', false);
      this.set('contentLoaderType', 'spinner');
      this.set('isShowLoader', true);
      if(this.get('model.selectedTabName') === 'setOrder') {
        this.getQualityControlOrderSet(setName);
      } else {
        this.getQualityControlOrderGeneral();
      }
    },

    _setPopupGridData() {
      const targetGridData = this.get('controlOrderSetItemsGridData');
      const popupGridItems = targetGridData.map(function(item) {
        return {
          equipment: item.equipment,
          controlMaterial: item.orderItem.controlMaterial,
          lot: item.orderItem.lot
        };
      });
      this.set('popupGridData', popupGridItems);
    },

    async _getControlOrderSpecimenNumbers() {
      try {
        let orderParams = [];
        if(this.get('model.selectedTabName') === 'setOrder') {
          orderParams = this.getSetBarcodeItem();
        } else {
          orderParams = this.getGeneralBarcodeItem();
        }
        if (!orderParams) {
          this.showWarningMessage(this.getLanguageResource('9325', 'F', null, '출력할 목록을 선택해주세요.'), 1000);
          return;
        }
        const dateParam = this.get('fr_I18nService').formatDate(new Date(this.get('selectedDate')), 'd');
        const now = this.get('co_CommonService').getNow();
        const localTime = `${now.getHours()}:${now.getMinutes()}:${now.getSeconds()}`;
        const params = {
          orderDatetime: new Date(`${dateParam} ${localTime}`),
          qualityControlOrders: orderParams
        };
        const path = `${this.get('controlOrderService').urlPrefix}/quality-control-orders`;
        const result = await this.getList(path, null, params, false);
        if(isPresent(result)) {
          this.set('controlOrderSpecimenNumbers', result.specimenNumbers);
          this._getControlOrdersSearch();
        }
      } catch(e) {
        this._showError(e);
      }
    },

    getSetBarcodeItem() {
      const items = this.get('selectedControlOrderItems');
      if (isEmpty(items)) {
        return;
      }
      return items.map(function(item) {
        return {
          equipmentId: item.equipment.id,
          lotId: item.orderItem.lot.id,
          observations: null
        };
      });
    },

    getGeneralBarcodeItem() {
      const items = this.get('selectedControlOrderItems');
      if (isEmpty(items)) {
        return;
      }
      const selectedItem = this.get('model.selectedOrderControlGeneralItem');
      const lotItem = selectedItem.orederItem ? selectedItem.orederItem.lot : selectedItem.lot;
      const orderList = [];
      const examinationIds = items.map(function(item) {
        return {examinationId: item.examination.id};
      });
      const observationParam = examinationIds.length > 0 ? examinationIds : null;
      orderList.push({equipmentId: selectedItem.equipment.id, lotId: lotItem.id, observations: observationParam});
      return orderList;
    },

    _getControlOrdersSearch() {
      const param = {
        specimenNumbers: this.get('controlOrderSpecimenNumbers')
      };
      const path = `${this.get('controlOrderService').urlPrefix}/quality-control-orders/search`;
      this.getList(path, null, param, false).then(res => {
        this.set('controlOrderBarcodeItmeList', res);
        this.orderSetBarcodeSendPrintMessage(res);
        // this.showToastSaved();
      });
    },

    async getExaminationRoomList() {
      try {
        const settingResult = await this.get('co_PersonalizationService').getSettingInfo(`laboratory-management-users-setting-info`);
        const result = await this.get('qualityManagementService').getExaminationRooms();
        if(!isEmpty(result)) {
          this.set('examinationRoomList', result);
          if(!isEmpty(settingResult.settingValue)) {
            const settingValue = JSON.parse(get(settingResult, 'settingValue'));
            if(!isEmpty(settingValue.conditionData)) {
              const settingOption = settingValue.conditionData[0];
              this.set('model.selectedExaminationRoom', settingOption.roomId);
            }
          } else {
            this.set('model.selectedExaminationRoom', result[0].id);
          }
          this.getDataList();
          this.set('isButtonDisabled', false);
        }
      } catch(e) {
        console.error(e);
      }
    },
    async _setSettingRoomInfo() {
      try {
        const settingData = {
          conditionData: [
            {
              roomId: this.get('model.selectedExaminationRoom'),
            }
          ]
        };
        await this.get('co_PersonalizationService').setSettingInfo(`laboratory-management-users-setting-info`, JSON.stringify(settingData), '검사결과조회 설정 저장');
      } catch(e) {
        console.log('_setSettingInfo Error::', e);
      }
    },
    async getQualityControlOrderSet(setName) {
      try {
        this.set('qualityControlOrderSetList', emberA());
        this.set('controlOrderSetGridData', emberA());
        if(isEmpty(this.get('model.selectedExaminationRoom'))) {
          return;
        }
        const param = {
          examinationRoomId: this.get('model.selectedExaminationRoom')
        };
        const result = await this.getList(`${this.get('controlOrderService').urlPrefix}/quality-control-order-sets`, param, null);
        if(!isEmpty(result)) {
          this.set('qualityControlOrderSetList', result);
          this.set('controlOrderSetGridData', result);
          let gridSelectItem = result[0];
          if(!isEmpty(setName)) {
            gridSelectItem = result.find(d => d.name === setName);
          }
          this.set('model.selectedOrdersetGridItem', gridSelectItem);
        }
        this.set('isShowLoader', false);
      } catch(e) {
        if(this.isDestroyed || this.isDestroying) {
          return;
        }
        this.set('isShowLoader', false);
        this._showError(e);
      }
    },

    async getQualityControlOrderGeneral() {
      try {
        this.set('controlOrderGeneralGridData', emberA());
        const param = {
          examinationRoomId: this.get('model.selectedExaminationRoom')
        };
        const result = await this.get('qualityManagementService').getControlMaterialsOrderList(param);
        if(!isEmpty(result)) {
          this.set('controlOrderGeneralGridData', result);
          this.set('model.selectedOrderGneralGridItem', result[0]);
        }
        this.set('isShowLoader', false);
      } catch(e) {
        if(this.isDestroyed || this.isDestroying) {
          return;
        }
        this.set('isShowLoader', false);
        this._showError(e);
      }

    },

    async _getControlMaterials() {
      try {
        if(isEmpty(this.get('model.selectedExaminationRoom'))) {
          return;
        }
        this.set('controlMaterialList', emberA());
        const param = {
          examinationRoomId: this.get('model.selectedExaminationRoom')
        };
        const result = await this.get('qualityManagementService').getControlMaterials(param);
        if (!isEmpty(result)) {
          // if (this.get('model.selectedControlMaterialId') === result[0].controlMaterialId) {
          //   return;
          // }
          this.set('controlMaterialList', result);
          this.set('model.selectedControlMaterialId', result[0].controlMaterialId);
          this.set('model.selectedControlMaterialName', result[0].displayCode);
          // this.getControlMateriasLot(result[0].controlMaterialId);
        }
      } catch(e) {
        if(this.isDestroyed || this.isDestroying) {
          return;
        }
        this._showError(e);
      }
    },

    getControlMateriasLot(materialId) {
      const param = {
        controlMaterialId: materialId
      };
      this.set('controlMaterialsLotList', emberA());
      this.get('qualityManagementService').getControlMateriasLot(param).then(result => {
        if (!isEmpty(result)) {
          this.set('controlMaterialsLotList', result);
          this.set('model.selectedControlMaterialsLotId', result[0].lotId);
        }
      });
    },

    getApplyEquipments(materialId) {
      const materialList = this.get('controlMaterialList');
      const findSetItems = materialList.find((d) => d.controlMaterialId === materialId);
      if(!isEmpty(findSetItems.applyEquipments)) {
        const findedFirstId = findSetItems.applyEquipments[0].id;
        if (this.get('model.selectedEquipmentId') === findedFirstId) {
          return;
        }
        this.set('equipmentList', findSetItems.applyEquipments);
        this.set('model.selectedEquipmentId', findSetItems.applyEquipments[0].id);
      }
    },

    getOrderItems(orderSet) {
      if(!isEmpty(orderSet.orderItems)) {
        this.set('controlOrderSetItemsGridData', orderSet.orderItems);
        later(() => {
          this.get('controlOrderSetGrid').selectAll();
        });
      }
    },

    _getBarcodePrintConfrim() {
      let secondCation = '';
      if(this.get('model.selectedTabName') === 'setOrder') {
        secondCation = `<br>${this.getLanguageResource('3725', 'S', null, '세트명')} : ${this.get('model.selectedOrdersetGridItem.name')}`;
      }
      const caption = `${this.getLanguageResource('5246', 'S', null, '오더일')} : ${this.get('fr_I18nService').formatDate(this.get('selectedDate'), 'd')}
      ${secondCation}`;
      const message = `<b>${this.getLanguageResource('10013', 'F', null, '정도관리 오더를 발행하시겠습니까?')}</b>`;
      this.showConfirmMessage(caption, message).then(result => {
        if (result === 'Yes') {
          this._getControlOrderSpecimenNumbers();
        }
      });
    },

    _getDeleteOrderConfirm() {
      this.showConfirmDelete().then(result => {
        if (result === 'Yes') {
          this._deleteOrderSet();
        }
      });
    },


  });