/* eslint-disable chis/avoid-memory-leak */
/* eslint-disable no-console */
import $ from 'jquery';
import layout from './template';
import CHIS from 'framework/chis-framework';
import QualityControlMixin from '../../mixins/quality-control-mixin';
import QualityControlMessageMixin from '../../mixins/quality-control-message-mixin';
import QualityControlPrintMixin from '../../mixins/quality-control-print-mixin';
import { isEmpty } from '@ember/utils';
import { later, once } from '@ember/runloop';
import { set, get, observer } from '@ember/object';
import { A as emberA } from '@ember/array';

export default CHIS.FR.Core.ComponentBase.extend(
  QualityControlMixin,
  QualityControlMessageMixin,
  QualityControlPrintMixin,
  {
    layout,
    model: null,
    paramEmployeeId: null,
    parallelTestId: null,
    parallelTestItem: null,
    editMode: null,
    isConditionDisabled: false,
    isShowLoader: false,
    isResetDesabled: false,
    examinationRoomId: null,
    isExaminationInvalid: false,
    isMaterialInvalid: false,
    isOldLotInValid: false,
    isNewLotInValid: false,
    isOldLotDateInValid: false,
    isNewLotDateInValid: false,
    isGridEditable: true,
    isReadOnly: false,
    selectedEmxaminationRoomItem: null,
    isRateChanged: false,
    isFirstLoad: true,
    roonListChanged: observer('examinationRoomList', function() {
      once(this, '_setExaminationRoom');
    }),
    parallelTestIdChanged: observer('parallelTestItem.id', function() {
      once(this, '_getParallelTestResults');
    }),

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'laboratory-quality-management-parallel-test-registration');

      this.setStateProperties([
        'isDisabled',
        'isReadOnly',
        'parallelColumns',
        'parallelGridData',
        'numericOptions',
        'examinationRoomId',
        'paramEmployeeList',
        'employees',
        'selectedDate',
        'gridSource'
      ]);
      if (!this.hasState()) {
        this.set('model', {
          searchEmployeeId: null,
          selectedGridItem: null,
          registItem: {
            parallelTestDate: null,
            oldLotNumber: null,
            oldLotDate: null,
            newLotNumber: null,
            newLotDate: null,
            entryStaff: {
              number: null,
              name: null,
            },
          },
        });
        this.set('parallelColumns', [
          { field: 'lotTypeCode.name', title: this.getLanguageResource('841', 'F', '', '검체농도')},
          { field: 'beforeChangeResult', title: this.getLanguageResource('14862', 'F', '', '변경전'), align:'right', bodyTemplateName: 'beforeResult'},
          { field: 'afterChangeResult', title: this.getLanguageResource('10274', 'F', '', '변경후'), align:'right', bodyTemplateName: 'afterResult'},
          // { field: 'differenceRate', title: 'Difference(%)', width: 100, align:'right', readOnly: true},
          { field: 'differenceRate', title: this.getLanguageResource('14856', 'F', '', 'Difference(%)'), width: 100, align:'right', readOnly: true},
          { field: 'judgementResult', title: this.getLanguageResource('17034', 'F', '', '판정'), readOnly: true},
        ]);
        this.set('parallelGridData', emberA());
        this.set('numericOptions', {
          alias: 'numeric',
          autoUnmask: true,
          unmaskAsNumber: true,
        });
      }
    },


    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1000');
      $(this.element).addClass('hp100');
      this.set('model.registItem.entryStaff.number', this.get('userGlobalInformation.employeeDisplayId'));
      this.set('model.registItem.entryStaff.name', this.get('userGlobalInformation.employeeName'));
      if(isEmpty(this.get('examinationRoomList'))) {
        this.getExaminationRoomList();
      }
      if (this.get('editMode') === 'Modify') {
        this.set('isConditionDisabled', true);
        // this.set('isResetDesabled', true);
      }
    },

    didUpdateAttrs() {
      this._super(...arguments);
    },

    didReceiveAttrs() {
      this._super(...arguments);
      // console.log('didReceiveAttrs---', this.get('isReadOnlyRefresh'));
      if(this.get('editMode') === 'ReadOnly' && this.get('isReadOnlyRefresh')) {
        this.set('model.selectedControlMaterialId', null);
        this.set('model.selectedExaminationId', null);
        this._resetRegistItems();
        this.set('isConditionDisabled', true);
        this.set('isReadOnly', true);
        this._getParallelTestResults();
        this.set('isGridEditable', false);
      }
    },

    actions: {
      childLoad(componentName, object) {
        console.log('childLoad---', componentName, object);
        // this.get('registerCB')('laboratory-quality-management-parallel-test-registration', this);
      },
      onSelectEmployee(item) {
        console.log('onSelectedEmployeeCB', item);
        if(!isEmpty(item)) {
          this.set('model.searchEmployeeId', item.employeeId);
        }
        // if(isEmpty(item) && !isEmpty(this.get('parallelTestItem'))) {
        //   this.employeeSetting();
        // }
      },
      onComboboxLoaded(type, e) {
        this.set(`${type}Combobox`, e.source);
      },
      onControlMaterialChangeByParallel(e) {
        const selectedItems = e.selectedItems;
        if(selectedItems.length > 0) {
          if(this.get('editMode') === 'Insert') {
            this._getParallelTestLotTypes();
          }
          this._getExaminationList();
        }
      },
      onExaminationRoomChangeByParallel(e) {
        console.log('onExaminationRoomChangeByParallel---');
        const selectedItems = e.selectedItems;
        this._gridDataReset();
        this.setComboboxReset();
        // if(selectedItems.length > 0) {
        //   this._getConditionList(selectedItems[0].id);
        // } else {
        //   this._getConditionList(this.get('examinationRoomList')[0].id);
        // }
        if(!isEmpty(selectedItems)) {
          this._getConditionList(selectedItems[0].id);
          this._setSettingRoomInfo();
          // this.set('isFirstLoad', false);
        }
        // this.getDataList();
      },
      onExaminationChangeByParallel() {
        // const selectedItems = e.selectedItems;
        // if (isEmpty(this.get('examinationList'))) {
        //   return;
        // }
        // if (selectedItems.length > 0) {
        //   const selectedItemList = this._pluck(selectedItems, 'id');
        //   this.set('model.selectedExaminationId', selectedItemList);
        // } else {
        //   this.set('model.selectedExaminationId', null);
        // }
        // this.getDataList();
      },
      onSaveClick() {
        if (!this._checkValidation()) {
          return;
        }
        this.set('isDisabled', true);
        if (this.get('editMode') === 'Modify') {
          this._updateParallelTest();
        } else {
          this._createParallelTest();
        }
      },
      onResetClick(){
        this._resetRegistItems();
      },
      onPrintClick() {
        this.parallelTestSendPrintMessage(this.get('parallelGridData'));
      },
      onGridCellClick(e) {
        const fieldName = e.column.field;
        if((fieldName === 'differenceRate' || fieldName === 'judgementResult') && this.get('isRateChanged')) {
          this._createParallelTestCalculrateDiff();
        }

      },
      onFocusInMaskedInput(e) {
        this.set('isRateChanged', false);
        setTimeout(() => {
          // $(e.originalEvent.target).select();
          e.originalEvent.target.select();
          e.originalEvent.preventDefault();
          e.originalEvent.stopPropagation();
        }, 100);
      },
      onChangeResultTextCommit(type, e) {
        console.log('type--', type);
        this.set('isRateChanged', true);
        if ((type === 'After' && e.originalEvent.keyCode === 9 ) || e.originalEvent.keyCode === 13) {
          later(this, function() {
            if(this.isDestroyed || this.isDestroying) {
              return;
            }
            this._createParallelTestCalculrateDiff();
          }.bind(this));
        }
      },
      onGridBeforeKeyDown(e) {
        // let targetElementId = '';
        if (e.originalEvent.keyCode === 13) {
          let gridComponent = e.source,
            currentCell = gridComponent.getCurrentCell(),
            itemIndex = gridComponent.getItemIndex(currentCell.item),
            columnIndex = gridComponent.getColumnIndex(currentCell.column);

          // console.log('currentCell---', currentCell);
          if (itemIndex !== -1 && columnIndex !== -1) {
            columnIndex = columnIndex + 1;
            e.cancel = true;
            if (get(gridComponent, 'bindingColumns').length <= columnIndex) {
              // is last column
              itemIndex = itemIndex + 1;
              columnIndex = 0;
            }
            gridComponent.focusCell(itemIndex, columnIndex);
            gridComponent.editCell(itemIndex, columnIndex);
            // this.$(`#${currentCell.cellComponent.elementId}`).select();
            // targetElementId = currentCell.cellComponent.elementId;
            // next(this, function(){
            //   this.$(`#${targetElementId}`).select();
            //   console.log('targetElementId---', targetElementId);
            // });
            // gridComponent.selectCell(itemIndex, columnIndex);
          }
          gridComponent = null;
          currentCell = null;
        }
      },
      onGridLoaded(e) {
        this.set('gridSource', e.source);
      },
    },

    getDataList() {
      // this._getParallelTestLotTypes();
    },
    _gridDataReset() {
      //
    },
    async getExaminationRoomList() {
      this.set('model.selectedExaminationRoom', null);
      const roomList = await this.get('qualityManagementService').getExaminationRooms();
      if (isEmpty(roomList)) {
        return;
      }
      this.set('examinationRoomList', roomList);
      this._setSelectedRoom();
    },
    _setExaminationRoom() {
      const roomList = this.get('examinationRoomList');
      if (isEmpty(roomList)) {
        return;
      }
      // this.set('examinationRoomList', roomList);
      this._setSelectedRoom();
    },
    _setSelectedRoom() {
      if(this.get('editMode') === 'Modify' || this.get('editMode') === 'ReadOnly') {
        let roomId = this.get('parallelTestItem.examinationRoom.id');
        if(isEmpty(roomId)) {
          roomId = this.get('examinationRoomId');
        }
        this.set('model.selectedExaminationRoom', roomId);
      } else {
        this.set('model.selectedExaminationRoom', this.get('examinationRoomId'));
      }

    },
    async _getConditionList(roomId) {
      try {
        await this._getControlMaterialsOrderList(roomId);
        await this.getControlMaterials(roomId);
        // if (this.get('editMode') === 'Modify' || this.get('editMode') === 'ReadOnly') {
        if (this.get('editMode') === 'Modify') {
          await this._getParallelTestResults();
        }
      } catch(e) {
        console.log('_getConditionList Error::: ', e);
      }
    },
    employeeSetting() {
      const item = this.get('parallelTestItem');
      if(!isEmpty(item) && !isEmpty(item.confirmationStaff)) {
        this.set('paramEmployeeId', item.confirmationStaff.id);
        this.set('model.searchEmployeeId',item.confirmationStaff.id);
      }
    },

    async _getControlMaterialsOrderList(roomId) {
      try {
        this.set('orderList', emberA());
        const param = {
          examinationRoomId: roomId
        };
        const result = await this.get('qualityManagementService').getControlMaterialsOrderList(param);
        if(!isEmpty(result)) {
          this.set('orderList', result);
        }
      } catch(e) {
        this._showError(e);
        console.log('_getControlMaterialsOrderList Error::: ', e);
      }
    },

    _getExaminationList() {
      this.set('examinationList', emberA());
      const orderList = this.get('orderList');
      const lotItems = [];
      if(!isEmpty(orderList)) {
        orderList.forEach(data => {
          if (data.controlMaterial.id === this.get('model.selectedControlMaterialId')) {
            data.lot.lotItems.forEach(item => {
              let findItem = null;
              if(!isEmpty(lotItems)) {
                findItem = lotItems.find(d => d.id === item.examination.id);
              }
              if(isEmpty(findItem)) {
                lotItems.push(item.examination);
              }
            });
          }
        });
        this.set('examinationList', lotItems);
      }
      if(this.get('model.selectedExaminationId') !== this.get('parallelTestItem.examination.id')) {
        this.set('model.selectedExaminationId', this.get('parallelTestItem.examination.id'));
      }

    },
    async _getParallelTestLotTypes() {
      try {
        this.set('parallelGridData', emberA());
        this.set('isShowLoader', true);
        const param = {
          controlMaterialId: this.get('model.selectedControlMaterialId')
        };
        const lotTypes = await this.get('qualityManagementService').getParallelTestLotTypes(param);
        this.set('parallelGridData', lotTypes);
        this.set('isShowLoader', false);
      } catch(e) {
        this._showDataError(e);
        console.log('_getParallelTestLotTypes Error::: ', e);
      }
    },
    async _getParallelTestResults() {
      try {
        this.set('parallelGridData', emberA());
        this.set('isShowLoader', true);
        const param = {
          parallelTestId: this.get('parallelTestItem.id')
        };
        const result = await this.get('qualityManagementService').getParallelTestResults(param);
        // this.set('resultItem', result);
        if(!isEmpty(result)) {
          this.set('parallelGridData', result[0].parallelTestResults);
          this._setModifyItem(result[0]);
        }
        this.set('isShowLoader', false);
      } catch(e) {
        this._showDataError(e);
        console.log('_getParallelTestResults Error::: ', e);
      } finally {
        later(this, function () {
          if(this.isDestroyed || this.isDestroying) {
            return;
          }
          this.employeeSetting();
          // this.get('employee-search').send('onTextCleared');
        });
      }
    },

    _setModifyItem(item) {
      // const item = this.get('parallelTestItem');
      this.set('parallelTestId', item.id);
      this.set('model.selectedExaminationRoom', item.examinationRoom.id);
      this.set('model.selectedControlMaterialId', item.controlMaterial.id);
      // this.set('model.selectedExaminationId', item.examination.id);
      this.set('model.registItem.parallelTestDate', item.parallelTestDatetime);
      this.set('model.registItem.oldLotNumber', item.oldLotNumber);
      this.set('model.registItem.newLotNumber', item.newLotNumber);
      this.set('model.registItem.oldLotDate', item.oldLotAvailableDatetime);
      this.set('model.registItem.newLotDate', item.newLotAvailableDatetime);
      this.set('model.registItem.entryStaff.name', item.registrationStaff.entryStaff.name);
      this.set('model.registItem.entryStaff.number', item.registrationStaff.entryStaff.number);
      this.set('selectedDate', item.parallelTestDatetime);
    },

    _getSaveParams() {
      const params = {
        parallelTestId: this.get('parallelTestId'),
        parallelTestDatetime: this.get('selectedDate'),
        oldLotNumber: this.get('model.registItem.oldLotNumber'),
        oldLotAvailableDatetime: this.get('model.registItem.oldLotDate'),
        newLotNumber: this.get('model.registItem.newLotNumber'),
        newLotAvailableDatetime: this.get('model.registItem.newLotDate'),
        confirmationStaffId: this.get('model.searchEmployeeId'),
        parallelTestResults: this._getSaveTestResults()
      };
      return params;
    },

    _getSaveTestResults() {
      const gridData = this.get('parallelGridData');
      const results = [];
      gridData.forEach(item => {
        results.push({
          id: item.id,
          parallelTestId: item.parallelTestId,
          lotTypeCode: {
            code: item.lotTypeCode.code,
            displayCode: item.lotTypeCode.code,
            name: item.lotTypeCode.name,
            abbreviation: item.lotTypeCode.name
          },
          beforeChangeResult: item.beforeChangeResult,
          afterChangeResult: item.afterChangeResult,
          differenceRate: item.differenceRate,
          judgementResult: item.judgementResult,
          displaySequence: item.displaySequence
        });
      });
      return results;
    },
    async _createParallelTest() {
      try {
        let params = {};
        params = this._getSaveParams();
        params.examinationRoomId = this.get('model.selectedExaminationRoom');
        params.controlMaterialId = this.get('model.selectedControlMaterialId');
        params.examinationId = this.get('model.selectedExaminationId');
        params.displaySequence = 0;
        await this.get('qualityManagementService').createParallelTest(params);
        this.showToastSaved();
        this.set('isDisabled', false);
        if(!isEmpty(this.get('registrationCB'))) {
          this.get('registrationCB')(this.get('editMode'));
        }
      } catch(e) {
        this.set('isDisabled', false);
        this._showSaveError(e);
      }
    },
    async _updateParallelTest() {
      try {
        const params = this._getSaveParams();
        await this.get('qualityManagementService').updateParallelTest(params);
        await this._getParallelTestResults();
        this.showToastSaved();
        this.set('isDisabled', false);
        if(!isEmpty(this.get('registrationCB'))) {
          this.get('registrationCB')(this.get('editMode'));
        }
      } catch(e) {
        this.set('isDisabled', false);
        this._showSaveError(e);
      }
    },
    async _createParallelTestCalculrateDiff() {
      try {
        const item = this.get('model.selectedGridItem');
        const params = {
          lotTypeCode: {
            code: item.lotTypeCode.code,
            displayCode: item.lotTypeCode.code,
            name: item.lotTypeCode.name,
            abbreviation: item.lotTypeCode.name
          },
          beforeChangeResult: item.beforeChangeResult,
          afterChangeResult: item.afterChangeResult,

        };
        const result = await this.get('qualityManagementService').createParallelTestCalculrateDiff(params);
        set(item, 'differenceRate', result.differenceRate);
        set(item, 'judgementResult', result.judgementResult);
        this.set('isRateChanged', false);
        // this.showToastSaved();
      } catch(e) {
        this._showSaveError(e);
      }

    },
    _resetRegistItems() {
      this.set('model.registItem.parallelTestDate', null);
      this.set('model.registItem.oldLotNumber', null);
      this.set('model.registItem.newLotNumber', null);
      this.set('model.registItem.oldLotDate', null);
      this.set('model.registItem.newLotDate', null);
      this.set('model.searchEmployeeId', null);
      this.set('paramEmployeeId', null);
      this.set('model.registItem.entryStaff.number', this.get('userGlobalInformation.employeeDisplayId'));
      this.set('model.registItem.entryStaff.name', this.get('userGlobalInformation.employeeName'));
      if(this.get('editMode') === 'Insert') {
        this.set('model.selectedExaminationRoom', null);
        this.set('model.selectedControlMaterialId', null);
        this.set('model.selectedExaminationId', null);
        this.set('parallelGridData', emberA());
      }
    },
    _checkValidation() {
      let isValid = false;
      if(isEmpty(this.get('model.selectedControlMaterialId'))) {
        this.set('isMaterialInvalid', true);
        set(this.get('materialCombobox'), 'isOpen', true);
      }else if(isEmpty(this.get('model.selectedExaminationId'))){
        this.set('isExaminationInvalid', true);
        set(this.get('examCombobox'), 'isOpen', true);
      } else if(isEmpty(this.get('model.registItem.oldLotNumber'))){
        this.set('isOldLotInValid', true);
      } else if(isEmpty(this.get('model.registItem.newLotNumber'))){
        this.set('isNewLotInValid', true);
      } else if(isEmpty(this.get('model.registItem.oldLotDate'))){
        this.set('isOldLotDateInValid', true);
      } else if(isEmpty(this.get('model.registItem.newLotDate'))){
        this.set('isNewLotDateInValid', true);
      } else {
        isValid = true;
      }
      if (!isValid) {
        this.showToastInputData();
      }
      return isValid;
    },

    _showDataError(e) {
      if(this.isDestroyed || this.isDestroying) {
        return;
      }
      this.set('isShowLoader', false);
      this._showError(e);
    },

  });