/* eslint-disable no-console */
import layout from './template';

import CHIS from 'framework/chis-framework';
import QualityControlChartMixin from '../../mixins/quality-control-chart-mixin';

export default CHIS.FR.Core.ComponentBase.extend(QualityControlChartMixin, {
  chart: null,

  layout,

  actionMode: null,
  chartType: null,
  colorOptions: null,
  yAxisOptions: null,
  customYAxis: null,
  customYAxisOptions: null,
  data: null,
  reload: null,
  selectedItem: null,
  yAxisPosition: null,
  strokeColor: null,
  strokeWidth: null,
  symbolColor: null,
  symbolSize: null,
  symbolType: null,
  symbolTypeOptions: null,
  selectedExaminationData: null,
  isChartShow: false,
  chartClass: null,
  chartHeight: null,
  chartWidth: null,
  periodType: null,

  onPropertyInit() {
    this._super(...arguments);
    this.set('viewId','laboratory-quality-management-quality-control-chart');
    console.log('laboratory-quality-management-quality-control-general.onPropertyInit()');
    this.setStateProperties([
      'actionMode', 'chartType', 'chartTypeOptions',
      'colorOptions', 'yAxisOptions', 'customYAxis', 'customYAxisOptions',
      'data', 'reload', 'selectedItem', 'strokeColor', 'strokeWidth', 'symbolColor', 'symbolSize',
      'symbolType', 'symbolTypeOptions', 'selectedExaminationData',
      'chartTimePointer', 'chart', 'lineChartData', 'size', 'legend', 'isChartShow', 'customYAxisValue', 'chartHeight', 'chartWidth'
    ]);

    if (this.hasState()===false) {
      this._setLineChart();
      this.set('actionMode', null);
      this.set('chartType', 'line');
      this.set('periodType', 'Daily');
    }
  },

  onLoaded() {
    this._super(...arguments);
    this.set('actionMode', 'update');
    console.log('quality-control-chart-onLoaded()');
  },

  didInsertElement(){
    this._super(...arguments);
  },

  didRender() {
    this._super(...arguments);
    console.log('chart.didRender()');
  },

  didUpdateAttrs() {
    this._super(...arguments);
    this.set('actionMode', 'update');
    this._setLineChart();
  },

  willDestroyElement() {
    this._super(...arguments);
    // console.log('willDestroyElement()');
  },

});
