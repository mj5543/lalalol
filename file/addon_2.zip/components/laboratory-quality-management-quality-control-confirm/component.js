/* eslint-disable no-console */
import layout from './template';
import CHIS from 'framework/chis-framework';
import QualityControlMixin from '../../mixins/quality-control-mixin';
import QualityControlPrintMixin from '../../mixins/quality-control-print-mixin';
import QualityControlMessageMixin from '../../mixins/quality-control-message-mixin';
import { isEmpty, isPresent } from '@ember/utils';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  QualityControlMixin,
  QualityControlPrintMixin,
  QualityControlMessageMixin,
  {
    layout,
    selectedFromDate: null,
    selectedToDate: null,
    isConfirmPopupOpen: false,
    selectedStaff: null,
    selectedLastStaff: null,
    isPopupLoaderShow: false,

    isOpenFull: false,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'laboratory-quality-management-quality-control-confirm');

      this.setStateProperties([
        'model',
        'selectedFromDate',
        'selectedToDate'
      ]);

      if(this.hasState()===false) {

        this.set('model', {
          selectedExaminationRoomId: null,
        });
      }
      this.set('gridColumns', [
        { field: 'confirmedDate', title: this.getLanguageResource('16890', 'S', '', '검사일'), align: 'center', width:90, type: 'date', dataFormat: 'd' },
        { field: 'equipment.name', title: this.getLanguageResource('689', 'F', '', '검사장비'), width: 110, align: 'center'},
        { field: 'controlMaterial.name', title: this.getLanguageResource('6814', 'F', '', '정도관리물질'), width: 110, align: 'center'},
        { field: 'lot.lotNumber', title: this.getLanguageResource('215', 'F', '', 'Lot No.'), width: 90, align: 'center'},
        { field: 'firstConfirmedStaff.name', title: this.getLanguageResource('8387', 'S', '', '확인자'), width: 100, align: 'center'},
        { field: 'lastConfirmedStaff.name', title: this.getLanguageResource('17228', 'S', '', '최종확인자'), width: 100, align: 'center'},
      ]);
      this.set('popupGridColumns', [
        { field: 'equipment.name', title: this.getLanguageResource('689', 'F', '', '검사장비'), width: 110, align: 'center'},
        { field: 'controlMaterial.name', title: this.getLanguageResource('6814', 'F', '', '정도관리물질'), width: 110, align: 'center'},
        { field: 'lot.lotNumber', title: this.getLanguageResource('215', 'F', '', 'Lot No.'), width: 110, align: 'center'},
      ]);
      this.set('lastStaffError', this.getLanguageResource('tempkey', 'F', null, '최종확인자를 선택해주세요'));
      this.set('popupGridItems', []);
      this.set('gridItems', []);
    },

    onLoaded() {
      this._super(...arguments);
      // this.set('menuClass', 'w1450');
      this.set('menuClass', 'w800');
      this.getExaminationRoomList();
      this._getBusinessCodes();
    },

    actions: {
      onGridLoaded(e) {
        this.set('gridSource', e.source);
      },
      onPopupGridLoaded(e) {
        this.set('popupGridSource', e.source);
      },
      onExaminationRoomChanged(e) {
        const selectedItems = e.selectedItems;
        if(!isEmpty(selectedItems)) {
          this.set('model.selectedExaminationRoom', selectedItems[0].id);
          this.getDataList();
          this._setSettingRoomInfo();
        }
      },
      onSearchData() {
        this.getDataList();
      },
      onPopupFromToUpdated() {
        // this._getPopupGridItems();
      },
      onPopupOpened() {
        //
      },
      onPopupClosed() {
        // this.set('selectedStaff', null);
      },
      onDelClick() {
        this._saveConfirmCancel();
      },
      onAddClick() {
        // const ele = document.getElementsByClassName('full-board');
        // console.log('element---', ele);
        // ele[0].requestFullscreen();
        // this.set('isOpenFull', true);
        this.set('popupTarget',`#${event.target.id}`);
        this.set('popupSelectedFromDate', this.get('selectedFromDate'));
        this.set('popupSelectedToDate', this.get('selectedToDate'));
        this.set('isConfirmPopupOpen', true);
        this._getPopupGridItems();
      },
      onCancel() {
        this.set('isConfirmPopupOpen', false);
      },
      onConfirm() {
        this._saveConfirm();
      },
      onStaffChanged() {
        this.set('lastStaffErrorMessage', null);
      },
      onLastConfirmClick() {
        this._saveLastConfirm();
      },
      onLastConfirmCancelClick() {
        this._saveLastConfirmCancel();
      }
    },
    getDataList() {
      // this.set('selectedLastStaff', null);
      this._getGridItems();
    },

    async _getBusinessCodes() {
      try {
        const confirmStaffList = await this.get('qualityManagementService').getLaboratoryBusinessCode({classificationCode: 'QualityControlConfirmStaff'});
        const lasConfirmStaffList = await this.get('qualityManagementService').getLaboratoryBusinessCode({classificationCode: 'QualityControlLastConfirmStaff'});
        this.set('confirmStaffList', confirmStaffList);
        if(isPresent(confirmStaffList)) {
          this.set('selectedStaff', confirmStaffList[0]);
        }
        this.set('lasConfirmStaffList', lasConfirmStaffList);
        if(isPresent(lasConfirmStaffList)) {
          this.set('selectedLastStaff', lasConfirmStaffList[0]);
        }
        this._getGridItems();
      } catch(e) {
        //
      }
    },

    async _getGridItems() {
      try {
        this.set('mainLoaderType', 'spinner');
        this.set('mainLoaderDimed', false);
        this.set('isShowLoader', true);
        this.set('gridItems', []);
        const params = {
          fromDate: this.getDateString(this.get('selectedFromDate')),
          toDate: this.getDateString(this.get('selectedToDate')),
          examinationRoomId: this.get('model.selectedExaminationRoom')
        };
        const result = await this.get('qualityManagementService').getComfirm(params);
        if(isPresent(result)) {
          this.set('gridItems', result);
        }
        this.set('isShowLoader', false);
      } catch(e) {
        this._error(e);
      }
    },

    async _getPopupGridItems() {
      try {
        this.set('popupLoadertype', 'spinner');
        this.set('popupLoaderDimed', false);
        this.set('isPopupLoaderShow', true);
        this.set('popupGridItems', []);
        const params = {
          examinationRoomId: this.get('model.selectedExaminationRoom')
        };
        const result = await this.get('qualityManagementService').getComfirmItems(params);
        if(isPresent(result)) {
          this.set('popupGridItems', result);
        }
        this.set('isPopupLoaderShow', false);
      } catch(e) {
        this._error(e);
      }
    },
    async _saveConfirm() {
      try {
        if(isEmpty(this.get('popupGridSource.selectedItems'))) {
          return;
        }
        if(isEmpty(this.get('selectedStaff'))) {
          this.showToastInputData();
          return;
        }
        // const res = await this.showConfirmSave();
        // if(res !== 'Yes') {
        //   return;
        // }
        this.set('popupLoadertype', 'progress');
        this.set('popupLoaderDimed', true);
        this.set('isPopupLoaderShow', true);
        const params = {
          fromDate: this.get('popupSelectedFromDate'),
          toDate: this.getDateString(this.get('popupSelectedToDate')),
          firstConfirmStaffDisplayId: this.get('selectedStaff.displayCode'),
          qualityControlConfirms: this._getQualityControlConfirms()
        };
        await this.get('qualityManagementService').createConfirm(params);
        this.showToastSaved();
        this.set('isPopupLoaderShow', false);
        this.set('isConfirmPopupOpen', false);
        this._getGridItems();
      } catch(e) {
        this._saveError(e);
      }
    },
    _getQualityControlConfirms() {
      const items = [];
      const selectedItmes = this.get('popupGridSource.selectedItems');
      const examinationRoomId = this.get('model.selectedExaminationRoom');
      if(isPresent(selectedItmes)) {
        selectedItmes.forEach(d => {
          items.push({
            examinationRoomId: examinationRoomId,
            equipmentId: d.equipment.id,
            controlMaterialId: d.controlMaterial.id,
            lotId: d.lot.id
          });
        });
      }
      return items;
    },
    async _saveLastConfirm() {
      try {
        const confirmItems = this.get('gridSource.selectedItems');
        if(isEmpty(confirmItems)) {
          return;
        }
        const selectedLastStaff = this.get('selectedLastStaff');
        if(isEmpty(selectedLastStaff)) {
          this.set('lastStaffErrorMessage', this.get('lastStaffError'));
          this.showToastCustomMessage('error', this.get('lastStaffError'));
          return;
        }
        const res = await this.showConfirmMessage(this.getLanguageResource('tempkey', 'F', null, '최종확인'), this.getLanguageResource('tempkey', 'F', null, '최종확인 하시겠습니까?'));
        if(res !== 'Yes') {
          return;
        }
        this.set('mainLoaderType', 'progress');
        this.set('mainLoaderDimed', true);
        this.set('isShowLoader', true);
        const params = {
          lastConfirmStaffDisplayId: selectedLastStaff.displayCode,
          qualityControlConfirmIds: confirmItems.map(d => d.qualityControlConfirmId)
        };
        await this.get('qualityManagementService').lastConfirm(params);
        this.set('isShowLoader', false);
        this.showToastSaved();
        this._getGridItems();
      } catch(e) {
        this._saveError(e);
      }
    },
    async _saveConfirmCancel() {
      try {
        const selectdeConfirmItems = this.get('gridSource.selectedItems');
        if(isEmpty(selectdeConfirmItems)) {
          return;
        }
        const res = await this.showConfirmDelete();
        if(res !== 'Yes') {
          return;
        }
        this.set('mainLoaderType', 'progress');
        this.set('mainLoaderDimed', true);
        this.set('isShowLoader', true);
        const params = {
          qualityControlConfirmIds: selectdeConfirmItems.map(d => d.qualityControlConfirmId)
        };
        await this.get('qualityManagementService').cancelConfirm(params);
        this.showToastDeleted();
        this.set('isShowLoader', false);
        this._getGridItems();
      } catch(e) {
        this._saveError(e);
      }
    },
    async _saveLastConfirmCancel() {
      try {
        const confirmItems = this.get('gridSource.selectedItems');
        if(isEmpty(confirmItems)) {
          return;
        }
        const res = await this.showConfirmMessage(this.getLanguageResource('tempkey', 'F', null, '최종확인취소'), this.getLanguageResource('tempkey', 'F', null, '최종확인 취소하시겠습니까?'));
        if(res !== 'Yes') {
          return;
        }
        this.set('mainLoaderType', 'progress');
        this.set('mainLoaderDimed', true);
        this.set('isShowLoader', true);
        const params = {
          qualityControlConfirmIds: confirmItems.map(d => d.qualityControlConfirmId)
        };
        await this.get('qualityManagementService').lastConfirmCancel(params);
        this.showToast('delete', '', this.getLanguageResource('tempkey', 'F', null, '확인취소되었습니다'));
        this.set('isShowLoader', false);
        this._getGridItems();
      } catch(e) {
        this._saveError(e);
      }
    },

    _error(e) {
      this.set('isShowLoader', false);
      this.set('isPopupLoaderShow', false);
      this._showError(e);
    },
    _saveError(e) {
      this.set('isShowLoader', false);
      this.set('isPopupLoaderShow', false);
      this._showSaveError(e);
    },
  });