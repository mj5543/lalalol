/* eslint-disable max-lines */
/* eslint-disable max-lines-per-function */
/* eslint-disable no-console */
// import $ from 'jquery';
// import { copy } from '@ember/object/internals';
import { A as emberA } from '@ember/array';
import { next } from '@ember/runloop';
import { isEmpty } from '@ember/utils';
import { get } from '@ember/object';
import layout from './template';
import CHIS from 'framework/chis-framework';
import QualityControlMixin from '../../mixins/quality-control-mixin';
import QualityControlPopupMixin from '../../mixins/quality-control-material-management/quality-control-popup-mixin';
import QualityControlMaterialsPopupMixin from '../../mixins/quality-control-material-management/quality-control-materials-popup-mixin';
import QualityControlLotsPopupMixin from '../../mixins/quality-control-material-management/quality-control-lots-popup-mixin';
import QualityControlMessageMixin from '../../mixins/quality-control-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  QualityControlMixin,
  QualityControlPopupMixin,
  QualityControlMaterialsPopupMixin,
  QualityControlLotsPopupMixin,
  QualityControlMessageMixin,
  {
    layout,
    selectedFromDate: null,
    selectedToDate: null,
    materialGridData: null,
    lotGridData: null,
    examinationGridData: null,
    materialColumns: null,
    lotColumns: null,
    examinationColumns: null,
    isMaterialPopupOpen: false,
    isLotPopupOpen: false,
    isExaminationSearchOpen: false,
    isUpdatePopup: false,
    isAddPopup: false,
    isSdSearchOpen: false,
    isPopupSearch: false,
    equipmentsCombobox: null,
    isMaterialsPopupShowLoader: false,
    isExaminationListByPopupShowLoader: false,
    lotLevelSource: null,
    cumulativePopupData: null,
    cumulativePopupColumns: null,
    examinationGrid: null,
    isLotsShowLoader: false,
    changedMaterialItems: null,
    changedExaminationItems: null,
    examinationSearchPopupColumns: null,
    inputMatarialCode: null,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'laboratory-quality-management-quality-control-material-management');

      this.setStateProperties([
        'model',
        'selectedFromDate',
        'selectedToDate',
        'equipmentsData',
        'equipmentsColumns',
      ]);

      if(this.hasState()===false) {
        this.set('model', {
          selectedMaterialItem: null,
          selectedLotItem: null,
          selectedExaminationItem: null,
          materialEditItems: {
            displayCode: null,
            name: null,
            groupName: null,
            equipmentsIds: null,
            companyName: null,
          },
          lotEditItems: {
            lotNumber: null,
            lotTypeCode: null,
            effectiveDatetime: null,
            startDatetime: null,
            endDatetime: null,
            barcodeNumber: null,
          },
          sdSearchCondition: {
            selectedFromDate: null,
            selectedToDate: null
          },
          isEditingExaminationItems: false,
        });

        this.set('materialGridData', emberA());
        this.set('materialColumns', [
          { field: 'displayCode', title: this.getLanguageResource('7674', 'F', '', '코드'), width: 110},
          { field: 'name', title: this.getLanguageResource('5930', 'F', '', '이름'), width: 120},
          { field: 'equipmentNameList', title: this.getLanguageResource('6513', 'F', '', '장비'), width: 130, bodyTemplateName: 'equipmentsName'},
        ]);
        this.set('lotGridData', emberA());
        this.set('controlMaterialsLotList', []);
        this.set('lotColumns', [
          { field: 'lotNumber', title: this.getLanguageResource('215', 'F', '', 'Lot No.'), width: 110, align: 'center'},
          { field: 'lotType.name', title: this.getLanguageResource('10008', 'F', '', '레벨'), width: 100, align: 'center'},
          { field: 'applyDatetime.startDatetime', title: this.getLanguageResource('4404', 'F', '', '시작일'), width: 130, align: 'center', type: 'date', dataFormat: 'd',},
          { field: 'effectiveDatetime', title: this.getLanguageResource('9932', 'F', '', '유효일자'), width: 130, align: 'center', type: 'date', dataFormat: 'd',},
        ]);
        this.set('examinationGridData', emberA());
        this.set('cumulativePopupData', emberA());
        const sdColumnWidth = 50;
        const cumulativeColumns = [
          { field: 'examination.name', title: this.getLanguageResource('16920', 'F', '', '검사명'), width: 110},
          { field: 'meanSD.meanValue', title: this.getLanguageResource('17026', 'F', '', 'Target Mean'), width: 70, align: 'right'},
          { field: 'meanSD.sdValue', title: 'Target SD', width: 70, align: 'right'},
          { field: 'meanSD.minus3SDValue', title: '-3 SD', width: sdColumnWidth, align: 'right'},
          { field: 'meanSD.minus2SDValue', title: '-2 SD', width: sdColumnWidth, align: 'right'},
          { field: 'meanSD.minus1SDValue', title: '-1 SD', width: sdColumnWidth, align: 'right'},
          { field: 'meanSD.plus1SDValue', title: '1 SD', width: sdColumnWidth, align: 'right'},
          { field: 'meanSD.plus2SDValue', title: '2 SD', width: sdColumnWidth, align: 'right'},
          { field: 'meanSD.plus3SDValue', title: '3 SD', width: sdColumnWidth, align: 'right'},
        ];
        this.set('cumulativePopupColumns', cumulativeColumns);

        this.set('examinationColumns', [
          { field: 'examination.name', title: this.getLanguageResource('16920', 'F', '', '검사명'), width: 110},
          { field: 'meanSD.meanValue', title: this.getLanguageResource('17026', 'F', '', 'Target Mean'), width: 70, bodyTemplateName: 'mean', enableGotFocusAutoSelect: true, type:'number'},
          { field: 'meanSD.sdValue', title: 'Target SD', width: 70, bodyTemplateName: 'cd', enableGotFocusAutoSelect: true, type:'number'},
          { field: 'meanSD.minus3SDValue', title: '-3 SD', width: sdColumnWidth, bodyTemplateName: 'minus3', enableGotFocusAutoSelect: true, type:'number'},
          { field: 'meanSD.minus2SDValue', title: '-2 SD', width: sdColumnWidth, bodyTemplateName: 'mean', enableGotFocusAutoSelect: true, type:'number'},
          { field: 'meanSD.minus1SDValue', title: '-1 SD', width: sdColumnWidth, bodyTemplateName: 'mean', enableGotFocusAutoSelect: true, type:'number'},
          { field: 'meanSD.plus1SDValue', title: '1 SD', width: sdColumnWidth, bodyTemplateName: 'mean', enableGotFocusAutoSelect: true, type:'number'},
          { field: 'meanSD.plus2SDValue', title: '2 SD', width: sdColumnWidth, bodyTemplateName: 'mean', enableGotFocusAutoSelect: true, type:'number'},
          { field: 'meanSD.plus3SDValue', title: '3 SD', width: sdColumnWidth, bodyTemplateName: 'mean', enableGotFocusAutoSelect: true, type:'number'},
          { field: 'cv.lowValue', title: 'CV Low', width: 50, bodyTemplateName: 'mean', enableGotFocusAutoSelect: true, type:'number'},
          { field: 'cv.highValue', title: 'CV High', width: 50, bodyTemplateName: 'mean', enableGotFocusAutoSelect: true, type:'number'},
          { field: 'unitCode', title: this.getLanguageResource('1819', 'F', '', '단위'), width: 50, bodyTemplateName: 'mean', enableGotFocusAutoSelect: true}
        ]);

        this.set('examinationSearchPopupColumns', [
          { field: 'examination.name', title: this.getLanguageResource('16920', 'F', '', '검사명'), width: 110},
          { field: 'meanSD.meanValue', title: this.getLanguageResource('17026', 'F', '', 'Target Mean'), width: 70, align: 'right', enableGotFocusAutoSelect: true, type:'number', allowDecimal: true},
          { field: 'meanSD.sdValue', title: 'Target SD', width: 70, align: 'right', enableGotFocusAutoSelect: true, type:'number', allowDecimal: true},
          { field: 'meanSD.minus3SDValue', title: '-3 SD', width: sdColumnWidth, align: 'right', enableGotFocusAutoSelect: true, type:'number', allowDecimal: true},
          { field: 'meanSD.minus2SDValue', title: '-2 SD', width: sdColumnWidth, align: 'right', enableGotFocusAutoSelect: true, type:'number', allowDecimal: true},
          { field: 'meanSD.minus1SDValue', title: '-1 SD', width: sdColumnWidth, align: 'right', enableGotFocusAutoSelect: true, type:'number', allowDecimal: true},
          { field: 'meanSD.plus1SDValue', title: '1 SD', width: sdColumnWidth, align: 'right', enableGotFocusAutoSelect: true, type:'number', allowDecimal: true},
          { field: 'meanSD.plus2SDValue', title: '2 SD', width: sdColumnWidth, align: 'right', enableGotFocusAutoSelect: true, type:'number', allowDecimal: true},
          { field: 'meanSD.plus3SDValue', title: '3 SD', width: sdColumnWidth, align: 'right', enableGotFocusAutoSelect: true, type:'number', allowDecimal: true},
          { field: 'cv.lowValue', title: 'CV Low', width: 50, align: 'right', enableGotFocusAutoSelect: true, type:'number', allowDecimal: true},
          { field: 'cv.highValue', title: 'CV High', width: 50, align: 'right', enableGotFocusAutoSelect: true, type:'number', allowDecimal: true},
          { field: 'unitCode', title: this.getLanguageResource('1819', 'F', '', '단위'), width: 50, enableGotFocusAutoSelect: true}
        ]);
      }
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1880');
      this.getExaminationRoomList();
      this.getLotTypeCodeList();
    },
    onAudit(){
      const selectedMaterial = this.get('model.selectedMaterialItem');
      console.log('onAudit--', selectedMaterial);
      if(!isEmpty(selectedMaterial)){
        this.set('aggregateKey',selectedMaterial.controlMaterialId);
        this.set('isOpenAuditTrail', true);
      }
    },

    actions: {
      //==================================================================Common Action
      onSearchData() {
        this.getDataList();
      },
      onExaminationRoomChangeByMaterial(e) {
        // console.log('onExaminationRoomChangeByMaterial--', e);
        const selectedItems = e.selectedItems;
        if(!isEmpty(selectedItems)) {
          this.getDataList();
          this._setSettingRoomInfo();
        }
      },
      onPopupOpenedAction() {
        //
      },

      //============================================= materialGrid Anction
      onMetarialGridLoaded(e) {
        this.set('metarialGrid', e.source);
      },
      onMetarialGridScroll(e) {
        this.set('metarialScroll', e.top);
      },
      onGridSelectedAction(e) {
        this.set('isEquipmentEditOpen', false);
        if(!isEmpty(e.selectedItems)) {
          this.set('model.selectedRowItem', e.selectedItems[0]);
        }
      },
      onMaterialGridSelectedAction(e) {
        this.set('isMaterialPopupOpen', false);
        this.set('isLotPopupOpen', false);
        this.set('isExaminationSearchOpen', false);
        this.set('isSdSearchOpen', false);
        this.set('lotGridData', emberA());
        this.set('examinationGridData', emberA());
        const selectedItem = e.selectedItems[0];
        if (selectedItem) {
          // this.set('model.selectedMaterialItem', selectedItem);
          this.getMateriasLotList(selectedItem.controlMaterialId);
        }
      },
      onMaterialsSaveClick() {
        this.set('inputMatarialCode', this.get('model.materialEditItems.displayCode'));
        if (this.get('isUpdatePopup') === true) {
          this._updateMaterial();
        } else {
          this._createMaterial();
        }
      },

      onMaterialGridCellDoubleClick() {
        const selectedMaterialItem = this.get('model.selectedMaterialItem');
        if (selectedMaterialItem) {
          this.setMaterialEditItems(selectedMaterialItem);
          this.set('isMaterialPopupOpen', true);
          this.set('savingScrollPosition', this.get('metarialScroll'));
          this.set('isUpdatePopup', true);
        }
      },

      onMaterialDeleteClick() {
        if(isEmpty(this.get('model.selectedMaterialItem'))) {
          this.showWarningMessage(this.getLanguageResource('9260', 'F', '항목을 선택하세요.'), 2000);
          return;
        } else if(!isEmpty(this.get('lotGridData'))) {
          this.showWarningMessage(this.getLanguageResource('9234', 'F', '', '삭제할 수 없습니다.'), 2000);
          return;
        }
        this._getMaterialDeleteConfirm();
      },

      onMaterialDragEnd(e) {
        this.set('changedMaterialItems', e.source.itemsSource);
      },
      onMaterialDisplaySequenceSave() {
        if (isEmpty(this.get('changedMaterialItems'))) {
          this.showWarningMessage(this.getLanguageResource('10015', 'F', '', '변경 된 순서가 없습니다.'), 2000);
          return;
        }
        this.setDisplaySequence('material', this.get('changedMaterialItems'));
      },

      //===========================================================LotGrid Action
      onLotGridSelectedAction(e) {
        const selectedItem = e.selectedItems[0];
        if (selectedItem) {
          this.set('model.selectedLotItem', selectedItem);
          this.setExaminationsReset();
          this.getLotsExaminationList(selectedItem.lotId);
        } else {
          this.set('model.selectedLotItem', null);

        }
      },

      onLotGridCellDoubleClick() {
        const selectedLotItem = this.get('model.selectedLotItem');
        if (selectedLotItem) {
          this.setLotEditItems(selectedLotItem);
          this.set('isLotPopupOpen', true);
          this.set('isUpdatePopup', true);
        }
      },

      //===========================================================ExaminationGrid Action
      onExaminationGrid(e) {
        this.set('examinationGrid', e.source);
      },

      onExaminationGridSelectedAction(e) {
        const selectedItem = e.selectedItems[0];
        this.set('model.selectedExaminationItem', selectedItem);
      },

      onExaminationSearch() {
        if (this.hasSelectedLotItem()) {
          return;
        }
        this.set('model.selectedExaminationRoomByPopup', this.get('model.selectedExaminationRoom'));
        this.set('isPopupSearch', true);
        this.set('isExaminationSearchOpen', true);
      },

      onExaminationGridEditEnd() {
        // console.log('onExaminationGridEditEnd--', e);
        this.set('model.isEditingExaminationItems', true);

      },
      onSdSearchButtonClick() {
        this.set('model.sdSearchCondition.selectedFromDate', this.get('selectedDate'));
        // const endDate = isEmpty(this.get('model.selectedLotItem.applyDatetime.startDatetime')) ? new Date('9999-12-31 00:00:00') : this.get('model.selectedLotItem.applyDatetime.startDatetime');
        // this.set('model.sdSearchCondition.selectedToDate', endDate);
        this.set('model.sdSearchCondition.selectedToDate', this.get('selectedDate'));
        this.set('isSdSearchOpen', true);
      },
      onSdSearchClick() {
        this.getCumulativeFactor();
      },
      onSdSearchPopupOpenedAction() {
        this.getCumulativeFactor();

      },
      onExaminationGridItemsChanged() {
        // console.log('onExaminationGridItemsChanged--', e);
        // console.log('examinationGridData changed!!', this.get('examinationGridData'));
      },
      onExaminationAddClick() {
        if(this.get('model.selectedLotItem.lotId')) {
          this.set('isCodeSeachOpen', true);
        } else {
          this.showWarningMessage(this.getLanguageResource('9260', 'F', '', 'Lot을 선택해 주세요.'), 2000);
        }
      },

      onExaminationGridSave() {
        if (!this.get('model.isEditingExaminationItems')) {
          this.showWarningMessage(this.getLanguageResource('10014', 'F', null, '수정 된 항목이 없습니다.'), 2000);
          return;
        }
        this._updateLotsItems();
      },
      onExaminationDeleteClick() {
        if(isEmpty(this.get('model.selectedExaminationItem'))) {
          this.showWarningMessage(this.getLanguageResource('9260', 'F', '항목을 선택하세요.'), 2000);
          return;
        }
        this._deleteLotsItems();
      },
      onExaminationDragEnd(e) {
        this.set('changedExaminationItems', e.source.itemsSource);
      },
      onExaminationDisplaySequenceSave() {
        if (this.get('model.isEditingExaminationItems')) {
          this.showWarningMessage(this.getLanguageResource('10277', 'F', null, '저장하지 않은 데이터가 있습니다.'), 2000);
          return;
        }
        if (!this.get('model.isEditingExaminationItems') && isEmpty(this.get('changedExaminationItems'))) {
          this.showWarningMessage(this.getLanguageResource('10015', 'F', '', '변경 된 순서가 없습니다.'), 2000);
          return;
        }
        this.setDisplaySequence('examination', this.get('changedExaminationItems'));
      },
      returnCodeValue(returnItem){
        if(isEmpty(returnItem)){
          return;
        }
        let obj = {};
        obj = {
          examinationId: returnItem.specimenExaminationId,
          examination: {
            id: returnItem.specimenExaminationId,
            name: returnItem.abbreviation
          },
          meanSD: {
            meanValue: null,
            sdValue: null,
            minus3SDValue: null,
            minus2SDValue: null,
            minus1SDValue: null,
            plus1SDValue: null,
            plus2SDValue: null,
            plus3SDValue: null,
          },
          cv: {
            lowValue: null,
            highValue: null
          },
          unitCode: null
        };
        // console.log('returnCodeValue=====', obj);
        const examinationGridItems = this.get('examinationGridData');
        const findedSameObj = examinationGridItems.find(item => item.examination.id === returnItem.specimenExaminationId);
        if (findedSameObj) {
          this.showWarningMessage(this.getLanguageResource('9226', 'F', '이미 추가되어있습니다.'), 2000);
        } else {
          // const unitItem = this.getExaminationsUnitCodeList(returnItem.specimenExaminationId);
          // console.log('-unitItem', unitItem);
          // obj.unitCode = unitItem.code;
          // examinationGridItems.addObject(obj);
          this.getExaminationsUnitCodeList(obj);
          this.set('model.isEditingExaminationItems', true);
          this.set('isExaminationGridEditing', true);
        }

        this.set('isCodeSeachOpen', false);
      },
      onBeforeKeyDown(e) {
        // let targetElementId = '';
        if (e.originalEvent.keyCode === 13) {
          let gridComponent = e.source,
            currentCell = gridComponent.getCurrentCell(),
            itemIndex = gridComponent.getItemIndex(currentCell.item),
            columnIndex = gridComponent.getColumnIndex(currentCell.column);

          // console.log('currentCell---', currentCell);
          if (itemIndex !== -1 && columnIndex !== -1) {
            columnIndex = columnIndex + 1;
            e.cancel = true;
            if (get(gridComponent, 'bindingColumns').length <= columnIndex) {
              // is last column
              itemIndex = itemIndex + 1;
              columnIndex = 0;
            }
            gridComponent.focusCell(itemIndex, columnIndex);
            gridComponent.editCell(itemIndex, columnIndex);
            // this.$(`#${currentCell.cellComponent.elementId}`).select();
            // targetElementId = currentCell.cellComponent.elementId;
            // next(this, function(){
            //   this.$(`#${targetElementId}`).select();
            //   console.log('targetElementId---', targetElementId);
            // });
            // gridComponent.selectCell(itemIndex, columnIndex);
          }
          gridComponent = null;
          currentCell = null;
        }
      },
    },

    async getMateriasLotList(materialId) {
      try {
        this.lotEditItemsReset();
        this.set('contentLoaderType', 'spinner');
        this.set('isLoaderDimed', false);
        this.set('isRefreshDisabled', true);
        this.set('isLotsShowLoader', true);
        const param = {
          controlMaterialId: materialId
        };
        const result = await this.get('qualityManagementService').getControlMateriasLot(param);
        if (!isEmpty(result)) {
          result.forEach(data => {
            data.effectiveDatetime = data.effectiveDatetime.toString() === '9999-12-31 00:00:00' ? null : data.effectiveDatetime;
            data.applyDatetime.endDatetime = data.applyDatetime.endDatetime.toString() === '9999-12-31 00:00:00' ? null : data.applyDatetime.endDatetime;
          });
          this.set('lotGridData', result);
          let targetObj = result[0];
          const targetCode = this.get('inputLotNumber');
          if(!isEmpty(targetCode)) {
            targetObj = result.find(d => d.lotNumber === targetCode);
          }
          this.set('model.selectedLotItem', targetObj);
          // this.getLotsExaminationList(result[0].lotId);
        }
        this.set('isRefreshDisabled', false);
        this.set('isLotsShowLoader', false);
        this.set('inputLotNumber', null);
      } catch(e) {
        this.set('isRefreshDisabled', false);
        this._showError(e);
      }
    },
    async getLotsExaminationList(lotId) {
      try {
        this.set('contentLoaderType', 'spinner');
        this.set('isLoaderDimed', false);
        this.set('isExaminationsShowLoader', true);
        this.set('isRefreshDisabled', true);
        this.set('examinationGridData', emberA());
        if (lotId) {
          const param = {
            lotId: lotId
          };
          const result = await this.get('qualityManagementService').getControlMateriasLotItems(param);
          if (!isEmpty(result)) {
            result.map(item => {
              // item.equipmentNameList = item.applyEquipments[0];
              item.id = item.lotItemId;
            });
            this.set('examinationGridData', result.sortBy('displaySequence'));
            this.set('model.selectedExaminationItem', result[0]);
          }
          this.set('isRefreshDisabled', false);
          this.set('isExaminationsShowLoader', false);
        }
      } catch(e) {
        this.set('isRefreshDisabled', false);
        this._showError(e);
      }
    },

    _gridDataReset() {
      this.set('materialGridData', emberA());
      this.set('lotGridData', emberA());
      this.set('examinationGridData', emberA());
    },

    getDataList() {
      this._gridDataReset();
      if(isEmpty(this.get('model.selectedExaminationRoom'))) {
        return;
      }
      this._getEquipmentList();
      this._getMaterialList();
    },

    async _getMaterialList() {
      try {
        this.set('contentLoaderType', 'spinner');
        this.set('isLoaderDimed', false);
        this.set('isMaterialsShowLoader', true);
        this.set('isRefreshDisabled', true);
        const param = {
          examinationRoomId: this.get('model.selectedExaminationRoom')
        };
        const result = await this.get('qualityManagementService').getControlMaterials(param);
        if (!isEmpty(result)) {
          result.map(item => {
            // item.equipmentNameList = item.applyEquipments[0];
            item.id = item.controlMaterialId;
            let equipmentNameList = null;
            if (item.applyEquipments !== null && item.applyEquipments.length > 0) {
              equipmentNameList = this._pluck(item.applyEquipments, 'name');
              equipmentNameList.pop();
              item.equipmentNameList = equipmentNameList;
            } else {
              item.equipmentNameList = [];
            }
          });
          this.set('materialGridData', result);
          let targetObj = result[0];
          const targetCode = this.get('inputMatarialCode');
          if(!isEmpty(targetCode)) {
            targetObj = result.find(d => d.displayCode === targetCode);
          }
          this.set('model.selectedMaterialItem', targetObj);
          next(() => {
            const metarialScroll = this.get('savingScrollPosition');
            if(!isEmpty(metarialScroll)) {
              this.get('metarialGrid').setScrollTop(metarialScroll);
            }
            // const gridId = this.get('metarialGrid.elementId');
            // const gridRows = $(`#${gridId}`).find('tr');
            // for(let i = 0; gridRows.length > 0; i++) {
            //   if(!isEmpty(gridRows[i])) {
            //     const dataKeys = Object.keys(gridRows[i].dataset);
            //     if(dataKeys.includes('bodyRowSelected')) {
            //       this.get('metarialGrid').setScrollTop(gridRows[i].offsetTop-100);
            //       break;
            //     }
            //   }
            // }
          });
        }
        this.set('isRefreshDisabled', false);
        this.set('isMaterialsShowLoader', false);
        this.set('inputMatarialCode', null);
      } catch(e) {
        this.set('isRefreshDisabled', false);
        this.set('isMaterialsShowLoader', false);
        this._showError(e);
      }
    },

    getExaminationsUnitCodeList(obj) {
      try {
        const examinationsId = obj.examinationId;
        this.get('qualityManagementService').getExaminationsUnits(examinationsId).then(result => {
          const examinationGridItems = this.get('examinationGridData');
          if (!isEmpty(result)) {
            obj.unitCode = result[0].code;
          }
          examinationGridItems.addObject(obj);
          this.get('examinationGrid').selectRow(obj);
        });
      } catch(e) {
        this._showError(e);
      }
    },
    hasSelectedLotItem() {
      const isEmptySelectedLot = isEmpty(this.get('model.selectedLotItem.lotId'));
      if (isEmptySelectedLot) {
        this.showWarningMessage(this.getLanguageResource('9260', 'F', '', 'Lot을 선택해 주세요.'), 2000);
      }
      return isEmptySelectedLot;
    },

  });