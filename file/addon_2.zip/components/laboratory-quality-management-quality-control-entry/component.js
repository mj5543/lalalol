/* eslint-disable max-lines */
/* eslint-disable max-lines-per-function */
/* eslint-disable no-console */
/* eslint-disable chis/require-js-permitted-expression */
import $ from 'jquery';
// import moment from 'moment';
import { A as emberA } from '@ember/array';
import { isEmpty, isPresent } from '@ember/utils';
import { next, later } from '@ember/runloop';
import EmberObject, {set} from '@ember/object';
// import { copy } from '@ember/object/internals';
import layout from './template';
import CHIS from 'framework/chis-framework';
import QualityControlMixin from '../../mixins/quality-control-mixin';
import QualityControlMessageMixin from '../../mixins/quality-control-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  QualityControlMixin,
  QualityControlMessageMixin,
  {
    layout,
    model: null,
    selectedDate: null,
    isEntryPopupOpen: null,
    isOverPopup: null,
    examinationsColumns: null,
    examinationsGridData: null,
    qualityControlGridData: null,
    examinationList: null,
    examinationContext: null,
    popupUseList: null,
    multiGridList: null,
    popupTarget: null,
    tootipTarget: null,
    isUpdatePopup: false,
    singleGridSource: null,
    multiGridSourceList: null,
    sortedExaminations: null,
    recordCount: null,
    recordSize: null,
    blockSize: null,
    currentPage: null,
    pageSource: null,
    examinationsPageData: null,
    pagingGridList: null,
    isEntriComp: true,
    overPopup: null,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'laboratory-quality-management-quality-control-entry');

      this.setStateProperties([
        'model',
        'isEntryPopupOpen',
        'isOverPopup',
        'selectedDate',
        'qualityControlGridData',
        'examinationList',
        'examinationContext',
        'popupUseList',
        'multiGridList',
        'popupTarget',
        'tootipTarget',
        'isUpdatePopup',
        'singleGridSource',
        'multiGridSource',
        'sortedExaminations'
      ]);

      if(this.hasState()===false) {

        this.set('model', {
          selectedExaminationRoom: null,
          selectedExamination: {
            id: null,
            name: null
          },
          selectedExaminationGridItem: null,
          isEntryPopupUpdated: false,
          selectedGridItem: null,
          selectedContextItem: null,
          editItems: {
            editDatetime: null,
            resultValue: null,
            isValidDataRow: null,
            resultComment: null,
          },
          mouseOverData: null,
        });

        const displayDate = new Date(this.get('co_CommonService').getNow());
        this.set('selectedDate', displayDate);
        this.set('examinationsColumns', [
          { field: 'examination.name', title: this.getLanguageResource('16920', 'F', '', '검사항목'), merge: true},
          { field: 'qualityControlDatetime', title: this.getLanguageResource('9691', 'F', '', '시간', ), merge: true, width: 140, align:'center'},
        ]);
        this.set('examinationsGridData', emberA());
        this.set('multiGridSourceList', emberA());
        this.set('recordCount', 1);
        this.set('recordSize', 27);
        this.set('blockSize', 5);
        this.set('currentPage', 1);
        this.set('pageSource', []);

        this.set('isEntryPopupOpen', false);
        this.set('isOverPopup', false);
        this.set('popupUseList', [{value: true, text: 'Y'}, {value: false, text: 'N'}]);

        this.set('examinationContext', emberA([
          EmberObject.create({ action : this.actions.examinationDetailAdd.bind(this), text : this.getLanguageResource('8933', 'F', '', '추가'), disabled : false, display : true, alias:'add'}),
          EmberObject.create({ action : this.actions.examinationDetailUpdate.bind(this), text : this.getLanguageResource('4144', 'F', '', '수정'), disabled : false, display : true, alias:'update'}),
          EmberObject.create({ action : this.actions.examinationDetailDelete.bind(this), text : this.getLanguageResource('3368', 'F', '', '수정'), disabled : false, display : true, alias:'delete'}),
        ]));

        this.set('multiGridList', emberA());

      }
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1880');

      this.getExaminationRoomList();
      this.getQualityControlEntryData();
    },

    actions: {
      onLoadedSingleGridAction(e) {
        this.set('singleGridSource', e.source);
      },
      onLoadedCustomGridAction(e) {
        // this.setAddEvent(e.source);
        this.get('multiGridSourceList').addObject(e.source.id);
        let gridEl = document.getElementById(e.source.id);
        const gridBody = gridEl.getElementsByClassName('c-grid-body-container');
        const gridHead = gridEl.getElementsByClassName('c-grid-head-container');
        $(gridBody).addClass('none');
        $(gridHead).addClass('none');
        const cellLines = gridEl.getElementsByClassName('c-gtd-line');
        for(let l = 0; l < cellLines.length; l++) {
          cellLines[l].style.height = '27px';
          cellLines[l].style.minHeight = '27px';
        }
        this.set(e.source.id, e.source);
        gridEl = null;
      },
      onUnloadCustomGrid() {
        // this.removeEvent(e.source);
      },
      onScrollAction(e) {
        this.scrollChangeEvent(e, true);
      },
      onMultiScrollAction(e) {
        this.scrollChangeEvent(e, false);

      },
      onSearchData() {
        this.getDataList();
      },

      onSelectedExaminationsGridItem(e) {
        const selectedCells = e.selectedCells;
        this.set('model.selectedGridItem', selectedCells[0]);

      },
      onOpenPopupAction() {
        this.set('isEntryPopupOpen', true);
      },
      onPopupOpenedAction() {
        this.get('model.isEntryPopupUpdated', false);
      },
      onOverPopupOpened() {
        // console.log('$(`.c-popup.ui-widget-content`)', $(`.c-popup.ui-widget-content`));
        // const popupContentEl = $(`.c-popup.ui-widget-content`);
        // if(popupContentEl[0].dataset.id === this.get('overPopup.elementId')) {
        //   $(`.c-popup.ui-widget-content`).fadeTo('slow', 1);
        // }
      },
      onOverPopupLoaded(e) {
        this.set('overPopup', e.source);
      },
      onPopupSaveClick() {
        this._controlResultSave();
      },
      onPopupClosedAction() {
        // this.set('model.selectedContextItem', null);
        this.set('model.editItems.editDatetime', null);
        this.set('model.editItems.resultValue', null);
        this.set('model.editItems.isValidDataRow', null);
        this.set('model.editItems.resultComment', null);
        this.set('entryPopupTitle', null);
        // if (this.get('model.isEntryPopupUpdated') === true){
        //   this.getDataList();
        // }
        // this.set('isEntryPopupOpen', false);
        this.set('isUpdatePopup', false);
      },
      examinationDetailAdd(e) {
        const selectedItem = e.dataItem.item;
        this.set('model.selectedContextItem', selectedItem);
        // const dateParam = moment(selectedItem.displayDatetime).format('YYYY-MM-DD');
        let editDatetime = selectedItem.displayDatetime;
        if(!isEmpty(selectedItem.qualityControlResultId)) {
          const dateParam = this.get('fr_I18nService').formatDate(selectedItem.displayDatetime, 'd');
          const updateTime = `${selectedItem.displayDatetime.getHours()}:${selectedItem.displayDatetime.getMinutes()+1}:${selectedItem.displayDatetime.getSeconds()}`;
          editDatetime = new Date(`${dateParam} ${updateTime}`);
        }
        this.set('model.editItems.editDatetime', editDatetime);
        this.set('model.editItems.isValidDataRow', true);
        this.set('entryPopupTitle', `${e.source.columns[0].title} [${this.getLanguageResource('8933', 'F', '', '추가')}]`);
        this.set('isEntryPopupOpen', true);
      },
      examinationDetailUpdate(e) {
        const selectedItem = e.dataItem.item;
        this.set('entryPopupTitle', `${e.source.columns[0].title} [${this.getLanguageResource('4143', 'F', '', '수정')}]`);
        this._setUpdatePopup(selectedItem);

      },
      examinationDetailDelete(e) {
        const selectedItems = e.source.selectedItems;
        let ids = null;
        if(isEmpty(selectedItems)) {
          ids = [e.dataItem.item.qualityControlResultId];
        } else {
          ids = selectedItems.mapBy('qualityControlResultId');
        }
        this.showConfirmDelete().then((res) => {
          if(res === 'Yes') {
            this._controlResultDelete(ids);
          }
        });

      },
      onMultiGridCellDoubleClick(e) {
        this.set('entryPopupTitle', `${e.source.columns[0].title} [${this.getLanguageResource('4143', 'F', '', '수정')}]`);
        this._setUpdatePopup(e.item);
        this.set('popupTarget', `#${e.source.elementId}`);
      },
      onContextMenuOpen(e) {
        const contextItem = e.dataItem.item;
        if (isEmpty(contextItem)) {
          set(e, 'cancel', true);
          return;
        }
        this.set('isOverPopup', false);
        set(this.get('examinationContext').findBy('alias', 'delete'), 'disabled', false);
        const selectedItems = e.source.selectedItems;
        if(selectedItems.length > 1) {
          set(this.get('examinationContext').findBy('alias', 'add'), 'disabled', true);
          set(this.get('examinationContext').findBy('alias', 'update'), 'disabled', true);
          return;
        }
        set(this.get('examinationContext').findBy('alias', 'add'), 'disabled', false);
        set(this.get('examinationContext').findBy('alias', 'update'), 'disabled', false);
        if(contextItem.qualityControlResultId === null) {
          set(this.get('examinationContext').findBy('alias', 'update'), 'disabled', true);
          set(this.get('examinationContext').findBy('alias', 'delete'), 'disabled', true);
        }
        this.set('popupTarget', `#${e.source.elementId}`);
      },
      onDateChangedAction() {
        this.getDataList();
      },

      onPageChanged(e) {
        this.set('isShowLoader', true);
        const multiGridSourceList = this.get('multiGridSourceList');
        if(!isEmpty(multiGridSourceList)) {
          multiGridSourceList.forEach(id => {
            let gridEl = document.getElementById(id);
            const gridBody = gridEl.getElementsByClassName('c-grid-body-container');
            $(gridBody).addClass('none');
            gridEl = null;
          });
        }
        this._onPageChanged(e.page);
        this._gridStyleSetting();
      },
      onRangeCellOver(item) {
        event.preventDefault();
        event.stopPropagation();
        // this.set('tootipTarget', event.target);
        // this.set('model.mouseOverData', item);
        // this.set('isOverPopup', true);

        // later(() => {
        //   const popupContentEl = $(`.c-popup.ui-widget-content`);
        //   if(!isEmpty(popupContentEl) && popupContentEl[0].dataset.id === this.get('overPopup.elementId')) {
        //     popupContentEl.fadeTo('slow', 1);
        //   }
        // });
        this.set('model.mouseOverData', item);
        const targetRect = event.target.getBoundingClientRect();
        const x = (targetRect.left - 2) + 'px';
        const y = (targetRect.top + event.target.offsetHeight + 5) + 'px';
        let tooltipElement = document.querySelector('.dynamic-grid-tooltip');
        tooltipElement.style.top = y;
        tooltipElement.style.left = x;
        tooltipElement.classList.add('show');
        tooltipElement = null;
      },
      onRangeCellOut() {
        event.preventDefault();
        event.stopPropagation();
        // this.set('isOverPopup', false);
        // const popupContentEl = $(`.dynamic-grid-tooltip`);
        // popupContentEl.removeClass('show');
        // popupContentEl.fadeTo('fast', 0);
        let tooltipElement = document.querySelector('.dynamic-grid-tooltip');
        tooltipElement.classList.remove('show');
        tooltipElement = null;
        this.set('model.mouseOverData', null);
      },
    },

    _gridStyleSetting() {
      next(() => {
        const multiGridSourceList = this.get('multiGridSourceList');
        if(!isEmpty(multiGridSourceList)) {
          multiGridSourceList.forEach(id => {
            const gridSource = this.get(id);
            let gridEl = document.getElementById(id);
            const gridBody = gridEl.getElementsByClassName('c-grid-body-container');
            const gridHead = gridEl.getElementsByClassName('c-grid-head-container');
            const cellLines = gridEl.getElementsByClassName('c-gtd-line');
            for(let l = 0; l < cellLines.length; l++) {
              cellLines[l].style.height = '27px';
              cellLines[l].style.minHeight = '27px';
            }
            const tableRows = $(`#${gridSource.elementId}`).find('.c-gtr');
            gridSource.itemsSource.forEach((item, ind) => {
              if(isEmpty(item.qualityControlResultId)) {
                $(tableRows[ind]).css({
                  'background-color': '#fff',
                  'background-image': 'linear-gradient(45deg, #f5f5f5, #f5f5f5 25%, transparent 25%, transparent 50%, #f5f5f5 50%, #f5f5f5 75%, transparent 75%, transparent)',
                  'background-size' : '10px 10px'
                });
              }
            });
            $(gridBody).removeClass('none');
            $(gridHead).removeClass('none');
            gridEl = null;
          });
        }
        later(() => {
          this.set('isShowLoader', false);
        });
      });
    },

    _onPageChanged(currentPage) {
      // this.set('pagingGridList', emberA());
      const tmp = this.getPageSource(this.get('examinationsGridData'), currentPage);
      const multiGridList = this.get('multiGridList');
      const pagingGridList = this.get('pagingGridList');
      if(isEmpty(pagingGridList)) {
        const pagingList = [];
        multiGridList.forEach(grid => {
          const gridItems = grid.itemsSource;
          const filterItem = this.getPageSource(gridItems, currentPage);
          pagingList.addObject({
            pageSource: filterItem,
            column: grid.column,
            itemsSource: grid.itemsSource,
            targetId: grid.targetId,
            className: grid.className,
          });
        });
        this.set('pagingGridList', pagingList);
      } else {
        multiGridList.forEach(grid => {
          const gridItems = grid.itemsSource;
          const filterItem = this.getPageSource(gridItems, currentPage);
          pagingGridList.forEach(datas => {
            if(grid.targetId === datas.targetId) {
              set(datas, 'pageSource', filterItem);
            }
          });
        });
      }
      this.set('examinationsPageData', tmp);
    },

    getPageSource(datas, currentPage) {
      const startAt = (currentPage - 1) * this.get('recordSize');
      const endAt = startAt + (this.get('recordSize') - 1);
      const returnItems = datas.filter(item => {
        const condition = item.rowNum >= startAt && item.rowNum <= endAt;
        return condition;
      });
      return returnItems;
    },

    scrollChangeEvent(e, isSingle){
      const multiGridList = this.get('multiGridSourceList');
      if (multiGridList.length > 0) {
        multiGridList.forEach(id => {
          if(!isSingle) {
            this.get('singleGridSource').setScrollTop(e.top);
          }
          if (e.source.id !== id) {
            this.get(id).setScrollTop(e.top);
          }
        });
      }

    },

    setAddEvent (grid) {
      const targetGridId = grid.id;
      let targetEl = document.getElementById(targetGridId);
      if (targetEl) {
        targetEl.addEventListener('mouseover', this._mouseoverEvent);
        targetEl.addEventListener('mouseout', this._mouseoutEvent);
      }
      targetEl = null;
    },

    removeEvent(grid) {
      const targetGridId = grid.id;
      let targetEl = document.getElementById(targetGridId);
      if(targetEl) {
        targetEl.removeEventListener('mouseover', this._mouseoverEvent);
        targetEl.removeEventListener('mouseout', this._mouseoutEvent);
        // targetEl.parentNode.removeChild(targetEl);
      }
      targetEl = null;
    },

    _mouseoverEvent() {
      const evt = event;
      const cellPath = evt.path.find(d => d.tagName === 'TD');
      const rowPath = evt.path.find(d => d.tagName === 'TR');
      if(isEmpty(cellPath)) {
        this.set('isOverPopup', false);
        this.set('tootipTarget', null);
        return;
      }
      // const origintarget = `#${cellPath.id}`;
      // const currentTarget = this.get('tootipTarget');
      // if (origintarget === currentTarget) {
      //   return;
      // }
      const popupContentEl = $(`.c-popup.ui-widget-content`);
      if(!isEmpty(popupContentEl) && popupContentEl[0].dataset.id === this.get('overPopup.elementId')) {
        popupContentEl.fadeIn('slow');
      }
      // this.set('isOverPopup', false);
      if (cellPath.cellIndex === 2 && !this.get('isEntryPopupOpen')) {
        const rowData = this.get(evt.currentTarget.id).getItem(rowPath.rowIndex);
        if (rowData && rowData.qualityControlResultId && rowData.qualityControlResultId !== null) {
          this.set('tootipTarget', `#${cellPath.id}`);
          this.set('model.mouseOverData', rowData);
          this.set('isOverPopup', true);
        } else {
          this.set('isOverPopup', false);
          this.set('tootipTarget', null);
          this.set('model.mouseOverData', null);
        }
      } else {
        this.set('isOverPopup', false);
        this.set('tootipTarget', null);
        this.set('model.mouseOverData', null);
      }
    },
    _mouseoutEvent() {
      const evt = event;
      const cellPath = evt.path.find(d => d.tagName === 'TD');
      if(!isEmpty(cellPath)) {
        const origintarget = `#${cellPath.id}`;
        const currentTarget = this.get('tootipTarget');
        if (origintarget === currentTarget) {
          return;
        }
      }
      // $(`.c-popup.ui-widget-content`).fadeOut('slow');
      this.set('isOverPopup', false);
      this.set('model.mouseOverData', null);
    },

    _gridDataReset() {
      this.set('multiGridSourceList', emberA());
      this.set('examinationsGridData', emberA());
      this.set('multiGridList', emberA());
      this.set('pagingGridList', emberA());
      this.set('examinationsPageData', emberA());
      this.set('pageSource', []);
      this.set('recordCount', 1);
      this.set('currentPage', 1);
    },

    async _controlResultSave() {
      try {
        this.set('isEntryPopupOpen', false);
        this.set('contentLoaderType', 'progress');
        this.set('loaderDimed', true);
        this.set('isShowLoader', true);
        let promise = null;
        const changedItem = this.get('model.editItems');
        const isUpdatePopup = this.get('isUpdatePopup');
        const path = `${this.get('qualityManagementService').urlPrefix}/quality-control-results`;
        const saveParams = this._getSaveParams(changedItem, isUpdatePopup);
        if (isUpdatePopup) {
          promise = this.update(path, null, false, saveParams, false);
        } else {
          promise = this.create(path, null, saveParams, false);
        }
        await promise;
        this._callSuccess();
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowLoader', false);
        }
        this._showSaveError(e);
        console.log('_controlResultSave Error:::', e);
      }
    },
    async _controlResultDelete(ids) {
      try {
        this.set('contentLoaderType', 'progress');
        this.set('loaderDimed', true);
        this.set('isShowLoader', true);
        const path = `${this.get('qualityManagementService').urlPrefix}/quality-control-results`;
        await this.delete(path, null, {qualityControlResultIds: ids}, false);
        this._callSuccess();
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowLoader', false);
        }
        this._showSaveError(e);
        console.log('_controlResultSave Error:::', e);
      }
    },

    _callSuccess() {
      this.set('model.isEntryPopupUpdated', true);
      this.showToastSaved();
      this.getDataList();
    },

    _getSaveParams(changedItem, isUpdate) {
      let params = null;
      if(isUpdate) {
        params = {
          qualityControlResults: [
            {
              qualityControlResultId: this.get('model.selectedContextItem.qualityControlResultId'),
              qualityControlDatetime: changedItem.editDatetime.toString(),
              specimenNumber: this.get('model.selectedContextItem.specimenNumber'),
              displaySequence: 0,
              examinationId: this.get('model.selectedContextItem.examination.id'),
              resultValue: changedItem.resultValue,
              resultValueContent: this.get('model.selectedContextItem.resultValueContent'),
              resultComment: changedItem.resultComment,
              performDatetime: changedItem.editDatetime.toString(),
              isValidDataRow: changedItem.isValidDataRow
            }
          ]
        };
      } else {
        params = {
          qualityControlResults: [
            {
              equipmentId: this.get('model.selectedContextItem.equipment.id'),
              lotId: this.get('model.selectedContextItem.lot.id'),
              qualityControlDatetime: changedItem.editDatetime.toString(),
              specimenNumber: this.get('model.selectedContextItem.specimenNumber'),
              resultValueContent: null,
              examinationId: this.get('model.selectedContextItem.examination.id'),
              resultValue: changedItem.resultValue,
              resultComment: changedItem.resultComment,
              performDatetime: changedItem.editDatetime.toString(),
              isValidDataRow: changedItem.isValidDataRow
            }
          ]
        };
      }
      return params;
    },

    getDataList() {
      this.set('contentLoaderType', 'spinner');
      this.set('loaderDimed', false);
      this.set('isShowLoader', true);
      this._gridDataReset();
      this.getQualityControlEntryData();
    },

    async getQualityControlEntryData() {
      try {
        this.set('pagingGridList', emberA());
        const selectedExaminationId = this.get('model.selectedExaminationId') === 'All' ? null : this.get('model.selectedExaminationId');
        const paramFromDate = new Date(this.get('selectedDate').getFullYear(), this.get('selectedDate').getMonth(), this.get('selectedDate').getDate(), 0, 0, 0).toFormatString();
        const paramToDate = new Date(this.get('selectedDate').getFullYear(), this.get('selectedDate').getMonth(), this.get('selectedDate').getDate(), 0, 0, 0).toFormatString();
        const params = {
          qualityControlFindTypeCode: "Daily",
          isGroupQuery: true,
          isValidDataRow: false,
          lotId: this.get('model.selectedControlMaterialsLotId'),
          equipmentId: this.get('model.selectedEquipmentId'),
          fromDatetime: paramFromDate,
          toDatetime: paramToDate,
          examinationIds: selectedExaminationId
        };
        const result = await this.get('qualityManagementService').getQualityControlResultsSearch(params);
        if (!isEmpty(result)) {
          // this.set('examinationsGridData', result.sortBy('examination.id'));
          this.set('examinationsGridData', result.sortBy('displaySequence'));
          const grouped = this.groupBy(result, item => item.lot.lotType.code);
          this.parseGridData(grouped);
        }
        this._gridStyleSetting();
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowLoader', false);
        }
        this._showError(e);
        console.log('getQualityControlEntryData Error::::', e);
      }

    },

    parseGridData(grouped) {
      const groupGridItems = [];
      const uniqLotItems = this.get('examinationsGridData').uniqBy('lot.lotType.code');
      uniqLotItems.forEach((item) => {
        groupGridItems.push(grouped.get(item.lot.lotType.code));
      });
      const examinationsList = this.get('examinationsGridData');
      const groupGridCnt = groupGridItems.length;

      const groupGridDatas = [];

      groupGridItems.forEach((group, index) => {
        const groupsGUID = this._getGUID();
        const gridIndexData = `lotGroupGrid${index}Data`;
        const gridIndexColumn = `lotGroup${index}Columns`;
        const tempArr = [];
        const dateMergeGridData = [];
        examinationsList.forEach((items) => {
          let tempObj = {};
          const targetItem = group.find(d => d.qualityControlResultId === items.qualityControlResultId);
          if (targetItem) {
            tempArr.push(items);
          } else {
            tempObj = Object.assign(tempObj, items);
            tempObj.qualityControlResultId = null;
            tempObj.lot = group[0].lot;
            tempObj.resultComment = null;
            tempObj.resultValue = '';
            tempObj.rules = [];
            tempObj.targetMeanSD = {minus2SDValue: null};
            tempObj.displayUseText = null;
            tempArr.push(tempObj);
          }
        });
        const ruleColorList = this._getRulesColor();
        tempArr.map(item => {
          let compareResult = null;
          let ruleNameList = null;
          if (item.resultValue !== '') {
            compareResult = 'normal';
            if (item.resultValue && item.targetMeanSD.minus2SDValue > item.resultValue) {
              compareResult = 'minus';
            } else if (item.resultValue && item.targetMeanSD.plus2SDValue < item.resultValue) {
              compareResult = 'plus';
            }
            if (!isEmpty(item.rules)) {
              ruleNameList = item.rules.mapBy('name');
              ruleNameList = ruleNameList.join(', ');
              item.rules.map(rule => {
                rule.color = ruleColorList[rule.code];
                if(isEmpty(rule.color)) {
                  rule.color = '#6F0F79';
                }
              });
            }
            item.displayUseText = item.isValidDataRow === true ? 'Y' : 'N';
          }
          item.compareResult = compareResult;
          item.ruleNameList = ruleNameList;
          item.gridIndex = index;
          item.displayDatetime = new Date(item.qualityControlDatetime);
          item.qualityControlDatetime = item.qualityControlDatetime.toString();
          return item;
        });
        const uniqExamination = tempArr.uniqBy('examination.id');
        const examinationGroup = this.groupBy(tempArr, item => item.examination.id);
        const examinationGroupList = [];
        uniqExamination.forEach(item => {
          examinationGroupList.push(examinationGroup.get(item.examination.id));
        });
        examinationGroupList.forEach(item => {
          const uniqDateList = item.uniqBy('qualityControlDatetime');
          const tempGroup = this.groupBy(item, d => d.qualityControlDatetime);
          const tempgroupList = [];
          uniqDateList.forEach(data => {
            tempgroupList.push(tempGroup.get(data.qualityControlDatetime));
          });
          tempgroupList.forEach(temp => {
            const hasResultIdObj = temp.find(d => d.qualityControlResultId !== null);
            if (temp.length > 1){
              if (!hasResultIdObj) {
                dateMergeGridData.push(temp[0]);
              } else {
                temp.forEach(child => {
                  if (child.qualityControlResultId !== null) {
                    dateMergeGridData.push(child);
                  }
                });
              }
            } else {
              dateMergeGridData.push(temp[0]);
            }

          });
        });

        const columnTitle = `${group[0].controlMaterial.name} ${group[0].lot.lotType.name} (${group[0].lot.lotNumber})`;
        const gridColumns = this._setGridColumns(ruleColorList);
        const addRowNumData = dateMergeGridData.map((data, ind) => {
          data.rowNum = ind;
          return data;
        });

        this.set(gridIndexColumn, [{title: columnTitle, columns: gridColumns}]);
        this.set(gridIndexData, addRowNumData);
        let gridClassName = 'mr-10';
        if (groupGridCnt === (index + 1)) {
          gridClassName = '';
        }
        this.get('multiGridList').addObject({
          column: [{title: columnTitle, columns: gridColumns}],
          itemsSource: addRowNumData,
          // targetId: `lotGroupGrid${index}`,
          targetId: groupsGUID,
          className: gridClassName
        });
        groupGridDatas.push(addRowNumData);
      });
      this.set('recordCount', groupGridDatas[0].length);
      this.set('examinationsGridData', groupGridDatas[0]);
      //#f2f2f2 #f5f5f5
      this._onPageChanged(this.get('currentPage'));
    },

    _setGridColumns(ruleColors) {
      return [
        { field: 'resultValue', title: this.getLanguageResource('17028', 'F', '', '결과'), align: 'center',
          onBodyCellRender: function (context) {
            const cellItem = context.item;
            if(isPresent(cellItem) && isPresent(cellItem.rules)) {
              let colorRuleCode = cellItem.rules[0].code;
              const rulecodeList = cellItem.rules.map(d => d.code);
              if(cellItem.rules.length > 1) {
                if(rulecodeList.includes('11S')){
                  colorRuleCode = '11S';
                }
                if(rulecodeList.includes('12S')){
                  colorRuleCode = '12S';
                }
                if(rulecodeList.includes('13S')){
                  colorRuleCode = '13S';
                }
                if(rulecodeList.includes('10X')) {
                  colorRuleCode = '10X';
                }
                if(rulecodeList.includes('R4S')) {
                  colorRuleCode = 'R4S';
                }
                if(rulecodeList.includes('41S')) {
                  colorRuleCode = '41S';
                }
                if(rulecodeList.includes('22S2')) {
                  colorRuleCode = '22S2';
                }
                if(rulecodeList.includes('22S')) {
                  colorRuleCode = '22S';
                }
              }
              let cellColor = ruleColors[colorRuleCode];
              if(isEmpty(cellColor)) {
                cellColor = '#6F0F79';
              }
              context.cellComponent.$().css('color', cellColor);
              context.cellComponent.$().css('font-weight', 'bold');
            }
            // switch(cellItem.compareResult) {
            //   case 'plus':
            //     context.cellComponent.$().css('color', '#f1260b');
            //     context.cellComponent.$().css('font-weight', 'bold');
            //     break;
            //   case 'minus':
            //     context.cellComponent.$().css('color', '#004df3');
            //     context.cellComponent.$().css('font-weight', 'bold');
            //     break;
            //   default:
            //     break;
            // }
          },
        },
        // { field: 'compareResult', title: this.getLanguageResource('1579', 'F', '', '참고'), align: 'center', width: 50,
        { field: 'compareResult', title: this.getLanguageResource('17029', 'F', '', '참고(2SD)'), align: 'center', width: 110, bodyTemplateName: 'compareRange'
          // onBodyCellRender: function (context) {
          //   const cellItem = context.item;
          //   let innerHtml = '';
          //   if (cellItem.targetMeanSD.minus2SDValue) {
          //     innerHtml = `${cellItem.targetMeanSD.minus2SDValue} ~ ${cellItem.targetMeanSD.plus2SDValue}`;
          //   }
          //   // switch(cellItem.compareResult) {
          //   //   case 'plus':
          //   //     innerHtml = '<span class="icon-arr-up upcolor01"></span>';
          //   //     break;
          //   //   case 'minus':
          //   //     innerHtml = '<span class="icon-arr-down downcolor01"></span>';
          //   //     break;
          //   //   default:
          //   //     innerHtml = '';
          //   //     break;
          //   // }
          //   context.cellComponent.$().html(innerHtml);
          // },
        },
        { field: 'displayUseText', title: this.getLanguageResource('3287', 'F', '', '사용'), align: 'center', width: 50, bodyTemplateName: 'useYNIcon'},
        { field: 'ruleNameList', title: 'Rules', bodyTemplateName: 'ruleIcons'},
        { field: 'resultComment', title: this.getLanguageResource('17117', 'F', '', '비고'), width: 50, bodyTemplateName: 'comments', align: 'center'},
      ];
    },
    _setUpdatePopup(selectedItem) {
      if (selectedItem.qualityControlResultId === null) {
        const message = this.getLanguageResource('10014', 'F', '', '수정 할 데이터가 없습니다.');
        this.showToastWarning(message);
        return;
      }
      this.set('isUpdatePopup', true);
      this.set('model.selectedContextItem', selectedItem);
      this.set('model.editItems.editDatetime', selectedItem.displayDatetime);
      this.set('model.editItems.resultValue', selectedItem.resultValue);
      this.set('model.editItems.isValidDataRow', selectedItem.isValidDataRow);
      this.set('model.editItems.resultComment', selectedItem.resultComment);
      this.set('isEntryPopupOpen', true);
    }

  });