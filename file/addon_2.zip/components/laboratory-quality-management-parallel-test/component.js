/* eslint-disable no-console */
import { isEmpty } from '@ember/utils';
import { A as emberA } from '@ember/array';
import layout from './template';
import CHIS from 'framework/chis-framework';
import QualityControlMixin from '../../mixins/quality-control-mixin';
import QualityControlMessageMixin from '../../mixins/quality-control-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(
  QualityControlMixin,
  QualityControlMessageMixin,
  {
    layout,
    model: null,
    isShowLoader: false,
    paramEmployeeId: null,
    resultItem: null,
    isPopupOpen: false,
    isShowModifyContent: false,
    parallelTestItem: null,
    popupOpenMode: null,
    isReadOnlyRefresh: false,
    popupTitle: null,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'laboratory-quality-management-parallel-test');

      this.setStateProperties([
        'isDisabled',
        'isCollapsible',
        'selectedName',
        'isReadOnly',
        'gridColumns',
        'gridItemsSource'
      ]);
      if (!this.hasState()) {
        this.set('model', {
          selectedGridItem: null,
        });

        this.set('gridColumns', [
          { field: 'parallelTestDatetime', title: this.getLanguageResource('16890', 'F', '', '검사일'), align: 'center', type: 'date', dataFormat: 'd',},
          { field: 'examination.name', title: this.getLanguageResource('16920', 'F', '', '검사항목'), bodyTemplateName: 'examinationName'},
          { field: 'registrationStaff.entryStaff.name', title: this.getLanguageResource('17033', 'F', '', '작성자'), align: 'center'},
        ]);
        this.set('gridItemsSource', emberA());
      }
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1360');
      this.getExaminationRoomList();
    },
    actions: {
      onExaminationRoomChanged(e) {
        const selectedItems = e.selectedItems;
        this._gridDataReset();
        if(!isEmpty(selectedItems)) {
          this.getDataList();
          this._setSettingRoomInfo();
        }
      },
      onSearchData() {
        this._gridDataReset();
        this.getDataList();
      },
      onGridLoaded(e) {
        this.set('gridSource', e.source);
      },
      onGridSelectionChanged(e) {
        // this.set('isPopupOpen', false);
        this.set('isShowModifyContent', false);
        this.set('parallelTestItem', null);
        const selectedItem = e.selectedItems[0];
        if(!isEmpty(selectedItem)) {
          this.set('parallelTestItem', selectedItem);
          this.set('isShowModifyContent', true);
        }
        this.set('isReadOnlyRefresh', true);
      },
      onGridCellDoubleClick(info) {
        this.set('popupOpenMode', 'Modify');
        this.set('popupTitle', `Parallel Test ${this.getLanguageResource('4143', 'F', '', '수정')}`);
        this.set('parallelTestItem', info.item);
        this.set('isReadOnlyRefresh', false);
        this.set('isPopupOpen', true);
      },
      onExpandComplete() {
        //
      },
      onCollapseComplete() {
        this.set('parallelTestItem', null);
      },
      onDeleteClick() {
        if(isEmpty(this.get('model.selectedGridItem'))) {
          return;
        }
        this._getDeleteConfirm();
      },
      onAddClick() {
        // this.set('parallelTestItem', null);
        this.get('gridSource').deselectAll();
        this.set('popupOpenMode', 'Insert');
        this.set('popupTitle', `Parallel Test ${this.getLanguageResource('10000', 'F', '', '등록')}`);
        this.set('isPopupOpen', true);
      },
      onSavedRegistration(mode) {
        this.set('isReadOnlyRefresh', false);
        this.set('isPopupOpen', false);
        if(mode === 'Insert') {
          this.getDataList();
        } else {
          this.set('isReadOnlyRefresh', true);
        }
      },
    },

    getDataList() {
      this.set('isReadOnlyRefresh', false);
      this._getParallelTest();
    },

    _gridDataReset() {
      this.set('isReadOnlyRefresh', false);
      this.set('gridItemsSource', emberA());
    },

    async _getParallelTest() {
      try {
        this.set('gridItemsSource', emberA());
        this.set('isShowLoader', true);
        const param = {
          examinationRoomId: this.get('model.selectedExaminationRoom'),
          parallelTestDatetime: this.get('selectedDate')
        };
        const result = await this.get('qualityManagementService').getParallelTest(param);
        this.set('gridItemsSource', result);
        this.set('model.selectedGridItem', result[0]);
        this.set('isShowLoader', false);
      } catch(e) {
        if(this.isDestroyed || this.isDestroying) {
          return;
        }
        console.log('_getConditionList Error::: ', e);
        this.set('isShowLoader', false);
        this._showError(e);
      }
    },

    async _getDeleteConfirm() {
      const result = await this.showConfirmDelete();
      if (result === 'Yes') {
        this._deleteParallelTest();
      }
    },

    async _deleteParallelTest() {
      try {
        const param = {parallelTestId: this.get('model.selectedGridItem.id')};
        await this.get('qualityManagementService').deleteParallelTest(param);
        await this._getParallelTest();
        this.showToastDeleted();
      } catch(e) {
        this.showToastDeleteFail();
      }
    },

  });