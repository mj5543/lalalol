import CHIS from 'framework/chis-framework';
import config from '../app-config';
import { inject as service } from '@ember/service';

export default CHIS.FR.Core.ServiceBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, {

  defaultUrl: null,
  businessUrl: null,
  toast: service('toast-service'),

  init() {
    this._super(...arguments);

    const basicUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', 'patientexamination') +
      `patient-examination/${config.version}`;
    const defaultUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', 'patientexamination') +
      `patient-examination/${config.version}/side-effects`;
    const businessUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', 'patientexamination') +
      `patient-examination/${config.version}/businesscodes`;
    this.set('basicUrl', basicUrl);
    this.set('defaultUrl', defaultUrl);
    this.set('businessUrl', businessUrl);
  },

  onShowToast(type, content, title) {
    this.get('toast').toastr({
      type: type,
      content: content,
      title: title,
      option: {
        closeButton: false,
        timeOut: 3000,
        positionClass: 'toast-bottom-center'
      }});
  },

  onDisplayMessage(type, caption, message, btype, focus, interval) {
    const options = {
      'caption': caption,
      'messageBoxButton': btype,
      'messageBoxImage': type,
      'messageBoxText': message,
      'messageBoxFocus': focus,
      'messageboxInterval': interval
    };

    messageBox.show(this, options);
  },

  getContrast(planId) {
    return this.getList(`${this.get('defaultUrl')}/${planId}/contrast`, null, null);
  },

  getSymptom() {
    return this.getList(`${this.get('defaultUrl')}/symptom`, null, null);
  },
  getDrug(params) {
    return this.getList(`${this.get('defaultUrl')}/drug`, params, null);
  },
  getDosage() {
    return this.getList(`${this.get('defaultUrl')}/dosage`, null, null);
  },
  getUnits() {
    return this.getList(`${this.get('defaultUrl')}/unit`, null, null);
  },
  createContrast(params){
    return this.create(`${this.get('defaultUrl')}/contrast`, null, params);
  },

  deleteContrast(params) {
    return this.delete(`${this.get('defaultUrl')}/contrast`, null, params);
  },

  getSedation(planId) {
    return this.getList(`${this.get('defaultUrl')}/${planId}/sedation`, null, null);
  },

  createSedation(params){
    return this.create(`${this.get('defaultUrl')}/sedation`, null, params);
  },

  deleteSedation(params) {
    return this.delete(`${this.get('defaultUrl')}/sedation`, null, params);
  },

  getSedationAll(params) {
    return this.getList(`${this.get('defaultUrl')}/sedation`, params, null);
  },

  getContrastAll(params) {
    return this.getList(`${this.get('defaultUrl')}/contrast`, params, null);
  },

  getBusinessCode(code) {
    const param = {classificationCode: code};
    return this.getList(`${this.get('businessUrl')}`, param, null);
  },

});