import CHIS from 'framework/chis-framework';
import config from '../app-config';
import { inject as service } from '@ember/service';

export default CHIS.FR.Core.ServiceBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, {

  defaultUrl: null,
  businessUrl: null,
  angiographyUrl: null,
  toast: service('toast-service'),

  init() {
    this._super(...arguments);

    const basicUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', 'patientexamination') +
      `patient-examination/${config.version}`;
    const angiographyUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', 'patientexamination') +
      `patient-examination/${config.version}/angiographies`;
    const defaultUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', 'patientexamination') +
      `patient-examination/${config.version}/angiography-plans`;
    const businessUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', 'patientexamination') +
      `patient-examination/${config.version}/businesscodes`;
    this.set('basicUrl', basicUrl);
    this.set('angiographyUrl', angiographyUrl);
    this.set('defaultUrl', defaultUrl);
    this.set('businessUrl', businessUrl);
  },

  onShowToast(type, content, title) {
    this.get('toast').toastr({
      type: type,
      content: content,
      title: title,
      option: {
        closeButton: false,
        timeOut: 3000,
        positionClass: 'toast-bottom-center'
      }});
  },

  onDisplayMessage(type, caption, message, btype, focus, interval) {
    const options = {
      'caption': caption,
      'messageBoxButton': btype,
      'messageBoxImage': type,
      'messageBoxText': message,
      'messageBoxFocus': focus,
      'messageboxInterval': interval
    };

    messageBox.show(this, options);
  },

  showConfirm(caption, messageBoxText){
    const options = {
      'caption': caption,
      'messageBoxButton': 'YesNo',
      'messageBoxImage': 'question',
      'messageBoxText': messageBoxText,
      'messageBoxFocus': 'No'
    };
    return messageBox.show(this, options);
  },

  getAngiographiesPart(param) {
    return this.getList(`${this.get('angiographyUrl')}`, param, null);
  },
  getAngiographiesCount(params) {
    return this.getList(`${this.get('defaultUrl')}/count`, params, null);
  },
  getAngiographiesDailyStatus(param) {
    return this.getList(`${this.get('defaultUrl')}/daily-status`, param, null);
  },
  getAngiographiesSearch(params) {
    return this.getList(`${this.get('defaultUrl')}/search`, params, null);
  },
  getAngiographiesByPatient(params) {
    return this.getList(`${this.get('defaultUrl')}/by-patient`, params, null);
  },
  getAngiographiesByWard(params) {
    return this.getList(`${this.get('defaultUrl')}/by-ward`, params, null);
  },
  getAngiographiesPatientDiagnosis(param) {
    return this.getList(`${this.get('defaultUrl')}/patient-diagnosis`, param, null);
  },
  getCurrentEncounter(param) {
    return this.getList(`${this.get('defaultUrl')}/current-encounter`, param, null);
  },
  createAngiographies(params){
    return this.create(this.get('defaultUrl'), null, params);
  },
  updateAngiographies(params){
    return this.update(this.get('defaultUrl'), null, false, params, false);
  },
  updateAngiographiesCancle(param){
    return this.update(`${this.get('defaultUrl')}/cancel`, null, false, param, false);
  },
  updateAngiographiesTreatment(params){
    return this.update(`${this.get('defaultUrl')}/treatment`, null, false, params, false);
  },
  updateAngiographiesAddProcedure(params){
    return this.update(`${this.get('defaultUrl')}/add-procedure`, null, false, params, false);
  },
  updateAngiographiesProgress(params){
    return this.update(`${this.get('defaultUrl')}/progress`, null, false, params, false);
  },
  updateAngiographiesUndo(params){
    return this.update(`${this.get('defaultUrl')}/undo`, null, false, params, false);
  },
  updateAngiographiesChangeRoom(params){
    return this.update(`${this.get('defaultUrl')}/change-room`, null, false, params, false);
  },
  updateAngiographiesTreatement(params){
    return this.update(`${this.get('defaultUrl')}/treatment`, null, false, params, false);
  },
  updateAngiographiesChangeSorting(params){
    return this.update(`${this.get('defaultUrl')}/change-sorting`, null, false, params, false);
  },
  getBusinessCode(param) {
    return this.getList(`${this.get('businessUrl')}`, param, null);
  },
  getPatientInfomation(param) {
    return this.getList(`${this.get('basicUrl')}/patients`, param, null);
  },
  getDepartment(param) {
    return this.getList(`${this.get('basicUrl')}/checkins/department`, param, null);
  },
  updateAngiographiesPrepare(param){
    return this.update(`${this.get('defaultUrl')}/prepare`, null, false, param, false);
  },
  updateAngiographiesComment(param){
    return this.update(`${this.get('defaultUrl')}/comment`, null, false, param, false);
  },
  createAngiographiesPart(params) {
    return this.create(`${this.get('angiographyUrl')}/part`, null, params, false);
  },
  updateAngiographiesPartSorting(params) {
    return this.update(`${this.get('angiographyUrl')}/part-change-sorting`, null, false, params, false);
  },
  deleteAngiographiesPart(param) {
    return this.delete(`${this.get('angiographyUrl')}/part`, null, param, false);
  },
  createAngiographiesProcedure(params) {
    return this.create(`${this.get('angiographyUrl')}/procedure`, null, params, false);
  },
  updateAngiographiesProcedureSorting(params) {
    return this.update(`${this.get('angiographyUrl')}/procedure-change-sorting`, null, false, params, false);
  },
  deleteAngiographiesProcedure(param) {
    return this.delete(`${this.get('angiographyUrl')}/procedure`, null, param, false);
  },
  createAngiographiesSubProcedureSet(params) {
    return this.create(`${this.get('angiographyUrl')}/sub-procedure-set`, null, params, false);
  },
  updateAngiographiesSubProcedureSetSorting(params) {
    return this.update(`${this.get('angiographyUrl')}/sub-procedure-set-change-sorting`, null, false, params, false);
  },
  deleteAngiographiesSubProcedureSet(param) {
    return this.delete(`${this.get('angiographyUrl')}/sub-procedure-set`, null, param, false);
  },
  getAngiographiesSubProcedure(param) {
    return this.getList(`${this.get('angiographyUrl')}/sub-procedure`, param, null);
  },
  createAngiographiesSubProcedure(params) {
    return this.create(`${this.get('angiographyUrl')}/sub-procedure`, null, params, false);
  },
  deleteAngiographiesSubProcedure(param) {
    return this.delete(`${this.get('angiographyUrl')}/sub-procedure`, null, param, false);
  },

});