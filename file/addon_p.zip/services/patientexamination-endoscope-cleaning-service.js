import CHIS from 'framework/chis-framework';
import config from '../app-config';

export default CHIS.FR.Core.ServiceBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, {

  defaultUrl: null,
  businessUrl: null,

  init() {
    this._super(...arguments);

    const basicUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', 'patientexamination') +
      `patient-examination/${config.version}`;
    const defaultUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', 'patientexamination') +
      `patient-examination/${config.version}/endoscope-cleanings`;
    const attributetUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', 'patientexamination') +
      `patient-examination/${config.version}/endoscope-cleaning-attributes`;
    const businessUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', 'patientexamination') +
      `patient-examination/${config.version}/businesscodes`;
    this.set('basicUrl', basicUrl);
    this.set('defaultUrl', defaultUrl);
    this.set('attributetUrl', attributetUrl);
    this.set('businessUrl', businessUrl);
  },

  showConfirm(caption, messageBoxText){
    const options = {
      'caption': caption,
      'messageBoxButton': 'YesNo',
      'messageBoxImage': 'question',
      'messageBoxText': messageBoxText,
      'messageBoxFocus': 'No'
    };
    return messageBox.show(this, options);
  },

  getEndoscopeCleaning(params) {
    return this.getList(`${this.get('defaultUrl')}`, params, null);
  },

  createEndoscopeCleaning(params){
    return this.create(`${this.get('defaultUrl')}`, null, params);
  },
  updateEndoscopeCleaning(params){
    return this.update(`${this.get('defaultUrl')}`, null, false, params, false);
  },

  deleteEndoscopeCleaning(params) {
    return this.delete(`${this.get('defaultUrl')}`, null, params);
  },

  getEndoscopeCleaningExaminationRoom(params) {
    return this.getList(`${this.get('defaultUrl')}/examination-room`, params, null);
  },

  getEndoscopeCleaningAttribute(code) {
    const param = {typeCode: code};
    return this.getList(`${this.get('attributetUrl')}`, param, null);
  },
  createEndoscopeCleaningAttribute(params){
    return this.create(`${this.get('attributetUrl')}`, null, params);
  },
  updateEndoscopeCleaningAttribute(params){
    return this.update(`${this.get('attributetUrl')}`, null, false, params, false);
  },

  deleteEndoscopeCleaningAttribute(params) {
    return this.delete(`${this.get('attributetUrl')}`, null, params);
  },

  updateEndoscopeCleaningAttributeDefaultSetting(params){
    return this.update(`${this.get('attributetUrl')}/default-setting`, null, false, params, false);
  },
  updateEndoscopeCleaningAttributeChangeSorting(params){
    return this.update(`${this.get('attributetUrl')}/change-sorting`, null, false, params, false);
  },
  getBusinessCode(code) {
    const param = {classificationCode: code};
    return this.getList(`${this.get('businessUrl')}`, param, null);
  },

  onShowToast(type, content, title) {
    this.get('toast').toastr({
      type: type,
      content: content,
      title: title,
      option: {
        closeButton: false,
        timeOut: 3000,
        positionClass: 'toast-bottom-center'
      }});
  },
});