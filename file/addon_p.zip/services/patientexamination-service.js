import EmberObject, { get } from '@ember/object';
import { A as emberA } from '@ember/array';
import { isEmpty, isPresent } from '@ember/utils';
import { Promise } from 'rsvp';
import CHIS from 'framework/chis-framework';
import config from '../app-config';
import { inject as service } from '@ember/service';

export default CHIS.FR.Core.ServiceBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, {

  checkinUrl: null,
  conductUrl: null,
  defaultUrl: null,
  toast: service('toast-service'),
  coPersonalizationService: service('personalization-service'),

  init() {
    this._super(...arguments);

    const checkinUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', 'patientexamination') +
      `patient-examination/${config.version}/checkins`;

    const conductUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', 'patientexamination') +
      `patient-examination/${config.version}/conductions`;

    const defaultUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', 'patientexamination') +
      `patient-examination/${config.version}/`;

    this.set('checkinUrl', checkinUrl);
    this.set('conductUrl', conductUrl);
    this.set('defaultUrl', defaultUrl);
  },

  //속성저장
  async setPeSettingInfo(settingKey, settingData, description){
    const result =
      await this.get('coPersonalizationService').setSettingInfo(settingKey, JSON.stringify(settingData), description);
    return result;
  },

  //속성조회
  async getPeSettingInfo(settingKey) {
    const result = await this.get('coPersonalizationService').getSettingInfo(settingKey);
    if(!isEmpty(result.settingValue)) {
      const settingValue = JSON.parse(result.settingValue);
      if(!isEmpty(settingValue.conditionData)) {
        return settingValue.conditionData;
      }else{
        return null;
      }
    }else{
      return null;
    }
  },

  //공통코드 조회
  onGetBusinessCodeList(classificationCode, code){
    const promise = new Promise((resolve, reject) => {
      try{

        const path = this.get('defaultUrl') + 'businesscodes';
        const queryParams={
          classificationCode : classificationCode,
          displayCode : code
        };
        const result = this.getList(path, queryParams, null);

        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },
  getBusinessCodesClassification(param){
    const promise = new Promise((resolve, reject) => {
      try{

        const path = this.get('defaultUrl') + 'businesscodes/classification';
        const queryParams={
          classificationCodes: param.classificationCodes,
          isUsed : param.isUsed
        };
        const result = this.getList(path, queryParams, null);

        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  //부서 그룹 조회
  onGetDepartmentGroupList(params){
    const promise = new Promise((resolve, reject) => {
      try{

        const path = this.get('checkinUrl') + '/department';
        const result = this.getList(path, params, null);

        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  //검사 그룹 조회 - 사용안함
  onGetExaminationGroupList(){
    const promise = new Promise((resolve, reject) => {
      try{

        const path = this.get('defaultUrl') + 'examinations/group';
        const result = this.getList(path, null, null);

        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  getMyRoomInfo(employeeId, examinationGroupCode, isRepresentative){

    const promise = new Promise((resolve, reject) => {
      try {
        if(isEmpty(employeeId)){
          reject(false);
          return;
        }
        const path = this.get('defaultUrl') + 'examinations/my-room';
        const query = {
          employeeId : employeeId,
          examinationGroupCode : examinationGroupCode,
          isRepresentative: isRepresentative
        };
        const result = this.getList(path, query, null);

        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  getRoomList(employeeId, examinationGroupCode){

    const promise = new Promise((resolve, reject) => {
      try {
        if(isEmpty(employeeId)){
          reject(false);
          return;
        }
        const path = this.get('defaultUrl') + 'examinations/rooms';
        const query = {
          employeeId : employeeId,
          examinationGroupCode : examinationGroupCode
        };
        const result = this.getList(path, query, null);

        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  onGetAppointmentList(item){
    const promise = new Promise((resolve, reject) => {
      try{
        if(isEmpty(item)){
          reject(false);
          return;
        }
        const path = this.get('checkinUrl') + '/appointment-plan';
        //examinationRoomCode: item.examinationRoomCode,
        const query = {
          addAccept: item.addAccept,
          fromDate: new Date(item.fromDate.getFullYear(), item.fromDate.getMonth(), item.fromDate.getDate(), 0, 0, 0).toFormatString(),
          toDate: new Date(item.toDate.getFullYear(), item.toDate.getMonth(), item.toDate.getDate(), 0, 0, 0).toFormatString(),
          personalSet: item.personalSet,
          employeeId: item.employeeId,
          examinationRoomId: item.examinationRoomId,
          examinationGroupCode: item.examinationGroupCode,
          scheduleTypeCode: item.scheduleTypeCode,
          isPayment: item.isPayment,
          isPortable: item.isPortable,
          patientType: item.patientType,
          issuedDoctorId: item.issuedDoctorId,
          issuedDepartmentIds: item.issuedDepartmentIds,
          examinationIds: item.examinationIds
        };
        const result = this.getList(path, query, null);

        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  onGetAcceptList(item){
    const promise = new Promise((resolve, reject) => {
      try{
        if(isEmpty(item)){
          reject(false);
          return;
        }
        const path = this.get('checkinUrl') + '/brief-accpet-plan';

        const query = {
          patientType: item.patientType,
          acceptDate: new Date(item.selectedDate.getFullYear(), item.selectedDate.getMonth(), item.selectedDate.getDate(), 0, 0, 0).toFormatString(),
          examinationRoomId: item.examinationRoomId,
          isAll: item.isAllStatus,
          performDoctorId: item.performDoctorId,
          issuedDepartmentIds: item.issuedDepartmentIds
        };

        const issuedDepartmentIds = query.issuedDepartmentIds;
        if(isPresent(issuedDepartmentIds)){
          query.issuedDepartmentIds = issuedDepartmentIds.join('&issuedDepartmentIds=');
        }
        const result = this.getList(path, query, null);

        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  onGetAcceptListPaging(item){
    const promise = new Promise((resolve, reject) => {
      try{
        if(isEmpty(item)){
          reject(false);
          return;
        }
        const path = this.get('checkinUrl') + '/accpet-plan-paging';

        const query = {
          patientType: item.patientType,
          fromDate: new Date(item.fromDate.getFullYear(), item.fromDate.getMonth(), item.fromDate.getDate(), 0, 0, 0).toFormatString(),
          toDate: new Date(item.toDate.getFullYear(), item.toDate.getMonth(), item.toDate.getDate(), 0, 0, 0).toFormatString(),
          examinationRoomId: item.examinationRoomId,
          examinationGroupCode: item.examinationGroupCode,
          isAll: item.isAllStatus,
          performDoctorId: item.performDoctorId,
          issuedDepartmentIds: item.issuedDepartmentIds,
          patientId: item.patientId,
          sortingType: item.sortingType,
          skipIndex: item.dataPage,
          takeCount: item.takeCount,
        };

        const issuedDepartmentIds = query.issuedDepartmentIds;
        if(isPresent(issuedDepartmentIds)){
          query.issuedDepartmentIds = issuedDepartmentIds.join('&issuedDepartmentIds=');
        }
        const result = this.getList(path, query, null, true);

        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  onGetAcceptCount(item){
    const promise = new Promise((resolve, reject) => {
      try{
        if(isEmpty(item)){
          reject(false);
          return;
        }
        const path = this.get('checkinUrl') + '/accpet-plan-count';

        const query = {
          patientType: item.patientType,
          fromDate: new Date(item.fromDate.getFullYear(), item.fromDate.getMonth(), item.fromDate.getDate(), 0, 0, 0).toFormatString(),
          toDate: new Date(item.toDate.getFullYear(), item.toDate.getMonth(), item.toDate.getDate(), 0, 0, 0).toFormatString(),
          examinationRoomId: item.examinationRoomId,
          examinationGroupCode: item.examinationGroupCode,
          patientId: item.patientId,
          isAll: item.isAllStatus,
          performDoctorId: item.performDoctorId,
          issuedDepartmentIds: item.issuedDepartmentIds,
        };

        const issuedDepartmentIds = query.issuedDepartmentIds;
        if(isPresent(issuedDepartmentIds)){
          query.issuedDepartmentIds = issuedDepartmentIds.join('&issuedDepartmentIds=');
        }
        const result = this.getList(path, query, null, true);

        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  onGetRoomStatus(item){
    if(isEmpty(item)){
      return;
    }
    if(isEmpty(item.examinationGroupCode)){
      return;
    }
    let defaultUrl = null;
    if(item.selectedType == "Conduction"){
      defaultUrl = '/accpet-status';
    }else{
      defaultUrl = '/appointment-status';
    }
    const path = this.get('checkinUrl') + defaultUrl;
    const query = {
      personalSet: !item.isAllRoomChecked,
      examinationGroupCode: item.examinationGroupCode,
      fromDate: new Date(item.fromDate.getFullYear(), item.fromDate.getMonth(), item.fromDate.getDate(), 0, 0, 0).toFormatString(),
      toDate: new Date(item.toDate.getFullYear(), item.toDate.getMonth(), item.toDate.getDate(), 0, 0, 0).toFormatString(),
      employeeId: item.employeeId,
      addStatus: item.addStatus
    };
    return this.getList(path, query, null);
  },

  onShowToast(type, content, title) {
    this.get('toast').toastr({
      type: type,
      content: content,
      title: title,
      option: {
        closeButton: false,
        timeOut: 3000,
        positionClass: 'toast-bottom-center'
      }});
  },

  onDisplayMessage(type, caption, message, btype, focus, interval) {
    const options = {
      'caption': caption,
      'messageBoxButton': btype,
      'messageBoxImage': type,
      'messageBoxText': message,
      'messageBoxFocus': focus,
      'messageboxInterval': interval
    };

    messageBox.show(this, options);
  },

  onCheckinOpen(item){
    if(isEmpty(item)){
      this.get('co_MenuManagerService').openMenu('patient-examination-checkin');
    }else{
      //{"examinationGroupCode": "DR"}
      this.get('co_MenuManagerService').openMenu('patient-examination-checkin_radiology');
    }
  },

  onExecuteOpen(item){
    if(isEmpty(item)){
      return;
    }
    const parameters = {
      patientType: item.patientType,
      acceptDate: item.selectedDate,
      patientId : item.patientId,
      waitingRoomCode: item.waitingRoomCode,
      isChecked: item.isAllStatus,
      performRoomCode: item.examinationRoomCode,
      examinationGroupCode: item.examinationGroupCode
    };
    let viewId = '';
    if(isEmpty(item.examinationGroupCode)){
      viewId = 'patient-examination-conducting';
    }else{
      viewId = 'patient-examination-conducting_radiology';
    }
    this.get('co_MenuManagerService').openMenu(viewId, parameters);
    this.get('co_ContentMessageService').sendMessage('messageCondution', parameters);
  },

  saveInformation(itemlist){

    const promise = new Promise((resolve, reject) => {
      try{
        const path = this.get('checkinUrl');

        this.update(path, null, false, itemlist, true).then(function (res) {
          if(res.response == true){
            resolve(true);
          }
        });
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  onGetIssuedMaterial(orderId){
    if(isEmpty(orderId)){
      return null;
    }

    const promise = new Promise((resolve, reject) => {
      try{
        const path = this.get('conductUrl') + '/material/';
        const param = {
          procedureRequestId: orderId
        };
        const result = this.getList(path, param, null);

        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  onGetStatusColor(statusCode){
    let color = '';
    if (statusCode == 1) {
      color = '#0056cc';
    }else if (statusCode == 2) {
      color = '#df4db1';
    }else if (statusCode == 3) {
      color = '#00b104';
    }else if (statusCode == 4) {
      color = '#008fb3';
    }else if (statusCode == 5) {
      color = '#f67400';
    }else if (statusCode == 6) {
      color = '#a41ad2';
    }else if (statusCode == 7) {
      color = '#f71616';
    }else{
      color = '';
    }
    return color;
  },

  onPatintGlobalSet(path, patientId, encounterId){
    if(isEmpty(patientId)){
      return;
    }
    if(path === "Encounter"){
      if(isEmpty(encounterId)){
        return;
      }
    }
    const globalItem = {
      patientGlobalPathType: path,
      patientChoicePath: path,
      patientId: patientId,
      encounterId: encounterId
    };
    this.get('co_PatientManagerService').selectPatient(globalItem);
  },

  getValidationEncounter(encounterId) {
    return this.getList(this.get('defaultUrl') + 'patients/encounter/' + encounterId + '/validation', null, null);
  },
  createBusinessCodesClassification(params){
    const path = this.get('defaultUrl') + 'businesscodes/classification';
    return this.create(path, null, params);
  },
  updateBusinessCodesClassification(params){
    const path = this.get('defaultUrl') + 'businesscodes/classification';
    return this.update(path, null, false, params, false);
  },
  createBusinessCode(params){
    const path = this.get('defaultUrl') + 'businesscodes';
    return this.create(path, null, params);
  },
  updateBusinessCode(params){
    const path = this.get('defaultUrl') + 'businesscodes';
    return this.update(path, null, false, params, false);
  },
  getBusinessCodes(params) {
    const path = this.get('defaultUrl') + 'businesscodes';
    return this.getList(path, params, null);

  },
  updateBusinessCodeSorting(params){
    const path = this.get('defaultUrl') + 'businesscodes/sorting';
    return this.update(path, null, false, params, false);
  },
  //검사접수(접수, 워크리스트)
  onCheckin(registerInfo){
    const promise = new Promise((resolve, reject) => {
      try{
        const path = this.get('checkinUrl');
        const result = this.create(path, null, registerInfo);
        resolve(result);
      }catch(e){
        reject(e);
      }
    });
    return promise;
  },

  //검사접수취소(접수, 워크리스트)
  onCheckinUndo(cancelInfo){

    const promise = new Promise((resolve, reject) => {
      try{
        const path = this.get('checkinUrl');
        const result = this.delete(path, null, cancelInfo);

        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  //검사시행
  onPerform(performInfo){
    const promise = new Promise((resolve, reject) => {
      try{
        const path = this.get('checkinUrl');
        const result = this.update(path, null, false, performInfo, true);
        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  //검사시행취소 (접수상태로)
  onPerformUndo(undoPerformInfo){
    const promise = new Promise((resolve, reject) => {
      try{
        const path = this.get('conductUrl') + '/undo-conduct';
        const result = this.update(path, null, false, undoPerformInfo, false);
        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  //검사취소
  onPerformCacnel(CancelInfo){
    const promise = new Promise((resolve, reject) => {
      try{
        const path = this.get('conductUrl') + '/cancel';
        const result = this.update(path, null, false, CancelInfo, true);
        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  //영상재료 접수시행
  onImageProgress(imageInfo){
    const promise = new Promise((resolve, reject) => {
      try{
        const path = this.get('defaultUrl') + 'image-materials';
        const result = this.create(path, null, imageInfo);
        resolve(result);
      }catch(e){
        reject(e);
      }
    });
    return promise;
  },

  //동의서 작성 취소여부
  onCheckConsent(consentInfo){

    const promise = new Promise((resolve, reject) => {
      try{
        const path = this.get('defaultUrl') + 'patients/electronic-consent';
        const result = this.create(path, null, consentInfo);
        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  //IV여부
  onCheckInjection(injectionInfo){

    const promise = new Promise((resolve, reject) => {
      try{
        const path = this.get('conductUrl') + '/injection';
        const result = this.update(path, null, false, injectionInfo, true);
        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  onGetSpecimenReport(param){
    const promise = new Promise((resolve, reject) => {
      try{

        const path = this.get('defaultUrl') + 'diagnostic-reports/specimen-report';
        const result = this.getList(path, param, null);

        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  getPacsLinkAddress(items){
    const promise = new Promise((resolve, reject) => {
      try{
        const path = this.get('defaultUrl') + 'conductions/pacs-link';
        const result = this.getList(path, items, null);
        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  //라벨출력
  onPrintNameCard(){
  },

  getExportByArrayTypeExcel(initial, itemList, content) {
    if(isEmpty(itemList)){
      return;
    }
    /* global XLSX */
    const exportItemsWS = XLSX.utils.aoa_to_sheet(initial);
    XLSX.utils.sheet_add_aoa(exportItemsWS, itemList, {cellDates: true, dateNF: 'YYYY-MM-DD HH:mm', origin: "A2"});
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, exportItemsWS, 'sheet1');
    const fileName = content + '_' + new Date(this.get('co_CommonService').getNow());
    XLSX.writeFile(wb, `${fileName}_.xlsx`);
    //this.auditExcelExport('onExcel', content, exportItemsWS);
  },

  getBodyMeasurement(params) {
    return this.getList(`${this.get('defaultUrl')}patients/body-measurement`, params, null);
  },

  onGetRegistration(params){

    const promise = new Promise((resolve, reject) => {
      try{
        const path = this.get('checkinUrl') + '/registration';
        const result = this.getList(path, params, null);

        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  getInboxParams(item, resource){
    const params = emberA({
      patient: { id: item.patientId, displayCode: item.patientCode, name: item.patientName},
      examination: {name: item.examinationName,
        issuedDate: this.get('fr_I18nService').formatDate(item.issuedDate, 'd')},
      encounter:{ id:item.encounterId},
      staffs: [{actorTypeName: resource,
        actorId:item.issuedDoctorId,
        actorName: item.issuedDoctorName}]
    });
    return params;
  },

  async _getPrinterSettingInfo(item){
    let category = 'Radiology';
    if(!isEmpty(category)){
      category = item;
    }
    var result = await this.get('co_PersonalizationService').getPersonalPrinterSetting(category, 'print');

    if(!isEmpty(result.get('firstObject'))) {
      const settingValue = JSON.parse(get(result.get('firstObject'), 'settingValue'));
      this.set('settingValue', settingValue);
      if(!isEmpty(settingValue)) {
        if(!isEmpty(settingValue.defaultLabelPrinter)){
          this.set('labelPrinter', settingValue.defaultLabelPrinter);
        }
        if(!isEmpty(settingValue.item)){
          this.set('printSettings', settingValue.item);
        }
      }
    }
  },

  //직원정보조회
  getEmployeeOccupation(employeeId){
    const promise = new Promise((resolve, reject) => {
      try{
        const path = this.get('checkinUrl') + '/employee-information';
        const param = {
          employeeId : employeeId
        };
        const result = this.getList(path, param, null);

        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  getActorList(params){
    const promise = new Promise((resolve, reject) => {
      try{
        const path = this.get('defaultUrl') + 'examinations/actors';
        const result = this.getList(path, params, null);

        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  getCurrentEncounter(params) {
    const promise = new Promise((resolve, reject) => {
      try{
        const path = this.get('defaultUrl') +'patients/current-encounter';
        const result = this.getList(path, params, null);

        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  //관계별 직원조회
  onGetExaminationEmployeeList(params){
    const promise = new Promise((resolve, reject) => {
      try{

        const path = this.get('defaultUrl') + 'examinations/employee';
        const result = this.getList(path, params, null);

        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  //검사그룹별 접수가능 검사실
  onGetAcceptableRoomList(params){
    const promise = new Promise((resolve, reject) => {
      try{

        const path = this.get('defaultUrl') + 'examinations/acceptable-room';
        const result = this.getList(path, params, null);

        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  onGetExaminationList(param){
    const promise = new Promise((resolve, reject) => {
      try{

        const path = this.get('defaultUrl') + 'examinations';
        const result = this.getList(path, param, null);

        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  onGetOrderDatailInfo(param){
    const promise = new Promise((resolve, reject) => {
      try{

        const path = this.get('conductUrl');
        const result = this.getList(path, param, null);

        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },

  //처방상태 검사의 검사실변경
  changeExaminationRoom(param){
    const promise = new Promise((resolve, reject) => {
      try{
        const path = this.get('checkinUrl') + '/change-ckeckin-examination-room';

        this.update(path, null, false, param, true).then(function (res) {
          if(res.response == true){
            resolve(true);
          }
        });
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },
  cpacsUsed() {
    const promise = new Promise((resolve, reject) => {
      try{
        const path = this.get('conductUrl') + '/regions/hospital-attribute';
        const items = {businessCode: 'CPACS USE YN'};
        const result = this.getList(path, items, null);
        resolve(result);
      } catch(e) {
        reject(e);
      }
    });
    return promise;
  },
});