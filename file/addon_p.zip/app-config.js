//configuration for biz
export default {
  config1 : "config value1",
  version: 'v0',
  examinationCategory: 'Id1'
};