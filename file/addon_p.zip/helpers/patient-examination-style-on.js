import { helper as buildHelper } from '@ember/component/helper';
import { isEmpty } from '@ember/utils';

export function patientExaminationStyleOn([roomItem, selectedRoom]) {
  if(isEmpty(roomItem)){
    return null;
  }
  if(isEmpty(selectedRoom)){
    return null;
  }
  return selectedRoom === roomItem ? 'on' : '';
}

export default buildHelper(patientExaminationStyleOn);

