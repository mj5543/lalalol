import { helper as buildHelper } from '@ember/component/helper';

export function patientExaminationStyleClose([type]) {
  return type ? 'close' : '';
}

export default buildHelper(patientExaminationStyleClose);


