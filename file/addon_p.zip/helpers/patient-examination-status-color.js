
import { helper as buildHelper } from '@ember/component/helper';

export function patientExaminationStatusColor([status]) {
  if (status == 1){
    return "font-weight:bold;color:#000000;user-select: none;font-size:14px";
  }else if(status == 2){
    return "font-weight:bold;color:#ff00b1;user-select: none;font-size:14px";
  }else if(status == 3){
    return "font-weight:bold;color:#119a00;user-select: none;font-size:14px";
  }else if(status == 4){
    return "font-weight:bold;color:#ff0000;user-select: none;font-size:14px";
  }else if(status == 5){
    return "font-weight:bold;color:#f67400;user-select: none;font-size:14px";
  }else if(status == 6){
    return "font-weight:bold;color:#bf00ff;user-select: none;font-size:14px";
  }else if(status == 7){
    return "font-weight:bold;color:#0070cc;user-select: none;font-size:14px";
  }else{
    return null;
  }
}

export default buildHelper(patientExaminationStatusColor);