import { next } from '@ember/runloop';
import { A as emberA } from '@ember/array';
import { isEmpty, isPresent } from '@ember/utils';
import EmberObject, { get, set } from '@ember/object';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'patientexamination-module/app-config';
import PtMixin from '../../../mixins/patient-examination-mixin';
import { inject as service } from '@ember/service';
import MessageMixin from '../../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, PtMixin, MessageMixin,
  {
    layout,
    isExpanded : false,
    defaultUrl : null,
    conditionSet : null,
    appointmentPatient: null,
    acceptPatient: null,
    examinationRoomStatusData: null,
    performRoom: null,
    examinationGroupCode: null,
    isPageLoader: false,
    print: null,
    isConsentPopupOpen: false,
    userGlobalInformation: null,
    contextMenu: null,
    acceptableRooms: null,
    acceptableRoomsSet: null,
    selectedExamList: null,
    appointmentGrid: null,
    isLabelPageOpen: false,
    nameLabelPage: null,
    peApiService:service('patientexamination-service'),

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'patient-examination-worklist');

      this.setStateProperties([
        'conditionSet',
        'defaultUrl',
        'examinationRoomStatusData',
        'performRoom',
        'model',
        'isPageLoader',
        'examinationGroupCode',
        'isConsentPopupOpen',
        'userGlobalInformation',
        'acceptableRooms',
        'acceptableRoomsSet',
        'contextMenu',
        'selectedExamList',
        'appointmentGrid',
        'isLabelPageOpen',
        'nameLabelPage',
        'print',]);

      if(this.hasState()===false) {
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'patientexamination') + `patient-examination/${config.version}/`);
        this.set('print', EmberObject.create({printPopup: null, printConfig: null, printContent: null}));
        this._getColumnHeader();
        this.set('appointmentPatient.selectedItem', EmberObject.create());
        this.set('isScheduleTypeItems', [{value:'S', text: this.getLanguageResource('5083', 'S', '예약')},
          {value:'N', text:this.getLanguageResource('11749', 'S', '비예약')}]);
        this.set('sortingItems', [{value:'Time', text:this.getLanguageResource('16804', 'S', '예약시간')},
          {value:'Patient', text:this.getLanguageResource('9101', 'S', '환자')}]);

        this.set('selectedExamList', []);
        this.set('isLabelPageOpen', false);
      }

    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'wp100');

      if(!isEmpty(this.get('co_CurrentUserService.user'))){
        this.set('userGlobalInformation', this.get('co_CurrentUserService.user'));
        set(this.get('conditionSet'), 'employeeId', this.get('userGlobalInformation.employeeId'));
      }

      const msgChRoom = this.getLanguageResource('748', 'S', '검사실변경');
      const msgCopy = this.getLanguageResource('12603', 'S', 'AccessNo.복사');
      const msgRsv = this.getLanguageResource('687', 'S', '검사예약');
      const msgSetRoom = this.getLanguageResource('12605', 'S', '검사실지정');

      this.set('contextMenu', emberA([
        EmberObject.create({ text: msgChRoom, disabled: true, display: true}),
        EmberObject.create({ action : this.actions.onCopyAccessNo.bind(this), text: msgCopy, disabled: true, display: true}),
        EmberObject.create({ action : this.actions.onAppointmentLink.bind(this), text: msgRsv, disabled: true, display: true}),
        EmberObject.create({ text: msgSetRoom, disabled: true, display: true}),
      ]));

      this.reSchedulingWarningMessage();
    },

    actions: {
      onLoadGrid(e){
        this.set('appointmentGrid', e.source);
      },

      onPatientTypeChanged(item){
        if(!isEmpty(this.get('onPatientChangedCB'))){
          this.get('onPatientChangedCB')(item);
        }
      },

      onVisibleClick() {
        if(this.get('isSettingVisible')){
          if(!isEmpty(this.get('selectedExamList'))){
            const msg = this.getLanguageResource('12604', 'F', '선택된 검사를 초기화 하시겠습니까?');
            const confirmMsg = this.getLanguageResource('확인', 'F', '확인');
            const options = {'messageBoxImage': 'question', 'caption': confirmMsg, 'messageBoxText': msg,
              'messageBoxButton': 'OKCancel', 'messageBoxFocus' : 'Ok', 'messageboxInterval' : 0};
            messageBox.show(this, options).then((rbutton) => {
              if(rbutton === "Ok"){
                this._onExaminationClear();
                this.set('isSettingVisible', false );
              }else{
                this.set('isSettingVisible', false );
              }
            });
          }else{
            this.set('isSettingVisible', false );
          }
        }else{
          this.set('isSettingVisible', true);
        }
      },

      onRoomClear(){
        if(!isEmpty(this.get('roomClearCB'))){
          this.get('roomClearCB')();
        }
      },

      onDeletedExamClick(item){
        if(isEmpty(item)){
          return;
        }
        this.get('selectedExamList').removeObject(item);
      },

      onCheckinRoomChanged(item){
        if(isEmpty(this.get('conditionSetCB'))){
          this.get('conditionSetCB')(item);
        }
        this._onGetAppointmentList();
      },

      onGetAppointmentList(){
        this._onGetAppointmentList();
      },

      onSelectionPatient(e){
        this.get('onSelectionPatientCB')(e);
      },

      onCheckchanged(){
        this.set('appointmentPatient.isCheckAll', false);
      },

      onAppointmentLink(e){
        if(isEmpty(e.dataItem.item)){
          return;
        }
        this.set('appointmentInfo', e.dataItem.item);
        this.set('isAppointmentPopupOpen', true);
      },

      onCopyAccessNo(e){
        if(isEmpty(e.dataItem.item) || isEmpty(e.dataItem.item.examinationConducts.accessNumber)){
          return;
        }
        this._copyItem(e.dataItem.item.examinationConducts.accessNumber);
      },

      onDisabledSetting(e){
        const msgChRoom = this.getLanguageResource('748', 'S', '검사실변경');
        const msgCopy = this.getLanguageResource('12603', 'S', 'AccessNo.복사');
        const msgRsv = this.getLanguageResource('687', 'S', '검사예약');
        const msgSetRoom = this.getLanguageResource('12605', 'S', '검사실지정');

        if(isEmpty(e.dataItem.item) || isEmpty(e.dataItem.item.isScheduling) || isEmpty(e.dataItem.item.statusCode)){
          set(this.get('contextMenu').findBy('text', msgChRoom), 'disabled', true);
          set(this.get('contextMenu').findBy('text', msgChRoom), 'children', null);
          set(this.get('contextMenu').findBy('text', msgRsv), 'disabled', true);
          set(this.get('contextMenu').findBy('text', msgCopy), 'disabled', true);
          set(this.get('contextMenu').findBy('text', msgSetRoom), 'disabled', true);
          set(this.get('contextMenu').findBy('text', msgSetRoom), 'children', null);
          return false;
        }

        if(e.dataItem.item.isScheduling && e.dataItem.item.statusCode == 1){
          set(this.get('contextMenu').findBy('text', msgRsv), 'disabled', false);
        }else{
          set(this.get('contextMenu').findBy('text', msgRsv), 'disabled', true);
        }
        if(isEmpty(e.dataItem.item.examinationConducts.accessNumber)){
          set(this.get('contextMenu').findBy('text', msgCopy), 'disabled', true);
        }else{
          set(this.get('contextMenu').findBy('text', msgCopy), 'disabled', false);
        }
        if(!isEmpty(this.get('acceptableRooms')) && this.get('acceptableRooms').length > 1){
          set(this.get('contextMenu').findBy('text', msgChRoom), 'children', this.get('acceptableRooms'));
          set(this.get('contextMenu').findBy('text', msgChRoom), 'disabled', false);

          set(this.get('contextMenu').findBy('text', msgSetRoom), 'children', this.get('acceptableRoomsSet'));
          set(this.get('contextMenu').findBy('text', msgSetRoom), 'disabled', false);
        }else{
          set(this.get('contextMenu').findBy('text', msgChRoom), 'disabled', true);
          set(this.get('contextMenu').findBy('text', msgSetRoom), 'disabled', true);
        }
      },

      onAutoPrinterChanged(){
        next(this, function(){
          if(!isEmpty(this.get('setPeSettingInfoCB'))){
            this.get('setPeSettingInfoCB')();
          }
        });
      },

      onLinkedInboxClick(){
        if(isEmpty(this.get('appointmentPatient.selectedItem')) || isEmpty(this.get('appointmentPatient.selectedItem.examinationPlanId'))){
          //선택된 내역이 없습니다.
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('11627'), '', 'Ok', 'Ok', 0);
          return;
        }

        const items = this.get('peApiService').getInboxParams(this.get('appointmentPatient.selectedItem'), this.getLanguageResource('9686', 'S', '처방의'));
        set(items, 'purpose', '');
        this.set('sendInformation', items);
        this.set('isInboxOpen', true);
      },

      onExaminationChanged(item){
        if(isEmpty(item) || isEmpty(item.examinationId)){
          return;
        }

        if(!isEmpty(this.get('selectedExamList'))){
          if(!this.get('selectedExamList').any((exam) => exam.examinationId === item.examinationId)){
            this.get('selectedExamList').pushObject(item);
          }
        }else{
          this.set('selectedExamList', []);
          this.get('selectedExamList').pushObject(item);
        }
        this.set('examination', EmberObject.create());
      },

      onIssuedDeptChanged(e){
        this.set('model.checkinIssuedDepartment', emberA());
        if(!isEmpty(e.selectedItems)){
          e.selectedItems.forEach(item => {
            this.get('model.checkinIssuedDepartment').pushObject(item.departmentId);
          });
        }
      },

      onCheckAllchanged(){
        if(isEmpty(this.get('appointmentPatient.itemsSource'))){
          return;
        }

        this.get('appointmentPatient.itemsSource').map(item =>{
          set(item, 'isCheck', !this.get('appointmentPatient.isCheckAll'));

          return item;
        });
      },

      onIssuedEmployee(item){
        if(isEmpty(item)){
          this.set('model.issuedDoctorId', null);
        }else{
          this.set('model.issuedDoctorId', item.employeeId);
        }
      },

      onSettingChanged(){
        if(!isEmpty(this.get('onSettingChangedCB'))){
          this.get('onSettingChangedCB')();
        }
      },

      onCheckConsent(item){
        if(isEmpty(item)){
          return;
        }
        if(!item.isWrittenConsent){
          const options = this._questionMessage(this.getLanguageResource('11028', 'F', null, '동의서작성여부를 취소하시겠습니까?'));
          messageBox.show(this, options).then(function (result) {
            if(result === 'Yes'){
              this._saveConsent(item);
            }else{
              set(item, 'isWrittenConsent', !item.isWrittenConsent);
            }
          }.bind(this));
        }else{
          this._saveConsent(item);
        }
      },

      onCheckinClick(){
        const checkInItems = emberA();
        const validation = {isNotMyRoom : false, isCanceled: false, isRefund: false, isConsent: false};

        if (isEmpty(this.get('appointmentPatient.itemsSource').findBy('isCheck', true))){
          //처리할 내역을 선택하세요
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9286'), '', 'Ok', 'Ok', 0);
          return;
        }

        this.set('isPageLoader', true);
        this.get('appointmentPatient.itemsSource').forEach(e => {
          if(e.isCheck && e.statusCode !== 3){
            checkInItems.pushObject(e);

            if(e.statusCode === 7){
              validation.isCanceled = true;
            }
            if(e.paymentStatus === 'Refund'){
              validation.isRefund = true;
            }
            if(!isEmpty(e.isWrittenConsent) && !e.isWrittenConsent){
              validation.isConsent = true;
            }
          }
        });

        /*오리지널소스 start*/
        if(validation.isCanceled){
          //취소된 처방입니다.
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9267'), '', 'Ok', 'Ok', 0);
          this.set('isPageLoader', false);
          return;
        }
        if(validation.isRefund){
          //환불된 처방입니다.
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9285'), '', 'Ok', 'Ok', 0);
          this.set('isPageLoader', false);
          return;
        }
        if(validation.isConsent){
          //동의서를 확인해야합니다..
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('13353', 'F', '동의서를 확인해야합니다.'), '', 'Ok', 'Ok', 0);
          this.set('isPageLoader', false);
          return;
        }
        this._checkin(checkInItems);
      },

      //접수취소
      onCheckinUndoClick(){
        if (isEmpty(this.get('appointmentPatient.itemsSource'))) {
          return;
        }

        if (isEmpty(this.get('appointmentPatient.itemsSource').findBy('isCheck', true))){
          //처리할 내역을 선택하세요
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9286'), '', 'Ok', 'Ok', 0);
          return;
        }

        const cancelExaminationList = emberA();
        this.get('appointmentPatient.itemsSource').forEach(e => {
          if(e.isCheck && e.statusCode === 3) {
            cancelExaminationList.pushObject(e.examinationConductId);
          }
        });
        if (!cancelExaminationList.length) {
          //검사상태를 확인해 주시기 바랍니다.
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9288'), '', 'Ok', 'Ok', 0);
          return;
        }
        this.set('isPageLoader', true);
        const cancelInfo = {actionStaffId: this.get('conditionSet.employeeId'), examinationConductIds: cancelExaminationList };
        this.get('peApiService').onCheckinUndo(cancelInfo).then((res) => {
          if(res){
            this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
            this.get('onSearchAllCB')();
            next(this, function(){
              this.set('isPageLoader', false);
            });
          }else{
            this.set('isPageLoader', false);
          }
        }).finally(function(){
          this.set('isPageLoader', false);
        }.bind(this));
      },

      onNameLabel(){
        const selectedItem = this.get('appointmentPatient.itemsSource').filterBy('isCheck', true);
        if(isEmpty(selectedItem)){
          //선택된내역이 없습니다.
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('11627'), '', 'Ok', 'Ok', 0);
          return;
        }

        const param = {examinationPlanIds: null};
        const examinationIds = selectedItem.getEach('examinationPlanId');
        if(isPresent(examinationIds)){
          param.examinationPlanIds = examinationIds.join('&examinationPlanIds=');
        }

        const path = this.get('defaultUrl') + 'checkins/label-print';
        this.getList(path, param, null, true).then(function (res) {
          if (!isEmpty(res.response)) {
            this.onNameLabelPrint(res.response, this.get('labelPrinter'));
            //this.onNameLabelPrint(res.response, this.get('labelPrinter'), this.get('nameLabelPage'));
          }
        }.bind(this));
      },

      onPrintNameCard(){
        const selectedItem = this.get('appointmentPatient.itemsSource').filterBy('isCheck', true);
        if(isEmpty(selectedItem)){
          //선택된내역이 없습니다.
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('11627'), '', 'Ok', 'Ok', 0);
          return;
        }
        this._printLabelCheck(selectedItem, null);
      },

      onLinkedConsentClick(){
        this.set('isConsentPopupOpen', true);
      },

      onAppointmentExport(type){
        if(isEmpty(this.get('appointmentPatient.itemsSource'))){
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('13230', 'F', '출력할 내용이 없습니다.'), '', 'Ok', 'Ok', 0);
        }

        const appointmentData = get(this.appointmentGrid, 'items');

        appointmentData.map(item => {
          set(item, 'birthDay', this.get('fr_I18nService').formatDate(item.birthDay, 'd'));
          set(item, 'scheduleDatetime', this.get('fr_I18nService').formatDate(item.scheduleDate, 'g'));
          set(item, 'warning', this._getWarning(item));
          return item;
        });

        if(type == 'Print'){
          this._onAppointmentPrint(appointmentData);
        }else{
          this._getExportExcelData(appointmentData);
        }
      },

      onNameLabelSetting(){
        this.set('isLabelPageOpen', true);
      },

      onNameLabelPage(page){
        this.set('nameLabelPage', page);
      }
    },

    _onGetAppointmentList(){
      this._getColumnHeader();
      this.get('getAppointmentListCB')();
    },

    _getExportExcelData(data) {
      if(isEmpty(data)){
        return;
      }

      const title = [
        this.getLanguageResource('5150', 'F','예약일시'),
        this.getLanguageResource('4184', 'F','환자명'),
        this.getLanguageResource('8451', 'F','등록번호'),
        this.getLanguageResource('3680', 'F','성별'),
        this.getLanguageResource('3480', 'F','생년월일'),
        this.getLanguageResource('16806', 'F','검사'),
        this.getLanguageResource('7111', 'F','진료과'),
        this.getLanguageResource('2749', 'F','병동'),
        this.getLanguageResource('3759', 'F','소견'),
        this.getLanguageResource('5228', 'F','오더비고'),
        this.getLanguageResource('5130', 'F','예약비고'),
        this.getLanguageResource('3173', 'F','비고'),
      ];

      const initArr = [title];
      const resultArr = [];
      data.forEach(datas => {
        resultArr.push([
          datas.scheduleDate,
          datas.patientName,
          datas.patientCode,
          datas.gender,
          datas.birthDay,
          datas.examinationName,
          datas.medicalDepartmentName,
          datas.occupyingLocation,
          datas.clinicalFinding,
          datas.orderDetail,
          datas.scheduleComment,
          datas.warning
        ]);
      });

      const today = this.get('fr_I18nService').formatDate(this.get('co_CommonService').getNow(), 'd');
      const roomInfo = data.get('firstObject').examinationRoomName;
      const fileName = today + '_' + this.getLanguageResource('5167', 'S','예약현황') + '_' + roomInfo;

      this.get('peApiService').getExportByArrayTypeExcel(initArr, resultArr, fileName);
    },

    _onAppointmentPrint(data){
      if(isEmpty(data)){
        return;
      }
      const roomInfo = data.get('firstObject').examinationRoomName + ' [' + data.get('firstObject').examinationRoomCode + ']';
      const appoinmentDate = this.get('fr_I18nService').formatDate(this.get('conditionSet.fromDate'), 'd')
        + '~' + this.get('fr_I18nService').formatDate(this.get('conditionSet.toDate'), 'd');
      const printContent = {};
      printContent.dataField = { "examinationScheduleStatus": data };
      printContent.parameterField = {"examinationRoom" : roomInfo, "appointmentDate" : appoinmentDate};

      this.set('print', EmberObject.create({printPopup: false,
        printConfig: {
          'printType': 2,
          'printName': 'ExaminationScheduleStatus',
          'commonInformation' : false
        },
        printContent: printContent
      }));
    },

    _questionMessage(messageBoxText){
      return {
        'caption': '',
        'messageBoxImage': 'question',
        'messageBoxButton': 'YesNo',
        'messageBoxText': messageBoxText,
        'messageBoxFocus': 'Yes',
      };
    },

    _checkin(checkInItems){

      if (!checkInItems.length) {
        //검사상태를 확인해 주시기 바랍니다.
        this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9288'), '', 'Ok', 'Ok', 0);
        this.set('isPageLoader', false);
        return;
      }

      const registerExaminationList = emberA();
      checkInItems.forEach(e => {
        registerExaminationList.addObject({
          examinationPlanId: e.examinationPlanId,
          examinationRoomId: e.examinationRoomId,
          encounterId: e.encounterId,
          statuscode: 3
        });
      });

      const now = this.get('co_CommonService').getNow();
      const registerInfo = { acceptDateTime: now,
        acceptStaffId: this.get('conditionSet.employeeId'),
        acceptDoctorId: '',
        equipmentId: null,
        actionDoctorId: this.get('performEmployeeId'),
        registerExamination: registerExaminationList};

      this.get('peApiService').onCheckin(registerInfo).then((res) => {
        if(res){
          this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
          this.get('onSearchAllCB')();
          next(this, function(){
            if(this.get('model.isAutoPrint')){
              if(this.get('autoPrintType') == '01'){
                this._getRegistration(checkInItems);
              }else{
                this._printLabelCheck(checkInItems, now);
              }
            }
          });
          next(this, function(){
            this.set('isPageLoader', false);
          });
        }else{
          this.set('isPageLoader', false);
        }
      }).finally(function(){
        this.set('isPageLoader', false);
      }.bind(this));
    },

    _getRegistration(items){

      if(isEmpty(items)){
        return;
      }

      const patientIds = items.getEach('patientId').uniq();
      const now = this.get('co_CommonService').getNow();
      const acceptDate = new Date(now.getFullYear(),now.getMonth(), now.getDate(), 0, 0, 0);

      patientIds.forEach(d => {
        let examimationPlanIds = emberA();
        const planList = items.filterBy('patientId', d);
        const ptInfo = planList.findBy('patientId', d);
        examimationPlanIds = planList.getEach('examinationPlanId');
        const params = {
          patientId: d,
          examinationPlanIds: null,
          acceptDate: acceptDate
        };

        if(isPresent(examimationPlanIds)){
          params.examinationPlanIds = examimationPlanIds.join('&examinationPlanIds=');
        }
        this.get('peApiService').onGetRegistration(params).then((res) => {
          if(res){
            this._printRegistration(res, ptInfo);
          }
        });
      });
    },

    _printRegistration(items, ptInfo){
      const printArray = emberA();
      items.forEach(e => {
        const printContent = emberA({
          parameterField: {},
          dataField : emberA(),
        });

        let departmentName = '';
        if(!isEmpty(e.checkinExaminations)){
          e.checkinExaminations.map(item =>{
            set(item, 'issuedDate', this.get('fr_I18nService').formatDate(item.issuedDate, 'd'));
            return item;
          });
          departmentName = e.checkinExaminations.get('firstObject').departmentName;
        }

        const patientInfo = ptInfo;
        if (!isEmpty(patientInfo)){
          printContent.parameterField = {
            "patientName": patientInfo.patientName,
            "patientDisplayID": patientInfo.patientCode,
            "birthday": this.get('fr_I18nService').formatDate(patientInfo.birthDay, 'd'),
            "gender": patientInfo.gender,
            "age": patientInfo.age,
            "departmentName": departmentName
          };
        }

        printContent.dataField = {
          "checkinExaminations": e.checkinExaminations,
          "reservationExaminations": e.reservationExaminations,
          "otherCheckinExaminations": e.otherCheckinExaminations};

        this.set('printPopup', false);

        const printerName = this.getPrinterName('General', e.examinationRoomId, this.get('printSettings'), this.get('labelPrinter'));
        printContent.printerName = printerName;
        const singlePrint = EmberObject.create({printPopup: false,
          printConfig: {
            'printType': 1,
            'printName': 'ExaminationRegistration',
            'autoPrint' : true,
            'printerName': printerName
          },
          printContent: printContent
        });
        printArray.addObject(singlePrint);
      });
      this.set('printList', printArray);
    },

    _printLabelCheck(item, now){
      if(isEmpty(item)){
        //선택된내역이 없습니다.
        this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('11627'), '', 'Ok', 'Ok', 0);
        return;
      }
      const patientIds = item.getEach('patientId').uniq();
      const examinationGroupCode = item.get('firstObject').examinationGroupCode;

      const param = {patientIds: null, examinationGroupCode: examinationGroupCode, acceptDate: new Date(this.get('co_CommonService').getNow())};
      if(isPresent(patientIds)){
        param.patientIds = patientIds.join('&patientIds=');
      }
      const path = this.get('defaultUrl') + 'checkins/registration/label';
      this.getList(path, param, null).then(function (res) {
        this._onPrintNameCard(item, now, this.getLanguageResource('789', 'S'), res);
      }.bind(this));
    },

    _saveConsent(item){
      const consentInfo = { examinationPlanId: item.examinationPlanId,
        isWritten: item.isWrittenConsent,
        occurrenceTypeCode: 'PatientExamination',
        editStaffId: this.get('userGlobalInformation.employeeId'),
        editDatetime: this.get('co_CommonService').getNow()};

      this.get('peApiService').onCheckConsent(consentInfo).then((res) => {
        if(res){
          this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
        }else{
          set(item, 'isWrittenConsent', !item.isWrittenConsent);
          this.get('peApiService').onShowToast('error', this.getLanguageResource('11755', 'F', '저장에 실패하였습니다.'), '');
        }
      });
    },

    _getColumnHeader(){
      const header = this.getWorklistColumnHeader(this.get('model.pageSorting'));
      if(!isEmpty(this.get('co_CommonService.hospitalAdditionalInfo'))){
        const hospitalInfo = this.get('co_CommonService.hospitalAdditionalInfo');
        if(!isEmpty(hospitalInfo.businesstype) && hospitalInfo.businesstype == 'global'){
          header.removeObject(header.findBy('field', 'insurance'));
        }
      }
      this.set('appointmentPatient.gridColumns', header);
    },

    _onExaminationClear(){
      this.set('selectedExamList', []);
    },

    _getWarning(item){
      let result = '';
      if(item.isInfection){
        result = this.getLanguageResource('581', 'S', '감염주의');
      }
      if(item.priorityTypeId == '4'){
        if(!isEmpty(result)){
          result = result + '/ ';
        }
        result = result + this.getLanguageResource('5725', 'S', '응급');
      }
      if(item.isPortable){
        if(!isEmpty(result)){
          result = result + '/ ';
        }
        result = result + this.getLanguageResource('12510', 'S', '이동검사');
      }
      return result;
    },

    reSchedulingWarningMessage(){
      this.get('peApiService').onGetBusinessCodeList('ReScheduling', "").then(res => {
        if(!isEmpty(res)){
          const msg = res.get('firstObject').name;
          this.set('isReschedulingMessage', msg);
        }else{
          this.set('isReschedulingMessage', "");
        }
      });
    },
    _onPrintNameCard(printoutList, now, type, exams){
      if(isEmpty(printoutList)){
        return;
      }
      const printArray = emberA();
      const examinationRoomIds = printoutList.getEach('examinationRoomId').uniq();
      examinationRoomIds.forEach(roomId => {
        const examList = printoutList.filterBy('examinationRoomId', roomId);
        const printContent = emberA({
          parameterField: {},
          dataField : emberA(),
        });
        const examinationInfo= emberA();
        let otherExamination= emberA();
        otherExamination = $.extend(true, emberA(), exams);
        const removeExams2 = otherExamination.filterBy('examinationRoomId', roomId);
        otherExamination.removeObjects(removeExams2);
        examList.forEach(e => {
          let acceptDate = null;
          if(isEmpty(e.examinationConducts.acceptDate)){
            acceptDate = now;
          }else{
            acceptDate = e.examinationConducts.acceptDate;
          }

          let patientExams = emberA();
          let otherExams = emberA();
          if(!isEmpty(exams)){
            const checkExam =  $.extend(true, emberA(), exams);
            patientExams = checkExam.filterBy('patientId', e.patientId);
            const removeExams = patientExams.filterBy('examinationRoomId', e.examinationRoomId);
            patientExams.removeObjects(removeExams);
            if(!isEmpty(patientExams)){
              patientExams.forEach(item => {
                if(!isEmpty(otherExams)){
                  otherExams = otherExams + '\n';
                }
                otherExams = otherExams + item.examinationName;
              });
            }
          }

          examinationInfo.pushObject({
            "PatientName" : e.patientName,
            "Gender" : e.gender,
            "Birthday" : this.get('fr_I18nService').formatDate(e.birthDay, 'd'),
            "PatientID": e.patientId,
            "PatientDisplayID": e.patientCode,
            "IsPortable": e.isPortable ? 'Y' : 'N',
            "ExaminationName" : e.examinationName,
            "DateType" : type,
            "Date" : this.get('fr_I18nService').formatDate(acceptDate, 'd'),
            "Time" : this.get('fr_I18nService').formatDate(acceptDate, 't'),
            "Age" : e.age,
            "IssuedDoctorName": e.issuedDoctorName,
            "DepartmentCode": e.medicalDepartmentCode,
            "Ward": e.adminWard.name,
            "Room": e.room.name,
            "OrderDetail": e.orderDetail,
            "ExaminationComment": e.examinationComment,
            "OtherExaminationName": otherExams
          });
        });
        this.set('printPopup', false);
        printContent.dataField = { "examinationInfo": examinationInfo, "otherExamination": otherExamination };
        const printerName =
          this.getPrinterName('Label', roomId, this.get('printSettings'), this.get('labelPrinter'));
        printContent.printerName = printerName;
        const singlePrint = EmberObject.create({printPopup: false,
          printConfig: {
            'printType': 1,
            'printName': 'ExaminationLabel',
            'printerName': printerName,
            'autoPrint' : true,
          },
          printContent: printContent
        });
        printArray.addObject(singlePrint);
      });
      this.set('printList', printArray);
    },
  });