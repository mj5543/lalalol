import { next } from '@ember/runloop';
import $ from 'jquery';
import { hash } from 'rsvp';
import { isEmpty, isPresent } from '@ember/utils';
import { A as emberA } from '@ember/array';
import { task } from 'ember-concurrency';
import EmberObject, { get, set } from '@ember/object';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'patientexamination-module/app-config';
import { inject as service } from '@ember/service';
import PtMixin from '../../mixins/patient-examination-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,PtMixin,
  {
    layout,
    defaultUrl : null,
    conditionSet : null,
    appointmentPatient: null,
    acceptPatient: null,
    examinationRoomStatusData: null,
    userGlobalInformation: null,
    performRoom: null,
    isloaded: false,
    model: null,
    loadAction: true,
    openWorklistType : null,
    examinationGroupCode: null,
    isLeftPageLoader: false,
    isSettingOpen: false,
    examinationPlanId: null,
    printSettings: null,
    labelPrinter: null,
    autoPrintType: null,
    performList: null,
    nameLabelPage: 1,
    dataPageCt: 1,
    dataTotalPageCt: 1,
    takeCount: 100,
    peApiService:service('patientexamination-service'),

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'patient-examination-worklist');

      this.setStateProperties([
        'conditionSet',
        'isloaded',
        'loadAction',
        'defaultUrl',
        'examinationRoomStatusData',
        'userGlobalInformation',
        'performRoom',
        'model',
        'isLeftPageLoader',
        'openWorklistType',
        'examinationPlanId',
        'printSettings',
        'labelPrinter',
        'autoPrintType',
        'performList',
        'nameLabelPage',
        'isNextPageSearchCt',
        'isValidPagingCt',
        'examinationGroupCode']);

      if(this.hasState()===false) {
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'patientexamination') + `patient-examination/${config.version}/`);

        this.set('model', EmberObject.create({isAddCheckin: true, statusLoader: false, isCancelPopOpen: false,
          appointmentRoom: EmberObject.create(),
          checkinRoom: EmberObject.create(),
          acceptRoom: EmberObject.create(),
          performRoom: EmberObject.create(),
          isScheduleTypeCode: null,
          isPayment: false,
          pageSorting: 'Time',
          patientTypeList: [],
          performDoctor: {employeeId: '', fullName:''}}));

        this.set('loadAction', true);
        this.set('conditionSet', { fromDate: this.get('co_CommonService').getNow(), toDate: this.get('co_CommonService').getNow(),
          isAllStatus: true, isAllRoomChecked: true, performRoom: {}, selectedType: 'CheckIn', selectedTypeLang: this.getLanguageResource('6758')});
        this.set('acceptPatient', EmberObject.create({gridColumns: emberA(), itemsSource: emberA(), totalCount: 0}));
        this.set('appointmentPatient', EmberObject.create({gridColumns: emberA(), itemsSource: emberA(), totalCount: 0}));

        this.set('printSettings', emberA());
        this.set('labelPrinter', null);
        this.set('autoPrintType', null);
        this.set('nameLabelPage', 1);
      }
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'wp100');

      if(!isEmpty(this.get('co_CurrentUserService.user'))){
        this.set('userGlobalInformation', this.get('co_CurrentUserService.user'));
        set(this.get('conditionSet'), 'employeeId', this.get('userGlobalInformation.employeeId'));
      }
      this.get('peApiService').onGetBusinessCodeList('PatientType', null).then(function(data){
        this.set('model.patientTypeList', data);
      }.bind(this));

      this._onPatientChanged('A', 'Load');

      if(isEmpty(this.get('parameters.examinationGroupCode'))){
        this.set('openWorklistType', null);
      }else{
        const examinationGroupCode = this.get('parameters.examinationGroupCode');
        this.set('openWorklistType', examinationGroupCode);
        this.set('examinationGroupCode', examinationGroupCode);
        this._setExaminationGroupChanged();
      }
      this._getPeSettingInfo();
      this._getPrinterSettingInfo();
      //this._getPersonalLabelSetting();
    },

    actions: {

      onPatientChanged(item){
        this._onPatientChanged(item, null);
      },

      onGetPatient(result){
        if(!isEmpty(result)){
          let viewType = '';
          if(this.get('examinationGroupCode') === 'DR'){
            viewType = '_radiology';
          }

          const globalItem = {
            patientChoicePath: 'Patient',
            patientId: result.patientId,
            encounterId: null,
            examination:{
              state: 'Checkin',
              patientExaminationId: null,
            },
            patientSelectionSource: {
              viewId:  this.get('viewId') + viewType
            }
          };

          const menuInfo = emberA();
          menuInfo.addObject({
            displayCode: 'patient-examination-checkin' + viewType,
            stateType: 'Checkin',
            parameters: {
              examinationGroupCode: this.get('examinationGroupCode')
            }
          });
          this.get('co_PatientManagerService').selectPatient(globalItem, menuInfo);
        }
      },

      onchangedEmployeeGroup(item){
        if(item !== 'DR'){
          this.set('examinationGroupCode', item);
          this._setExaminationGroupChanged();
          this._setPeSettingInfo();
        }
        if(!isEmpty(item)){
          this._roomInfoClear();
          this._onInitSetting();
          this._onSearchAll();
          this._sendMessageChangeExaminationGroup();
        }
      },

      onConditionSet(item){
        this.set('selectedRoom', item);
      },

      onPerformExport(exportType){
        this._onPerformExport(exportType);
      },

      onTypeChanged(){
        this.set('isNextPageSearchCt', false);
        //초기로드시 안타게 하기위함
        if(!this.get('loadAction')){
          this.set('examinationRoomStatusData', emberA());
          this._onSearchAll();
        }
        this.set('loadAction', false);
        if(this.get('conditionSet.selectedType') == "Conduction"){
          this.set('conditionSet.selectedTypeLang', this.getLanguageResource('14894'));
        }else{
          this.set('conditionSet.selectedTypeLang', this.getLanguageResource('6758'));
        }
      },

      onGetMyRoomStatus(){
        this._setPeSettingInfo();
        this.get('getRoomStatusTask').perform();
        if(isEmpty(this.get('model.appointmentRoom.examinationRoomCode')) && (this.get('conditionSet.selectedType') == 'CheckIn')){
          this._onGetAppointmentList();
        }
      },

      onRoomClear(){
        const roomInfo = {};

        //탭 구분없이 전체변경
        this.set('model.acceptRoom', roomInfo);
        this.set('model.performRoom', roomInfo);
        this.set('model.appointmentRoom', roomInfo);
        this.set('model.checkinRoom', roomInfo);
      },

      onExaminationRoomClick(item){
        this.set('isNextPageSearchCt', false);

        const roomInfo = $.extend(true, EmberObject.create(), item);

        //탭 구분없이 전체변경
        this.set('model.acceptRoom', roomInfo);
        this.set('model.performRoom', roomInfo);
        this.set('model.appointmentRoom', roomInfo);
        this.set('model.checkinRoom', roomInfo);
      },

      onGetAppointmentList(){
        this._onSearchAll();
      },

      onGetAcceptList(){
        this._onSearchAll();
      },

      onSetPerformRoom(){
        this.set('isSettingOpen', true);
      },

      setPersonalRoom(item){
        if(!isEmpty(item)){
          if(isEmpty(this.get('examinationGroupCode')) || item.examinationGroupCode == this.get('examinationGroupCode')){
            this.set('performRoom', item);
          }else{
            this.set('performRoom', {});
          }
        }else{
          this.set('performRoom', {});
        }
      },

      onSelectionPatient(e){
        if(isEmpty(e.item)){
          return;
        }
        let encounterId = e.item.encounterId;
        var param = {procedureRequestId: e.item.orderId};
        this.get('peApiService').getCurrentEncounter(param).then(function(res){
          if(!isEmpty(res)){
            encounterId = res.encounterId;
            this.patientInfoSet(e, encounterId);
          }else{
            this.patientInfoSet(e, encounterId);
          }
        }.bind(this));
      },

      onFromToPickerOpenChanged(e){
        if(!e.source.isOpen){
          const dateDiff = this.checkValidDate(e.selectedFromDate, e.selectedToDate ,7);
          if(dateDiff.isValid){
            this.set('isNextPageSearchCt', false);
            this._onSearchAll();
          }
        }
      },

      onSearchAll(){
        this.set('isNextPageSearchCt', false);
        this._onSearchAll();
      },

      onSettingChanged(){
        this._setPeSettingInfo();
      }
    },

    didInsertElement() {
      this._super(...arguments);
      this.get('co_ContentMessageService').subscribeMessage('messagePatienExaminationRefresh', this.get('currentMenuId'), this, this.messagePatienExaminationRefresh);
      this.get('co_ContentMessageService').subscribeMessage('afterHideAccessPopup', this.get('viewId'), this, this._afterHideAccessPopup);
      this.get('co_ContentMessageService').subscribeMessage('messageChangeExaminationGroup', this.get('currentMenuId'), this, this.messageChangeExaminationGroup);
    },

    willDestroyElement() {
      this._super(...arguments);
      this.get('co_ContentMessageService').unsubscribeMessage('messagePatienExaminationRefresh', this.get('currentMenuId'), this, this.messagePatienExaminationRefresh);
      this.get('co_ContentMessageService').unsubscribeMessage('messageChangeExaminationGroup', this.get('currentMenuId'), this, this.messageChangeExaminationGroup);
    },

    messageChangeExaminationGroup(message){
      //본인이 발생한 메세지 Return
      if(message.viewId.substring(0, 28) === this.get('viewId') && message.viewId.indexOf('mini') < 0){
        return;
      }
      //영상은 제외필요
      if(!isEmpty(message.examinationGroupCode) && message.viewId.indexOf('_radiology') < 0
        && this.get('examinationGroupCode') != 'DR'){
        this.set('examinationGroupCode', message.examinationGroupCode);
        this._setExaminationGroupChanged();
      }
    },

    _afterHideAccessPopup(param) {
      if(param.viewId.substring(0, 28) === this.get('viewId') && param.viewId.indexOf('mini') < 0){
        if(param.isConfirmed === true) {
          this.triggerAction('onMainWorkListContainerOpenStateChange', false, 'hide');
          this._sendMessageToMini();
        }
      }
    },

    messagePatienExaminationRefresh(){
      this._onSearchAll();
    },

    messageWorklistSetRoom(){
      this._onInitSetting();
    },

    getRoomStatusTask: task(function * (){
      const dateDiff = this.checkValidDate(this.get('condition.fromDate'), this.get('condition.toDate') ,7);
      if(!dateDiff.isValid){
        return;
      }

      const param = $.extend(true, EmberObject.create(), this.get('conditionSet'));
      set(param, 'examinationGroupCode', this.get('examinationGroupCode'));
      set(param, 'addStatus', true);
      if(!this.get('isloaded')){
        this.set('model.statusLoader', true);
      }
      //this.set('examinationRoomStatusData', emberA());
      const result = yield this.get('peApiService').onGetRoomStatus(param);
      if(!isEmpty(result)){
        result.map((item, ind) =>{
          item.index = `0${ind+1}`;
          if (ind === 0) {
            item.index = '';
          }
        });
        this.set('examinationRoomStatusData', result);
        next(this, function(){
          this.set('model.statusLoader', false);
          this.set('isloaded', false);
        });
      }else{
        this.set('examinationRoomStatusData', emberA());
        next(this, function(){
          this.set('model.statusLoader', false);
          this.set('isloaded', false);
        });
      }
    }).restartable(),

    _onGetAppointmentList(){
      if(isEmpty(this.get('model.appointmentRoom.examinationRoomId'))
        && isEmpty(this.get('examinationGroupCode'))){
        return;
      }
      if(this.get('conditionSet.selectedType') != "CheckIn"){
        return;
      }

      let examinationRoomId = null;
      if(!isEmpty(this.get('model.appointmentRoom.examinationRoomId'))){
        examinationRoomId = this.get('model.appointmentRoom.examinationRoomId');
      }
      this.set('appointmentPatient.itemsSource', emberA());
      this.set('appointmentPatient.isCheckAll', false);

      const item = { addAccept: this.get('model.isAddCheckin'),
        personalSet: !this.get('conditionSet.isAllRoomChecked'),
        employeeId: this.get('conditionSet.employeeId'),
        fromDate: this.get('conditionSet.fromDate'),
        toDate: this.get('conditionSet.toDate'),
        examinationRoomId: examinationRoomId,
        examinationGroupCode: this.get('examinationGroupCode'),
        scheduleTypeCode: this.get('model.scheduleTypeCode'),
        isPayment: this.get('model.isPayment'),
        isPortable: this.get('model.isPortable'),
        patientType: this.get('model.checkinPatientType'),
        issuedDoctorId: this.get('model.issuedDoctorId'),
        issuedDepartmentIds: null,
        examinationIds: null};

      const issuedDepartmentIds = this.get('model.checkinIssuedDepartment');
      if(isPresent(issuedDepartmentIds)){
        item.issuedDepartmentIds = issuedDepartmentIds.join('&issuedDepartmentIds=');
      }

      if(!isEmpty(this.get('selectedExamList'))){
        const examinationIds = this.get('selectedExamList').getEach('examinationId');
        if(isPresent(examinationIds)){
          item.examinationIds = examinationIds.join('&examinationIds=');
        }
      }

      this.set('isLeftPageLoader', true);
      this.get('peApiService').onGetAppointmentList(item).then(function(res){
        if(!isEmpty(res)){
          res.map(data => {
            set(data, 'patientCodeName', data.patientName + data.patientCode);
            set(data, 'point', this._setIconDisplayTooltip(data));
            set(data, 'detail', this._getOrderComments(data));
            set(data, 'examinationName', this._getOrderName(data));
            set(data, 'occupyingLocation', this.getOccupyingDate(data, 'code'));
            set(data, 'occupyingLocationName', this.getOccupyingDate(data, 'name'));
            set(data, 'assignedLocationName', isEmpty(data.assignedLocationName)? data.issuedDepartmentName : data.assignedLocationName);
            return data;
          });

          if(this.get('model.pageSorting') == 'Patient'){
            this.set('appointmentPatient.itemsSource', res.sortBy('patientName'));
          }else{
            this.set('appointmentPatient.itemsSource', res);
          }
          this.set('appointmentPatient.totalCount', res.length);
        }else{
          this.set('appointmentPatient.itemsSource', emberA());
          this.set('appointmentPatient.totalCount', null);
        }
      }.bind(this)).finally(function(){
        this.set('isLeftPageLoader', false);
      }.bind(this));
    },

    _onGetAcceptList(){
      if(this.get('conditionSet.selectedType') != "Conduction"){
        return;
      }

      const isNextPageSearch = this.get('isNextPageSearchCt');
      if(isNextPageSearch) {
        if(this.get('dataTotalPageCt') <= this.get('dataPageCt')){
          return;
        }
        this.set('dataPageCt', this.get('dataPageCt') + 1 );
      } else {
        this._allClear();
      }

      const item = this._getConductParam();
      this.set('isLeftPageLoader', true);

      hash({
        totalCount: this.get('peApiService').onGetAcceptCount(item),
        acceptData: this.get('peApiService').onGetAcceptListPaging(item),
      }).then(function(res){
        if(!isEmpty(res.acceptData.response)){
          const data = this._setConductDataReturn(res.acceptData.response);
          if(isNextPageSearch) {
            this.get('acceptPatient.itemsSource').pushObjects(data);
          }else{
            this._getColumnHeader();

            const totalCount = res.totalCount.response;
            const takeCount = JSON.parse(res.acceptData.jqXHR.getResponseHeader('customdata')).takeCount;

            this.set('acceptPatient.totalCount', totalCount);
            this.set('takeCount', takeCount);
            if(totalCount > 100){
              const page = parseInt(totalCount / takeCount) + 1;
              this.set('dataTotalPageCt', page);
            }else{
              this.set('dataTotalPageCt', 1);
            }
            this.set('acceptPatient.itemsSource', data);
          }
        }else{
          this.set('acceptPatient.itemsSource', emberA());
          this.set('acceptPatient.totalCount', null);
        }
        next(this, function(){
          this.set('isValidPagingCt', true);
        });
      }.bind(this)).finally(function(){
        this.set('isLeftPageLoader', false);
      }.bind(this));
    },

    _getConductParam(){
      const item = $.extend(true, EmberObject.create(), this.get('conditionSet'));
      set(item, 'examinationRoomCode', this.get('model.acceptRoom.examinationRoomCode'));
      set(item, 'examinationRoomId', this.get('model.acceptRoom.examinationRoomId'));
      set(item, 'examinationGroupCode', this.get('examinationGroupCode'));
      set(item, 'patientId', this.get('model.patientId'));
      set(item, 'issuedDepartmentIds', this.get('model.conductIssuedDepartment'));
      set(item, 'sortingType', this.get('model.pageSorting'));
      set(item, 'dataPage', this.get('dataPageCt'));
      set(item, 'takeCount', this.get('takeCount'));

      if(!isEmpty(this.get('model.performDoctorId'))){
        set(item, 'performDoctorId', this.get('model.performDoctorId'));
      }
      return item;
    },

    _setConductDataReturn(items){
      if(isEmpty(items)){
        return;
      }
      items.map(data => {
        set(data, 'patientCodeName', data.patientName + data.patientCode);
        set(data, 'point', this._setIconDisplayTooltip(data));
        set(data, 'detail', this._getOrderComments(data));
        set(data, 'examinationName', this._getOrderName(data));
        set(data, 'occupyingLocation', this.getOccupyingDate(data, 'code'));
        set(data, 'occupyingLocationName', this.getOccupyingDate(data, 'name'));
        set(data, 'assignedLocationName', isEmpty(data.assignedLocationName)? data.issuedDepartmentName : data.assignedLocationName );
        return data;
      });
      return items;
    },

    _getColumnHeader(){
      const header = this.getConductWorklistColumnHeader(this.get('model.pageSorting'));
      if(!isEmpty(this.get('co_CommonService.hospitalAdditionalInfo'))){
        const hospitalInfo = this.get('co_CommonService.hospitalAdditionalInfo');
        if(!isEmpty(hospitalInfo.businesstype) && hospitalInfo.businesstype == 'global'){
          header.removeObject(header.findBy('field', 'insurance'));
        }
      }
      this.set('acceptPatient.gridColumns', header);
    },

    _onSearchAll(){
      const dateDiff = this.checkValidDate(this.get('conditionSet.fromDate'), this.get('conditionSet.toDate') ,7);
      if(!dateDiff.isValid){
        return;
      }
      this.set('isloaded', true);
      this.get('getRoomStatusTask').perform();
      this._onGetSearchList();
    },

    _onGetSearchList(){
      const dateDiff = this.checkValidDate(this.get('conditionSet.fromDate'), this.get('conditionSet.toDate') ,7);
      if(!dateDiff.isValid){
        return;
      }

      if(this.get('conditionSet.selectedType') == "Conduction"){
        this._onGetAcceptList();
      }else{
        this._onGetAppointmentList();
      }
    },

    _sendMessageToMini(){
      const selectedType = this.get('conditionSet.selectedType');
      let examinationRoom = emberA();

      if(selectedType == 'CheckIn'){
        examinationRoom = this.get('model.appointmentRoom');
      }else{
        examinationRoom = this.get('acceptRoom.acceptRoom');
      }
      const message = { examinationGroupCode : this.get('examinationGroupCode'),
        examinationRoom: examinationRoom,
        selectedType: selectedType,
        patientType: this.get('conditionSet.patientType'),
        examinationPlanId: this.get('examinationPlanId'),
        parameters : {examinationGroupCode : this.get('examinationGroupCode')}};

      this.get('co_ContentMessageService').sendMessage('messagePatienExaminationMiniSetting', message);
    },

    _sendMessageChangeExaminationGroup(){
      if(isEmpty(this.get('examinationGroupCode'))){
        return;
      }
      let viewType = '';
      if(this.get('examinationGroupCode') === 'DR'){
        viewType = '_radiology';
      }

      const message = { examinationGroupCode : this.get('examinationGroupCode'), viewId:  this.get('viewId') + viewType};
      this.get('co_ContentMessageService').sendMessage('messageChangeExaminationGroup', message);
    },

    _onGetRoomStatusSetting(){
      const item = $.extend(true, EmberObject.create(), this.get('conditionSet'));
      set(item, 'examinationGroupCode', this.get('examinationGroupCode'));
      set(item, 'addStatus', false);

      this.get('peApiService').onGetRoomStatus(item).then(function(res){
        if(!isEmpty(res) && emberA(this.get('examinationRoomStatusData'))){
          res.map((items, ind) =>{
            items.class = '';
            items.index = `0${ind+1}`;
            if (ind === 0) {
              items.index = '';
            }
          });
          this.set('examinationRoomStatusData', res);
        }
      }.bind(this));
    },

    async _setPeSettingInfo(){

      let viewId = this.get('viewId');
      if(this.get('examinationGroupCode') === 'DR'){
        viewId = this.get('viewId') + '_radiology';
      }
      const settingKey = viewId;
      const settingData = {
        conditionData: [{
          isAllRoomChecked: this.get('conditionSet.isAllRoomChecked'),
          patientSorting: this.get('model.pageSorting'),
          isAutoPrint: this.get('model.isAutoPrint'),
          usedExaminationGroupCode: this.get('examinationGroupCode')
        }]};

      const description = this.getLanguageResource('13354', 'F', '영상/기능검사실 워크리스트');
      await this.get('peApiService').setPeSettingInfo(settingKey, settingData, description);
    },

    async _getPeSettingInfo(){
      let viewId = this.get('viewId');
      if(this.get('examinationGroupCode') === 'DR'){
        viewId = this.get('viewId') + '_radiology';
      }
      const settingKey = viewId;
      const data = await this.get('peApiService').getPeSettingInfo(settingKey);
      if(!isEmpty(data)) {
        const condition = data[0];
        if(!isEmpty(condition.usedExaminationGroupCode) && this.get('examinationGroupCode') != 'DR'){
          this.set('examinationGroupCode', condition.usedExaminationGroupCode);
        }
        this.set('conditionSet.isAllRoomChecked', condition.isAllRoomChecked);
        this.set('model.pageSorting', condition.pageSorting || 'Time');
        this.set('model.isAutoPrint', condition.isAutoPrint || false);
        this.get('getRoomStatusTask').perform();

        this._onInitSetting();
      }else{
        this._onInitSetting();
      }
    },

    async _getPersonalLabelSetting(){
      let viewId = 'patient-examination-label-setting';
      if(this.get('examinationGroupCode') === 'DR'){
        viewId = viewId + '_radiology';
      }
      const settingKey = viewId;
      const data = await this.get('peApiService').getPeSettingInfo(settingKey);
      if(!isEmpty(data)) {
        const condition = data[0];
        if(!isEmpty(condition.nameLabelPage)){
          this.set('nameLabelPage', condition.nameLabelPage);
        }
      }
    },

    _onInitSetting(){
      this.get('peApiService').getMyRoomInfo(this.get('userGlobalInformation.employeeId'), this.get('examinationGroupCode'), null).then(function(res){
        if(!isEmpty(res)){
          res.map(item => {
            if(isEmpty(item.examinationCategoryId)){
              item.examinationCategoryId = item.examinationGroupCode;
            }
          });
          const myroom = res.findBy('isRepresentative', true);
          this.set('performRoom', myroom);
          if(isEmpty(this.get('model.acceptRoom.examinationRoomCode'))){
            this.set('model.acceptRoom', myroom);
            this.set('model.performRoom', myroom);
          }
          if(isEmpty(this.get('model.appointmentRoom.examinationRoomCode'))){
            this.set('model.appointmentRoom', myroom);
            this.set('model.checkinRoom', myroom);
          }
        }else{
          this.set('performRoom', {examinationRoomCode: null});
        }
        this._onGetSearchList();
      }.bind(this));
    },

    _roomInfoClear(){
      this.set('model.acceptRoom', {});
      this.set('model.performRoom', {});
      this.set('acceptPatient.itemsSource', emberA());

      this.set('model.appointmentRoom', {});
      this.set('model.checkinRoom', {});
      this.set('appointmentPatient.itemsSource', emberA());
    },

    async _getPrinterSettingInfo(){
      let category = 'Radiology';
      if(this.get('examinationGroupCode') != 'DR'){
        category = 'Clinic';
      }
      var result = await this.get('co_PersonalizationService').getPersonalPrinterSetting(category, 'print');

      if(!isEmpty(result.get('firstObject'))) {
        const settingValue = JSON.parse(get(result.get('firstObject'), 'settingValue'));
        this.set('settingValue', settingValue);
        if(!isEmpty(settingValue)) {
          if(!isEmpty(settingValue.defaultLabelPrinter)){
            this.set('labelPrinter', settingValue.defaultLabelPrinter);
          }
          if(!isEmpty(settingValue.autoPrintType)){
            this.set('autoPrintType', settingValue.autoPrintType);
          }
          if(!isEmpty(settingValue.item)){
            this.set('printSettings', settingValue.item);
          }
        }
      }
    },

    patientInfoSet(e, encounterId){
      if(!isEmpty(e.item)){
        let viewType = '';
        if(this.get('examinationGroupCode') === 'DR'){
          viewType = '_radiology';
        }

        const globalItem = {
          patientChoicePath: 'Encounter',
          patientId: e.item.patientId,
          encounterId: encounterId,
          examination:{
            state: e.item.procedureExecutionStatusCode,
            patientExaminationId: e.item.examinationPlanId,
          },
          patientSelectionSource: {
            viewId:  this.get('viewId') + viewType
          }
        };

        const menuInfo = emberA();
        if(this.get('conditionSet.selectedType') === 'CheckIn'){
          menuInfo.addObject({
            displayCode: 'patient-examination-checkin' + viewType,
            stateType: e.item.procedureExecutionStatusCode,
            parameters: {
              patientType: this.get('model.checkinPatientType'),
              scheduleDate: e.item.scheduleDate,
              examinationGroupCode: this.get('examinationGroupCode'),
              patientExaminationId: e.item.examinationPlanId,
              performRoom: this.get('performRoom')
            }
          });
        }else{
          menuInfo.addObject({
            displayCode: 'patient-examination-conducting' + viewType,
            stateType: e.procedureExecutionStatusCode,
            parameters: {
              patientType: this.get('model.conditionPatientType'),
              acceptDate: e.item.acceptDate,
              patientId : e.item.patientId,
              waitingRoom: {examinationRoomId: e.item.examinationRoomId,
                examinationRoomCode: e.item.examinationRoomCode,
                examinationRoomName: e.item.examinationRoomName},
              isChecked: this.get('conditionSet').isAllStatus,
              examinationGroupCode: this.get('examinationGroupCode'),
              patientExaminationId: e.item.examinationPlanId,
              performRoom: this.get('performRoom')
            }
          });
        }
        this.set('examinationPlanId', e.item.examinationPlanId);
        this.get('co_PatientManagerService').selectPatient(globalItem, menuInfo);
      }
    },

    _getOrderComments(item){
      let res=[];
      if(!isEmpty(item.orderDetail)){
        res.addObject('***' + this.getLanguageResource('5228', 'S', '오더비고') + '***<br>' + item.orderDetail);
      }
      if(!isEmpty(item.clinicalFinding)){
        res.addObject('***' + this.getLanguageResource('6228','S', '임상소견') + '***<br>' + item.clinicalFinding);
      }
      if(!isEmpty(item.insuranceReason)){
        res.addObject('***' + this.getLanguageResource('13355', 'F', '보험적용사유') + '***<br>' + item.insuranceReason);
      }
      if(!isEmpty(item.scheduleComment)){
        res.addObject('***' + this.getLanguageResource('5130','S', '예약비고') + '***<br>' + item.scheduleComment);
      }
      if(!isEmpty(item.examinationComment)){
        res.addObject('***' + this.getLanguageResource('750','S', '검사실비고') + '***<br>' + item.examinationComment);
      }
      if(res.length >= 1){
        res=res.join('<br><br>').toString();
      }else{
        res=[];
      }
      return res;
    },


    _getPerformDoctor(){
      if(isEmpty(this.get('examinationGroupCode'))){
        return;
      }

      this.set('performList', []);
      const param = {
        examinationGroupCode: this.get('examinationGroupCode'),
        relationTypeCode: "PerformDoctor"
      };
      this.get('peApiService').onGetExaminationEmployeeList(param).then(function(data){
        this.set('performList', data);
      }.bind(this));
    },

    _getAcceptableRoomList(){
      if(isEmpty(this.get('examinationGroupCode'))){
        return;
      }

      this.set('acceptableRooms', []);
      this.set('acceptableRoomsSet', []);

      const param = {
        examinationGroupCode: this.get('examinationGroupCode')
      };

      const contextSource = [];
      const contextSource2 = [];
      const contextSourcePerform = [];
      this.get('peApiService').onGetAcceptableRoomList(param).then(function(data){
        if(!isEmpty(data)){
          data.forEach(room => {
            const context = {action: this.onChangeAcceptRoom.bind(null, room),
              text: room.examinationRoomName, value: room.examinationRoomId, disabled : false, display : true};
            contextSource.addObject(context);
          });

          data.forEach(room => {
            const context2 = {action: this.onChangeAcceptRoomSet.bind(null, room),
              text: room.examinationRoomName, value: room.examinationRoomId, disabled : false, display : true};
            contextSource2.addObject(context2);
          });

          data.forEach(room => {
            const contextPerform = {action: this.onChangePerformRoom.bind(null, room),
              text: room.examinationRoomName, value: room.examinationRoomId, disabled : false, display : true};
            contextSourcePerform.addObject(contextPerform);
          });
        }
      }.bind(this));

      this.set('acceptableRooms', contextSource);
      this.set('acceptableRoomsSet', contextSource2);
      this.set('performRooms', contextSourcePerform);
    },

    onChangePerformRoom(item){
      if(isEmpty(item)){
        return;
      }

      if(isEmpty(this.get('acceptPatient.itemsSource'))){
        return;
      }

      let isChecked = false;
      this.get('acceptPatient.itemsSource').forEach(e => {
        if(e.isCheck){
          set(e, 'examinationRoomId', item.examinationRoomId);
          set(e, 'examinationRoomName', item.examinationRoomName);
          isChecked = true;
        }
      });
      if(!isChecked){
        this.get('peApiService').onShowToast('warning', this.getLanguageResource('13357', 'F', '변경할 검사를 먼저 체크하세요.'), '');
      }
    },


    onChangeAcceptRoomSet(item){
      if(isEmpty(item)){
        return;
      }

      if(isEmpty(this.get('appointmentPatient.itemsSource'))){
        return;
      }

      let isChecked = false;
      this.get('appointmentPatient.itemsSource').forEach(e => {
        if(e.isCheck){
          set(e, 'examinationRoomId', item.examinationRoomId);
          set(e, 'examinationRoomName', item.examinationRoomName);
          isChecked = true;
        }
      });
      if(!isChecked){
        this.get('peApiService').onShowToast('warning', this.getLanguageResource('11918', 'F', '선택한 항목이 없습니다.'), '');
      }
    },

    onChangeAcceptRoom(item){
      if(isEmpty(item)){
        return;
      }

      if(isEmpty(this.get('appointmentPatient.itemsSource'))){
        return;
      }
      const items = this.get('appointmentPatient.itemsSource').filterBy('isCheck', true);
      const validItems = items.filterBy('statusCode', 1);
      const notValidItems = items.filter(d => d.get('statusCode') === 2 || d.get('statusCode') === 3);

      if(validItems.length < 1){
        this.get('peApiService').onShowToast('warning', this.getLanguageResource('12608', 'F', '진행할 유효항목이 없습니다.'), '');
      }else{
        if(notValidItems.length > 0){
          this.get('peApiService').onShowToast('warning', this.getLanguageResource('12609', 'F', '예약, 접수상태 항목을 제외하고 검사실 변경이 진행됩니다.'), '');
        }

        const param = {
          examinationRoomId: item.examinationRoomId,
          examinationPlanIds: validItems.getEach('examinationPlanId')
        };

        this.get('peApiService').changeExaminationRoom(param).then((res) => {
          if(res){
            this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
            this._onSearchAll();
          }else{
            this.get('peApiService').onShowToast('error', this.getLanguageResource('11755', 'F','저장에 실패했습니다.'), '');
          }
        });
      }
    },

    _onPatientChanged(item, type){
      let classCode = 'A';
      if(!isEmpty(item)){
        classCode = item;
      }

      this.get('peApiService').onGetDepartmentGroupList({issuedPatientTypeCode: classCode}).then(function(res){
        if(!isEmpty(res)){
          if(type != 'Load'){
            if(this.get('conditionSet.selectedType') == 'CheckIn'){
              this.set('issuedCheckInDepartmentItems', res);
            }else{
              this.set('issuedConductDepartmentItems', res);
            }
          }else{
            this.set('issuedCheckInDepartmentItems', res);
            this.set('issuedConductDepartmentItems', res);
          }
        }
      }.bind(this));
    },

    _getAllExaminationList(){
      if(isEmpty(this.get('examinationGroupCode'))){
        return;
      }

      const param = { examinationGroupCode: this.get('examinationGroupCode')};
      this.get('peApiService').onGetExaminationList(param).then(function(res){
        if(!isEmpty(res)){
          this.set('examinationItems', res);
        }
      }.bind(this));
    },

    _setExaminationGroupChanged(){
      this.set('isNextPageSearchCt', false);
      this._getAllExaminationList();
      this._getPerformDoctor();
      this._getAcceptableRoomList();
    },

    getOccupyingDate(item, type){
      if(isEmpty(item)){
        return;
      }

      let location = null;

      if(type == 'code'){
        if(!isEmpty(item.adminWard.displayCode)){
          location = item.adminWard.displayCode;
        }
        if(!isEmpty(item.room.displayCode)){
          location = location + '/ ' + item.room.displayCode;
        }
        if(!isEmpty(item.bed.displayCode)){
          location = location + '/ ' + item.bed.displayCode;
        }
        return location;
      }else{
        if(!isEmpty(item.adminWard.name)){
          location = item.adminWard.name;
        }
        if(!isEmpty(item.room.name)){
          location = location + '/ ' + item.room.name;
        }
        if(!isEmpty(item.bed.name)){
          location = location + '/ ' + item.bed.name;
        }
        return location;
      }
    },

    _allClear(){
      if(this.get('conditionSet.selectedType') == "Conduction"){
        this.set('dataPageCt', 1);
        this.set('acceptPatient.itemsSource', emberA());
        this.set('acceptPatient.selectedItem', EmberObject.create({isWarning:false}));
        this.set('acceptPatient.isCheckAll', false);
      }
    },


    _onPerformExport(exportType){
      if(this.get('dataTotalPageCt') == this.get('dataPageCt')){
        if(exportType == 'Print'){
          this._onPerformPrintFormat(get(this.acceptGrid, 'items'));
        }else{
          this._getExportExcelData(get(this.acceptGrid, 'items'));
        }
      }else{
        let total = 1000;
        if(!isEmpty(this.get('acceptPatient.totalCount')) && this.get('acceptPatient.totalCount') > 1000){
          total = this.get('acceptPatient.totalCount') + 1;
        }
        const item = this._getConductParam();
        set(item, 'dataPage', 1);
        set(item, 'takeCount', total);

        this.get('peApiService').onGetAcceptListPaging(item).then(function(res){
          if(!isEmpty(res.response)){
            if(exportType == 'Print'){
              this._onPerformPrintFormat(res.response);
            }else{
              this._getExportExcelData(res.response);
            }
          }
        }.bind(this));
      }
    },

    _onPerformPrintFormat(data){
      if(isEmpty(data)){
        this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('13230', 'F', '출력할 내용이 없습니다.'), '', 'Ok', 'Ok', 0);
        return;
      }
      data.map(item => {
        set(item, 'birthDay', this.get('fr_I18nService').formatDate(item.birthDay, 'd'));
        set(item, 'issuedDate', this.get('fr_I18nService').formatDate(item.issuedDate, 'd'));
        if(!isEmpty(item.executeDatetime)){
          set(item, 'executeDatetime', this.get('fr_I18nService').formatDate(item.executeDatetime, 'g'));
        }
        return item;
      });

      const roomInfo = data.get('firstObject').examinationRoomName + ' [' + data.get('firstObject').examinationRoomCode + ']';
      const execDate = this.get('fr_I18nService').formatDate(this.get('conditionSet.fromDate'), 'd')
        + '~' + this.get('fr_I18nService').formatDate(this.get('conditionSet.toDate'), 'd');
      const printContent = {};
      printContent.dataField = { "examinationConductedList": data };
      printContent.parameterField = {"examinationRoom" : roomInfo, "execDate" : execDate};
      this.set('print', EmberObject.create({printPopup: false,
        printConfig: {
          'printType': 2,
          'printName': 'ExaminationConductedList',
          'commonInformation' : false
        },
        printContent: printContent
      }));
    },

    _getExportExcelData(gridItemsSource) {
      if(isEmpty(gridItemsSource)){
        this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('13230', 'F', '출력할 내용이 없습니다.'), '', 'Ok', 'Ok', 0);
        return;
      }
      gridItemsSource.map(item => {
        set(item, 'birthDay', this.get('fr_I18nService').formatDate(item.birthDay, 'd'));
        if(!isEmpty(item.executeDatetime)){
          set(item, 'executeDatetime', this.get('fr_I18nService').formatDate(item.executeDatetime, 'g'));
        }
        return item;
      });

      const title = [
        this.getLanguageResource('6770', 'S', '접수시간'),
        this.getLanguageResource('4184', 'F','환자명'),
        this.getLanguageResource('8451', 'F','등록번호'),
        this.getLanguageResource('3680', 'F','성별'),
        this.getLanguageResource('1662', 'S', '나이'),
        this.getLanguageResource('3480', 'F','생년월일'),
        this.getLanguageResource('16806', 'F','검사'),
        this.getLanguageResource('738', 'S', '시행시간'),
        this.getLanguageResource('9924', 'S', '시행의'),
        this.getLanguageResource('3859', 'S', '수납'),
        this.getLanguageResource('5246', 'S', '오더일'),
        this.getLanguageResource('9686', 'S', '처방의'),
        this.getLanguageResource('8421', 'S', '환자구분'),
        this.getLanguageResource('7111', 'F','진료과'),
        this.getLanguageResource('732', 'S', '검사상태'),
      ];

      const initArr = [title];
      const resultArr = [];

      gridItemsSource.forEach(datas => {
        resultArr.push([
          datas.acceptDate,
          datas.patientName,
          datas.patientCode,
          datas.gender,
          datas.age,
          datas.birthDay,
          datas.examinationName,
          datas.executeDatetime,
          datas.performDoctorName,
          datas.paymentStatusName,
          datas.issuedDate,
          datas.issuedDoctorName,
          datas.patientTypeName,
          datas.medicalDepartmentName,
          datas.statusName,
        ]);
      });
      const fileName = this.getLanguageResource('6787', 'S','접수현황');
      this.get('peApiService').getExportByArrayTypeExcel(initArr, resultArr, fileName);
    },

    checkValidDate(fromDate, toDate, maxPeriod) {
      if(isEmpty(fromDate) || isEmpty(toDate) || isEmpty(maxPeriod)){
        return {isValid: true, days: ''};
      }
      const dat1 = new Date(fromDate.getFullYear(), fromDate.getMonth(), fromDate.getDate(), 0, 0, 0);
      const dat2 = new Date(toDate.getFullYear(), toDate.getMonth(), toDate.getDate(), 0, 0, 0);
      const diff = dat2 - dat1;
      const currDay = 24 * 60 * 60 * 1000;
      const diffDays = parseInt(diff/currDay);
      if (diffDays > maxPeriod) {
        const message = this.getLanguageResource('17030', 'F','7일 이상 조회하실 수 없습니다.');
        this.get('peApiService').onShowToast('error', '', message);
        return {isValid: false, days: diffDays};
      } else {
        return {isValid: true, days: diffDays};
      }
    },
  });
