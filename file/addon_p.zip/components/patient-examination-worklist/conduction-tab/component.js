import { next } from '@ember/runloop';
import { A as emberA } from '@ember/array';
import { isEmpty, isPresent } from '@ember/utils';
import EmberObject, { set } from '@ember/object';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'patientexamination-module/app-config';
import { inject as service } from '@ember/service';
import PtMixin from '../../../mixins/patient-examination-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, PtMixin,
  {
    layout,
    defaultUrl : null,
    conditionSet : null,
    appointmentPatient: null,
    acceptPatient: null,
    examinationRoomStatusData: null,
    performRoom: null,
    conductModel: null,
    examinationGroupCode: null,
    isPageLoader: false,
    targetId: null,
    placementTargetId: null,
    print: null,
    isSideSedationOpen: false,
    isScopeOpen: false,
    userGlobalInformation: null,
    paramEmployeeId: null,
    acceptGrid: null,
    isValidPagingCt: true,
    isNextPageSearchCt: false,
    isRoomDisabled: false,
    isCpacsUsed: false,
    nameLabelPage: null,
    peApiService:service('patientexamination-service'),

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'patient-examination-worklist');

      this.setStateProperties([
        'conditionSet',
        'defaultUrl',
        'examinationRoomStatusData',
        'performRoom',
        'conductModel',
        'isPageLoader',
        'targetId',
        'placementTargetId',
        'isSideSedationOpen',
        'userGlobalInformation',
        'isScopeOpen',
        'paramEmployeeId',
        'acceptGrid',
        'isNextPageSearchCt',
        'isRoomDisabled',
        'isCpacsUsed',
        'nameLabelPage',
        'examinationGroupCode']);

      if(this.hasState()===false) {
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'patientexamination') + `patient-examination/${config.version}/`);
        this._getColumnHeader();
        this.set('print', EmberObject.create({printPopup: null, printConfig: null, printContent: null}));
        //ID 동적으로 부여하기 위해서.. 시간을 사용
        const now = this.get('co_CommonService').getNow();
        const targetId = 'employee' + now.getHours().toString() + now.getMinutes().toString() + now.getSeconds().toString() + now.getMilliseconds().toString();
        this.set('targetId', targetId);
        this.set('placementTargetId', '#'+ targetId);
        this.set('acceptPatient.selectedItem', EmberObject.create({isWarning:false}));
        this.set('paramEmployeeId', null);

        this.set('sortingItems', [{value:'Time', text: this.getLanguageResource('6770', 'F', '접수시간')},
          {value:'Patient', text: this.getLanguageResource('9101', 'S', '환자')}]);

        this.set('isCpacsUsed', false);
      }
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'wp100');

      if(!isEmpty(this.get('co_CurrentUserService.user'))){
        this.set('userGlobalInformation', this.get('co_CurrentUserService.user'));
        set(this.get('conditionSet'), 'employeeId', this.get('userGlobalInformation.employeeId'));
        this._getEmployeeOccupation(this.get('userGlobalInformation.employeeId'));
      }
      this._getViewerMode();
      const msgSetRoom = this.getLanguageResource('12605', 'S', '검사실지정');
      this.set('contextMenu', emberA([
        EmberObject.create({ text: msgSetRoom, disabled: true, display: true}),
      ]));
    },

    actions: {
      onGetPatient(item) {
        this.set('conductModel.patientId', item && item.patientId);
      },

      onLoadGrid(e){
        this.set('acceptGrid', e.source);
      },

      onGridScroll(e){
        if(this.get('acceptPatient.totalCount') === this.get('acceptPatient.itemsSource.length')) {
          return;
        }
        if (e.top !== 0 && Math.round(e.maxTop) <= Math.round(e.top) + 1){
          if(this.get('isValidPagingCt')){
            this.set('isValidPagingCt', false);
            this.set('isNextPageSearchCt', true);
            this.get('getAcceptListCB')();
          }
        }
      },

      onConductRoomChanged(item){
        if(isEmpty(this.get('conditionSetCB'))){
          this.get('conditionSetCB')(item);
        }
        this.set('isNextPageSearchCt', false);
        this.get('getAcceptListCB')();
      },

      onPatientTypeChanged(item){
        if(!isEmpty(this.get('onPatientChangedCB'))){
          this.get('onPatientChangedCB')(item);
        }
      },

      onRoomClear(){
        if(!isEmpty(this.get('roomClearCB'))){
          this.get('roomClearCB')();
        }
      },

      onGetAcceptList(){
        this.set('isNextPageSearchCt', false);
        this.get('getAcceptListCB')();
      },

      onConductchanged(){
        this.set('acceptPatient.isCheckAll', false);
      },

      onConductAllchanged(){
        if(isEmpty(this.get('acceptPatient.itemsSource'))){
          return;
        }

        this.get('acceptPatient.itemsSource').map(item =>{
          set(item, 'isCheck', !this.get('acceptPatient.isCheckAll'));

          return item;
        });
      },

      onIssuedDeptChanged(e){
        this.set('conductModel.conductIssuedDepartment', emberA());
        if(!isEmpty(e.selectedItems)){
          e.selectedItems.forEach(item => {
            this.get('conductModel.conductIssuedDepartment').pushObject(item.departmentId);
          });
        }
      },

      onSelectionPatient(e){
        this.get('onSelectionPatientCB')(e);
      },

      onDisabledSetting(e){
        const msgSetRoom = this.getLanguageResource('12605', 'S', '검사실지정');
        if(isEmpty(e.dataItem.item) || isEmpty(e.dataItem.item.isScheduling) || isEmpty(e.dataItem.item.statusCode)){
          set(this.get('contextMenu').findBy('text', msgSetRoom), 'disabled', true);
          set(this.get('contextMenu').findBy('text', msgSetRoom), 'children', null);
          return false;
        }

        if(!isEmpty(this.get('performRooms')) && this.get('performRooms').length > 1){
          set(this.get('contextMenu').findBy('text', msgSetRoom), 'children', this.get('performRooms'));
          set(this.get('contextMenu').findBy('text', msgSetRoom), 'disabled', false);
        }else{
          set(this.get('contextMenu').findBy('text', msgSetRoom), 'disabled', true);
        }
      },

      onLinkedInboxClick(){
        if(isEmpty(this.get('acceptPatient.selectedItem')) || isEmpty(this.get('acceptPatient.selectedItem.examinationPlanId'))){
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('11627'), '', 'Ok', 'Ok', 0);
          return;
        }

        const items = this.get('peApiService').getInboxParams(this.get('acceptPatient.selectedItem'), this.getLanguageResource('9686', 'S', '처방의'));
        set(items, 'purpose', '');
        this.set('sendInformation', items);
        this.set('isInboxOpen', true);
      },

      onPerformClick(){
        if(isEmpty(this.get('acceptPatient.itemsSource'))){
          return;
        }

        /*의사시행 체크*/
        let isNotDoctorPerform = false;

        if (isEmpty(this.get('acceptPatient.itemsSource').findBy('isCheck', true))){
          //처리할 내역을 선택하세요
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9286'), '', 'Ok', 'Ok', 0);
          return;
        }

        const modifyExaminationList = emberA();
        this.get('acceptPatient.itemsSource').forEach(e =>{
          if (e.isCheck && (e.statusCode == 3 || e.statusCode == 7)) {
            const modifyExamination = { examinationConductId: e.examinationConductId,
              examinationPlanId: e.examinationPlanId,
              statuscode: 4,
              examinationRoomId: e.examinationRoomId,
              actionExamDoctorId: e.performDoctorId
            };
            modifyExaminationList.pushObject(modifyExamination);
            if(e.isDoctorPerform && isEmpty(e.performDoctorName) && isEmpty(this.get('performEmployeeId'))){
              isNotDoctorPerform = true;
            }
          }
        });
        if (!modifyExaminationList.length) {
          //검사상태를 확인해 주시기 바랍니다.
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9288'), '', 'Ok', 'Ok', 0);
          return;
        }
        const performInfo = {actionDateTime: this.get('co_CommonService').getNow(),
          actionStaffId: this.get('conditionSet.employeeId'),
          equipmentId: this.get('equipment'),
          actionDoctorId: this.get('performEmployeeId'),
          modifyExamination: modifyExaminationList};

        /*내 검사실 체크*/
        const performRoomId = this.get('conductModel.acceptRoom.examinationRoomId');
        let isNotMyRoom = false;
        if(!isEmpty(this.get('performRoom')) && !isEmpty(this.get('performRoom.examinationRoomId'))){
          const myRooms = modifyExaminationList.filterBy('examinationRoomId', this.get('performRoom.examinationRoomId'));
          if(!isEmpty(performRoomId) && myRooms.length != modifyExaminationList.length){
            isNotMyRoom = true;
          }
        }

        if(isNotMyRoom){
          const options = this._questionMessage(this.getLanguageResource('11945', 'F', null, '내 검사실이 아닌 검사를 진행하시겠습니까?'));
          messageBox.show(this, options).then(function (result) {
            if(result === "Yes"){
              if(isNotDoctorPerform){
                this.questionPerformMessage(performInfo);
              }else{
                this.get('peApiService').onPerform(performInfo).then((res) => {
                  if(res){
                    this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
                    this.get('onSearchAllCB')();
                  }else{
                    this.set('isPageLoader', false);
                  }
                }).finally(function(){
                  this.set('isPageLoader', false);
                }.bind(this));
              }
            }
          }.bind(this));
        }

        if(isNotDoctorPerform && !isNotMyRoom){
          this.questionPerformMessage(performInfo);
        }

        if(!isNotMyRoom && !isNotDoctorPerform){
          this.set('isPageLoader', true);
          this.get('peApiService').onPerform(performInfo).then((res) => {
            if(res){
              this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
              this.get('onSearchAllCB')();
            }else{
              this.set('isPageLoader', false);
            }
          }).finally(function(){
            this.set('isPageLoader', false);
          }.bind(this));
        }
      },

      onPerformUndoClick(){
        if(isEmpty(this.get('acceptPatient.itemsSource'))){
          return;
        }

        if (isEmpty(this.get('acceptPatient.itemsSource').findBy('isCheck', true))){
          //처리할 내역을 선택하세요
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9286'), '', 'Ok', 'Ok', 0);
          return;
        }

        let isMaterial = false;
        const undoExaminationConductList = emberA();

        this.get('acceptPatient.itemsSource').forEach(e =>{
          if(e.isCheck && e.statusCode == 4) {
            this.ajaxSyncCall(this.get('defaultUrl') + 'conductions/material/', {procedureRequestId: e.orderId}, 'GET', null, false).done(res => {
              if(res > 0){
                isMaterial=true;
              }
            });
            const undoExaminationConduct = {examinationConductId: e.examinationConductId,
              examinationPlanId: e.examinationPlanId,
              statuscode: 3,
              examinationRoomCode: null};
            undoExaminationConductList.pushObject(undoExaminationConduct);
          }
        });
        const undoPerformInfo = {actionDate: this.get('co_CommonService').getNow(),
          actionStaffId: this.get('conditionSet.employeeId'),
          undoExaminationConduct: undoExaminationConductList};

        this.set('isPageLoader', true);
        if(isEmpty(undoPerformInfo)){
          //검사상태를 확인해 주시기 바랍니다.
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9288'), '', 'Ok', 'Ok', 0);
          this.set('isPageLoader', false);
          return;
        }
        if(isMaterial){
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('12607', 'F', '재료를 먼저 환불해 주시기바랍니다.'), '', 'Ok', 'Ok', 0);
          this.set('isPageLoader', false);
          return;
        }
        this.get('peApiService').onPerformUndo(undoPerformInfo).then((res) => {
          if(res){
            this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
            this.get('onSearchAllCB')();
          }else{
            this.set('isPageLoader', false);
          }
        }).finally(function(){
          this.set('isPageLoader', false);
        }.bind(this));
      },

      onPerformCancelClick(){
        if(isEmpty(this.get('acceptPatient.itemsSource'))){
          return;
        }

        if (isEmpty(this.get('acceptPatient.itemsSource').findBy('isCheck', true))){
          //처리할 내역을 선택하세요
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9286'), '', 'Ok', 'Ok', 0);
          return;
        }
        const msg = this.getLanguageResource('8941', 'S', '취소하시겠습니까?');
        const confirmMsg = this.getLanguageResource('8377', 'S', '확인');
        const options = {'messageBoxImage': 'question', 'caption':  confirmMsg, 'messageBoxText': msg,
          'messageBoxButton': 'OKCancel', 'messageBoxFocus' : 'Ok', 'messageboxInterval' : 0};
        messageBox.show(this, options).then((rbutton) => {
          if(rbutton === "Ok"){
            this._onPerformCancel();
          }
        });
      },

      getSaveCancelReason(item){
        this._onCancelPerform(item);
      },

      onExcel(){
        this._getExportExcelData();
      },

      onPerformPrint(){
        this._onPerformPrint();
      },

      onSideSedClick(){
        this.set('isSideSedationOpen', true);
      },

      onScopeClick(){
        if(!isEmpty(this.get('acceptPatient.selectedItem'))){
          this.set('isScopeOpen', true);
        }
      },

      onCheckInjection(item){
        if(isEmpty(item)){
          return;
        }
        if(!item.isInjection){
          const options = this._questionMessage(this.getLanguageResource('11754', 'F', null, 'IV여부를 취소하시겠습니까?'));
          messageBox.show(this, options).then(function (result) {
            if(result === 'Yes'){
              this._saveInjectiont(item);
            }else{
              set(item, 'isInjection', !item.isInjection);
            }
          }.bind(this));
        }else{
          this._saveInjectiont(item);
        }
      },

      onViewerLinkedClick(linkedType){
        this._onViewerLinkedClick(linkedType);
      },

      onNameLabel(){
        const selectedItem = this.get('acceptPatient.itemsSource').filterBy('isCheck', true);
        if(isEmpty(selectedItem)){
          //선택된내역이 없습니다.
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('11627'), '', 'Ok', 'Ok', 0);
          return;
        }

        const param = {examinationPlanIds: null};
        const examinationIds = selectedItem.getEach('examinationPlanId');
        if(isPresent(examinationIds)){
          param.examinationPlanIds = examinationIds.join('&examinationPlanIds=');
        }

        const path = this.get('defaultUrl') + 'checkins/label-print';
        this.getList(path, param, null, true).then(function (res) {
          if (!isEmpty(res.response)) {
            this.onNameLabelPrint(res.response, this.get('labelPrinter'));
            //this.onNameLabelPrint(res.response, this.get('labelPrinter'), this.get('nameLabelPage'));
          }
        }.bind(this));
      },
    },

    _onViewerLinkedClick(linkedType){
      if(isEmpty(this.get('acceptPatient.selectedItem'))){
        return;
      }

      const item = this.get('acceptPatient.selectedItem');
      const param = {
        patientId: item.patientId,
        examinationPlanId: item.examinationPlanId,
        employeeId: this.get('userGlobalInformation.employeeId'),
        interfaceTypeCode: linkedType
      };

      this.get('peApiService').getPacsLinkAddress(param).then(res => {
        next(this, function(){
          const pacsItem = EmberObject.create();
          res.forEach(e => {
            set(pacsItem, e.displayCode, e.resultValue);
          });
          this.pacsViewerOpen(pacsItem);
        });
      });
    },

    _onCancelPerform(cancelReason){
      if(isEmpty(this.get('acceptPatient.itemsSource'))){
        return;
      }
      const cancelList = emberA();
      this.get('acceptPatient.itemsSource').forEach(e =>{
        if(e.isCheck && e.statusCode == 4) {
          cancelList.addObject(e.examinationConductId);
        }
      });
      if (!cancelList.length) {
        //검사상태를 확인해 주시기 바랍니다.
        this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9288'), '', 'Ok', 'Ok', 0);
        return;
      }
      const cancelInfo = {actionDateTime: this.get('co_CommonService').getNow(),
        actionStaffId: this.get('conditionSet.employeeId'),
        reasonId: cancelReason.reasonId,
        otherReason: cancelReason.otherReason,
        reasonDescription: cancelReason.reasonDescription,
        examinationConductIds: cancelList};

      this.get('peApiService').onPerformCacnel(cancelInfo).then((res) => {
        if(res){
          this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
          this.get('onSearchAllCB')();
        }
      });
    },

    _setCancelItem(cancelRequestList){
      if(!isEmpty(cancelRequestList)){
        this.set('cancelRequestList', cancelRequestList);
        this.set('conductModel.isCancelPopOpen', true);
      }
    },

    _saveInjectiont(item){
      const consentInfo = { examinationPlanId: item.examinationPlanId,
        isInjection: item.isInjection,
        recordStaffId: this.get('userGlobalInformation.employeeId'),
        recordDatetime: this.get('co_CommonService').getNow()};

      this.get('peApiService').onCheckInjection(consentInfo).then((res) => {
        if(res){
          this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
        }else{
          set(item, 'isInjection', !item.isInjection);
          this.get('peApiService').onShowToast('error', this.getLanguageResource('11755', 'F', '저장에 실패했습니다.'), '');
        }
      });
    },

    _questionMessage(messageBoxText){
      return {
        'caption': '',
        'messageBoxImage': 'question',
        'messageBoxButton': 'YesNo',
        'messageBoxText': messageBoxText,
        'messageBoxFocus': 'Yes',
      };
    },

    _onPerformPrint(){
      if(!isEmpty(this.get('onPerformExportCB'))){
        this.get('onPerformExportCB')('Print');
      }
    },

    _getColumnHeader(){
      const header = this.getConductWorklistColumnHeader(this.get('conductModel.pageSorting'));
      if(!isEmpty(this.get('co_CommonService.hospitalAdditionalInfo'))){
        const hospitalInfo = this.get('co_CommonService.hospitalAdditionalInfo');
        if(!isEmpty(hospitalInfo.businesstype) && hospitalInfo.businesstype == 'global'){
          header.removeObject(header.findBy('field', 'insurance'));
        }
      }
      this.set('acceptPatient.gridColumns', header);
    },

    _getExportExcelData() {
      if(!isEmpty(this.get('onPerformExportCB'))){
        this.get('onPerformExportCB')('Excel');
      }
    },

    _onPerformCancel(){
      const cancelRequestList = emberA();
      const validation = EmberObject.create({isMaterial:false, isInterpretation:false, isCheckin:false});

      this.get('acceptPatient.itemsSource').forEach(e =>{
        if(e.isCheck){
          if(e.statusCode == 4){
            cancelRequestList.addObject(e);
            this.ajaxSyncCall(this.get('defaultUrl') + 'conductions/material/' , {procedureRequestId: e.orderId}, 'GET', null, false).done(res => {
              if(res > 0){
                validation.isMaterial=true;
              }
            });
          }else if(e.statusCode == 3){
            validation.isCheckin=true;
          }else if(e.statusCode == 5 && e.statusCode == 6){
            validation.isInterpretation=true;
          }
        }
      });
      next(this, function() {
        if(validation.isInterpretation){
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('12599', 'F', '판독을 삭제해 주시기 바랍니다.'), '', 'Ok', 'Ok', 0);
          return;
        }
        if(validation.isCheckin){
          //검사상태를 확인해 주시기 바랍니다.(접수취소하세요)
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9288'), '', 'Ok', 'Ok', 0);
          return;
        }
        if(isEmpty(cancelRequestList)){
          //검사상태를 확인해 주시기 바랍니다.(해당내역이 없음)
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9288'), '', 'Ok', 'Ok', 0);
          return;
        }
        if(validation.isMaterial){
          const msg = this.getLanguageResource('10674', 'S', '기 발행된 재료가 있습니다. 반납하지 않고 검사를 취소하시겠습니까?');
          const confirmMsg = this.getLanguageResource('8377', 'S', '확인');
          const options = {'messageBoxImage': 'question', 'caption':  confirmMsg, 'messageBoxText': msg,
            'messageBoxButton': 'OKCancel', 'messageBoxFocus' : 'Ok', 'messageboxInterval' : 0};
          messageBox.show(this, options).then((rbutton) => {
            if(rbutton === "Ok"){
              this._setCancelItem(cancelRequestList);
            }
          });
        }else{
          this._setCancelItem(cancelRequestList);
        }
      });
    },
    _getEmployeeOccupation(item){
      if(isEmpty(item)){
        return;
      }
      this.get('peApiService').getEmployeeOccupation(item).then((res) => {
        if(!isEmpty(res) && !isEmpty(res.occupationCode)){
          this.set('userGlobalInformation.occupationCode', res.occupationCode);
        }
      });
    },

    questionPerformMessage(performInfo){
      const msg = this.getLanguageResource('12595', 'F', '시행의사정보가 없습니다. 시행하시겠습니까?');
      const options = this._questionMessage(msg);
      messageBox.show(this, options).then(function (result) {
        if(result === "Yes"){
          this.set('isPageLoader', true);
          this.get('peApiService').onPerform(performInfo).then((res) => {
            if(res){
              this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
              this.get('onSearchAllCB')();
            }else{
              this.set('isPageLoader', false);
            }
          }).finally(function(){
            this.set('isPageLoader', false);
          }.bind(this));
        }
      }.bind(this));
    },

    _getCpacsUsed(){
      this.get('peApiService').cpacsUsed().then(res => {
        next(this, function(){
          if(!isEmpty(res)){
            this.set('isCpacsUsed', true);
          }
        });
      });
    },

    _getViewerMode(){
      this._getCpacsUsed();
    },
  });