import $ from 'jquery';
import { hash } from 'rsvp';
import EmberObject from '@ember/object';
import { isEmpty } from '@ember/utils';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'patientexamination-module/app-config';
import { inject as service } from '@ember/service';
import MesaggeMixin from '../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MesaggeMixin, {
  layout,
  examinationInfo: null,
  examinationInfoClone: null,
  formdisabled: null,
  checkinUrl: null,
  conductUrl: null,
  targetId: null,
  placementTargetId: null,
  isSpecimenReportOpen: false,
  isExaminationEmployeeOpen: false,
  performList: null,
  isPageDetailLoader: false,
  peApiService:service('patientexamination-service'),

  onPropertyInit(){
    this._super(...arguments);
    this.set('viewId', 'patient-examination-detail-information');

    this.setStateProperties([
      'examinationInfo',
      'examinationInfoClone',
      'formdisabled',
      'checkinUrl',
      'conductUrl',
      'targetId',
      'placementTargetId',
      'isSpecimenReportOpen',
      'isExaminationEmployeeOpen',
      'performList',
      'isPageDetailLoader'
    ]);


    if(this.hasState()===false) {

      const checkinUrl = this.get('fr_HostConfigService')
        .getEnvConfig('ServerCallConfig', 'patientexamination') +
        `patient-examination/${config.version}/checkins`;

      const conductUrl = this.get('fr_HostConfigService')
        .getEnvConfig('ServerCallConfig', 'patientexamination') +
        `patient-examination/${config.version}/conductions`;

      this.set('checkinUrl', checkinUrl);
      this.set('conductUrl', conductUrl);

      this.set('formdisabled', false);
      this.set('isPageDetailLoader', false);
    }
    this.send('loadChild');

    //ID 동적으로 부여하기 위해서.. 시간을 사용
    const now = this.get('co_CommonService').getNow();
    const targetId = 'employee_dt' + now.getHours().toString() + now.getMinutes().toString() + now.getSeconds().toString() + now.getMilliseconds().toString();
    this.set('targetId', targetId);
    this.set('placementTargetId', '#'+ targetId);
  },

  onLoaded() {
    this._super(...arguments);

    if (isEmpty(this.get('examinationInfo'))){
      const examinationInfo = EmberObject.create({examinationGroupCode: null});

      this.set('examinationInfo', examinationInfo);
    }
    if (isEmpty(this.get('specimenExaminationInfo'))){
      const specimenExaminationInfo = EmberObject.create({});

      this.set('specimenExaminationInfo', specimenExaminationInfo);
    }

    if(!isEmpty(this.get('co_CurrentUserService.user'))){
      this.set('userGlobalInformation', this.get('co_CurrentUserService.user'));
    }

  },

  actions:{
    loadChild() {
      this.get('registerCB')('patient-examination-detail-information', this);
    },

    onPopupEmployee(){
      this.set('isExaminationEmployeeOpen', true);
    },

    onPerformDoctor(item){
      if(isEmpty(item)){
        return;
      }
      this.set('isExaminationEmployeeOpen', false);

      const perform = this.get('performList').findBy('employeeId', item.employeeId);
      if(isEmpty(perform)){
        this._getPerformDoctor(item.employeeId);
      }else{
        this.set('examinationInfo.executeDoctorId', item.employeeId);
      }
    },

    onClearContrast(){
      if (!isEmpty(this.get('examinationInfo'))){
        this.set('examinationInfo.contrastInfomations.contrastType', null);
      }
    },

    onLinkedSpecimenReportClick(){
      if(isEmpty(this.get('examinationInfo.patientId'))){
        return;
      }
      this.set('isSpecimenReportOpen', true);
    },

    onSaveInformation(){
      this.saveInformation();
    },

    onBodyMeasurement(){
      this._getBodyMeasurement();
    },

    onChangeExecuteDoctor(){
      this.set('isPageDetailLoader', false);
    }
  },

  saveComment(){
    try {
      if(this.get('examinationInfo.examinationComment') !== this.get('examinationInfoClone.examinationComment')){
        const commentpath = this.get('checkinUrl') + '/examination-memos';
        const commentParams = {
          examinationPlanId: this.get('examinationInfo.examinationPlanId'),
          memoTypeCode: 'Conduction',
          examinationComment: this.get('examinationInfo.examinationComment'),
          editStaffId: this.get('userGlobalInformation.employeeId')};
        const commentHash = this.create(commentpath, null, commentParams);
        hash({
          comment: commentHash
        }).then(function(res){
          if(res.comment){
            if(!isEmpty(this.get('saveRefreshCB'))) {
              this.get('saveRefreshCB')();
            }
          }
        }.bind(this));
      }
    }catch(e) {
      if(!this.get('isDestroyed')) {
        this._showSaveError(e);
      }
    }
  },

  saveInformation(){
    try {
      if (isEmpty(this.get('examinationInfo.examinationPlanId'))){
        //처리할 정보를 선택하세요.
        this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9257'), '', 'Ok', 'Ok', 0);
        return;
      }
      const edited = this.editedCheck();
      if(!edited.contrast && !edited.comment && !edited.performDoctor && !edited.performDate && !edited.performRoom){
        const msg = this.getLanguageResource('8999', 'F', '변경내역이 없습니다.');
        this.get('peApiService').onShowToast('message', msg, '');
        return;
      }
      const items = {
        contrast: true,
        comment: true,
        performDoctor: true,
        performDate: true,
        performRoom: true,
      };
      const saved = this.editedSave(items);
      this.set('isPageDetailLoader', true);
      hash({
        comment: saved.commentHash,
        contrast: saved.contrastHash,
        performDoctor: saved.performDoctorHash,
        performDate: saved.performDateHash,
        performRoomDate: saved.performRoomHash
      }).then(function(res){
        if(res.comment && res.contrast && res.performDoctor && res.performRoomDate){
          this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
          this.set('examinationInfoClone', $.extend(true, EmberObject.create(), this.get('examinationInfo')));
          this.set('isPageDetailLoader', false);
          if(!isEmpty(this.get('getSearchCB'))) {
            this.get('getSearchCB')(this.get('examinationInfo'));
          }
        }
      }.bind(this));
    } catch(e) {
      if(!this.get('isDestroyed')) {
        this.set('isPageDetailLoader', false);
        this._showSaveError(e);
      }
    }
  },

  _allClear(){
    this.set('examinationInfo', EmberObject.create());
  },

  editedCheck(){
    const edited = {
      contrast: false,
      comment: false,
      performDoctor: false,
      performDate: false,
      performRoom: false,
    };

    if(isEmpty(this.get('examinationInfoClone'))){
      return edited;
    }
    if(isEmpty(this.get('examinationInfo')) || isEmpty(this.get('examinationInfo.examinationPlanId'))){
      return edited;
    }
    const originInfo= this.get('examinationInfoClone');
    const newInfo= this.get('examinationInfo');

    if(!isEmpty(originInfo.contrastInfomations)){
      if((originInfo.contrastInfomations.height !== newInfo.contrastInfomations.height) ||
        (originInfo.contrastInfomations.weight !== newInfo.contrastInfomations.weight) ||
        (originInfo.contrastInfomations.isInjection !== newInfo.contrastInfomations.isInjection) ||
        (originInfo.contrastInfomations.contrastType !== newInfo.contrastInfomations.contrastType)){
        edited.contrast = true;
      }
    }
    if(this.get('examinationInfo.examinationComment') !== this.get('examinationInfoClone.examinationComment')){
      if(!isEmpty(this.get('examinationInfo.examinationComment')) || !isEmpty(this.get('examinationInfoClone.examinationComment'))){
        edited.comment = true;
      }
    }
    if(this.get('examinationInfo.executeDoctorId') !== this.get('examinationInfoClone.executeDoctorId')){
      edited.performDoctor = true;
    }
    if(this.get('examinationInfo.executeDatetime') !== this.get('examinationInfoClone.executeDatetime')
    || this.get('examinationInfo.executeEndDatetime') !== this.get('examinationInfoClone.executeEndDatetime')){
      edited.performDate = true;
    }
    if(this.get('examinationInfo.examinationRoom.examinationRoomId') !== this.get('examinationInfoClone.examinationRoom.examinationRoomId')){
      edited.performRoom = true;
    }
    return edited;
  },

  // eslint-disable-next-line complexity
  editedSave(items){
    const edited = {
      contrast: false,
      comment: false,
      performDoctor: false,
      performDate: false,
      performRoom: false,
      contrastHash: true,
      commentHash: true,
      performDoctorHash: true,
      performDateHash: true,
      performRoomHash: true
    };

    if(isEmpty(this.get('examinationInfoClone'))){
      return edited;
    }
    if(isEmpty(this.get('examinationInfo')) || isEmpty(this.get('examinationInfo.examinationPlanId'))){
      return edited;
    }
    const originInfo= this.get('examinationInfoClone');
    const newInfo= this.get('examinationInfo');

    if(!isEmpty(originInfo.contrastInfomations) && items.contrast){
      if((originInfo.contrastInfomations.height !== newInfo.contrastInfomations.height) ||
        (originInfo.contrastInfomations.weight !== newInfo.contrastInfomations.weight) ||
        (originInfo.contrastInfomations.isInjection !== newInfo.contrastInfomations.isInjection) ||
        (originInfo.contrastInfomations.contrastType !== newInfo.contrastInfomations.contrastType)){
        edited.contrast = true;
        const contrastpath = this.get('conductUrl') + '/contrast-record';
        const contrastMedia = {
          examinationPlanId: this.get('examinationInfo.examinationPlanId'),
          contrastType: this.get('examinationInfo.contrastInfomations.contrastType'),
          isInjection: this.get('examinationInfo.contrastInfomations.isInjection'),
          recordStaffId: this.get('userGlobalInformation.employeeId'),
          height: this.get('examinationInfo.contrastInfomations.height'),
          weight: this.get('examinationInfo.contrastInfomations.weight')};
        edited.contrastHash = this.create(contrastpath, null, contrastMedia);
      }
    }

    if(this.get('examinationInfo.examinationComment') !== this.get('examinationInfoClone.examinationComment') && items.comment){
      if(!isEmpty(this.get('examinationInfo.examinationComment')) || !isEmpty(this.get('examinationInfoClone.examinationComment'))){
        edited.comment = true;
        const commentpath = this.get('checkinUrl') + '/examination-memos';
        const commentParams = {
          examinationPlanId: this.get('examinationInfo.examinationPlanId'),
          memoTypeCode: 'Conduction',
          examinationComment: this.get('examinationInfo.examinationComment'),
          editStaffId: this.get('userGlobalInformation.employeeId')};
        edited.commentHash = this.create(commentpath, null, commentParams);
      }
    }
    if(this.get('examinationInfo.executeDoctorId') !== this.get('examinationInfoClone.executeDoctorId') && items.performDoctor){
      edited.performDoctor = true;
      const performDoctorpath = this.get('conductUrl') + '/perform-doctor';
      const performDoctorParams = {
        actionDoctorId : this.get('examinationInfo.executeDoctorId'),
        examinationConductIds: [this.get('examinationInfo.examinationConductId')]
      };
      edited.performDoctorHash = this.update(performDoctorpath, null, false, performDoctorParams);
    }
    if((this.get('examinationInfo.executeDatetime') !== this.get('examinationInfoClone.executeDatetime')
    || this.get('examinationInfo.executeEndDatetime') !== this.get('examinationInfoClone.executeEndDatetime')) && items.performDate){
      edited.performDate = true;
      const executeDate = this.get('examinationInfo.executeDatetime');
      const executeEndDate = this.get('examinationInfo.executeEndDatetime');
      const actionDatetime = this._getReturnDateType(executeDate);
      const executeEndDatetime = this._getReturnDateType(executeEndDate);
      const performDatepath = this.get('conductUrl') + '/perform-datetime';
      const performDateParams = {
        actionDatetime : actionDatetime,
        executeEndDatetime : executeEndDatetime,
        examinationConductId: this.get('examinationInfo.examinationConductId')
      };
      edited.performDateHash = this.update(performDatepath, null, false, performDateParams);
    }
    if(this.get('examinationInfo.examinationRoom.examinationRoomId') !== this.get('examinationInfoClone.examinationRoom.examinationRoomId')
      && items.performRoom){
      edited.performRoom = true;
      const performRoompath = this.get('checkinUrl') + '/change-examination-room';
      const performRoomParams = {
        examinationRoomId : this.get('examinationInfo.examinationRoom.examinationRoomId'),
        examinationConductId: this.get('examinationInfo.examinationConductId')
      };
      edited.performRoomHash = this.update(performRoompath, null, false, performRoomParams);
    }
    return edited;
  },

  async _getBodyMeasurement(){
    try {
      if(isEmpty(this.get('examinationInfo.patientId'))){
        return;
      }
      const param = {
        patientId: this.get('examinationInfo.patientId')
      };
      const result = await this.get('peApiService').getBodyMeasurement(param);
      if(!isEmpty(result)) {
        this.set('examinationInfo.contrastInfomations.height', result.height);
        this.set('examinationInfo.contrastInfomations.weight', result.weight);
      }
    } catch(e) {
      if(!this.get('isDestroyed')) {
        this._showError(e);
      }
    }
  },

  _getReturnDateType(pDate){
    if(isEmpty(pDate)){
      return null;
    }
    return new Date(pDate.getFullYear(), pDate.getMonth(), pDate.getDate(), pDate.getHours(), pDate.getMinutes(), 0);
  },

  _getPerformDoctor(employeeId){
    try {
      if(isEmpty(this.get('examinationInfo.examinationGroupCode'))){
        return;
      }
      this.set('performList', []);
      const param = {
        examinationGroupCode: this.get('examinationInfo.examinationGroupCode'),
        relationTypeCode: "PerformDoctor"
      };
      this.get('peApiService').onGetExaminationEmployeeList(param).then(function(data){
        this.set('performList', data);
        this.set('examinationInfo.executeDoctorId', employeeId);
      }.bind(this));
    } catch(e) {
      if(!this.get('isDestroyed')) {
        this._showError(e);
      }
    }
  },

  saveInformationByExecute(){
    try {
      const items = {
        contrast: true,
        comment: true,
        performDoctor: false,
        performDate: true,
        performRoom: true,
      };

      const saved = this.editedSave(items);
      if(!(saved.contrast || saved.comment || saved.performDate || saved.performRoom)){
        if(!isEmpty(this.get('saveRefreshCB'))) {
          this.get('saveRefreshCB')();
        }
        return;
      }
      hash({
        comment: saved.commentHash,
        contrast: saved.contrastHash,
        performDate: saved.performDateHash,
        performRoomDate: saved.performRoomHash
      }).then(function(res){
        if(res.comment && res.contrast && res.performDate && res.performRoomDate){
          this.set('examinationInfoClone', $.extend(true, EmberObject.create(), this.get('examinationInfo')));
          if(!isEmpty(this.get('saveRefreshCB'))) {
            this.get('saveRefreshCB')();
          }
        }
      }.bind(this));
    } catch(e) {
      if(!this.get('isDestroyed')) {
        this._showSaveError(e);
      }
    }
  },
});
