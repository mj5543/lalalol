import { next } from '@ember/runloop';
import { isEmpty } from '@ember/utils';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'patientexamination-module/app-config';
import { inject as service } from '@ember/service';
import MesaggeMixin from '../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MesaggeMixin,{
  layout,
  examination: null,
  checkinUrl: null,
  priorityData: null,
  isMediumLoader: false,
  peApiService:service('patientexamination-service'),

  onPropertyInit() {
    this._super(...arguments);
    this.set('viewId', 'patient-examination-priority-information');

    this.setStateProperties([
      'condition',
      'examination',
      'checkinUrl',
      'priorityData',
      'isMediumLoader'
    ]);

    if(this.hasState()===false) {
      const checkinUrl = this.get('fr_HostConfigService')
        .getEnvConfig('ServerCallConfig', 'patientexamination') +
        `patient-examination/${config.version}/checkins`;

      this.set('checkinUrl', checkinUrl);

      this.set('priorityColumns', [
        { field: 'examinationCode', title: this.getLanguageResource('802', 'S', '검사코드'), width: 100, align: 'center', readOnly: true },
        { field: 'examinationName', title: this.getLanguageResource('16806', 'S', '검사'), readOnly: true },
        { field: 'appointmentDatetime', title: this.getLanguageResource('5150', 'S', '예약일시'), width: 120, type: 'date', dataFormat: 'g', align: 'center', readOnly: true },
        { field: 'executeDatetime', title: this.getLanguageResource('9925', 'S', '시행일시'), width: 120, type: 'date', dataFormat: 'g', align: 'center', readOnly: true },
      ]);
      this.set('examination', {code: null, name: null, referenceDate: null});
    }
  },

  onLoaded() {
    this._super(...arguments);
    this.set('menuClass', 'w1000');
  },

  actions: {
    onOpened(){
      try {
        if(isEmpty(this.get('condition'))){
          return;
        }
        const condition = this.get('condition');
        this.set('examination', condition);
        const path = this.get('checkinUrl') + '/priority-information';
        const param = {patientId: condition.patientId, examinationId: condition.examinationId, referenceDate: condition.referenceDate };
        this.set('isMediumLoader', true);
        this.getList(path, param, null).then(function (data) {
          this.set('priorityData', data);
          next(this, function(){
            this.set('isMediumLoader', false);
          });
        }.bind(this));
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isMediumLoader', false);
          this._showError(e);
        }
      }
    }
  }
});