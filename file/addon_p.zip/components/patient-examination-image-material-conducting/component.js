import { next } from '@ember/runloop';
import { isEmpty } from '@ember/utils';
import EmberObject, { get, set } from '@ember/object';
import { A as emberA } from '@ember/array';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'patientexamination-module/app-config';
import { inject as service } from '@ember/service';
import MesaggeMixin from '../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MesaggeMixin,{
  layout,
  imageUrl: null,
  model: null,
  print: null,
  cancelRequestList: null,
  userGlobalInformation: null,
  imageMaterialCategoryItems : null,
  imageMaterialCategoryItem : null,
  isPageLoader: false,
  examinationGroupCode: null,
  perform: null,
  labelPrinter: null,
  peApiService:service('patientexamination-service'),

  onPropertyInit() {
    this._super(...arguments);
    this.set('viewId', 'patient-examination-checkin');

    this.setStateProperties([
      'imageUrl',
      'model',
      'print',
      'cancelRequestList',
      'imageMaterialCategoryItems',
      'imageMaterialCategoryItem',
      'userGlobalInformation',
      'isPageLoader',
      'perform',
      'examinationGroupCode'
    ]);

    if(this.hasState()===false) {
      const imageUrl = this.get('fr_HostConfigService')
        .getEnvConfig('ServerCallConfig', 'patientexamination') +
        `patient-examination/${config.version}/image-materials`;

      this.set('imageUrl', imageUrl);

      this.set('imageMaterialGrid',
        {count: null, isCheckAll:false, columns: emberA(), itemsSource: emberA(), selectedItem: EmberObject.create()});

      this.set('imageMaterialGrid.columns', [
        { field: 'isCheck', bodyTemplateName: 'checkbox', width: 50, align: 'center', headerTemplateName: 'checkall' },
        { field: 'patientInformation.patientName', title: this.getLanguageResource('4184', 'S', '환자명'), align: 'center', width: 100},
        { field: 'patientInformation.patientCode', title: this.getLanguageResource('8451', 'S', '등록번호'), width: 80, align: 'center'},
        { field: 'patientInformation.gender', title: this.getLanguageResource('3680', 'S', '성별'), width: 40, align: 'center'},
        { field: 'examinationPlan.order.examination.displayCode', title: this.getLanguageResource('16919', 'S', '검사코드'), width: 100, align: 'center'},
        { field: 'examinationPlan.order.examination.name', title: this.getLanguageResource('16806', 'S', '검사'), bodyTemplateName:'tooltip'},
        { field: 'accessNumber', title: 'AccessNumber', width: 120},
        { field: 'examinationPlan.payment.name', title: this.getLanguageResource('3859', 'S', '수납'), width: 60, align: 'center', bodyTemplateName:'paid' },
        { field: 'examinationPlan.order.issuedDate', title: this.getLanguageResource('5246', 'F', '오더일'), width: 80, type: 'date', dataFormat: 'd', align: 'center' },
        { field: 'examinationPlan.order.issuedStaffName', title: this.getLanguageResource('9686', 'S', '처방의'), width: 80, align: 'center'},
        { field: 'examinationPlan.encounter.patientTypeName', title: this.getLanguageResource('8421', 'S', '환자구분'), width: 70, align: 'center'},
        { field: 'examinationPlan.encounter.medicalDepartment.name', title: this.getLanguageResource('7111', 'S', '진료과'), width: 100, align: 'center'},
        { field: 'occupyingLocation', title: this.getLanguageResource('3325', 'S', '현위치'), width: 70, align: 'center', bodyTemplateName:'location'},
        { field: 'examinationPlan.status.name', title: this.getLanguageResource('732', 'S', '검사상태'), width: 80, align: 'center', bodyTemplateName:'status'},
        { field: 'examinationPlan.order.orderDetail', title: this.getLanguageResource('3173', 'S', '비고'), width: 40, align: 'center', bodyTemplateName: 'comments'},
        { field: 'executeDateTime', title: this.getLanguageResource('17047', 'S', '시행일시'), width: 110, type: 'date', dataFormat: 'g', align: 'center' },
        { field: 'executeStaff.name', title: this.getLanguageResource('17048', 'S', '시행자'), width: 80, align: 'center'},
        { field: 'pacsConfirm', title: 'IMG', width:30, align: 'center'}
      ]);

      this.set('model',
        EmberObject.create({
          selectedDate: null,
          patientTypeList:null,
          patientType: null,
          isAll: false,
          isAutoPrint: false,
          isCancelPopOpen:false,
          imageMaterialSubCategoryCode: null}));
      this.set('print', EmberObject.create({printPopup: null, printConfig: null, printContent: null}));
      this.set('perform', EmberObject.create({examinationRoomCode: null}));
      this.set('examinationGroupCode', 'DR');
    }
  },

  onLoaded() {
    this._super(...arguments);
    this.set('menuClass', 'w1450');

    if(!isEmpty(this.get('co_CurrentUserService.user'))){
      this.set('userGlobalInformation', this.get('co_CurrentUserService.user'));
    }

    this._initControl();
    this._getPeSettingInfo();
    this._getPrinterSettingInfo();
  },

  actions: {
    onImageMaterialCategoryChanged(item){
      if(!isEmpty(item)){
        this.set('model.imageMaterialCategoryCode', item.businessCode);
      }else{
        this.set('model.imageMaterialCategoryCode', null);
      }
    },

    onCheckchanged(){
      this.set('imageMaterialGrid.isCheckAll', false);
    },

    onCheckAllchanged(){
      if(isEmpty(this.get('imageMaterialGrid.itemsSource'))){
        return;
      }

      this.get('imageMaterialGrid.itemsSource').map(item =>{
        set(item, 'isCheck', !this.get('imageMaterialGrid.isCheckAll'));

        return item;
      });
    },

    onCopyAccessCode(){
      /* if(Ember.isEmpty(this.get('imageMaterialGrid.selectedItem'))){
        return;
      } */

    },

    onGetImageMaterialList(){
      this._getImageMaterialList();
    },

    onCheckinClick(){
      this.onProgress(3);
    },

    onPerformClick(){
      this.onProgress(4);
    },

    onPerformCancelClick(){
      if(isEmpty(this.get('imageMaterialGrid.itemsSource'))){
        return;
      }
      if (isEmpty(this.get('imageMaterialGrid.itemsSource').findBy('isCheck', true))){
        //처리할 내역을 선택하세요
        this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9286'), '', 'Ok', 'Ok', 0);
        return;
      }
      const cancelRequestList = emberA();
      const validation = EmberObject.create({isMaterial:false, isInterpretation:false, isCheckin:false});

      this.get('imageMaterialGrid.itemsSource').forEach(e =>{
        if(e.isCheck){
          if(e.examinationPlan.status.id == 4 || e.examinationPlan.status.id == 3){
            cancelRequestList.addObject(e.examinationConductId);
          }else if(e.examinationPlan.status.id == 5 && e.examinationPlan.status.id == 6){
            validation.isInterpretation=true;
          }
        }
      });
      next(this, function() {
        if(validation.isInterpretation){
          const msg = this.getLanguageResource('12599', 'F', '판독을 삭제해 주시기 바랍니다.');
          this.get('peApiService').onDisplayMessage('warning', msg, '', 'Ok', 'Ok', 0);
          return;
        }
        if(validation.isCheckin){
          //검사상태를 확인해 주시기 바랍니다.(접수취소하세요)
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9288'), '', 'Ok', 'Ok', 0);
          return;
        }
        if(isEmpty(cancelRequestList)){
          //검사상태를 확인해 주시기 바랍니다.(해당내역이 없음)
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9288'), '', 'Ok', 'Ok', 0);
          return;
        }
        if(validation.isMaterial){
          const msg = this.getLanguageResource('10674', 'S', '기 발행된 재료가 있습니다. 반납하지 않고 검사를 취소하시겠습니까?');
          const confirmMsg = this.getLanguageResource('8377', 'S', '확인');
          const options = {'messageBoxImage': 'question', 'caption': confirmMsg, 'messageBoxText': msg,
            'messageBoxButton': 'OKCancel', 'messageBoxFocus' : 'Ok', 'messageboxInterval' : 0};
          messageBox.show(this, options).then((rbutton) => {
            if(rbutton === "Ok"){
              this._onCancelPerform(cancelRequestList);
            }
          });
        }else{
          this._onCancelPerform(cancelRequestList);
        }
      });
    },

    onNameCardClick(){
      if(isEmpty(this.get('imageMaterialGrid.itemsSource'))){
        return;
      }
      const nameLabelPringList = emberA();
      this.get('imageMaterialGrid.itemsSource').forEach(e =>{
        if(e.isCheck){
          nameLabelPringList.addObject(e);
        }
      });

      if(!isEmpty(nameLabelPringList)){
        this._onPrintNameCard(nameLabelPringList);
      }
    },

    onAutoPrinterChanged(){
      next(this, function(){
        this._setPeSettingInfo();
      });
    },

    onExaminationRoomChanged(){
      this._setPeSettingInfo();
    }
  },


  _getImageMaterialList(){
    try {
      this.set('imageMaterialGrid.itemsSource', emberA());
      this.set('imageMaterialGrid.isCheckAll', false);
      this.set('imageMaterialGrid.count', null);
      if(isEmpty(this.get('model.selectedDate'))){
        return;
      }
      const selectedDate = this.get('model.selectedDate');
      const issuedDate = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate(), 0, 0, 0);
      const path = this.get('imageUrl');
      const param = {
        acceptDate: issuedDate,
        patientType: this.get('model.patientType'),
        isAll: this.get('model.isAll'),
        imageCategoryCode: this.get('model.imageMaterialCategoryCode'),
        imageSubCategoryCode: this.get('model.imageMaterialSubCategoryCode'),
      };
      this.set('isPageLoader', true);
      this.getList(path, param, null, true).then(function(res){
        if(!isEmpty(res.response)){
          res.response.map(item =>{
            if(isEmpty(item.guideName)){
              set(item, 'guideName', item.examinationPlan.order.examination.name);
            }
            set(item, 'occupyingLocation', this.getOccupyingDate(item, 'code'));
            set(item, 'occupyingLocationName', this.getOccupyingDate(item, 'name'));
            return item;
          });
          this.set('imageMaterialGrid.itemsSource', res.response);
          this.set('imageMaterialGrid.count', res.response.length);
        }
        next(this, function(){
          this.set('isPageLoader', false);
        });
      }.bind(this));
    } catch(e) {
      if(!this.get('isDestroyed')) {
        this.set('isPageLoader', false);
        this._showError(e);
      }
    }
  },

  _onPrintNameCard(item){
    if(isEmpty(item)){
      return;
    }

    const printerName = this.get('labelPrinter');
    const examinationInfo= emberA();
    const printContent = emberA({
      parameterField: {},
      dataField : emberA(),
    });

    item.forEach(e => {
      let printDate = e.issuedDate;
      if(!isEmpty(e.acceptDateTime)){
        printDate = e.acceptDateTime;
      }
      examinationInfo.pushObject({
        "patientName" : e.patientInformation.patientName + ' (' + e.patientInformation.gender + '/' + e.patientInformation.age + ')',
        "gender" : e.patientInformation.gender,
        "birthday" : this.get('fr_I18nService').formatDate(e.patientInformation.birthDay, 'd'),
        "patientDisplayID": e.patientInformation.patientCode,
        "examinationName" : e.guideName,
        "dateType" : this.getLanguageResource('789', 'S'),
        "date" : this.get('fr_I18nService').formatDate(printDate, 'd'),
        "time" : this.get('fr_I18nService').formatDate(printDate, 't'),
        "age" : e.patientInformation.age,
        "hospitalName": e.hospitalName
      });
    });

    printContent.dataField = { "imageMaterialLabel": examinationInfo };
    this.set('printPopup', false);
    this.set('print', EmberObject.create({printPopup: false,
      printConfig: {
        'printType': 1,
        'printName': 'ImageMaterialLabel',
        'commonInformation' : false,
        'printerName': printerName
      },
      printContent: printContent
    }));
  },

  _onCancelPerform(){
    try {
      if(isEmpty(this.get('imageMaterialGrid.itemsSource'))){
        return;
      }
      const cancelList = emberA();
      this.get('imageMaterialGrid.itemsSource').forEach(e =>{
        if(e.isCheck && (e.examinationPlan.status.id == 4 || e.examinationPlan.status.id == 3)) {
          cancelList.addObject(e.examinationConductId);
        }
      });
      if (!cancelList.length) {
        //검사상태를 확인해 주시기 바랍니다.
        this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9288'), '', 'Ok', 'Ok', 0);
        return;
      }
      const cancelInfo = {
        actionDateTime: this.get('co_CommonService').getNow(),
        actionStaffId: this.get('userGlobalInformation.employeeId'),
        examinationConductIds: cancelList
      };
      const path = this.get('imageUrl') + '/cancel';
      this.update(path, null, false, cancelInfo, true).then((res) => {
        if(res){
          this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
          this._getImageMaterialList();
        }
      });
    } catch(e) {
      if(!this.get('isDestroyed')) {
        this.set('isPageLoader', false);
        this._showSaveError(e);
      }
    }
  },

  _initControl(){
    const now = this.get('co_CommonService').getNow();
    this.set('model.selectedDate', now);
    this.get('peApiService').onGetBusinessCodeList('PatientType', null).then(function(data){
      this.set('model.patientTypeList', data);
      this.set('model.patientType', null);
      /* Ember.run.next(this, function(){
        this._getImageMaterialList();
      }); */
    }.bind(this));

    this.set('imageMaterialCategoryItems', emberA());
    this.get('peApiService').onGetBusinessCodeList('ImageMaterialSubCategory', null).then(function(res){
      this.get('imageMaterialCategoryItems').pushObjects(res);
      this.get('imageMaterialCategoryItems').forEach(e => {
        this.get('peApiService').onGetBusinessCodeList(e.businessCode, null).then(data => {
          set(e, 'subCategoryItem', data);
        });
      });
    }.bind(this));
  },

  onProgress(requestStatusCode){
    if (isEmpty(this.get('imageMaterialGrid.itemsSource'))) {
      return;
    }

    if (isEmpty(this.get('imageMaterialGrid.itemsSource').findBy('isCheck', true))){
      //처리할 내역을 선택하세요
      this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9286'), '', 'Ok', 'Ok', 0);
      return;
    }

    const registerExaminationList = emberA();
    const registerItems = emberA();
    const validation = {isRefund: false};

    this.get('imageMaterialGrid.itemsSource').forEach(e => {
      if(e.isCheck && (e.examinationPlan.status.id == 1 ||
          e.examinationPlan.status.id == 2 ||
          e.examinationPlan.status.id == 3 ||
          e.examinationPlan.status.id == 7)){
        if(e.examinationPlan.payment.id === "Refund"){
          validation.isRefund = true;
        }
        let examinationRoomId = null;
        if(!isEmpty(this.get('perform')) && !isEmpty(this.get('perform.examinationRoomId'))){
          examinationRoomId = this.get('perform.examinationRoomId');
        }

        registerItems.addObject(e);
        const registerExamination = {
          examinationPlanId: e.examinationPlanId,
          examinationRoomId: examinationRoomId,
          statuscode: requestStatusCode
        };
        registerExaminationList.pushObject(registerExamination);
      }
    });
    if(validation.isRefund){
      //환불된 처방입니다.
      this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9285'), '', 'Ok', 'Ok', 0);
      return;
    }
    const now = this.get('co_CommonService').getNow();
    const registerInfo = {
      acceptDateTime: now,
      acceptStaffId: this.get('userGlobalInformation.employeeId'),
      equipmentId: null,
      actionDoctorId: '',
      registerImageMaterial: registerExaminationList
    };
    if (!registerExaminationList.length) {
      //검사상태를 확인해 주시기 바랍니다.
      this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9288'), '', 'Ok', 'Ok', 0);
      return;
    }
    this.get('peApiService').onImageProgress(registerInfo).then((res) => {
      if(res){
        this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
        this._getImageMaterialList();
        next(this, function(){
          if(this.get('model.isAutoPrint') && (requestStatusCode == '4')){
            this._onPrintNameCard(registerItems);
          }
        });
      }
    });
  },

  async _setPeSettingInfo(){
    const settingKey = this.get('viewId');
    const settingData = {
      conditionData: [{
        isAutoPrint: this.get('model.isAutoPrint'),
        perform: this.get('perform')
      }]};
    const description = '영상재료 접수시행';
    await this.get('peApiService').setPeSettingInfo(settingKey, settingData, description);
  },

  async _getPeSettingInfo(){
    const settingKey = this.get('viewId');
    const data = await this.get('peApiService').getPeSettingInfo(settingKey);
    if(!isEmpty(data)) {
      const condition = data[0];
      this.set('model.isAutoPrint', condition.isAutoPrint || false);
      if(!isEmpty(condition.perform)){
        this.set('perform', condition.perform);
        if(!isEmpty(condition.perform.examinationGroupCode)){
          this.set('examinationGroupCode', condition.perform.examinationGroupCode);
        }
      }
    }
  },

  async _getPrinterSettingInfo(){
    const category = 'Radiology';
    /* if(this.get('examinationGroupCode') != 'DR'){
      category = 'Clinic';
    } */
    var result = await this.get('co_PersonalizationService').getPersonalPrinterSetting(category, 'print');

    if(!isEmpty(result.get('firstObject'))) {
      const settingValue = JSON.parse(get(result.get('firstObject'), 'settingValue'));
      this.set('settingValue', settingValue);
      if(!isEmpty(settingValue)) {
        if(!isEmpty(settingValue.defaultLabelPrinter)){
          this.set('labelPrinter', settingValue.defaultLabelPrinter);
        }
      }
    }
  },
  getOccupyingDate(item, type){
    if(isEmpty(item)){
      return;
    }

    let location = null;

    if(type == 'code'){
      if(!isEmpty(item.adminWard.displayCode)){
        location = item.adminWard.displayCode;
      }
      if(!isEmpty(item.room.displayCode)){
        location = location + '/ ' + item.room.displayCode;
      }
      if(!isEmpty(item.bed.displayCode)){
        location = location + '/ ' + item.bed.displayCode;
      }
      return location;
    }else{
      if(!isEmpty(item.adminWard.name)){
        location = item.adminWard.name;
      }
      if(!isEmpty(item.room.name)){
        location = location + '/ ' + item.room.name;
      }
      if(!isEmpty(item.bed.name)){
        location = location + '/ ' + item.bed.name;
      }
      return location;
    }
  }
});