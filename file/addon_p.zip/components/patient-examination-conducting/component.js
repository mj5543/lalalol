/* eslint-disable max-lines */
import { hash } from 'rsvp';
import { next } from '@ember/runloop';
import $ from 'jquery';
import { isEmpty } from '@ember/utils';
import { A as emberA } from '@ember/array';
import EmberObject, { set } from '@ember/object';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'patientexamination-module/app-config';
import { inject as service } from '@ember/service';
import PtMixin from '../../mixins/patient-examination-mixin';
import MesaggeMixin from '../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, PtMixin, MesaggeMixin,{
  layout,
  model: null,
  columnheader: null,
  conductingGrid: null,
  otherExaminationGrid: null,
  selectCondition: null,
  userGlobalInformation: null,
  defaultUrl: null,
  conductUrl: null,
  isContrastMediaOpen: false,
  isSedationOpen: false,
  isSideSedationOpen: false,
  isWarnigDisabled: true,
  examinationGroupCode: null,
  isScopeOpen: false,
  patientExaminationId: null,
  performRoom: null,
  performList: null,
  isPageLoader: false,
  patientGlobalInformation: null,
  isCpacsUsed: false,
  isPageDetailLoader: false,
  peApiService:service('patientexamination-service'),

  onPropertyInit(){
    this._super(...arguments);
    this.set('viewId', 'patient-examination-conducting');

    this.setStateProperties([
      'model',
      'columnheader',
      'conductingGrid',
      'otherExaminationGrid',
      'selectCondition',
      'userGlobalInformation',
      'defaultUrl',
      'conductUrl',
      'isContrastMediaOpen',
      'isSideSedationOpen',
      'isSedationOpen',
      'isWarnigDisabled',
      'examinationGroupCode',
      'isScopeOpen',
      'performRoom',
      'performList',
      'isPageLoader',
      'patientGlobalInformation',
      'isCpacsUsed',
      'isPageDetailLoader'
    ]);

    if(this.hasState()===false) {

      const defaultUrl = this.get('fr_HostConfigService')
        .getEnvConfig('ServerCallConfig', 'patientexamination') +
        `patient-examination/${config.version}/`;

      const conductUrl = this.get('fr_HostConfigService')
        .getEnvConfig('ServerCallConfig', 'patientexamination') +
        `patient-examination/${config.version}/conductions`;

      this.set('defaultUrl', defaultUrl);
      this.set('conductUrl', conductUrl);
      this.set('columnheader', { conductingGrid: [
        { field: 'isCheck', bodyTemplateName: 'checkbox', width: 40, align: 'center', headerTemplateName: 'checkall'},
        { title: this.getLanguageResource('3813', 'S','속성'), align: 'center', width: 35, bodyTemplateName:'icon'},
        { field: 'examinationName', title: this.getLanguageResource('16806', 'S', '검사'), align: 'left', bodyTemplateName:'examName'},
        { field: 'acceptDate', title: this.getLanguageResource('17036', 'S', '접수시간'), width:110, type: 'date', dataFormat: 't', align: 'center'},
        { field: 'orderDetail', title: this.getLanguageResource('5228', 'S', '오더비고'), width:60, align: 'center', bodyTemplateName:'detail'},
        { field: 'clinicalFinding', title: this.getLanguageResource('6227','F', '임상비고'), width:60, align: 'center', bodyTemplateName:'detail'},
        { field: 'accessNumber', title: 'AccessNumber', width: 140},
        { field: 'statusName', title: this.getLanguageResource('732', 'S', '검사상태'), width:90, align: 'center', bodyTemplateName:'status'},
        { field: 'pacsConfirm', title: 'IMG', width:30, align: 'center'}],
      otherExaminationGrid: [
        { field: 'examinationName', title: this.getLanguageResource('16806', 'S', '검사'), align: 'left', bodyTemplateName:'examName'},
        { field: 'orderDetail', title: this.getLanguageResource('5228', 'S', '오더비고'), width:60, align: 'center', bodyTemplateName:'detail'},
        { field: 'clinicalFinding', title: this.getLanguageResource('6228','S', '임상소견'), width:60, align: 'center', bodyTemplateName:'detail'},
        { field: 'statusName', title: this.getLanguageResource('732', 'S', '검사상태'), width:90, align: 'center' , bodyTemplateName:'status'} ,
        { field: 'examinationRoom.examinationRoomName', title: this.getLanguageResource('743', 'S', '검사실'), width:100, align: 'center' }]
      });

      this.set('conductingGrid', emberA({itemsSource: emberA(), selectedItem: EmberObject.create()}));
      this.set('otherExaminationGrid', emberA({itemsSource: emberA(), selectedItem: emberA()}));
      this.set('model', {
        waitingRoom: { examinationRoomId: null, examinationRoomCode: null, examinationRoomName: null},
        selectedTabName: 'myRoomTab',
        examinationInfo: null,
        examinationInfoClone: null,
        formdisabled: null,
        isCancelPopOpen: false,
        isAllChecked: true,
        equipmentitems: [{ equipmentId: '', equipmentName: ''}],
        equipment: '',
        isAllGroupChecked: false
      });
    }
    this.set('selectCondition', {patientId: null});
    this.set('isPageLoader', false);

    this.set('isCpacsUsed', false);
    this.set('isPageDetailLoader', false);
  },

  onOpenMenuParamsChanged(item){
    if(!isEmpty(item.patientExaminationId)){
      this.set('patientExaminationId', item.patientExaminationId);
    }
    if(isEmpty(item.performRoom)){
      this.set('performRoom', {examinationRoomId: null, examinationRoomCode: null, examinationRoomName: null});
    }else{
      this.set('performRoom', item.performRoom);
    }
    this.messageCondution(item);
  },


  onLoaded() {
    this._super(...arguments);
    this.set('model.waitingRoom.examinationRoomCode', this.getLanguageResource('743', 'S', '검사실'));
    this._getViewerMode();
    const selectCondition = this.getOpenMenuParams();
    if(!isEmpty(selectCondition)){
      this.set('selectCondition', selectCondition);
      this.set('model.isAllChecked', selectCondition.isChecked);
      this.set('model.waitingRoom', selectCondition.waitingRoom);
      this.set('examinationGroupCode', selectCondition.examinationGroupCode);
      this._getPerformDoctor();
      if(!isEmpty(selectCondition.patientExaminationId)){
        this.set('patientExaminationId', selectCondition.patientExaminationId);
      }
      if(isEmpty(selectCondition.performRoom)){
        this.set('performRoom', {examinationRoomId: null, examinationRoomCode: null, examinationRoomName: null});
      }else{
        this.set('performRoom', selectCondition.performRoom);
      }
      this._getPeSettingInfo();
      //판독검사포함여부 속성관리함에 따라 _getPeSettingInfo 안에서 초기데이터 호출
      //추후 문제가 될 경우 속성관리 빼고 _onGetInitData 직접호출
      //this._onGetInitData();
    }

    if(isEmpty(this.get('performRoom.examinationRoomId'))){
      this._getGolbalItem();
    }

    if(!isEmpty(this.get('co_CurrentUserService.user'))){
      this.set('userGlobalInformation', this.get('co_CurrentUserService.user'));
      this._getEmployeeOccupation(this.get('userGlobalInformation.employeeId'));
    }
    this.set('menuClass', 'w1000');
  },

  onBeforePatientChange(){
    this._super(...arguments);

    const canChange = this._checkSaveInfo();
    if(canChange){
      return true;
    }else{
      return false;
    }
  },

  onPatientChange(canChange){
    this._super(...arguments);
    const msg = this.getLanguageResource('10277', 'S','저장하지 않은 데이터가 있습니다.') +
    this.getLanguageResource('8939', 'S','저장하시겠습니까?');

    if(canChange === false){
      const options = {
        'caption': this.getLanguageResource('10251', 'S','환자 선택 변경 진행중'),
        'messageBoxButton': 'YesNoCancel',
        'messageBoxImage': 'question',
        'messageBoxText': `[${this.get('menuTitle')}]` + msg,
        'messageBoxFocus': 'Yes'
      };

      return messageBox.show(this, options).then(function(result){
        if(result === 'Yes'){
          this._onSaveDetailInfo();
          this.continuePatientChanging();
        }else if(result == 'No'){
          this.continuePatientChanging();
        }else if(result == 'Cancel'){
          this.cancelPatientChanging();
        }
      }.bind(this));
    }
  },

  /* onPatientChanged(patient){
    this._super(...arguments);
    if(isEmpty(patient)){
      this._allClear();
      return;
    }
    this._onGetInfoAfterPatientChanged(patient);
  }, */

  onPatientChanged(patient){
    this._super(...arguments);
    if(isEmpty(patient)){
      this._allClear();
      return;
    }

    if(this.checkPatientDataClear()===true){
      this._allClear();
    }else{
      this._onGetInfoAfterPatientChanged(patient);
    }
  },

  _onGetInfoAfterPatientChanged(patient){
    if(isEmpty(patient) || isEmpty(patient.patientId)){
      return;
    }

    if(!isEmpty(this.get('selectCondition.patientId'))){
      if( patient.patientId !== this.get('selectCondition.patientId')){
        this._setInitInformation(patient);
      }
    }else{
      this._setInitInformation(patient);
    }
  },

  _setInitInformation(patient){
    if(isEmpty(patient) || isEmpty(patient.patientId)){
      return;
    }

    this.set('selectCondition.patientId', patient.patientId);
    this._allClear();

    if(!isEmpty(patient.examination)){
      if(!isEmpty(patient.examination.patientExaminationId)){
        this.set('patientExaminationId', patient.examination.patientExaminationId);
      }
    }
    this._onGetInitData();
  },

  actions:{
    childComponentLoad(componentName, object){
      this.set(componentName, object);
    },

    onAllStatusChanged(){
      const allCheck = this.get('model.isAllChecked');
      const isAllGroupChecked = this.get('model.isAllGroupChecked');
      this._setPeSettingInfo(allCheck, isAllGroupChecked);
    },

    onOtherRoomCheckClick(){
      this._onSelectionOtherRoomExam();

      const allCheck = this.get('model.isAllChecked');
      const isAllGroupChecked = !this.get('model.isAllGroupChecked');
      this._setPeSettingInfo(allCheck, isAllGroupChecked);
    },

    setSavedDetailInfo(item){
      if(!isEmpty(item)){
        this.get('conductingGrid.itemsSource').forEach(function(e){
          if(item.examinationPlanId == e.examinationPlanId){
            set(e, 'examinationComment', item.examinationComment);
            set(e, 'executeDoctorId', item.executeDoctorId);
            set(e, 'height', item.executeDoctorId);
            set(e, 'weight', item.executeDoctorId);
            set(e, 'isInjection', item.executeDoctorId);
            set(e, 'contrastType', item.executeDoctorId);
            set(e, 'executeDatetime', item.executeDoctorId);
            set(e, 'executeEndDatetime', item.executeDoctorId);
            set(e, 'examinationRoomId', item.executeDoctorId);
          }
        });
      }
    },

    onLinkedInboxClick(){
      if(isEmpty(this.get('conductingGrid.selectedItem'))){
        return;
      }

      const items = this.get('peApiService').getInboxParams(this.get('conductingGrid.selectedItem'), this.getLanguageResource('9686', 'S', '처방의'));
      set(items, 'purpose', '');
      this.set('sendInformation', items);
      this.set('isInboxOpen', true);
    },

    onSaveDetailInfo(){
      this._onSaveDetailInfo();
    },

    onCheckchanged(item){
      this.set('conductingGrid.isCheckAll', false);

      next(this, function(){
        if(item.examinationPlanId == this.get('model.examinationInfo.examinationPlanId')){
          this.set('model.examinationInfo.isCheck', item.isCheck);
          this.set('model.examinationInfoClone.isCheck', item.isCheck);
        }
      });
    },

    onCheckAllchanged(){
      if(isEmpty(this.get('conductingGrid.itemsSource'))){
        return;
      }

      this.get('conductingGrid.itemsSource').map(item =>{
        set(item, 'isCheck', !this.get('conductingGrid.isCheckAll'));

        return item;
      });
    },

    onSelectionAcceptChange(){
      this._onGetInitData();
    },

    onSelectionExaminationChange(){
      if(isEmpty(this.get('conductingGrid.selectedItem'))){
        return;
      }

      const item = this.get('conductingGrid.selectedItem');
      if(isEmpty(item.contrastInfomations)){
        set(item, 'contrastInfomations', {height: '', weight: '', contrastType: '', isInjection: false});
      }
      this.set('model.examinationInfo', $.extend(true, EmberObject.create(), item));
      this.set('model.examinationInfoClone', $.extend(true, EmberObject.create(), item));

      const openViewId = 'medicalchargeentry-main-management';
      if (this.get('co_MenuManagerService').checkMenuOpened(openViewId)) {
        this.get('co_MenuManagerService').closeMenu(openViewId);
      }
    },

    onPerformClick(){
      if(isEmpty(this.get('conductingGrid.itemsSource'))){
        return;
      }

      /*의사시행 체크*/
      let isNotDoctorPerform = false;

      if (isEmpty(this.get('conductingGrid.itemsSource').findBy('isCheck', true))){
        //처리할 내역을 선택하세요
        this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9286'), '', 'Ok', 'Ok', 0);
        return;
      }

      let actionDoctorId = null;
      if(!isEmpty(this.get('model.examinationInfo.executeDoctorId'))){
        actionDoctorId = this.get('model.examinationInfo.executeDoctorId');
      }

      let isCanceled = false;
      const modifyExaminationList = emberA();
      this.get('conductingGrid.itemsSource').forEach(e =>{
        if (e.isCheck){
          if(e.statusCode == 3){
            const modifyExamination = {
              examinationConductId: e.examinationConductId,
              examinationPlanId: e.examinationPlanId,
              statuscode: 4,
              examinationRoomId: this.get('model.waitingRoom.examinationRoomId'),
              actionExamDoctorId: actionDoctorId,
            };
            modifyExaminationList.pushObject(modifyExamination);
            if(e.isDoctorPerform && isEmpty(this.get('model.examinationInfo.executeDoctorId'))){
              isNotDoctorPerform = true;
            }
          }else if(e.statusCode == 7){
            isCanceled = true;
          }
        }
      });
      if(isCanceled){
        //취소된 처방입니다.
        this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9267'), '', 'Ok', 'Ok', 0);
        this.set('isPageLoader', false);
        return;
      }

      if (!modifyExaminationList.length) {
        //검사상태를 확인해 주시기 바랍니다.
        this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9288'), '', 'Ok', 'Ok', 0);
        return;
      }

      const performInfo = {
        actionDateTime: this.get('co_CommonService').getNow(),
        actionStaffId: this.get('userGlobalInformation.employeeId'),
        equipmentId: this.get('equipment'),
        actionDoctorId: null,
        modifyExamination: modifyExaminationList
      };

      /*내 검사실 체크*/
      let isNotMyRoom = false;
      if(!isEmpty(this.get('performRoom')) && !isEmpty(this.get('performRoom.examinationRoomId'))){
        if(this.get('model.waitingRoom.examinationRoomId') != this.get('performRoom.examinationRoomId')){
          isNotMyRoom = true;
        }
      }

      if(isNotMyRoom){
        const options = this._questionMessage(this.getLanguageResource('11945', 'F', null, '내 검사실이 아닌 검사를 진행하시겠습니까?'));
        messageBox.show(this, options).then(function (result) {
          if(result === "Yes"){
            if(isNotDoctorPerform){
              this.questionPerformMessage(performInfo);
            }else{
              this.set('isPageLoader', true);
              this.get('peApiService').onPerform(performInfo).then((res) => {
                if(res){
                  this.get('patient-examination-detail-information').saveInformationByExecute();
                  this.set('patientExaminationId', null);
                  this.onSendMessagePatientList();
                }
                next(this, function(){
                  this.set('isPageLoader', false);
                });
              });
            }
          }
        }.bind(this));
      }

      if(isNotDoctorPerform && !isNotMyRoom){
        this.questionPerformMessage(performInfo);
      }

      if(!isNotMyRoom && !isNotDoctorPerform){
        this.get('peApiService').onPerform(performInfo).then((res) => {
          if(res){
            this.get('patient-examination-detail-information').saveInformationByExecute();
            this.set('patientExaminationId', null);
            this.onSendMessagePatientList();
          }
          next(this, function(){
            this.set('isPageLoader', false);
          });
        });
      }
    },

    onRefreshAfterExecute(){
      this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
      this._onSelectionAcceptChange();
    },

    // eslint-disable-next-line max-lines-per-function
    onPerformUndoClick(){
      if(isEmpty(this.get('conductingGrid.itemsSource'))){
        return;
      }

      if (isEmpty(this.get('conductingGrid.itemsSource').findBy('isCheck', true))){
        //처리할 내역을 선택하세요
        this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9286'), '', 'Ok', 'Ok', 0);
        return;
      }

      let isMaterial = false;
      const undoExaminationConductList = emberA();

      this.get('conductingGrid.itemsSource').forEach(e =>{
        if(e.isCheck && e.statusCode == 4) {
          this.ajaxSyncCall(this.get('conductUrl') + '/material/', {procedureRequestId: e.orderId}, 'GET', null, false).done(res => {
            if(res > 0){
              isMaterial=true;
            }
          });
          const undoExaminationConduct = {
            examinationConductId: e.examinationConductId,
            examinationPlanId: e.examinationPlanId,
            statuscode: 3,
            examinationRoomCode: null
          };
          undoExaminationConductList.pushObject(undoExaminationConduct);
        }
      });

      if (!undoExaminationConductList.length) {
        //검사상태를 확인해 주시기 바랍니다.
        this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9288'), '', 'Ok', 'Ok', 0);
        return;
      }

      const undoPerformInfo = {
        actionDate: this.get('co_CommonService').getNow(),
        actionStaffId: this.get('userGlobalInformation.employeeId'),
        undoExaminationConduct: undoExaminationConductList
      };
      if(isEmpty(undoPerformInfo)){
        //검사상태를 확인해 주시기 바랍니다.
        this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9288'), '', 'Ok', 'Ok', 0);
        return;
      }
      if(isMaterial){
        const msg = this.getLanguageResource('12607', 'F', '재료를 먼저 환불해 주시기바랍니다.');
        this.get('peApiService').onDisplayMessage('warning', msg, '', 'Ok', 'Ok', 0);
        return;
      }
      this.set('isPageLoader', true);
      this.get('peApiService').onPerformUndo(undoPerformInfo).then((res) => {
        if(res){
          this.set('patientExaminationId', null);
          this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
          this._onSelectionAcceptChange();
          this.onSendMessagePatientList();
        }
        next(this, function(){
          this.set('isPageLoader', false);
        });
      });
    },

    onPerformCancelClick(){
      if(isEmpty(this.get('conductingGrid.itemsSource'))){
        return;
      }
      if (isEmpty(this.get('conductingGrid.itemsSource').findBy('isCheck', true))){
        //처리할 내역을 선택하세요
        this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9286'), '', 'Ok', 'Ok', 0);
        return;
      }

      const msg = this.getLanguageResource('8941', 'S', '취소하시겠습니까?');
      const options = {'messageBoxImage': 'question', 'caption':  this.getLanguageResource('8377'), 'messageBoxText': msg,
        'messageBoxButton': 'OKCancel', 'messageBoxFocus' : 'Ok', 'messageboxInterval' : 0};
      messageBox.show(this, options).then((rbutton) => {
        if(rbutton === "Ok"){
          this._onPerformCancel();
        }
      });
    },

    onRoomChange(){

      if(!isEmpty(this.get('otherExaminationGrid.selectedItem'))){

        let isNotValid=true;
        const others = this.get('otherExaminationGrid.selectedItem');
        if(isEmpty(others)){
          return;
        }
        others.forEach(e => {
          if(e.examinationGroupCode != this.get('examinationGroupCode')){
            isNotValid = false;
          }
        });

        if(!isNotValid){
          const options = this._questionMessage(this.getLanguageResource('11978', 'F', null, '해당파트 검사가 아닙니다. 변경진행하시겠습니까?'));
          messageBox.show(this, options).then(function (result) {
            if(result === 'Yes'){
              this._changedExaminationRoom();
            }
          }.bind(this));
        }else{
          const options = this._questionMessage(this.getLanguageResource('10675', 'S','해당 검사들의 검사실을 변경하시겠습니까?'));
          messageBox.show(this, options).then(function (result) {
            if(result === 'Yes'){
              this._changedExaminationRoom();
            }
          }.bind(this));
        }
      }
    },

    onOtherListSelectionChange(e){
      if(e.selectedItems.length){
        this.set('otherExaminationGrid.selectedItem', e.selectedItems);
      }
    },

    onSelectedTabchanged(tabItem){
      if(isEmpty(tabItem)){
        return;
      }

      if(tabItem == 'myRoomTab'){
        this.set('model.formdisabled', false);
        if(!isEmpty(this.get('conductingGrid.selectedItem'))){
          const item = this.get('conductingGrid.selectedItem');
          this.set('model.examinationInfo', $.extend(true, EmberObject.create(), item));
          this.set('model.examinationInfoClone', $.extend(true, EmberObject.create(), item));
        }
      }else{
        this.set('model.formdisabled', true);
        this.set('model.examinationInfo', {isPacsInterface: false, isEndoscope: false});
      }
    },

    onMatreialOrder(){
      if(isEmpty(this.get('conductingGrid.selectedItem.examinationPlanId'))){
        return;
      }
      if(this.get('conductingGrid.selectedItem.statusCode') == 3 || this.get('conductingGrid.selectedItem.statusCode') == 7){
        //검사상태를 확인해 주시기 바랍니다.
        this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9288'), '', 'Ok', 'Ok', 0);
        return;
      }

      const path = this.get('defaultUrl') + 'examinations/material';
      const queryParams = {
        examinationId: this.get('conductingGrid.selectedItem.examinationId'),
      };

      const materialList = emberA();

      this.getList(path, queryParams, null, true).then(function(res){
        if(!isEmpty(res.response)){
          if(!isEmpty(res.response)){
            res.response.forEach(e => {
              const material = {
                id : e.materialId,
                code : e.code,
                name : e.name,
                englishName : e.name,
                displaySequence : 0,
                feeCodeType : "S",
                feeRate1 : null,
                feeRate2 : null,
                remark : null,
                useHour : 1,
                useQuantity : 1,
              };

              materialList.pushObject(material);
            });
          }
        }
        next(this, function(){
          const message = { messageTypeCode: 'Issue',
            materialLists: materialList,
            procedureRequestId: this.get('conductingGrid.selectedItem.orderId'),
            encounterId: this.get('conductingGrid.selectedItem.encounterId'),
            departmentId: this.get('conductingGrid.selectedItem.examinationRoom.roomDepartmentId'),
            examinationRoomId: this.get('conductingGrid.selectedItem.examinationRoom.examinationRoomId'),
          };

          if(!this.get('co_MenuManagerService').checkMenuOpened('medicalchargeentry-main-management')) {
            this.get('co_MenuManagerService').openMenu('medicalchargeentry-main-management', message);
          }else{
            this.get('co_ContentMessageService').sendMessage('setDataBindingExaminationMCB', message);
          }
        });
      }.bind(this));
    },

    onReturnMatreial(){
      if(isEmpty(this.get('conductingGrid.selectedItem.examinationPlanId'))){
        return;
      }
      if(isEmpty(this.get('conductingGrid.selectedItem.examinationConductId'))){
        this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9288'), '', 'Ok', 'Ok', 0);
        return;
      }

      const message = { messageTypeCode: 'Return',
        materialLists: [],
        procedureRequestId: this.get('conductingGrid.selectedItem.orderId'),
        encounterId: this.get('conductingGrid.selectedItem.encounterId'),
        departmentId: this.get('conductingGrid.selectedItem.examinationRoom.roomDepartmentId'),
        examinationRoomId: this.get('conductingGrid.selectedItem.examinationRoom.examinationRoomId'),
      };
      if(!this.get('co_MenuManagerService').checkMenuOpened('medicalchargeentry-main-management')) {
        this.get('co_MenuManagerService').openMenu('medicalchargeentry-main-management', message);
      }else{
        this.get('co_ContentMessageService').sendMessage('setDataBindingExaminationMCB', message);
      }
    },

    getSaveCancelReason(item){
      this._onCancelPerform(item);
    },

    onSideEffectClick(){
      if(isEmpty(this.get('model.examinationInfo.examinationPlanId'))){
        return;
      }
      this.set('isContrastMediaOpen', true);
    },

    onSaveSideEffect(isSide){
      this.set('isContrastMediaOpen', false);
      if(isSide){
        this.set('isWarnigDisabled', false);
      }
    },

    onSedationClick(){
      if(isEmpty(this.get('model.examinationInfo.examinationPlanId'))){
        return;
      }
      this.set('isSedationOpen', true);
    },

    onSaveSedation(isSed){
      this.set('isSedationOpen', false);
      if(isSed){
        this.set('isWarnigDisabled', false);
      }
    },

    onSideSedClick(){
      if(isEmpty(this.get('selectCondition.patientId'))){
        return;
      }
      this.set('isSideSedationOpen', true);
    },

    onScopeClick(){
      if(!isEmpty(this.get('conductingGrid.selectedItem'))){
        this.set('isScopeOpen', true);
      }
    },

    onViewerLinkedClick(linkedType){
      this._onViewerLinkedClick(linkedType);
    },
  },

  onSendMessagePatientList(){
    this.get('co_ContentMessageService').sendMessage('messagePatienExaminationMiniRefresh');
    this.get('co_ContentMessageService').sendMessage('messagePatienExaminationRefresh');
  },

  didInsertElement() {
    this._super(...arguments);
    this.get('co_ContentMessageService').subscribeMessage('messageCondution', this.get('currentMenuId'), this, this.messageCondution);
  },

  willDestroyElement() {
    this._super(...arguments);
    this.get('co_ContentMessageService').unsubscribeMessage('messageCondution', this.get('currentMenuId'), this, this.messageCondution);
  },

  messageCondution(selectCondition){
    if(!isEmpty(selectCondition)){
      this.set('model.isAllChecked', selectCondition.isChecked);
      this.set('selectCondition', selectCondition);
      this.set('model.waitingRoom', selectCondition.waitingRoom);
      this.set('examinationGroupCode', selectCondition.examinationGroupCode);
      this._getPerformDoctor();
      this.set('model.selectedTabName', 'myRoomTab');
      this._onGetInitData();
    }
  },

  _onGetInitData(){
    this._onSelectionAcceptChange();
    this._onGetSpecimenResult();
    this.set('isPageDetailLoader', false);
  },

  _allClear(){
    const item = EmberObject.create();
    set(item, 'performDoctors', {performDoctorId: null, performDoctorName: null});

    this.set('conductingGrid', emberA({totalcount: null, itemsSource: emberA(), selectedItem: item}));
    this.set('otherExaminationGrid', emberA({totalcount: null, itemsSource: emberA()}));
    this.set('model.selectedTabName', 'myRoomTab');
    this.set('model.examinationInfo', $.extend(true, EmberObject.create(), item));
    this.set('model.examinationInfoClone', $.extend(true, EmberObject.create(), item));
    this.set('isWarnigDisabled', true);
    this.set('specimenExaminationInfo', {creatineResult:null, gfrResult: null});
  },

  _onSelectionAcceptChange(){

    if(isEmpty(this.get('selectCondition.patientId'))){
      return;
    }else{
      this._allClear();
    }

    if(isEmpty(this.get('selectCondition.acceptDate'))){
      return;
    }
    const patientPath = this.get('defaultUrl') + 'patients';
    const patientParams = {patientId: this.get('selectCondition.patientId')};

    const accept = new Date(this.get('selectCondition.acceptDate'));
    const acceptFrdate = new Date(accept.getFullYear(),accept.getMonth(), accept.getDate(), 0, 0, 0);
    const path = this.get('conductUrl') + '/patient-condutions';
    const queryParams = {
      patientType: 'A',
      acceptDate: acceptFrdate.toFormatString(),
      patientId: this.get('selectCondition.patientId'),
      isAll: this.get('model.isAllChecked'),
    };

    this.set('conductingGrid.isCheckAll', false);
    this.set('conductingGrid.totalcount', '');
    this.set('otherExaminationGrid.totalcount', '');

    hash({
      patientData: this.getList(patientPath, patientParams, null),
      acceptData: this.getList(path, queryParams, null)
    }).then(function(res){
      if(!isEmpty(res.patientData)){
        if(res.patientData.isWarning){
          this.set('isWarnigDisabled', false);
        }
      }
      if(!isEmpty(res.acceptData)){
        const myRoomList = res.acceptData.filterBy('examinationRoom.examinationRoomId', this.get('model.waitingRoom.examinationRoomId'));
        let otherRoomList = res.acceptData.removeObjects(myRoomList);

        if(isEmpty(myRoomList)){
          return;
        }
        myRoomList.forEach(e => {
          set(e, 'isCheck', false);
          set(e, 'point', this._setIconDisplayTooltip(e));
          set(e, 'examinationName', this._getOrderName(e));
        });

        if(!this.get('model.isAllGroupChecked')){
          const filterLists = otherRoomList.filterBy('examinationGroupCode', this.get('examinationGroupCode'));
          otherRoomList = filterLists;
        }

        this.set('conductingGrid', {
          itemsSource: myRoomList,
          selectedItem: myRoomList.get('firstObject'),
          totalcount: myRoomList.length
        });
        if(!isEmpty(this.get('patientExaminationId'))){
          const selectedItem = myRoomList.findBy('examinationPlanId', this.get('patientExaminationId'));
          if(!isEmpty(selectedItem)){
            set(selectedItem, 'isCheck', true);
            this.set('conductingGrid.selectedItem', selectedItem);
          }
        }

        this.set('otherExaminationGrid', {
          itemsSource: otherRoomList,
          totalcount: otherRoomList.length
        });
      }
    }.bind(this));
  },


  _onCancelPerform(cancelReason){
    if(isEmpty(this.get('conductingGrid.itemsSource'))){
      return;
    }

    const cancelList = emberA();
    this.get('conductingGrid.itemsSource').forEach(e =>{
      if(e.isCheck && e.statusCode == 4) {
        cancelList.addObject(e.examinationConductId);
      }
    });
    if (!cancelList.length) {
      //검사상태를 확인해 주시기 바랍니다.
      this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9288'), '', 'Ok', 'Ok', 0);
      return;
    }
    this.set('isPageLoader', true);
    const cancelInfo = {
      actionDateTime: this.get('co_CommonService').getNow(),
      actionStaffId: this.get('userGlobalInformation.employeeId'),
      reasonId: cancelReason.reasonId,
      otherReason: cancelReason.otherReason,
      reasonDescription: cancelReason.reasonDescription,
      examinationConductIds: cancelList
    };

    this.get('peApiService').onPerformCacnel(cancelInfo).then((res) => {
      if(res){
        this.set('patientExaminationId', null);
        this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
        this._onSelectionAcceptChange();
        this.onSendMessagePatientList();
      }
      next(this, function(){
        this.set('isPageLoader', false);
      });
    });
  },

  _setCancelItem(cancelRequestList){
    if(!isEmpty(cancelRequestList)){
      this.set('cancelRequestList', cancelRequestList);
      this.set('model.isCancelPopOpen', true);
    }
  },

  _checkSaveInfo(){
    let isValid = true;
    const condition = this.get('patient-examination-detail-information').editedCheck();
    if(!isEmpty(condition)){
      if(condition.contrast || condition.comment || condition.performDoctor || condition.performDate){
        isValid = false;
      }
    }
    return isValid;
  },

  _onGetSpecimenResult(){
    try {
      if(isEmpty(this.get('selectCondition.patientId'))){
        return;
      }
      const path = this.get('defaultUrl') + 'diagnostic-reports/specimen-examination-report';
      const crParam = {
        patientId: this.get('selectCondition.patientId'),
        examinationType: 'Cr'
      };
      const gfrParam = {
        patientId: this.get('selectCondition.patientId'),
        examinationType: 'EGFR'
      };
      this.set('specimenExaminationInfo', {creatineResult:null, gfrResult: null});
      hash({
        crData: this.getList(path, crParam, null),
        gfrData: this.getList(path, gfrParam, null)
      }).then(function(res){
        if(!isEmpty(res.crData)){
          set(this.get('specimenExaminationInfo'), 'creatineResult', res.crData.displayResult);
        }
        if(!isEmpty(res.gfrData)){
          set(this.get('specimenExaminationInfo'), 'gfrResult', res.gfrData.displayResult);
        }
      }.bind(this));
    } catch(e) {
      if(!this.get('isDestroyed')) {
        this._showError(e);
      }
    }
  },

  _changedExaminationRoom(){
    if(isEmpty(this.get('otherExaminationGrid.selectedItem'))){
      return;
    }
    const path = this.get('defaultUrl') + 'checkins/change-examination-room';
    this.get('otherExaminationGrid.selectedItem').forEach(e =>{

      const queryParams = {
        examinationConductId: e.examinationConductId,
        examinationRoomCode: null,
        examinationRoomId: this.get('model.waitingRoom.examinationRoomId')
      };

      this.update(path, null, false, queryParams).then(function (res) {
        if(res == true){
          this._onSelectionAcceptChange();
          this.set('model.selectedTabName', 'myRoomTab');
        }
      }.bind(this));
    });

  },

  _onSaveDetailInfo(){
    this.get('patient-examination-detail-information').saveInformation();
  },

  _questionMessage(messageBoxText){
    return {
      'caption': '',
      'messageBoxImage': 'question',
      'messageBoxButton': 'YesNo',
      'messageBoxText': messageBoxText,
      'messageBoxFocus': 'Yes',
    };
  },

  _onSelectionOtherRoomExam(){
    try {
      if(isEmpty(this.get('selectCondition.patientId'))){
        return;
      }
      if(isEmpty(this.get('selectCondition.acceptDate'))){
        return;
      }
      const accept = new Date(this.get('selectCondition.acceptDate'));
      const acceptFrdate = new Date(accept.getFullYear(),accept.getMonth(), accept.getDate(), 0, 0, 0);
      const path = this.get('conductUrl') + '/patient-condutions';
      const queryParams = {
        patientType: 'A',
        acceptDate: acceptFrdate.toFormatString(),
        patientId: this.get('selectCondition.patientId'),
        isAll: this.get('model.isAllChecked'),
      };
      this.set('otherExaminationGrid', emberA({totalcount: null, itemsSource: emberA()}));
      this.set('otherExaminationGrid.totalcount', '');
      hash({
        acceptData: this.getList(path, queryParams, null)
      }).then(function(res){
        if(!isEmpty(res.acceptData)){
          const myRoomList = res.acceptData.filterBy('examinationRoom.examinationRoomId', this.get('model.waitingRoom.examinationRoomId'));
          let otherRoomList = res.acceptData.removeObjects(myRoomList);
          if(!this.get('model.isAllGroupChecked')){
            const filterLists = otherRoomList.filterBy('examinationGroupCode', this.get('examinationGroupCode'));
            otherRoomList= filterLists;
          }
          this.set('otherExaminationGrid', {
            itemsSource: otherRoomList,
            totalcount: otherRoomList.length
          });
        }
      }.bind(this));
    } catch(e) {
      if(!this.get('isDestroyed')) {
        this._showError(e);
      }
    }
  },

  _onPerformCancel(){

    const cancelRequestList = emberA();
    const validation = EmberObject.create({isMaterial:false, isInterpretation:false, isCheckin:false});

    this.get('conductingGrid.itemsSource').forEach(e =>{
      if(e.isCheck){
        if(e.statusCode == 4){
          cancelRequestList.addObject(e);
          this.ajaxSyncCall(this.get('conductUrl') + '/material/', {procedureRequestId: e.orderId}, 'GET', null, false).done(res => {
            if(res > 0){
              validation.isMaterial=true;
            }
          });
        }else if(e.statusCode == 3){
          validation.isCheckin=true;
        }else if(e.statusCode == 5 && e.statusCode == 6){
          validation.isInterpretation=true;
        }
      }
    });
    next(this, function() {
      if(validation.isInterpretation){
        this.get('peApiService').onDisplayMessage('warning', '판독을 삭제해 주시기 바랍니다.', '', 'Ok', 'Ok', 0);
        return;
      }
      if(validation.isCheckin){
        //검사상태를 확인해 주시기 바랍니다.(접수취소하세요)
        this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9288'), '', 'Ok', 'Ok', 0);
        return;
      }
      if(isEmpty(cancelRequestList)){
        //검사상태를 확인해 주시기 바랍니다.(해당내역이 없음)
        this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9288'), '', 'Ok', 'Ok', 0);
        return;
      }
      if(validation.isMaterial){
        const msg = this.getLanguageResource('10674', 'S', '기 발행된 재료가 있습니다. 반납하지 않고 검사를 취소하시겠습니까?');
        const options = {'messageBoxImage': 'question', 'caption':  '확인', 'messageBoxText': msg,
          'messageBoxButton': 'OKCancel', 'messageBoxFocus' : 'Ok', 'messageboxInterval' : 0};
        messageBox.show(this, options).then((rbutton) => {
          if(rbutton === "Ok"){
            this._setCancelItem(cancelRequestList);
          }
        });
      }else{
        this._setCancelItem(cancelRequestList);
      }
    });
  },

  async _setPeSettingInfo(isAllChecked, isAllGroupChecked){
    const settingKey = this.get('viewId');
    const settingData = {
      conditionData: [{
        isAllChecked: isAllChecked,
        isAllGroupChecked: isAllGroupChecked
      }]};
    const description = '검사시행';
    await this.get('peApiService').setPeSettingInfo(settingKey, settingData, description);
  },

  async _getPeSettingInfo(){
    const settingKey = this.get('viewId');
    const data = await this.get('peApiService').getPeSettingInfo(settingKey);
    if(!isEmpty(data)) {
      const condition = data[0];
      this.set('model.isAllChecked', condition.isAllChecked);
      this.set('model.isAllGroupChecked', condition.isAllGroupChecked);
      this._onGetInitData();
    }else{
      this._onGetInitData();
    }
  },

  _getEmployeeOccupation(item){
    if(isEmpty(item)){
      return;
    }
    this.get('peApiService').getEmployeeOccupation(item).then((res) => {
      if(!isEmpty(res) && !isEmpty(res.occupationCode)){
        this.set('userGlobalInformation.occupationCode', res.occupationCode);
      }
    });
  },

  questionPerformMessage(performInfo){
    const options = this._questionMessage('시행의사정보가 없습니다. 시행하시겠습니까?');
    messageBox.show(this, options).then(function (result) {
      if(result === "Yes"){
        this.get('peApiService').onPerform(performInfo).then((res) => {
          if(res){
            this.get('patient-examination-detail-information').saveInformationByExecute();
            this.set('patientExaminationId', null);
            this.onSendMessagePatientList();
          }
        });
      }
    }.bind(this));
  },

  _getPerformDoctor(){
    if(isEmpty(this.get('examinationGroupCode'))){
      return;
    }

    this.set('performList', []);
    const param = {
      examinationGroupCode: this.get('examinationGroupCode'),
      relationTypeCode: "PerformDoctor"
    };
    this.get('peApiService').onGetExaminationEmployeeList(param).then(function(data){
      if(!this.get('isDestroyed')) {
        this.set('performList', data);
      }
    }.bind(this));
  },

  _getGolbalItem(){
    if(isEmpty(this.get('co_PatientManagerService.selectedPatient'))){
      return;
    }
    this.set('patientGlobalInformation', this.get('co_PatientManagerService.selectedPatient'));

    if(isEmpty(this.get('patientGlobalInformation.patientId')) || isEmpty(this.get('patientGlobalInformation.examination.patientExaminationId'))){
      return;
    }

    const param = { patientExaminationId: this.get('patientGlobalInformation.examination.patientExaminationId')};
    this.get('peApiService').onGetOrderDatailInfo(param).then(function(res){
      if(!isEmpty(res)){

        const parameters = {
          patientType: 'A',
          acceptDate: this.get('co_CommonService').getNow(),
          patientId : res.patientId,
          waitingRoom: res.examinationRoom,
          isChecked: true,
          performRoom: res.examinationRoom,
          examinationGroupCode: res.examinationGroupCode
        };
        this.messageCondution(parameters);
      }
    }.bind(this));
  },

  _onViewerLinkedClick(linkedType){
    if(isEmpty(this.get('conductingGrid.selectedItem'))){
      return;
    }

    const item = this.get('conductingGrid.selectedItem');
    const param = {
      patientId: this.get('selectCondition.patientId'),
      examinationPlanId: item.examinationPlanId,
      employeeId: this.get('userGlobalInformation.employeeId'),
      interfaceTypeCode: linkedType
    };

    this.get('peApiService').getPacsLinkAddress(param).then(res => {
      next(this, function(){
        const pacsItem = EmberObject.create();
        res.forEach(e => {
          set(pacsItem, e.displayCode, e.resultValue);
        });
        this.pacsViewerOpen(pacsItem);
      });
    });
  },

  _getCpacsUsed(){
    this.get('peApiService').cpacsUsed().then(res => {
      next(this, function(){
        if(!isEmpty(res)){
          this.set('isCpacsUsed', true);
        }
      });
    });
  },

  _getViewerMode(){
    this._getCpacsUsed();
  },
});
