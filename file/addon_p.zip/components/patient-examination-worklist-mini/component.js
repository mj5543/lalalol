import { next } from '@ember/runloop';
import $ from 'jquery';
import EmberObject, { set } from '@ember/object';
import { isEmpty } from '@ember/utils';
import { A as emberA } from '@ember/array';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'patientexamination-module/app-config';
import { inject as service } from '@ember/service';
import MessageMixin from '../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MessageMixin,{
  layout,
  waitingRoom: null,
  acceptPatientData: null,
  examinationRoomStatusColumns: null,
  examinationRoomStatusData: null,
  isSettingVisible: false,
  defaultUrl: null,
  conductUrl:null,
  userGlobalInformation: null,
  examinationGroupCode: null,
  conditionSet: null,
  model: null,
  isMediumPopupLoader: false,
  isMediumLoader: false,
  examinationRoomList: null,
  openWorklistType: null,
  isSettingOpen: false,
  patientExamination: null,
  examinationType: null,
  peApiService:service('patientexamination-service'),

  onPropertyInit(){
    this._super(...arguments);
    this.set('viewId', 'patient-examination-worklist-mini');

    this.setStateProperties([
      'waitingRoom',
      'acceptPatientData',
      'examinationRoomStatusColumns',
      'examinationRoomStatusData',
      'isSettingVisible',
      'defaultUrl',
      'conductUrl',
      'userGlobalInformation',
      'examinationGroupCode',
      'conditionSet',
      'model',
      'isMediumPopupLoader',
      'examinationRoomList',
      'isMediumLoader',
      'openWorklistType',
      'isSettingOpen',
      'patientExamination',
      'examinationType'
    ]);

    if(this.hasState()===false) {

      const defaultUrl = this.get('fr_HostConfigService')
        .getEnvConfig('ServerCallConfig', 'patientexamination') +
        `patient-examination/${config.version}/`;

      const conductUrl = this.get('fr_HostConfigService')
        .getEnvConfig('ServerCallConfig', 'patientexamination') +
        `patient-examination/${config.version}/conductions`;


      this.set('defaultUrl', defaultUrl);
      this.set('conductUrl', conductUrl);

      this.set('model', emberA({
        isStatusOpen: false,
        selectedTypeList: [{ text: this.getLanguageResource('6758', 'S', '접수'), value: 'CheckIn' },
          { text: this.getLanguageResource('14894', 'S', '시행'), value: 'Conduction' }],
        patientTypeList: []
      }));

      this.set('examinationRoomStatusColumns', [
        { field: 'examinationRoomName', title: this.getLanguageResource('743', 'S'), width: 100, align: 'center', bodyTemplateName: 'myRoom'},
        { field: 'wait', title: this.getLanguageResource('6758'), width: 80, align: 'center' },
        { field: 'done', title: this.getLanguageResource('14894'), width: 80, align: 'center' },
      ]);

      this.set('conditionSet', {
        patientType: null,
        selectedDate: this.get('co_CommonService').getNow(),
        isAllStatus: true,
        isAllRoomChecked: true,
        performRoom: {},
        selectedType: 'CheckIn',
        selectedTypeLang: this.getLanguageResource('14894')
      });

      this.set('waitingRoom', EmberObject.create());
      this.set('patientExamination', EmberObject.create());
    }
  },

  onPatientChanged(patient){
    this._super(...arguments);

    if(isEmpty(patient)){
      return;
    }

    if(!isEmpty(patient.examination)){
      if(!isEmpty(patient.examination.patientExaminationId)){
        this.set('patientExamination.examinationPlanId', patient.examination.patientExaminationId);
      }
    }
  },

  onLoaded() {
    this._super(...arguments);
    if(!isEmpty(this.get('co_CurrentUserService.user'))){
      this.set('userGlobalInformation', this.get('co_CurrentUserService.user'));
      set(this.get('conditionSet'), 'employeeId', this.get('userGlobalInformation.employeeId'));
    }

    this.set('examinationType', 'Clinic');
    if(!isEmpty(this.get('parameters'))){
      const examinationGroupCode = this.get('parameters').examinationGroupCode;
      this.set('openWorklistType', examinationGroupCode);
      this.set('examinationGroupCode', examinationGroupCode);
      this.set('examinationType', 'Radiology');
    }

    this.get('peApiService').onGetBusinessCodeList('PatientType', null).then(function(data){
      this.set('model.patientTypeList', data);
      this.set('conditionSet.patientType', null);
    }.bind(this));

    const selectCondition = this.getOpenMenuParams();
    if(!isEmpty(selectCondition)){
      if(!isEmpty(selectCondition)){
        this.set('examinationGroupCode', selectCondition.examinationGroupCode);
        this.set('patientExamination.examinationPlanId', selectCondition.examinationPlanId);
      }

      if(!isEmpty(selectCondition.examinationRoom)){
        this.set('waitingRoom', selectCondition.examinationRoom);
        set(this.get('conditionSet'),'patientType', selectCondition.patientType);
      }
    }
    if(!isEmpty(this.get('examinationGroupCode'))){
      this._setMyRoom();
      this._getRooms();
    }
  },

  actions: {
    onchangedEmployeeGroup(item){
      if(item !== 'DR'){
        this.set('examinationGroupCode', item);
      }
      if(!isEmpty(item)){
        this._roomInfoClear();
        this._setMyRoom();
        this._getRooms();
        this._onSearchAll();
        this._sendMessageChangeExaminationGroup();
      }
    },

    onTypeChanged(){
      this._onSearchAll();
      if(this.get('conditionSet.selectedType') == "Conduction"){
        this.set('conditionSet.selectedTypeLang', this.getLanguageResource('14894'));
      }else{
        this.set('conditionSet.selectedTypeLang', this.getLanguageResource('6758'));
      }
    },

    onSearchAll(){
      this._onSearchAll();
    },

    onRoomCodeCleared() {
      this.set('waitingRoom', EmberObject.create());
    },

    onGetRoomStatus(){
      if(this.get('conditionSet.selectedType') == "Conduction"){
        this.set('examinationRoomStatusColumns', [
          { field: 'examinationRoomName', title: this.getLanguageResource('743', 'S'), width: 100, align: 'left', bodyTemplateName: 'myRoom'},
          { field: 'wait', title: this.getLanguageResource('6758', 'S'), width: 80, align: 'center' },
          { field: 'done', title: this.getLanguageResource('14894', 'S'), width: 80, align: 'center' },
        ]);
      }else{
        this.set('examinationRoomStatusColumns', [
          { field: 'examinationRoomName', title: this.getLanguageResource('743', 'S'), width: 100, align: 'left', bodyTemplateName: 'myRoom'},
          { field: 'done', title: this.getLanguageResource('5083', 'S'), width: 80, align: 'center' },
          { field: 'wait', title: this.getLanguageResource('3204', 'S'), width: 80, align: 'center' },
        ]);
      }
      this._onGetRoomStatus();
    },

    onSelectionRoomChange(e){
      if(!isEmpty(e.item)){
        this.set('waitingRoom', e.item);
        this.set('model.isStatusOpen', false);

        if(this.get('conditionSet.selectedType') == "Conduction"){
          this._onGetAcceptList();
        }else{
          this._onGetAppointmentList();
        }
      }
    },

    onVisibleClick(){
      this.set('isSettingVisible', !this.get('isSettingVisible'));
    },

    onSelectionAppointmentPatient(e){
      if(!isEmpty(e)){
        let encounterId = e.encounterId;
        var param = {procedureRequestId: e.orderId};
        this.get('peApiService').getCurrentEncounter(param).then(function(res){
          if(!isEmpty(res)){
            encounterId = res.encounterId;
            this.patientCheckInInfoSet(e, encounterId);
          }else{
            this.patientCheckInInfoSet(e, encounterId);
          }
        }.bind(this));
      }
    },

    onSelectionCheckinPatient(e){
      if(!isEmpty(e)){
        let encounterId = e.encounterId;
        var param = {procedureRequestId: e.orderId};
        this.get('peApiService').getCurrentEncounter(param).then(function(res){
          if(!isEmpty(res)){
            encounterId = res.encounterId;
            this.patientConductInfoSet(e, encounterId);
          }else{
            this.patientConductInfoSet(e, encounterId);
          }
        }.bind(this));
      }
    },

    onGetPatient(result) {
      if(!isEmpty(result)){
        let viewType = '';
        if(this.get('examinationGroupCode') === 'DR'){
          viewType = '_radiology';
        }

        const globalItem = {
          patientChoicePath: 'Patient',
          patientId: result.patientId,
          encounterId: null,
          examination:{
            state: 'Checkin',
            patientExaminationId: null,
          },
          patientSelectionSource: {
            viewId:  this.get('viewId') + viewType
          }
        };

        const menuInfo = emberA();
        menuInfo.addObject({
          displayCode: 'patient-examination-checkin' + viewType,
          stateType: 'Checkin',
          parameters: {
            examinationGroupCode: this.get('examinationGroupCode')
          }
        });
        this.get('co_PatientManagerService').selectPatient(globalItem, menuInfo);
      }
    },

    onSetPerformRoom(){
      this.set('isSettingOpen', true);
    },

    setPersonalRoom(item){
      if(!isEmpty(item)){
        if(isEmpty(this.get('examinationGroupCode')) || item.examinationGroupCode == this.get('examinationGroupCode')){
          this.set('performRoom', item);
        }else{
          this.set('performRoom', {});
        }
      }else{
        this.set('performRoom', {});
      }
    },
  },

  didInsertElement() {
    this._super(...arguments);
    this.get('co_ContentMessageService').subscribeMessage('messagePatienExaminationMiniRefresh', this.get('currentMenuId'), this, this.messagePatienExaminationMiniRefresh);
    this.get('co_ContentMessageService').subscribeMessage('messagePatienExaminationMiniSetting', this.get('currentMenuId'), this, this.messagePatienExaminationMiniSetting);
    this.get('co_ContentMessageService').subscribeMessage('messageChangeExaminationGroup', this.get('currentMenuId'), this, this.messageChangeExaminationGroup);
  },

  willDestroyElement() {
    this._super(...arguments);
    this.get('co_ContentMessageService').unsubscribeMessage('messagePatienExaminationMiniRefresh', this.get('currentMenuId'), this, this.messagePatienExaminationMiniRefresh);
    this.get('co_ContentMessageService').unsubscribeMessage('messagePatienExaminationMiniSetting', this.get('currentMenuId'), this, this.messagePatienExaminationMiniSetting);
    this.get('co_ContentMessageService').subscribeMessage('messageChangeExaminationGroup', this.get('currentMenuId'), this, this.messageChangeExaminationGroup);
  },

  messagePatienExaminationMiniRefresh(){
    this._onSearchAll();
  },

  messagePatienExaminationMiniSetting(selectCondition){
    this.set('waitingRoom', selectCondition.examinationRoom);
    this.set('conditionSet.selectedType', selectCondition.selectedType);
    this.set('examinationGroupCode', selectCondition.examinationGroupCode);
    set(this.get('conditionSet'),'patientType', selectCondition.patientType);
    this.set('patientExamination.examinationPlanId', selectCondition.examinationPlanId);
    this._onSearchAll();
  },

  messageChangeExaminationGroup(message){
    //본인이 발생한 메세지 Return
    if(message.viewId.substring(0, 32) === this.get('viewId') && message.viewId.indexOf('mini') > 0){
      return;
    }
    //영상은 제외필요
    if(!isEmpty(message.examinationGroupCode) && message.viewId.indexOf('_radiology') < 0
      && this.get('examinationGroupCode') != 'DR'){
      this.set('examinationGroupCode', message.examinationGroupCode);
    }
  },

  _sendMessageChangeExaminationGroup(){
    if(isEmpty(this.get('examinationGroupCode'))){
      return;
    }

    let viewType = '';
    if(this.get('examinationGroupCode') === 'DR'){
      viewType = '_radiology';
    }

    const message = { examinationGroupCode : this.get('examinationGroupCode'), viewId:  this.get('viewId') + viewType};
    this.get('co_ContentMessageService').sendMessage('messageChangeExaminationGroup', message);
  },


  _onGetAppointmentList(){
    this.set('acceptPatientData', emberA());
    if(isEmpty(this.get('waitingRoom.examinationRoomId'))){
      return;
    }
    const item = $.extend(true, EmberObject.create(), this.get('conditionSet'));
    set(item, 'examinationRoomId', this.get('waitingRoom.examinationRoomId'));
    set(item, 'examinationGroupCode', this.get('examinationGroupCode'));
    set(item, 'addAccept', this.get('conditionSet.isAllStatus'));
    set(item, 'fromDate', this.get('conditionSet.selectedDate'));
    set(item, 'toDate', this.get('conditionSet.selectedDate'));
    this.set('isMediumLoader', true);
    this.get('peApiService').onGetAppointmentList(item).then(function(res){
      if(!isEmpty(res)){
        this.set('acceptPatientData', res);
      }
      next(this, function(){
        this.set('isMediumLoader', false);
      });
    }.bind(this));


  },

  _onGetAcceptList(){
    try {
      this.set('acceptPatientData', emberA());
      if(isEmpty(this.get('waitingRoom.examinationRoomId'))){
        return;
      }
      const item = $.extend(true, EmberObject.create(), this.get('conditionSet'));
      set(item, 'examinationRoomId', this.get('waitingRoom.examinationRoomId'));
      set(item, 'examinationGroupCode', this.get('examinationGroupCode'));
      set(item, 'addAccept', false);
      this.set('isMediumLoader', true);
      this.get('peApiService').onGetAcceptList(item).then(function(res){
        if(!isEmpty(res)){
          this.set('acceptPatientData', res);
        }
        next(this, function(){
          this.set('isMediumLoader', false);
        });
      }.bind(this));
    } catch(e) {
      if(!this.get('isDestroyed')) {
        this.set('isMediumPopupLoader', false);
        this._showError(e);
      }
    }
  },

  async _onGetRoomStatus(){
    try {
      this.set('examinationRoomStatusData', emberA());
      const item = $.extend(true, EmberObject.create(), this.get('conditionSet'));
      set(item, 'examinationGroupCode', this.get('examinationGroupCode'));
      set(item, 'fromDate', this.get('conditionSet.selectedDate'));
      set(item, 'toDate', this.get('conditionSet.selectedDate'));
      set(item, 'addStatus', true);
      set(item, 'examinationType', this.get('examinationType'));
      this.set('isMediumPopupLoader', true);
      const result = await this.get('peApiService').onGetRoomStatus(item);
      if(!isEmpty(result)){
        const resultDate = emberA();
        result.forEach(element => {
          resultDate.addObjects(element.roomStatus);
        });
        this.set('examinationRoomStatusData', resultDate);
      }
      this.set('isMediumPopupLoader', false);
    } catch(e) {
      if(!this.get('isDestroyed')) {
        this.set('isMediumPopupLoader', false);
        this._showError(e);
      }
    }
  },

  _setMyRoom(){
    this.get('peApiService').getMyRoomInfo(this.get('userGlobalInformation.employeeId'),
      this.get('examinationGroupCode'), null, this.get('examinationType')).then(function(res){
      if(!isEmpty(res)){
        const myroom = res.findBy('isRepresentative', true);

        this.set('conditionSet.performRoom', myroom);
        if(isEmpty(this.get('waitingRoom.examinationRoomCode'))){
          this.set('waitingRoom', myroom);
        }
      }else{
        //todo - 근무검사실 셋팅
        this.set('conditionSet.performRoom', {examinationRoomCode: null});
      }
      next(this, function(){
        this._onSearchAll();
      });
    }.bind(this));
  },

  _getRooms(){
    this.get('peApiService').getRoomList(this.get('userGlobalInformation.employeeId'), this.get('examinationGroupCode')).then(function(res){
      if(!isEmpty(res)){
        this.set('examinationRoomList', res);
      }
    }.bind(this));
  },

  _onSearchAll(){
    //this._onGetRoomStatus();
    if(this.get('conditionSet.selectedType') == "Conduction"){
      this._onGetAcceptList();
    }else{
      this._onGetAppointmentList();
    }
  },

  _roomInfoClear(){
    this.set('waitingRoom', {});
    this.set('acceptPatientData', emberA());
  },

  patientConductInfoSet(e, encounterId){
    if(!isEmpty(e)){
      let viewType = '';
      if(this.get('examinationGroupCode') === 'DR'){
        viewType = '_radiology';
      }

      const globalItem = {
        patientChoicePath: 'Encounter',
        patientId: e.patientId,
        encounterId: encounterId,
        examination:{
          state: e.procedureExecutionStatusCode,
          patientExaminationId: e.examinationPlanId,
        },
        patientSelectionSource: {
          viewId:  this.get('viewId') + viewType
        }
      };

      const menuInfo = emberA();
      menuInfo.addObject({
        displayCode: 'patient-examination-conducting' + viewType,
        stateType: null,
        parameters: {
          patientType: this.get('conditionSet').patientType,
          acceptDate: e.acceptDate,
          patientId : e.patientId,
          waitingRoom:  {examinationRoomId: e.examinationRoomId,
            examinationRoomCode: e.examinationRoomCode,
            examinationRoomName: e.examinationRoomName},
          isChecked: this.get('conditionSet').isAllStatus,
          examinationGroupCode: this.get('examinationGroupCode'),
          patientExaminationId: e.examinationPlanId,
        }
      });
      this.get('co_PatientManagerService').selectPatient(globalItem, menuInfo);
    }
  },

  patientCheckInInfoSet(e, encounterId){
    if(!isEmpty(e)){
      let viewType = '';
      if(this.get('examinationGroupCode') === 'DR'){
        viewType = '_radiology';
      }

      const globalItem = {
        patientChoicePath: 'Encounter',
        patientId: e.patientId,
        encounterId: encounterId,
        examination:{
          state: e.procedureExecutionStatusCode,
          patientExaminationId: e.examinationPlanId,
        },
        patientSelectionSource: {
          viewId:  this.get('viewId') + viewType
        }
      };

      const menuInfo = emberA();
      menuInfo.addObject({
        displayCode: 'patient-examination-checkin' + viewType,
        stateType: e.procedureExecutionStatusCode,
        parameters: {
          examinationGroupCode: this.get('examinationGroupCode'),
          scheduleDate: e.scheduleDate,
          patientExaminationId: e.examinationPlanId,
        }
      });
      this.get('co_PatientManagerService').selectPatient(globalItem, menuInfo);
    }
  },
});