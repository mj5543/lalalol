import { isEmpty } from '@ember/utils';
import { A as emberA } from '@ember/array';
import EmberObject from '@ember/object';
import config from 'patientexamination-module/app-config';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import MessageMixin from '../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  MessageMixin,
  {
    layout,
    actorItems: null,
    examinationInfo: null,
    isOpened: true,
    userGlobalInformation: null,
    peApiService:service('patientexamination-service'),

    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId', 'patient-examination-scheduling');

      this.setStateProperties([
        'actorItems',
        'examinationInfo',
        'defaultUrl',
        'isOpened',
        'userGlobalInformation',
      ]);

      if(this.hasState()===false) {
        this.set('actorItems', emberA());

        const defaultUrl = this.get('fr_HostConfigService')
          .getEnvConfig('ServerCallConfig', 'patientexamination') +
          `patient-examination/${config.version}/`;

        this.set('defaultUrl', defaultUrl);
      }
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1000');

      if(!isEmpty(this.get('co_CurrentUserService.user'))){
        this.set('userGlobalInformation', this.get('co_CurrentUserService.user'));
      }
    },

    actions :{
      onPopOpen(){
        this._getActorItem();
        this.set('schedulingComment', null);
        const now = this.get('co_CommonService').getNow();
        this.set('schedulingDatetime', now.addMinutes(2));
      },

      onCancel(){
        this.set('isAppointmentPopupOpen', false);
        this.set('examinationInfo', EmberObject.create());
      },

      onSave(){
        try {
          if(isEmpty(this.get('examinationInfo'))){
            //항목을 선택하세요.
            this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9260', 'F', '항목을 선택하세요.'), '', 'Ok', 'Ok', 0);
            return;
          }
          if(!this._validationCheck()){
            return;
          }
          this.set('isAppointmentPopupOpen', false);
          const path = this.get('defaultUrl') + "scheduling";
          const params = {
            examinationPlanId: this.get('examinationInfo.examinationPlanId'),
            appointmentDateTime: this.get('schedulingDatetime'),
            examinationRoomId: this.get('examinationInfo.actorId'),
            appointmentStatusComment: this.get('schedulingComment'),
            actionId: this.get('userGlobalInformation.employeeId'),
          };
          this.create(path, null, params).then(function (res) {
            if(res == true){
              this.set('isAppointmentPopupOpen', false);
              //CallBack 재조회
              if(!isEmpty(this.get('setScheduledCB'))){
                this.get('setScheduledCB')();
              }
            }
          }.bind(this));
        } catch(e) {
          if(!this.get('isDestroyed')) {
            this.set('isAppointmentPopupOpen', false);
            this._showSaveError(e);
          }
        }
      },
    },

    _getActorItem(){
      try {
        const params = {
          examinationId: this.get('examinationInfo.examinationId')
        };
        this.set('isMediumLoader', true);
        this.get('peApiService').getActorList(params).then(res => {
          this.set('actorItems', res);
          this.set('isMediumLoader', false);
        });
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isMediumLoader', false);
          this._showError(e);
        }
      }
    },

    _validationCheck(){
      var now = this.get('co_CommonService').getNow();

      if(this.get('schedulingDatetime') < now){
        const msg = this.getLanguageResource('13232', 'F', '과거시간으로는 예약을 진행할 수 없습니다.');
        this.get('peApiService').onDisplayMessage('warning', msg, '', 'Ok', 'Ok', 0);
        return false;
      }

      if(isEmpty(this.get('examinationInfo.actorId'))){
        const msg = this.getLanguageResource('13233', 'F', '예약검사실을 선택하세요.');
        this.get('peApiService').onDisplayMessage('warning', msg, '', 'Ok', 'Ok', 0);
        return false;
      }

      return true;
    }
  });