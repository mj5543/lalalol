import { set } from '@ember/object';
import { A as emberA } from '@ember/array';
import { isEmpty } from '@ember/utils';
import layout from './template';
import CHIS from 'framework/chis-framework';
import CatheterizationManagementMixin from '../../mixins/patient-examination-catheterization-management-mixin';
import MesaggeMixin from '../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(
  CatheterizationManagementMixin,
  MesaggeMixin,
  {
    layout,
    selectedTabName: null,
    isDisabled: false,
    angiographiesPartList: null,
    typeGroupValue: null,
    searchPatientInfo: null,
    isShowContainerLoader: false,
    gridSource: null,
    checkbox: null,
    userGlobalInformation: null,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'patient-examination-catheterization-search');
      this.setStateProperties([
        'model',
        'selectedFromDate',
        'selectedToDate',
        'isDisabled',
        'angiographyList',
        'angiographiesPartList',
        'departmentList',
        'wardByColumns',
        'wardByItemsSource',
        'userGlobalInformation'
      ]);

      if (!this.hasState()) {
        this.set('isDisabled', false);
        this.set('model', {
          selectedAngiographyCode: null,
          selectedAngiographyPartId: null,
          selectedDepartmentId: null,
          wardBySelectedItem: null,
        });
        const displayDate = this.get('co_CommonService').getNow();
        this.set('selectedFromDate', displayDate);
        this.set('selectedToDate', displayDate);
        this.set('wardByColumns', [
          { field: 'angiographyGroupName', title: this.getLanguageResource('9698', 'F', null, '구분'), width: 120, align: 'center', readOnly: true},
          { field: 'scheduleDate', title: this.getLanguageResource('17043', 'F', null, '예약일자'), width: 90, align: 'center', type: 'date', dataFormat: 'd', readOnly: true},
          { field: 'patientCode', title: this.getLanguageResource('8451', 'F', null, '등록번호'), width: 90, align: 'center', readOnly: true},
          { field: 'patientName', title: this.getLanguageResource('16881', 'F', null, '환자명'), width: 70, align: 'center', readOnly: true},
          { field: 'age', title: this.getLanguageResource('1662', 'F', null, '나이'), width: 40, align: 'center', readOnly: true},
          { field: 'gender', title: this.getLanguageResource('3680', 'F', null, '성별'), width: 40, align: 'center', readOnly: true},
          { field: 'mainProcedure.name', title: this.getLanguageResource('4383', 'F', null, '시술명'), width: 180, bodyTemplateName: 'mainProcedure', readOnly: true},
          { field: 'procedureStatusName', title: this.getLanguageResource('3452', 'F', null, '상태'), width: 70, align: 'center', readOnly: true},
          { field: 'executeDatetime', title: this.getLanguageResource('4402', 'F', null, '시작시간'), width: 80, type: 'date', dataFormat: 't', align: 'center', readOnly: true},
          { field: 'completeDatetime', title: this.getLanguageResource('5297', 'F', null, '종료시간'), width: 80, type: 'date', dataFormat: 't', align: 'center', readOnly: true},
          { field: 'timeTypeName', title:this.getLanguageResource('9691', 'F', null, '시간'), width: 60, align: 'center', readOnly: true},
          { field: 'comment', title: this.getLanguageResource('3173', 'S', null, '비고'), width: 50, align: 'center', bodyTemplateName: 'comment', readOnly: true},
          { field: 'isPrepared', title: this.getLanguageResource('9493', 'F', null, '준비완료'), width: 80, align: 'center', type: 'boolean'},

        ]);
      }
      this.set('wardByItemsSource', emberA());
      this.set('angiographyList', emberA());
      this.set('angiographiesPartList', emberA());
      this.set('departmentList', emberA());
      this.set('typeGroupValue', 'A');
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1360');
      this._init();

      if(!isEmpty(this.get('co_CurrentUserService.user'))){
        this.set('userGlobalInformation', this.get('co_CurrentUserService.user'));
      }
    },

    actions: {
      onEditStart(e) {
        if (!e.item.isPrepared) {
          this._showCancelConfirm();
        } else {
          this._showSaveConfirm();
        }

      },
      onGridLoaded(e) {
        this.set('gridSource', e.source);
      },
      onSearchClick() {
        this._getAngiographiesByWard();
      },
      onGetPatient(item) {
        this.set('searchPatientInfo', item);
        this._getAngiographiesByWard();
      },
      onClearedSearch() {
        this.set('searchPatientId', null);
        this.set('searchPatientInfo', null);
        this._getAngiographiesByWard();

      },
      onCommitSearch(result) {
        if (!isEmpty(result.selectedItem)) {
          this.set('searchPatientId', result.selectedItem.patientId);
        }
      },
      onTreatmentResult() {
        this._getAngiographiesByWard();
      },

    },

    _init() {
      this._getAngiographyCodeList();
      this._getDepartmentList();
    },

    async _getDepartmentList() {
      try {
        const result = await this.get('apiService').getDepartment({code: 'ward'});
        if (!isEmpty(result)) {
          this.set('departmentList', result);
          if(!isEmpty(this.get('userGlobalInformation'))){
            const wardId = result.findBy('departmentId', this.get('userGlobalInformation.hospital.workPlaceId'));
            if(!isEmpty(wardId)){
              this.set('typeGroupValue', 'I');
              this.set('model.selectedDepartmentId', wardId.departmentId);
              this._getAngiographiesByWard();
            }
          }
        }
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this._showError(e);
        }
      }

    },

    async _getAngiographiesByWard() {
      try {
        this.set('isShowContainerLoader', true);
        const params = {
          fromDate: this.getFormatDate(this.get('selectedFromDate')),
          toDate: this.getFormatDate(this.get('selectedToDate')),
          angioGroupCode: this.get('model.selectedAngiographyCode'),
          partId: this.get('model.selectedAngiographyPartId'),
          patientType: this.get('typeGroupValue'),
          ward: this.get('model.selectedDepartmentId'),
          patientId: this.get('searchPatientInfo.patientId')
        };
        const result = await this.get('apiService').getAngiographiesByWard(params);
        this.set('wardByItemsSource', result);
        this.set('isShowContainerLoader', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowContainerLoader', false);
          this._showError(e);
        }
      }
    },
    async _showCancelConfirm() {
      const gridComponent = this.get('gridSource');
      set(gridComponent.selectedItem, 'isPrepared', true);
      const message = this.getLanguageResource('10126', 'F', null, '사전준비완료를 취소하시겠습니까?');
      const result = await this.showConfirm(message, '');
      if (result === 'Yes') {
        set(gridComponent.selectedItem, 'isPrepared', false);
        this._updateAngiographiesPrepare();
      }
    },

    async _showSaveConfirm() {
      const gridComponent = this.get('gridSource');
      set(gridComponent.selectedItem, 'isPrepared', false);
      const message = this.getLanguageResource('10127', 'F', null, '사전준비완료를 진행하시겠습니까?');
      const result = await this.showConfirm(message, '');
      if (result === 'Yes') {
        set(gridComponent.selectedItem, 'isPrepared', true);
        this._updateAngiographiesPrepare();
      }
    },

    async _updateAngiographiesPrepare() {
      try {
        const params = {
          angiographyPlanId: this.get('model.wardBySelectedItem.angiographyId'),
          isPrepared: this.get('model.wardBySelectedItem.isPrepared'),
          actionStaffId: this.get('globalCurrentUser.employeeId'),
          actionDatetime: new Date(this.get('co_CommonService').getNow())
        };
        await this.get('apiService').updateAngiographiesPrepare(params);
        this.get('apiService').onShowToast('save', this.getLanguageResource('8942', 'S', '저장되었습니다.'), '');
      } catch(e) {
        this._showSaveError(e);
      }

    },


  });
