import { next } from '@ember/runloop';
import { A as emberA } from '@ember/array';
import { isEmpty, isPresent } from '@ember/utils';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'patientexamination-module/app-config';
import EmberObject from '@ember/object';
import { inject as service } from '@ember/service';
import PtMixin from '../../mixins/patient-examination-mixin';
import MesaggeMixin from '../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, PtMixin, MesaggeMixin,{
  layout,
  model: null,
  changeModal: null,
  examinationGridColumns: null,
  examinationDataList: null,
  defaultUrl: null,
  conductUrl: null,
  userGlobalInformation: null,
  selectedExaminationItem: null,
  isPageLoader: false,
  isChangeDatetimePopupOpen: false,
  requestEmployee: null,
  peApiService:service('patientexamination-service'),

  onPropertyInit(){
    this._super(...arguments);
    this.set('viewId', 'patient-examination-progress-search');

    this.setStateProperties([
      'patientId',
      'examinationGridColumns',
      'examinationDataList',
      'defaultUrl',
      'conductUrl',
      'isPageLoader',
      'requestEmployee',
      'selectedExaminationItem',
      'userGlobalInformation',
      'isChangeDatetimePopupOpen',
      'changeModal',
    ]);

    if(this.hasState()===false) {

      const defaultUrl = this.get('fr_HostConfigService')
        .getEnvConfig('ServerCallConfig', 'patientexamination') +
        `patient-examination/${config.version}/`;

      const conductUrl = this.get('fr_HostConfigService')
        .getEnvConfig('ServerCallConfig', 'patientexamination') +
        `patient-examination/${config.version}/conductions`;

      this.set('defaultUrl', defaultUrl);
      this.set('conductUrl', conductUrl);

      const examinationGridColumns=[
        { field: 'issuedDate', title: this.getLanguageResource('5246', 'S', '오더일'), width:100, type: 'date', dataFormat:'d', align: 'center'},
        { field: 'issuedDoctorName', title: this.getLanguageResource('9686', 'S', '처방의'), width:70, align: 'center'},
        { field: 'examinationName', title: this.getLanguageResource('16806', 'S', '검사'), bodyTemplateName:'examName'},
        { field: 'issuedDoctorName', title: this.getLanguageResource('9686', 'S', '처방의'), width:70, align: 'center'},
        { field: 'medicalDepartmentName', title: this.getLanguageResource('7111', 'S', '진료과'), width: 75, align: 'center'},
        { field: 'patientType', title: this.getLanguageResource('8421', 'S', '환자구분'), width: 40, align: 'center'},
        { field: 'wardName', title: this.getLanguageResource('2749', 'S', '병동'), width: 60, align: 'center'},
        { field: 'statusName', title: this.getLanguageResource('732', 'S', '검사상태'), width:55, align: 'center', bodyTemplateName:'status'},
        { field: 'paymentStatusName', title: this.getLanguageResource('3859', 'S', '수납'), width:40, align: 'center', bodyTemplateName:'paid'},
        { field: 'acceptDatetime', title: this.getLanguageResource('6777', 'S', '접수일'), width:110, type: 'date', dataFormat: 'g' , align: 'center'},
        { field: 'acceptStaff', title: this.getLanguageResource('9283', 'S', '접수자'), width:70, align: 'center'},
        { field: 'executeDatetime', title: this.getLanguageResource('739', 'S', '검사시행일'), width:110, type: 'date', dataFormat: 'g' , align: 'center'},
        { field: 'executeStaff', title: this.getLanguageResource('4419', 'S', '시행자'), width:70, align: 'center'},
        { field: 'interpretationDateTime', title: this.getLanguageResource('7955', 'S', '판독일시'), width:110, type: 'date', dataFormat: 'g' , align: 'center'},
        { field: 'examinationGroupName', title:this.getLanguageResource('10002', 'S', '그룹명'), width:70, align: 'center'},
        { field: 'accessNumber', title:'A.No', width:50, align: 'center'},
        { field: 'examinationRoom.examinationRoomName', title: this.getLanguageResource('743', 'S', '검사실'), width:120, align: 'center' },
      ];
      this.set('examinationGridColumns', examinationGridColumns);
      this.set('model', {
        patientId: null,
        checkin : true,
        perform : true,
        preliminary : true,
        complete : true,
      });

      this.set('requestEmployee', {employeeId: null, employeeName: null});

      this.set('contextMenu', emberA([
        EmberObject.create({ text: this.getLanguageResource('12603', 'S', 'AccessNo. 복사'), disabled: false, display: true, action : this.actions.onCopyItems.bind(this, 'Access')}),
        EmberObject.create({ text: '환자정보복사', disabled: false, display: true, action : this.actions.onCopyItems.bind(this, 'Patient')}),
        EmberObject.create({ text: '처방정보복사', disabled: false, display: true, action : this.actions.onCopyItems.bind(this, 'Order')}),
        EmberObject.create({ text: '검사진행정보복사', disabled: false, display: true, action : this.actions.onCopyItems.bind(this, 'Examination')}),
        EmberObject.create({ text: '검사마스터링크', disabled: false, display: true, action : this.actions.examinationLink.bind(this)}),
        EmberObject.create({ text: '판독화면링크', disabled: false, display: true, action : this.actions.interpretationLink.bind(this)}),
      ]));
    }
  },

  /*관리자화면으로 구현했으나 사용여부 미정으로 다국어 적용하지 않음*/

  onLoaded() {
    this._super(...arguments);

    if(!isEmpty(this.get('co_CurrentUserService.user'))){
      this.set('userGlobalInformation', this.get('co_CurrentUserService.user'));
    }

    if(!isEmpty(this.get('co_PatientManagerService.selectedPatient'))){
      const patientGlobalInformation = this.get('co_PatientManagerService.selectedPatient');

      this.set('model.patientId', patientGlobalInformation.patientId);
      this._getExaminationList();
    }
    this.set('menuClass', 'w1360');
  },

  actions:{
    onCopyItems(type, e){
      const selectItem = e.dataItem.item;
      if(isEmpty(selectItem)){
        return;
      }
      let clipBoard = null;
      const qMark = "'";
      const newline = '\r';
      if(type == 'Access'){
        if(isEmpty(selectItem.accessNumber)){
          this.get('peApiService').onDisplayMessage('warning', 'AccessNumber가 없습니다.', '', 'Ok', 'Ok', 0);
        }
        clipBoard = 'select * from patientexamination_examinationconduct' + newline
          + 'where accessnumber = ' + qMark + selectItem.accessNumber + qMark + newline
          + '  and isvaliddatarow = 1;';
      }else if(type == 'Patient'){
        clipBoard = 'select a.ordername, a.* from patientexamination_examinationplan a' + newline
        + 'where patientId = ' + qMark + selectItem.patientId + qMark + newline
        + '  and dc = "C";';
      }else if(type == 'Order'){
        clipBoard = 'select a.ordername, a.* from patientexamination_examinationplan a' + newline
        + 'where orderid = ' + qMark + selectItem.orderId + qMark + newline + ';';
      }else if(type == 'Examination'){
        clipBoard = 'select a.ordername, a.* from patientexamination_examinationplan a' + newline
        + 'where id = ' + qMark + selectItem.examinationPlanId + qMark + newline + ';';
      }else{
        return;
      }
      this._copyItem(clipBoard);
    },

    examinationLink(e){
      const selectItem = e.dataItem.item;
      if(isEmpty(selectItem)){
        return;
      }
      this._sendMessageExamination(selectItem);
    },

    interpretationLink(e){
      const selectItem = e.dataItem.item;
      if(isEmpty(selectItem)){
        return;
      }
      this._sendMessageInterpretation(selectItem);
    },

    onSearchList(){
      this._getExaminationList();
    },

    onPopOpen(){
      const selectItem = this.get('selectedExaminationItem');
      if(isEmpty(selectItem)){
        return;
      }
      this.set('changeModal', {acceptDatetime: selectItem.acceptDatetime, executeDatetime: selectItem.executeDatetime});
    },

    onCancelChangeDate(){
      this.set('isChangeDatetimePopupOpen', false);
    },

    onSelectEmployee(item) {
      if(isEmpty(this.get('model.selectedGridItem'))) {
        return;
      }
      const employee= {employeeId: item.employeeId, employeeName: item.fullName};
      this.set('requestEmployee', employee);
    },

    onUndo(){
      if(isEmpty(this.get('selectedExaminationItem'))){
        return;
      }

      const item = this.get('selectedExaminationItem');
      if(!(item.statusCode == '3' || item.statusCode == '4')){
        this.get('peApiService').onDisplayMessage('warning', '접수 혹은 시행상태만 가능합니다.', '', 'Ok', 'Ok', 0);
        return;
      }
      if(item.statusCode == '3'){
        const options = this.questionMessage('이전상태로 변경하면 오더상태로 돌아갑니다 진행하시겠습니까?');
        messageBox.show(this, options).then(function (result) {
          if(result === 'Yes'){
            const cancelExaminationList = emberA();
            cancelExaminationList.pushObject(item.examinationConductId);
            this._undoCheckin(cancelExaminationList);
          }
        }.bind(this));
      }
      if(item.statusCode == '4'){
        const options = this.questionMessage('이전상태로 변경하면 접수상태로 돌아갑니다. 오더상태로 변경을 원할 경우 완료 후 Undo처리를 한번 더 진행해 주시기 바랍니다. 진행하시겠습니까?');
        messageBox.show(this, options).then(function (result) {
          if(result === 'Yes'){
            this._undoPerform(item);
          }
        }.bind(this));
      }
    },

    getSaveCancelReason(item){
      this._onCancelPerform(item);
    },

    onChangedExecuteTime(){
      if(this._validationCheck()){
        return;
      }

      const item = this.get('selectedExaminationItem');
      if(item.statusCode == '1' || item.statusCode == '2' || item.statusCode == '3' || item.statusCode == '7'){
        this.get('peApiService').onDisplayMessage('warning', '검사가 진행되지 않은 상태에서는 불가합니다.', '', 'Ok', 'Ok', 0);
        return;
      }
      this.set('isChangeDatetimePopupOpen', true);
    },

    onExaminationCancel(){
      if(!this._validationCheck()){
        return;
      }
      const item = this.get('selectedExaminationItem');
      if(item.statusCode != '4'){
        this.get('peApiService').onDisplayMessage('warning', '검사가 시행에서만 진행가능합니다.', '', 'Ok', 'Ok', 0);
        return;
      }

      const options = this.questionMessage('검사취소시 해당 검사는 재진행은 불가합니다. 추후 재진행을 해야 할 경우 Undo로 진행하세요. 취소하시겠습니까?');
      messageBox.show(this, options).then(function (result) {
        if(result === 'Yes'){
          this._undoPerform(item);
        }
      }.bind(this));
    },

    onDeleteInterpretation(){
      if(!this._validationCheck()){
        return;
      }
      const item = this.get('selectedExaminationItem');
      if(!(item.statusCode == '5' || item.statusCode == '6')){
        this.get('peApiService').onDisplayMessage('warning', '가판독 판독상태에서만 가능합니다.', '', 'Ok', 'Ok', 0);
      }
    },
  },

  _sendMessageExamination(item) {
    const parameters = {
      keyword: item.examinationCode
    };

    this.get('co_MenuManagerService').openMenu('examination-code-builder-all-management', parameters);
    this.get('co_ContentMessageService').sendMessage('messagePatientExamination', parameters);
  },

  _sendMessageInterpretation(item) {
    const parameters = {
      patientId: item.patientId,
      examinationPlanId: item.examinationPlanId,
      examinationGroupCode: item.examinationGroupCode
    };

    this.get('co_MenuManagerService').openMenu('patient-examination-report-interpretation', parameters);
    this.get('co_ContentMessageService').sendMessage('messageResultViewerInterpretation', parameters);
  },

  onPatientChanged(Patient){
    this._super(...arguments);
    if(isEmpty(Patient)){
      return;
    }
    this.set('model.patientId', Patient.patientId);
    this._getExaminationList();
  },

  _getExaminationList(){
    try {
      if(isEmpty(this.get('model.patientId'))){
        return;
      }
      this.set('examinationDataList',emberA());
      const path = this.get('defaultUrl') + 'conducted-examinations/management';
      const statusCodeList = emberA();
      if(this.get('model.checkin')){
        statusCodeList.pushObject(3);
      }
      if(this.get('model.perform')){
        statusCodeList.pushObject(4);
      }
      if(this.get('model.preliminary')){
        statusCodeList.pushObject(5);
      }
      if(this.get('model.complete')){
        statusCodeList.pushObject(6);
      }
      const queryParams = {
        patientId: this.get('model.patientId'),
        statusCode: statusCodeList
      };
      if(isPresent(queryParams.statusCode)){
        queryParams.statusCode = queryParams.statusCode.join('&statusCode=');
      }else{
        return;
      }
      this.set('isPageLoader', true);
      this.getList(path, queryParams, null).then(function(data){
        this.set('examinationDataList',data);
        next(this, function(){
          this.set('isPageLoader', false);
        });
      }.bind(this));
    } catch(e) {
      if(!this.get('isDestroyed')) {
        this.set('isPageLoader', false);
        this._showError(e);
      }
    }
  },

  _allClear(){
    this.set('patientInfo', EmberObject.create());
    this.set('examinationDataList', emberA());
  },

  _undoCheckin(cancelExaminationList){
    try {
      const cancelInfo = {actionStaffId: this.get('requestEmployee.employeeId'), examinationConductIds: cancelExaminationList };
      this.get('peApiService').onCheckinUndo(cancelInfo).then((res) => {
        if(res){
          this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
          //재조회
        }
      });
    } catch(e) {
      if(!this.get('isDestroyed')) {
        this._showSaveError(e);
      }
    }
  },

  _undoPerform(item){
    let isMaterial = false;
    const undoExaminationConductList = emberA();


    this.ajaxSyncCall(this.get('conductUrl') + '/material/', {procedureRequestId: item.orderId}, 'GET', null, false).done(res => {
      if(res > 0){
        isMaterial=true;
      }
    });
    const undoExaminationConduct = {
      examinationConductId: item.examinationConductId,
      examinationPlanId: item.examinationPlanId,
      statuscode: 3,
      examinationRoomCode: null
    };
    undoExaminationConductList.pushObject(undoExaminationConduct);

    const undoPerformInfo = {
      actionDate: this.get('co_CommonService').getNow(),
      actionStaffId: this.get('requestEmployee.employeeId'),
      undoExaminationConduct: undoExaminationConductList
    };

    if(isMaterial){
      this.get('peApiService').onDisplayMessage('warning', '재료를 먼저 환불해 주시기바랍니다.', '', 'Ok', 'Ok', 0);
      return;
    }
    this.get('peApiService').onPerformUndo(undoPerformInfo).then((res) => {
      if(res){
        this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
        //재조회
      }
    });
  },

  _onPerformCancel(item){

    const cancelRequestList = emberA();
    const validation = EmberObject.create({isMaterial:false, isInterpretation:false, isCheckin:false});

    cancelRequestList.addObject(item);
    this.ajaxSyncCall(this.get('conductUrl') + '/material/', {procedureRequestId: item.orderId}, 'GET', null, false).done(res => {
      if(res > 0){
        validation.isMaterial=true;
      }
    });

    if(validation.isMaterial){
      const options = this.getLanguageResource('10674', 'S', '기 발행된 재료가 있습니다. 반납하지 않고 검사를 취소하시겠습니까?');
      messageBox.show(this, options).then(function (result) {
        if(result === "Ok"){
          this._setCancelItem(cancelRequestList);
        }
      });
    }else{
      this._setCancelItem(cancelRequestList);
    }
  },

  _setCancelItem(cancelRequestList){
    if(!isEmpty(cancelRequestList)){
      this.set('cancelRequestList', cancelRequestList);
      this.set('model.isCancelPopOpen', true);
    }
  },

  _onCancelPerform(cancelReason){

    const item = this.get('selectedExaminationItem');
    const cancelList = emberA();
    if(item.statusCode == 4){
      cancelList.addObject(item.examinationConductId);
    }

    if (!cancelList.length) {
      //검사상태를 확인해 주시기 바랍니다.
      this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9288'), '', 'Ok', 'Ok', 0);
      return;
    }
    const cancelInfo = {
      actionDateTime: this.get('co_CommonService').getNow(),
      actionStaffId: this.get('requestEmployee.employeeId'),
      reasonId: cancelReason.reasonId,
      otherReason: cancelReason.otherReason,
      reasonDescription: cancelReason.reasonDescription,
      examinationConductIds: cancelList
    };

    this.get('peApiService').onPerformCacnel(cancelInfo).then((res) => {
      if(res){
        this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
      }
    });
  },

  _validationCheck(){
    if(isEmpty(this.get('selectedExaminationItem'))) {
      this.get('peApiService').onShowToast('save', '처리할 내용을 선택하세요.', '');
      return false;
    }
  },

  _clearInformation(){
    this.set('requestEmployee', {employeeId: null, employeeName: null});
  }
});