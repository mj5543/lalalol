/* eslint-disable max-lines */
import { A as emberA } from '@ember/array';
import { isEmpty } from '@ember/utils';
import { set } from '@ember/object';
import layout from './template';
import CHIS from 'framework/chis-framework';
import { inject as service } from '@ember/service';
import MessageMixin from '../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(
  MessageMixin,
  {
    layout,
    isDisabled: false,
    paramEmployeeId: null,
    examinationTypeCode: null,
    severityTypeCode: null,
    isDeabetesDrugChecked: false,
    deabetesDrugTextValue: null,
    remark: null,
    symptomItemsSource: null,
    loaderType: 'spinner',
    isShoeLoader: false,
    loaderDimed: false,
    contrastResult: null,
    isContrastMediaOpen: false,
    isDrugOpen: false,
    classificationCodes: null,
    apiService: service('patientexamination-side-effects-service'),

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'patient-examination-side-effect-management');
      this.setStateProperties([
        'globalCurrentUser',
        'globalPatient',
        'checkboxList',
        'treatmentItemsSource',
        'subsideItemsSource',
        'mediaContrastList',
        'isDisabled',
        'selectedDate',
        'drugByContrast',
        'drugBySeative',
        'sideExaminationTypes',
        'sideSeverityTypes',
        'firstInstrunctions',
        'secondInstrunctions',
        'thirdInstrunctions',
        'dosageUnits',
        'fristDrugs',
        'secondDrugs',
        'thirdDrugs',
        'resultSymptom',
        'isContrastOpen'
      ]);

      if (!this.hasState()) {
        this.set('model', {
          searchEmployeeId: null,
          drugByContrastId: null,
          contrastDrugId: null,
          fristDrugsItem: null,
          secondDrugsItem: null,
          thirdDrugsItem: null,
          firstInstructionRouteType: null,
          secondInstructionRouteType: null,
          thirdInstructionRouteType: null,
          firstInstructionCode: null,
          secondInstructionCode: null,
          thirdInstructionCode: null,
          firstUnitCode: null,
          secondUnitCode: null,
          thirdUnitCode: null,
          dosageUnitsItem: null,
          isTreatment: true,
          isSubSide: true,
          firstDosage: null,
          secondDosage: null,
          thirdDosage: null,
          firstDrugCode: null,
          secondDrugCode: null,
          thirdDrugCode: null,
        });
        this.set('isDisabled', false);
        const displayDate = new Date(this.get('co_CommonService').getNow());
        this.set('selectedDate', displayDate);
        if(!isEmpty(this.get('co_CurrentUserService.user'))){
          this.set('globalCurrentUser', this.get('co_CurrentUserService.user'));
        }
        if(!isEmpty(this.get('co_PatientManagerService.selectedPatient'))){
          this.set('globalPatient', this.get('co_PatientManagerService.selectedPatient'));
        }
        this.set('mediaContrastList', emberA());
        this.set('resultSymptom', emberA());
        this.set('symptomItemsSource', emberA());
        this.set('treatmentItemsSource', [
          {value: true, name: 'Y'},
          {value: false, name: 'N'}
        ]);
        this.set('subsideItemsSource', [
          {value: true, name: 'Y'},
          {value: false, name: 'N'}
        ]);
        this.set('numericOptions', {
          alias: 'numeric',
          digits: 3,
          autoUnmask: true,
          unmaskAsNumber: true,
        });
        this.set('fristDrugs', emberA());
        this.set('classificationCodes', ['Contrast']);
      }
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1360');
    },
    actions: {
      onPopupOpenedAction() {
        this._init();
      },
      onPopupClosedAction() {
        this._dataReset();
      },
      onSelectEmployee(item) {
        if(isEmpty(item)) {
          return;
        }
        this.set('model.searchEmployeeId', item.employeeId);
      },
      onCheckboxListLoaded(e) {
        this.set('checkboxList', e.source);
      },
      onClickRemove(item) {
        if (isEmpty(item)) {
          return;
        }
        if (item.itemId === '49') {
          set(item, 'itemDisplayName', null);
        }
        set(item, 'selected', false);
      },
      onClickEtcSymptom(item) {
        if(isEmpty(item.itemDisplayName)) {
          return;
        }
        set(item, 'selected', true);
      },
      onFirstDrugChanged(e) {
        const selectedItems = e.selectedItems[0];
        if (!isEmpty(selectedItems)) {
          this.set('model.fristDrugsItem', selectedItems);
        }
      },
      onSecondDrugChanged(e) {
        const selectedItems = e.selectedItems[0];
        if (!isEmpty(selectedItems)) {
          this.set('model.secondDrugsItem', selectedItems);
        }
      },
      onThirdDrugChanged(e) {
        const selectedItems = e.selectedItems[0];
        if (!isEmpty(selectedItems)) {
          this.set('model.thirdDrugsItem', selectedItems);
        }
      },

      onLinkedDrugClick(){
        this.set('isDrugOpen', true);
      },

      onSaveClick() {
        this._saveContrast();
      },
      onDeleteClick() {
        this._deleteContrast();
      },

      onDrugChanged(controlPosition, e){
        if(isEmpty(e.selectedItems.get('firstObject'))){
          if(controlPosition === 'first'){
            this.set('model.firstDosage', null);
            this.set('model.firstUnitCode', null);
            this.set('model.firstInstructionRouteType', null);
            this.set('model.firstInstructionCode', null);
          }else if(controlPosition === 'second'){
            this.set('model.secondDosage', null);
            this.set('model.secondUnitCode', null);
            this.set('model.secondInstructionRouteType', null);
            this.set('model.secondInstructionCode', null);
          }else{
            this.set('model.thirdDosage', null);
            this.set('model.thirdUnitCode', null);
            this.set('model.thirdInstructionRouteType', null);
            this.set('model.thirdInstructionCode', null);
          }
          return;
        }
        const administrationRouteTypeCode = e.selectedItems.get('firstObject').administrationRouteTypeCode || '';
        const administrationRouteCode = e.selectedItems.get('firstObject').administrationRouteCode || '';
        const frequency = e.selectedItems.get('firstObject').frequency || '';
        const dosageUnitCode = e.selectedItems.get('firstObject').dosageUnitCode || '';

        if(controlPosition === 'first'){
          this._firstDrugSet(frequency, dosageUnitCode, administrationRouteTypeCode, administrationRouteCode);
        }else if(controlPosition === 'second'){
          this._secondDrugSet(frequency, dosageUnitCode, administrationRouteTypeCode, administrationRouteCode);
        }else{
          this._thirdDrugSet(frequency, dosageUnitCode, administrationRouteTypeCode, administrationRouteCode);
        }
      }
    },

    _firstDrugSet(frequency, dosageUnitCode, administrationRouteTypeCode, administrationRouteCode){
      if(isEmpty(this.get('model.firstDosage'))){
        this.set('model.firstDosage', frequency);
      }
      this.set('model.firstUnitCode', this.get('model.firstOriginUnitCode') || dosageUnitCode);
      this.set('model.firstInstructionRouteType', this.get('model.firstOriginInstructionRouteType') || this.get('firstRouteTypeCodes').findBy('code', administrationRouteTypeCode));
      this.set('model.firstInstructionCode', this.get('model.firstOriginInstructionCode') || administrationRouteCode);
      this.set('model.firstOriginUnitCode', null);
      this.set('model.firstOriginInstructionRouteType', null);
      this.set('model.firstOriginInstructionCode', null);
    },

    _secondDrugSet(frequency, dosageUnitCode, administrationRouteTypeCode, administrationRouteCode){
      if(isEmpty(this.get('model.secondDosage'))){
        this.set('model.secondDosage', frequency);
      }
      this.set('model.secondUnitCode', this.get('model.secondOriginUnitCode') || dosageUnitCode);
      this.set('model.secondInstructionRouteType', this.get('model.secondOriginInstructionRouteType') ||this.get('secondRouteTypeCodes').findBy('code', administrationRouteTypeCode));
      this.set('model.secondInstructionCode', this.get('model.secondOriginInstructionCode') ||administrationRouteCode);
      this.set('model.secondOriginUnitCode', null);
      this.set('model.secondOriginInstructionRouteType', null);
      this.set('model.secondOriginInstructionCode', null);
    },

    _thirdDrugSet(frequency, dosageUnitCode, administrationRouteTypeCode, administrationRouteCode){
      if(isEmpty(this.get('model.thirdDosage'))){
        this.set('model.thirdDosage', frequency);
      }
      this.set('model.thirdUnitCode', this.get('model.thirdOriginUnitCode') ||dosageUnitCode);
      this.set('model.thirdInstructionRouteType', this.get('model.thirdOriginInstructionRouteType')|| this.get('thirdRouteTypeCodes').findBy('code', administrationRouteTypeCode));
      this.set('model.thirdInstructionCode', this.get('model.thirdOriginInstructionCode') ||administrationRouteCode);
      this.set('model.thirdOriginUnitCode', null);
      this.set('model.thirdOriginInstructionRouteType', null);
      this.set('model.thirdOriginInstructionCode', null);
    },

    async _init() {
      this.set('isShoeLoader', true);
      try {
        await this._getBusinessCodeList();
        await this._getDrugByContrast();
        await this._getContrast();
        await this._getSymptom();
        setTimeout(() => {
          if (!isEmpty(this.get('contrastResult.confirmDoctor'))) {
            this.set('paramEmployeeId', this.get('contrastResult.confirmDoctor.id'));
          }
        }, 2000);
      } catch(e) {
        //console.log('_init Error::' , e);
      }
      this.set('isShoeLoader', false);
    },

    async _getBusinessCodeList() {
      const examinationTypes = await this.get('apiService').getBusinessCode('SideExaminationType');
      this.set('sideExaminationTypes', examinationTypes);
      const severityTypes = await this.get('apiService').getBusinessCode('SideSeverityType');
      this.set('sideSeverityTypes', severityTypes);

      const routeTypeCodes = await this.get('apiService').getDosage();
      this.set('firstRouteTypeCodes', routeTypeCodes);
      this.set('secondRouteTypeCodes', routeTypeCodes);
      this.set('thirdRouteTypeCodes', routeTypeCodes);

      const dosageUnits = await this.get('apiService').getUnits();
      this.set('firstUnits', dosageUnits);
      this.set('secondUnits', dosageUnits);
      this.set('thirdUnits', dosageUnits);
      await this._getDrugBySedative();
    },

    async _getContrast() {
      try {
        const result = await this.get('apiService').getContrast(this.get('examinationPlanId'));
        this.set('contrastResult', result);
        if (!isEmpty(result)) {
          if(isEmpty(result.examinationType)){
            this.set('examinationTypeCode', 'ETC');
          }else{
            this.set('examinationTypeCode', result.examinationType.displayCode);
          }
          this.set('model.contrastDrugId', result.contrastMedia.id);
          if(!isEmpty(result.severityType)) {
            this.set('severityTypeCode', result.severityType.displayCode);
          }
          if(!isEmpty(result.occurredDate)) {
            this.set('selectedDate', result.occurredDate);
          }
          if (!isEmpty(result.firstDrugOrder)) {
            this.set('model.firstDrugCode', result.firstDrugOrder.drugCode);
            this.set('model.firstOriginUnitCode', result.firstDrugOrder.unitCode);
            this.set('model.firstOriginInstructionRouteType', this.get('firstRouteTypeCodes').findBy('code',result.firstDrugOrder.instructionRouteTypeCode));
            this.set('model.firstOriginInstructionCode', result.firstDrugOrder.instructionCode);
            this.set('model.firstDosage', result.firstDrugOrder.dosage);
          }
          if (!isEmpty(result.secondDrugOrder)) {
            this.set('model.secondDrugCode', result.secondDrugOrder.drugCode);
            this.set('model.secondOriginUnitCode', result.secondDrugOrder.unitCode);
            this.set('model.secondOriginInstructionRouteType', this.get('secondRouteTypeCodes').findBy('code',result.secondDrugOrder.instructionRouteTypeCode));
            this.set('model.secondOriginInstrunctionsCode', result.secondDrugOrder.instructionCode);
            this.set('model.secondOriginDosage', result.secondDrugOrder.dosage);
          }
          if (!isEmpty(result.thirdDrugOrder)) {
            this.set('model.thirdDrugCode', result.thirdDrugOrder.drugCode);
            this.set('model.thirdOriginUnitCode', result.thirdDrugOrder.unitCode);
            this.set('model.thirdOriginInstructionRouteType', this.get('thirdRouteTypeCodes').findBy('code',result.thirdDrugOrder.instructionRouteTypeCode));
            this.set('model.thirdOriginInstrunctionsCode', result.thirdDrugOrder.instructionCode);
            this.set('model.thirdOriginDosage', result.thirdDrugOrder.dosage);
          }
          this.set('model.isTreatment', result.isPreviousTreatment);

          if(!isEmpty(result.confirmDoctor)){
            this.set('model.searchEmployeeId', result.confirmDoctor.id);
          }
          this.set('model.isSubSide', result.isSubside);
          this.set('isDeabetesDrugChecked', result.isDiabetesDrug);
          this.set('deabetesDrugTextValue', result.diabetesContent);
          this.set('remark', result.remark);
          this.set('resultSymptom', result.symptom);
        }
      } catch(e) {
        //
      }
    },
    async _getDrugByContrast() {
      const mediaContrastList = await this.get('apiService').getBusinessCode('Contrast');
      this.set('mediaContrastList', mediaContrastList);
    },

    async _getDrugBySedative() {
      const params = {
        examinationGroupCode: 'DR',
        relationTypeCode: 'Sedative'
      };
      const result = await this.get('apiService').getDrug(params);
      this.set('fristDrugs', result);
      this.set('secondDrugs', result);
      this.set('thirdDrugs', result);
    },

    async _getSymptom() {
      try {
        this.set('symptomItemsSource', []);
        const result = await this.get('apiService').getSymptom();
        const resultSymptom = this.get('resultSymptom');
        if(!isEmpty(result)){
          result.map(data => {
            data.symptomItems.map(item => {
              let resultItem = null;
              if (!isEmpty(resultSymptom)) {
                resultItem = resultSymptom.find(d => d.id === item.itemId);
              }
              if (isEmpty(resultItem)) {
                item.selected = false;
                if(item.itemId === '49') {
                  item.itemDisplayName = null;
                }
              } else {
                item.selected = true;
                if(item.itemId === '49') {
                  item.itemDisplayName = resultItem.name;
                }
              }
            });
          });
          this.set('symptomItemsSource', result);
        }
      } catch(e) {
        //
      }

    },

    _setSymptom() {
      const result = this.get('symptomItemsSource');
      const resultSymptom = this.get('resultSymptom');
      if(isEmpty(result)){
        return;
      }
      result.map(data => {
        data.symptomItems.map(item => {
          let resultItem = null;
          if (!isEmpty(resultSymptom)) {
            resultItem = resultSymptom.find(d => d.id === item.itemId);
          }
          if (isEmpty(resultItem)) {
            item.selected = false;
            if(item.itemId === '49') {
              item.itemDisplayName = null;
            }
          } else {
            item.selected = true;
            if(item.itemId === '49') {
              item.itemDisplayName = resultItem.name;
            }
          }
        });
      });
      this.set('symptomItemsSource', result);
    },

    async _saveContrast() {
      if(!this._checkInputField()) {
        return;
      }
      this.set('loaderType', 'progress');
      this.set('loaderDimed', true);
      this.set('isShoeLoader', true);
      try {
        const params = this._getSaveParameters();
        await this.get('apiService').createContrast(params);
        const result = await this.get('apiService').getContrast(this.get('examinationPlanId'));
        if(!isEmpty(this.get('contrastCB'))) {
          this.get('contrastCB')(result);
        }
        this.get('apiService').onShowToast('save', this.getLanguageResource('8942', 'F', '저장되었습니다.'), '');
        this.set('isShoeLoader', false);
        this.set('isContrastMediaOpen', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShoeLoader', false);
          this.set('isContrastMediaOpen', false);
          this.get('apiService').onShowToast('error', this.getLanguageResource('11755', 'F', '저장에 실패하였습니다.'), '');
        }
      }

    },

    _checkInputField() {
      let flag = true;
      if (isEmpty(this.get('examinationTypeCode'))) {
        this.get('apiService').onDisplayMessage('warning', this.getLanguageResource('9775', 'F', '검사분류를 먼저 선택하세요'), '', 'Ok', 'Ok', 0);
        flag = false;
        return flag;
      }
      if (isEmpty(this.get('model.contrastDrugId'))) {
        this.get('apiService').onDisplayMessage('warning', this.getLanguageResource('12600', 'F', '조영제를 선택해주세요.'), '', 'Ok', 'Ok', 0);
        flag = false;
        return flag;
      }
      if (isEmpty(this.get('severityTypeCode'))) {
        this.get('apiService').onDisplayMessage('warning', this.getLanguageResource('12601', 'F', '중증도를 선택해주세요.'), '', 'Ok', 'Ok', 0);
        flag = false;
        return flag;
      }
      if((!isEmpty(this.get('model.firstDosage')) || !isEmpty(this.get('model.firstUnitCode')) ||
      !isEmpty(this.get('model.firstInstrunctionsCode'))) && isEmpty(this.get('model.firstDrugCode'))) {
        this.get('apiService').onShowToast('error', this.getLanguageResource('12601', 'F', '처치약을 선택해주세요'), '');
        flag = false;
        return flag;
      }
      if((!isEmpty(this.get('model.secondDosage')) || !isEmpty(this.get('model.secondUnitCode')) ||
      !isEmpty(this.get('model.secondInstrunctionsCode'))) && isEmpty(this.get('model.secondDrugCode'))) {
        this.get('apiService').onShowToast('error', this.getLanguageResource('12601', 'F', '처치약을 선택해주세요'), '');
        flag = false;
        return flag;
      }
      if((!isEmpty(this.get('model.thirdDosage')) || !isEmpty(this.get('model.thirdUnitCode')) ||
      !isEmpty(this.get('model.thirdInstrunctionsCode'))) && isEmpty(this.get('model.thirdDrugCode'))) {
        this.get('apiService').onShowToast('error', this.getLanguageResource('12601', 'F', '처치약을 선택해주세요'), '');
        flag = false;
        return flag;
      }
      return flag;
    },

    _getSaveParameters() {
      const params = {
        patientId: this.get('contrastResult.patientId'),
        examinationPlanId: this.get('examinationPlanId'),
        examinationTypeCode: this.get('examinationTypeCode'),
        contrastMediaId: this.get('model.contrastDrugId'),
        severityTypeCode: this.get('severityTypeCode'),
        isPreviousTreatment: this.get('model.isTreatment'),
        confirmDoctorId: this.get('model.searchEmployeeId'),
        isSubside: this.get('model.isSubSide'),
        firstDrugOrder: {
          drugId: this.get('model.fristDrugsItem.drugId'),
          drugCode: this.get('model.fristDrugsItem.drugCode'),
          drugName: this.get('model.fristDrugsItem.drugName'),
          dosage: this.get('model.firstDosage'),
          unitCode: this.get('model.firstUnitCode'),
          instructionRouteTypeCode: this.get('model.firstInstructionRouteType.code'),
          instructionCode: this.get('model.firstInstructionCode')
        },
        secondDrugOrder: {
          drugId: this.get('model.secondDrugsItem.drugId'),
          drugCode: this.get('model.secondDrugsItem.drugCode'),
          drugName: this.get('model.secondDrugsItem.drugName'),
          dosage: this.get('model.secondDosage'),
          unitCode: this.get('model.secondUnitCode'),
          instructionRouteTypeCode: this.get('model.secondInstructionRouteType.code'),
          instructionCode: this.get('model.secondInstructionCode')
        },
        thirdDrugOrder: {
          drugId: this.get('model.thirdDrugsItem.drugId'),
          drugCode: this.get('model.thirdDrugsItem.drugCode'),
          drugName: this.get('model.thirdDrugsItem.drugName'),
          dosage: this.get('model.thirdDosage'),
          unitCode: this.get('model.thirdUnitCode'),
          instructionRouteTypeCode: this.get('model.thirdInstructionRouteType.code'),
          instructionCode: this.get('model.thirdInstructionCode')
        },
        symptom: this._getSelectedSymptomItems(),
        isDiabetesDrug: this.get('isDeabetesDrugChecked'),
        diabetesContent: this.get('deabetesDrugTextValue'),
        remark: this.get('remark'),
        occurredDate: this.get('selectedDate'),
        actionStaffId: this.get('globalCurrentUser.employeeId'),
        actionDatetime: new Date(this.get('co_CommonService').getNow())
      };
      return params;
    },

    _getSelectedSymptomItems() {
      const list = this.get('symptomItemsSource');
      const returnArr = [];
      if (!isEmpty(list)) {
        list.forEach(datas => {
          datas.symptomItems.forEach(item => {
            if (item.selected) {
              returnArr.push({
                id: item.itemId,
                displayCode: item.itemCode,
                name: item.itemDisplayName
              });
            }
          });
        });
      }
      return returnArr;
    },

    async _deleteContrast() {
      if (isEmpty(this.get('contrastResult.contrastSideEffectId'))) {
        return;
      }
      try {
        const params = {
          contrastSideEffectId: this.get('contrastResult.contrastSideEffectId'),
          actionStaffId: this.get('globalCurrentUser.employeeId'),
          actionDatetime: new Date(this.get('co_CommonService').getNow())
        };
        await this.get('apiService').deleteContrast(params);
        const result = await this.get('apiService').getContrast(this.get('examinationPlanId'));
        if(!isEmpty(this.get('contrastCB'))) {
          this.get('contrastCB')(result);
        }
        this.get('apiService').onShowToast('delete', '', this.getLanguageResource('8944', 'F', null, '삭제되었습니다'));
        this.set('isContrastMediaOpen', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isContrastMediaOpen', false);
        }
        this.get('apiService').onShowToast('error', this.getLanguageResource('11755', 'F', null, '저장에 실패했습니다.'), '');
        //console.log('delete Error:::', e);
      }
    },

    _dataReset() {
      this.set('loaderType', 'spinner');
      this.set('examinationTypeCode', null);
      this.set('model.contrastDrugId', null);
      this.set('severityTypeCode', null);
      this.set('selectedDate', new Date(this.get('co_CommonService').getNow()));
      this.set('model.isTreatment', null);
      this.set('model.searchEmployeeId',null);
      this.set('model.isSubSide', null);
      this.set('model.fristDrugsItem', null);
      this.set('model.firstUnitCode', null);
      this.set('model.firstInstrunctionsCode', null);
      this.set('model.firstDosage', null);

      this.set('model.secondDrugsItem', null);
      this.set('model.secondUnitCode', null);
      this.set('model.secondInstrunctionsCode', null);
      this.set('model.secondDosage', null);

      this.set('model.thirdDrugsItem',null);
      this.set('model.thirdUnitCode', null);
      this.set('model.thirdInstrunctionsCode', null);
      this.set('model.thirdDosage', null);

      this.set('isDeabetesDrugChecked', false);
      this.set('deabetesDrugTextValue', null);
      this.set('remark', null);
      this.set('resultSymptom', null);
      this.set('contrastResult', null);
      this.set('symptomItemsSource', emberA());
      this.set('model.firstDrugCode', null);
      this.set('model.secondDrugCode', null);
      this.set('model.thirdDrugCode', null);
      this.set('paramEmployeeId', null);
    }
  });
