import layout from './template';
import CHIS from 'framework/chis-framework';
import { isEmpty } from '@ember/utils';
import { inject as service } from '@ember/service';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  {
    layout,
    isLabelPageOpen: true,
    userGlobalInformation: null,
    nameLabelPage: 1,
    examinationGroupCode: null,
    peApiService:service('patientexamination-service'),

    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId', 'patient-examination-label-setting');

      this.setStateProperties([
        'isLabelPageOpen',
        'nameLabelPage',
        'examinationGroupCode'
      ]);
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1000');
    },

    actions :{
      onCancel(){
        this.set('isLabelPageOpen', false);
      },

      onSave(){
        this._setPersonalLabelSetting();
        this.set('isLabelPageOpen', false);
        if(!isEmpty(this.get('onNameLabelPageCB'))){
          this.get('onNameLabelPageCB')(this.get('nameLabelPage'));
        }
      },
    },

    async _setPersonalLabelSetting(){
      let viewId = this.get('viewId');
      if(this.get('examinationGroupCode') == 'DR'){
        viewId = this.get('viewId') + '_radiology';
      }
      const settingKey = viewId;
      const settingData = {
        conditionData: [{
          nameLabelPage: this.get('nameLabelPage')
        }]};

      const description = this.getLanguageResource('13354', 'F', '영상/기능검사실 네임라벨셋팅');
      await this.get('peApiService').setPeSettingInfo(settingKey, settingData, description);
    }
  });