import { A as emberA } from '@ember/array';
import { isEmpty } from '@ember/utils';
import layout from './template';
import CHIS from 'framework/chis-framework';
import CatheterizationManagementMixin from '../../../mixins/patient-examination-catheterization-management-mixin';
import MessageMixin from '../../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(
  CatheterizationManagementMixin,
  MessageMixin,
  {
    layout,
    angiographyGroupCode: null,
    calendarSelectedDate: null,
    angiographiesPartList: null,
    schedulePartItemsSource: null,
    angiographyItemsSource: null,
    subProcedureItemsource: null,
    scheduleGrid: null,
    searchPatientInfo: null,
    timeTypeItemsSource: null,
    calendarItemsSource: null,
    scheduleGridItemsSource: null,
    scheduleGridColumns: null,
    searchByPatientGridItemsSource: null,
    searchByPatientGridColumns: null,
    patientInfo: null,
    searchPatientId: null,
    paramEmployeeId: null,
    diagnosisItemsSource: null,
    selectedDate: null,
    isShowScheduleLoader: false,
    isShowScheduleByPatientLoader: false,
    calendarDisplayDate: null,
    isShowAgiographiesEntryLoader: false,
    isShowCalendarLoader: false,
    isShowCustomInput: false,
    selectedPartId: null,
    isFirstRecieve: true,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'patient-examination-catheterization-management/schedule-tab');
      this.setStateProperties([
        'model',
        'calendarSelectedDate',
        'angiographyGroupCode'
      ]);

      if (!this.hasState()) {
        this.set('model', {
          selectedEntryAngiographyId: null,
          selectedProcedureId: null,
          selectedTimeTypeCode: null,
          isUrgent: false,
          comment: null,
          selectedDiseaseId: null,
          selectedDiagnosisItem: null,
          searchEmployeeId: null,
          scheduleGridSelectedItem: null,
          customMainProcedure: null,
          selectedPartId: null,
          selectedDate: null,
          diseaseFilterValue: null,
          entryAngiographyFilterValue: null,
          procedureFilterValue: null,
        });
        const displayDate = new Date(this.get('co_CommonService').getNow());
        this.set('calendarSelectedDate', displayDate);
        this.set('angiographyItemsSource', emberA());
        this.set('subProcedureItemsSource', emberA());
        this.set('timeTypeItemsSource', emberA());
        this.set('calendarItemsSource', emberA());
        this.get('scheduleGridItemsSource', emberA());
        this.get('searchByPatientGridItemsSource', emberA());
        this.set('scheduleGridColumns', [
          { field: 'isUrgent', title: this.getLanguageResource('1642', 'S', '긴급'), locked: true, width: 35, align: 'center', bodyTemplateName: 'urgentIcon'},
          { field: 'patientName', title: this.getLanguageResource('4184', 'S', '환자명'), locked: true, width: 90, align: 'center', bodyTemplateName: 'patientName'},
          { field: 'patientCode', title: this.getLanguageResource('8451', 'S', '등록번호'), locked: true, width: 65, align: 'center', bodyTemplateName: 'patientCode'},
          { field: 'age', title: this.getLanguageResource('1662', 'S', '나이'), width: 35, align: 'center'},
          { field: 'gender', title: this.getLanguageResource('3680', 'S', '성별'), width: 35, align: 'center'},
          { field: 'diagnosis.name', title: this.getLanguageResource('9601', 'S', '진단명'), width: 200, bodyTemplateName:'colfont', headerTemplateName:'headercolfont01'},
          { field: 'mainProcedure.name', title: this.getLanguageResource('4383', 'S', '시술명'), bodyTemplateName:'colfont', headerTemplateName:'headercolfont02'},
          { field: 'subProcedure.name', title: this.getLanguageResource('9170', 'S', '상세'), width: 90, bodyTemplateName: 'subProcedure'},
          { field: 'assignedPhysician.name', title: this.getLanguageResource('8898', 'S', '진료의'), width: 80, align: 'center'},
          { field: 'timeTypeName', title: this.getLanguageResource('9691', 'S', '시간'), width: 60, align: 'center'},
          { field: 'comment', title: this.getLanguageResource('3173', 'S', '비고'), width: 40, align: 'center', bodyTemplateName: 'commentIcon'},
          { field: 'rsvFirstDatetime', title: this.getLanguageResource('10765', 'S', '입력일시'), width: 100, type: 'date', dataFormat: 'g', align: 'center'},
          { field: 'rsvFirstStaffName', title: this.getLanguageResource('6298', 'S', '입력자'), width: 80, align: 'center'},
        ]);
        this.set('searchByPatientGridColumns', [
          { field: 'isUrgent', title: this.getLanguageResource('1642', 'S', '긴급'), width: 35, align: 'center', bodyTemplateName: 'urgentIcon'},
          { field: 'scheduleDate', title: this.getLanguageResource('5146', 'S', '예약일자'), width: 100, type: 'date', dataFormat: 'd', align: 'center'},
          { field: 'procedureStatusName', title: this.getLanguageResource('3452', 'S', '상태'), width: 80, align: 'center'},
          { field: 'diagnosis.name', title: this.getLanguageResource('9601', 'S', '진단명'), width: 200},
          { field: 'mainProcedure.name', title: this.getLanguageResource('4383', 'S', '시술명'), bodyTemplateName: 'mainProcedure'},
          { field: 'subProcedure.name', title: this.getLanguageResource('9170', 'S', '상세'), width: 90, bodyTemplateName: 'subProcedure'},
          { field: 'assignedPhysician.name', title: this.getLanguageResource('8898', 'S', '진료의'), width: 80, align: 'center'},
          { field: 'executeDatetime', title: this.getLanguageResource('1679', 'S', '날짜'), width: 100, type: 'date', dataFormat: 'g', align: 'center'},
          { field: 'timeTypeName', title: this.getLanguageResource('9691', 'S', '시간'), width: 60, align: 'center'},
          { field: 'comment', title: this.getLanguageResource('3173', 'S', '비고'), width: 40, align: 'center', bodyTemplateName: 'commentIcon'},
          { field: 'rsvFirstDatetime', title: this.getLanguageResource('10765', 'S', '등록시간'), width: 100, type: 'date', dataFormat: 'g', align: 'center'},
          { field: 'rsvFirstStaffName', title: this.getLanguageResource('6298', 'S', '입력자'), width: 80, align: 'center'},
        ]);
      }
    },

    onLoaded() {
      this._super(...arguments);
      this._getItemsSourceList();
    },
    didReceiveAttrs() {
      this._super(...arguments);
    },
    _setSelectedPartId() {
      if(!this.get('isFirstRecieve')) {
        this.set('model.selectedPartId', this.get('selectedPartId'));
      }
    },

    actions: {
      onPartIdChagned(e){
        if(this.get('isFirstRecieve')) {
          return;
        }
        const selectedItem = e.selectedItems[0];
        this._getAngiographiesCount();
        if (!isEmpty(selectedItem)) {
          this._getAngiographyList(selectedItem.id);
        } else {
          this._getAngiographyList();
        }
        this._getAngiographiesSearchList();
      },
      onCalendarClick(e){
        if(this.get('selectedDate') == e.selectedDate || isEmpty(this.get('model.selectedDate'))){
          this._changeDate(e);
        }
      },

      onCalendarSelecteChanged(e) {
        // if(this.get('isFirstRecieve')) {
        //   return;
        // }
        this._changeDate(e);
      },
      onCalendarRangeChanged(e) {
        if (!isEmpty(e.displayDate)) {
          this.set('calendarDisplayDate', e.displayDate);
        }
        this._getAngiographiesCount();

      },
      onPickerSelectChanged() {
        this._getAngiographiesSearchList();
      },
      onScheduleGridLoaded(e) {
        this.set('scheduleGrid', e.source);
      },
      onAngiographyItemChanged(e) {
        const selectedItem = e.selectedItems[0];
        if (!isEmpty(selectedItem)) {
          if (!isEmpty(selectedItem.subProcedure)) {
            this.set('subProcedureItemsSource', selectedItem.subProcedure);
            if (!isEmpty(this.get('model.scheduleGridSelectedItem'))) {
              this.set('model.selectedProcedureId', this.get('model.scheduleGridSelectedItem.subProcedure.id'));
            }
          } else {
            this.set('subProcedureItemsSource', emberA());
          }
          if (selectedItem.displayCode.indexOf('9999') > 0) {
            this.set('isShowCustomInput', true);
          } else {
            this.set('isShowCustomInput', false);
          }
          if(!isEmpty(this.get('model.customMainProcedure'))){
            this.set('model.customMainProcedure', null);
          }
        }
      },
      onScheduleAngiographyChanged() {
        this._getAngiographiesSearchList();
      },
      onScheduleGridSelectedChanged(e) {
        this.set('searchByPatientGridItemsSource', emberA());
        const item = e.selectedItems.get('firstObject');
        this._setReserveInformation(item);
      },
      onGridDoubleClick(e){
        if(!isEmpty(this.get('patientChangedCB'))) {
          if(!isEmpty(e.item.patientId)){
            this.get('patientChangedCB')(e.item.patientId);
          }
        }
      },

      onResetCilck() {
        if (!isEmpty(this.get('model.scheduleGridSelectedItem'))) {
          this.get('scheduleGrid').deselectRow(this.get('model.scheduleGridSelectedItem'));
        } else {
          this.set('searchByPatientGridItemsSource', emberA());
          this._angiographyEntryFieldsReset();
        }

        //this.set('model.selectedDate', this.get('calendarSelectedDate'));
      },
      onAngiographieSaveClick() {
        this._saveAngiographies();
      },
      onRetrySearch() {
        this._getAngiographiesSearchList();
      },
      onCancelClick() {
        this._showCancelConfirm();
      },
      onSelectEmployee(item) {
        if(isEmpty(item)) {
          return;
        }
        this.set('model.searchEmployeeId', item.employeeId);
      },
      onGetPatient(item) {
        this.set('searchPatientInfo', item);
        this._changedPatientSettings();
      },
      onPatientCleared() {
        this.set('patientInfo', null);
        this.set('searchPatientInfo', null);
        this.set('diagnosisItemsSource', emberA());
      }
    },

    _setReserveInformation(item){
      const selectedItem = item;
      this.set('searchByPatientGridItemsSource', emberA());
      this._angiographyEntryFieldsReset();
      if(!isEmpty(selectedItem)) {
        this.set('searchPatientId', selectedItem.patientId);
        if(!isEmpty(selectedItem.assignedPhysician)) {
          this.set('paramEmployeeId', selectedItem.assignedPhysician.id);
          this.set('model.searchEmployeeId', selectedItem.assignedPhysician.id);
        }
        if(!isEmpty(selectedItem.mainProcedure.id)){
          this.set('model.selectedEntryAngiographyId', selectedItem.mainProcedure.id);
        }
        this.set('model.isUrgent', selectedItem.isUrgent);
        this.set('model.selectedTimeTypeCode', selectedItem.timeTypeCode);
        this.set('model.selectedDate', selectedItem.scheduleDate);
        this.set('model.comment', selectedItem.comment);
        this.set('model.angiographyPlanId', selectedItem.angiographyId);
        if (selectedItem.mainProcedure.displayCode.indexOf('9999') > 0) {
          this.set('isShowCustomInput', true);
          this.set('model.customMainProcedure', selectedItem.mainProcedure.name);
        }
      }
    },

    async _getItemsSourceList() {
      this.getSchedulePartItems();
      this.set('model.selectedPartId', this.get('selectedPartId'));
      const timeTypes = await this.get('apiService').getBusinessCode({classificationCode: 'TimeType'});
      this.set('timeTypeItemsSource', timeTypes);
    },

    async _getAngiographiesCount() {
      try {
        this.set('isShowCalendarLoader', true);
        this.set('calendarItemsSource', emberA());
        if(isEmpty(this.get('calendarDisplayDate'))) {
          this.set('calendarDisplayDate', this.get('calendarSelectedDate'));
        }
        const partId = this._getSelectedPartId(this.get('selectedPartId'));
        const params = {
          searchDate: this.get('calendarDisplayDate'),
          angioGroupCode: this.get('angiographyGroupCode'),
          partId: partId,
        };
        const countResult = await this.get('apiService').getAngiographiesCount(params);
        if(!isEmpty(countResult)) {
          countResult.forEach(d => {
            this.get('calendarItemsSource').addObject({date: d.scheduleDate, content: d.scheduleCount});
          });
        }
        this.set('isFirstRecieve', false);
        this.set('isShowCalendarLoader', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowCalendarLoader', false);
          this._showError(e);
        }
      }
    },

    async _getPatientInfomation(param) {
      try {
        const result = await this.get('apiService').getPatientInfomation(param);
        this.set('patientInfo', result);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this._showError(e);
        }
      }
    },
    async _saveAngiographies() {
      try {
        if (!this._checkValidation()) {
          const msg = this.getLanguageResource('10275', 'F', '필수항목을 입력하세요.');
          this.get('apiService').onShowToast('error', msg, '');
          return;
        }
        const actionTime = new Date(this.get('co_CommonService').getNow());
        const dateParam = this.getFormatDate(this.get('model.selectedDate'));
        let params = {};
        params = {
          scheduleDate: dateParam,
          diagnosis: {
            id: this.get('model.selectedDiagnosisItem.diseaseId'),
            displayCode: this.get('model.selectedDiagnosisItem.diseaseTermCode'),
            name: this.get('model.selectedDiagnosisItem.diseaseTermName')
          },
          mainProcedureId: this.get('model.selectedEntryAngiographyId'),
          subProcedureId: this.get('model.selectedProcedureId'),
          timeTypeCode: this.get('model.selectedTimeTypeCode'),
          angiographyGroupCode: this.get('angiographyGroupCode'),
          assignedPhysicianId: this.get('model.searchEmployeeId'),
          comment: this.get('model.comment'),
          isUrgent: this.get('model.isUrgent'),
          actionStaffId: this.get('globalCurrentUser.employeeId'),
          actionDatetime: actionTime,
          contactNumber: this.get('patientInfo.telephonePrimary'),
          manualProcedureName: this.get('model.customMainProcedure')
        };
        let promise = null;
        if(isEmpty(this.get('model.scheduleGridSelectedItem'))) {
          params.patientId = this.get('searchPatientInfo.patientId');
          promise = this.get('apiService').createAngiographies(params);
        } else {
          params.angiographyPlanId = this.get('model.scheduleGridSelectedItem.angiographyId');
          promise = this.get('apiService').updateAngiographies(params);
        }
        await promise;
        this.showToastSaved();
        this._angiographyEntryFieldsReset();
        this._getAngiographiesCount();
        await this._getAngiographiesSearchList();
      } catch(e) {
        this._showSaveError(e);
      }
    },

    _changeDate(e){
      this.set('selectedDate', e.selectedDate);
      this.set('calendarDisplayDate', e.selectedDate);

      if(isEmpty(this.get('model.selectedDate'))){
        this.set('model.selectedDate', e.selectedDate);
      }

      if(isEmpty(this.get('model.angiographyPlanId'))){
        this.set('model.selectedDate', e.selectedDate);
      }
    },

    _checkValidation() {
      if(isEmpty(this.get('searchPatientInfo.patientId')) || isEmpty(this.get('model.selectedEntryAngiographyId'))){
        return false;
      } else {
        return true;
      }
    },

    async _getAngiographiesSearchList() {
      try {
        this.set('isShowScheduleLoader', true);
        const partId = this._getSelectedPartId(this.get('selectedPartId'));
        const params = {
          searchDate: this.getFormatDate(this.get('calendarSelectedDate')),
          angioGroupCode: this.get('angiographyGroupCode'),
          partId: partId,
          angiographyId: this.get('model.selectedScheduleAngiographyId')
        };
        const countResult = await this.get('apiService').getAngiographiesSearch(params);
        if(!isEmpty(countResult)){
          countResult.map(data => {
            if (isEmpty(data.diagnosis)) {
              data.diagnosis = {
                id: null,
                displayCode: null,
                name: null,
              };
            }
          });
          this.set('scheduleGridItemsSource', countResult);
          this.set('isShowScheduleLoader', false);
        }else{
          this.set('scheduleGridItemsSource', emberA());
        }
        this.set('isShowScheduleLoader', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowScheduleLoader', false);
          this._showError(e);
        }
      }
    },

    async _getAngiographiesByPatient() {
      try {
        this.set('isShowScheduleByPatientLoader', true);
        const params = {
          angioGroupCode: this.get('angiographyGroupCode'),
          patientId: this.get('searchPatientInfo.patientId')
        };
        const result = await this.get('apiService').getAngiographiesByPatient(params);
        this.set('searchByPatientGridItemsSource', result);
        this.set('isShowScheduleByPatientLoader', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowScheduleByPatientLoader', false);
          this._showError(e);
        }
      }
    },

    async _getAngiographiesPatientDiagnosis(param) {
      try {
        const result = await this.get('apiService').getAngiographiesPatientDiagnosis(param);
        this.set('diagnosisItemsSource', result);
        if (!isEmpty(result)) {
          this.set('model.selectedDiseaseId', this.get('model.scheduleGridSelectedItem.diagnosis.id'));
        }
      } catch(e) {
        this._showError(e);
      }
    },

    async _showCancelConfirm() {
      const message = this.getLanguageResource('8941', 'F', null, '취소하시겠습니까?');
      const result = await this.showConfirm(message, '');
      if (result === 'Yes') {
        this._reservationCancel();
      }
    },

    async _reservationCancel() {
      try {
        const param = {angiographyPlanId: this.get('model.scheduleGridSelectedItem.angiographyId')};
        await this.get('apiService').updateAngiographiesCancle(param);
        this.showToastCanceled();
        this._angiographyEntryFieldsReset();
        this._getAngiographiesCount();
        await this._getAngiographiesSearchList();
      } catch(e) {
        this._showSaveError(e);
      }
    },

    async _changedPatientSettings() {
      try {
        this.set('isShowAgiographiesEntryLoader', true);
        const param = {
          patientId: this.get('searchPatientInfo.patientId')
        };
        /* const patientParam = {
          patientId: this.get('searchPatientInfo.patientId'),
          isDetail: true
        };*/
        await this._getAngiographiesByPatient();
        await this._getAngiographiesPatientDiagnosis(param);
        await this._getPatientInfomation(param);
        this.set('isShowAgiographiesEntryLoader', false);
      } catch(e) {
        this.set('isShowAgiographiesEntryLoader', false);
        this._showError(e);
      }

    },

    _angiographyEntryFieldsReset() {
      this.set('model.selectedDate', null);
      this.set('formReset', !this.get('formReset'));
      this.set('paramEmployeeId', null);
      this.set('model.searchEmployeeId', null);
      this.set('patientInfo', null);
      this.set('searchPatientId', null);
      this.set('searchPatientInfo', null);
      this.set('model.selectedEntryAngiographyId', null);
      this.set('model.selectedProcedureId', null);
      this.set('diagnosisItemsSource', emberA());
      this.set('model.selectedDiseaseId',null);
      this.set('model.selectedTimeTypeCode', null);
      this.set('model.isUrgent', false);
      this.set('model.comment', null);
      this.set('isShowCustomInput', false);
      this.set('model.diseaseFilterValue', null);
      this.set('model.entryAngiographyFilterValue', null);
      this.set('model.procedureFilterValue', null);
      this.set('model.customMainProcedure', null);
    }

  });