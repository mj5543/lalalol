import { next } from '@ember/runloop';
import { A as emberA } from '@ember/array';
import { isEmpty } from '@ember/utils';
import layout from './template';
import CHIS from 'framework/chis-framework';
import CatheterizationManagementMixin from '../../../mixins/patient-examination-catheterization-management-mixin';
import MessageMixin from '../../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(
  CatheterizationManagementMixin,
  MessageMixin,
  {
    layout,
    angiographyGroupCode: null,
    angiographiesPartList: null,
    schedulePartItemsSource: null,
    angiographyItemsSource: null,
    searchPatientInfo: null,
    performedList: null,
    addProcedurePopupTarget: null,
    mainProcedureList: null,
    subProcedureList: null,
    isShowContainerLoader: false,
    selectedPartId: null,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'patient-examination-catheterization-management/complete-tab');
      this.setStateProperties([
        'model',
        'completeItemsSource',
        'completeColumns',
      ]);

      if (!this.hasState()) {
        this.set('model', {
          selectedPartId: null,
          selectedAngiographyId: null,
        });
        this.set('schedulePartItemsSource', emberA());
        this.set('angiographyItemsSource', emberA());
        this.set('mainProcedureList', emberA());
        this.set('subProcedureList', emberA());
        this.set('completeItemsSource', emberA());
        this.set('completeColumns', [
          { field: 'isUrgent', title: this.getLanguageResource('1642', 'S', '긴급'), width: 35, align: 'center', bodyTemplateName: 'urgentIcon'},
          { field: 'patientName', title: this.getLanguageResource('4184', 'S', '환자명'), width: 90, align: 'center', bodyTemplateName: 'patientName'},
          { field: 'patientCode', title: this.getLanguageResource('8451', 'S', '등록번호'), width: 65, align: 'center', bodyTemplateName: 'patientCode'},
          { field: 'age', title: this.getLanguageResource('1662', 'S', '나이'), width: 35, align: 'center'},
          { field: 'gender', title: this.getLanguageResource('3680', 'S', '성별'), width: 35, align: 'center'},
          { field: 'diagnosis.name', title: this.getLanguageResource('9601', 'S', '진단명'), width: 200, bodyTemplateName:'colfont', headerTemplateName:'headercolfont01'},
          { field: 'mainProcedure.name', title: this.getLanguageResource('4383', 'S', '시술명'), bodyTemplateName:'colfont', headerTemplateName:'headercolfont02'},
          { field: 'subProcedure.name', title: this.getLanguageResource('9170', 'S', '상세'), width: 150, bodyTemplateName: 'subProcedure'},
          { field: 'isPrepared', title: this.getLanguageResource('10846', 'S', '간호준비완료'), width: 30, align: 'center', bodyTemplateName: 'preparedYN'},
          { field: 'procedureStatusName', title: this.getLanguageResource('3452', 'S', '상태'), width: 60, align: 'center'},
          { field: 'procedureRoomCode', title: this.getLanguageResource('4387', 'S', '시술실'), width: 100, align: 'center', bodyTemplateName: 'roomCombobox'},
          { field: 'assignedPhysician.name', title: this.getLanguageResource('8898', 'S', '진료의'), width: 60, align: 'center'},
          { field: 'timeTypeName', title: this.getLanguageResource('9475', 'S', '예정시간'), width: 60, align: 'center'},
          { field: 'comment', title: this.getLanguageResource('3173', 'S', '비고'), width: 40, align: 'center', bodyTemplateName: 'commentIcon'},
          { field: 'editDatetime', title: this.getLanguageResource('5297', 'S', '완료시간'), width: 100, type: 'date', dataFormat: 'g', align: 'center'},
          { field: 'editStaffName', title: this.getLanguageResource('5300', 'S', '완료자'), width: 70, align: 'center'},
        ]);

        this.set('detailCompleteColumns', [
          { field: 'rsvFirstStaffName', title: this.getLanguageResource('11885', 'S', '최초예약자'), align: 'center'},
          { field: 'rsvFirstDatetime', title: this.getLanguageResource('11886', 'S', '최초예약입력일시'), width: 160, type: 'date', dataFormat: 'g', align: 'center'},
          { field: 'rsvEditStaffName', title: this.getLanguageResource('11887', 'S', '최종예약자'), align: 'center'},
          { field: 'rsvEditDatetime', title: this.getLanguageResource('11888', 'S', '최종예약수정일시'), width: 160, type: 'date', dataFormat: 'g', align: 'center'},
          { field: 'acceptDatetime', title: this.getLanguageResource('7028', 'S', '준비일시'), width: 160, type: 'date', dataFormat: 'g', align: 'center'},
          { field: 'executeDatetime', title: this.getLanguageResource('11889', 'S', '입실일시'), width: 160, type: 'date', dataFormat: 'g', align: 'center'},
          { field: 'recoveryDatetime', title: this.getLanguageResource('7791', 'S', '퇴실일시'), width: 160, type: 'date', dataFormat: 'g', align: 'center'},
          { field: 'transportDatetime', title: this.getLanguageResource('11890', 'S', '이송신청일시'), width: 160, type: 'date', dataFormat: 'g', align: 'center'},
          { field: 'completeDatetime', title: this.getLanguageResource('11891', 'S', '완료일시'), width: 160, type: 'date', dataFormat: 'g', align: 'center'}
        ]);
      }
    },

    onLoaded() {
      this._super(...arguments);
      if(isEmpty(this.get('selectedPartId'))) {
        this.set('selectedPartId', 'Total');
      }
      this._completeTabInit();
    },
    didReceiveAttrs() {
      this._super(...arguments);
      // this.set('model.selectedPartId', this.get('selectedPartId'));
    },
    _setSelectedPartId() {
      this.set('model.selectedPartId', this.get('selectedPartId'));
    },
    actions: {
      onPartIdChagned(e){
        next(this, function(){
          const selectedItem = e.selectedItems[0];
          if (!isEmpty(selectedItem)) {
            this._getAngiographyList(selectedItem.id);
          } else {
            this._getAngiographyList();
          }
          this._getAngiographiesSearchList();
        });
      },

      onProcedureChagned(){
        next(this, function(){
          this._getAngiographiesSearchList();
        });
      },

      onSearchButtonClick() {
        this._getAngiographiesSearchList();
      },

      onGridDoubleClick(e){
        if(isEmpty(e.item)){
          return;
        }
        if(!isEmpty(this.get('patientChangedCB'))) {
          if(!isEmpty(e.item.patientId)){
            this.get('patientChangedCB')(e.item.patientId);
          }
        }
      },
    },

    _completeTabInit() {
      this.set('isShowContainerLoader', true);
      this._getAngiographyRoom();
      this.getSchedulePartItems();
      this.set('model.selectedPartId', this.get('selectedPartId'));
      this._getAngiographiesSearchList();
      // this._getAngiographyStatus();
    },

    async _getAngiographiesSearchList() {
      try {
        this.set('isShowContainerLoader', true);
        this._dataReset();
        const partId = this._getSelectedPartId(this.get('selectedPartId'));
        const params = {
          searchDate: this.getSearchPramsDate(),
          angioGroupCode: this.get('angiographyGroupCode'),
          partId: partId,
          angiographyId: this.get('model.selectedAngiographyId'),
          procedureStatusCode: this.get('model.selectedStatusCode')
        };
        const countResult = await this.get('apiService').getAngiographiesSearch(params);
        const completeList = [];
        if(!isEmpty(countResult)) {
          countResult.forEach(d => {
            if (d.procedureStatusCode === 'Completed') {
              completeList.push(d);
            }
          });
          this.set('completeItemsSource', completeList);
        }else{
          this.set('completeItemsSource', emberA());
        }
        this.set('isShowContainerLoader', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowContainerLoader', false);
          this._showError(e);
        }
      }
    },

    _dataReset() {
      this.set('completeItemsSource', emberA());
    },

    async _getAngiographyRoom() {
      try {
        const roomList = await this.get('apiService').getBusinessCode({classificationCode: 'AngiographyRoom'});
        this.set('angiographyRoomList', roomList);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this._showError(e);
        }
      }
    },
  });