import { next } from '@ember/runloop';
import EmberObject from '@ember/object';
import { A as emberA } from '@ember/array';
import { isEmpty } from '@ember/utils';
import layout from './template';
import CHIS from 'framework/chis-framework';
import CatheterizationManagementMixin from '../../../mixins/patient-examination-catheterization-management-mixin';
import MessageMixin from '../../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(
  CatheterizationManagementMixin,
  MessageMixin,
  {
    layout,
    selectedDate: null,
    angiographyGroupCode: null,
    angiographiesPartList: null,
    schedulePartItemsSource: null,
    angiographyItemsSource: null,
    searchPatientInfo: null,
    performedList: null,
    isAddProcedurePopupOpen: false,
    addProcedurePopupTarget: null,
    mainProcedureList: null,
    subProcedureList: null,
    isShowContainerLoader: false,
    preRoom1Info: null,
    preRoom2Info: null,
    preRoom3Info: null,
    preRoom4Info: null,
    room1Info: null,
    room2Info: null,
    room3Info: null,
    room4Info: null,
    isConsentPopupOpen: false,
    selectedPartId: null,
    isGridReorderRow: false,
    isCommentOpened: false,
    angioComment: null,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'patient-examination-catheterization-management/procedure-tab');
      this.setStateProperties([
        'model',
        'scheduledItemsSource',
        'scheduledColumns',
        'checkInColumns',
        'checkInItemsSource',
        'angiographyRoomList',
        'scheduleCount',
        'isPrepared',
        'angiographyGroupCode',
        'preparedList',
        'statusList',
        'isConsentPopupOpen',
        'isCommentOpened',
        'angioComment'
      ]);

      if (!this.hasState()) {
        this.set('model', {
          selectedAngiographyId: null,
          scheduleGridSelectedItem: null,
          checkinGridSelectedItem: null,
          completeGridSelectedItem: null,
          selectedPerformedItem: null,
          selectedStatusCode: null,
        });
        this.set('schedulePartItemsSource', emberA());
        this.set('angiographyItemsSource', emberA());
        this.set('mainProcedureList', emberA());
        this.set('subProcedureList', emberA());
        this.set('scheduledItemsSource', emberA());

        this.set('detailScheduledColumns', [
          { field: 'rsvFirstStaffName', title: this.getLanguageResource('11885', 'S', '최초예약자'), align: 'center'},
          { field: 'rsvFirstDatetime', title: this.getLanguageResource('11886', 'S', '최초예약입력일시'), width: 160, type: 'date', dataFormat: 'g', align: 'center'},
          { field: 'rsvEditStaffName', title: this.getLanguageResource('11887', 'S', '최종예약자'), align: 'center'},
          { field: 'rsvEditDatetime', title: this.getLanguageResource('11888', 'S', '최종예약수정일시'), width: 160, type: 'date', dataFormat: 'g', align: 'center'},
          { field: 'acceptDatetime', title: this.getLanguageResource('7028', 'S', '준비일시'), width: 160, type: 'date', dataFormat: 'g', align: 'center'},
          { field: 'executeDatetime', title: this.getLanguageResource('11889', 'S', '입실일시'), width: 160, type: 'date', dataFormat: 'g', align: 'center'},
          { field: 'recoveryDatetime', title: this.getLanguageResource('7791', 'S', '퇴실일시'), width: 160, type: 'date', dataFormat: 'g', align: 'center'},
          { field: 'transportDatetime', title: this.getLanguageResource('11890', 'S', '이송신청일시'), width: 160, type: 'date', dataFormat: 'g', align: 'center'},
          { field: 'completeDatetime', title: this.getLanguageResource('11891', 'S', '완료일시'), width: 160, type: 'date', dataFormat: 'g', align: 'center'}
        ]);

        this.set('scheduledColumns', [
          { field: 'isUrgent', title: this.getLanguageResource('1642', 'S', '긴급'), width: 35, align: 'center', bodyTemplateName: 'urgentIcon'},
          { field: 'patientName', title: this.getLanguageResource('4184', 'S', '환자명'), width: 90, align: 'center', bodyTemplateName: 'patientName'},
          { field: 'patientCode', title: this.getLanguageResource('8451', 'S', '등록번호'), width: 65, align: 'center', bodyTemplateName: 'bolder'},
          { field: 'age', title: this.getLanguageResource('1662', 'S', '나이'), width: 35, align: 'center'},
          { field: 'gender', title: this.getLanguageResource('3680', 'S', '성별'), width: 35, align: 'center'},
          { field: 'diagnosis.name', title: this.getLanguageResource('9601', 'S', '진단명'), width: 250, bodyTemplateName:'colfont', headerTemplateName:'headercolfont01'},
          { field: 'mainProcedure.name', title: this.getLanguageResource('4383', 'S', '시술명'), bodyTemplateName:'colfont', headerTemplateName:'headercolfont02'},
          { field: 'subProcedure.name', title: this.getLanguageResource('9170', 'S', '상세'), width: 90, bodyTemplateName: 'tooltip'},
          { field: 'isPrepared', title: this.getLanguageResource('10846', 'S', '간호준비완료'), width: 30, align: 'center', bodyTemplateName: 'preparedYN'},
          { field: 'procedureStatusName', title: this.getLanguageResource('3452', 'S', '상태'), width: 60, align: 'center', bodyTemplateName:'statusName'},
          { field: 'procedureRoomCode', title: this.getLanguageResource('4387', 'S', '시술실'), width: 100, align: 'center', bodyTemplateName: 'roomCombobox'},
          { field: 'assignedPhysician.name', title: this.getLanguageResource('8898', 'S', '진료의'), width: 60, align: 'center'},
          { field: 'timeTypeName', title: this.getLanguageResource('9475', 'S', '예정시간'), width: 60, align: 'center'},
          { field: 'comment', title: this.getLanguageResource('3173', 'S', '비고'), width: 40, align: 'center', bodyTemplateName: 'commentIcon'},
          { field: 'editDatetime', title: this.getLanguageResource('12446', 'S', '변경시간'), width: 100, type: 'date', dataFormat: 'g', align: 'center'},
          { field: 'editStaffName', title: this.getLanguageResource('4158', 'S', '수정자'), width: 70, align: 'center'},

        ]);
        this.set('checkInColumns', [
          { field: 'patientName', title: this.getLanguageResource('4184', 'S', '환자명'), width: 100, align: 'center'},
          { field: 'mainProcedure.name', title: this.getLanguageResource('4383', 'S', '시술명'), width: 100, align: 'center', bodyTemplateName: 'angiographiesName'},
          { field: 'acceptDatetime', title: this.getLanguageResource('4356', 'S', '시간'), width: 100, align: 'center', type: 'date', dataFormat: 't'},
          { field: 'procedureRoomCode', title: this.getLanguageResource('9646', 'S', 'Room'), width: 100, align: 'center', bodyTemplateName: 'roomCombobox'},

        ]);
        this.set('angiographyRoomList', emberA());
        this.set('scheduleCount', 0);

        this.set('contextMenu', emberA([
          EmberObject.create({ action : this.actions.nursingConfirm.bind(this), text: '간호준비완료', disabled: false, display: false}),
          EmberObject.create({ action : this.actions.nursingCancel.bind(this), text: '간호준비취소', disabled: false, display: false}),
          EmberObject.create({ action : this.actions.editComments.bind(this), text: '비고수정', disabled: false, display: true}),
        ]));
      }
    },

    onLoaded() {
      this._super(...arguments);
      if(isEmpty(this.get('selectedPartId'))) {
        this.set('selectedPartId', 'Total');
      }
      this._procedueTabInit();
    },
    didReceiveAttrs() {
      this._super(...arguments);
      // this.set('model.selectedPartId', this.get('selectedPartId'));
    },
    _setSelectedPartId() {
      this.set('model.selectedPartId', this.get('selectedPartId'));
    },

    actions: {
      onPartIdChagned(e){
        const selectedItem = e.selectedItems[0];
        if (!isEmpty(selectedItem)) {
          this._getAngiographyList(selectedItem.id);
        } else {
          this._getAngiographyList();
        }
        next(this, function(){
          this._getAngiographiesSearchList();
        });
      },
      onProcedureChagned(){
        next(this, function(){
          this._getAngiographiesSearchList();
        });
      },

      onStatusChagned(){
        next(this, function(){
          this._getAngiographiesSearchList();
        });
      },

      onGridDoubleClick(e){
        if(isEmpty(e.item)){
          return;
        }
        if(!isEmpty(this.get('patientChangedCB'))) {
          if(!isEmpty(e.item.patientId)){
            this.get('patientChangedCB')(e.item.patientId);
          }
        }
      },

      onLinkedConsentClick(){
        this.set('isConsentPopupOpen', true);
      },

      onSearchButtonClick() {
        this._getAngiographiesSearchList();
        this._getAngiographiesSearchByRoom();
      },
      onAddProcedureClick(e) {
        this.set('addProcedurePopupTarget', e.originalEvent.currentTarget);
        this.set('isAddProcedurePopupOpen', true);
      },
      onProgressClick(item, status) {
        if (isEmpty(item)) {
          const message = this.getLanguageResource('9286', 'F', null, '처리할 내역을 선택하세요');
          this.get('apiService').onShowToast('error', message, '');
          return;
        }
        const params = this.getProcedureParams(item.angiographyId, status);
        // if (status === 'Prepared' && isEmpty(item.procedureRoomCode)) {
        //   this._showComfirmMessage(params);
        //   return;
        // }
        if (!this._dateValidation()) {
          this._showComfirmMessage(params, 'progress');
          return;
        }
        this._getAngiographiesProgress(params);
      },

      nursingConfirm(e){
        const item = e.dataItem.item;
        this._nursingStatusChanged(item, true);
      },

      nursingCancel(e){
        const item = e.dataItem.item;
        this._nursingStatusChanged(item, false);
      },

      editComments(e){
        const item = e.dataItem.item;
        const title = this.getLanguageResource('3173', 'S', '비고');
        this.set('angioComment', {angiographyId: item.angiographyId, comment: item.comment, title: item.patientName + ' ' + title,});
        this.set('isCommentOpened', true);
      },

      onCancelComment(){
        this.set('isCommentOpened', false);
      },

      async onSaveComment(){
        if(isEmpty(this.get('angioComment')) || isEmpty(this.get('angioComment.angiographyId'))){
          return;
        }
        try {
          const params = {
            angiographyPlanId: this.get('angioComment.angiographyId'),
            comment: this.get('angioComment.comment'),
            actionStaffId: this.get('globalCurrentUser.employeeId'),
            actionDatetime: new Date(this.get('co_CommonService').getNow())
          };
          await this.get('apiService').updateAngiographiesComment(params);
          this.set('isCommentOpened', false);
          this.get('apiService').onShowToast('save', this.getLanguageResource('8942', 'S', '저장되었습니다.'), '');
          this._getAngiographiesSearchList();
        } catch(e) {
          this._showSaveError(e);
        }
      },

      onAddProcedureSave() {
        this._addSubProcedure();
      },
      onPreviousClick(item, status) {
        if (isEmpty(item)) {
          const msg = this.getLanguageResource('13206', 'F', null, '항목을 선택해주세요.');
          this.get('apiService').onShowToast('error', msg, '');
          return;
        }
        const params = this.getProcedureParams(item.angiographyId, status);
        if (!this._dateValidation()) {
          this._showComfirmMessage(params, 'undo');
          return;
        }
        this._getPreviousState(params);
      },
      onAngiographyRoomChanged(e) {
        this._getAngiographiesChangeRoom(e.item.businessCode);
      },
      onTreatmentResult() {
        this._getAngiographiesSearchList();
      },
      onGridRowDragEnd(e) {
        this._getAngiographiesChangeSorting(e.source.itemsSource);
      },
    },

    async _showComfirmMessage(params, type) {
      const message = this.getLanguageResource('10118', 'F', null, '당일 시술예약건이 아닙니다. 진행하시겠습니까?');
      const result = await this.get('apiService').showConfirm(message, '');
      if (result === 'Yes') {
        if (type === 'progress') {
          this._getAngiographiesProgress(params);
        } else {
          this._getPreviousState(params);
        }
      }

    },
    _procedueTabInit() {
      this.set('isShowContainerLoader', true);
      this.getSchedulePartItems();
      this._getAngiographyRoom();
      this._getAngiographiesSearchList();
      this._getAngiographiesSearchByRoom();
      this._getAngiographyStatus();
    },

    async _getAngiographiesSearchList() {
      try {
        this.set('isShowContainerLoader', true);
        this._dataReset();
        const partId = this._getSelectedPartId(this.get('selectedPartId'));
        if(isEmpty(partId)) {
          this.set('isGridReorderRow', true);
        }
        const params = {
          searchDate: this.getSearchPramsDate(),
          angioGroupCode: this.get('angiographyGroupCode'),
          partId: partId,
          angiographyId: this.get('model.selectedAngiographyId'),
          procedureStatusCode: this.get('model.selectedStatusCode')
        };
        const countResult = await this.get('apiService').getAngiographiesSearch(params);
        if(!isEmpty(countResult)) {
          countResult.map(d => {
            if(!isEmpty(d.procedureDuration)) {
              d.durationTime = this._getDurationTime(d.procedureDuration);
            }
            d.isRoomDesabled = true;
            if (d.procedureStatusCode === 'Prepared') {
              d.isRoomDesabled = false;
            }
          });
          const notCompleteList = [];
          countResult.forEach(d => {
            if (d.procedureStatusCode !== 'Completed') {
              notCompleteList.push(d);
            }
          });
          this.set('scheduledItemsSource', notCompleteList);
        }else{
          this.set('scheduledItemsSource', emberA());
        }
        this.set('isShowContainerLoader', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowContainerLoader', false);
          this._showError(e);
        }
      }
    },

    async _getAngiographiesSearchByRoom() {
      try {
        this._roomInfoReset();
        const params = {
          searchDate: this.getSearchPramsDate(),
          angioGroupCode: this.get('angiographyGroupCode'),
          partId: null,
          angiographyId: null,
          procedureStatusCode: null
        };
        const countResult = await this.get('apiService').getAngiographiesSearch(params);
        if(!isEmpty(countResult)) {
          const performedList = [];
          const preparedList = [];
          countResult.forEach(d => {
            if (d.procedureStatusCode === 'Prepared') {
              preparedList.push(d);
            } else if (d.procedureStatusCode === 'Performed') {
              performedList.push(d);
            }
          });
          this.set('preparedList', preparedList);
          this.set('performedList', performedList);
          this._getPerformedRoomList();
          this._getPreparedRoomList();
        }
      } catch(e) {
        this._showError(e);
      }
    },

    _getPerformedRoomList() {
      const list = this.get('performedList');
      const room1List = [];
      const room2List = [];
      const room3List = [];
      const room4List = [];
      if(isEmpty(list)){
        return;
      }
      list.forEach(data => {
        if (data.procedureRoomCode === '1') {
          room1List.push(data);
        } else if (data.procedureRoomCode === '2') {
          room2List.push(data);
        } else if (data.procedureRoomCode === '3') {
          room3List.push(data);
        } else if (data.procedureRoomCode === '4') {
          room4List.push(data);
        }
      });
      if (!isEmpty(room1List)) {
        this.set('room1Info', room1List[0]);
        this.set('isDisabledRoom1', true);
      }
      if (!isEmpty(room2List)) {
        this.set('room2Info', room2List[0]);
        this.set('isDisabledRoom2', true);
      }
      if (!isEmpty(room3List)) {
        this.set('room3Info', room3List[0]);
        this.set('isDisabledRoom3', true);
      }
      if (!isEmpty(room4List)) {
        this.set('room4Info', room4List[0]);
        this.set('isDisabledRoom4', true);
      }
    },

    _getPreparedRoomList() {
      const list = this.get('preparedList');
      const room1List = [];
      const room2List = [];
      const room3List = [];
      const room4List = [];
      if(isEmpty(list)){
        return;
      }
      list.forEach(data => {
        if (data.procedureRoomCode === '1') {
          room1List.push(data);
        } else if (data.procedureRoomCode === '2') {
          room2List.push(data);
        } else if (data.procedureRoomCode === '3') {
          room3List.push(data);
        } else if (data.procedureRoomCode === '4') {
          room4List.push(data);
        }
      });
      if (!isEmpty(room1List)) {
        this.set('preRoom1Info', room1List[0]);
      }
      if (!isEmpty(room2List)) {
        this.set('preRoom2Info', room2List[0]);
      }
      if (!isEmpty(room3List)) {
        this.set('preRoom3Info', room3List[0]);
      }
      if (!isEmpty(room4List)) {
        this.set('preRoom4Info', room4List[0]);
      }
    },

    _dataReset() {
      this.set('scheduleCount', 0);
      this.set('scheduledItemsSource', emberA());
      this.set('checkInItemsSource', emberA());
      this.set('isGridReorderRow', false);
      // this._roomInfoReset();

    },

    _roomInfoReset() {
      this.set('performedList', emberA());
      this.set('preparedList', emberA());
      this.set('room1Info', null);
      this.set('room2Info', null);
      this.set('room3Info', null);
      this.set('room4Info', null);
      this.set('preRoom1Info', null);
      this.set('preRoom2Info', null);
      this.set('preRoom3Info', null);
      this.set('preRoom4Info', null);
      this.set('isDisabledRoom1', false);
      this.set('isDisabledRoom2', false);
      this.set('isDisabledRoom3', false);
      this.set('isDisabledRoom4', false);

    },

    async _getAngiographyStatus() {
      try {
        const result = await this.get('apiService').getBusinessCode({classificationCode: 'AngiographyStatus'});
        const statusList = [];
        if(isEmpty(result)){
          return;
        }
        result.forEach(item => {
          if (item.businessCode !== 'Completed') {
            statusList.push(item);
          }
        });
        this.set('statusList', statusList);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this._showError(e);
        }
      }
    },

    async _getPreviousState(params) {
      try {
        await this.get('apiService').updateAngiographiesUndo(params);
        this.showToastSaved();
        await this._getAngiographiesSearchList();
        this._getAngiographiesSearchByRoom();
      } catch(e) {
        this._showSaveError(e);
      }
    },
    async _addSubProcedure() {
      try {
        const params = {
          angiographyPlanId: '',
          subProcedureId: '',
        };
        await this.get('apiService').updateAngiographiesAddProcedure(params);
      } catch(e) {
        //
      }
    },
    async _getAngiographiesProgress(params) {
      try {
        await this.get('apiService').updateAngiographiesProgress(params);
        this.showToastSaved();
        await this._getAngiographiesSearchList();
        this._getAngiographiesSearchByRoom();
      } catch(e) {
        this._showSaveError(e);
      }

    },

    async _getAngiographiesChangeRoom(roomCode) {
      try {
        const selectedItem = this.get('model.scheduleGridSelectedItem');
        if(isEmpty(selectedItem)) {
          return;
        }
        let params = {};
        params = this.getProcedureParams(selectedItem.angiographyId);
        params.procedureRoomCode = roomCode;
        await this.get('apiService').updateAngiographiesChangeRoom(params);
        this.showToastSaved();
        await this._getAngiographiesSearchByRoom();
      } catch(e) {
        this._showSaveError(e);
      }

    },

    async _getAngiographiesChangeSorting(items) {
      try {
        if(isEmpty(items)) {
          return;
        }
        const sortingParam = [];
        items.forEach((data, index) => {
          sortingParam.push({
            angiographyPlanId: data.angiographyId,
            displaySequence: index
          });
        });
        const params = {
          actionStaffId: this.get('globalCurrentUser.employeeId'),
          actionDateTime: new Date(this.get('co_CommonService').getNow()),
          changeAngiographyPlanSorting: sortingParam
        };
        await this.get('apiService').updateAngiographiesChangeSorting(params);
        this.showToastSaved();
      } catch(e) {
        this._showSaveError(e);
      }
    },

    _getDurationTime(time) {
      const min = parseInt(time);
      const day = parseInt(min/1440);
      const hour = parseInt((min%1440)/60);
      const minute = min%60;
      let returnText = `${minute}Min`;
      if (day > 0) {
        returnText = `${day}Day ${hour}Hr ${minute}Min`;
      } else if (hour > 0) {
        returnText = `${hour}Hr ${minute}Min`;
      }
      return returnText;
    },

    async _nursingStatusChanged(item, isNursing){
      const isPrepared = isNursing;
      if(isEmpty(item)){
        return;
      }
      try {
        const params = {
          angiographyPlanId: item.angiographyId,
          isPrepared: isPrepared,
          actionStaffId: this.get('globalCurrentUser.employeeId'),
          actionDatetime: new Date(this.get('co_CommonService').getNow())
        };
        await this.get('apiService').updateAngiographiesPrepare(params);
        this.get('apiService').onShowToast('save', this.getLanguageResource('8942', 'S', '저장되었습니다.'), '');
        this._getAngiographiesSearchList();
      } catch(e) {
        this._showSaveError(e);
      }
    },

    async _getAngiographyRoom() {
      try {
        const roomList = await this.get('apiService').getBusinessCode({classificationCode: 'AngiographyRoom'});
        this.set('angiographyRoomList', roomList);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this._showError(e);
        }
      }
    },
  });