import { A as emberA } from '@ember/array';
import { isEmpty } from '@ember/utils';
import { set } from '@ember/object';
import layout from './template';
import CHIS from 'framework/chis-framework';
import { inject as service } from '@ember/service';
import MessageMixin from '../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(
  MessageMixin,
  {
    layout,

    selectedTabName: null,
    isDisabled: false,
    tabClassType: null,
    angiographyGroupCode: null,
    paramSearchDate1: null,
    paramSearchDate2: null,
    paramSearchDate3: null,
    angiographyPartCode1: null,
    angiographyPartCode2: null,
    angiographyPartCode3: null,
    angiographiesPartList: null,
    isShowLoader: false,
    loaderType: 'spinner',
    isShowDataArea: false,
    apiService:service('patientexamination-angiographies-service'),

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'patient-examination-catheterization-management');
      this.setStateProperties(['isDisabled', 'selectedTabName', 'value', 'dailyStatusList']);

      if (!this.hasState()) {
        this.set('model', {
          selectedPartId: null,
        });
        this.set('isDisabled', false);
        this.set('dailyStatusList', emberA());
        this.set('angiographyGroupCode', null);
        const displayDate = new Date(this.get('co_CommonService').getNow());
        this.set('searchDate', displayDate);
        this.set('calendarSelectedDate', displayDate);
        this.set('paramSearchDate1', displayDate);
        this.set('paramSearchDate2', displayDate);
        this.set('paramSearchDate3', displayDate);
        this.set('model.selectedPartId', 'Total');
      }
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1624');

      if(!isEmpty(this.get('parameters'))){
        const angiographyGroupCode = this.get('parameters').angiographyGroupCode;
        this.set('angiographyGroupCode', angiographyGroupCode);
      }else{
        this.set('angiographyGroupCode', 'angiography');
      }
      this._getDataList();

    },
    didUpdateAttrs() {
      this._super(...arguments);
    },

    actions: {
      onTabLoaded() {
        //
      },
      onSelectionChangedAction(e) {
        const dailyStatusList = this.get('dailyStatusList');
        const targetPartId = this.get('model.selectedPartId');
        if (!isEmpty(dailyStatusList)) {
          dailyStatusList.map((items, index) => {
            if(isEmpty(targetPartId) && index === 0) {
              set(items, 'class', 'on');
            } else {
              set(items, 'class', '');
            }
            if(!isEmpty(targetPartId) && items.angiographyPartId === targetPartId) {
              set(items, 'class', 'on');
            }
            items.angiographyProcedureStatus.map((data, ind) => {
              if(isEmpty(targetPartId) && ind === 0) {
                set(data, 'class', 'on');
              } else {
                set(data, 'class', '');
              }
              if (items.angiographyPartId === targetPartId && data.procedureStatusCode === e.dataItem.id) {
                set(data, 'class', 'on');
              }
            });
          });
        }
      },
      onDateChanged(e) {
        const selectedDate = e.selectedDate;
        this._childParamsReset(selectedDate);
        this._getAngiographiesDailyStatus();

      },
      onSearchDailyStatus() {
        this._childParamsReset(this.get('searchDate'));
        this._getAngiographiesDailyStatus();
      },
      onTabChange(tab, partId) {
        this.set('model.selectedPartId', partId);
        this._setTabsPartId(tab);
        if(this.get('selectedTabName') === tab) {
          this._angiographyPartIdChange(partId, tab);
        } else {
          this.set('selectedTabName', tab);
          this._angiographyPartIdChange(partId);
        }
      },
      onPartChanged(partId){
        this.set('model.selectedPartId', partId);
        this._setAllTabPartId();
        this._angiographyPartIdChange(partId, this.get('selectedTabName'));
      },

      onPatientInfoSetting(patientId){
        this.onGlobalPatientInfo(patientId);
      }
    },

    _angiographyPartIdChange(code, name) {
      const dailyStatusList = this.get('dailyStatusList');
      if (!isEmpty(dailyStatusList)) {
        dailyStatusList.map(items => {
          set(items, 'class', '');
          if (items.angiographyPartId === code) {
            set(items, 'class', 'on');
          }
          items.angiographyProcedureStatus.map(data => {
            set(data, 'class', '');
            if(!isEmpty(name)) {
              if (items.angiographyPartId === code && data.procedureStatusCode === name) {
                set(data, 'class', 'on');
              }
            }
          });
        });
      }
      this.set('angiographyPartCode1', code);
      this.set('angiographyPartCode2', code);
      this.set('angiographyPartCode3', code);
      this.set('model.selectedPartId', code);
    },

    _setTabsPartId(tab) {
      const parentPartId = this.get('model.selectedPartId');
      switch(tab) {
        case 'Schedule':
          this.set('angiographyPartCode1', parentPartId);
          this.set('paramSearchDate1', this.get('searchDate'));
          break;
        case 'Procedure':
          this.set('angiographyPartCode2', parentPartId);
          this.set('paramSearchDate2', this.get('searchDate'));
          break;
        case 'Complete':
          this.set('angiographyPartCode3', parentPartId);
          this.set('paramSearchDate3', this.get('searchDate'));
          break;
        default:
          this.set('angiographyPartCode1', 'Total');
      }
    },

    _setAllTabPartId() {
      const parentPartId = this.get('model.selectedPartId');
      this.set('angiographyPartCode1', parentPartId);
      this.set('paramSearchDate1', this.get('searchDate'));
      this.set('angiographyPartCode2', parentPartId);
      this.set('paramSearchDate2', this.get('searchDate'));
      this.set('angiographyPartCode3', parentPartId);
      this.set('paramSearchDate3', this.get('searchDate'));
      // this.set('angiographyPartCode1', 'Total');
    },

    async onGlobalPatientInfo(patientId){
      let viewType = '';
      if(this.get('angiographyGroupCode') === 'cardiography'){
        viewType = '_cardiography';
      }

      try {
        const param = {
          patientId: patientId
        };
        const result = await this.get('apiService').getCurrentEncounter(param);
        if(isEmpty(result)){
          const globalItem = {
            patientChoicePath: 'Patient',
            patientId: patientId,
            encounterId: null,
            examination:{
              state: 'Request',
            },
            patientSelectionSource: {
              viewId:  this.get('viewId') + viewType
            }
          };
          const menuInfo = emberA();
          this.get('co_PatientManagerService').selectPatient(globalItem, menuInfo);
        }else{
          const globalItem = {
            patientChoicePath: 'Encounter',
            patientId: patientId,
            encounterId: result,
            examination:{
              state: 'Request',
            },
            patientSelectionSource: {
              viewId:  this.get('viewId') + viewType
            }
          };
          const menuInfo = emberA();
          this.get('co_PatientManagerService').selectPatient(globalItem, menuInfo);
        }
      } catch(e) {
        this._showError(e);
      }
    },

    async _getDataList() {
      await this._getAngiographiesDailyStatus();
      this.set('isShowDataArea', true);
      await this._getAngiographiesPartList();
    },

    async _getAngiographiesPartList() {
      try {
        const param = {
          angioGroupCode: this.get('angiographyGroupCode'),
          isUsed: true
        };
        const partResult = await this.get('apiService').getAngiographiesPart(param);
        this.set('angiographiesPartList', partResult);
        this.set('angiographyPartCode1', 'Total');
      } catch(e) {
        this._showError(e);
      }
    },

    async _getAngiographiesDailyStatus() {
      try {
        this.set('isShowLoader', true);
        const params = {
          searchDate: new Date(this.get('searchDate').getFullYear(), this.get('searchDate').getMonth(), this.get('searchDate').getDate()).toFormatString(),
          angioGroupCode: this.get('angiographyGroupCode'),
        };
        const result = await this.get('apiService').getAngiographiesDailyStatus(params);
        if(!isEmpty(result)){
          result.map((item, ind) => {
            item.class = '';
            const classIdx = ind+1;
            if(classIdx < 10){
              item.index = `0${classIdx}`;
            }else if (classIdx == 10){
              item.index = classIdx;
            }else{
              item.index = `0${classIdx-9}`;
            }
            if (ind === 0) {
              item.class = 'on';
              item.index = '';
            }
            item.angiographyProcedureStatus.map(d => {
              d.class = '';
              if (item.angiographyPartId === 'Total' && d.procedureStatusCode === 'Schedule') {
                d.class = 'on';
              }
            });
          });
          this.set('dailyStatusList', result);
          this.set('isShowLoader', false);
        }else{
          this.set('dailyStatusList', []);
          this.set('isShowLoader', false);
        }

      } catch(e) {
        this._showError(e);
      }
    },

    _childParamsReset(date) {
      this.set('paramSearchDate1', date);
      this.set('paramSearchDate2', date);
      this.set('paramSearchDate3', date);
      this.set('angiographyPartCode1', 'Total');
      this.set('angiographyPartCode2', 'Total');
      this.set('angiographyPartCode3', 'Total');
      this.set('model.selectedPartId', 'Total');
    },

    didInsertElement() {
      this._super(...arguments);
      this.get('co_ContentMessageService').subscribeMessage('afterHideAccessPopup', this.get('viewId'), this, this._afterHideAccessPopup);
    },

    _afterHideAccessPopup(param) {
      if(param.viewId.substring(0, 46) === this.get('viewId')){
        if(param.isConfirmed === true) {
          this.triggerAction('onMainWorkListContainerOpenStateChange', false, 'hide');
        }
      }
    },
  });
