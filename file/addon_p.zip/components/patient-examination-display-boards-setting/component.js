/* eslint-disable no-console */
import layout from './template';
import CHIS from 'framework/chis-framework';
import MesaggeMixin from '../../mixins/patient-examination-message-mixin';
import config from 'patientexamination-module/app-config';
import { isEmpty, isPresent, isEqual } from '@ember/utils';
import { A } from '@ember/array';
import { cancel , later } from '@ember/runloop';
import { set } from '@ember/object';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  MesaggeMixin,
  {
    layout,
    examinationGroupCode: null,
    bNewTab : false,
    listLimit: 4,
    hospitalImagePath: null,
    divisionCount: null,
    isGroupDisabled: false,
    isShowLoader: false,

    onPropertyInit(){
      this._super(...arguments);
      // this.set('viewId', 'patient-examination-display-boards-setting');
      this.setStateProperties(['prop1', 'prop2', 'serverModel']);
      const defaultUrl = this.get('fr_HostConfigService')
        .getEnvConfig('ServerCallConfig', 'patientexamination') +
        `patient-examination/${config.version}/`;

      this.set('defaultUrl', defaultUrl);
      this.set('technicalServiceUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'technicalServiceUrl')+'file/v4/');
      const userInfoSets = this.get('co_CurrentUserService.user');
      let hospitalId = null;
      let tenantId = null;
      if(!isEmpty(userInfoSets)){
        hospitalId = userInfoSets.hospital.hospitalId;
        tenantId = userInfoSets.tenant.tenantId;
      }
      this.set('fileUrl', this.get('technicalServiceUrl')+tenantId+'/'+hospitalId+'/view');
      if(!isEmpty(this.get('co_CommonService.hospitalInfo')) && !isEmpty(this.get('co_CommonService.hospitalInfo.hospitalImageContent'))) {
        const imageInfo = this.get('co_CommonService.hospitalInfo.hospitalImageContent').find(d => d.hospitalImageType === 2);
        if(!isEmpty(imageInfo)) {
          this.set('hospitalImagePath', `${this.get('fileUrl')}/${imageInfo.imagePath}`);
        }
      }
      const divisionList = [];
      const listLimit = this.get('listLimit');
      for(let i = 0; i < listLimit; i++) {
        divisionList.push({
          code: i+1,
        });
      }
      this.set('divisionCountList', divisionList);
    },
    onLoaded(){
      this._super(...arguments);
      let viewId = 'patient-examination-display-boards-setting';
      const contentParameters = this.getOpenMenuParams();
      if(isPresent(contentParameters)) {
        this.set('examinationGroupCode', contentParameters.examinationGroupCode);
        this.set('isGroupDisabled', true);
        viewId = 'patient-examination-display-boards-setting_radiology';
      }
      this.set('viewId', viewId);
      this.set('ctxmenu', [
        { text: this.getLanguageResource('17458', 'F', null, '전체화면'), disabled: false, display: true, checked: true, action: this._requestFullscreen.bind(this) },
        { text: this.getLanguageResource('17459', 'F', null, '전광판 닫기'), disabled: false, display: true, checked: true, action: this._exitBoardScreen.bind(this) },
      ]);
      const ip = isEmpty(this.get('fr_GlobalSystemService.localMacAddress')) ? '' : this.get('fr_GlobalSystemService.localMacAddress');
      let infoKey = `examination-dashboard-${ip}`;
      if(isPresent(this.get('examinationGroupCode'))) {
        infoKey = `examination-dashboard-${this.get('examinationGroupCode')}-${ip}`;
      }
      const _viewItem = this.get('fr_GlobalSystemService.queryParams');
      this.set('isShowLoader', true);
      this.get('co_PersonalizationService').getSettingInfo(infoKey).then((result) => {
        if (!isEmpty(result) && !isEmpty(result.settingValue)) {
          const settingValue = JSON.parse(result.settingValue);
          if (!isEmpty(settingValue.conditionData) && settingValue.conditionData.length > 0) {
            this.set('examinationRoomList', settingValue.conditionData[0].examinationRoomList);
            this.set('divisionCount', settingValue.conditionData[0].divisionCount);
            this.set('imagePath',A(settingValue.conditionData[0].imagePath));
            this.set('scrollText',A(settingValue.conditionData[0].scrollText));
            if(!isEmpty(this.get('imagePath'))){
              this._validationImagePath(this.get('imagePath'));
            }
            if(!isEmpty(_viewItem)&&!isEmpty(_viewItem.callGuid)){
              if (!isEqual(this.get('componentGuid'),_viewItem.callGuid)) {
                this.send('onOpenAction');
              }
            }
          }
        } else {
          this._setDefualtSettings(infoKey);
        }
        this.set('isShowLoader', false);
      });
    },
    didInsertElement(){
      this._super(...arguments);
      this.get('co_ContentMessageService').subscribeMessage('SET_OPEN_EXAMINATION_PATIENT_LIST_BOARD', this.get('currentMenuId'), this, this.setDashboard);
    },
    willDestroyElement() {
      this._super(...arguments);
      this.get('co_ContentMessageService').unsubscribeMessage('SET_OPEN_EXAMINATION_PATIENT_LIST_BOARD', this.get('currentMenuId'), this, this.setDashboard);
    },
    actions: {
      onChangedDisplayDivision(e) {
        if(isEmpty(this.get('examinationRoomList'))) {
          return;
        }
        this.get('examinationRoomList').forEach(d => {
          let isDisabled = true;
          if(e.item.code >= d.no) {
            isDisabled = false;
          } else {
            set(d, 'roomCode', null);
            set(d, 'roomName', null);
            set(d, 'displayRoomName', null);
          }
          set(d, 'isDisabled', isDisabled);
        });
      },
      onPopupExamintionRoom(item, e) {
        this.set('currentSettingItem', item);
        this.set('isRoomPopupOpen', true);
        this.set('placementTargetId', `#${e.source.elementId}`);
      },
      onExaminationRoomCB(item){
        console.log('onExaminationRoomCB--', item);
        const currentSettingItem = this.get('currentSettingItem');
        this.get('examinationRoomList').forEach(d => {
          if(d.no === currentSettingItem.no) {
            set(d, 'roomCode', item.examinationRoomId);
            set(d, 'roomName', item.examinationRoomName);
            set(d, 'displayRoomName', item.examinationRoomName);
          }
        });
        this.set('currentSettingItem', null);
      },
      onOpenAction() {
        if(this._openValidation()){
          const ip = isEmpty(this.get('fr_GlobalSystemService.localMacAddress')) ? '' : this.get('fr_GlobalSystemService.localMacAddress');
          let infoKey = `examination-dashboard-${ip}`;
          if(isPresent(this.get('examinationGroupCode'))) {
            infoKey = `examination-dashboard-${this.get('examinationGroupCode')}-${ip}`;
          }
          if(!isEmpty(this.get('imageFile'))){
            var result = this.get('fr_UploadHelperService').putFileObject(this.get('viewId'), this.get('imageFile'));
            result.then((data) => {
              //console.log(data);//업로드한 파일의 file ID를 확인할 수 있습니다.
              this.set('imagePath', data[0].fileKey);
              this._setSettingInfo(infoKey);
            });
          }else{
            this._setSettingInfo(infoKey);
          }
          if(!this.get('bNewTab')){
            this._getRoomByPatientList();
            this.set('isOpen', true);
            const _viewItem = this.get('fr_GlobalSystemService.queryParams');
            if(isEmpty(Object.keys(_viewItem))) {
              this._requestFullscreen();
            }
            this._setAutoSearch();
          }else{
            this._gnbNewTab();
          }
        }else{
          this.get('toast').toastr({ type: 'error', content: this.getLanguageResource('10570', 'F', null, '필수입력값이 누락되었습니다.'), title: '', option: { closeButton: false, timeOut: 3000, positionClass: 'toast-bottom-center' } });
        }
      },
      onClosed() {
        cancel(this.get('autoSearchTimer'));
      },
      onOpened() {
        //
      },
      onChangedSignImage(){
        const _files = this.get('imageFile');
        if(_files.length > 0){
          this.set('backgroundImage', URL.createObjectURL(_files[0]));
        }
      },
      onClickImageReset(){
        this.set('backgroundImage', null);
        this.set('imagePath',null);
        this.set('imageFile',null);
        this.set('serverImage',null);
      },
      onBoardLoaded(e) {
        this.set('boardSource', e.source);
      },
      onContextOpen() {
        //
      },
    },
    async _getRoomByPatientList() {
      try {
        const examinationRoomList = this.get('examinationRoomList').filter(d => !d.isDisabled);
        if(isEmpty(examinationRoomList)) {
          return;
        }
        let isCountOne = false;
        let isCountTwo = false;
        const roomIds = examinationRoomList.map(d => d.roomCode);
        const params = {
          examinationRoomIds: roomIds.join('&examinationRoomIds=')
        };
        if(examinationRoomList.length === 1) {
          isCountOne = true;
        } else if(examinationRoomList.length === 2) {
          isCountTwo = true;
        }
        const result = await this.getList(`${this.get('defaultUrl')}checkins/display-boards`, params, null);
        if(isPresent(result)) {
          result.map(d => {
            d.displayPatientName = this.maskingName(d.patientName);
          });
          examinationRoomList.forEach(item => {
            const findRoomsPatients = result.filter(d => d.examinationRoomId === item.roomCode);
            const listL = [];
            const listR = [];
            if(isPresent(findRoomsPatients)) {
              findRoomsPatients.forEach((p, ind) => {
                if(ind <= 10) {
                  listL.push(p);
                } else if(ind > 10) {
                  listR.push(p);
                }
              });
            }
            set(item, 'patientList', listL);
            set(item, 'listL', listL);
            set(item, 'listR', listR);
          });
        } else {
          examinationRoomList.forEach(item => {
            set(item, 'patientList', null);
            set(item, 'listL', null);
            set(item, 'listR', null);
          });
        }
        this.set('isSingle', isCountOne);
        this.set('isTwo', isCountTwo);
        this.set('boardList', examinationRoomList);
      } catch(e) {
        this._showError(e);
      }
    },
    async _validationImagePath(fileId) {
      try {
        const tenantId = this.get('co_CurrentUserService.user.tenant.tenantId');
        const hospitalId = this.get('co_CurrentUserService.user.hospital.hospitalId');
        const path = this.get('technicalServiceUrl') + tenantId+'/'+hospitalId+'/file/'+fileId;
        const res = await this.getList(path, null, null);
        if(!isEmpty(res)){
          var result = this.get('fr_UploadHelperService').getFileView(fileId);
          result.then((data) => {
            this.set('serverImage',data[0]);
            this.set('backgroundImage',data[1]);
          });
        }
      }catch(e) {
        console.log(e);
        if(e.status === 404) {
          this.set('imagePath',null);
          this.set('backgroundImage',null);
          this.get('toast').toastr({ type: 'error', content: this.getLanguageResource('17415', 'F', null, '이미지에 오류가 있습니다.'), title: '', option: { closeButton: false, timeOut: 3000, positionClass: 'toast-bottom-center' } });
        }
      }
    },
    _setDefualtSettings(infoKey) {
      const examinationRoomList = [];
      const listLimit = this.get('listLimit');
      for(let i = 0; i < listLimit; i++) {
        examinationRoomList.push({
          no: i+1,
          roomCode: null,
          roomName: null,
          displayRoomName: null,
          isDisabled: true,
        });
      }
      let settingData = [];
      settingData = {
        conditionData: [
          {
            divisionCount: null,
            imagePath: null,
            scrollText: null,
            examinationRoomList: examinationRoomList,
          }
        ]
      };
      this.set('examinationRoomList', examinationRoomList);
      this.get('co_PersonalizationService').setSettingInfo(infoKey, JSON.stringify(settingData), '검사실 대기설정 저장');
    },
    _setSettingInfo(infoKey) {
      const settingData = {
        conditionData: [
          {
            divisionCount: this.get('divisionCount'),
            imagePath: isEmpty(this.get('imagePath')) ? null : this.get('imagePath'),
            scrollText: isEmpty(this.get('scrollText')) ? null : this.get('scrollText'),
            examinationRoomList: this.get('examinationRoomList'),
          }
        ]
      };
      this.get('co_PersonalizationService').setSettingInfo(infoKey, JSON.stringify(settingData), '검사실 대기설정 저장');
    },
    setDashboard(e){
      if(!isEqual(this.get('currentMenuId'), e.componentGuid)){
        if(this.get('isDestroyed')){
          this.get('co_ContentMessageService').unsubscribeMessage('SET_OPEN_EXAMINATION_PATIENT_LIST_BOARD', this.get('currentMenuId'), this, this.setDashboard);
        } else {
          this.send('onOpenAction');
        }
      }
    },
    _gnbNewTab() {
      const _viewId = this.get('viewId');
      const _componentGuid = this.get('componentGuid');
      const _url = location.origin + `?newTab=true&view=${_viewId}&callGuid=${_componentGuid}`;
      window.open(_url,"", "_blank");
    },
    _setAutoSearch() {
      if(this.get('isDestroyed')) {
        return;
      }
      const self = this;
      this.set('timer', this.get('fr_I18nService').formatDate(new Date(), 'g'));
      this.set('autoSearchTimer', later(function () {
        self._getRoomByPatientList();
        self._setAutoSearch();
      }, 10000));
    },
    _openValidation() {
      const examinationRoomList = this.get('examinationRoomList');
      const tagetItems = examinationRoomList.filter(d => !d.isDisabled);
      if(isEmpty(tagetItems)) {
        return false;
      } else if(isPresent(tagetItems.find(d => d.roomCode === null))) {
        return false;
      } else {
        return true;
      }
    },
    _exitBoardScreen () {
      const _viewItem = this.get('fr_GlobalSystemService.queryParams');
      if (document.fullscreenElement && document.exitFullscreen) {
        //Standard syntax
        document.exitFullscreen().then(() => {
          if(isEmpty(Object.keys(_viewItem))) {
            this.set('isOpen', false);
          }
          console.log("Document Exited from Full screen mode");
        }).catch((err) => console.error(err));
      } else if (document.webkitFullscreenElement && document.webkitExitFullscreen) {
        //Safari and Opera syntax
        document.webkitExitFullscreen();
      } else if (document.msFullscreenElement && document.msExitFullscreen) {
        //IE11 syntax
        document.msExitFullscreen();
      }
      if(document.fullscreenElement === null && isEmpty(Object.keys(_viewItem))) {
        this.set('isOpen', false);
      } else {
        window.open('','_self').close();
      }
    },
    _requestFullscreen() {
      let docV = document.getElementById(this.get('boardSource.elementId'));
      if (docV.requestFullscreen) {
        docV.requestFullscreen();
      } else if (docV.webkitRequestFullscreen) {
        docV.webkitRequestFullscreen();
      } else if (docV.msRequestFullscreen) {
        docV.msRequestFullscreen();
      }
      docV = null;
    },
    maskingName(strName){
      if(strName.length > 2){
        const originName = strName.split('');
        originName.forEach(function(name,i){
          if(i === 0 || i === originName.length-1) {
            return;
          }
          originName[i] = 'O';
        });
        var joinName = originName.join();
        return joinName.replace(/,/gu,'');
      }else{
        var pattern = /.$/u;
        return strName.replace(pattern, 'O');
      }
    }
  });