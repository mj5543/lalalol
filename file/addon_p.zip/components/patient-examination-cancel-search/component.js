import { next } from '@ember/runloop';
import { isEmpty } from '@ember/utils';
import { A as emberA } from '@ember/array';
import EmberObject from '@ember/object';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'patientexamination-module/app-config';
import MessageMixin from '../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  MessageMixin,
  {
    layout,
    model: null,
    conductUrl: null,
    patientId: null,
    cancelGrid:  null,
    cancelReasonItems: null,
    examinationGroupCode: null,
    isPageLoader: false,
    peApiService:service('patientexamination-service'),

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'patient-examination-cancel-search');

      this.setStateProperties([
        'model',
        'cancelGrid',
        'patientId',
        'conductUrl',
        'cancelReasonItems',
        'examinationGroupCode',
        'isPageLoader'
      ]);

      if(this.hasState()===false) {

        const conductUrl = this.get('fr_HostConfigService')
          .getEnvConfig('ServerCallConfig', 'patientexamination') +
          `patient-examination/${config.version}/conductions`;

        this.set('conductUrl', conductUrl);
        this.set('model',
          EmberObject.create({fromDate: this.get('co_CommonService').getNow().addDays(-30),
            toDate : this.get('co_CommonService').getNow(),
            reasonId : null}));

        this.set('cancelGrid', emberA({columns: emberA(), itemsSource: emberA()}));
        this.set('cancelGrid.columns', [
          { field: 'cancelDate', title: this.getLanguageResource('17040', 'S', '취소일'), width:120, type: 'date', dataFormat: 'g' , align: 'center'},
          { field: 'patientCode', title: this.getLanguageResource('8451', 'S', '등록번호'), width: 100, align: 'center'},
          { field: 'patientName', title: this.getLanguageResource('4184', 'S', '환자명'), align: 'center', width: 100},
          { field: 'orderInformation.issuedDate', title: this.getLanguageResource('5246', 'F', '오더일'), width: 90, type: 'date', dataFormat: 'd', align: 'center'},
          { field: 'orderInformation.examinationCode', title: this.getLanguageResource('16919', 'S', '검사코드'), width:90, align: 'center'},
          { field: 'orderInformation.examinationName', title: this.getLanguageResource('16806', 'S', '검사'), width:200, align: 'left'},
          { field: 'executeDate', title: this.getLanguageResource('17047', 'S', '검사시행일'), width:120, type: 'date', dataFormat: 'g' , align: 'center'},
          { field: 'cancelStaff.name', title: this.getLanguageResource('7602', 'S', '취소자'), width:100, align: 'center'},
          { field: 'reason', title: this.getLanguageResource('3332', 'S', '사유'), width: 180, align: 'left', bodyTemplateName:'otherReason'},
          { field: 'reasonDescription', title: this.getLanguageResource('11051', 'F', '비고'), align: 'left', bodyTemplateName:'tooltip'},
        ]);
      }
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1360');

      const getOpenMenuParams = this.getOpenMenuParams();
      if(!isEmpty(getOpenMenuParams)){
        this.set('examinationGroupCode', getOpenMenuParams.examinationGroupCode);
      }else{
        this.set('examinationGroupCode', null);
      }
      this._getReasonItem();
      //this._onSearchList();
    },

    actions: {
      onSearchList(){
        this._onSearchList();
      },

      onGetPatient(result) {
        if(!isEmpty(result)){
          //this.get('peApiService').onPatintGlobalSet('Patient', result.patientId, null);
          this.set('patientId', result.patientId);
          //this._onSearchList();
        }
      },

      onPatientClear(){
        this.set('patientId', null);
        //this._onSearchList();
      }
    },

    _getReasonItem(){
      try {
        this.set('cancelReasonItems', emberA());
        this.get('peApiService').onGetBusinessCodeList('CancelReason', null).then(function(data){
          this.get('cancelReasonItems').pushObject({businessCodeId: '', name: this.getLanguageResource('11734', 'S', '전체')});
          this.get('cancelReasonItems').pushObjects(data);
          next(this, function(){
            this.set('model.reasonId', '');
          });
        }.bind(this));
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this._showError(e);
        }
      }
    },

    _onSearchList(){
      try {
        this.set('cancelGrid.itemsSource', emberA());
        const period = {fromDate : this.get('model.fromDate'), toDate : this.get('model.toDate')};
        const path = this.get('conductUrl') + '/cancel-list';
        const queryParams = {
          fromDate: new Date(period.fromDate.getFullYear(), period.fromDate.getMonth(), period.fromDate.getDate(), 0, 0, 0).toFormatString(),
          toDate: new Date(period.toDate.getFullYear(), period.toDate.getMonth(), period.toDate.getDate(), 0, 0, 0).addDays(1).toFormatString(),
          patientId: this.get('patientId'),
          examinationGroupCode: this.get('examinationGroupCode')
        };
        this.set('isPageLoader', true);
        this.getList(path, queryParams, null, false).then((res) => {
          if(!isEmpty(res)){
            if(!isEmpty(this.get('model.reasonId'))){
              const filterResult = res.filterBy('reasonId', this.get('model.reasonId'));
              if(isEmpty(filterResult)){
                this.get('peApiService').onShowToast('notify', this.getLanguageResource('10872', 'F', '검색결과가 없습니다.'), '');
              }else{
                this.set('cancelGrid.itemsSource', filterResult);
              }
            }else{
              this.set('cancelGrid.itemsSource', res);
            }
            next(this, function(){
              this.set('isPageLoader', false);
            });
          }else{
            this.get('peApiService').onShowToast('notify', this.getLanguageResource('10872', 'F', '검색결과가 없습니다.'), '');
            next(this, function(){
              this.set('isPageLoader', false);
            });
          }
        });
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isPageLoader', false);
          this._showError(e);
        }
      }
    },

  });