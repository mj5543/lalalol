import { next } from '@ember/runloop';
import { A as emberA } from '@ember/array';
import { isEmpty, isPresent } from '@ember/utils';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'patientexamination-module/app-config';
import EmberObject from '@ember/object';
import { inject as service } from '@ember/service';
import MesaggeMixin from '../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MesaggeMixin,{
  layout,
  model: null,
  examinationGridColumns: null,
  examinationDataList: null,
  defaultUrl: null,
  userGlobalInformation: null,
  isPageLoader: false,
  peApiService:service('patientexamination-service'),

  onPropertyInit(){
    this._super(...arguments);
    this.set('viewId', 'patient-examination-progress-search');

    this.setStateProperties([
      'patientId',
      'examinationGridColumns',
      'examinationDataList',
      'defaultUrl',
      'isPageLoader',
      'userGlobalInformation',
    ]);

    if(this.hasState()===false) {

      const defaultUrl = this.get('fr_HostConfigService')
        .getEnvConfig('ServerCallConfig', 'patientexamination') +
        `patient-examination/${config.version}/`;

      this.set('defaultUrl', defaultUrl);

      const examinationGridColumns=[
        { field: 'executeDate', title: this.getLanguageResource('17047', 'S', '시행일자'), width:120, type: 'date', dataFormat: 'g' , align: 'center'},
        { field: 'examination.name', title: this.getLanguageResource('16806', 'S', '검사'), bodyTemplateName:'examName'},
        { field: 'medicalDepartmentName', title: this.getLanguageResource('7111', 'S', '진료과'), width: 75, align: 'center'},
        { field: 'wardName', title: this.getLanguageResource('2749', 'S', '병동'), width: 60, align: 'center'},
        { field: 'issuedDate', title: this.getLanguageResource('5246', 'F', '오더일'), width:100, type: 'date', dataFormat:'d', align: 'center'},
        { field: 'issuedDoctorName', title: this.getLanguageResource('9686', 'S', '처방의'), width:80, align: 'center'},
        { field: 'statusName', title: this.getLanguageResource('732', 'S', '검사상태'), width:90, align: 'center', bodyTemplateName:'status'},
        { field: 'paymentStatusName', title: this.getLanguageResource('3859', 'S', '수납'), width:50, align: 'center', bodyTemplateName:'paid'},
        { field: 'prescribedTypeName', title: this.getLanguageResource('9284', 'S', '오더유형'), width:120, align: 'left' },
        { field: 'acceptDate', title: this.getLanguageResource('10244', 'S', '접수일시'), width:120, type: 'date', dataFormat: 'g' , align: 'center'},
        { field: 'interpretationDate', title: this.getLanguageResource('7955', 'S', '판독일시'), width:120, type: 'date', dataFormat: 'g' , align: 'center'},
        { field: 'examinationRoom.name', title: this.getLanguageResource('743', 'S', '검사실'), width:120, align: 'center' },
      ];
      this.set('examinationGridColumns', examinationGridColumns);
      this.set('model', {examinationGroupCode: null,
        patientId: null,
        fromDate: this.get('co_CommonService').getNow().addYears(-3),
        toDate: this.get('co_CommonService').getNow(),
        perform : true,
        preliminary : true,
        complete : true,
      });

    }
  },

  onLoaded() {
    this._super(...arguments);

    const selectCondition = this.getOpenMenuParams();
    if(!isEmpty(selectCondition)){
      this.set('model.examinationGroupCode', selectCondition.examinationGroupCode);
    }

    if(!isEmpty(this.get('co_PatientManagerService.selectedPatient'))){
      const patientGlobalInformation = this.get('co_PatientManagerService.selectedPatient');

      this.set('model.patientId', patientGlobalInformation.patientId);
      this._getExaminationList();
    }
    this.set('menuClass', 'w1360');
  },

  actions:{
    onSearchList(){
      this._getExaminationList();
    },
  },

  /* onPatientChanged(Patient){
    this._super(...arguments);
    if(isEmpty(Patient)){
      return;
    }
    this.set('model.patientId', Patient.patientId);
    this._getExaminationList();
  }, */

  onPatientChanged(Patient){
    this._super(...arguments);
    if(isEmpty(Patient)){
      return;
    }

    if(this.checkPatientDataClear()===true){
      this._allClear();
    }else{
      this.set('model.patientId', Patient.patientId);
      this._getExaminationList();
    }
  },

  _getExaminationList(){
    try {
      if(isEmpty(this.get('model.patientId'))){
        return;
      }
      this.set('examinationDataList',emberA());
      const path = this.get('defaultUrl') + 'conductions/patient-all-conductions';
      const statusCodeList = emberA();
      if(this.get('model.perform')){
        statusCodeList.pushObject(4);
      }
      if(this.get('model.preliminary')){
        statusCodeList.pushObject(5);
      }
      if(this.get('model.complete')){
        statusCodeList.pushObject(6);
      }
      const queryParams = {
        patientId: this.get('model.patientId'),
        examinationGroupCode: this.get('model.examinationGroupCode'),
        fromDate: this.get('model.fromDate'),
        toDate: this.get('model.toDate'),
        statusCode: statusCodeList
      };
      if(isPresent(queryParams.statusCode)){
        queryParams.statusCode = queryParams.statusCode.join('&statusCode=');
      }else{
        return;
      }
      this.set('isPageLoader', true);
      this.getList(path, queryParams, null).then(function(data){
        this.set('examinationDataList',data);
        next(this, function(){
          this.set('isPageLoader', false);
        });
      }.bind(this));
    } catch(e) {
      if(!this.get('isDestroyed')) {
        this.set('isPageLoader', false);
        this._showError(e);
      }
    }
  },

  _allClear(){
    this.set('patientInfo', EmberObject.create());
    this.set('examinationDataList', emberA());
  },
});