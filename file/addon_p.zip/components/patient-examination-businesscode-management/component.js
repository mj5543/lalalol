import { inject as service } from '@ember/service';
import { isEmpty, isPresent } from '@ember/utils';
import { A as emberA } from '@ember/array';
import layout from './template';
import CHIS from 'framework/chis-framework';
import MessageMixin from '../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(
  MessageMixin,
  {
    layout,
    classificationColumns: null,
    classificationItemsSource: null,
    businesscodeItemsSource: null,
    businesscodeColumns: null,
    isClassificationPopupOpen: false,
    isNewItem: false,
    isShowBusinessCodeLoader: false,
    loaderType: 'spinner',
    loaderDimed: false,
    isShowClassificationLoader: false,
    isSortChecked: false,
    isClassificationAll: false,
    isBusinessCodeAll: false,
    editReadOnly:false,
    isMainForm: true,
    classificationCodes: null,
    isAllManage: false,
    model: null,
    businessCodeSelectedItem: null,
    peApiService: service('patientexamination-service'),

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'patient-examination-businesscode-management');

      this.setStateProperties([
        'model',
        'businessCodeSelectedItem'
      ]);
      if (!this.hasState()) {
        this.set('model', {
          classificationSelectedItem: null,
          classificationId: null,
          classificationInputValue: null,
          classificationInputName: null,
          classificationComment: null,
          businessCodeSelectedItem: null,
          editBusinessCode: null,
          editBusinessName: null,
          editeIsUsed: null,
          classificationCode: null,
        });
        this.set('classificationItemsSource', emberA());
        this.set('classificationColumns',[
          { title: this.getLanguageResource('9833', 'S','명칭'), field: 'name', align: 'left'},
        ]);
        this.set('businesscodeItemsSource', emberA());
        this.set('businesscodeColumns',[
          { title: this.getLanguageResource('7674', 'S','코드'), field: 'businessCode', width: 130, align: 'center'},
          { title: this.getLanguageResource('9833', 'S','명칭'), field: 'name', align: 'left'},
        ]);
        this.set('isUsedItemsSource',[{text: 'Yes', value: true}, {text: 'No', value: false}]);
      }
    },
    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1000');

      const selectCondition = this.getOpenMenuParams();
      if(!isEmpty(selectCondition)){
        this.set('isAllManage', selectCondition.isAllManage);

        if(!isEmpty(selectCondition.classificationCodes)){
          this.set('classificationCodes', selectCondition.classificationCodes);
        }
      }

      this._getClassificationList();
    },

    actions: {
      onOpenPopupAction() {
        this.set('isPopupOpen', true);
      },
      onClassificationAddClick() {
        this.set('isClassificationPopupOpen', true);
        this.set('editReadOnly', false);
      },

      onClassificationDoubleClick(){
        if(!isEmpty(this.get('model.classificationSelectedItem'))){
          const classificationSelectedItem = this.get('model.classificationSelectedItem');
          this.set('model.classificationId', classificationSelectedItem.classificationId);
          this.set('model.classificationInputValue', classificationSelectedItem.classificationCode);
          this.set('model.classificationName', classificationSelectedItem.name);
          this.set('model.classificationComment', classificationSelectedItem.comment);

          this.set('isClassificationPopupOpen', true);
          this.set('editReadOnly', true);
        }
      },

      onPopupClosedAction() {
        this.set('model.classificationId', null);
        this.set('model.classificationInputValue', null);
        this.set('model.classificationName', null);
        this.set('model.classificationComment', null);
      },
      onClassificationSelectChanged(e) {
        const selectedItem = e.selectedItems[0];
        if (!isEmpty(selectedItem)) {
          this._getBusinessCodeList(selectedItem.classificationCode);
        }
      },
      onBusinesscodeSelectChanged(e) {
        const selectedItem = e.selectedItems[0];
        if (!isEmpty(selectedItem)) {
          this.set('model.editBusinessCodeId', selectedItem.businessCodeId);
          this.set('model.editBusinessCode', selectedItem.businessCode);
          this.set('model.editBusinessName', selectedItem.name);
          this.set('model.editeIsUsed', selectedItem.isUsed);
          this.set('isNewItem', false);
          this.set('businessCodeSelectedItem', this.get('model.businessCodeSelectedItem'));
        }else{
          this.set('model.editBusinessCode', null);
          this.set('model.editBusinessName', null);
          this.set('model.editeIsUsed', null);
          this.set('isNewItem', true);
          this.set('businessCodeSelectedItem', {});
        }
      },
      onPopupSaveButtonClick() {
        if(isEmpty(this.get('model.classificationSelectedItem.classificationCode')) && this.get('editReadOnly')){
          this.get('peApiService').onShowToast('error', this.getLanguageResource('8945', 'F', '필수값을 입력하세요.'), '');
          return;
        }

        if(isEmpty(this.get('model.classificationId'))){
          this._addClassification();
        }else{
          this._updateClassification();
        }
      },
      onNewBusinessCode() {
        this.set('isNewItem', true);
        this.set('model.editBusinessCode', null);
        this.set('model.editBusinessName', null);
        this.set('model.editeIsUsed', null);
        this.set('model.businessCodeSelectedItem', null);
      },
      onSaveBusinessCode() {
        this._saveBusinessCode();
      },
      onSortChanged(){
        if(this.get('isSortChecked')){
          this.set('sortButtonName', this.getLanguageResource('6616', 'F', null,'저장'));
        }else{
          this.set('sortButtonName', this.getLanguageResource('6818', 'F', null,'정렬'));
        }
      },
      onClickSort() {
        if(!this.get('isSortChecked')){
          return;
        }

        this._saveBusinessCodeSorting();

      },
      onClassificationCheckChange() {
        this._getClassificationList();
      },
      onBusinessCodeCheckChange() {
        this._getBusinessCodeList(this.get('model.classificationSelectedItem.classificationCode'));
      },
      onBusinesscodeDoubleClick(){
        if(!isEmpty(this.get('onGetBusinessCodeCB'))){
          this.get('onGetBusinessCodeCB')(this.get('model.businessCodeSelectedItem'));
        }
      }
    },

    didInsertElement() {
      this._super(...arguments);
      this.get('co_ContentMessageService').subscribeMessage('messagePEClassification', this.get('currentMenuId'), this, this.messageClassification);
    },

    willDestroyElement() {
      this._super(...arguments);
      this.get('co_ContentMessageService').unsubscribeMessage('messagePEClassification', this.get('currentMenuId'), this, this.messageClassification);
    },

    messageClassification(selectCondition){
      if(!isEmpty(selectCondition)){
        this.set('classificationCodes', selectCondition.classificationCodes);
        this._getClassificationList();
      }
    },

    async _getClassificationList() {
      try {
        this.set('isShowClassificationLoader', true);
        this.set('classificationItemsSource', emberA());
        const param = {
          classificationCodes: null,
          isUsed: this.get('isClassificationAll') ? this.get('isClassificationAll') : null
        };
        const classificationCodes = this.get('classificationCodes');
        if(isPresent(classificationCodes)){
          param.classificationCodes = classificationCodes.join('&classificationCodes=');
        }
        const classifications = await this.get('peApiService').getBusinessCodesClassification(param);
        if(!isEmpty(classifications)) {
          if(this.get('isAllManage')){
            this.set('classificationItemsSource', classifications);
          }else{
            this.set('classificationItemsSource', classifications.filterBy('isUserManage', true));
          }
          if(!isEmpty(this.get('classificationItemsSource'))){
            this.set('model.classificationSelectedItem', this.get('classificationItemsSource').get('firstObject'));
          }
        }
        this.set('isShowClassificationLoader', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowClassificationLoader', false);
          this._showError(e);
        }
      }
    },

    async _getBusinessCodeList(classificationCode) {
      try {
        this.set('isShowBusinessCodeLoader', true);
        const paramIsUsed = this.get('isBusinessCodeAll') ? this.get('isBusinessCodeAll') : null;
        const params = {
          classificationCode: classificationCode,
          isUsed: paramIsUsed
        };
        this.set('businesscodeItemsSource', emberA());
        const businessCodes = await this.get('peApiService').getBusinessCodes(params);
        if (!isEmpty(businessCodes)) {
          this.set('businesscodeItemsSource', businessCodes);
          this.set('model.businessCodeSelectedItem', businessCodes[0]);
        }
        this.set('isShowBusinessCodeLoader', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowBusinessCodeLoader', false);
          this._showError(e);
        }
      }
    },

    async _addClassification() {
      try {
        const params = {
          code: this.get('model.classificationInputValue'),
          name: this.get('model.classificationName'),
          comment: this.get('model.classificationComment'),
        };
        await this.get('peApiService').createBusinessCodesClassification(params);
        this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
        this.set('isClassificationPopupOpen', false);
        await this._getClassificationList();

      } catch(e) {
        this._showSaveError(e);
      }
    },

    async _updateClassification() {
      try {
        const params = {
          classificationId: this.get('model.classificationId'),
          classificationCode: this.get('model.classificationInputValue'),
          name: this.get('model.classificationName'),
          comment: this.get('model.classificationComment'),
        };
        await this.get('peApiService').updateBusinessCodesClassification(params);
        this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
        this.set('isClassificationPopupOpen', false);
        await this._getClassificationList();

      } catch(e) {
        this._showSaveError(e);
      }
    },

    async _saveBusinessCode() {
      try {
        let promise = null;
        let displaySequence = 1;
        if(!isEmpty(this.get('businesscodeItemsSource'))){
          displaySequence = this.get('businesscodeItemsSource').length+1;
        }
        const params = {};
        params.classificationCode = this.get('model.classificationSelectedItem.classificationCode');
        if (this.get('isNewItem')) {
          params.businessCodes = [{
            businessCode: this.get('model.editBusinessCode'),
            name: this.get('model.editBusinessName'),
            displaySequence: displaySequence
          }];
          promise = this.get('peApiService').createBusinessCode(params);
        } else {
          params.businessCodes = [{
            businessCodeId: this.get('model.editBusinessCodeId'),
            name: this.get('model.editBusinessName'),
            displaySequence: this.get('model.businessCodeSelectedItem.displaySequence'),
            isUsed: this.get('model.editeIsUsed')
          }];
          promise = this.get('peApiService').updateBusinessCode(params);

        }
        await promise;
        await this._getBusinessCodeList(params.classificationCode);
        //저장내역 컨트롤 초기화
        this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');

      } catch(e) {
        this._showSaveError(e);
      }
    },

    async _saveBusinessCodeSorting() {
      try {
        const businessCodeItems = this.get('businesscodeItemsSource');
        const businessCodeParams = [];
        if(isEmpty(businessCodeItems)){
          return;
        }
        businessCodeItems.forEach((item, index) => {
          businessCodeParams.push({businessCodeId: item.businessCodeId, displaySequence: index+1});
        });
        const params = {
          classificationCode: this.get('model.classificationSelectedItem.classificationCode'),
          businessCodes: businessCodeParams
        };
        await this.get('peApiService').updateBusinessCodeSorting(params);
      } catch(e) {
        this._showSaveError(e);
      }
    }

  });