/* eslint-disable max-lines */
import $ from 'jquery';
import { hash } from 'rsvp';
import { next } from '@ember/runloop';
import { isEmpty, isPresent } from '@ember/utils';
import EmberObject, {
  set, get
} from '@ember/object';
import { A as emberA } from '@ember/array';
import { task } from 'ember-concurrency';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'patientexamination-module/app-config';
import { inject as service } from '@ember/service';
import PtMixin from '../../mixins/patient-examination-mixin';
import MesaggeMixin from '../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  PtMixin,
  MesaggeMixin,
  {
    layout,
    patientCode: null,
    patientId: null,
    checkinGrid: null,
    userGlobalInformation: null,
    model: null,
    checkinUrl: null,
    examinationGroupCode: null,
    isPriorityOpen: false,
    contextMenu: null,
    patientExaminationId: null,
    isConsentPopupOpen: false,
    isSpecimenReportOpen: false,
    printSettings: null,
    labelPrinter: null,
    autoPrintType: null,
    patientInfo: null,
    performRoom: null,
    appointmentInfo: null,
    isPageLoader: false,
    performList: null,
    fromDate: null,
    toDate: null,
    peApiService:service('patientexamination-service'),

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'patient-examination-checkin');

      this.setStateProperties([
        'patientId',
        'patientCode',
        'checkinGrid',
        'userGlobalInformation',
        'model',
        'checkinUrl',
        'patientUrl',
        'defaultUrl',
        'examinationGroupCode',
        'isPriorityOpen',
        'contextMenu',
        'isConsentPopupOpen',
        'isSpecimenReportOpen',
        'printSettings',
        'labelPrinter',
        'autoPrintType',
        'patientInfo',
        'performRoom',
        'appointmentInfo',
        'isPageLoader',
        'performList',
        'fromDate',
        'toDate'
      ]);

      if(this.hasState()===false) {
        const checkinUrl = this.get('fr_HostConfigService')
          .getEnvConfig('ServerCallConfig', 'patientexamination') +
          `patient-examination/${config.version}/checkins`;

        const patientUrl = this.get('fr_HostConfigService')
          .getEnvConfig('ServerCallConfig', 'patientexamination') +
          `patient-examination/${config.version}/patients`;

        const defaultUrl = this.get('fr_HostConfigService')
          .getEnvConfig('ServerCallConfig', 'patientexamination') +
          `patient-examination/${config.version}/`;

        this.set('defaultUrl', defaultUrl);
        this.set('patientUrl', patientUrl);
        this.set('checkinUrl', checkinUrl);

        this.set('checkinGrid', emberA({columns: emberA(), itemsSource: emberA(), selectedItem: EmberObject.create()}));
        this.set('checkinGrid.columns', [
          { field: 'isCheck', bodyTemplateName: 'checkbox', width: 40, align: 'center', headerTemplateName: 'checkall'},
          { title: this.getLanguageResource('3813', 'S','속성'), align: 'center', width: 35, bodyTemplateName:'icon'},
          { field: 'examinationName', title: this.getLanguageResource('16806', 'S', '검사'), bodyTemplateName:'examName'},
          { field: 'scheduleRoomId', title: this.getLanguageResource('743', 'S', '검사실'), width: 120, bodyTemplateName:'examRoom' },
          { field: 'paymentStatusName', title: this.getLanguageResource('3859'), width: 50, align: 'center', bodyTemplateName:'paid'},
          { field: 'isWrittenConsent', title: this.getLanguageResource('2028', 'S', '동의서'), width: 50, align: 'center', bodyTemplateName:'consent'},
          { field: 'scheduleDate', title: this.getLanguageResource('5150', 'S', '예약일시'), width: 120, type: 'date', dataFormat: 'g', align: 'center'},
          { field: 'acceptDate', title: this.getLanguageResource('10244', 'S', '접수일'), width: 120, type: 'date', dataFormat: 'g', align: 'center'},
          { field: 'orderDetail', title: this.getLanguageResource('5228', 'S', '오더비고'), width:60, align: 'center', bodyTemplateName:'detail'},
          { field: 'clinicalFinding', title: this.getLanguageResource('6227','F', '임상비고'), width:60, align: 'center', bodyTemplateName:'detail'},
          { field: 'scheduleComment', title: this.getLanguageResource('5130','S', '예약비고'), width:60, align: 'center', readOnly: true, bodyTemplateName:'detail'},
          { field: 'statusName', title: this.getLanguageResource('732', 'S', '검사상태'), width: 75, align: 'center', bodyTemplateName:'status'},
        ]);

        this.set('contextMenu', emberA([
          EmberObject.create({ text: this.getLanguageResource('748', 'S', '검사실변경'), disabled: true, display: true}),
          EmberObject.create({ action : this.actions.onAppointmentLink.bind(this), text: this.getLanguageResource('687', 'S', '검사예약'), disabled: true, display: true}),
          EmberObject.create({ action : this.actions.onExaminationGuideLink.bind(this), text: this.getLanguageResource('761', 'S', '검사안내'), disabled: false, display : true}),
        ]));

        this.set('model', {
          examinationInfo: null,
          examinationInfoClone: null,
          isChecked: true,
          isAutoPrint: false,
        });
        this.set('printSettings', emberA());
        this.set('labelPrinter', null);
        this.set('isPageLoader', false);
        this.setFromToDate();
      }
    },

    onBeforePatientChange(){
      this._super(...arguments);

      const canChange = this._checkSaveInfo();
      if(canChange){
        return true;
      }else{
        return false;
      }
    },

    onPatientChange(canChange){
      this._super(...arguments);
      const msg = this.getLanguageResource('10277', 'S','저장하지 않은 데이터가 있습니다.') +
      this.getLanguageResource('8939', 'S','저장하시겠습니까?');
      if(canChange === false){
        const options = {
          'caption': this.getLanguageResource('10251', 'S','환자 선택 변경 진행중'),
          'messageBoxButton': 'YesNoCancel',
          'messageBoxImage': 'question',
          'messageBoxText': `[${this.get('menuTitle')} ]` + msg,
          'messageBoxFocus': 'Yes'
        };

        return messageBox.show(this, options).then(function(result){
          if(result === 'Yes'){
            this.send('onSaveDetailInfo');
            this.continuePatientChanging();
          }else if(result == 'No'){
            this.continuePatientChanging();
          }else if(result == 'Cancel'){
            this.cancelPatientChanging();
          }
        }.bind(this));
      }
    },

    /* onPatientChanged(patient){
      this._super(...arguments);

      if(isEmpty(patient)){
        return;
      }
      this._onGetInfoAfterPatientChanged(patient);
    }, */

    onPatientChanged(patient){
      this._super(...arguments);

      if(isEmpty(patient)){
        return;
      }

      if(this.checkPatientDataClear()===true){
        this._allClear();
      }else{
        this._onGetInfoAfterPatientChanged(patient);
      }
    },

    _onGetInfoAfterPatientChanged(patient){
      this.set('patientId', patient.patientId);
      this.set('patientCode', patient.patientDisplayId);
      const item = EmberObject.create();
      set(item, 'performDoctors', {performDoctorId: null, performDoctorName: null});
      this.set('model.examinationInfo', $.extend(true, EmberObject.create(), item));
      this.set('model.examinationInfoClone', $.extend(true, EmberObject.create(), item));
      this._getPatientInfo();
      if(!isEmpty(patient.examination) && !isEmpty(patient.examination.patientExaminationId)){
        this.set('patientExaminationId', patient.examination.patientExaminationId);
      }
      this._onSearchAll();
    },

    onOpenMenuParamsChanged(item){
      if(!isEmpty(item.patientExaminationId)){
        this.set('patientExaminationId', item.patientExaminationId);
      }
      if(isEmpty(item.performRoom)){
        this.set('performRoom', {examinationRoomId: null, examinationRoomCode: null, examinationRoomName: null});
      }else{
        this.set('performRoom', item.performRoom);
      }
      if(!isEmpty(item.examinationGroupCode)){
        this.set('examinationGroupCode', item.examinationGroupCode);
        this._getPerformDoctor();
      }
      // SR
      /*if(!isEmpty(item.scheduleDate)){
        this.setFromToDate(item.scheduleDate);
      } */
      this._onSearchAll();
    },

    onLoaded() {
      this._super(...arguments);

      if(!isEmpty(this.get('co_CurrentUserService.user'))){
        this.set('userGlobalInformation', this.get('co_CurrentUserService.user'));
      }

      this.reSchedulingWarningMessage();

      this._getPeSettingInfo();
      const selectCondition = this.getOpenMenuParams();
      if(!isEmpty(selectCondition)){
        this.set('examinationGroupCode', selectCondition.examinationGroupCode);
        this._getPerformDoctor();
        if(!isEmpty(selectCondition.patientExaminationId)){
          this.set('patientExaminationId', selectCondition.patientExaminationId);
        }
        if(isEmpty(selectCondition.performRoom)){
          this.set('performRoom', {examinationRoomId: null, examinationRoomCode: null, examinationRoomName: null});
        }else{
          this.set('performRoom', selectCondition.performRoom);
        }
        if(!isEmpty(selectCondition.scheduleDate)){
          this.setFromToDate(selectCondition.scheduleDate);
        }
        this.getInitLoad();
      }else{
        this._getWorkListPeSettingInfo();
      }
      this.set('menuClass', 'w1000');
    },

    actions: {
      childComponentLoad(componentName, object){
        this.set(componentName, object);
      },

      onFromToPickerOpenChanged(e){
        if(!e.isOpen){
          this._onSearchAll();
        }
      },

      onAutoPrinterChanged(){

        this._setPeSettingInfo();
      },

      onSaveDetailInfo(){
        this.get('patient-examination-detail-information').saveInformation();
      },

      setSavedDetailInfo(item){
        if(!isEmpty(item)){
          this.get('checkinGrid.itemsSource').forEach(function(e){
            if(item.examinationPlanId == e.examinationPlanId){
              set(e, 'examinationComment', item.examinationComment);
              set(e, 'executeDoctorId', item.executeDoctorId);
            }
          });
        }
      },

      onAppointmentLink(e){
        if(isEmpty(e.dataItem.item)){
          return;
        }
        this.set('appointmentInfo', e.dataItem.item);
        this.set('isAppointmentPopupOpen', true);
      },

      onDisabledSetting(e){
        if(isEmpty(e.dataItem.item) || isEmpty(e.dataItem.item.isScheduling) || isEmpty(e.dataItem.item.statusCode)){
          return;
        }
        const contextSource = [];
        if(!isEmpty(e.dataItem.item.acceptableRooms)){
          const acceptableRooms = e.dataItem.item.acceptableRooms;
          acceptableRooms.forEach(room => {
            const context = {action: this.onChangeAcceptRoom.bind(null, room),
              text: room.examinationRoomName, value: room.examinationRoomId, disabled : false, display : true};
            contextSource.addObject(context);
          });
          const msgChRoom = this.getLanguageResource('748', 'S', '검사실변경');
          set(this.get('contextMenu').findBy('text', msgChRoom), 'disabled', false);
          set(this.get('contextMenu').findBy('text', msgChRoom), 'children', contextSource);
        }

        const msgRsv = this.getLanguageResource('687', 'S', '검사예약');
        if(e.dataItem.item.isScheduling && e.dataItem.item.statusCode == 1){
          set(this.get('contextMenu').findBy('text', msgRsv), 'disabled', false);
        }else{
          set(this.get('contextMenu').findBy('text', msgRsv), 'disabled', true);
        }
      },

      onLinkedInboxClick(){
        if(isEmpty(this.get('checkinGrid.selectedItem')) || isEmpty(this.get('checkinGrid.selectedItem.examinationPlanId'))){
          //선택된 내역이 없습니다.
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('11627'), '', 'Ok', 'Ok', 0);
          return;
        }
        const items = this.get('peApiService').getInboxParams(this.get('checkinGrid.selectedItem'), this.getLanguageResource('9686', 'S', '처방의'));
        set(items, 'purpose', '');
        this.set('sendInformation', items);
        this.set('isInboxOpen', true);
      },

      onCheckAllchanged(){
        if(isEmpty(this.get('checkinGrid.itemsSource'))){
          return;
        }
        this.get('checkinGrid.itemsSource').map(item =>{
          set(item, 'isCheck', !this.get('checkinGrid.isCheckAll'));
          return item;
        });
      },

      onCheckchanged(item){
        this.set('checkinGrid.isCheckAll', false);
        
        next(this, function(){
          if(item.examinationPlanId == this.get('model.examinationInfo.examinationPlanId')){
            this.set('model.examinationInfo.isCheck', item.isCheck);
            this.set('model.examinationInfoClone.isCheck', item.isCheck);
          }
        });
      },

      onSearchAcceptList(){
        this._onSearchAll();
      },

      onCheckinClick() {
        if (isEmpty(this.get('checkinGrid.itemsSource'))) {
          return;
        }

        if (isEmpty(this.get('checkinGrid.itemsSource').findBy('isCheck', true))){
          //처리할 내역을 선택하세요
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9286', 'F', '처리할 내역을 선택하세요.'), '', 'Ok', 'Ok', 0);
          return;
        }

        const checkInItems = emberA();
        const validation = {isCanceled: false, isRefund: false, isRoom: false, isConsent: false};

        this.set('isPageLoader', true);
        this.get('checkinGrid.itemsSource').forEach(e => {
          if(e.isCheck && e.statusCode !== 3){
            checkInItems.pushObject(e);
            if(isEmpty(e.scheduleRoomId)){
              validation.isRoom = true;
              return;
            }
            if(e.statusCode == 7){
              validation.isCanceled = true;
              return;
            }
            if(e.paymentStatus === "Refund"){
              validation.isRefund = true;
              return;
            }
            if(!isEmpty(e.isWrittenConsent) && !e.isWrittenConsent){
              validation.isConsent = true;
            }
          }
        });
        if(validation.isRoom){
          //검사실을 선택하세요.
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('10981'), '', 'Ok', 'Ok', 0);
          this.set('isPageLoader', false);
          return;
        }
        if(validation.isCanceled){
          //취소된 처방입니다.
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9267'), '', 'Ok', 'Ok', 0);
          this.set('isPageLoader', false);
          return;
        }
        if(validation.isRefund){
          //환불된 처방입니다.
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9285'), '', 'Ok', 'Ok', 0);
          this.set('isPageLoader', false);
          return;
        }
        if(validation.isConsent){
          //동의서를 확인해야합니다.
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('13353', 'F', '동의서를 확인해야합니다.'), '', 'Ok', 'Ok', 0);
          this.set('isPageLoader', false);
          return;
        }
        this._checkin(checkInItems);
      },

      onCheckinUndoClick() {
        if (isEmpty(this.get('checkinGrid.itemsSource'))) {
          return;
        }

        if (isEmpty(this.get('checkinGrid.itemsSource').findBy('isCheck', true))){
          //처리할 내역을 선택하세요
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9286'), '', 'Ok', 'Ok', 0);
          return;
        }

        let isPerformDoctor = false;
        const cancelExaminationList = emberA();
        this.get('checkinGrid.itemsSource').forEach(e => {
          if(e.isCheck && e.statusCode === 3) {
            cancelExaminationList.pushObject(e.examinationConductId);
            if(!isEmpty(e.performDoctors) && !isEmpty(e.performDoctors.performDoctorId)){
              isPerformDoctor = true;
            }
          }
        });
        if (!cancelExaminationList.length) {
          //검사상태를 확인해 주시기 바랍니다.
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9288'), '', 'Ok', 'Ok', 0);
          return;
        }

        if(isPerformDoctor){
          const options = this._questionMessage(this.getLanguageResource('12473', 'F', null, '이전상태로 변경시 등록된 시행의정보는 삭제됩니다. 진행하시겠습니까?'));
          messageBox.show(this, options).then(function (result) {
            if(result === 'Yes'){
              this._undo(cancelExaminationList);
            }
          }.bind(this));
        }else{
          this._undo(cancelExaminationList);
        }
      },

      onChangedAcceptCheck() {
        if (!isEmpty(this.get('patientId'))){
          this.get('getAcceptListTask').perform();
        }
      },

      onChangedExceptDischarge() {
        if (!isEmpty(this.get('patientId'))){
          this.get('getAcceptListTask').perform();
        }
      },

      onSelectionAcceptListChange() {
        if(isEmpty(this.get('checkinGrid.selectedItem'))){
          return;
        }
        const item = this.get('checkinGrid.selectedItem');

        this.set('model.examinationInfo', $.extend(true, EmberObject.create(), item));
        this.set('model.examinationInfoClone', $.extend(true, EmberObject.create(), item));
      },

      onPrintClick(){
        const selectedItems = emberA();

        this.get('checkinGrid.itemsSource').forEach(e => {
          if(e.isCheck && e.statusCode == 3){
            selectedItems.pushObject(e);
          }
        });

        this._getRegistration(selectedItems);
      },

      onSideEffectClick(){
        if(isEmpty(this.get('model.examinationInfo'))){
          return;
        }
        this.set('isContrastMediaOpen', true);
      },

      onSaveSideEffect(isSide){
        this.set('isContrastMediaOpen', false);
        if(isSide){
          this.set('isWarnigDisalbled', false);
        }
      },

      onSedationClick(){
        if(isEmpty(this.get('model.examinationInfo'))){
          return;
        }
        this.set('isSedationOpen', true);
      },

      onSaveSedation(isSed){
        this.set('isSedationOpen', false);
        if(isSed){
          this.set('isWarnigDisalbled', false);
        }
      },

      onSideSedClick(){
        this.set('isSideSedationOpen', true);
      },

      onCheckConsent(item){
        if(isEmpty(item)){
          return;
        }

        if(!item.isWrittenConsent){
          const options = this._questionMessage(this.getLanguageResource('11028', 'F', null, '동의서작성여부를 취소하시겠습니까?'));
          messageBox.show(this, options).then(function (result) {
            if(result === 'Yes'){
              this._saveConsent(item);
            }else{
              set(item, 'isWrittenConsent', !item.isWrittenConsent);
            }
          }.bind(this));
        }else{
          this._saveConsent(item);
        }
      },

      onNameCardClick(){
        const selectedItems = emberA();

        this.get('checkinGrid.itemsSource').forEach(e => {
          if(e.isCheck){
            selectedItems.pushObject(e);
          }
        });
        this._printLabelCheck(selectedItems, null);
      },

      onPriorityClick(item){
        if(isEmpty(item)){
          return;
        }
        const condition =
          { examinationCode: item.examinationCode,
            examinationName: item.examinationName,
            examinationId: item.examinationId,
            patientId: item.patientId,
            referenceDate: this.get('co_CommonService').getNow()};

        this.set('condition', condition);
        this.set('isPriorityOpen', true);
      },

      onExaminationGuideLink(e){
        if(isEmpty(e.dataItem.item)){
          return;
        }
        this.set('isGuidePopupOpen', true);
      },

      onLinkedConsentClick(){
        this.set('isConsentPopupOpen', true);
      },

      onLinkedSpecimenReportClick(){
        this.set('isSpecimenReportOpen', true);
      }
    },

    onSendMessagePatientList(){
      this.get('co_ContentMessageService').sendMessage('messagePatienExaminationMiniRefresh');
      this.get('co_ContentMessageService').sendMessage('messagePatienExaminationRefresh');
    },

    _onSearchAll(){
      this._onGetSpecimenResult();
      this.get('getAcceptListTask').perform();
    },

    getAcceptListTask: task(function * (){
      if(isEmpty(this.get('patientId'))){
        this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('8945'), '', 'Ok', 'Ok', 0);
        return;
      }

      this.set('checkinGrid.itemsSource', emberA());
      this.set('isPageLoader', true);
      this.set('checkinGrid.totalcount', '');
      this.set('checkinGrid.isCheckAll', false);
      const path = this.get('checkinUrl') + '/patient-accept-plans';

      const queryParams = {
        addAccept: this.get('model.isChecked'),
        patientId: this.get('patientId'),
        examinationGroupCode: this.get('examinationGroupCode'),
        employeeId: this.get('userGlobalInformation.employeeId'),
        fromDate: this.get('fromDate'),
        toDate: this.get('toDate'),
      };

      yield this.getList(path, queryParams, null, true).then(function (res) {
        if (!isEmpty(res.response)) {
          res.response.map(item => {
            set(item, 'tempAdministrationRouteCode', item.administrationRouteCode);
            set(item, 'point', this._setIconDisplayTooltip(item));
            set(item, 'examinationName', this._getOrderName(item));
            return item;
          });
          this.set('checkinGrid.itemsSource', res.response);
          this.set('checkinGrid.totalcount', this.getLanguageResource('7335', 'F', null, '총 건수')+ ": " + res.response.length);

          if(!isEmpty(this.get('patientExaminationId'))){
            const selectedItem = this.get('checkinGrid.itemsSource').findBy('examinationPlanId', this.get('patientExaminationId'));
            if(!isEmpty(selectedItem)){
              set(selectedItem, 'isCheck', true);
              next(this, function(){
                this.set('checkinGrid.selectedItem', selectedItem);
              });
            }else{
              this.set('checkinGrid.selectedItem', res.response.get('firstObject'));
            }
          }else{
            this.set('checkinGrid.selectedItem', res.response.get('firstObject'));
          }
          next(this, function(){
            this.set('isPageLoader', false);
          });
        }else if(isEmpty(res.response)){
          this._allClear();
          next(this, function(){
            this.set('isPageLoader', false);
          });
        }
      }.bind(this));
    }).restartable(),

    _allClear() {
      const item = EmberObject.create();
      set(item, 'performDoctors', {performDoctorId: null, performDoctorName: null});
      this.set('checkinGrid.itemsSource', emberA());
      this.set('checkinGrid.totalcount', '');
      this.set('model.examinationInfo', $.extend(true, EmberObject.create(), item));
      this.set('model.examinationInfoClone', $.extend(true, EmberObject.create(), item));
      this.set('specimenExaminationInfo', {creatineResult:null, gfrResult: null});
    },

    _printLabelCheck(item, now){
      if(isEmpty(item)){
        //선택된내역이 없습니다.
        this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('11627'), '', 'Ok', 'Ok', 0);
        return;
      }
      const patientIds = this.get('patientId');
      const examinationGroupCode = item.get('firstObject').examinationGroupCode;

      const param = {patientIds: patientIds, examinationGroupCode: examinationGroupCode, acceptDate: new Date(this.get('co_CommonService').getNow())};
      const path = this.get('defaultUrl') + 'checkins/registration/label';
      this.getList(path, param, null).then(function (res) {
        this._onPrintNameCard(item, now, res);
      }.bind(this));
    },

    _onPrintNameCard(items, checkInTime, exams){
      if(isEmpty(items)){
        return;
      }
      const printArray = emberA();
      const patientInfo = this.get('patientInfo');
      const examinationRoomIds = items.getEach('scheduleRoomId').uniq();
      examinationRoomIds.forEach(roomId => {
        const examList = items.filterBy('scheduleRoomId', roomId);
        const printContent = emberA({
          parameterField: {},
          dataField : emberA(),
        });
        const examinationInfo= emberA();
        let otherExamination= emberA();
        otherExamination = $.extend(true, emberA(), exams);
        const removeExams2 = otherExamination.filterBy('examinationRoomId', roomId);
        otherExamination.removeObjects(removeExams2);

        examList.forEach(e => {
          let otherExams = emberA();
          let patientExams = emberA();
          if(!isEmpty(exams)){
            patientExams = $.extend(true, emberA(), exams);
            const removeExams = patientExams.filterBy('examinationRoomId', e.scheduleRoomId);
            patientExams.removeObjects(removeExams);
            if(!isEmpty(patientExams)){
              patientExams.forEach(item => {
                if(!isEmpty(otherExams)){
                  otherExams = otherExams + '\n';
                }
                otherExams = otherExams + item.examinationName;
              });
            }
          }
          const checkinDatetime = e.acceptDate || checkInTime;
          examinationInfo.pushObject({
            "PatientName" : patientInfo.name,
            "Gender" : patientInfo.gender,
            "Birthday" : this.get('fr_I18nService').formatDate(patientInfo.birthDay, 'd'),
            "PatientID": e.patientId,
            "PatientDisplayID": patientInfo.displayCode,
            "IsPortable": e.isPortable ? 'Y' : 'N',
            "ExaminationName" : e.examinationName,
            "DateType" : this.getLanguageResource('789', 'S'),
            "Date" : this.get('fr_I18nService').formatDate(checkinDatetime, 'd'),
            "Time" : this.get('fr_I18nService').formatDate(checkinDatetime, 't'),
            "Age" : patientInfo.age,
            "IssuedDoctorName": e.issuedDoctorName,
            "DepartmentCode": e.medicalDepartmentCode,
            "Ward": e.ward,
            "Room": e.room.displayCode,
            "OrderDetail": e.orderDetail,
            "ExaminationComment": e.examinationComment,
            "OtherExaminationName": otherExams
          });
        });

        this.set('printPopup', false);
        printContent.dataField = { "examinationInfo": examinationInfo, "otherExamination": otherExamination };

        const printerName =
          this.getPrinterName('Label', roomId, this.get('printSettings'), this.get('labelPrinter'));
        printContent.printerName = printerName;
        const singlePrint = EmberObject.create({printPopup: false,
          printConfig: {
            'printType': 1,
            'printName': 'ExaminationLabel',
            'printerName': printerName,
            'autoPrint' : true,
          },
          printContent: printContent
        });
        printArray.addObject(singlePrint);
      });
      this.set('printList', printArray);
    },

    _checkSaveInfo(){
      let isValid = true;
      const condition = this.get('patient-examination-detail-information').editedCheck();
      if(!isEmpty(condition)){
        if(condition.contrast || condition.comment || condition.performDoctor || condition.performDate){
          isValid = false;
        }
      }
      return isValid;
    },

    _questionMessage(messageBoxText){
      return {
        'caption': '',
        'messageBoxImage': 'question',
        'messageBoxButton': 'YesNo',
        'messageBoxText': messageBoxText,
        'messageBoxFocus': 'Yes',
      };
    },

    _undo(cancelExaminationList){
      try {
        const cancelInfo = {actionStaffId: this.get('userGlobalInformation.employeeId'), examinationConductIds: cancelExaminationList };
        this.get('peApiService').onCheckinUndo(cancelInfo).then((res) => {
          if(res){
            this.set('patientExaminationId', null);
            this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
            this.get('getAcceptListTask').perform();
            this.onSendMessagePatientList();
          }
        });
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this._showSaveError(e);
        }
      }
    },

    _checkin(checkInItems){
      try {
        let actionDoctorId = null;
        if(!isEmpty(this.get('model.examinationInfo.executeDoctorId'))){
          actionDoctorId = this.get('model.examinationInfo.executeDoctorId');
        }
        const registerExaminationList = emberA();
        checkInItems.forEach(e => {
          registerExaminationList.addObject({
            examinationPlanId: e.examinationPlanId,
            examinationRoomId: e.scheduleRoomId,
            encounterId: e.encounterId,
            statuscode: 3
          });
        });
        const now = this.get('co_CommonService').getNow();
        const registerInfo = {
          acceptDateTime: now,
          acceptStaffId: this.get('userGlobalInformation.employeeId'),
          equipmentId: null,
          actionDoctorId: actionDoctorId,
          registerExamination: registerExaminationList
        };
        if (!registerExaminationList.length) {
          //검사상태를 확인해 주시기 바랍니다.
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9288'), '', 'Ok', 'Ok', 0);
          this.set('isPageLoader', false);
          return;
        }
        //비고저장
        const comment = this.getCommentParam();
        this.create(this.get('checkinUrl'), null, registerInfo).then(function (result){
          if(result){
            if(isEmpty(comment.path)){
              next(this, function(){
                this.afterCheckin(checkInItems, now);
              });
            }else{
              this.create(comment.path, null, comment.param).then(function (res){
                if(res){
                  next(this, function(){
                    const allItems = $.extend(true, emberA(), this.get('checkinGrid.itemsSource'));
                    const item = allItems.findBy('examinationPlanId', this.get('model.examinationInfo.examinationPlanId'));
                    set(item, 'examinationComment', this.get('model.examinationInfo.examinationComment'));
                    this.afterCheckin(checkInItems, now);
                  });
                }
              }.bind(this));
            }
          }
        }.bind(this)).finally(function(){
          this.set('isPageLoader', false);
        }.bind(this));
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isPageLoader', false);
          this._showSaveError(e);
        }
      }
    },

    afterCheckin(registerExaminationList, checkInTime){
      if(isEmpty(registerExaminationList)){
        return;
      }

      this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
      this.set('patientExaminationId', null);
      this.onSendMessagePatientList();
      this._onExecuteSendMessage(registerExaminationList);
      this.get('getAcceptListTask').perform();
      next(this, function(){
        this.set('isPageLoader', false);
        if(this.get('model.isAutoPrint')){
          if(this.get('autoPrintType') == '01'){
            this._getRegistration(registerExaminationList);
          }else{
            this._printLabelCheck(registerExaminationList, checkInTime);
          }
        }
      }.bind(this));
    },

    getCommentParam(){
      const items = {
        path: null,
        params: null,
      };
      if(this.get('model.examinationInfo.examinationComment') !== this.get('model.examinationInfoClone.examinationComment')){
        items.path = this.get('checkinUrl') + '/examination-memos';
        items.param = {
          examinationPlanId: this.get('model.examinationInfo.examinationPlanId'),
          memoTypeCode: 'Conduction',
          examinationComment: this.get('model.examinationInfo.examinationComment'),
          editStaffId: this.get('userGlobalInformation.employeeId')
        };
      }
      return items;
    },

    _onGetSpecimenResult(){
      try {
        if(isEmpty(this.get('patientId'))){
          return;
        }
        const path = this.get('defaultUrl') + 'diagnostic-reports/specimen-examination-report';
        const crParam = {
          patientId: this.get('patientId'),
          examinationType: 'Cr'
        };
        const gfrParam = {
          patientId: this.get('patientId'),
          examinationType: 'EGFR'
        };
        this.set('specimenExaminationInfo', {creatineResult:null, gfrResult: null});
        hash({
          crData: this.getList(path, crParam, null),
          gfrData: this.getList(path, gfrParam, null)
        }).then(function(res){
          if(!isEmpty(res.crData)){
            set(this.get('specimenExaminationInfo'), 'creatineResult', res.crData.displayResult);
          }
          if(!isEmpty(res.gfrData)){
            set(this.get('specimenExaminationInfo'), 'gfrResult', res.gfrData.displayResult);
          }
        }.bind(this));
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this._showError(e);
        }
      }
    },

    _saveConsent(item){
      try {
        const consentInfo = { examinationPlanId: item.examinationPlanId,
          isWritten: item.isWrittenConsent,
          occurrenceTypeCode: 'PatientExamination',
          editStaffId: this.get('userGlobalInformation.employeeId'),
          editDatetime: this.get('co_CommonService').getNow()};
        this.get('peApiService').onCheckConsent(consentInfo).then((res) => {
          if(res){
            this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
          }else{
            set(item, 'isWrittenConsent', !item.isWrittenConsent);
            //저장실패
            this.get('peApiService').onShowToast('error', this.getLanguageResource('9195'), '');
          }
        });
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this._showSaveError(e);
        }
      }
    },

    _getRegistration(items){
      try {
        if(isEmpty(items)){
          return;
        }
        const examimationPlanIds = emberA();
        items.forEach(e => {
          examimationPlanIds.pushObject(e.examinationPlanId);
        });
        const now = this.get('co_CommonService').getNow();
        const acceptDate = new Date(now.getFullYear(),now.getMonth(), now.getDate(), 0, 0, 0);
        const params = {
          patientId: this.get('patientId'),
          examinationPlanIds: null,
          acceptDate: acceptDate
        };
        if(isPresent(examimationPlanIds)){
          params.examinationPlanIds = examimationPlanIds.join('&examinationPlanIds=');
        }
        this.get('peApiService').onGetRegistration(params).then((res) => {
          if(res){
            this._printRegistration(res);
          }
        });
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this._showSaveError(e);
        }
      }
    },

    _printRegistration(items){
      const printArray = emberA();
      items.forEach(e => {
        const printContent = emberA({
          parameterField: {},
          dataField : emberA(),
        });
        let departmentName = '';
        if(!isEmpty(e.checkinExaminations)){
          e.checkinExaminations.map(item =>{
            set(item, 'issuedDate', this.get('fr_I18nService').formatDate(item.issuedDate, 'd'));
            return item;
          });
          departmentName = e.checkinExaminations.get('firstObject').departmentName;
        }

        const patientInfo = this.get('patientInfo');
        if (!isEmpty(patientInfo)){
          printContent.parameterField = {
            "patientName": patientInfo.name,
            "patientDisplayID": patientInfo.displayCode,
            "birthday": this.get('fr_I18nService').formatDate(patientInfo.birthDay, 'd'),
            "gender": patientInfo.gender,
            "age": patientInfo.age,
            "departmentName": departmentName
          };
        }

        printContent.dataField = {
          "checkinExaminations": e.checkinExaminations,
          "reservationExaminations": e.reservationExaminations,
          "otherCheckinExaminations": e.otherCheckinExaminations};

        this.set('printPopup', false);
        const printerName =
          this.getPrinterName('General', e.examinationRoomId, this.get('printSettings'), this.get('labelPrinter'));
        printContent.printerName = printerName;
        const singlePrint = EmberObject.create({printPopup: false,
          printConfig: {
            'printType': 1,
            'printName': 'ExaminationRegistration',
            'autoPrint' : true,
            'printerName': printerName
          },
          printContent: printContent
        });
        printArray.addObject(singlePrint);
      });
      this.set('printList', printArray);
    },


    async _getPrinterSettingInfo(){
      try {
        let category = 'Radiology';
        if(this.get('examinationGroupCode') != 'DR'){
          category = 'Clinic';
        }
        var result = await this.get('co_PersonalizationService').getPersonalPrinterSetting(category, 'print');
        if(!isEmpty(result.get('firstObject'))) {
          const settingValue = JSON.parse(get(result.get('firstObject'), 'settingValue'));
          this.set('settingValue', settingValue);
          if(!isEmpty(settingValue)) {
            if(!isEmpty(settingValue.defaultLabelPrinter)){
              this.set('labelPrinter', settingValue.defaultLabelPrinter);
            }
            if(!isEmpty(settingValue.autoPrintType)){
              this.set('autoPrintType', settingValue.autoPrintType);
            }
            if(!isEmpty(settingValue.item)){
              this.set('printSettings', settingValue.item);
            }
          }
        }
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this._showError(e);
        }
      }
    },

    _getPatientInfo(){
      const path = this.get('patientUrl');
      const param = {
        patientId : this.get('patientId')
      };

      this.getList(path, param, null).then(function (res) {
        if (!isEmpty(res)){
          this.set('patientInfo', res);
        }
      }.bind(this));
    },

    _getPerformDoctor(){
      try {
        if(isEmpty(this.get('examinationGroupCode'))){
          return;
        }
        this.set('performList', []);
        const param = {
          examinationGroupCode: this.get('examinationGroupCode'),
          relationTypeCode: "PerformDoctor"
        };
        this.get('peApiService').onGetExaminationEmployeeList(param).then(function(data){
          this.set('performList', data);
        }.bind(this));
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this._showError(e);
        }
      }
    },

    _onExecuteSendMessage(item){
      if(isEmpty(item)){
        return;
      }

      const exam = this.get('checkinGrid.itemsSource').findBy('examinationPlanId', item.get('firstObject').examinationPlanId);
      if(isEmpty(exam.acceptableRooms)){
        return;
      }

      const room = exam.acceptableRooms.findBy('examinationRoomId', exam.scheduleRoomId);

      const parameters = {
        patientType: 'A',
        acceptDate: this.get('co_CommonService').getNow(),
        patientId : exam.patientId,
        waitingRoom: room,
        isChecked: true,
        performRoom: room,
        examinationGroupCode: exam.examinationGroupCode
      };

      //영상일때
      if(this.get('co_MenuManagerService').checkMenuOpened('patient-examination-conducting_radiology')
      && parameters.examinationGroupCode == 'DR'){
        this.get('co_ContentMessageService').sendMessage('messageCondution', parameters);
      }

      //기능검사일때
      if(this.get('co_MenuManagerService').checkMenuOpened('patient-examination-conducting')
      && parameters.examinationGroupCode != 'DR'){
        this.get('co_ContentMessageService').sendMessage('messageCondution', parameters);
      }
    },

    async _getWorkListPeSettingInfo(){
      try {
        const viewId = 'patient-examination-worklist';
        const settingKey = viewId;
        const data = await this.get('peApiService').getPeSettingInfo(settingKey);
        if(!isEmpty(data)) {
          const condition = data[0];
          if(!isEmpty(condition.usedExaminationGroupCode) && this.get('examinationGroupCode') != 'DR'){
            this.set('examinationGroupCode', condition.usedExaminationGroupCode);
            this.getInitLoad();
          }
        }
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this._showSaveError(e);
        }
      }
    },

    getInitLoad(){
      if(!isEmpty(this.get('co_PatientManagerService.selectedPatient'))){
        const patientGlobalInformation = this.get('co_PatientManagerService.selectedPatient');

        this.set('patientId', patientGlobalInformation.patientId);
        this.set('patientCode', patientGlobalInformation.patientDisplayId);
        this._getPatientInfo();
        this._onSearchAll();
        this._getPrinterSettingInfo();
      }
    },

    async _getPeSettingInfo(){
      const settingKey = this.get('viewId');
      const data = await this.get('peApiService').getPeSettingInfo(settingKey);
      if(!isEmpty(data)) {
        const condition = data[0];
        this.set('model.isAutoPrint', condition.isAutoPrint);
      }
    },

    async _setPeSettingInfo(){
      const settingKey = this.get('viewId');
      const settingData = {
        conditionData: [{
          isAutoPrint: this.get('model.isAutoPrint')
        }]};
      const description = this.getLanguageResource('788', 'S', '검사접수');
      await this.get('peApiService').setPeSettingInfo(settingKey, settingData, description);
    },

    onChangeAcceptRoom(item){
      try {
        if(isEmpty(item)){
          return;
        }
        if(isEmpty(this.get('checkinGrid.itemsSource'))){
          return;
        }
        const items = this.get('checkinGrid.itemsSource').filterBy('isCheck', true);
        const validItems = items.filterBy('statusCode', 1);
        const notValidItems = items.filter(d => d.get('statusCode') === 2 || d.get('statusCode') === 3);
        if(validItems.length < 1){
          const msg = this.getLanguageResource('13220', 'S', '처리할 대상의 검사가 없습니다.');
          this.get('peApiService').onShowToast('warning', msg, '');
        }else{
          if(notValidItems.length > 0){
            const msg = this.getLanguageResource('13221', 'S', '예약 혹은 접수가 진행된 검사를 제외하고 검사실 변경이 진행됩니다.');
            this.get('peApiService').onShowToast('warning', msg, '');
          }
          const param = {
            examinationRoomId: item.examinationRoomId,
            examinationPlanIds: validItems.getEach('examinationPlanId')
          };
          this.get('peApiService').changeExaminationRoom(param).then((res) => {
            if(res){
              this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
              this._onSearchAll();
            }else{
              this.get('peApiService').onShowToast('error', this.getLanguageResource('9195'), '');
            }
          });
        }
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this._showSaveError(e);
        }
      }
    },

    reSchedulingWarningMessage(){
      try {
        this.get('peApiService').onGetBusinessCodeList('ReScheduling', "").then(res => {
          if(!isEmpty(res)){
            const msg = res.get('firstObject').name;
            this.set('isReschedulingMessage', msg);
          }else{
            this.set('isReschedulingMessage', "");
          }
        });
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this._showError(e);
        }
      }
    },

    setFromToDate(searchDate){
      let conditionDate = searchDate;
      if(isEmpty(searchDate)){
        conditionDate = this.get('co_CommonService').getNow();
      }
      this.set('fromDate', conditionDate.addDays(-365));
      this.set('toDate', conditionDate.addDays(365));
    }
  });