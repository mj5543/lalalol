import { inject as service } from '@ember/service';
import $ from 'jquery';
import { next } from '@ember/runloop';
import { hash } from 'rsvp';
import { isEmpty } from '@ember/utils';
import EmberObject from '@ember/object';
import { A as emberA } from '@ember/array';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'patientexamination-module/app-config';
import MesaggeMixin from '../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MesaggeMixin,{

  layout,
  examinationInfo: null,
  patientId: null,
  usedScope: null,
  peApiService: service('patientexamination-service'),

  onPropertyInit() {
    this._super(...arguments);
    this.set('viewId', 'patient-examination-endoscope-setting');

    this.setStateProperties([
      'examinationInfo',
      'patientId',
      'usedScope',
      'defaultUrl'
    ]);

    if(this.hasState()===false) {
      const defaultUrl = this.get('fr_HostConfigService')
        .getEnvConfig('ServerCallConfig', 'patientexamination') +
        `patient-examination/${config.version}/`;

      this.set('defaultUrl', defaultUrl);

      this.set('endoscopeGrid', emberA({columns: emberA(), itemsSource: emberA(), selectedItem: EmberObject.create()}));
      this.set('endoscopeGrid.columns', [
        { field: 'name', title: this.getLanguageResource('10135', 'S', '내시경스코프'), readOnly: true }
      ]);

      this.set('usedScope', EmberObject.create({name: null}));
    }
  },

  onLoaded() {
    this._super(...arguments);
  },


  actions:{
    onEndoscopePopupOpenedAction(){
      this.set('usedScope', EmberObject.create({name: null}));
      if(!isEmpty(this.get('examinationInfo'))){
        this._getEndoscopeList();
      }
    },

    onEndoscopeInputCommit(){
      //코드로 했을때 찾기..
      const endoscope = this.get('usedScope.name');
      const item = this.get('endoscopeGrid.itemsSource').findBy('name', endoscope);

      if(isEmpty(item)){
        //유효한 스코프가 없습니다.
        return;
      }
      this._onSaveEndoscope(item);
    },

    onEndoscopeSelectChanged(){
      this.set('usedScope',this.get('endoscopeGrid.selectedItem'));
    },
    onEndoscopeDoubleClick(){
      this._onSaveEndoscope(this.get('endoscopeGrid.selectedItem'));
    }
  },

  _getEndoscopeList(){
    try {
      this.set('endoscopeGrid.itemsSource', emberA());
      const examinationPath = this.get('defaultUrl') + 'endoscopes/maaping-examination';
      const endoscopePath = this.get('defaultUrl') + 'endoscopes/' + this.get('examinationInfo.examinationId');
      const examinationParams = {examinationPlanId: this.get('examinationInfo.examinationPlanId')};
      hash({
        examinationData: this.getList(examinationPath, examinationParams, null),
        endoscopeListData: this.getList(endoscopePath, null, null)
      }).then(function(res){
        if(!isEmpty(res.examinationData)){
          this.set('usedScope', res.examinationData);
        }
        if(!isEmpty(res.endoscopeListData)){
          this.set('endoscopeGrid.itemsSource', res.endoscopeListData);
        }
        next(this, function() {
          $('#examinationEndoscopeValue').find('input').focus();
          next('this', function() {
            $('#examinationEndoscopeValue input').select();
          });
        });
      }.bind(this));
    } catch(e) {
      if(!this.get('isDestroyed')) {
        this._showError(e);
      }
    }
  },

  _onSaveEndoscope(item){
    try {
      if(isEmpty(this.get('patientId')) || isEmpty(this.get('examinationInfo'))){
        //필수값 없음
        return;
      }
      const examinationInfo = this.get('examinationInfo');
      const path = this.get('defaultUrl') + 'endoscope-cleanings';
      const param = {
        patientId: this.get('patientId'),
        examinationPlanId: examinationInfo.examinationPlanId,
        endoscopeId: item.endoscopeId,
        actionStaffId: this.get('co_CurrentUserService.user.employeeId'),
        actionDatetime: this.get('co_CommonService').getNow()
      };
      this.create(path, null, param, false).then(function (){
        this.get('peApiService').onShowToast('save', this.getLanguageResource('8942'), '');
        this.set('isScopeOpen', false);
      }.bind(this));
    }catch(e) {
      if(!this.get('isDestroyed')) {
        this._showSaveError(e);
      }
    }
  }
});