/* eslint-disable no-console */
import layout from './template';
import CHIS from 'framework/chis-framework';
import { inject as service } from '@ember/service';
import { isEmpty } from '@ember/utils';
import { A as emberA } from '@ember/array';
import { set } from '@ember/object';
import MesaggeMixin from '../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,MesaggeMixin,{
  layout,
  attributeGrid: null,
  isPopupOpen: false,
  isShowLoader: false,
  loaderType: 'spinner',
  isChangedDisplaySquence: false,
  apiService:service('patientexamination-endoscope-cleaning-service'),


  onPropertyInit() {
    this._super(...arguments);
    this.set('viewId', 'patient-examination-cleaning-endoscope-attribute-management');
    this.setStateProperties([
      'isDisabled',
      'dailyStatusList',
      'gridItemsSource',
      'gridColumns',
      'claeningAttributeList',
      'userGlobalInformation',
      'removeAttributeIds'
    ]);

    if (!this.hasState()) {
      this.set('model', {
        selectedAttributeCode: null,
        selectedGridItem: null,
        popupsInputValue: null,
      });
      this.set('isDisabled', false);
      this.set('gridColumns', [
        { field: 'attributeName', title: this.getLanguageResource('9833', 'F', null, '명칭'), width: 250, bodyTemplateName: 'attributeName'}
      ]);
      if(!isEmpty(this.get('co_CurrentUserService.user'))){
        this.set('userGlobalInformation', this.get('co_CurrentUserService.user'));
      }
      this.set('removeAttributeIds', emberA());
    }
  },

  onLoaded() {
    this._super(...arguments);

    this.set('menuClass', 'w400');
    this._init();
  },

  actions: {
    onGridLoaded(e) {
      this.set('attributeGrid', e.source);
    },
    onDelButtonClick() {
      this._removeGridItem();
    },
    onAddButtonClick() {
      this.set('isPopupOpen', true);
    },
    onPopupAddClick() {
      this._addGridItem();
    },
    onSelectionAttributeChange() {
      this._getEndoscopeCleaningAttribute();
    },
    onPopupClosed() {
      this.set('model.popupsInputValue', null);
    },
    onGridCellCoubleClick(e) {
      this._showDefaultChangeMessage(e.item);
    },
    onSaveClick() {
      this._saveCleaningAttribute();
    },
    onGridRowDragEnd() {
      this.set('isChangedDisplaySquence', true);
    }
  },

  _init() {
    this._getCleaningAttributes();
  },

  async _getCleaningAttributes() {
    const result = await this.get('apiService').getBusinessCode('EndoscopeCleaningAttribute');
    this.set('claeningAttributeList', result);
    this.set('model.selectedAttributeCode', result[0].businessCode);

  },
  async _getEndoscopeCleaningAttribute() {
    try {
      this.set('isShowLoader', true);
      const result = await this.get('apiService').getEndoscopeCleaningAttribute(this.get('model.selectedAttributeCode'));
      this.set('gridItemsSource', result);
      this.set('isShowLoader', false);
    } catch(e) {
      if(!this.get('isDestroyed')) {
        this.set('isShowLoader', false);
        this._showError(e);
      }
    }
  },

  async _createAttribute(attributes) {
    try {
      const {actionStaffId, actionDateTime} = this._getActionParams();
      const params = {
        attributeTypeCode: this.get('model.selectedAttributeCode'),
        actionStaffId,
        actionDateTime,
        endoscopeCleaningAttributes: attributes
      };
      await this.get('apiService').createEndoscopeCleaningAttribute(params);
    } catch(e) {
      if(!this.get('isDestroyed')) {
        this._showSaveError(e);
      }
    }
  },

  async _saveCleaningAttribute() {
    try {
      const createParams = this._getAddAttributeItems();
      if(!isEmpty(createParams)) {
        await this._createAttribute(createParams);
      }
      if(!isEmpty(this.get('removeAttributeIds'))) {
        await this._deleteAttribute();
      }
      if(this.get('isChangedDisplaySquence')) {
        if(isEmpty(createParams) && isEmpty(this.get('removeAttributeIds'))) {
          await this._updateChangeSorting();
        } else {
          const result = await this.get('apiService').getEndoscopeCleaningAttribute(this.get('model.selectedAttributeCode'));
          await this._updateChangeSorting(result);
        }
      }
      await this._getEndoscopeCleaningAttribute();
      this.set('removeAttributeIds', emberA());
      this.get('apiService').onShowToast('save', this.getLanguageResource('8942', 'F', '저장되었습니다.'), '');
    } catch(e) {
      console.log(e);
    }
  },

  _getAddAttributeItems(item) {
    const gridList = this.get('gridItemsSource');
    const attrList = [];
    if(isEmpty(item)) {
      if(!isEmpty(gridList)) {
        gridList.forEach(data => {
          if(isEmpty(data.endoscopeCleaningAttributeId)) {
            attrList.push({
              attributeName: data.attributeName,
              isDefaultValue: data.isDefaultValue,
              displaySequence: data.displaySequence
            });
          }
        });
      }
    } else {
      attrList.push({
        attributeName: item.attributeName,
        isDefaultValue: item.isDefaultValue,
        displaySequence: item.displaySequence
      });

    }
    return attrList;
  },
  async _deleteAttribute() {
    try {
      const {actionStaffId, actionDateTime} = this._getActionParams();
      const params = {
        endoscopeCleaningAttributeIds: this.get('removeAttributeIds'),
        actionStaffId,
        actionDateTime,
      };
      await this.get('apiService').deleteEndoscopeCleaningAttribute(params);
    } catch(e) {
      if(!this.get('isDestroyed')) {
        console.log(e);
        this.showToastDeleteFail();
      }
    }
  },
  async _updateeDefaultSetting() {
    try {
      const item = this.get('model.selectedGridItem');
      const {actionStaffId, actionDateTime} = this._getActionParams();
      const params = {
        attributeTypeCode: this.get('model.selectedAttributeCode'),
        endoscopeCleaningAttributeId: item.endoscopeCleaningAttributeId,
        isDefaultValue: !item.isDefaultValue,
        actionStaffId,
        actionDateTime
      };
      await this.get('apiService').updateEndoscopeCleaningAttributeDefaultSetting(params);
      await this._getEndoscopeCleaningAttribute();
    } catch(e) {
      if(!this.get('isDestroyed')) {
        this._showSaveError(e);
      }
    }
  },
  async _updateChangeSorting(list) {
    try {
      const gridItems = this.get('gridItemsSource');
      const attributes = [];
      if(!isEmpty(gridItems)){
        gridItems.map((d, index) => {
          if(!isEmpty(list) && isEmpty(d.endoscopeCleaningAttributeId)) {
            const findIdsItem = list.find(item => item.attributeName === d.attributeName);
            d.endoscopeCleaningAttributeId = findIdsItem.endoscopeCleaningAttributeId;
          }
          d.displaySequence = index;
          attributes.push({
            endoscopeCleaningAttributeId: d.endoscopeCleaningAttributeId,
            displaySequence: index
          });
        });
        const {actionStaffId, actionDateTime} = this._getActionParams();
        const params = {
          actionStaffId,
          actionDateTime,
          attributes: attributes
        };
        await this.get('apiService').updateEndoscopeCleaningAttributeChangeSorting(params);
      }
    } catch(e) {
      console.log(e);
      this.showToast('error', '', this.getLanguageResource('11755', 'F', null, '저장에 실패하였습니다'));
    }
  },
  _addGridItem() {
    const gridSource = this.get('gridItemsSource');
    let seq = 0;
    if(!isEmpty(gridSource)) {
      seq = gridSource.length;
    }
    const tempObj = {
      endoscopeCleaningAttributeId: null,
      endoscopeCleaningAttributeTypeCode: this.get('model.selectedAttributeCode'),
      attributeName: this.get('model.popupsInputValue'),
      attributeValue: null,
      displaySequence: seq,
    };
    this.get('gridItemsSource').addObject(tempObj);
    this.get('attributeGrid').selectRow(tempObj);
    this.set('isPopupOpen', false);
  },
  _removeGridItem() {
    const selectedItem = this.get('model.selectedGridItem');
    if(isEmpty(selectedItem)) {
      return;
    }
    if(!isEmpty(selectedItem.endoscopeCleaningAttributeId)) {
      this.get('removeAttributeIds').addObject(selectedItem.endoscopeCleaningAttributeId);
    }
    this.get('gridItemsSource').removeObject(selectedItem);
    this.get('attributeGrid').selectRow(this.get('gridItemsSource').length - 1);

  },
  async _getDefaulrSettingItem(item) {
    const createParams = this._getAddAttributeItems(item);
    await this._createAttribute(createParams);
    const result = await this.get('apiService').getEndoscopeCleaningAttribute(this.get('model.selectedAttributeCode'));
    const sevedItem = result.find(d => d.attributeName === item.attributeName);
    set(this.get('model.selectedGridItem'), 'endoscopeCleaningAttributeId', sevedItem.endoscopeCleaningAttributeId);
    await this._updateeDefaultSetting();
  },

  async _showDefaultChangeMessage(item) {
    let message = null;
    if(item.isDefaultValue) {
      message = this.getLanguageResource('11751', 'F', null, '해당항목을 기본값 해지하시겠습니까?');
    } else {
      message = this.getLanguageResource('11750', 'F', null, '해당항목을 기본값으로 설정하시겠습니까?');
    }
    const result = await this.get('apiService').showConfirm(message, '');
    if (result === 'Yes') {
      if(isEmpty(item.endoscopeCleaningAttributeId)) {
        this._getDefaulrSettingItem(item);

      } else {
        this._updateeDefaultSetting();
      }
    }

  },

  _getActionParams() {
    const actionStaffId = this.get('userGlobalInformation.employeeId');
    const actionDateTime = this.get('co_CommonService').getNow();
    return {actionStaffId, actionDateTime};
  },

});

