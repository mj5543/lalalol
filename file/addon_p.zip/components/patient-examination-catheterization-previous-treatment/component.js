import layout from './template';
import CHIS from 'framework/chis-framework';
import { inject as service } from '@ember/service';
import MessageMixin from '../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(
  CHIS.FR.CrossCutting.ServerCallMixin,
  MessageMixin,
  {
    layout,
    angiographyId: null,
    staffId: null,
    recordTypeCode: null,
    recordNoteId: null,
    isPretreatmentOpen: false,
    isPrepared: false,
    popupTarget: null,
    apiService: service('patientexamination-angiographies-service'),

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'patient-examination-catheterization-previous-treatment');
      this.setStateProperties([ 'isPretreatmentOpen', 'popupTarget']);

      if (!this.hasState()) {
        this.set('draggable', true);
        this.set('destroyOnHide', true);
      }

      this.set('isDisabled', false);

    },
    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1000');
    },

    actions: {
      onResultRecordSave(recordNoteId) {
        this.set('recordNoteId', recordNoteId);
        this._saveAngiographiesTreatment();
      },
    },

    async _saveAngiographiesTreatment() {
      try {
        const params = {
          angiographyPlanId: this.get('angiographyId'),
          treatmentRecordNoteId: this.get('recordNoteId'),
          isPrepared: this.get('isPrepared'),
          actionStaffId: this.get('staffId'),
          actionDatetime: new Date(this.get('co_CommonService').getNow())
        };
        await this.get('apiService').updateAngiographiesTreatement(params);
        this.get('apiService').onShowToast('save', this.getLanguageResource('8942', 'F', '저장되었습니다.'), '');
        this.get('treatmentResultCB')();
        this.set('isPretreatmentOpen', false);
      } catch(e) {
        this._showSaveError(e);
      }
    }

  });