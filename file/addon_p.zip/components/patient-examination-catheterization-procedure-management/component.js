import { copy } from '@ember/object/internals';
import { isEmpty } from '@ember/utils';
import { A as emberA } from '@ember/array';
import { next } from '@ember/runloop';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import CatheterizationManagementMixin from '../../mixins/patient-examination-catheterization-management-mixin';
import MesaggeMixin from '../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(
  CatheterizationManagementMixin,
  MesaggeMixin,
  {
    layout,
    isDisabled: false,
    angiographiesPartList: null,
    isShowContainerLoader: false,
    gridSource: null,
    isPartGridSorting: false,
    isProcedureGridSorting: false,
    isSubProcedureGridSorting: false,
    isProcedureLoader: false,
    isSubProcedureLoader: false,
    isPartSortChecked: false,
    isProcedureSortChecked: false,
    isProcedureSetSortChecked: false,
    isChangedDisplayOnPart: false,
    isChangedDisplayOnProc: false,
    isChangedDisplayOnProcSet: false,
    peApiService:service('patientexamination-service'),

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'patient-examination-catheterization-procedure-management');
      this.setStateProperties([
        'model',
        'selectedFromDate',
        'selectedToDate',
        'isDisabled',
        'angiographyList',
        'angiographiesPartList',
        'departmentList',
        'partColumns',
        'procedureList',
        'subProcedureList',
        'refreshPartCode',
        'refreshProcedureCode',
        'refreshSubProcedureId'
      ]);

      if (!this.hasState()) {
        this.set('isDisabled', false);
        this.set('model', {
          selectedAngiographyCode: null,
          selectedPartGridItem: null,
          selectedAngiographyPartId: null,
          selectedProcedureGridItem: null,
          selectedProcedureSetGridItem: null,
          editItems: {
            code: null,
            name: null,
            type: null
          },
        });
        const displayDate = new Date(this.get('co_CommonService').getNow());
        this.set('selectedFromDate', displayDate);
        this.set('selectedToDate', displayDate);
        this.set('partColumns', [
          { field: 'angiographyPartCode', title: this.getLanguageResource('3039', 'F', null, '부위'), width: 70, align: 'center', readOnly: true},
          { field: 'angiographyPartName', title: this.getLanguageResource('3041', 'F', null, '부위명'), width: 120, readOnly: true},
        ]);
        this.set('procedureColumns', [
          { field: 'angiographyProcedureCode', title: this.getLanguageResource('4394', 'F', null, '시술코드'), width: 70, align: 'center', readOnly: true},
          { field: 'angiographyProcedureName', title: this.getLanguageResource('4383', 'F', null, '시술명'), width: 120, readOnly: true},
        ]);
        this.set('subProcedureColumns', [
          { field: 'angiographySubProcedureName', title: this.getLanguageResource('10672', 'F', null, '상세부위'), width: 120, readOnly: true},
        ]);
      }
      this.set('angiographyList', []);
      this._resetGridData();
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1180');
      const selectCondition = this.getOpenMenuParams();
      if(!isEmpty(selectCondition)){
        this.set('angiographyGroupCode', selectCondition.angiographyGroupCode);
      }
      this._init();
    },
    actions: {
      onGridLoaded(e) {
        this.set('gridSource', e.source);
      },
      onAngiographyCodeChanged(e) {
        this._resetGridData();
        const selectedItem = e.selectedItems[0];
        if (!isEmpty(selectedItem)) {
          this._getAngiographies(false);
        }
      },
      onPartGridSelectionChanged() {
        this.set('procedureList', emberA());
        this._getProcedureList();
      },
      onProcedureSelectionChanged(e) {
        this.set('subProcedureList', emberA());
        const selectedItem = e.selectedItems[0];
        if (!isEmpty(selectedItem)) {
          this._getSubProcedureList();
        }
      },
      onSearchClick() {
        this._getAngiographies(false);
      },
      onSearchAddClick(type) {
        if (type === 'SubProcedure') {
          this.set('isSubProcedureOpen', true);
        } else {
          this.set('model.editItems.type', type);
          this.set('isRegistPopupOpen', true);
        }
      },
      onDelClick(type) {
        this._showDeleteConfirm(type);
      },
      onGridCellDoubleClick(e) {
        const item = e.item;
        let itemCode = null;
        let itemName = null;
        if(item.type === 'Part') {
          itemCode = item.angiographyPartCode;
          itemName = item.angiographyPartName;
        } else if(item.type === 'Procedure') {
          itemCode = item.angiographyProcedurCode;
          itemName = item.angiographyProcedureName;
        } else if(item.type === 'SubProcedure') {
          itemCode = item.angiographySubProcedureCode;
          itemName = item.angiographySubProcedureName;
        }
        this.set('model.editItems.code', itemCode);
        this.set('model.editItems.name', itemName);
        this.set('isRegistPopupOpen', true);
        this.set('isUpdatePopup', true);
      },
      onPopupClosedAction() {
        this.set('isUpdatePopup', false);
        this.set('model.editItems.code', null);
        this.set('model.editItems.name', null);
        this.set('model.editItems.type', null);
      },
      onClickSort() {
        if(!this.get('isPartSortChecked') && this.get('isChangedDisplayOnPart')){
          this._AngiographiesPartSortingChange();
        }
      },
      onProcedureClickSort() {
        if(!this.get('isProcedureSortChecked') && this.get('isChangedDisplayOnProc')){
          this._AngiographiesProcedureSortingChange();
        }
      },
      onProcedureSetClickSort() {
        if(!this.get('isProcedureSetSortChecked') && this.get('isChangedDisplayOnProcSet')){
          this._AngiographiesSubProcedureSetSortingChange();
        }
      },
      onSubProcedureCB(item) {
        if(isEmpty(this.get('model.selectedProcedureGridItem'))){
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('11627', 'F', '선택된 내역이 없습니다.'), '', 'Ok', 'Ok', 0);
          return;
        }

        this.set('refreshPartCode', copy(this.get('model.selectedPartGridItem.angiographyPartCode'), true));
        this.set('refreshProcedureCode', copy(this.get('model.selectedProcedureGridItem.angiographyProcedureCode'), true));
        this.set('refreshSubProcedureId', item.angiographySubProcedureId);
        this._createAngiographiesSubProcedureSet(item.angiographySubProcedureId);
      },
      onPopupSave() {
        if(this.get('model.editItems.type') === 'Part') {
          this._createAngiographiesPart();
        } else {
          this._createAngiographiesProcedure();
        }
      },
      onRowDragEndByPart() {
        this.set('isChangedDisplayOnPart', true);
      },
      onRowDragEndByProc() {
        this.set('isChangedDisplayOnProc', true);
      },
      onRowDragEndByProcSet() {
        this.set('isChangedDisplayOnProcSet', true);
      },
      onRefreshCB(){
        this._refreshDatas();
      }
    },
    _init() {
      this.get('peApiService').onGetBusinessCodeList('Angiography').then(res => {
        this.set('angiographyList', res);
        if(!isEmpty(this.get('angiographyGroupCode'))){
          this.set('model.selectedAngiographyCode', this.get('angiographyGroupCode'));
        }
      });
    },
    async _showDeleteConfirm(type) {
      const message = this.getLanguageResource('11669', 'F', null, '삭제 하시겠습니까?');
      const result = await this.get('apiService').showConfirm(message, '');
      if (result === 'Yes') {
        if(type === 'Part') {
          this._deleteAngiographiesPart();
        } else if(type === 'Procedure') {
          this._deleteAngiographiesProcedure();
        } else if(type === 'SubProcedure') {
          this._deleteAngiographiesSubProcedureSet();
        }
      }
    },
    _resetGridData() {
      this.set('angiographiesPartList', []);
      this.set('procedureList', []);
      this.set('subProcedureList', []);
    },

    _refreshDatas() {
      this._resetGridData();
      this._getAngiographies(true);
    },

    _getProcedureList() {
      try {
        this.set('isProcedureLoader', true);
        const selectedPartItem = this.get('model.selectedPartGridItem');
        if(!isEmpty(selectedPartItem) && !isEmpty(selectedPartItem.angiography)) {
          selectedPartItem.angiography.map(item => {
            item.type = 'Procedure';
          });
          this.set('procedureList', selectedPartItem.angiography);
          const refreshTarget = this.get('refreshProcedureCode');
          if(!isEmpty(refreshTarget)) {
            const focusTargetItem = selectedPartItem.angiography.find(d => d.angiographyProcedureCode === refreshTarget);
            this.set('model.selectedProcedureGridItem', focusTargetItem);
          } else {
            this.set('model.selectedProcedureGridItem', selectedPartItem.angiography[0]);
          }
        }
        next(this, function(){
          this.set('isProcedureLoader', false);
          this.set('refreshProcedureCode', null);
        });
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isProcedureLoader', false);
          this._showError(e);
        }
      }
    },
    _getSubProcedureList() {
      try {
        this.set('isSubProcedureLoader', true);
        const selectedProcedure = this.get('model.selectedProcedureGridItem');
        if(!isEmpty(selectedProcedure) && !isEmpty(selectedProcedure.subProcedure)) {
          selectedProcedure.subProcedure.map(item => {
            item.type = 'SubProcedure';
          });
          this.set('subProcedureList', selectedProcedure.subProcedure);
          const refreshTarget = this.get('refreshSubProcedureId');
          if(!isEmpty(refreshTarget)) {
            const focusTargetItem = selectedProcedure.subProcedure.find(d => d.angiographySubProcedureId === refreshTarget);
            this.set('model.selectedProcedureSetGridItem', focusTargetItem);
          }
        }
        next(this, function(){
          this.set('isSubProcedureLoader', false);
          this.set('refreshSubProcedureId', null);
        });
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isSubProcedureLoader', false);
          this._showError(e);
        }
      }

    },
    async _createAngiographiesPart() {
      try{
        const {actionStaffId, actionDatetime} = this._getActionParams();
        const params = {
          displayCode: this.get('model.editItems.code'),
          name: this.get('model.editItems.name'),
          displaySequence: 0,
          angiographyGroupCode: this.get('model.selectedAngiographyCode'),
          actionStaffId,
          actionDatetime
        };
        await this.get('apiService').createAngiographiesPart(params);
        this.set('refreshPartCode', copy(this.get('model.editItems.code'), true));
        this.set('isRegistPopupOpen', false);
        this.showToastSaved();
        this._refreshDatas();
      } catch(e) {
        this._showSaveError(e);
        //console.log('_createAngiographiesPart Error:::', e);
      }
    },
    async _createAngiographiesProcedure() {
      try{
        const {actionStaffId, actionDatetime} = this._getActionParams();
        const params = {
          angiographyPartId: this.get('model.selectedPartGridItem.angiographyPartId'),
          displayCode: this.get('model.editItems.code'),
          name: this.get('model.editItems.name'),
          displaySequence: 0,
          actionStaffId,
          actionDatetime
        };
        await this.get('apiService').createAngiographiesProcedure(params);
        this.set('refreshProcedureCode', copy(this.get('model.editItems.code'), true));
        this.set('refreshPartCode', copy(this.get('model.selectedPartGridItem.angiographyPartCode'), true));
        this.set('isRegistPopupOpen', false);
        this.showToastSaved();
        this._refreshDatas();
      } catch(e) {
        this._showSaveError(e);
      }
    },
    async _createAngiographiesSubProcedureSet(id) {
      try{
        const {actionStaffId, actionDatetime} = this._getActionParams();
        const params = {
          angiographyProcedureId: this.get('model.selectedProcedureGridItem.angiographyProcedureId'),
          angiographySubProcedureId: id,
          displaySequence: 0,
          actionStaffId,
          actionDatetime
        };
        await this.get('apiService').createAngiographiesSubProcedureSet(params);
        this.showToastSaved();
        this._refreshDatas();
      } catch(e) {
        this._showSaveError(e);
      }
    },
    async _deleteAngiographiesPart() {
      try{
        const {actionStaffId, actionDatetime} = this._getActionParams();
        const params = {
          angiographyPartId: this.get('model.selectedPartGridItem.angiographyPartId'),
          actionStaffId,
          actionDatetime
        };
        await this.get('apiService').deleteAngiographiesPart(params);
        this.showToastDeleted();
        this._refreshDatas();
      } catch(e) {
        this._showSaveError(e);
      }
    },
    async _deleteAngiographiesProcedure() {
      try{
        const {actionStaffId, actionDatetime} = this._getActionParams();
        const params = {
          angiographyProcedureId: this.get('model.selectedProcedureGridItem.angiographyProcedureId'),
          actionStaffId,
          actionDatetime
        };
        await this.get('apiService').deleteAngiographiesProcedure(params);
        this.set('refreshPartCode', copy(this.get('model.selectedPartGridItem.angiographyPartCode'), true));
        this.showToastDeleted();
        this._refreshDatas();
      } catch(e) {
        this._showSaveError(e);
      }
    },
    async _deleteAngiographiesSubProcedureSet() {
      try{
        const {actionStaffId, actionDatetime} = this._getActionParams();
        const params = {
          subProcedureSetIds: [this.get('model.selectedProcedureSetGridItem.angiographySubProcedureSetId')],
          actionStaffId,
          actionDatetime
        };
        await this.get('apiService').deleteAngiographiesSubProcedureSet(params);
        this.showToastDeleted();
        this._refreshDatas();
      } catch(e) {
        this._showSaveError(e);
      }
    },
    async _AngiographiesPartSortingChange() {
      try{
        const {actionStaffId, actionDatetime} = this._getActionParams();
        const partItemsSource = this.get('angiographiesPartList');
        const partList = [];
        if(isEmpty(partItemsSource)){
          return;
        }
        partItemsSource.forEach((item, index) => {
          partList.push({
            angiographyPartId: item.angiographyPartId,
            angiographyPartName: item.angiographyPartName,
            displaySequence: index+1
          });
        });
        const params = {
          angiographyGroupCode: this.get('model.selectedAngiographyCode'),
          actionStaffId,
          actionDatetime,
          angiographyParts: partList
        };
        await this.get('apiService').updateAngiographiesPartSorting(params);
        this.showToastSaved();
        this.set('isChangedDisplayOnPart', false);
      } catch(e) {
        this._showSaveError(e);
      }
    },

    async _AngiographiesProcedureSortingChange() {
      try{
        const {actionStaffId, actionDatetime} = this._getActionParams();
        const itemsSource = this.get('procedureList');
        const partList = [];
        if(isEmpty(itemsSource)){
          return;
        }
        itemsSource.forEach((item, index) => {
          partList.push({
            angiographyProcedureId: item.angiographyProcedureId,
            angiographyProcedureCode: item.angiographyProcedureCode,
            angiographyProcedureName: item.angiographyProcedureName,
            displaySequence: index+1
          });
        });
        const params = {
          angiographyPartId: this.get('model.selectedPartGridItem.angiographyPartId'),
          actionStaffId,
          actionDatetime,
          angiographyProcedures: partList
        };
        await this.get('apiService').updateAngiographiesProcedureSorting(params);
        this.showToastSaved();
        this.set('isChangedDisplayOnProc', false);
      } catch(e) {
        this._showSaveError(e);
      }
    },
    async _AngiographiesSubProcedureSetSortingChange() {
      try{
        const {actionStaffId, actionDatetime} = this._getActionParams();
        const itemsSource = this.get('subProcedureList');
        const partList = [];
        if(isEmpty(itemsSource)){
          return;
        }
        itemsSource.forEach((item, index) => {
          partList.push({
            angiographySubSetProcedureId: item.angiographySubProcedureSetId,
            displaySequence: index+1
          });
        });
        const params = {
          angiographyProcedureId: this.get('model.selectedProcedureGridItem.angiographyProcedureId'),
          actionStaffId,
          actionDatetime,
          angiographyProcedureSets: partList
        };
        await this.get('apiService').updateAngiographiesSubProcedureSetSorting(params);
        this.showToastSaved();
        this.set('isChangedDisplayOnProcSet', false);
      } catch(e) {
        this._showSaveError(e);
      }
    },

    async _getAngiographies(reFresh) {
      try {
        let refreshPartCode = null;
        let refreshProcedureCode = null;
        if(reFresh){
          refreshPartCode = this.get('model.selectedPartGridItem.angiographyPartCode');
          refreshProcedureCode = this.get('model.selectedProcedureGridItem.angiographyProcedureCode');
        }

        this.set('isDisabled', true);
        this.set('isPartLoader', true);
        const param = {
          angioGroupCode: this.get('model.selectedAngiographyCode'),
          isUsed: true
        };
        const partResult = await this.get('apiService').getAngiographiesPart(param);
        if (!isEmpty(partResult)) {
          partResult.map(item => {
            item.type = 'Part';
          });
          this.set('angiographiesPartList', partResult);
          if(!isEmpty(refreshPartCode)) {
            const focusTargetItem = partResult.find(d => d.angiographyPartCode === refreshPartCode);
            this.set('model.selectedPartGridItem', focusTargetItem);
            if(!isEmpty(refreshProcedureCode)) {
              next(this, function(){
                const focusPTargetItem = focusTargetItem.angiography.find(d => d.angiographyProcedureCode === refreshProcedureCode);
                this.set('model.selectedProcedureGridItem', focusPTargetItem);
              });
            } else {
              this.set('model.selectedProcedureGridItem', focusTargetItem.angiography[0]);
            }
          } else {
            this.set('model.selectedPartGridItem', partResult[0]);
          }
          this.set('isDisabled', false);
          this.set('refreshPartCode', null);
          this.set('refreshProcedureCode', null);
        }
      } catch(e) {
        this._showSaveError(e);
      }
      this.set('isPartLoader', false);
    },
  });
