import EmberObject, { get, set } from '@ember/object';
import $ from 'jquery';
import { hash } from 'rsvp';
import moment from 'moment';
import { isEmpty, isPresent } from '@ember/utils';
import { A as emberA } from '@ember/array';
import layout from './template';
import CHIS from 'framework/chis-framework';
import MessageMixin from '../../mixins/patient-examination-message-mixin';
import config from 'patientexamination-module/app-config';
import { inject as service } from '@ember/service';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  MessageMixin,
  {
    layout,
    isPageLoader: false,
    isShowGridLoader: false,
    gridItems: null,
    gridColumns: null,
    print: null,
    calendarSelectedDate: null,
    calendarItemsSource: null,
    examinationGroupCode: null,
    isOpenMenuParamsGroupCode: false,
    isSettingOpen: false,
    performRoom: null,
    selectedStatusValue: null,
    selectedExaminationRoomId: null,
    examinationRoomItems: null,
    appointmentGrid: null,
    isEndLoad: false,
    isReschedulingMessage: null,
    peApiService:service('patientexamination-service'),

    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','patient-examination-scheduled-search');
      this.setStateProperties([
        'model',
        'appointmentGrid',
        'print',
        'examinationRoomItems',
        'isReschedulingMessage'
      ]);
      if (this.hasState() === false) {
        const defaultUrl = this.get('fr_HostConfigService')
          .getEnvConfig('ServerCallConfig', 'patientexamination') +
          `patient-examination/${config.version}/`;
        this.set('defaultUrl', defaultUrl);
        this.set('print', EmberObject.create({printPopup: null, printConfig: null, printContent: null}));
        this.set('model', {
          selectedGridItem: null,
        });
        this.set('gridColumns', this._getGridColumns());
        this.set('gridItems', emberA());
        this.set('isEndLoad', false);
      }
      const displayDate = new Date(this.get('co_CommonService').getNow());
      this.set('calendarSelectedDate', displayDate);
      this.set('selectedFromDate', displayDate);
      this.set('selectedToDate', displayDate);
      this.set('statusComboItems', [
        {name: this.getLanguageResource('10670', 'S', '예약'), code: true},
        {name: this.getLanguageResource('11749', 'S', '비예약'), code: false},
      ]);
      this.set('periodType', 'Daily');
    },

    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1360');

      this.reSchedulingWarningMessage();
      const getOpenMenuParams = this.getOpenMenuParams();
      if(!isEmpty(getOpenMenuParams)){
        this.set('isOpenMenuParamsGroupCode', true);
        this.set('examinationGroupCode', getOpenMenuParams.examinationGroupCode);
        this._getExaminationRoom();
        this._getAllExaminationList();
      }else{
        this.set('examinationGroupCode', null);
      }
      this._getPeSettingInfo();
      this._getDepartment();
    },

    actions: {
      onlyOneGroup(){
        this.set('isOpenMenuParamsGroupCode', true);
      },

      onPickerDateUpdated(e) {
        this.set('calendarSelectedDate', e.selectedDate);
      },
      onCalendarSelecteChanged(e) {
        this.set('calendarSelectedDate', e.selectedDate);
        const formToDate = this._setFromToDate(this.get('periodType'));
        this.set('selectedFromDate', formToDate.fromDate);
        this.set('selectedToDate', formToDate.toDate);

        this._getScheduleList();
      },
      onCalendarRangeChanged(e) {
        if (!isEmpty(e.displayDate)) {
          this._getCalenderStatus(e.displayDate);
        }
      },
      onRadioTypeChange(e) {
        const formToDate = this._setFromToDate(e.value);
        this.set('selectedFromDate', formToDate.fromDate);
        this.set('selectedToDate', formToDate.toDate);
        this._getScheduleList();
      },
      onSearchClick() {
        if(!this.get('isEndLoad')){
          this.set('isEndLoad', true);
        }
        this._getAllSearch();
      },
      onAllSearch(){
        this._getAllSearch();
      },
      onDateChangedAction(e) {
        this.set('selectedFromDate', e.selectedFromDate);
        this.set('selectedToDate', e.selectedToDate);
        this._getScheduleList();
      },
      onchangedEmployeeGroup(item){
        if(item !== 'DR'){
          this.set('examinationGroupCode', item);
        }
        this._setPeSettingInfo();
        this._setExaminationGroupChanged();
        this._getAllSearch();
      },
      onExaminationRoomChanged(){
        this._setPeSettingInfo();
        this._getAllSearch();
      },
      onDeletedExamClick(item){
        if(isEmpty(item)){
          return;
        }
        this.get('selectedExamList').removeObject(item);
      },

      onExaminationChanged(item){
        if(isEmpty(item) || isEmpty(item.examinationId)){
          return;
        }

        if(!isEmpty(this.get('selectedExamList'))){
          if(!this.get('selectedExamList').any((exam) => exam.examinationId === item.examinationId)){
            this.get('selectedExamList').pushObject(item);
          }
        }else{
          this.set('selectedExamList', []);
          this.get('selectedExamList').pushObject(item);
        }
        this.set('examination', EmberObject.create());
      },

      onVisibleClick(){
        if(this.get('isSettingVisible')){
          if(!isEmpty(this.get('selectedExamList'))){
            const msg = this.getLanguageResource('13229', 'S', '선택된 검사를 초기화 하시겠습니까');
            const confirmMsg = this.getLanguageResource('8377', 'S', '확인');
            const options = {'messageBoxImage': 'question', 'caption':  confirmMsg, 'messageBoxText': msg,
              'messageBoxButton': 'OKCancel', 'messageBoxFocus' : 'Ok', 'messageboxInterval' : 0};
            messageBox.show(this, options).then((rbutton) => {
              if(rbutton === "Ok"){
                this._onExaminationClear();
                this.set('isSettingVisible', false );
              }else{
                this.set('isSettingVisible', false );
              }
            });
          }else{
            this.set('isSettingVisible', false );
          }
        }else{
          this.set('isSettingVisible', true);
        }
      },

      onLoadGrid(e){
        this.set('appointmentGrid', e.source);
      },

      onExcelClick(){

        if(isEmpty(this.get('gridItems'))){
          const msg = this.getLanguageResource('13230', 'F', '출력할 내용이 없습니다.');
          this.get('peApiService').onDisplayMessage('warning', msg, '', 'Ok', 'Ok', 0);
        }

        const data = get(this.appointmentGrid, 'items');
        this._getExportExcelData(data);
      },

      onPrintClick(){
        if(isEmpty(this.get('gridItems'))){
          const msg = this.getLanguageResource('13230', 'F', '출력할 내용이 없습니다.');
          this.get('peApiService').onDisplayMessage('warning', msg, '', 'Ok', 'Ok', 0);
        }

        const data = get(this.appointmentGrid, 'items');
        this._getPrintOut(data);
      }
    },

    _getGridColumns() {
      return [
        { field: 'examinationRoomName', title: this.getLanguageResource('743', 'S', '검사실'), width: 100, align: 'center', bodyTemplateName: 'cellTooltip'},
        { field: 'scheduleDateTime', title: this.getLanguageResource('5150', 'S', '예약일시'), width: 100, align: 'center', type: 'date', dataFormat: 'g', },
        { field: 'patientName', title: this.getLanguageResource('4184', 'S', '환자명'), width: 70, align: 'center', bodyTemplateName:'patientName'},
        { field: 'patientCode', title: this.getLanguageResource('8451', 'S', '등록번호'), width: 65, align: 'center'},
        { field: 'gender', title: this.getLanguageResource('3680', 'S', '성별'), width: 35, align: 'center'},
        { field: 'age', title: this.getLanguageResource('1662', 'S', '나이'), width: 35, align: 'center'},
        { field: 'birthDay', title: this.getLanguageResource('3480', 'S', '생년월일'), width: 70, type: 'date', dataFormat: 'd', align: 'center'},
        { field: 'examinationName', title: this.getLanguageResource('16806', 'S', '검사'), bodyTemplateName:'colfont',},
        { field: 'paymentStatusName', title: this.getLanguageResource('3859', 'S', '수납'), width: 35, align: 'center', bodyTemplateName:'paid'},
        { field: 'issuedDate', title: this.getLanguageResource('5246', 'S', '오더일'), width: 70, type: 'date', dataFormat: 'd', align: 'center' },
        { field: 'issuedStaffName', title: this.getLanguageResource('9686', 'S', '처방의'), width: 60, align: 'center'},
        { field: 'patientTypeName', title: this.getLanguageResource('8421', 'S', '환자구분'), width: 40, align: 'center'},
        { field: 'medicalDepartmentName', title: this.getLanguageResource('7111', 'S', '진료과'), width: 75, align: 'center'},
        { field: 'scheduleComment', title: this.getLanguageResource('3173', 'S', '비고'), width:40, align: 'center', readOnly: true, bodyTemplateName:'detail'},
      ];
    },

    _getPerformDoctor(){
      if(isEmpty(this.get('examinationGroupCode'))){
        return;
      }

      this.set('issuedDoctorItems', []);
      const param = {
        examinationGroupCode: this.get('examinationGroupCode'),
        relationTypeCode: "PerformDoctor"
      };
      this.get('peApiService').onGetExaminationEmployeeList(param).then(function(data){
        this.set('issuedDoctorItems', data);
      }.bind(this));
    },

    _getExaminationRoom(){
      if(isEmpty(this.get('examinationGroupCode'))){
        return;
      }
      const param = {
        examinationGroupCode: this.get('examinationGroupCode')
      };
      this.get('peApiService').onGetAcceptableRoomList(param).then(function(data){
        this.set('examinationRoomItems', data);

        if(!isEmpty(this.get('condition.examinationRoomId'))){
          const examinationRoomId = this.get('condition.examinationRoomId');
          const exist = data.findBy('examinationRoomId', examinationRoomId);
          if(!isEmpty(exist)){
            this.set('selectedExaminationRoomId', examinationRoomId);
            if(!this.get('isEndLoad')){
              this._endLoadSearch();
            }
          }
        }
      }.bind(this));
    },

    _getDepartment(){
      this.get('peApiService').onGetDepartmentGroupList({code: 'AMD'}).then(function(res){
        if(!isEmpty(res)){
          this.set('issuedDepartmentItems', res);
        }
      }.bind(this));
    },

    getParamsDate(date) {
      return new Date(date.getFullYear(), date.getMonth(), date.getDate()).toFormatString();
    },

    _setFromToDate(type) {
      const calendarDate = new Date(this.getParamsDate(this.get('calendarSelectedDate')));
      let firstDay = moment(calendarDate).format('YYYY-MM-DD');
      let lastDay = moment(calendarDate).format('YYYY-MM-DD');
      if(type === 'Weekly') {
        const days = calendarDate.getDay();
        const diff = days - 0;
        const weekFirstDay = calendarDate.addDays(-diff);
        const weekLastDay = weekFirstDay.addDays(6);
        firstDay = weekFirstDay;
        lastDay = weekLastDay;
      } else if(type === 'Monthly') {
        firstDay = new Date(calendarDate.getFullYear(), calendarDate.getMonth(), 1);
        lastDay = new Date(calendarDate.getFullYear(), calendarDate.getMonth()+1, 0);
      }
      return {fromDate: firstDay, toDate: lastDay};
    },

    _getExportExcelData(data) {
      if(isEmpty(data)){
        return;
      }

      const title = [
        this.getLanguageResource('743', 'F','검사실'),
        this.getLanguageResource('1258', 'F','구분'),
        this.getLanguageResource('5150', 'F','예약일시'),
        this.getLanguageResource('4184', 'S', '환자명'),
        this.getLanguageResource('8451', 'S', '등록번호'),
        this.getLanguageResource('3680', 'F','성별'),
        this.getLanguageResource('1662', 'F','나이'),
        this.getLanguageResource('3480', 'F','생년월일'),
        this.getLanguageResource('16806', 'F','검사'),
        this.getLanguageResource('3859', 'S', '수납'),
        this.getLanguageResource('5246', 'S', '오더일'),
        this.getLanguageResource('8421', 'F','환자구분'),
        this.getLanguageResource('7111', 'F','진료과'),
        this.getLanguageResource('14751', 'S', '현위치'),
        this.getLanguageResource('9686', 'S', '처방의'),
        this.getLanguageResource('3173', 'F', '비고'),
      ];

      const initArr = [title];
      const resultArr = [];
      data.forEach(datas => {
        resultArr.push([
          datas.examinationRoomName,
          datas.isScheduling ? this.getLanguageResource('10670', 'S', '예약') : this.getLanguageResource('11749', 'S', '비예약'),
          datas.scheduleDateTime,
          datas.patientName,
          datas.patientCode,
          datas.gender,
          datas.age,
          this.get('fr_I18nService').formatDate(datas.birthDay, 'd'),
          datas.examinationName,
          datas.paymentStatusName,
          this.get('fr_I18nService').formatDate(datas.issuedDate, 'd'),
          datas.patientTypeName,
          datas.medicalDepartmentName,
          datas.occupyingLocation,
          datas.issuedStaffName,
          datas.scheduleComment
        ]);
      });

      const today = this.get('fr_I18nService').formatDate(this.get('co_CommonService').getNow(), 'd');
      const fileName = today + '_' + this.getLanguageResource('5167', 'S','예약현황');

      this.get('peApiService').getExportByArrayTypeExcel(initArr, resultArr, fileName);
    },

    _getPrintOut(data){
      if(isEmpty(data)){
        return;
      }

      data.map(item => {
        set(item, 'birthDay', this.get('fr_I18nService').formatDate(item.birthDay, 'd'));
        set(item, 'issuedDate', this.get('fr_I18nService').formatDate(item.issuedDate, 'd'));
        set(item, 'scheduleDateTime', this.get('fr_I18nService').formatDate(item.scheduleDateTime, 'g'));
        set(item, 'schedulingTypeName', item.isScheduling ? this.getLanguageResource('10670', 'S', '예약') : this.getLanguageResource('11749', 'S', '비예약'));
        return item;
      });

      const scheduleDate = this.get('calendarSelectedDate');
      const printContent = {};
      printContent.dataField = { "examinationScheduleList": data };
      printContent.parameterField = {"scheduleDate" : this.get('fr_I18nService').formatDate(scheduleDate, 'd')};

      this.set('print', EmberObject.create({printPopup: false,
        printConfig: {
          'printType': 2,
          'printName': 'ExaminationScheduleList',
          'commonInformation' : false
        },
        printContent: printContent
      }));
    },

    _onExaminationClear(){
      this.set('selectedExamList', []);
    },

    _getAllExaminationList(){
      if(isEmpty(this.get('examinationGroupCode'))){
        return;
      }

      const param = { examinationGroupCode: this.get('examinationGroupCode')};
      this.get('peApiService').onGetExaminationList(param).then(function(res){
        if(!isEmpty(res)){
          this.set('examinationItems', res);
        }
      }.bind(this));
    },

    _setExaminationGroupChanged(){
      this._getExaminationRoom();
      this._getPerformDoctor();
      this._getAllExaminationList();
    },

    _getParam(){
      const param = {
        examinationGroupCode: this.get('examinationGroupCode'),
        examinationRoomId: this.get('selectedExaminationRoomId'),
        isScheduling: this.get('selectedStatusValue'),
        departmentId: this.get('selectedDepartmentId'),
        issuedStaffId: this.get('selectedEmployeeId'),
        examinationIds: null
      };
      if(!isEmpty(this.get('selectedExamList'))){
        const examinationIds = this.get('selectedExamList').getEach('examinationId');
        if(isPresent(examinationIds)){
          param.examinationIds = examinationIds.join('&examinationIds=');
        }
      }
      return param;
    },


    _getAllSearch(){
      if(!this.get('isEndLoad')){
        return;
      }
      try {
        if(isEmpty(this.get('calendarSelectedDate'))) {
          return;
        }
        this.set('isPageLoader', true);
        this.set('calendarItemsSource', emberA());
        this.set('gridItems', emberA());
        const param = this._getParam();
        const path = this.get('defaultUrl') + 'scheduled-status';
        const pathList = this.get('defaultUrl') + 'scheduled-list';
        const statusParam = $.extend({}, param);
        statusParam.searchDate = this.get('calendarSelectedDate');
        const listParam = $.extend({}, param);
        listParam.fromDate = this.get('selectedFromDate');
        listParam.toDate = this.get('selectedToDate');

        hash({
          statusData: this.getList(path, statusParam, null),
          listData: this.getList(pathList, listParam, null)
        }).then(function(res){
          if(!isEmpty(res.statusData)){
            res.statusData.forEach(d => {
              const tempObj = {
                fromDate: moment(d.scheduleDate).format('YYYY-MM-DD'),
                toDate: moment(d.scheduleDate).format('YYYY-MM-DD'),
                amCount: d.amCount,
                pmCount: d.pmCount,
              };
              this.get('calendarItemsSource').addObject(tempObj);
            });
          }
          if(!isEmpty(res.listData)){
            this.set('gridItems', res.listData);
          }
          this.set('isPageLoader', false);
        }.bind(this));
      }catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isPageLoader', false);
          this._showError(e);
        }
      }
    },

    _getCalenderStatus(selectedDate){
      try {
        if(!this.get('isEndLoad')){
          return;
        }
        if(isEmpty(selectedDate)){
          return;
        }
        this.set('calendarItemsSource', emberA());
        const param = this._getParam();
        set(param, 'searchDate', selectedDate);
        const path = this.get('defaultUrl') + 'scheduled-status';
        this.getList(path, param, null).then(function (res) {
          if (!isEmpty(res)){
            res.forEach(d => {
              const tempObj = {
                fromDate: moment(d.scheduleDate).format('YYYY-MM-DD'),
                toDate: moment(d.scheduleDate).format('YYYY-MM-DD'),
                amCount: d.amCount,
                pmCount: d.pmCount,
              };
              this.get('calendarItemsSource').addObject(tempObj);
            });
          }
        }.bind(this));
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this._showError(e);
        }
      }
    },

    _getScheduleList(){
      try {
        if(!this.get('isEndLoad')){
          return;
        }
        this.set('gridItems', emberA());
        this.set('isShowGridLoader', true);
        const path = this.get('defaultUrl') + 'scheduled-list';
        const param = this._getParam();
        // const formToDate = this._setFromToDate(this.get('periodType'));
        // param.fromDate = formToDate.fromDate;
        // param.toDate = formToDate.toDate;
        param.fromDate = this.get('selectedFromDate');
        param.toDate = this.get('selectedToDate');

        this.getList(path, param, null).then(function (res) {
          if (!isEmpty(res)){
            res.map(data => {
              set(data, 'occupyingLocation', this.getOccupyingDate(data, 'code'));
              return data;
            });
            this.set('gridItems', res);
          }
        }.bind(this)).finally(function(){
          this.set('isShowGridLoader', false);
        }.bind(this));
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowGridLoader', false);
          this._showError(e);
        }
      }
    },

    async _setPeSettingInfo(){

      let viewId = this.get('viewId');
      if(this.get('examinationGroupCode') === 'DR'){
        viewId = this.get('viewId') + '_radiology';
      }
      const settingKey = viewId;
      const settingData = {
        conditionData: [{
          examinationGroupCode: this.get('examinationGroupCode'),
          examinationRoomId: this.get('selectedExaminationRoomId')
        }]};

      const description = this.getLanguageResource('13231', 'F', '영상/기능예약현황');
      await this.get('peApiService').setPeSettingInfo(settingKey, settingData, description);
    },

    async _getPeSettingInfo(){
      let viewId = this.get('viewId');
      if(this.get('examinationGroupCode') === 'DR'){
        viewId = this.get('viewId') + '_radiology';
      }
      const settingKey = viewId;
      const data = await this.get('peApiService').getPeSettingInfo(settingKey);
      if(!isEmpty(data)) {
        const condition = data[0];
        this.set('condition', condition);
        if(!isEmpty(condition.examinationGroupCode) && this.get('examinationGroupCode') != 'DR'){
          this.set('examinationGroupCode', condition.examinationGroupCode);
        }
        if(!isEmpty(condition.examinationRoomId) && isEmpty(this.get('examinationRoomItems'))){
          return;
        }

        if(!isEmpty(condition.examinationRoomId) && !isEmpty(this.get('examinationRoomItems'))){
          const exist = this.get('examinationRoomItems').findBy('examinationRoomId', condition.examinationRoomId);
          if(!isEmpty(exist)){
            this.set('selectedExaminationRoomId', condition.examinationRoomId);
          }
        }
        this._endLoadSearch();
      }else{
        this._endLoadSearch();
      }
    },

    _endLoadSearch(){
      this.set('isEndLoad', true);
      this._getAllSearch();
    },

    reSchedulingWarningMessage(){
      try {
        this.get('peApiService').onGetBusinessCodeList('ReScheduling', "").then(res => {
          if(!isEmpty(res)){
            const msg = res.get('firstObject').name;
            this.set('isReschedulingMessage', msg);
          }else{
            this.set('isReschedulingMessage', "");
          }
        });
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this._showError(e);
        }
      }
    },

    getOccupyingDate(item, type){
      if(isEmpty(item)){
        return;
      }

      let location = null;

      if(type == 'code'){
        if(!isEmpty(item.adminWard.displayCode)){
          location = item.adminWard.displayCode;
        }
        if(!isEmpty(item.room.displayCode)){
          location = location + '/ ' + item.room.displayCode;
        }
        if(!isEmpty(item.bed.displayCode)){
          location = location + '/ ' + item.bed.displayCode;
        }
        return location;
      }else{
        if(!isEmpty(item.adminWard.name)){
          location = item.adminWard.name;
        }
        if(!isEmpty(item.room.name)){
          location = location + '/ ' + item.room.name;
        }
        if(!isEmpty(item.bed.name)){
          location = location + '/ ' + item.bed.name;
        }
        return location;
      }
    },
  });