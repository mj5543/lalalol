import { set } from '@ember/object';
import { isEmpty, isPresent } from '@ember/utils';
import { A as emberA } from '@ember/array';
import layout from './template';
import CHIS from 'framework/chis-framework';
import { inject as service } from '@ember/service';
import MesaggeMixin from '../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(
  MesaggeMixin,
  {
    layout,
    loaderType: 'spinner',
    isShowContainerLoader: false,
    isShowLoader: false,
    isShowLoaderByRoom: false,
    loaderDimed: false,
    roomCombobox: null,
    paramEmployeeId: null,
    hasEmptyData: false,
    userGlobalInformation: null,
    apiService: service('patientexamination-endoscope-cleaning-service'),
    peApiService: service('patientexamination-service'),

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'patient-examination-cleaning-endoscope-management');
      this.setStateProperties([
        'model',
        'gridItemsSource',
        'gridColumns',
        'confirmItemsSource',
        'selectedFromDate',
        'selectedToDate',
        'cleaningFluidList',
        'cleaningFluidQuantityList',
        'disinfectingFluidList',
        'disinfectingFluidQuantityList',
        'sterilizerList',
        'examinationRoomList',
        'gridEditedItems'
      ]);

      if (!this.hasState()) {
        this.set('model', {
          selectedExaminationRoom: null,
          selectedConfirm: null,
          selectedRoomItems: null,
          selectedGridItem: null,
          searchEmployeeId: null,
          isCheckAll: false,
        });
        this.set('cleaningFluidList', emberA());
        this.set('cleaningFluidQuantityList', emberA());
        this.set('disinfectingFluidList', emberA());
        this.set('disinfectingFluidQuantityList', emberA());
        this.set('sterilizerList', emberA());
        this.set('gridItemsSource', emberA());
        this.set('gridColumns', [
          { field: 'isCheck', bodyTemplateName: 'checkbox', width: 35, align: 'center', headerTemplateName: 'checkall'},
          { field: 'examinationRoom.name', title: this.getLanguageResource('743', 'S', null, '검사실'), width: 100, align: 'center', readOnly: true},
          { field: 'patient.displayCode', title: this.getLanguageResource('8451', 'F', null, '등록번호'), width: 65, align: 'center', readOnly: true},
          { field: 'patient.name', title: this.getLanguageResource('16881', 'F', null, '환자명'), width: 90, readOnly: true},
          { field: 'examinationName', title: this.getLanguageResource('17062', 'F', null, '검사명'), bodyTemplateName: 'examinationName', readOnly: true},
          { field: 'executeStaffName', title: this.getLanguageResource('17131', 'F', null, '시행자'), width: 65, align: 'center', readOnly: true},
          { field: 'interpretationStaffName', title: this.getLanguageResource('7953', 'F', null, '판독의'), width: 66, align: 'center', readOnly: true},
          { field: 'endoscope.id', title: this.getLanguageResource('10136', 'F', null, '사용스콥'), width: 110, align: 'center', bodyTemplateName: 'endoscopeCombobox'},
          { field: 'cleaningDatetime', title: this.getLanguageResource('10657', 'F', null, '세척일시'), width: 165, align: 'center', type: 'date', dataFormat: 'g', bodyTemplateName:'cleaningDate'},
          { field: 'disinfectionDatetime', title: this.getLanguageResource('10662', 'F', null, '소독일시'), width: 165, align: 'center', type: 'date', dataFormat: 'g', bodyTemplateName:'disinfectionDate'},
          { field: 'cleaningCount', title: this.getLanguageResource('4214', 'S', null, '수행횟수'), width: 60, align: 'right', type: 'number', allowDecimal: true},
          { field: 'cleaningFluid.name', title: this.getLanguageResource('10659', 'F', null, '세척액'), width: 100, align: 'center', bodyTemplateName: 'cleaningFluid'},
          { field: 'cleaningFluidQuantity', title: this.getLanguageResource('10660', 'F', null, '세척액사용량'), width: 80, align: 'right', type: 'number', allowDecimal: true},
          { field: 'disinfectingFluid.name', title: this.getLanguageResource('10663', 'F', null, '소독액'), width: 100, align: 'center', bodyTemplateName: 'disinfectingFluid'},
          { field: 'disinfectingFluidQuantity', title: this.getLanguageResource('10664', 'F', null, '소독액사용량'), width: 80, align: 'right', type: 'number', allowDecimal: true},
          { field: 'sterilizer.name', title: this.getLanguageResource('10665', 'F', null, '소독기'), width: 90, align: 'center', bodyTemplateName: 'sterilizer'},
          { field: 'cleaningStaff.name', title: this.getLanguageResource('10661', 'F', null, '세척직원'), width: 65, align: 'center', readOnly: true}
        ]);
        this.set('confirmItemsSource', [
          {value: true, name: this.getLanguageResource('10000', 'F', null, '등록')},
          {value: false, name: this.getLanguageResource('2367', 'F', null, '미등록')}
        ]);
        const displayDate = new Date(this.get('co_CommonService').getNow());
        this.set('selectedFromDate', displayDate);
        this.set('selectedToDate', displayDate);
        if(!isEmpty(this.get('co_CurrentUserService.user'))){
          this.set('userGlobalInformation', this.get('co_CurrentUserService.user'));
        }
        this.set('gridEditedItems', emberA());
      }
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1624');
      this._init();
    },
    actions: {
      onExaminationRoomLoaded(e) {
        this.set('roomCombobox', e.source);
      },
      onRoomSelectionChanged(e) {
        this.set('model.selectedRoomItems', e.selectedItems);
      },
      onSearchButtonClick() {
        this._getEndoscopeCleaning();
      },
      onDateUpdated() {
        this._getEndoscopeCleaningExaminationRoom();
      },
      onExcelButtonClick() {
        this._getExportExcelData();
      },
      onDelButtonClick() {
        this._showDeleteConfirm();
      },
      onSaveButtonClick() {
        if(isEmpty(this.get('gridEditedItems'))) {
          return;
        }
        this._updateBeforeCheck();
      },
      onSelectEmployee(item) {
        if(isEmpty(this.get('model.selectedGridItem'))) {
          return;
        }
        set(this.get('model.selectedGridItem'), 'cleaningStaff.id', item.employeeId);
        set(this.get('model.selectedGridItem'), 'cleaningStaff.name', item.fullName);
      },
      onGridCellEditEnd(e) {
        let hasItem = null;
        if(!isEmpty(this.get('gridEditedItems'))) {
          hasItem = this.get('gridEditedItems').find(d => d.endoscopeCleaningId === e.item.endoscopeCleaningId);
        }
        if(isEmpty(hasItem)) {
          this.get('gridEditedItems').addObject(e.item);
        }
      },

      onCheckAllchanged(){
        if(isEmpty(this.get('gridItemsSource'))){
          return;
        }
        this.get('gridItemsSource').map(item =>{
          set(item, 'isCheck', !this.get('model.isCheckAll'));
          return item;
        });
      },

      onCheckchanged(){
        this.set('model.isCheckAll', false);
      },

      onMultiApplyClick(){
        const selectedItems = this.get('gridItemsSource').filterBy('isCheck', true);
        this.set('multiSettingItems', selectedItems);
        if(isEmpty(selectedItems)){
          //Message
          return;
        }
        this.set('isMultiSettingOpen', true);
      },

      onSetValue(result){
        const selectedItems = this.get('gridItemsSource').filterBy('isCheck', true);
        if(isEmpty(selectedItems)){
          return;
        }
        selectedItems.map(items =>{
          if(!isEmpty(result.cleaningDatetime)){
            set(items, 'cleaningDatetime', result.cleaningDatetime);
          }
          if(!isEmpty(result.cleaningFluidId)){
            set(items, 'cleaningFluid.id', result.cleaningFluidId);
          }
          if(!isEmpty(result.cleaningFluidQuantity)){
            set(items, 'cleaningFluidQuantity', result.cleaningFluidQuantity);
          }
          if(!isEmpty(result.disinfectionDatetime)){
            set(items, 'disinfectionDatetime', result.disinfectionDatetime);
          }
          if(!isEmpty(result.disinfectingFluidId)){
            set(items, 'disinfectingFluid.id', result.disinfectingFluidId);
          }
          if(!isEmpty(result.disinfectingFluidQuantity)){
            set(items, 'disinfectingFluidQuantity', result.disinfectingFluidQuantity);
          }
          if(!isEmpty(result.sterilizerId)){
            set(items, 'sterilizer.id', result.sterilizerId);
          }
          if(!isEmpty(result.cleaningStaff)){
            set(items, 'cleaningStaff', {id: result.cleaningStaff.employeeId, name: result.cleaningStaff.fullName});
          }
          if(isEmpty(items.cleaningCount)){
            set(items, 'cleaningCount', 1);
          }
        });

        const gridEditedItems = this.get('gridEditedItems');
        selectedItems.forEach(e => {
          let hasItem = null;
          if(!isEmpty(gridEditedItems.endoscopeCleaningId)){
            hasItem = this.get('gridEditedItems').find(d => d.endoscopeCleaningId === e.endoscopeCleaningId);
          }
          if(isEmpty(hasItem)) {
            this.get('gridEditedItems').addObject(e);
          }
        });
      }
    },

    async _getEndoscopeCleaningAttribute() {
      try {
        const cleaningFluid = await this.get('apiService').getEndoscopeCleaningAttribute('CleaningFluid');
        this.set('cleaningFluidList', cleaningFluid);
        const disinfectingFluid = await this.get('apiService').getEndoscopeCleaningAttribute('DisinfectingFluid');
        this.set('disinfectingFluidList', disinfectingFluid);
        const disinfectingFluidQuantity = await this.get('apiService').getEndoscopeCleaningAttribute('DisinfectingFluidQuantity');
        this.set('disinfectingFluidQuantityList', disinfectingFluidQuantity);
        const sterilizer = await this.get('apiService').getEndoscopeCleaningAttribute('Sterilizer');
        this.set('sterilizerList', sterilizer);
        const cleaningFluidQuantity = await this.get('apiService').getEndoscopeCleaningAttribute('CleaningFluidQuantity');
        this.set('cleaningFluidQuantityList', cleaningFluidQuantity);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this._showError(e);
        }
      }
    },

    async _getEndoscopeCleaningExaminationRoom() {
      try {
        this.set('isShowLoaderByRoom', true);
        const params = {
          fromDate: this.getSearchPramsDate(this.get('selectedFromDate')),
          toDate: this.getSearchPramsDate(this.get('selectedToDate'))
        };
        const result = await this.get('apiService').getEndoscopeCleaningExaminationRoom(params);
        this.set('examinationRoomList', result);
        this.set('isShowLoaderByRoom', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowLoaderByRoom', false);
          this._showError(e);
        }
      }
    },

    async _getEndoscopeCleaning() {
      try {
        const roomIds = [];
        this.set('loaderType', 'spinner');
        this.set('loaderDimed', false);
        this.set('isShowLoader', true);
        this.set('gridItemsSource', emberA());
        this.set('gridEditedItems', emberA());
        const selectedRoomItems = this.get('roomCombobox.selectedItems');
        if (!isEmpty(selectedRoomItems)) {
          selectedRoomItems.forEach(item => {
            roomIds.push(item.examinationRoomId);
          });
        }
        const params = {
          fromDate: this.getSearchPramsDate(this.get('selectedFromDate')),
          toDate: this.getSearchPramsDate(this.get('selectedToDate')),
          isConfirm: this.get('model.selectedConfirm'),
          examinationRooms: null
        };
        if (isPresent(roomIds)){
          params.examinationRooms = roomIds.join('&examinationRooms=');
        }
        const result = await this.get('apiService').getEndoscopeCleaning(params);
        if(!isEmpty(result)){
          result.map(item => {
            set(item, 'isCheck', false);
            if(isEmpty(item.cleaningFluid)){
              set(item, 'cleaningFluid', {id: null, displayCode: null, name: null});
            }
            if(isEmpty(item.disinfectingFluid)){
              set(item, 'disinfectingFluid', {id: null, displayCode: null, name: null});
            }
            if(isEmpty(item.sterilizer)){
              set(item, 'sterilizer', {id: null, displayCode: null, name: null});
            }
            return item;
          });
          this.set('gridItemsSource', result);
        }
        this.set('isShowLoader', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowLoader', false);
          this._showError(e);
        }
      }
    },

    _init() {
      this.set('isShowContainerLoader', true);
      this._getEndoscopeCleaningAttribute();
      this._getEndoscopeCleaningExaminationRoom();

    },

    _updateBeforeCheck() {
      const params = this._getSaveData();
      if(this.get('hasEmptyData')) {
        this._showSaveConfirm(params);
        return;
      }
      this._updateEndoscopeCleanings(params);

    },

    async _updateEndoscopeCleanings(params) {
      this.set('loaderType', 'progress');
      this.set('loaderDimed', true);
      this.set('isShowLoader', true);
      try {
        await this.get('apiService').updateEndoscopeCleaning(params);
        this.get('peApiService').onShowToast('save', this.getLanguageResource('8942', 'F', null, '저장되었습니다'), '');
        await this._getEndoscopeCleaning();
        this.set('isShowLoader', false);
        this.set('loaderDimed', false);
      } catch(e) {
        this._showSaveError(e);
        this.set('isShowLoader', false);
        this.set('loaderDimed', false);
      }
    },

    async _showSaveConfirm(params) {
      const message = this.getLanguageResource('8939', 'F', '저장하시겠습니까?');
      const result = await this.get('apiService').showConfirm(message, '');
      if (result === 'Yes') {
        this.set('hasEmptyData', false);
        this._updateEndoscopeCleanings(params);
      }
    },

    async _deleteEndoscopeCleanings() {
      if(isEmpty(this.get('model.selectedGridItem'))) {
        return;
      }
      this.set('loaderType', 'progress');
      this.set('loaderDimed', true);
      this.set('isShowLoader', true);
      try {
        const {actionStaffId, actionDateTime} = this._getActionParams();
        const params = {
          endoscopeCleaningId: this.get('model.selectedGridItem.endoscopeCleaningId'),
          actionStaffId,
          actionDateTime
        };
        await this.get('apiService').deleteEndoscopeCleaning(params);
        const message = this.getLanguageResource('8944', 'F', '삭제되었습니까?');
        this.get('peApiService').onShowToast('delete', message, '');
        await this._getEndoscopeCleaning();
        this.set('isShowLoader', false);
        this.set('loaderDimed', false);
      } catch(e) {
        this.showToastDeleteFail();
        this.set('isShowLoader', false);
        this.set('loaderDimed', false);
      }
    },

    _getSaveData() {
      const {actionStaffId, actionDateTime} = this._getActionParams();
      const gridDatas = this.get('gridEditedItems');
      this.set('hasEmptyData', false);
      const endoscopeCleaningArr = [];
      if(isEmpty(gridDatas)){
        return;
      }
      gridDatas.forEach(data => {
        let cleaningStaffId = data.cleaningStaff.id;
        if(isEmpty(cleaningStaffId)){
          cleaningStaffId = actionStaffId;
        }
        const dataObj = {
          endoscopeCleaningId: data.endoscopeCleaningId,
          endoscopeId: data.endoscope.id,
          cleaningDatetime: data.cleaningDatetime,
          disinfectionDatetime: data.disinfectionDatetime,
          cleaningCount: data.cleaningCount,
          cleaningFluidId: data.cleaningFluid.id,
          cleaningFluidQuantity:  data.cleaningFluidQuantity,
          disinfectingFluidId: data.disinfectingFluid.id,
          disinfectingFluidQuantity: data.disinfectingFluidQuantity,
          sterilizerId:  data.sterilizer.id,
          cleaningStaffId: cleaningStaffId
        };
        const valueArr = Object.values(dataObj);
        if(isEmpty(valueArr)){
          return;
        }
        valueArr.forEach(v => {
          if(isEmpty(v)) {
            this.set('hasEmptyData', true);
          }
        });
        endoscopeCleaningArr.push(dataObj);
      });
      const params = {
        actionStaffId: actionStaffId,
        actionDatetime: actionDateTime,
        endoscopeCleanings: endoscopeCleaningArr
      };
      return params;
    },

    _getActionParams() {
      const actionStaffId = this.get('userGlobalInformation.employeeId');
      const actionDateTime = this.get('co_CommonService').getNow();
      return {actionStaffId, actionDateTime};
    },
    getSearchPramsDate(date) {
      return new Date(date.getFullYear(), date.getMonth(), date.getDate()).toFormatString();
    },

    _showDeleteConfirm() {
      const options = this._questionMessage(this.getLanguageResource('8929', 'F', null, '삭제 하시겠습니까?'));
      messageBox.show(this, options).then(function (result) {
        if(result === 'Yes'){
          this._deleteEndoscopeCleanings();
        }
      }.bind(this));
    },

    _getExportExcelData() {
      const gridItemsSource = this.get('gridItemsSource');
      const firstRow = [];
      const columns = this.get('gridColumns');
      columns.forEach(column => {
        firstRow.push(column.title);
      });
      const initArr = [firstRow];
      const resultArr = [];
      if(isEmpty(gridItemsSource)){
        return;
      }
      gridItemsSource.forEach(datas => {
        resultArr.push([
          null,
          datas.examinationRoom.name,
          datas.patient.displayCode,
          datas.patient.name,
          datas.examinationName,
          datas.executeStaffName,
          datas.interpretationStaffName,
          datas.endoscope.name,
          datas.cleaningDatetime,
          datas.disinfectionDatetime,
          datas.cleaningCount,
          datas.cleaningFluid.name,
          datas.cleaningFluidQuantity,
          datas.disinfectingFluid.name,
          datas.disinfectingFluidQuantity,
          datas.sterilizer.name,
          datas.cleaningStaff.name
        ]);
      });
      const fileName = 'EndoscopeCleaning';
      this.get('peApiService').getExportByArrayTypeExcel(initArr, resultArr, fileName);
    },

    _questionMessage(messageBoxText){
      return {
        'caption': '',
        'messageBoxImage': 'question',
        'messageBoxButton': 'YesNo',
        'messageBoxText': messageBoxText,
        'messageBoxFocus': 'Yes',
      };
    },
  });