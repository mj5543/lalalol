import { next } from '@ember/runloop';
import { hash } from 'rsvp';
import { set } from '@ember/object';
import { isEmpty } from '@ember/utils';
import layout from './template';
import CHIS from 'framework/chis-framework';
import { inject as service } from '@ember/service';
import MesaggeMixin from '../../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(
  MesaggeMixin,
  {
    layout,
    cleaningStaff: null,
    userGlobalInformation: null,
    multiSettingItems: null,
    apiService:service('patientexamination-endoscope-cleaning-service'),

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'patient-examination-cleaning-endoscope-management');
      this.setStateProperties([
        'model',
        'cleaningStaff',
        'userGlobalInformation',
        'multiSettingItems'
      ]);

      if (!this.hasState()) {
        this.set('model', {
          cleaningDatetime: null,
          cleaningFluidId: null,
          cleaningFluidQuantity: null,
          disinfectionDatetime: null,
          disinfectingFluidId: null,
          disinfectingFluidQuantity: null,
          sterilizerId: null
        });
      }
    },

    onLoaded() {
      this._super(...arguments);
      if(!isEmpty(this.get('co_CurrentUserService.user'))){
        this.set('userGlobalInformation', this.get('co_CurrentUserService.user'));
      }
      this._getEndoscopeCleaningAttribute();
    },

    actions: {
      onSelectEmployee(item){
        this.set('cleaningStaff', item);
      },

      onSetDefaultValue(){
        const cleaningFluid = this.get('cleaningFluidList').findBy('isDefaultValue', true);
        const cleaningFluidQuantity = this.get('cleaningFluidQuantityList').findBy('isDefaultValue', true);
        const disinfectingFluid = this.get('disinfectingFluidList').findBy('isDefaultValue', true);
        const disinfectingFluidQuantity = this.get('disinfectingFluidQuantityList').findBy('isDefaultValue', true);
        const sterilizer = this.get('sterilizerList').findBy('isDefaultValue', true);

        if(!isEmpty(cleaningFluid)){
          this.set('model.cleaningFluidId', cleaningFluid.endoscopeCleaningAttributeId);
        }
        if(!isEmpty(cleaningFluidQuantity)){
          this.set('model.cleaningFluidQuantity', Number(cleaningFluidQuantity.attributeName));
        }
        if(!isEmpty(disinfectingFluid)){
          this.set('model.disinfectingFluidId', disinfectingFluid.endoscopeCleaningAttributeId);
        }
        if(!isEmpty(disinfectingFluidQuantity)){
          this.set('model.disinfectingFluidQuantity', Number(disinfectingFluidQuantity.attributeName));
        }
        if(!isEmpty(sterilizer)){
          this.set('model.sterilizerId', sterilizer.endoscopeCleaningAttributeId);
        }
        const now = this.get('co_CommonService').getNow();
        this.set('model.cleaningDatetime', now);
        this.set('model.disinfectionDatetime', now);
        this.set('paramEmployeeId', this.get('userGlobalInformation.employeeId'));
        this.set('cleaningStaff', {employeeId: this.get('userGlobalInformation.employeeId'), fullName: this.get('userGlobalInformation.employeeName')});
      },

      onEndoscopePopupClose(){
        this.set('model', {
          cleaningDatetime: null,
          cleaningFluidId: null,
          cleaningFluidQuantity: null,
          disinfectionDatetime: null,
          disinfectingFluidId: null,
          disinfectingFluidQuantity: null,
          sterilizerId: null
        });
        this.set('paramEmployeeId', null);
        this.set('cleaningStaff', {});
      },

      onSetConfirm(){
        const items = this.get('model');
        set(items, 'cleaningStaff', this.get('cleaningStaff'));
        this.set('isMultiSettingOpen', false);
        if(!isEmpty(this.get('EndoscopeMultiSetCB'))) {
          this.get('EndoscopeMultiSetCB')(items);
        }
      }
    },

    _getEndoscopeCleaningAttribute(){
      try {
        this.set('isMediumLoader', true);
        hash({
          cleaningFluidList: this.get('apiService').getEndoscopeCleaningAttribute('CleaningFluid'),
          cleaningFluidQuantityList: this.get('apiService').getEndoscopeCleaningAttribute('CleaningFluidQuantity'),
          disinfectingFluidList: this.get('apiService').getEndoscopeCleaningAttribute('disinfectingFluid'),
          disinfectingFluidQuantityList: this.get('apiService').getEndoscopeCleaningAttribute('DisinfectingFluidQuantity'),
          sterilizerList: this.get('apiService').getEndoscopeCleaningAttribute('Sterilizer')
        }).then(function(res){
          if(!isEmpty(res.cleaningFluidList)){
            this.set('cleaningFluidList', res.cleaningFluidList);
          }
          if(!isEmpty(res.disinfectingFluidList)){
            this.set('disinfectingFluidList', res.disinfectingFluidList);
          }
          if(!isEmpty(res.sterilizerList)){
            this.set('sterilizerList', res.sterilizerList);
          }
          if(!isEmpty(res.cleaningFluidQuantityList)){
            this.set('cleaningFluidQuantityList', res.cleaningFluidQuantityList);
          }
          if(!isEmpty(res.disinfectingFluidQuantityList)){
            this.set('disinfectingFluidQuantityList', res.disinfectingFluidQuantityList);
          }
          next(this, function(){
            this.set('isMediumLoader', false);
          });
        }.bind(this));
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isMediumLoader', false);
          this._showError(e);
        }
      }
    }
  });