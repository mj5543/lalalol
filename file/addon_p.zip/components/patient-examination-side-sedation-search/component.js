import { A as emberA } from '@ember/array';
import { isEmpty } from '@ember/utils';
import layout from './template';
import CHIS from 'framework/chis-framework';
import { inject as service } from '@ember/service';
import MessageMixin from '../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(
  MessageMixin,
  {
    layout,
    isDisabled: false,
    loaderType: 'spinner',
    isShowLoader: false,
    loaderDimed: false,
    patientId: null,
    apiService:service('patientexamination-side-effects-service'),
    peApiService:service('patientexamination-service'),

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'patient-examination-side-sedation-search');
      this.setStateProperties([
        'selectedFromDate',
        'selectedToDate',
        'radioSelectedValue',
        'gridItemsSource',
        'gridColumns',
        'sideExaminationTypes',
        'columnResizeType',
        'patientColumns',
        'sedatienColumns',
        'contrastColumns'
      ]);

      if (!this.hasState()) {
        this.set('model', {
          examinationType: null,
        });
        this.set('isDisabled', false);
        const displayDate = new Date(this.get('co_CommonService').getNow());
        this.set('selectedDate', displayDate);
        if(!isEmpty(this.get('co_CurrentUserService.user'))){
          this.set('globalCurrentUser', this.get('co_CurrentUserService.user'));
        }
        if(!isEmpty(this.get('co_PatientManagerService.selectedPatient'))){
          this.set('globalPatient', this.get('co_PatientManagerService.selectedPatient'));
        }
        this.set('radioButtonItems', [
          {value: 'contrast', name: this.getLanguageResource('3045', 'S','부작용')},
          {value: 'sedation', name: this.getLanguageResource('7139', 'S','진정')}
        ]);

        // this.set('patientId', '29d4a8de-37ba-44c6-b974-426342bcfe3a');
        if (isEmpty(this.get('patientId'))) {
          this.set('selectedFromDate', this.get('co_CommonService').getNow().addMonths(-1));
          this.set('selectedToDate', this.get('co_CommonService').getNow());
        } else {
          this.set('selectedFromDate', this.get('co_CommonService').getNow().addYears(-3));
          this.set('selectedToDate', this.get('co_CommonService').getNow());
        }
        this.set('radioSelectedValue', 'contrast');
      }
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1360');
      this._getBusinessCodeList();
      this._getDataList();
    },
    actions: {
      onSearchClick() {
        this._getDataList();
      },
      onExcelClick() {
        this._getExportExcelData();
      },

      onTypeChanged(){
        if(!isEmpty(this.get('patientId'))){
          this._getDataList();
        }
      }
    },

    _setGridColumns() {
      const contrastColumns = [
        { field: 'occurredDate', title: this.getLanguageResource('9947', 'F', null, '시행일'), width: 80, type: 'date', dataFormat: 'd', align: 'center'},
        { field: 'examination.name', title: this.getLanguageResource('16806', 'F', null, '검사'), width: 150, bodyTemplateName:'tooltip'},
        { field: 'contrastMedia.name', title: this.getLanguageResource('6904', 'F', null, '조영제'), width: 120, bodyTemplateName: 'tooltip'},
        { field: 'isPreviousTreatment', title: this.getLanguageResource('6699', 'F', null, '전처치여부'), width: 50, align: 'center', bodyTemplateName: 'boolToDisplay'},
        { field: 'isSubside', title: this.getLanguageResource('7139', 'F', null, '진정'), width: 50, align: 'center', bodyTemplateName: 'boolToDisplay'},
        { field: 'symptomNames', title: this.getLanguageResource('7063', 'F', null, '증상'), width: 100, bodyTemplateName:'tooltip'},
        { field: 'isDiabetesDrug', title: this.getLanguageResource('1868', 'F', null, '당뇨약'), width: 50, align: 'center', bodyTemplateName: 'diabetesDrug'},
        { title: this.getLanguageResource('10129', 'S', null, '1차') , columns: [
          { field: 'firstDrugOrder.drugName', title: this.getLanguageResource('10116', 'F', null, '처치약'), width: 90},
          { field: 'firstDrugOrder.dosage', title: this.getLanguageResource('5520', 'F', null, '용량'), width: 40, align: 'center'},
          { field: 'firstDrugOrder.instructionRouteTypeName', title: this.getLanguageResource('7894', 'F', null, '투여경로'), width: 50, align: 'center'},
          { field: 'firstDrugOrder.instructionName', title: this.getLanguageResource('3431', 'F', null, '상세투여경로'), width: 70, align: 'center'},
        ]},
        { title: this.getLanguageResource('10130', 'S', null, '2차'), columns: [
          { field: 'secondDrugOrder.drugName', title: this.getLanguageResource('10116', 'F', null, '처치약'), width: 90},
          { field: 'secondDrugOrder.dosage', title: this.getLanguageResource('5520', 'F', null, '용량'), width: 40, align: 'center'},
          { field: 'secondDrugOrder.instructionRouteTypeName', title: this.getLanguageResource('7894', 'F', null, '투여경로'), width: 50, align: 'center'},
          { field: 'secondDrugOrder.instructionName', title: this.getLanguageResource('3431', 'F', null, '상세투여경로'), width: 70, align: 'center'},
        ]},
        { title: this.getLanguageResource('10131', 'S', null, '3차'), columns: [
          { field: 'thirdDrugOrder.drugName', title: this.getLanguageResource('10116', 'F', null, '처치약'), width: 90},
          { field: 'thirdDrugOrder.dosage', title: this.getLanguageResource('5520', 'F', null, '용량'), width: 40, align: 'center'},
          { field: 'thirdDrugOrder.instructionRouteTypeName', title: this.getLanguageResource('7894', 'F', null, '투여경로'), width: 50, align: 'center'},
          { field: 'thirdDrugOrder.instructionName', title: this.getLanguageResource('3431', 'F', null, '상세투여경로'), width: 70, align: 'center'},
        ]},
        { field: 'remark', title: this.getLanguageResource('3173', 'S', null, '비고'), width: 40, align: 'center', bodyTemplateName: 'remark'},
      ];
      const sedatienColumns = [
        { field: 'occurredDate', title: this.getLanguageResource('9947', 'F', null, '시행일'), width: 80, type: 'date', dataFormat: 'd', align: 'center'},
        { field: 'examination.name', title: this.getLanguageResource('16806', 'F', null, '검사'), bodyTemplateName:'tooltip'},
        { field: 'examinationType.name', title: this.getLanguageResource('9009', 'F', null, '분류'), width: 60, align: 'center'},
        { field: 'isSedation', title: this.getLanguageResource('7139', 'F', null, '진정'), width: 60, align: 'center', bodyTemplateName: 'boolToDisplay'},
        { field: 'isClaustrophobia', title: this.getLanguageResource('8026', 'F', null, '폐쇄 공포증'), width: 70, align: 'center', bodyTemplateName: 'boolToDisplay'},
        { field: 'drugOrder.drugName', title: this.getLanguageResource('10116', 'F', null, '처치약'), width: 120},
        { field: 'drugOrder.dosage', title: this.getLanguageResource('5520', 'F', null, '용량'), width: 60, align: 'center'},
        { field: 'drugOrder.instructionRouteTypeName', title: this.getLanguageResource('7894', 'F', null, '투여경로'), width: 50, align: 'center'},
        { field: 'drugOrder.instructionName', title: this.getLanguageResource('3431', 'F', null, '상세투여경로'), width: 70, align: 'center'},
        { field: 'remark', title: this.getLanguageResource('3173', 'S', null, '비고'), width: 40, align: 'center', bodyTemplateName: 'remark'},
      ];
      const patientColumns = [
        { field: 'patientName', title: this.getLanguageResource('16881', 'S', null, '환자명'), width: 90, align: 'center', bodyTemplateName:'bold'},
        { field: 'patientCode', title: this.getLanguageResource('8451', 'F', null, '등록번호'), width: 65, align: 'center', bodyTemplateName:'bold'},
        { field: 'age', title: this.getLanguageResource('1662', 'F', null, '나이'), width: 35, align: 'center'},
        { field: 'gender', title: this.getLanguageResource('3680', 'F', null, '성별'), width: 35, align: 'center'},
      ];
      if (this.get('radioSelectedValue') === 'contrast') {
        this.set('columnResizeType', 'flex');
        if (isEmpty(this.get('patientId'))) {
          patientColumns.push(...contrastColumns);
          this.set('gridColumns', patientColumns);
        } else {
          this.set('gridColumns', contrastColumns);
        }
      } else {
        this.set('columnResizeType', 'fit');
        if (isEmpty(this.get('patientId'))) {
          patientColumns.push(...sedatienColumns);
          this.set('gridColumns', patientColumns);
        } else {
          this.set('gridColumns', sedatienColumns);
        }
      }
    },

    async _getBusinessCodeList() {
      try {
        const examinationTypes = await this.get('apiService').getBusinessCode('SideExaminationType');
        this.set('sideExaminationTypes', examinationTypes);
      } catch(e) {
        //
      }
    },

    async _getDataList() {
      try {
        this.set('isShowLoader', true);
        this._setGridColumns();
        this.set('gridItemsSource', emberA());
        const radioValue = this.get('radioSelectedValue');
        const params = {
          examinationTypeCode: this.get('model.examinationType'),
          fromdate: this.getSearchParamsDate(this.get('selectedFromDate')),
          todate: this.getSearchParamsDate(this.get('selectedToDate')),
          patientId: this.get('patientId')
        };
        let promise = null;
        if (radioValue === 'contrast') {
          promise = this.get('apiService').getContrastAll(params);
        } else {
          promise = this.get('apiService').getSedationAll(params);
        }
        const result = await promise;
        if(!isEmpty(result)) {
          result.map(data => {
            const symptomList = [];
            if(!isEmpty(data.symptom)) {
              data.symptom.forEach(item => {
                symptomList.push(item.name);
              });
            }
            data.symptomNames = symptomList.join(', ');
            if (radioValue === 'contrast') {
              if (isEmpty(data.firstDrugOrder)) {
                data.firstDrugOrder = {
                  drugName: null,
                  dosage: null,
                  instructionCode: null,
                };
              }
              if (isEmpty(data.secondDrugOrder)) {
                data.secondDrugOrder = {
                  drugName: null,
                  dosage: null,
                  instructionCode: null,
                };
              }
              if (isEmpty(data.thirdDrugOrder)) {
                data.thirdDrugOrder = {
                  drugName: null,
                  dosage: null,
                  instructionCode: null,
                };
              }
            }
          });
          this.set('gridItemsSource', result);
        }
        this.set('isShowLoader', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowLoader', false);
          this._showError(e);
        }

      }
    },
    getSearchParamsDate(date) {
      return new Date(date.getFullYear(), date.getMonth(), date.getDate()).toFormatString();
    },
    _getExportExcelData() {
      const gridItemsSource = this.get('gridItemsSource');
      const firstRow = [];
      const columns = this.get('gridColumns');
      columns.forEach(column => {
        if(isEmpty(column.columns)){
          firstRow.push(column.title);
        }else{
          column.columns.forEach(subColumn => {
            firstRow.push(column.title + '/' + subColumn.title);
          });
        }
      });
      if(isEmpty(gridItemsSource)){
        return;
      }
      const initArr = [firstRow];
      const resultArr = [];
      gridItemsSource.forEach(datas => {
        const dataArr = [];
        if (this.get('radioSelectedValue') === 'contrast') {
          const isSubside = datas.isSubside ? 'Y' : 'N';
          const isPreviousTreatment = datas.isPreviousTreatment ? 'Y' : 'N';
          const isDiabetesDrug = datas.isDiabetesDrug ? 'Y' : 'N';
          dataArr.push(
            datas.occurredDate,
            datas.examination.name,
            datas.contrastMedia.name,
            isPreviousTreatment,
            isSubside,
            datas.symptomNames,
            isDiabetesDrug,
            datas.diabetesContent,
            datas.remark,
            datas.firstDrugOrder.drugName,
            datas.firstDrugOrder.dosage,
            datas.firstDrugOrder.instructionCode,
            datas.secondDrugOrder.drugName,
            datas.secondDrugOrder.dosage,
            datas.secondDrugOrder.instructionCode,
            datas.thirdDrugOrder.drugName,
            datas.thirdDrugOrder.dosage,
            datas.thirdDrugOrder.instructionCode
          );
        } else {
          const isSedation = datas.isSedation ? 'Y' : 'N';
          const isClaustrophobia = datas.isClaustrophobia ? 'Y' : 'N';
          dataArr.push(
            datas.occurredDate,
            datas.examination.name,
            datas.examinationType.name,
            isSedation,
            isClaustrophobia,
            datas.remark,
            datas.drugOrder.drugName,
            datas.drugOrder.dosage,
            datas.drugOrder.instructionCode,
          );
        }
        if (isEmpty(this.get('patientId'))) {
          resultArr.push([
            datas.patientName,
            datas.patientCode,
            datas.age,
            datas.gender,
            ...dataArr
          ]);
        } else {
          resultArr.push([...dataArr]);
        }
      });
      const fileName = 'Side/Sedation';
      this.get('peApiService').getExportByArrayTypeExcel(initArr, resultArr, fileName);
    },

    /*     _getExportByArrayTypeExcel(initial, itemList) {
      const exportItemsWS = XLSX.utils.aoa_to_sheet(initial);
      XLSX.utils.sheet_add_aoa(exportItemsWS, itemList, {origin: "A2"});
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, exportItemsWS, 'sheet1');
      const fileName = new Date(this.get('co_CommonService').getNow());
      XLSX.writeFile(wb, `${fileName}.xlsx`);
    }, */
  });
