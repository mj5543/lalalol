import { isEmpty } from '@ember/utils';
import { A as emberA } from '@ember/array';
import EmberObject, { set } from '@ember/object';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import MessageMixin from '../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(
  MessageMixin,
  {
    layout,
    cancelReasonItems: null,
    cancelRequestList: null,
    isOpened: true,
    peApiService:service('patientexamination-service'),

    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId', 'patient-examination-cancellation-reason-entry');

      this.setStateProperties([
        'cancelReasonItems',
        'cancelRequestList',
        'defaultUrl',
        'isOpened',
      ]);

      if(this.hasState()===false) {
        this.set('cancelInfo', EmberObject.create());
        this.set('cancelReasonItems', emberA());
      }
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1000');
      this._getReasonItem();
    },

    actions :{
      onPopOpen(){
        this.set('cancelInfo', EmberObject.create());
        this.set('cancelInfo', this.get('cancelRequestList').get('firstObject'));
        set(this.get('cancelInfo'), 'reasonId', null);
        set(this.get('cancelInfo'), 'otherReason', "");
        set(this.get('cancelInfo'), 'disabled', true);
        set(this.get('cancelInfo'), 'reasonDescription', "");
        set(this.get('cancelInfo'), 'examinationCount', this.get('cancelRequestList').length);
      },

      onCancel(){
        this.set('isOpened', false);
        this.set('cancelInfo', EmberObject.create());
      },

      onSave(){
        if(isEmpty(this.get('cancelInfo.reasonId'))){
          //항목을 선택하세요.
          this.get('peApiService').onDisplayMessage('warning', this.getLanguageResource('9260', 'F' , '항목을 선택하세요.'), '', 'Ok', 'Ok', 0);
          return;
        }
        this.set('isOpened', false);
        this.get('setCancelInfoCB')(this.get('cancelInfo'));
      },

      onCancelReasonChanged(e){
        if(!isEmpty(e.selectedItems)){
          if(e.selectedItems.get('firstObject').businessCode === 'R5' || e.selectedItems.get('firstObject').businessCode === 'ETC'){
            set(this.get('cancelInfo'), 'disabled', false);
          }else{
            set(this.get('cancelInfo'), 'disabled', true);
            set(this.get('cancelInfo'), 'otherReason' , "");
          }
        }
      },
    },

    _getReasonItem(){
      try {
        this.get('peApiService').onGetBusinessCodeList('CancelReason', "").then(res => {
          const items = res.filterBy('isUsed', true);
          this.set('cancelReasonItems', items);
        });
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this._showError(e);
        }
      }
    }
  });