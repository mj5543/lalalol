import { isEmpty } from '@ember/utils';
import { A as emberA } from '@ember/array';
import layout from './template';
import CHIS from 'framework/chis-framework';
import { inject as service } from '@ember/service';
import MessageMixin from '../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(
  MessageMixin,
  {
    layout,
    isDisabled: false,
    paramEmployeeId: null,
    examinationTypeCode: null,
    severityTypeCode: null,
    isDeabetesDrugChecked: false,
    deabetesDrugTextValue: null,
    remark: null,
    symptomItemsSource: null,
    // examinationPlanId: null,
    loaderType: 'spinner',
    isShowLoader: false,
    loaderDimed: false,
    contrastResult: null,
    sedationResult: null,
    isSedationOpen: false,
    isDrugOpen: false,
    apiService: service('patientexamination-side-effects-service'),

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'patient-examination-sedation-management');
      this.setStateProperties([
        'globalCurrentUser',
        'globalPatient',
        'checkboxList',
        'claustrophobiaItemsSource',
        'sedationItemsSource',
        'isDisabled',
        'selectedDate',
        'drugByContrast',
        'drugBySeative',
        'sideExaminationTypes',
        'routeTypeCodes',
        'dosageUnits',
        'drugItemsSource',
        'dosageUnitItemsSource',
      ]);

      if (!this.hasState()) {
        this.set('model', {
          searchEmployeeId: null,
          drugByContrastId: null,
          drugsItem: null,
          instrunctionsCode: null,
          unitCode: null,
          dosageUnitsItem: null,
          isSedation: true,
          isClaustrophobia: true,
          dosage: null,
          drugCode: null,
          instructionRouteType: null,
          instructionCode: null
        });
        this.set('isDisabled', false);
        const displayDate = new Date(this.get('co_CommonService').getNow());
        this.set('selectedDate', displayDate);
        if(!isEmpty(this.get('co_CurrentUserService.user'))){
          this.set('globalCurrentUser', this.get('co_CurrentUserService.user'));
        }
        if(!isEmpty(this.get('co_PatientManagerService.selectedPatient'))){
          this.set('globalPatient', this.get('co_PatientManagerService.selectedPatient'));
        }
        this.set('resultSymptom', emberA());
        this.set('symptomItemsSource', emberA());
        this.set('claustrophobiaItemsSource', [
          {value: true, name: 'Y'},
          {value: false, name: 'N'}
        ]);
        this.set('sedationItemsSource', [
          {value: true, name: 'Y'},
          {value: false, name: 'N'}
        ]);
        this.set('numericOptions', {
          alias: 'numeric',
          digits: 3,
          autoUnmask: true,
          unmaskAsNumber: true,
        });
        this.set('fristDrugs', emberA());

      }
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1000');
    },
    actions: {
      onPopupOpenedAction() {
        this._init();
      },
      onPopupClosedAction() {
        this._dataReset();
      },

      onLinkedDrugClick(){
        this.set('isDrugOpen', true);
      },

      onSaveClick() {
        this._saveSedation();
      },
      onDeleteClick() {
        this._deleteSedation();
      },

      onDrugChanged(e){
        if(isEmpty(e.selectedItems.get('firstObject'))){
          this.set('model.dosage', null);
          this.set('model.unitCode', null);
          this.set('model.instructionRouteType', null);
          this.set('model.instructionCode', null);
          return;
        }
        const administrationRouteTypeCode = e.selectedItems.get('firstObject').administrationRouteTypeCode || '';
        const administrationRouteCode = e.selectedItems.get('firstObject').administrationRouteCode || '';
        const frequency = e.selectedItems.get('firstObject').frequency || '';
        const dosageUnitCode = e.selectedItems.get('firstObject').dosageUnitCode || '';

        if(isEmpty(this.get('model.dosage'))){
          this.set('model.dosage', frequency);
        }
        this.set('model.unitCode', this.get('model.originUnitCode') || dosageUnitCode);
        this.set('model.instructionRouteType', this.get('model.originInstructionRouteType') || this.get('routeTypeCodes').findBy('code', administrationRouteTypeCode));
        this.set('model.instructionCode', this.get('model.originInstructionCode') || administrationRouteCode);

        this.set('model.originUnitCode', null);
        this.set('model.originInstructionRouteType', null);
        this.set('model.originInstructionCode', null);
      }
    },

    async _init() {
      try {
        this.set('isShowLoader', true);
        await this._getBusinessCodeList();
        // await this._getDrugBySedative();
        await this._getSedation();
        setTimeout(() => {
          if (!isEmpty(this.get('contrastResult.confirmDoctor'))) {
            this.set('paramEmployeeId', this.get('contrastResult.confirmDoctor.id'));
          }
        }, 2000);
        this.set('isShowLoader', false);
      } catch(e) {
        this.set('isShowLoader', false);
        //console.log('_init Error::' , e);
      }
    },

    async _getBusinessCodeList() {
      const examinationTypes = await this.get('apiService').getBusinessCode('SideExaminationType');
      this.set('sideExaminationTypes', examinationTypes);
      const routeTypeCodes = await this.get('apiService').getDosage();
      this.set('routeTypeCodes', routeTypeCodes);
      // const drugInstrunctions = await this.get('apiService').getBusinessCode('DrugInstruction');
      // this.set('instrunctionItemsSource', drugInstrunctions);
      const dosageUnits = await this.get('apiService').getUnits();
      this.set('dosageUnitItemsSource', dosageUnits);
      await this._getDrugBySedative();
    },

    async _getSedation() {
      try {
        const result = await this.get('apiService').getSedation(this.get('examinationPlanId'));
        //console.log('_getSedation--', result);
        this.set('sedationResult', result);
        if (!isEmpty(result)) {
          if(isEmpty(result.examinationType)){
            this.set('examinationTypeCode', 'ETC');
          }else{
            this.set('examinationTypeCode', result.examinationType.displayCode);
          }
          if(!isEmpty(result.occurredDate)) {
            this.set('selectedDate', result.occurredDate);
          }
          this.set('model.isClaustrophobia', result.isClaustrophobia);
          this.set('model.isSedation', result.isSedation);
          if (!isEmpty(result.drugOrder)) {
            this.set('model.drugCode', result.drugOrder.drugCode);
            this.set('model.dosage', result.drugOrder.dosage);
            this.set('model.originUnitCode', result.drugOrder.unitCode);
            this.set('model.originInstructionRouteType', this.get('routeTypeCodes').findBy('code', result.drugOrder.instructionRouteTypeCode));
            this.set('model.originInstructionCode', result.drugOrder.instructionCode);
          }
          this.set('remark', result.remark);
        }
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this._showError(e);
        }
      }

    },

    async _getDrugBySedative() {
      const params = {
        examinationGroupCode: 'DR',
        relationTypeCode: 'Sedative'
      };
      const result = await this.get('apiService').getDrug(params);
      this.set('drugItemsSource', result);
    },

    async _saveSedation() {
      if(!this._checkInputField()) {
        return;
      }
      this.set('loaderType', 'progress');
      this.set('loaderDimed', true);
      this.set('isShowLoader', true);
      try {
        const params = this._getSaveParameters();
        await this.get('apiService').createSedation(params);
        const result = await this.get('apiService').getSedation(this.get('examinationPlanId'));
        if(!isEmpty(this.get('sedationCB'))) {
          this.get('sedationCB')(result);
        }
        this.get('apiService').onShowToast('save', this.getLanguageResource('8942', 'F', null, '저장되었습니다'), '');
        this.set('isShowLoader', false);
        this.set('isSedationOpen', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowLoader', false);
          this.set('isSedationOpen', false);
          this._showSaveError(e);
        }
      }
    },

    _checkInputField() {
      let flag = true;
      if (isEmpty(this.get('examinationTypeCode'))) {
        this.get('apiService').onDisplayMessage('warning', this.getLanguageResource('9775', 'F', null, '검사분류를 먼저 선택하세요.'), '', 'Ok', 'Ok', 0);
        flag = false;
      }
      if((!isEmpty(this.get('model.dosage')) || !isEmpty(this.get('model.unitCode')) ||
      !isEmpty(this.get('model.instrunctionsCode'))) && isEmpty(this.get('model.drugCode'))) {
        const msg = this.getLanguageResource('12602', 'F', '처치약을 선택해주세요.');
        this.get('apiService').onShowToast('error', msg, '');
        flag = false;
      }
      return flag;
    },

    _getSaveParameters() {
      const params = {
        patientId: this.get('sedationResult.patientId'),
        examinationPlanId: this.get('examinationPlanId'),
        examinationTypeCode: this.get('examinationTypeCode'),
        drugOrder: {
          drugId: this.get('model.drugsItem.drugId'),
          drugCode: this.get('model.drugsItem.drugCode'),
          drugName: this.get('model.drugsItem.drugName'),
          dosage: this.get('model.dosage'),
          unitCode: this.get('model.unitCode'),
          instructionRouteTypeCode: this.get('model.instructionRouteType.code'),
          instructionCode: this.get('model.instructionCode')
        },
        isSedation: this.get('model.isSedation'),
        isClaustrophobia: this.get('model.isClaustrophobia'),
        remark: this.get('remark'),
        occurredDate: this.get('selectedDate'),
        actionStaffId: this.get('globalCurrentUser.employeeId'),
        actionDatetime: new Date(this.get('co_CommonService').getNow())
      };
      return params;
    },

    async _deleteSedation() {
      if (isEmpty(this.get('sedationResult.sedationId'))) {
        return;
      }
      try {
        const params = {
          sedationId: this.get('sedationResult.sedationId'),
          actionStaffId: this.get('globalCurrentUser.employeeId'),
          actionDatetime: new Date(this.get('co_CommonService').getNow())
        };
        await this.get('apiService').deleteSedation(params);
        const result = await this.get('apiService').getSedation(this.get('examinationPlanId'));
        if(!isEmpty(this.get('sedationCB'))) {
          this.get('sedationCB')(result);
        }
        this.get('apiService').onShowToast('delete', '', this.getLanguageResource('8944', 'F', null, '삭제되었습니다'));
        this.set('isSedationOpen', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isSedationOpen', false);
          this.get('apiService').onShowToast('error', this.getLanguageResource('11755', 'F', null, '저장에 실패하였습니다'), '');
        }
      }
    },

    _dataReset() {
      this.set('loaderType', 'spinner');
      this.set('examinationTypeCode', null);
      this.set('severityTypeCode', null);
      this.set('selectedDate', new Date(this.get('co_CommonService').getNow()));
      this.set('model.isClaustrophobia', null);
      this.set('model.isSedation', null);
      this.set('model.drugsItem', null);
      this.set('model.drugCode', null);
      this.set('model.unitCode', null);
      this.set('model.instrunctionsCode', null);
      this.set('model.dosage', null);
      this.set('remark', null);
      this.set('sedationResult', null);
      this.set('symptomItemsSource', emberA());
    }
  });
