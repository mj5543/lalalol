import { isEmpty } from '@ember/utils';
import { A as emberA } from '@ember/array';
import { set } from '@ember/object';
import layout from './template';
import CHIS from 'framework/chis-framework';
import CatheterizationManagementMixin from '../../mixins/patient-examination-catheterization-management-mixin';
import MesaggeMixin from '../../mixins/patient-examination-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(
  CatheterizationManagementMixin,
  MesaggeMixin,
  {
    layout,
    isDisabled: true,
    angiographiesPartList: null,
    isShowLoader: false,
    gridSource: null,
    isPartGridSorting: false,
    isProcedureGridSorting: false,
    isSubProcedureGridSorting: false,
    isSubProcedureOpen: false,
    gridRemoveIds: null,
    isGridEditing: false,
    keyWord: null,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'patient-examination-catheterization-sub-procedure-management');
      this.setStateProperties([
        'model',
        'gridColumns',
        'gridItemsSource',
        'subProcedureName',
        'keyWord'
      ]);

      if (!this.hasState()) {
        this.set('model', {
          selectedAngiographyCode: null,
          selectedAngiographyPartId: null,
          selectedDepartmentId: null,
          selectedGridItem: null,
        });

        this.set('gridColumns', [
          { field: 'angiographySubProcedureName', title: this.getLanguageResource('10672', 'F', null, '시술상세명'), width: 120, readOnly: true, enableGotFocusAutoSelect: true},
        ]);
      }
      this.set('gridItemsSource', emberA());
      this.set('gridRemoveIds', emberA());
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1180');
    },
    actions: {
      onGridLoaded(e) {
        this.set('gridSource', e.source);
      },
      onGridSelectionChanged(e) {
        const selectedItem = e.source.selectedItems[0];
        set(this.get('gridSource').get('columns')[0], 'readOnly', true);
        if (!isEmpty(selectedItem)) {
          if(isEmpty(selectedItem.angiographySubProcedureId)) {
            set(this.get('gridSource').get('columns')[0], 'readOnly', false);
          }
        }

      },
      onPopupOpened() {
        this.set('isGridEditing', false);
        this._getAngiographiesSubProcedure();
      },
      onSearch() {
        this._getAngiographiesSubProcedure();
      },
      onPopupClosed() {
        if(this.get('isGridEditing')){
          this._setRefreshCallBack();
        }
      },
      onSelectClick() {
        this._itemsCheck();
      },
      onAddClick() {
        this.set('isMRegistPopupOpen', true);
      },
      onDelClick() {
        this._delSubProcedure();
      },

      onMPopupClosedAction() {
        this.set('isUpdatePopup', false);
        this.set('subProcedureName', null);
      },

      onMPopupSave(){
        this._saveSubProcedure();
      },
    },

    _itemsCheck() {
      this._setCallBack();
    },

    async _getAngiographiesSubProcedure() {
      this.set('gridItemsSource', emberA());
      try {
        this.set('isShowLoader', true);
        const param = {
          angiographyId: this.get('angiographyProcedureId'),
          subProcedureName: this.get('keyWord')
        };
        const result = await this.get('apiService').getAngiographiesSubProcedure(param);
        if(!isEmpty(result)) {
          this.set('gridItemsSource', result);
          this.set('isDisabled', false);
          this.set('isShowLoader', false);
        }else{
          this.set('isShowLoader', false);
        }
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowLoader', false);
          this._showError(e);
        }
      }
    },
    async _saveSubProcedure(){
      if(isEmpty(this.get('subProcedureName'))){
        return;
      }
      const message = this.getLanguageResource('8939', 'F', null, '저장 하시겠습니까?');
      const result = await this.showConfirm(message, '');
      if (result === 'Yes') {
        try {
          this.set('isMRegistPopupOpen', false);

          const {actionStaffId, actionDatetime} = this._getActionParams();
          const param = {
            actionStaffId,
            actionDatetime,
            displaySequence: 0,
            subProcedurNames: [this.get('subProcedureName')],
          };
          await this.get('apiService').createAngiographiesSubProcedure(param);
          await this._getAngiographiesSubProcedure();
        } catch(e) {
          this._showSaveError(e);
        }
      }
    },
    async _delSubProcedure(){
      if(isEmpty(this.get('model.selectedGridItem'))){
        return;
      }
      const selectedItem = this.get('model.selectedGridItem');

      const message = this.getLanguageResource('8929', 'F', null, '삭제 하시겠습니까?');
      const result = await this.showConfirm(message, '');
      if (result === 'Yes') {
        try {
          const {actionStaffId, actionDatetime} = this._getActionParams();
          const params = {
            actionStaffId,
            actionDatetime,
            angiographySubProcedureIds: [selectedItem.angiographySubProcedureId]
          };
          await this.get('apiService').deleteAngiographiesSubProcedure(params);
          this.set('isGridEditing', true);
          await this._getAngiographiesSubProcedure();
        } catch(e) {
          this._showSaveError(e);
        }
      }
    },
    _setCallBack() {
      if(!isEmpty(this.get('subProcedureCB'))) {
        this.get('subProcedureCB')(this.get('model.selectedGridItem'));
      }
      this.set('isSubProcedureOpen', false);
    },
    _setRefreshCallBack() {
      if(!isEmpty(this.get('refreshCB'))) {
        this.get('refreshCB')();
      }
      this.set('isSubProcedureOpen', false);
    }
  });
