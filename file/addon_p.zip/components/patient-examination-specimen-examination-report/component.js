import { isEmpty } from '@ember/utils';
import { A as emberA } from '@ember/array';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';

export default CHIS.FR.Core.ComponentBase.extend(
  {
    layout,
    isSpecimenReportOpen: true,
    specimenexaminationGridListItemsSource: null,
    specimenexaminationGridListColumns: null,
    isShowLoader: false,
    peApiService:service('patientexamination-service'),

    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId', 'patient-examination-specimen-examination-report');

      this.setStateProperties([
        'defaultUrl',
        'isSpecimenReportOpen',
        'specimenexaminationGridListItemsSource',
        'specimenexaminationGridListColumns',
        'isShowLoader'
      ]);

      if(this.hasState()===false) {

        this.set('specimenexaminationGridListColumns', [
          { field: 'checkInDateTime', title: this.getLanguageResource('10244', 'S', '접수일'), width: 150, type: 'date', dataFormat: 'g', align: 'center'},
          { field: 'examination.abbreviation', title: this.getLanguageResource('807', 'S', '검사항목')},
          { field: 'displayResult', title: this.getLanguageResource('890', 'S', '결과'), align: 'center', width:120}
        ]);

        this.set('specimenexaminationGridListItemsSource', emberA());
        this.set('model', {
          fromDate: this.get('co_CommonService').getNow().addYears(-1),
          toDate: this.get('co_CommonService').getNow()
        });
      }
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1300');
    },

    actions: {
      onPopOpen() {
        this._onGetResult();
      },

      onSearchList(){
        this._onGetResult();
      },
    },

    _onGetResult(){
      try {
        if(isEmpty(this.get('patientId'))){
          return;
        }
        this.set('specimenexaminationGridListItemsSource', []);
        const params = {
          patientId: this.get('patientId'),
          fromDate: this.get('model.fromDate'),
          toDate: this.get('model.toDate')
        };
        this.set('isShowLoader', true);
        this.get('peApiService').onGetSpecimenReport(params).then(res => {
          this.set('specimenexaminationGridListItemsSource', res);
          this.set('isShowLoader', false);
        });
      } catch(e) {
        //
      }
    }
  });
