import Mixin from '@ember/object/mixin';
import { inject as service } from '@ember/service';
import { isEmpty } from '@ember/utils';
import { observer } from '@ember/object';
import { once } from '@ember/runloop';

export default Mixin.create({
  model: null,
  globalCurrentUser: null,
  globalPatient: null,
  angiographyItemsSource: null,
  searchScheduleAngiographyItems: null,
  schedulePartItemsSource: null,
  loaderType: 'spinner',
  loaderDimed: false,
  isShowLoader: false,
  calendarSelectedDate: null,
  selectedDate: null,
  selectedPartId: null,
  isPartLoader: false,
  apiService: service('patientexamination-angiographies-service'),
  partIdChanged: observer('selectedPartId', function() {
    once(this, '_setSelectedPartId');
  }),


  onPropertyInit() {
    this._super(...arguments);

    this.setStateProperties([
      'model',
      'recordTypeCode',
      'recordNoteId',
      'isPrepared',
      'popupTarget',
      'isPretreatmentOpen',
      'angiographyList',
      'angiographiesPartList',
    ]);

    if(this.hasState()===false) {

      this.set('model', {
        selectedAngiographyId: null,
        selectedScheduleAngiographyId: null,
        selectedEntryAngiographyId: null,
        selectedAngiographyCode: null,
        selectedPartGridItem: null,
      });
      if(!isEmpty(this.get('co_CurrentUserService.user'))){
        this.set('globalCurrentUser', this.get('co_CurrentUserService.user'));
      }
      if(!isEmpty(this.get('co_PatientManagerService.selectedPatient'))){
        this.set('globalPatient', this.get('co_PatientManagerService.selectedPatient'));
      }
    }
  },
  actions: {
    onGridButtonClick(item) {
      this.set('recordTypeCode', item.previousTreatment.treatmentRecordTypeCode);
      this.set('recordNoteId', item.previousTreatment.treatmentRecordNoteId);
      this.set('isPrepared', item.previousTreatment.isPrepared);
      this.set('popupTarget', `#${event.target.id}`);
      this.set('isPretreatmentOpen', true);
    },
    onAngiographyCodeChanged(e) {
      const selectedItem = e.selectedItems[0];
      if (!isEmpty(selectedItem)) {
        this._getAngiographiesPartList(true);
      }
    },
  },
  getSchedulePartItems() {
    const partList = this.get('angiographiesPartList');
    const schedulePartItems = [{id: 'Total', name: this.getLanguageResource('6700', 'F', null, '전체')}];
    if(isEmpty(partList)){
      return;
    }
    partList.forEach(list => {
      schedulePartItems.push({id: list.angiographyPartId, name: list.angiographyPartName});
    });
    // this.set('model.selectedPartId', schedulePartItems[0].id);
    this.set('schedulePartItemsSource', schedulePartItems);
    // this.set('selectedPartId', 'Total');
    this._getAngiographyList();

  },

  async _getAngiographyCodeList() {
    const angiographyList = await this.get('apiService').getBusinessCode({classificationCode: 'Angiography'});
    if (!isEmpty(angiographyList)) {
      //this.set('model.selectedAngiographyCode', angiographyList[0].businessCode);
      this.set('angiographyList', angiographyList);
    }

  },
  async _getAngiographiesPartList(isUsed) {
    try {
      this.set('isDisabled', true);
      this.set('isPartLoader', true);
      const param = {
        angioGroupCode: this.get('model.selectedAngiographyCode'),
        isUsed: isUsed
      };
      const partResult = await this.get('apiService').getAngiographiesPart(param);
      if (!isEmpty(partResult)) {
        partResult.map(item => {
          item.type = 'Part';
        });
        this.set('angiographiesPartList', partResult);
        // this.set('model.selectedAngiographyPartId', partResult[0].angiographyPartId);
        const refreshTaget = this.get('refreshPartCode');
        if(!isEmpty(refreshTaget)) {
          const focusTargetItem = partResult.find(d => d.angiographyPartCode === refreshTaget);
          this.set('model.selectedPartGridItem', focusTargetItem);
        } else {
          this.set('model.selectedPartGridItem', partResult[0]);
        }
        this.set('isDisabled', false);
        this.set('refreshPartCode', null);
      }
    } catch(e) {
      //console.log('_getAngiographiesPartList Error:::', e);
    }
    this.set('isPartLoader', false);
  },

  _getAngiographyList(partId) {
    const partList = this.get('angiographiesPartList');
    const angiographyItems = [];
    let findedPartIdsitem = null;
    if(!isEmpty(partId) && partId !== 'Total') {
      findedPartIdsitem = partList.find(datas => datas.angiographyPartId === partId);
      findedPartIdsitem.angiography.forEach(items => {
        angiographyItems.push({
          id: items.angiographyProcedureId,
          displayCode: items.angiographyProcedureCode,
          name: items.angiographyProcedureName,
          subProcedure: items.subProcedure
        });
      });
    } else {
      partList.forEach(items => {
        items.angiography.forEach(item => {
          angiographyItems.push({
            id: item.angiographyProcedureId,
            displayCode: item.angiographyProcedureCode,
            name: item.angiographyProcedureName,
            subProcedure: item.subProcedure
          });
        });
      });

    }
    this.set('angiographyItemsSource', angiographyItems);
    this.set('searchScheduleAngiographyItems', angiographyItems);
    if (!isEmpty(findedPartIdsitem) && findedPartIdsitem.name === 'Other') {
      this.set('model.selectedEntryAngiographyId', angiographyItems[0].id);
      // this.set('model.selectedScheduleAngiographyId', angiographyItems[0].id);
    }

  },

  getSearchPramsDate() {
    return new Date(this.get('selectedDate').getFullYear(), this.get('selectedDate').getMonth(), this.get('selectedDate').getDate()).toFormatString();
  },

  getFormatDate(date) {
    return new Date(date.getFullYear(), date.getMonth(), date.getDate()).toFormatString();
  },

  getProcedureParams(id, status) {
    const returnParam = {
      angiographyPlanId: id,
      actionStaffId: this.get('globalCurrentUser.employeeId'),
      actionDatetime: new Date(this.get('co_CommonService').getNow())
    };
    if (status) {
      returnParam.newProcedureStatusCode = status;
    }
    return returnParam;

  },
  _getActionParams() {
    const actionStaffId = this.get('globalCurrentUser.employeeId');
    const actionDatetime = this.get('co_CommonService').getNow();
    return {actionStaffId, actionDatetime};
  },

  showConfirm(caption, messageBoxText){
    const options = {
      'caption': caption,
      'messageBoxButton': 'YesNo',
      'messageBoxImage': 'question',
      'messageBoxText': messageBoxText,
      'messageBoxFocus': 'No'
    };
    return messageBox.show(this, options);
  },

  _dateValidation() {
    const now = new Date(this.get('co_CommonService').getNow());
    const nowString = `${now.getFullYear()}${now.getMonth()}${now.getDate()}`;
    const compareDate = `${this.get('selectedDate').getFullYear()}${this.get('selectedDate').getMonth()}${this.get('selectedDate').getDate()}`;
    if (nowString !== compareDate) {
      return false;
    } else {
      return true;
    }
  },

  _getSelectedPartId(id) {
    let partId = null;
    if (id !== 'Total') {
      partId = id;
    }
    return partId;
  }

});