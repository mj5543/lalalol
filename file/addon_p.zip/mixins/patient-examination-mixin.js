import Mixin from '@ember/object/mixin';
import $ from 'jquery';
import { isEmpty } from '@ember/utils';
import { A as emberA } from '@ember/array';
import EmberObject from '@ember/object';
import Pacs from 'co-interface/mixins/pacs-mixin';
import { inject as service } from '@ember/service';

export default Mixin.create(Pacs,{

  peApiService:service('patientexamination-service'),
  pacsService: service('pacs-service'),

  onPropertyInit() {
    this._super(...arguments);

    this.setStateProperties([
      'model',
    ]);

    if(this.hasState()===false) {
      this.set('model', {
      });
    }
  },

  getPrinterName(printType, roomId, printSettings, labelPrinter){
    if(isEmpty(printSettings)){
      if(printType == 'Label'){
        if(isEmpty(labelPrinter)){
          return null;
        }else{
          return labelPrinter;
        }
      }else{
        return null;
      }
    }
    const printerList = printSettings;
    const roomPrinter = printerList.findBy('printSettingCode', roomId);
    if(isEmpty(roomPrinter)){
      if(printType == 'Label'){
        return labelPrinter;
      }else{
        return null;
      }
    }

    let printerName = null;
    if(printType == 'General'){
      printerName = roomPrinter.printerName;
    }

    if(printType == 'Label'){
      if(isEmpty(roomPrinter.labelPrinterName)){
        printerName = labelPrinter;
      }else{
        printerName = roomPrinter.labelPrinterName;
      }
    }
    return printerName;
  },

  getWorklistColumnHeader(sortingType){
    let header = [];

    /*동명이인 Merge되는 현상때문에 임의로 field엔 code로 하고 탬플릿에서 이름 표출*/
    if(sortingType == 'Patient'){
      header = [
        { field: 'isCheck', bodyTemplateName: 'checkbox', locked:true, width: 40, align: 'center', headerTemplateName: 'checkall' },
        { title: this.getLanguageResource('3813', 'S','속성'), align: 'center', width: 35, bodyTemplateName:'icon'},
        { field: 'patientCodeName', title: this.getLanguageResource('4184', 'S', '환자명'), merge:true, width: 90, bodyTemplateName:'patientName'},
        { field: 'patientCode', title: this.getLanguageResource('8451', 'S', '등록번호'), merge:true, width: 65, align: 'center', bodyTemplateName:'bolder'},
        { field: 'gender', title: this.getLanguageResource('3680', 'S', '성별'), merge:true, width: 35, align: 'center'},
        { field: 'age', title: this.getLanguageResource('1662', 'S', '나이'), merge:true, width: 35, align: 'center'},
        { field: 'birthDay', title: this.getLanguageResource('3480', 'S', '생년월일'), merge:true, width: 70, type: 'date', dataFormat: 'd', align: 'center'},
        { field: 'examinationName', title: this.getLanguageResource('16806', 'S', '검사'), width: 230, bodyTemplateName:'colfont', headerTemplateName:'headercolfont'},
        { field: 'insurance', title: this.getLanguageResource('8915', 'S', '본인부담'), align: 'center', width: 50,},
        { field: 'scheduleDate', title: this.getLanguageResource('5150', 'S', '예약일시'), width: 105, align: 'center', bodyTemplateName:'scheduling'},
        { field: 'paymentStatusName', title: this.getLanguageResource('3859', 'S', '수납'), width: 35, align: 'center', bodyTemplateName:'paid'},
        { field: 'isWrittenConsent', title: this.getLanguageResource('2028', 'S', '동의서'), width: 45, align: 'center', bodyTemplateName:'consent'},
        { field: 'issuedDate', title: this.getLanguageResource('5246', 'F', '오더일'), width: 70, align: 'center', bodyTemplateName:'issuedDate' },
        { field: 'issuedDoctorName', title: this.getLanguageResource('9686', 'S', '처방의'), width: 50, align: 'center'},
        { field: 'patientTypeName', title: this.getLanguageResource('8421', 'S', '환자구분'), width: 35, align: 'center'},
        { field: 'medicalDepartmentName', title: this.getLanguageResource('7111', 'S', '진료과'), width: 70, align: 'center', bodyTemplateName: 'tooltip'},
        { field: 'assignedLocationName', title: this.getLanguageResource('8827', 'S', '발행처'), width: 70, align: 'center', bodyTemplateName: 'tooltip'},
        { field: 'occupyingLocation', title: this.getLanguageResource('14751', 'S', '현위치'), width: 70, align: 'center', bodyTemplateName:'location'},
        { field: 'detail', title: this.getLanguageResource('3173', 'S', '비고'), width:35, align: 'center', readOnly: true, bodyTemplateName:'detail'},
        { field: 'examinationRoomName', title: this.getLanguageResource('743', 'S', '검사실'), width: 80, align: 'center', bodyTemplateName: 'tooltip'},
        { field: 'statusName', title: this.getLanguageResource('732', 'S'), width: 60, align: 'center', bodyTemplateName:'status'},
        { field: 'examinationConducts.accessNumber', title: 'AccessNumber', width: 110, align: 'center'}
      ];
    }else{
      header = [
        { field: 'isCheck', bodyTemplateName: 'checkbox', locked:true, width: 40, align: 'center', headerTemplateName: 'checkall' },
        { title: this.getLanguageResource('3813', 'S','속성'), align: 'center', width: 35, bodyTemplateName:'icon'},
        { field: 'isScheduling', title: this.getLanguageResource('1258', 'S', '구분'), width: 50, align: 'center', bodyTemplateName:'sche'},
        { field: 'scheduleDate', title: this.getLanguageResource('16804', 'S', '예약일시'), width: 105, align: 'center', bodyTemplateName:'scheduling'},
        { field: 'patientCodeName', title: this.getLanguageResource('4184', 'S', '환자명'), width: 90, bodyTemplateName:'patientName'},
        { field: 'patientCode', title: this.getLanguageResource('8451', 'S', '등록번호'), width: 65, align: 'center', bodyTemplateName:'bolder'},
        { field: 'gender', title: this.getLanguageResource('3680', 'S', '성별'), width: 35, align: 'center'},
        { field: 'age', title: this.getLanguageResource('1662', 'S', '나이'), width: 35, align: 'center'},
        { field: 'birthDay', title: this.getLanguageResource('3480', 'S', '생년월일'), width: 70, type: 'date', dataFormat: 'd', align: 'center'},
        { field: 'examinationName', title: this.getLanguageResource('16806', 'S', '검사'), width: 200, bodyTemplateName:'colfont', headerTemplateName:'headercolfont'},
        { field: 'insurance', title: this.getLanguageResource('8915', 'S', '본인부담'), align: 'center', width: 50,},
        { field: 'paymentStatusName', title: this.getLanguageResource('3859', 'S', '수납'), width: 35, align: 'center', bodyTemplateName:'paid'},
        { field: 'isWrittenConsent', title: this.getLanguageResource('2028', 'S', '동의서'), width: 45, align: 'center', bodyTemplateName:'consent'},
        { field: 'issuedDate', title: this.getLanguageResource('5246', 'F', '오더일'), width: 70, align: 'center', bodyTemplateName:'issuedDate' },
        { field: 'issuedDoctorName', title: this.getLanguageResource('9686', 'S', '처방의'), width: 50, align: 'center'},
        { field: 'patientTypeName', title: this.getLanguageResource('8421', 'S', '환자구분'), width: 35, align: 'center'},
        { field: 'medicalDepartmentName', title: this.getLanguageResource('7111', 'S', '진료과'), width: 70, align: 'center', bodyTemplateName: 'tooltip'},
        { field: 'assignedLocationName', title: this.getLanguageResource('8827', 'S', '발행처'), width: 70, align: 'center', bodyTemplateName: 'tooltip'},
        { field: 'occupyingLocation', title: this.getLanguageResource('14751', 'S', '현위치'), width: 70, align: 'center',bodyTemplateName:'location'},
        { field: 'detail', title: this.getLanguageResource('3173', 'S', '비고'), width:35, align: 'center', readOnly: true, bodyTemplateName:'detail'},
        { field: 'examinationRoomName', title: this.getLanguageResource('743', 'S', '검사실'), width: 80, align: 'center', bodyTemplateName: 'tooltip'},
        { field: 'statusName', title: this.getLanguageResource('732', 'S'), width: 60, align: 'center', bodyTemplateName:'status'},
        { field: 'examinationConducts.accessNumber', title: 'AccessNumber', width: 110, align: 'center'}
      ];
    }
    return header;
  },


  getConductWorklistColumnHeader(sortingType){
    let header = [];

    /*동명이인 Merge되는 현상때문에 임의로 field엔 code로 하고 탬플릿에서 이름 표출*/
    if(sortingType == 'Patient'){
      header = [
        { field: 'isCheck', bodyTemplateName: 'checkbox', locked:true, width: 40, align: 'center', headerTemplateName: 'checkall' },
        { title: this.getLanguageResource('3813', 'S','속성'), align: 'center', width: 35, bodyTemplateName:'icon'},
        { field: 'patientCodeName', title: this.getLanguageResource('4184', 'S', '환자명'), merge:true, width: 90, bodyTemplateName:'patientName'},
        { field: 'patientCode', title: this.getLanguageResource('8451', 'S', '등록번호'), merge:true, width: 65, align: 'center', bodyTemplateName:'bolder'},
        { field: 'gender', title: this.getLanguageResource('3680', 'S', '성별'), merge:true, width: 35, align: 'center'},
        { field: 'age', title: this.getLanguageResource('1662', 'S', '나이'), merge:true, width: 35, align: 'center'},
        { field: 'birthDay', title: this.getLanguageResource('3480', 'S', '생년월일'), merge:true, width: 70, type: 'date', dataFormat: 'd', align: 'center'},
        { field: 'examinationName', title: this.getLanguageResource('16806', 'S', '검사'), width: 160, bodyTemplateName:'colfont', headerTemplateName:'headercolfont'},
        { field: 'insurance', title: this.getLanguageResource('8915', 'S', '본인부담'), align: 'center', width: 50,},
        { field: 'paymentStatusName', title: this.getLanguageResource('3859', 'S', '수납'), width: 35, align: 'center', bodyTemplateName:'paid'},
        { field: 'acceptDate', title: this.getLanguageResource('6770', 'F', '접수일시'), width: 100, type: 'date', dataFormat: 'g', align: 'center' },
        { field: 'executeDatetime', title: this.getLanguageResource('738', 'S', '시행시간'), width: 40, type: 'date', dataFormat: 't', align: 'center' },
        { field: 'performDoctorName', title: this.getLanguageResource('9924', 'S', '시행의'), width: 50, align: 'center' },
        { field: 'issuedDate', title: this.getLanguageResource('5246', 'F', '오더일'), width: 70, type: 'date', dataFormat: 'd', align: 'center' },
        { field: 'issuedDoctorName', title: this.getLanguageResource('9686', 'S', '처방의'), width: 50, align: 'center'},
        { field: 'patientTypeName', title: this.getLanguageResource('8421', 'S', '환자구분'), width: 40, align: 'center'},
        { field: 'medicalDepartmentName', title: this.getLanguageResource('7111', 'S', '진료과'), width: 70, align: 'center', bodyTemplateName:'tooltip'},
        { field: 'assignedLocationName', title: this.getLanguageResource('8827', 'S', '발행처'), width: 70, align: 'center', bodyTemplateName:'tooltip'},
        { field: 'occupyingLocation', title: this.getLanguageResource('14751', 'S', '현위치'), width: 70, align: 'center', bodyTemplateName:'location'},
        { field: 'isInjection', title: this.getLanguageResource('11753', 'S', 'IV여부'), width: 40, align: 'center', bodyTemplateName:'injection'},
        { field: 'detail', title: this.getLanguageResource('3173', 'S', '비고'), width:35, align: 'center', readOnly: true, bodyTemplateName:'detail'},
        { field: 'examinationRoomName', title: this.getLanguageResource('743', 'S', '검사실'), width: 80, align: 'center', bodyTemplateName: 'tooltip'},
        { field: 'statusName', title: this.getLanguageResource('732', 'S'), width: 60, align: 'center', bodyTemplateName:'status'},
        { field: 'pacsConfirm', title: 'IMG', width:30, align: 'center'},
        { field: 'accessNumber', title: 'AccessNumber', width: 110, align: 'center'},
      ];
    }else{
      header = [
        { field: 'isCheck', bodyTemplateName: 'checkbox', locked:true, width: 40, align: 'center', headerTemplateName: 'checkall' },
        { title: this.getLanguageResource('3813', 'S','속성'), align: 'center', width: 35, bodyTemplateName:'icon'},
        { field: 'acceptDate', title: this.getLanguageResource('6770', 'F', '접수일시'), width: 100, type: 'date', dataFormat: 'g', align: 'center' },
        { field: 'patientCodeName', title: this.getLanguageResource('4184', 'S', '환자명'), width: 90, bodyTemplateName:'patientName'},
        { field: 'patientCode', title: this.getLanguageResource('8451', 'S', '등록번호'), width: 65, align: 'center', bodyTemplateName:'bolder'},
        { field: 'gender', title: this.getLanguageResource('3680', 'S', '성별'), width: 35, align: 'center'},
        { field: 'age', title: this.getLanguageResource('1662', 'S', '나이'), width: 35, align: 'center'},
        { field: 'birthDay', title: this.getLanguageResource('3480', 'S', '생년월일'), width: 70, type: 'date', dataFormat: 'd', align: 'center'},
        { field: 'examinationName', title: this.getLanguageResource('16806', 'S', '검사'), width: 160, bodyTemplateName:'colfont', headerTemplateName:'headercolfont'},
        { field: 'insurance', title: this.getLanguageResource('8915', 'S', '본인부담'), align: 'center', width: 50,},
        { field: 'executeDatetime', title: this.getLanguageResource('738', 'S', '시행시간'), width: 40, type: 'date', dataFormat: 't', align: 'center' },
        { field: 'performDoctorName', title: this.getLanguageResource('9924', 'S', '시행의'), width: 50, align: 'center' },
        { field: 'paymentStatusName', title: this.getLanguageResource('3859', 'S', '수납'), width: 35, align: 'center', bodyTemplateName:'paid'},
        { field: 'issuedDate', title: this.getLanguageResource('5246', 'F', '오더일'), width: 70, type: 'date', dataFormat: 'd', align: 'center' },
        { field: 'issuedDoctorName', title: this.getLanguageResource('9686', 'S', '처방의'), width: 50, align: 'center'},
        { field: 'patientTypeName', title: this.getLanguageResource('8421', 'S', '환자구분'), width: 40, align: 'center'},
        { field: 'medicalDepartmentName', title: this.getLanguageResource('7111', 'S', '진료과'), width: 70, align: 'center', bodyTemplateName:'tooltip'},
        { field: 'assignedLocationName', title: this.getLanguageResource('8827', 'S', '발행처'), width: 70, align: 'center', bodyTemplateName:'tooltip'},
        { field: 'occupyingLocation', title: this.getLanguageResource('14751', 'S', '현위치'), width: 70, align: 'center', bodyTemplateName:'location'},
        { field: 'isInjection', title: this.getLanguageResource('11753', 'S', 'IV여부'), width: 40, align: 'center', bodyTemplateName:'injection'},
        { field: 'detail', title: this.getLanguageResource('3173', 'S', '비고'), width:35, align: 'center', readOnly: true, bodyTemplateName:'detail'},
        { field: 'examinationRoomName', title: this.getLanguageResource('743', 'S', '검사실'), width: 80, align: 'center', bodyTemplateName: 'tooltip'},
        { field: 'statusName', title: this.getLanguageResource('732', 'S'), width: 60, align: 'center', bodyTemplateName:'status'},
        { field: 'pacsConfirm', title: 'IMG', width:30, align: 'center'},
        { field: 'accessNumber', title: 'AccessNumber', width: 110, align: 'center'},
      ];
    }
    return header;
  },

  pacsViewerOpen(item){
    if(isEmpty(item)){
      return;
    }

    if(isEmpty(item.Id) && (item.IsMandotoryUserInfo == 'Y')){
      const msg = this.getLanguageResource('13366', 'F', 'PACS 사용자정보가 없습니다. 직원정보에서 PACS사용정보를 등록해주세요.');
      this.get('peApiService').onDisplayMessage('warning', msg, '', 'Ok', 'Ok', 0);
      return;
    }

    const message = item;
    this.get('pacsService').sendPacket(this, message, item.LinkedTypeCode);
  },

  _copyItem(item) {
    if(item){
      this._copy(item);
      this.get('peApiService').onShowToast('message', this.getLanguageResource('11506', 'F', '복사 완료.'), '');
    } else {
      this.get('peApiService').onShowToast('warning', this.getLanguageResource('11507', 'F', '복사 실패'), '');
    }
  },

  _copy(item) {
    const temp = $("<textarea>");
    $("body").append(temp);
    temp.val(item).select();
    document.execCommand("copy");
    temp.remove();
  },

  _getOrderName(item){
    let result = '';
    if(!isEmpty(item.prescribedTypeId)){
      if(item.prescribedTypeId == '2'){
        result = this.getLanguageResource('4067', 'F', '수술전') + ')' + item.examinationName;
      }else if(item.prescribedTypeId == '3'){
        result = this.getLanguageResource('3928', 'F', '수술중') + ')' + item.examinationName;
      }else if(item.prescribedTypeId == '4'){
        result = this.getLanguageResource('4103', 'F', '수술후') + ')' + item.examinationName;
      }else if(item.prescribedTypeId == '6'){
        result = this.getLanguageResource('12757', 'F', '퇴원오더') + ')' + item.examinationName;
      }else{
        result = item.examinationName;
      }
    }else{
      result = item.examinationName;
    }
    return result;
  },

  _setIconDisplayTooltip(item){
    let res=[];
    if(item.isInfection){
      res.addObject(this.getLanguageResource('581', 'F', 'Infection Precaution'));
    }
    if(item.priorityTypeId == '4'){
      let msgEm = this.getLanguageResource('5725', 'F', '응급');
      if(res.length > 0){
        msgEm = '<br>'+ msgEm;
      }
      res.addObject(msgEm);
    }
    if( item.prescribedTypeId === "6"){
      let msgPrescribedType = this.getLanguageResource('11988', 'S', '퇴원오더');
      if(res.length > 0){
        msgPrescribedType = '<br>'+ msgPrescribedType;
      }
      res.addObject(msgPrescribedType);
    }
    if(item.isPortable){
      let msgIsPortable = this.getLanguageResource('12510', 'F', '이동검사');
      if(res.length > 0){
        msgIsPortable = '<br>'+ msgIsPortable;
      }
      res.addObject(msgIsPortable);
    }

    if(res.length > 1){
      res=res.join('').toString();
    }else{
      res=[];
    }
    return res;
  },

  showResponseMessage (err){
    if (err.status === 400 && !isEmpty(err.responseJSON)) {
      return messageBox.show(this, {
        'messageBoxImage' : 'warning',
        'caption': err.responseJSON.messages[0],
        'messageBoxText' : ''
      });
    }else if(err.status === 500){
      return this.get('toast').toastr({
        type: 'error',
        content: '',
        title: this.getLanguageResource('8947'),
        option: {
          closeButton: false,
          timeOut: 4000,
          positionClass: 'toast-bottom-center'
        }
      });
    }else{
      return this.get('toast').toastr({
        type: 'error',
        content: '',
        title: this.getLanguageResource('8947'),
        option: {
          closeButton: false,
          timeOut: 4000,
          positionClass: 'toast-bottom-center'
        }
      });
    }
  },

  onNameLabelPrint(item, labelPrinter){
    if(isEmpty(item)){
      return;
    }

    const printerName = labelPrinter;
    const examinationInfo= emberA();
    const printContent = emberA({
      parameterField: {},
      dataField : emberA(),
    });

    item.forEach(e => {
      examinationInfo.pushObject({
        "patientName" : e.patientName + ' (' + e.gender + '/' + e.age + ')',
        "gender" : e.gender,
        "birthday" : this.get('fr_I18nService').formatDate(e.birthDay, 'd'),
        "patientDisplayID": e.patientCode,
        "examinationName" : e.examinationName,
        "dateType" : this.getLanguageResource('789', 'S'),
        "date" : this.get('fr_I18nService').formatDate(e.printDate, 'd'),
        "time" : this.get('fr_I18nService').formatDate(e.printDate, 't'),
        "age" : e.age,
        "hospitalName": e.hospitalName
      });
    });

    printContent.dataField = { "imageMaterialLabel": examinationInfo };
    this.set('printPopup', false);
    this.set('print', EmberObject.create({printPopup: false,
      printConfig: {
        'printType': 1,
        'printName': 'ImageMaterialLabel',
        'commonInformation' : false,
        'printerName': printerName
      },
      printContent: printContent
    }));
    //'copies': nameLabelPage
  },
});