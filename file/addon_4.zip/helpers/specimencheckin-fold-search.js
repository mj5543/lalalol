import { helper } from '@ember/component/helper';

export function specimencheckinFoldSearch([type]) {
  return type ? 'close' : '';
}

export default helper(specimencheckinFoldSearch);
