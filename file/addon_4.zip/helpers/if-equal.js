import { helper } from '@ember/component/helper';

export function ifEqual(params) {
  if(params[0] === params[1]){
    return true;
  }else{
    return false;
  }
}

export default helper(ifEqual);
