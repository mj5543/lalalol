import { helper } from '@ember/component/helper';
import { isEmpty } from '@ember/utils';

export function dateSlice(param) {
  if(!isEmpty(param)){
    return param.toString().slice(0,10);
  }else{
    return '';
  }
}

export default helper(dateSlice);
