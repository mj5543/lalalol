import { isEmpty } from '@ember/utils';
import { hash } from 'rsvp';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
// import { getOwner } from '@ember/application';
// import { computed} from '@ember/object';
import { next } from '@ember/runloop';
import specimencheckinMessageMixin from 'specimencheckin-module/mixins/specimen-check-in-message-mixin';
export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, specimencheckinMessageMixin,
  {
    specimenCheckinService: service('specimen-check-in-service'),
    layout,
    // 2. Property Area

    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-check-in-inappropriate-registration');
      //Set Stateful properties
      this.setStateProperties([
        'defaultUrl',
        'reasonsItemsSource',
        'reasonsSelectedItem'
      ]);
      if (this.hasState() === false) {
      //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimencheckin')
        + `specimen-checkin/v0/`);
        this.set('currentUser', this.get('co_CurrentUserService.user'));
      }
    //Initialize Stateless properties
    },

    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1360');
      if (this.hasState() === false) {
        hash({
          reasonsItemsSource: this.getList(this.get('defaultUrl') + 'business-codes/search', {classificationCode: 'InappropriateSpecimenReason'}, null)
        }).then(function(result){
          this.set('reasonsItemsSource', result.reasonsItemsSource);
        }.bind(this)).catch(function(e){
          this._catchError(e);
        }.bind(this));
      }
    },
    // 4. Actions Area
    actions: {
      onOpened(){
        if(this._validationCheck()==false){
          return;
        }
        this._initialize();
      },

      //부적합검체등록 사유 선택
      onReasonsChanged(){
        if(this.get('reasonsSelectedItem.code') == '9999'){
          this.set('inappropriateReasonsInputDisabled', false);
        }else{
          this.set('inappropriateReasonsInputDisabled', true);
          this.set('textareaValue', null);
        }
      },

      onSelectEmployee(item){
        //확인자 선택 콜백
        if(isEmpty(item)){
          return;
        }
        this.set('isEmployeeListPopupOpen', false);
        this.set('verifiedStaffId', item.employeeId);
      },

      //부적합검체등록 modal OK 클릭
      onInappropriateRegistrationOKAction(){
        //삭제 후 등록시
        if(!isEmpty(this.get('inappropriateInfo'))){
          this.get('specimenCheckinService').deleteInappropriate(this.get('inappropriateInfo.firstObject.inappropriateSpecimenId'));
        }
        next(this,function(){
          const specimen= this.get('specimen');
          const currentUser= this.get('currentUser');
          const params={
            specimenId: specimen.specimenId,
            registrationDatetime: this.get('co_CommonService').getNow(),
            registrationStaffId: currentUser.employeeId,
            verifiedStaffId: this.get('verifiedStaffId'),
            reasonId: this.get('reasonsSelectedItem.code'),
            reasonContent: isEmpty(this.get('textareaValue'))? this.get('reasonsSelectedItem.name') : this.get('textareaValue')
          };
          this.create(this.get('defaultUrl') + 'specimen-checkins/inappropriate-specimens', null, params).then(function(){
            this.get('specimenCheckinService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
            this.set('isModalOpen', false);
            this.set('inappropriateInfo', null);
          }.bind(this)).catch(function(e){
            this._catchError(e);
          }.bind(this));
        }.bind(this));
      },
    },
    // 5. Private methods Area
    _initialize(){
      const reasonsItemsSource= this.get('reasonsItemsSource');
      this.set('reasonsSelectedItem', reasonsItemsSource.get('firstObject'));
      this.set('inappropriateReasonsDisabled', false);
      this.set('inappropriateReasonsInputDisabled', true);
      this.set('textareaValue', null);
    },

    _validationCheck(){
      if(isEmpty(this.get('specimenNumber')) && isEmpty(this.get('specimen.specimenId')) ){
        this.get('specimenCheckinService')._showMessage(this.getLanguageResource('10105', 'F', '검체번호를 확인하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
        return false;
      }
    },

    _catchError(e){
      this.showResponseMessage(e);
    }
  });