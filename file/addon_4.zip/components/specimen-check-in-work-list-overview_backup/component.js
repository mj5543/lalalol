/* eslint-disable max-lines */
import { copy } from '@ember/object/internals';
import { next, cancel, later } from '@ember/runloop';
import $ from 'jquery';
import { hash } from 'rsvp';
import { isEmpty } from '@ember/utils';
import EmberObject, { computed, set } from '@ember/object';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import specimencheckinMessageMixin from 'specimencheckin-module/mixins/specimen-check-in-message-mixin';
export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, specimencheckinMessageMixin,
  {
    //참고!!!기존 개발자 코드 파일임
    layout,
    specimenCheckinService: service('specimen-check-in-service'),
    defaultUrl: null,
    isAutoReset:null,
    autoResetTimer:null,
    findSettingPopupInfo:null,
    examinationTagNameItemsSource:null,
    examinationTagNameSelectedItem:null,
    examinationFromDate:null,
    examinationToDate:null,
    examinationTagNameItemsSourceCopy: null,
    reLoad: computed('reLoadCB', function() {
      if(!isEmpty(this.get('reLoadCB'))){
        this._setOverViewGetItems('autoReset');
      }
    }),
    queryOption: null,
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId', 'specimen-check-in-work-list-overview');
      this.set('previewPopupInfo', EmberObject.create());
      this.set('previewPopupInfo.isOpen', false);
      this.set('isPopover', false);
      this.setStateProperties([
        'defaultUrl',
        'isAutoReset',
        'autoResetTimer',
        'examinationTagNameItemsSource',
        'examinationTagNameSelectedItem',
        'examinationFromDate',
        'examinationToDate',
        'isAuto',
        'examinationTagNameItemsSourceCopy',
        'queryOption'
      ]);
      if (this.hasState() === false) {
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimencheckin') + `specimen-checkin/v0/`);
        this.set('isAutoReset', true);
        this.set('findSettingPopupInfo', {});
        this.set('findSettingPopupInfo.isOpen', false);
        const today= this.get('co_CommonService').getNow();
        this.set('examinationFromDate',today);
        this.set('examinationToDate',today);
      }
    },

    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'wp100');

      if (this.hasState() === false) {
        hash({
          examinationTagNameItemsSource: this.getList(this.get('defaultUrl') + 'worklist-configurations/search', {staffId: this.get('co_CurrentUserService.user.employeeId')}, null),
          settingInfo: this.get('co_PersonalizationService').getSettingInfo(`specimen-check-in-work-list-overview`),
        }).then(function(result){
          this.set('examinationTagNameItemsSource', result.examinationTagNameItemsSource);
          const examinationTagNameItemsSource= this.get('examinationTagNameItemsSource');
          if(!isEmpty(examinationTagNameItemsSource)){
            this.set('examinationTagNameItemsSourceCopy', $.extend(true, [], examinationTagNameItemsSource.map(function(e){
              return $.extend(true, {}, e);
            })));
          }else{
            this.set('examinationTagNameItemsSourceCopy', null);
          }
          const filterdExaminationTagList=[];
          if(!isEmpty(result.examinationTagNameItemsSource)){
            result.examinationTagNameItemsSource.forEach(e=>{
              filterdExaminationTagList.addObject(this._filterExaminationTagList(
                e.workListFindConfigurationId, e.property.classifications, e.property.unitWorks, e.property.observationExaminations));
            });
          }
          this.set('filterdExaminationTagList', filterdExaminationTagList);

          const settingInfo = result.settingInfo;
          if(isEmpty(settingInfo.settingValue)){
            if(isEmpty(examinationTagNameItemsSource)){
              //최초 로그인
              this._setOverViewGetItems();
            }else{
              this.set('examinationTagNameSelectedItem', examinationTagNameItemsSource.get('firstObject') );
              next(this, function(){
                this._setExaminationTagList();
                this._setOverViewGetItems();
              }.bind(this));
            }
          }else{
            //개인화설정값 있는경우
            const data = JSON.parse(settingInfo.settingValue);
            //conditionData [examinationTagList, examinationTagNameSelectedItem, queryOption ]
            if(!isEmpty(data.conditionData)){
              if(isEmpty(data.conditionData.get('firstObject')) && isEmpty(data.conditionData[1])){
                //저장된 set 없거나, examinationTagNameSelectedItem, examinationTagList 없는경우
                this.set('examinationTagNameSelectedItem', examinationTagNameItemsSource.get('firstObject') );
                this._setExaminationTagList();
                this._setOverViewGetItems();
              }else if(isEmpty(data.conditionData[1])){
                //set 선택값 없는경우 examinationTagList로 조회
                this.set('examinationTagNameSelectedItem', null);
                this.set('examinationTagList',data.conditionData.get('firstObject'));
                this._setTagGroupList(this.get('examinationTagList'));
                if(!isEmpty(data.conditionData[2])){
                  this.set('queryOption', data.conditionData[2]);
                  this._setOverViewGetItems(data.conditionData[2]);
                }else{
                  this._setOverViewGetItems();
                }
              }else if(!isEmpty(data.conditionData[1])){
                //set 선택값 있는경우 examinationTagNameSelectedItem 값으로 조회
                // this.set('examinationTagList',data.conditionData.get('firstObject'));
                this.set('examinationTagNameSelectedItem', data.conditionData[1] );
                this._setExaminationTagList();
                this._setTagGroupList(this.get('examinationTagList'));
                // this.set('examinationTagNameSelectedItem', isEmpty(data.conditionData[1])? examinationTagNameItemsSource.get('firstObject') : data.conditionData[1] );
                if(!isEmpty(data.conditionData[2])){
                  this.set('queryOption', data.conditionData[2]);
                  this._setOverViewGetItems(data.conditionData[2]);
                }else{
                  this._setOverViewGetItems();
                }
              }
            }else{
              this._setOverViewGetItems();
            }
          }
          this._setAutoResetOverView();
          // }).catch(function(error) {
          //   this._catchError(error);
          // }.bind(this));
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      }
    },

    didInsertElement() {
      this._super(...arguments);
    },

    willDestroyElement() {
      this._super(...arguments);
      this.set('isAutoReset', false);
      cancel(this.get('autoResetTimer'));
    },

    actions: {
      onOpenConditionPreview(isOpen) {
        if(isEmpty(this.get('tagGroupList'))){
          return;
        }
        if(this.get('tagGroupList').length >0){
          this.set('previewPopupInfo.isOpen', isOpen);
        }else{
          this.set('previewPopupInfo.isOpen', false);
        }
      },

      onReset() {
        this.set('examinationTagList', []);
        this.set('tagGroupList', []);
        this.set('previewPopupInfo.isOpen', false);
        this._setOverViewGetItems();
        this.set('examinationTagNameSelectedItem', null);
      },

      //자동-레프레시 토클버튼 클릭 이벤트
      onAutoResetChangeClick(){
        this._setAutoResetOverView();
      },
      //레프레시 버튼 클릭 이벤트
      onResetOverviewOnClick(){
        this._setOverViewGetItems();
      },
      onExamDateChangedAction(){
        this._setOverViewGetItems();
      },
      //콤보박스 변경 이벤트
      onExaminationTagNameChanged(e){
        // 2019-04-24 디자인 수정
        this.set('examinationTagNameSelectedItem', e);
        if(!isEmpty(e)){
          this.set('examinationTagList', null);
          this._setExaminationTagList();
        }
        this._setOverViewGetItems();
        this.set('isExamSetOpen', false);
      },

      onDeleteConditionGroup(deleteGroupItem) {
        const examinationTagList= this.get('examinationTagList');
        const tagGroupList= this.get('tagGroupList');
        const obj= examinationTagList.findBy('items', deleteGroupItem.items);
        examinationTagList.removeObject(obj);
        let newTagList = copy(examinationTagList);
        try {
          tagGroupList.removeObject(tagGroupList.findBy('type', deleteGroupItem.type));
          this.set('tagGroupList', tagGroupList);
          if(!isEmpty(deleteGroupItem.items)){
            deleteGroupItem.items.forEach(i=>{
              const item= examinationTagList.findBy('id', i.id);
              if(!isEmpty(item)){
                newTagList.removeObject(item);
              }
            });
          }else{
            newTagList=examinationTagList;
          }
          this.set('examinationTagList', newTagList);
        } catch (e) {
          //
        }
        this._setOverViewGetItems();
        this.set('examinationTagNameSelectedItem', null);
        if(this.get('tagGroupList').length <1){
          this.set('previewPopupInfo.isOpen', false);
        }
      },

      onDeleteCondition(index, subIndex, item) {
        const examinationTagList = $.extend(true, [], this.get('examinationTagList').map(function(e){
          return $.extend(true, {}, e);
        }));
        const newTagList = [];
        try {
          examinationTagList[index].items.removeObject(examinationTagList[index].items[subIndex]);
          examinationTagList.forEach(function(element) {
            if(!isEmpty(element.items)){
              //제거대상 아닌 경우
              newTagList.push(element);
              return;
            }
            if(!isEmpty(element.id) && (element.id !== item.id)){
              newTagList.push({
                id:element.id,
                name:element.name,
                abbreviation:element.abbreviation,
                type:element.type
              });
            }
          });
          this.set('examinationTagList', newTagList);
          this._setTagGroupList(newTagList);
        } catch (e) {
          //
        }
        this._setOverViewGetItems();
        this.set('examinationTagNameSelectedItem', null);
      },
      onSearchPopupOnClick(e){
        this.set('findSettingPopupInfo.isOpen', !this.get('findSettingPopupInfo.isOpen'));
        this.set('findSettingPopupInfo.targetId', e.originalEvent.currentTarget);
        this.set('examinationTagListCopy', copy(this.get('examinationTagList')));
      },

      //팝업 콜백 이벤트
      onFindSettingCallBack(sResult){
        this.set('examinationTagNameSelectedItem', null);
        this._setExaminationTagList(sResult.tagList);
        this.set('tagGroupList', sResult.tagGroupList);
        if(!isEmpty(sResult.workListFindConfigurationId)){
          //저장된 세트를 선택한 경우
          this._setExaminationComboBox(sResult.workListFindConfigurationId, sResult.tagList);
          // this._setTagGroupList(sResult.tagList);
        }else{
          if(this.get('examSetRefresh')){
            this._setExaminationComboBox(sResult.workListFindConfigurationId, null);
          }
          this.set('examinationTagNameSelectedItem', null);
          this.set('examinationTagList', sResult.tagList);
          this._setTagGroupList(sResult.tagList);
          this._setOverViewGetItems();
        }
      },

      onFindSettingClosed(savedSettingSelectedItem, tagList){
        //셋팅 팝업 닫은 후 콜백 - 저장or 수정건이 있었으면 재조회
        if(this.get('examSetRefresh')){
          if(!isEmpty(savedSettingSelectedItem) && !isEmpty(this.get('examinationTagNameSelectedItem'))){
            const currentWorkListFindConfigurationId= this.get('examinationTagNameSelectedItem.workListFindConfigurationId');
            if(savedSettingSelectedItem.workListFindConfigurationId == currentWorkListFindConfigurationId){
              this._setExaminationComboBox(currentWorkListFindConfigurationId, tagList);
              return;
            }
            this._setExaminationComboBox(currentWorkListFindConfigurationId, null);
          }
          this.set('examSetRefresh', false);
        }
      },

      onOverViewListItemClick(item){
        if(!isEmpty(this.get('selectedFirstTabCB'))){
          this.get('selectedFirstTabCB')();
        }
        if(!isEmpty(this.get('overViewList'))){
          this.get('overViewList').forEach(element => {
            set(element, '2depthStyle_stat', '');
            set(element, '2depthStyle_general', '');
          });
        }
        this._setOverView(item, 'A');
      },
      onDetailOverViewListItemClick(item, option){
        if(!isEmpty(this.get('selectedFirstTabCB'))){
          this.get('selectedFirstTabCB')();
        }
        if(!isEmpty(this.get('overViewList'))){
          this.get('overViewList').forEach(element => {
            set(element, '2depthStyle_stat', '');
            set(element, '2depthStyle_general', '');
          });
        }
        if(option == 'D'){
          //응급/당일
          set(item, '2depthStyle_stat', 'on');
        }else{
          set(item, '2depthStyle_general', 'on');
        }
        this._setOverView(item, option);
      },
    },
    // 5. Private methods Area
    _setOverView(item, option){
      if(isEmpty(item)){
        return;
      }
      if(item.progressStatusCode == 'Checkin'){
        this.set('queryOption', 'Checkin');
      }else if(item.progressStatusCode == 'Execution'){
        this.set('queryOption', 'Execution');
      }else if(item.progressStatusCode == 'Preliminary'){
        this.set('queryOption', 'Preliminary');
      }else if(item.progressStatusCode == 'Final'){
        this.set('queryOption', 'Final');
      }
      if(!isEmpty(this.get('overViewList'))){
        this.get('overViewList').forEach(element => {
          set(element, 'style', 'wl-db-row');
        });
      }
      //응급당일, 일반 클릭에 따른 그리드 조회
      if(!isEmpty(option)){
        this.set('progressTypeCode', option);
      }
      let isNull = false;
      if((item.generalCount==0 && option=='G') ||(item.statTodayCount==0 && (option == 'D'))){
        isNull= true;
      }

      if(item.progressStatusCode ==='Checkin'){
        this._callBackViewSettingCB('2', isNull);
        set(item, 'style', 'wl-db-row on');
      }else if(item.progressStatusCode ==='Preliminary'){
        this._callBackViewSettingCB('3', isNull);
        set(item, 'style', 'wl-db-row on');
      }else if(item.progressStatusCode ==='Execution'){
        this._callBackViewSettingCB('5', isNull);
        set(item, 'style', 'wl-db-row on');
      }else if(item.progressStatusCode ==='Final'){
        this._callBackViewSettingCB('4', isNull);
        set(item, 'style', 'wl-db-row on');
      }
    },

    _setExaminationComboBox(workListFindConfigurationId, tagList){
      this.getList(this.get('defaultUrl') + 'worklist-configurations/search', {staffId: this.get('co_CurrentUserService.user.employeeId')}, null).then(function(res){
        this.set('examinationTagNameItemsSource', res);
        if(!isEmpty(res)){
          const filterdExaminationTagList=[];
          res.forEach(e=>{
            if(e.workListFindConfigurationId===workListFindConfigurationId){
              this.set('examinationTagNameSelectedItem', e);
            }
            //검사분류, 작업단위, 검사항목별로 나눠서 저장해둠
            filterdExaminationTagList.addObject(this._filterExaminationTagList(
              e.workListFindConfigurationId, e.property.classifications, e.property.unitWorks, e.property.observationExaminations));
          });
          this.set('filterdExaminationTagList', filterdExaminationTagList);
          if(!isEmpty(tagList)){
            //setting 팝업 닫으면서 재조회할경우
            this.set('examinationTagList', tagList);
            this._setTagGroupList(tagList);
            this._setOverViewGetItems(null);
          }
        }
      }.bind(this)).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    _setExaminationTagList(getTagList){
      let examinationTagNameSelectedItem = this.get('examinationTagNameSelectedItem');
      const examinationTagList = this.get('examinationTagList');

      if(!isEmpty(examinationTagNameSelectedItem) && isEmpty(examinationTagList)){
        //최초
        this.set('examinationTagList', this._filterExaminationTagList(
          examinationTagNameSelectedItem.workListFindConfigurationId,
          examinationTagNameSelectedItem.property.classifications,
          examinationTagNameSelectedItem.property.unitWorks,
          examinationTagNameSelectedItem.property.observationExaminations
        ));
        this._setTagGroupList(this.get('examinationTagList'));
      }else if(isEmpty(examinationTagNameSelectedItem) && !isEmpty(examinationTagList)){
        //콜백받은경우
        this.set('examinationTagList', getTagList);
        this._setTagGroupList(getTagList);
      }else if (!isEmpty(examinationTagNameSelectedItem)){
        //다시선택
        const examinationTagNameItemsSourceCopy= this.get('examinationTagNameItemsSourceCopy');
        examinationTagNameSelectedItem= examinationTagNameItemsSourceCopy.findBy('workListFindConfigurationId', examinationTagNameSelectedItem.workListFindConfigurationId);
        this.set('examinationTagList', this._filterExaminationTagList(
          examinationTagNameSelectedItem.workListFindConfigurationId,
          examinationTagNameSelectedItem.property.classifications,
          examinationTagNameSelectedItem.property.unitWorks,
          examinationTagNameSelectedItem.property.observationExaminations
        ));
        this._setTagGroupList(this.get('examinationTagList'));
      }else if (!isEmpty(getTagList)){
        this.set('examinationTagList', getTagList);
      }
    },

    _setTagGroupList(tagList) {
      const tagGroupList= [];
      if(!isEmpty(tagList)){
        tagList.forEach(list => {
          if(isEmpty(list.items)){
            return;
          }
          if (list.items.length > 0) {
            let tempName = isEmpty(list.items[0].abbreviation)? list.items[0].name: list.items[0].abbreviation;
            if (list.items.length > 1) {
              tempName += '(+' + (list.items.length - 1) + ')';
            }
            tagGroupList.pushObject({ type: list.type, name: tempName, items: list.items });
          }
        });
      }
      this.set('tagGroupList', tagGroupList);
      if (tagGroupList.length == 0) {
        this.set('isPopover', false);
      } else {
        this.set('isPopover', true);
      }
    },
    _filterExaminationTagList(workListFindConfigurationId, examinationCategoryTagItems,examinationUnitTagItems,examinationTagItems){
      const filterdExaminationTagList= [];
      filterdExaminationTagList.workListFindConfigurationId=workListFindConfigurationId;
      if(!isEmpty(examinationCategoryTagItems)){
        filterdExaminationTagList.push({type: 'category', items: examinationCategoryTagItems });
      }
      if(!isEmpty(examinationUnitTagItems)){
        filterdExaminationTagList.push({type: 'unit', items: examinationUnitTagItems });
      }
      if(!isEmpty(examinationTagItems)){
        filterdExaminationTagList.push({type: 'exam', items: examinationTagItems});
      }

      return filterdExaminationTagList;
    },
    _setAutoResetOverView(){
      const isAuto = this.get('isAutoReset');
      const self = this;
      if(isAuto){
        this.set('autoResetTimer', later(function(){
          if(!isEmpty(self.get('tagGroupList'))){
            self._setOverViewGetItems('autoReset');
            self._setAutoResetOverView();
          }
        }, 60000));
      }else{
        cancel(this.get('autoResetTimer'));
      }
    },
    _setOverViewGetItems(mode) {
      const examinationTagList= this.get('examinationTagList');
      const examinationFromDate= this.get('examinationFromDate');
      const examinationToDate= this.get('examinationToDate');
      if(isEmpty(examinationFromDate) || isEmpty(examinationToDate)){
        this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9290', 'F', '날짜를 확인하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
        return;
      }
      const params = {
        checkInFromDate: new Date(examinationFromDate.getFullYear(), examinationFromDate.getMonth(), examinationFromDate.getDate(), 0, 0, 0),
        checkInToDate: new Date(examinationToDate.getFullYear(), examinationToDate.getMonth(), examinationToDate.getDate(), 0, 0, 0),
      };
      if(!isEmpty(examinationTagList)){
        examinationTagList.forEach(e=>{
          if(e.type=='category'){
            params.classificationIds= e.items.mapBy('id');
          }else if(e.type=='unit'){
            params.unitWorkIds= e.items.mapBy('id');
          }else if(e.type=='exam'){
            params.examinationIds= e.items.mapBy('id');
          }
        });
      }
      params.classificationIds= isEmpty(params.classificationIds)? params.classificationIds : params.classificationIds.filter(function(item){
        return item;
      });
      params.unitWorkIds= isEmpty(params.unitWorkIds)? params.unitWorkIds : params.unitWorkIds.filter(function(item){
        return item;
      });
      params.examinationIds= isEmpty(params.examinationIds)? params.examinationIds : params.examinationIds.filter(function(item){
        return item;
      });
      const overViewValueList = [];
      let temp = {};
      hash({
        overViewListItemsSource: this.getList(this.get('defaultUrl') + 'specimen-examination-worklists/overview', null, params),
      }).then(function(result){
        // if(isEmpty(result.overViewListItemsSource)){
        //   // return;
        // }
        result.overViewListItemsSource.forEach(item => {
          if(item.progressStatusCode !== temp.progressStatusCode){
            if(!isEmpty(temp.progressStatusCode)){
              overViewValueList.push(temp);
            }
            temp = {
              progressStatusCode: item.progressStatusCode,
              statusName: item.progressStatusName,
              generalCount: item.progressTypeCode === 'G' ? item.specimenCount : 0,
              statTodayCount: 0,
              totalCount: item.specimenCount,
              style: 'wl-db-row',
              progressTypeCode: item.progressTypeCode
            };
            temp.statTodayCount= item.progressTypeCode === 'D' || item.progressTypeCode === 'F'? item.specimenCount : 0;
          } else{
            if(item.progressTypeCode === 'G'){
              temp.generalCount = item.specimenCount;
            }else if(item.progressTypeCode === 'D' || item.progressTypeCode === 'F'){
              temp.statTodayCount = item.specimenCount;
            }
            temp.totalCount = temp.generalCount + temp.statTodayCount;
          }
          temp.name= item.progressStatusCode+item.progressTypeCode;
        });
        if(!isEmpty(temp.progressStatusCode)){
          overViewValueList.push(temp);
        }
        if(!isEmpty(this.get('overViewList')) && mode == 'autoReset'){
          this.get('overViewList').forEach(function(item, index) {
            if(!isEmpty(overViewValueList[index])){
              set(item, 'generalCount', overViewValueList[index].generalCount);
              set(item, 'totalCount', overViewValueList[index].totalCount);
              set(item, 'statTodayCount', overViewValueList[index].statTodayCount);
            }
          });
        }else{
          this.set('overViewList', overViewValueList);
        }

        if(isEmpty(params.classificationIds) && isEmpty(params.unitWorkIds) && isEmpty(params.examinationIds)){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9192', 'F', null, 'Overview 검색 조건을 확인하세요'), 'warning', 'Ok', 'Ok', '', 2000);
          if(!isEmpty(this.get('overViewList'))){
            this.get('overViewList').forEach(e=>{
              set(e, 'generalCount', 0);
              set(e, 'totalCount', 0);
              set(e, 'statTodayCount', 0);
            });
            return;
          }
          this.set('examinationTagNameSelectedItem', null);
          this._setOverView(this.get('overViewList').get('firstObject'), 'A');
          return;
        }
        let selectedOverView = this.get('overViewList').get('firstObject');
        if(mode == "1"){
          //개인화 설정된 queryOption 가 '전체'인 경우
          this._setOverView(null, 'A');
          this.set('selectedOverView', null);
        }else if(mode == "2"){
          //개인화 설정된 queryOption 지정
          selectedOverView = this.get('overViewList').findBy('progressStatusCode', "Checkin");
          this._setOverView(selectedOverView);
          this.set('selectedOverView', selectedOverView);
        }else if(mode == "5" ){
          selectedOverView = this.get('overViewList').findBy('progressStatusCode', "Execution");
          this._setOverView(selectedOverView);
          this.set('selectedOverView', selectedOverView);
        }else if(mode == "3"){
          selectedOverView = this.get('overViewList').findBy('progressStatusCode', "Preliminary");
          this._setOverView(selectedOverView);
          this.set('selectedOverView', selectedOverView);
        }else if(mode == "4"){
          selectedOverView = this.get('overViewList').findBy('progressStatusCode', "Final");
          this._setOverView(selectedOverView);
          this.set('selectedOverView', selectedOverView);
        }else if(mode == 'autoReset'){
          // 새로 바인딩 안하고 기존유지. 디자인만 유지
        }else if(mode!= 'autoReset' && mode!= 'init'){
          //개인화저장 안한 최초조회일경우
          selectedOverView= this.get('overViewList').get('firstObject');
          this._setOverView(selectedOverView, 'A');
          this.set('selectedOverView', selectedOverView);
        }

        // this.get('co_PersonalizationService').setSettingInfo(`specimen-check-in-work-list-overview`,
        //   JSON.stringify({
        //     conditionData:[this.get('examinationTagList'), this.get('examinationTagNameSelectedItem'), selectedOverView],
        //     hpcSearchTypeCode: this.get('hpcSelectedValue')
        //   }), '진단검사 워크리스트 OverView 설정 저장');
      }.bind(this)).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },
    _getArrayExaminationTagId(sTagName){
      if(isEmpty(this.get('examinationTagList'))){
        return null;
      }
      const tagArray = this.get('examinationTagList').filter(function(item){
        return item.type === sTagName;
      }).map(function(res){
        return res.id;
      });
      if ((tagArray === null) || (tagArray.length === 0)){
        return null;
      } else{
        return tagArray;
      }
    },
    _callBackViewSettingCB(WorkListSearchCode, isNull){
      const callBackSetting = {};
      callBackSetting.selectedComboBox = this.get('examinationTagNameSelectedItem');
      callBackSetting.selectedTagSet = this.get('examinationTagList');
      callBackSetting.workListSearchCode= WorkListSearchCode;
      callBackSetting.examinationFromDate= this.get('examinationFromDate');
      callBackSetting.examinationToDate= this.get('examinationToDate');
      callBackSetting.examinationTagNameSelectedItem= this.get('examinationTagNameSelectedItem');
      callBackSetting.examinationTagList= this.get('examinationTagList');
      callBackSetting.progressTypeCode= this.get('progressTypeCode');
      callBackSetting.isNull= isNull;
      //WorkList에서 조각UI로 열릴시에 변경값 탭으로 전달하는 콜백 이벤트
      this.get('ViewSettingCB')(callBackSetting);
    },

    _catchError(e){
      this.showResponseMessage(e);
    }
  });