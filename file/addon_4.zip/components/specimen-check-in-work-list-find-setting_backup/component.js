/* eslint-disable max-lines */
import { hash } from 'rsvp';
import { next } from '@ember/runloop';
import $ from 'jquery';
import { set } from '@ember/object';
import { isEmpty, compare } from '@ember/utils';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import specimencheckinMessageMixin from 'specimencheckin-module/mixins/specimen-check-in-message-mixin';
export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, specimencheckinMessageMixin,
  {
    /** NOTICE: 전체적인 리팩토링으로 원본 파일 _backkup 파일로 남겨둠..(원 개발자가 퇴사했으므로 비즈니스로직 참고용) **/
    specimenCheckinService: service('specimen-check-in-service'),
    layout,
    // 2. Property Area
    defaultUrl: null,
    popupInfo: null,
    popupReturn: null,
    examinationCategoryListItems: null,
    examinationCategoryListSelectedItem: null,
    examinationUnitListItems: null,
    examinationUnitListSelectedItem: null,
    examinationListItems: null,
    examinationListSelectedItem: null,
    examinationCategoryTagItems: null,
    examinationUnitTagItems: null,
    examinationText: null,
    examinationTagItems: null,
    examinationTagNameText: null,
    savedSettingGridColumns: null,
    savedSettingGridItems: null,
    savedSettingSelectedItem: null,
    savedSettingParams: null,
    conditionInfo: null,

    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId', 'specimen-check-in-work-list-find-setting');
      this.setStateProperties([
        'defaultUrl',
        'popupReturn',
        'examinationCategoryListItems',
        'examinationCategoryListSelectedItem',
        'examinationUnitListItems',
        'examinationUnitListSelectedItem',
        'examinationListItems',
        'examinationListSelectedItem',
        'examinationText',
        'examinationCategoryTagItems',
        'examinationUnitTagItems',
        'examinationTagItems',
        'examinationTagNameText',
        'savedSettingGridColumns',
        'savedSettingGridItems',
        'savedSettingSelectedItem',
        'savedSettingParams',
        'conditionInfo'
      ]);
      if (this.hasState() === false) {
        //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimencheckin')
        + `specimen-checkin/v0/`);
        this.set('popupReturn', {});

        this.set('savedSettingGridColumns',[
          { title: this.getLanguageResource('3718', 'F','세트'), field: 'name', align: 'left'},
          { title: this.getLanguageResource('3368', 'F','삭제'), bodyTemplateName: 'command', align: 'center', width: 60}
        ]);
        this.set('savedSettingParams', {});
        this._initTagList();
      }
    },

    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'wp100');

      if (this.hasState() === false) {
        this._setExaminationCategoryList();
        this._setSavedSettingGrid();

        //Test용.. 나중에 지워야됨!!!!
        if(this.get('popupInfo') === null){
          this.set('popupInfo', {});
          this.set('popupInfo.isOpen', true);
        }
      }
    },


    // 4. Actions Area
    actions: {
      onSavedSettingGridLoad(e){
        this.set('savedSettingGrid', e.source);
      },
      onInitializeClick(){
        this._initializeClick();
      },

      onExaminationCategoryChanged(){
        this.set('isExamListboxShow', true);
        this._setExaminationUnitList();
      },
      onExaminationUnitChanged(){
        this._setExaminationList();
      },
      onExaminationChanged(){
        this.set('examinationText', null);
      },
      onExaminationTextSearch(){
        this._matchExaminationList();
      },
      onExaminationTextCommit(){
        this._matchExaminationList();
      },
      //Tag Save 이벤트
      onTagItemsSave() {
        // Tag가 1개이상 지정되어있고 이름이 지정되어 있어야함.
        if(this.get('tagList').length === 0){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('8945', 'F','필수값을 입력하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        if ((this.get('examinationTagNameText') === null) || (this.get('examinationTagNameText') === '')){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('8945', 'F','필수값을 입력하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        this._setSavedSettingParamsForCreate(true);
        //overview의 examset 콤보박스 재조회
        this.set('examSetRefresh', true);
        // this.toggleProperty('examSetRefresh');
      },
      onSetGridSelectionChanged(){
        const savedSettingSelectedItem = this.get('savedSettingSelectedItem');

        if (savedSettingSelectedItem === null){
          return;
        }
        this._initTagList();
        this.set('examinationTagNameText', savedSettingSelectedItem.name);

        if(!isEmpty(savedSettingSelectedItem.property.classifications)){
          if(savedSettingSelectedItem.property.classifications.length !== 0){
            savedSettingSelectedItem.property.classifications.forEach(element => {
              this._addTagItems('category', element);
            });
          }
        }
        if(!isEmpty(savedSettingSelectedItem.property.unitWorks)){
          if(savedSettingSelectedItem.property.unitWorks.length !== 0){
            savedSettingSelectedItem.property.unitWorks.forEach(element => {
              this._addTagItems('unit', element);
            });
          }
        }
        if(!isEmpty(savedSettingSelectedItem.property.observationExaminations)){
          if(savedSettingSelectedItem.property.observationExaminations.length !== 0){
            savedSettingSelectedItem.property.observationExaminations.forEach(element => {
              this._addTagItems('exam', element);
            });
          }
        }
        this._setExaminationTagList('updated');
      },
      onDeleteSavedSettingItems(item){
        //isValidDataRow = false로 update
        this._setSavedSettingParamsForUpdate(false, item.displaySequence, item);
      },
      onSavedSettingGridItemDragEnd(){
        this.set('isPopupShow', true);
        for(var i = 0; i < this.get('savedSettingGridItems').length; i++){
          const savedSettingGridItem = this.get('savedSettingGridItems')[i];
          this._setSavedSettingParamsForUpdate(true, i + 1, savedSettingGridItem);
        }
        next(this, function(){
          this.get('specimenCheckinService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
          this.set('isPopupShow', false);
        }.bind(this));
      },
      //최종선택 되어있는 Tag 전달해주기 (OverView)
      onTagItemsSelect(){
        this.set('popupReturn.tagName',this.get('examinationTagNameText'));
        this.set('popupReturn.tagList', this.get('tagList'));
        const savedSettingSelectedItem= this.get('savedSettingSelectedItem');
        if(!isEmpty(savedSettingSelectedItem)){
          //set에서 선택된 아이템이 있을경우 examinationTagList와 비교해서 확인
          const filterdExaminationTagList= this._filterExaminationTagList(
            savedSettingSelectedItem.workListFindConfigurationId,
            savedSettingSelectedItem.property.classifications,
            savedSettingSelectedItem.property.unitWorks,
            savedSettingSelectedItem.property.observationExaminations);
          const ids=[];
          if(!isEmpty(this.get('tagList'))){
            this.get('tagList').forEach(e=>{
              e.items.forEach(i=>{
                ids.addObject(i.id);
              });
            });
            if(compare(filterdExaminationTagList.mapBy('id').sort(),ids.sort())==0){
              this.set('popupReturn.workListFindConfigurationId',this.get('savedSettingSelectedItem.workListFindConfigurationId'));
            }else{
              this.set('popupReturn.workListFindConfigurationId', null);
            }
          }
        }else{
          this.set('popupReturn.workListFindConfigurationId', null);
        }
        this.get('findSettingCB')(this.get('popupReturn'));
        this.set('popupInfo.isOpen', false);
      },

      onPopupOpenedAction(){
        this.set('isPopupShow', true);
        this.set('examinationUnitListItems', []);
        this.set('examinationListItems', []);
        this.set('examSetRefresh', false);
        $('#examSearchText').on('input', this._matchExaminationList.bind(this));
        const savedSettingSelectedItem = this.get('examinationTagNameSelectedItem');
        if (isEmpty(savedSettingSelectedItem)){
          if(this.get('mode')== 'overview'){
            this._setExaminationTagList('updatedByOverview');
          }else{
            this._setExaminationTagList('updated');
          }
          next(this, function(){
            this.set('examinationCategoryListSelectedItem', null);
            this.set('conditionInfo', {});
            if(!isEmpty(this.get('tagList'))){
              this.get('tagList').forEach(element=>{
                if (element.type == 'category') {
                  if(!isEmpty(element.items)){
                    element.items.forEach(item=>{
                      this._addTagItems(element.type, item);
                    });
                  }
                }else if (element.type == 'unit') {
                  if(!isEmpty(element.items)){
                    element.items.forEach(item=>{
                      this._addTagItems(element.type, item);
                    });
                  }
                }else if (element.type == 'exam') {
                  if(!isEmpty(element.items)){
                    element.items.forEach(item=>{
                      this._addTagItems(element.type, item);
                    });
                  }
                }
              });
            }
            this.set('isPopupShow', false);
          }.bind(this));
          return;
        }
        this.set('examinationTagNameText', savedSettingSelectedItem.name);
        if(!isEmpty(this.get('examinationTagNameSelectedItem'))){
          //콤보박스선택값이 있으면
          next(this, function(){
            this.set('savedSettingSelectedItem',this.get('savedSettingGridItems').findBy('workListFindConfigurationId', savedSettingSelectedItem.workListFindConfigurationId) );
            this._initTagList();
            this.set('examinationTagNameText', savedSettingSelectedItem.displayName);
            this._setExaminationTagList('updated');
          }.bind(this));
        }else{
          this._setExaminationTagList('updated');
        }
        next(this, function(){
          this.set('examinationCategoryListSelectedItem', null);
          this.set('isPopupShow', false);
        }.bind(this));
      },

      onPopupClosedAction(){
        $('#examSearchText').off('input', this._matchExaminationList.bind(this));
        this.set('examinationText', null);

        if(!isEmpty(this.get('closedCB'))){
          this.get('closedCB')(this.get('savedSettingSelectedItem'), this.get('tagList'));
        }
        this._initializeSettingGrid();
        // if(!isEmpty(this.get('closedCB'))){
        //   this.get('closed2CB')();
        // }
      },
      onAddDbClick(type, e) {
        if (isEmpty(e)) {
          return;
        }
        this._addTagItems(type, e.item);
      },
      onGroupDeletedTagClick(type) {
        if (type == 'category') {
          this.set('conditionInfo.selectedCategoryList', []);
        }
        if (type == 'unit') {
          this.set('conditionInfo.selectedUnitList', []);
        }
        if (type == 'exam') {
          this.set('conditionInfo.selectedExamList', []);
        }
        this._setTagList();
      },
      onDeletedTagClick(item, type) {
        let selectedItem = null;
        if (type == 'category') {
          this.get('conditionInfo.selectedCategoryList').forEach((category) => {
            if (category.id == item.id) {
              selectedItem = category;
            }
          });
          this.get('conditionInfo.selectedCategoryList').removeObject(selectedItem);
        }
        if (type == 'unit') {
          this.get('conditionInfo.selectedUnitList').forEach((unit) => {
            if (unit.id == item.id) {
              selectedItem = unit;
            }
          });
          this.get('conditionInfo.selectedUnitList').removeObject(selectedItem);
        }
        if (type == 'exam') {
          this.get('conditionInfo.selectedExamList').forEach((exam) => {
            if (exam.id == item.id) {
              selectedItem = exam;
            }
          });
          this.get('conditionInfo.selectedExamList').removeObject(selectedItem);
        }

        this._setTagList();
      },
      onTagResetClick(){
        this._initTagList();
      }
    },

    // 5. Private methods Area
    _setTagList() {
      const newConditionList = [];
      const conditionInfo = this.get('conditionInfo');

      this.set('tagList', []);
      if (!isEmpty(conditionInfo.selectedCategoryList)) {
        newConditionList.push({type: 'category', items: conditionInfo.selectedCategoryList});
      }
      if (!isEmpty(conditionInfo.selectedUnitList)) {
        newConditionList.push({type: 'unit', items: conditionInfo.selectedUnitList});
      }
      if (!isEmpty(conditionInfo.selectedExamList)) {
        newConditionList.push({type: 'exam', items: conditionInfo.selectedExamList});
      }
      this.set('tagList', newConditionList);
    },
    _filterExaminationTagList(workListFindConfigurationId, examinationCategoryTagItems,examinationUnitTagItems,examinationTagItems){
      const filterdExaminationTagList= [];
      filterdExaminationTagList.workListFindConfigurationId=workListFindConfigurationId;
      if(!isEmpty(examinationCategoryTagItems)){
        examinationCategoryTagItems.forEach(element => {
          filterdExaminationTagList.push({id: element.id, name: element.name, abbreviation: element.abbreviation, type: 'category'});
        });
      }
      if(!isEmpty(examinationUnitTagItems)){
        examinationUnitTagItems.forEach(element => {
          filterdExaminationTagList.push({ id: element.id, name: element.name, abbreviation: element.name, type: 'unit'});
        });
      }
      if(!isEmpty(examinationTagItems)){
        examinationTagItems.forEach(element => {
          filterdExaminationTagList.push({id: element.id, name: element.name, abbreviation: element.abbreviation, type: 'exam'});
        });
      }
      return filterdExaminationTagList;
    },
    _initializeSettingGrid(){
      this.set('savedSettingSelectedItem', null);
      this.set('examinationTagNameText', null);
    },

    _initializeClick(){
      this.set('examinationTagNameText', null);
      this._initTagList();
      this._setExaminationCategoryList();
      this._setSavedSettingGrid();
    },

    _initTagList(){
      this.set('conditionInfo', {});
      this.set('tagList', []);
    },

    _setExaminationCategoryList(){
      const path = this.get('defaultUrl') + 'classifications/search';
      const params = {selectedOption: 0, classificationType: 1};
      hash({
        examinationCategoryListItems: this.getList(path, params, null, false)
      }).then(function(result){
        this.set('examinationCategoryListItems', result.examinationCategoryListItems);
        this.set('examinationCategoryListSelectedItem', result.examinationCategoryListItems.get('firstObject'));
      }.bind(this)).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },
    _setExaminationUnitList() {
      this.set('examinationText', null);
      const path = this.get('defaultUrl') + 'unitworks/search';
      const params = {
        classificationIds: [this.get('examinationCategoryListSelectedItem.classificationId')],
        searchKey: '',
        isAllIncluded:false
      };
      hash({
        examinationUnitListItems: this.getList(path, null, params, false)
      }).then(function(result){
        this.set('examinationUnitListItems', result.examinationUnitListItems);
        this.set('examinationUnitListSelectedItem', result.examinationUnitListItems.get('firstObject'));
        this.set('isExamListboxShow',false);
      }.bind(this)).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },
    _setExaminationList() {
      this.set('examinationText', null);
      const path = this.get('defaultUrl') + 'specimen-examinations/search';
      const params = {
        classificationIds: [this.get('examinationCategoryListSelectedItem.classificationId')],
        unitWorkIds: [this.get('examinationUnitListSelectedItem.id')],
        isAllIncluded: false
      };
      hash({
        examinationListItems: this.getList(path, null, params, false)
      }).then(function(result){
        this.set('examinationListItems', result.examinationListItems);
        this.set('examinationListItemsCopy', result.examinationListItems);
        // this.set('examinationListSelectedItem', result.examinationListItems.get('firstObject'));
        this.set('isExamListboxShow', false);
      }.bind(this)).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },
    async _setSavedSettingGrid(index){
      const params = {staffId: this.get('co_CurrentUserService.user.employeeId')};
      //Grid 재조회
      await this.getList(this.get('defaultUrl') + 'worklist-configurations/search', params, null, false).then(function(res) {
        if(isEmpty(res)){
          this.set('examinationTagNameText', null);
          this.set('savedSettingSelectedItem',null);
          return;
        }
        res.forEach(element => {
          set(element, 'workListFindConfigurationId', element.workListFindConfigurationId);
          set(element, 'staffId', element.staffId);
          set(element, 'name', element.displayName);
          set(element, 'displaySequence', element.displaySequence);
          set(element, 'property', element.property);
        });
        this.set('savedSettingGridItems', res);
        next(this, function(){
          if(!isEmpty(index)){
            // this.get('savedSettingGrid').selectRow(index);
            this.set('savedSettingSelectedItem', res[index]);
          }
        }.bind(this));
      }.bind(this)).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    _matchExaminationList(e){
      if(isEmpty(this.get('examinationListItemsCopy')) || isEmpty(e)){
        return;
      }
      const arr=[];
      if(isEmpty(e.target.value)){
        this.set('examinationListItems', this.get('examinationListItemsCopy'));
      }
      this.get('examinationListItemsCopy').forEach(element => {
        if(element.displayCode.toUpperCase().includes(e.target.value.toUpperCase()) ||
           element.name.toUpperCase().includes(e.target.value.toUpperCase())){
          arr.addObject(element);
          //매칭되면 아래에 tag추가해줌..
        }
        this.set('examinationListItems', arr);
      });
    },

    _addTagItems(type, e){
      if (isEmpty(e)) {
        return;
      }
      if (type == 'category') {
        if (isEmpty(this.get('conditionInfo.selectedCategoryList'))) {
          this.set('conditionInfo.selectedCategoryList', []);
        }
        if( (!isEmpty(e.classificationId) && !isEmpty(this.get('conditionInfo.selectedCategoryList').findBy('id', e.classificationId)))
         || (!isEmpty(e.id) && !isEmpty(this.get('conditionInfo.selectedCategoryList').findBy('id', e.id)))){
          //항목 이미 있는경우
          this.get('specimenCheckinService').onShowToast('error', this.getLanguageResource('9842', 'F', '중복데이터가 있습니다'), '');
          return;
        }
        this.get('conditionInfo.selectedCategoryList').push({
          id: isEmpty(e.classificationId)? e.id: e.classificationId,
          name: e.name,
          abbreviation: e.abbreviation
        });
      } else if (type == 'unit') {
        if (isEmpty(this.get('conditionInfo.selectedUnitList'))) {
          this.set('conditionInfo.selectedUnitList', []);
        }
        if(!isEmpty(this.get('conditionInfo.selectedUnitList').findBy('id', e.id))){
          this.get('specimenCheckinService').onShowToast('error', this.getLanguageResource('9842', 'F', '중복데이터가 있습니다'), '');
          return;
        }
        this.get('conditionInfo.selectedUnitList').push({
          //abbreviation 없음
          id: e.id,
          name: e.name
        });
      } else if (type == 'exam') {
        if (isEmpty(this.get('conditionInfo.selectedExamList'))) {
          this.set('conditionInfo.selectedExamList', []);
        }
        if(!isEmpty(this.get('conditionInfo.selectedExamList').findBy('id', e.id))){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9226', 'F','이미 추가되어있습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        this.get('conditionInfo.selectedExamList').push({
          id: e.id,
          name: e.name,
          abbreviation: e.abbreviation
        });
      }
      this._setTagList();
    },

    _deleteTagItems(sTagItems, tagId){
      const tagItems = this.get(sTagItems);
      for(var i = 0; i < tagItems.length; i++){
        if(tagItems[i].id === tagId){
          tagItems.splice(i,1);
          i--;
        }
      }
      this.set(sTagItems, tagItems);
    },

    _setExaminationTagList(status){
      let newTagList = [];
      const examinationTagNameSelectedItem = this.get('examinationTagNameSelectedItem');
      const examinationTagList = this.get('examinationTagList');
      const savedSettingSelectedItem = this.get('savedSettingSelectedItem');

      if(this.get('mode')== 'overview' && isEmpty(examinationTagNameSelectedItem)){
        //specimen-check-in-work-list-overview에서 tag제거했을때
        //savedSettingSelectedItem값이 있는지에 따라 examinationTagList 셋팅
        if(status== 'updatedByOverview'){
          if(!isEmpty(examinationTagList)){
            examinationTagList.forEach(e=>{
              if(!isEmpty(e.items)){
                newTagList.addObject(e);
              }
            });
          }
          this.set('tagList', newTagList);
          return;
        }else if(status== 'updated'){
          // this.set('examinationTagList',this._setByUpdatedParam(examinationCategoryTagItems,examinationUnitTagItems,examinationTagItems));
          return;
        }else{
          return;
        }
      }
      if(status == 'updated'){
        // this.set('examinationTagList', this._setByUpdatedParam(examinationCategoryTagItems,examinationUnitTagItems,examinationTagItems));
        return;
      }
      if(isEmpty(examinationTagNameSelectedItem) && isEmpty(examinationTagList) && isEmpty(savedSettingSelectedItem)){
        this.set('examinationTagList', this.get('popupReturn.tagList'));
        return;
      }else if(!isEmpty(examinationTagNameSelectedItem) && !isEmpty(examinationTagList)){
        //저장된 combobox에서 선택
        newTagList=examinationTagList;
        return;
      }else if(!isEmpty(examinationTagList)){
        newTagList=examinationTagList;
        return;
      }else if(!isEmpty(savedSettingSelectedItem)){
        //세트 설정 List에서 선택
        newTagList=savedSettingSelectedItem;
        return;
      }else if(!isEmpty(examinationTagNameSelectedItem)&& !isEmpty(examinationTagList)){
        newTagList=[];
      }
      this.set('examinationTagList', newTagList);
    },

    _setSavedSettingParamsForCreate(isValidDataRow){
      const path = this.get('defaultUrl') + 'worklist-configurations';
      const savedSettingSelectedItem=this.get('savedSettingSelectedItem');
      const savedSettingGridItems= this.get('savedSettingGridItems');
      let displaySequence = 0;
      this.set('savedSettingParams',{});
      this.set('savedSettingParams.staffId', this.get('co_CurrentUserService.user.employeeId'));
      this.set('savedSettingParams.displayName', this.get('examinationTagNameText'));
      if(isEmpty(savedSettingGridItems)){
        displaySequence = 1;
      } else{
        displaySequence = savedSettingGridItems.get('lastObject').displaySequence + 1;
      }
      this.set('savedSettingParams.displaySequence', displaySequence);
      this.set('savedSettingParams.property', {});
      this._setCurrentTagForCreate();
      if (isEmpty(savedSettingSelectedItem)){
        //최초등록
        this.create(path, null, this.get('savedSettingParams')).then(function() {
          this.get('specimenCheckinService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
          this._setSavedSettingGrid(displaySequence);
          this.set('isPopupShow', false);
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      }else{
        this.get('specimenCheckinService')._showMessage(savedSettingSelectedItem.name+' 세트를 수정하시겠습니까?', 'question', 'YesNo', 'Yes', '', null).then(function(result){
          if(result === 'Yes'){
            this.set('isPopupShow', true);
            this.set('savedSettingParams.displaySequence', savedSettingSelectedItem.displaySequence);
            this.set('savedSettingParams.workListFindConfigurationId', savedSettingSelectedItem.workListFindConfigurationId);
            this.set('savedSettingParams.isValidDataRow', isValidDataRow);
            this.update(path, null, false, this.get('savedSettingParams')).then(function() {
              this.get('specimenCheckinService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
              this._setSavedSettingGrid(savedSettingGridItems.indexOf(savedSettingSelectedItem));
              this.set('isPopupShow', false);
            }.bind(this));
          }else if(result === 'No'){
            // this.create(path, null, this.get('savedSettingParams')).then(function() {
            //   this.get('specimenCheckinService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
            //   this._setSavedSettingGrid(savedSettingGridItems.get('lastObject').displaySequence);
            //   this.set('isPopupShow', false);
            // }.bind(this));
          }
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      }
    },
    _setCurrentTagForCreate(){
      const selectedCategoryList= this.get('conditionInfo.selectedCategoryList');
      const selectedUnitList= this.get('conditionInfo.selectedUnitList');
      const selectedExamList= this.get('conditionInfo.selectedExamList');
      if(!isEmpty(selectedCategoryList)){
        this.set('savedSettingParams.property.classificationId', selectedCategoryList.mapBy('id'));
      }else{
        this.set('savedSettingParams.property.classificationId', []);
      }
      if(!isEmpty(selectedUnitList)){
        this.set('savedSettingParams.property.unitWorkId', selectedUnitList.mapBy('id'));
      }else{
        this.set('savedSettingParams.property.unitWorkId', []);
      }
      if(!isEmpty(selectedExamList)){
        this.set('savedSettingParams.property.observationExaminationId', selectedExamList.mapBy('id'));
      }else{
        this.set('savedSettingParams.property.observationExaminationId', []);
      }
    },

    async _setSavedSettingParamsForUpdate(isValidDataRow, displaySequence, item){
      this.set('isSavedSettingGridShow', true);
      const path = this.get('defaultUrl') + 'worklist-configurations';
      this.set('savedSettingParams',{});
      this.set('savedSettingParams.workListFindConfigurationId', item.workListFindConfigurationId);
      this.set('savedSettingParams.staffId', this.get('co_CurrentUserService.user.employeeId'));
      this.set('savedSettingParams.displayName', item.name);
      //시퀀스는 받아온걸로 따로 매겨줌..
      this.set('savedSettingParams.displaySequence', displaySequence);
      this.set('savedSettingParams.property', {});
      if(!isEmpty(item.property.classifications)){
        this.set('savedSettingParams.property.classificationId', item.property.classifications.mapBy('id'));
      }
      if(!isEmpty(item.property.unitWorks)){
        this.set('savedSettingParams.property.unitWorkId', item.property.unitWorks.mapBy('id'));
      }
      if(!isEmpty(item.property.observationExaminations)){
        this.set('savedSettingParams.property.observationExaminationId', item.property.observationExaminations.mapBy('id'));
      }
      //삭제여부도 받아온걸로 따로 매겨줌..
      this.set('savedSettingParams.isValidDataRow', isValidDataRow);
      await this.update(path, null, false, this.get('savedSettingParams')).then(function() {
        this._initializeClick();
        this.set('isSavedSettingGridShow', false);
        if(isValidDataRow){
          //index 수정
          // this.get('specimenCheckinService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
        }else{
          //삭제
          this.get('specimenCheckinService').onShowToast('delete', this.getLanguageResource('8944', 'F', 'Deleted'), '');
        }
      }.bind(this)).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    _catchError(e){
      this.set('isPopupShow',false);
      this.set('isExamListboxShow',false);
      this.set('isSavedSettingGridShow',false);
      this.showResponseMessage(e);
    }
  });