import { isEmpty } from '@ember/utils';
// import { set } from '@ember/object';
import { hash } from 'rsvp';
import $ from 'jquery';
// import { inject as service } from '@ember/service';
import { computed, set } from '@ember/object';
import { getOwner } from '@ember/application';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'specimencheckin-module/app-config';
import specimencheckinPrintMixin from 'specimencheckin-module/mixins/specimen-check-in-print-mixin';
import specimencheckinMessageMixin from 'specimencheckin-module/mixins/specimen-check-in-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,specimencheckinPrintMixin, specimencheckinMessageMixin,
  {
    layout,
    // specimenCheckinService: service('specimen-check-in-service'),
    specimenCheckinService: computed(function () {
      return getOwner(this).lookup('service:specimen-check-in-service');
    }),
    isCheckin: null,
    // 2. Property Area
    defaultUrl: null,
    paramEmployeeId: null,
    isCancelGridShow: null,
    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-check-in-specimen-cancel-search');
      //Set Stateful properties
      this.setStateProperties([
        'defaultUrl',
        'searchCondition',
        'cancelGridColumns',
        'cancelGridItemsSource',
        'patientTypeItemsSource',
        'isCheckin'
      ]);
      if (this.hasState() === false) {
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimencheckin')+ `specimen-checkin/${config.version}/`);
        this.set('isCancelGridShow', true);
        this.set('cancelGridColumns',[
          { title: this.getLanguageResource('7601', 'F', '취소일'), field: 'rejectDatetime', width: 80,type: 'date', dataFormat: 'd', align: 'center', bodyTemplateName: 'dateTooltip' },
          { title: this.getLanguageResource('16963', 'S', '구분'), field: 'encounterType.name', align: 'center', width: 50},
          { title: this.getLanguageResource('16881', 'S','Pt Name'), field: 'subject.name', align: 'center', headerTemplateName: 'barcolor', bodyTemplateName: 'boldTooltip', width: 90 },
          { title: this.getLanguageResource('8451', 'S','MRN'), field: 'subject.number', headerTemplateName: 'barcolor', bodyTemplateName: 'bold', align: 'center', width: 65 },
          { title: this.getLanguageResource('3680', 'F','Sex'), field: 'subject.gender',align: 'center', width: 35 },
          { title: this.getLanguageResource('1662', 'S','Age'), field: 'subject.age', width: 35, align: 'center' },
          { title: this.getLanguageResource('16892', 'S','검사분류'), field: 'classification.name', bodyTemplateName: 'tooltip', width: 140 },
          { title: this.getLanguageResource('859', 'S','검체번호'), field: 'specimenNumber', headerTemplateName: 'barcolor', bodyTemplateName: 'colfont', width: 85 },
          // { title: this.getLanguageResource('801', 'S','검사취소'), field: 'isExaminationCancel', type: 'boolean',width: 60, align: 'center'},
          { title: this.getLanguageResource('7591', 'S','취소사유'), field: 'reasonContent', bodyTemplateName: 'tooltip' },
          { title: this.getLanguageResource('7602', 'S','취소자'), field: 'registrationStaff.name', bodyTemplateName: 'tooltip', width: 110, align: 'center' },
        ]);
        this._getCancelList();
      }
    },

    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1000');
      if (this.hasState() === false) {
        const defaultUrl= this.get('defaultUrl');
        hash({
          worklistConfigurations: this.getList(defaultUrl + 'worklist-configurations/search', {staffId:this.get('co_CurrentUserService.user.employeeId')}, null),
          examTypeItemsSource: this.getList(defaultUrl + 'classifications/search', {selectedOption: 'EncounterTypeCode', classificationType: 1}, null),
          businessCodes: this.getList(defaultUrl + 'business-codes/search', null,{classificationCodes: ['EncounterTypeCode']}, false),
        }).then(function(result){
          this.set('examTypeItemsSource', result.examTypeItemsSource);
          this.set('worklistConfigurations', result.worklistConfigurations.get('firstObject.property'));

          const worklistConfigurations= this.get('worklistConfigurations');
          set(worklistConfigurations, 'classificationIds', isEmpty(worklistConfigurations)? null
            : worklistConfigurations.classifications.mapBy('id'));
          const patientTypeItemsSource= [];
          result.businessCodes.forEach(e=>{
            if(e.classificationCode == 'EncounterTypeCode'){
              patientTypeItemsSource.addObject(e);
            }
          });
          this.set('patientTypeItemsSource', patientTypeItemsSource);
          const today= this.get('co_CommonService').getNow();
          const searchCondition= {
            fromDate: today,
            toDate: today,
            subjectNumber: null,
            specimenNumber: null,
            encounterTypeCode: patientTypeItemsSource.get('firstObject.code'),
            classificationIds: [],
          };
          this.set('canclCategoryValue', 'Final');
          this.set('searchCondition', searchCondition);
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      }
    },
    // 4. Actions Area
    actions: {
      onLoadCombobox(e){
        this.set('_classificationIdsCombobox', e.source);
      },
      onGridLoad(e){
        this.set('_cancelGridControl', e.source);
      },
      onExamTypeSelectedChanged(){
        set(this.get('searchCondition'), 'classificationIds', this.get('_classificationIdsCombobox.selectedItems').mapBy('classificationId'));
        this._getCancelList();
      },
      onSearchClick(){
        if(this.get('canclCategoryValue') == 'Checkin'){
          const cancelGridColumns= this.get('cancelGridColumns');
          if(cancelGridColumns.length == 10){
            const tmp= $.extend(true, [], cancelGridColumns.map(function(u){
              return $.extend(true, {}, u);
            }));
            tmp.splice(8, 0,
              { title: this.getLanguageResource('801', 'S','검사취소'), field: 'isExaminationCancel', type: 'boolean',width: 60, align: 'center'});
            this.set('cancelGridColumns', tmp);
          }
        }else{
          const tmp= $.extend(true, [], this.get('cancelGridColumns').map(function(u){
            return $.extend(true, {}, u);
          }));
          if(tmp.length ==11){
            tmp.splice(8, 1);
            this.set('cancelGridColumns', tmp);
          }
          this.set('isCheckin', true);
        }
        this._getCancelList();
      },
      onEncounterTypeChanged(e){
        set(this.get('searchCondition'), 'encounterTypeCode',e.item.code);
        this._getCancelList();
      },
      onExcelPrintAction() {
        const itemsSource = this.get('cancelGridItemsSource');
        const columns = this.get('cancelGridColumns');
        if(isEmpty(itemsSource)){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9264', 'F', '조회된 정보가 없습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        const gridSource=this.get('_cancelGridControl');
        const reason = 'Excel export specimen cancel list';
        const headers = columns.map(function(item, index){
          return { left: index, top: 0, right: index, bottom: 0, value: item.title };
        });
        const fields = columns.map(function(item){
          return { width: item.width, value: item.field};
        });
        gridSource.exportToExcel('specimen_cancel_list.xlsx', headers, fields, this, 'onExcelPrintAction', reason , itemsSource);
      },
      // onSelectEmployee(item){
      //   if(isEmpty(item)){
      //     return;
      //   }
      //   this.set('isEmployeeListPopupOpen', false);
      //   set(this.get('searchCondition'), 'subjectNumber', item.displayId);
      // },
    },
    // 5. Private methods Area
    _getCancelList(){
      this.set('isCancelGridShow',true);
      const searchCondition= this.get('searchCondition');
      if(isEmpty(searchCondition)){
        this.set('isCancelGridShow',false);
        return;
      }
      if(isEmpty(searchCondition.fromDate) || isEmpty(searchCondition.toDate)){
        this.set('isCancelGridShow',false);
        this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9290', 'F', '날짜를 확인하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
        return;
      }

      const params={
        fromDate: new Date(searchCondition.fromDate.getFullYear(), searchCondition.fromDate.getMonth(), searchCondition.fromDate.getDate(), 0, 0, 0),
        toDate: new Date(searchCondition.toDate.getFullYear(), searchCondition.toDate.getMonth(), searchCondition.toDate.getDate(), 0, 0, 0),
        subjectTypeCode: 'Patient',
        subjectNumber: isEmpty(searchCondition.subjectNumber)? null: searchCondition.subjectNumber.trim(),
        specimenNumber: isEmpty(searchCondition.specimenNumber)? null: searchCondition.specimenNumber.trim(),
        encounterTypeCode: searchCondition.encounterTypeCode =='A'? null: searchCondition.encounterTypeCode,
        classificationIds: isEmpty(searchCondition.classificationIds)? [] :searchCondition.classificationIds
      };
      let promise= null;
      switch (this.get('canclCategoryValue')) {
        case 'Final':
          promise =this.getList(this.get('defaultUrl') + 'specimen-states/observation-cancels',null, params, true);
          break;
        case 'Checkin':
          promise =this.getList(this.get('defaultUrl') + 'specimen-states/check-in-rejects', null, params, true);
          break;
        case 'Drawn':
          promise =this.getList(this.get('defaultUrl') + 'specimen-states/rejects',null, params, true);
          break;
        default:
          break;
      }
      if(isEmpty(promise)){
        return;
      }
      promise.then(function(res){
        this.set('isCancelGridShow',false);
        if(isEmpty(res.response)){
          this.set('cancelGridItemsSource', null);
          return;
        }
        this.set('cancelGridItemsSource', res.response);
      }.bind(this)).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    _catchError(e){
      this.set('isCancelGridShow',false);
      this.showResponseMessage(e);
    }
  });