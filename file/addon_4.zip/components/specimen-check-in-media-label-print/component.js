/* eslint-disable no-console */
// import { set } from '@ember/object';
import { set } from '@ember/object';
import { A as emberA } from '@ember/array';
import { isEmpty, isPresent } from '@ember/utils';
import { next } from '@ember/runloop';
import { hash } from 'rsvp';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'specimencheckin-module/app-config';
import specimencheckinPrintMixin from 'specimencheckin-module/mixins/specimen-check-in-print-mixin';
import specimencheckinMessageMixin from 'specimencheckin-module/mixins/specimen-check-in-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,specimencheckinPrintMixin, specimencheckinMessageMixin,
  {
    specimenCheckinService: service('specimen-check-in-service'),
    layout,
    // 2. Property Area
    defaultUrl: null,
    //print
    printPopup:null,
    printConfig:null,
    printContent:null,
    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-check-in-media-label-print');
      //Set Stateful properties
      this.setStateProperties([
        'defaultUrl',
        'mediasGridColumns',
        'mediasGridItemsSource',
        'gridSelectedItem',
        'mediaGroupItemsSource',
        'mediaPrintClassification',
        'searchCondition'
      ]);
      if (this.hasState() === false) {
      //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimencheckin')+ `specimen-checkin/${config.version}/`);
        this.set('mediasGridColumns',[
          { title: this.getLanguageResource('6767', 'S','Check-in No.'),field: 'checkInNumber', width: 60, align: 'center' },
          { title: this.getLanguageResource('870', 'F','Specimen Code'),field: 'specimenType.displayCode', bodyTemplateName: 'tooltip', width: 70, align: 'center' },
          { title: this.getLanguageResource('16921', 'F','Specimen Name'), field: 'specimenType.name', bodyTemplateName: 'tooltip', width: 100, align: 'center' },
          { title: this.getLanguageResource('16881', 'F','Pt Name'), field: 'subject.name', bodyTemplateName: 'boldTooltip', align: 'center',width: 90 },
          { title: this.getLanguageResource('8451', 'S','MRN'), field: 'subject.number', bodyTemplateName: 'bold', width: 65, align: 'center' },
          { title: this.getLanguageResource('1662', 'F','Age'), field: 'subject.age', width: 35, align: 'center' },
          { field: 'issuedDepartment.name', title: this.getLanguageResource('8827', 'S','발행처'), align: 'center', width: 80, bodyTemplateName: 'tooltip'},
          { field: 'department.name', title: this.getLanguageResource('7111', 'S','진료과'), align: 'center', width: 70, bodyTemplateName: 'tooltip'},
          { field: 'orderedStaff.name', title: this.getLanguageResource('9686', 'S','처방의'), align: 'center', width: 70, bodyTemplateName: 'tooltip'},
          { title: this.getLanguageResource('2676', 'S','배지명'), field: 'media.name',bodyTemplateName: 'tooltip', width: 75, align: 'center' },
          { title: this.getLanguageResource('2677', 'S','배지번호'), field: 'mediaNumber', width: 105, headerTemplateName: 'barcolor', bodyTemplateName: 'colfont', align: 'center' },
          { title: this.getLanguageResource('859', 'S','Specimen No.'), field: 'specimenNumber', headerTemplateName: 'barcolor', bodyTemplateName: 'colfont', width: 95, align: 'center' },
          // { title: this.getLanguageResource('5259', 'F','Order Code'), field: 'examination.displayCode', width: 70, bodyTemplateName: 'tooltip', align: 'center'},
          { title: this.getLanguageResource('5218', 'F','Order Name'), field: 'examination.name', width: 190, headerTemplateName: 'barcolor', bodyTemplateName: 'colfontTooltip'},
          { title: this.getLanguageResource('5228', 'F','Order Comment'), field: 'orderComment', bodyTemplateName: 'tooltip' },
        ]);
        const today= this.get('co_CommonService').getNow();
        this.set('searchCondition',{
          checkInFromDate: today,
          checkInToDate: today,
          classificationIds: null,
          mediaGroupCodes: null,
          checkInStartNumber: null,
          checkInEndNumber: null,
          mediaUseGroupCodes: null,
        });
        this.getPrinterName().then(function(res){
          this.set('printerBName', res);
        }.bind(this)).catch(function(error) {
          this._catchError(error);
        }.bind(this));
      }
    //Initialize Stateless properties
    },

    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1360');
      if (this.hasState() === false) {
        const defaultUrl= this.get('defaultUrl');
        hash({
          businessCodes: this.getList(defaultUrl + 'business-codes/search', null,{
            classificationCodes: [
              'MediaPrintClassification','MediaGroupCode'
            ]
          }, false),
        }).then(function(result) {
          const mediaPrintClassification= [];
          const mediaGroupItemsSource= [];
          result.businessCodes.forEach(e=>{
            if(e.classificationCode == 'MediaPrintClassification'){
              mediaPrintClassification.addObject(e);
            }else if(e.classificationCode == 'MediaGroupCode'){
              mediaGroupItemsSource.addObject(e);
            }
          });
          this.set('mediaPrintClassification', mediaPrintClassification);
          this.set('mediaGroupItemsSource', mediaGroupItemsSource);
          next(this, function(){
            this.get('_classificationIdsCombobox').selectItem(0);
            // this.get('_mediaGroupCodesCombobox').selectItem(0);
            this._getMedias();
          }.bind(this));
        }.bind(this)).catch(function(e){
          this._catchError(e);
        }.bind(this));
      }
    },
    // 4. Actions Area
    actions: {
      onMediasGridLoad(e){
        this.set('_gridControl', e.source);
      },
      onSearchClick(){
        this._getMedias();
      },

      onLoadCombobox(e){
        switch (e.source.name){
          case 'classificationIds':
            this.set('_classificationIdsCombobox', e.source);
            break;
          case 'mediaGroupCodes':
            this.set('_mediaGroupCodesCombobox', e.source);
            break;
          default:
            break;
        }
      },

      onGridSelectionChanged(e){
        this.set('selectedItems', e.selectedItems);
      },
      onPrintBtnClick(){
        const selectedItems= this.get('selectedItems');
        if(isEmpty(selectedItems)){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9260', 'F', 'Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        const searchCondition =this.get('searchCondition');
        const mediaLabelPrintList = [];

        this.set('printPopup',true);
        selectedItems.forEach(e=>{
          mediaLabelPrintList.addObject({
            "checkInNumber" : e.checkInNumber,
            "subjectNumber" : e.get('subject.number'),
            "subjectName" : e.get('subject.name'),
            "specimenTypeName" : e.get('specimenType.name'),
            "issuedDepartmentName" : e.get('issuedDepartment.name'),
            "departmentName" : e.get('department.name'),
            "mediaName" : e.get('media.name'),
            "orderComment" : e.orderComment,
          });
        });
        const classificationNames= this.get('_classificationIdsCombobox.selectedItems').map(function (item) {
          return item.abbreviation;
        });
        const checkInStartNumber=isEmpty(searchCondition.checkInStartNumber)? '' : searchCondition.checkInStartNumber.toString();
        const checkInEndNumber=isEmpty(searchCondition.checkInEndNumber)? '' : ' ~ '+searchCondition.checkInEndNumber.toString();
        const printConfig = {
          'printType': 2,
          'commonInformation' : true,
          "printName": "MediaLabelPrintList"
        };
        this.set('printConfig', printConfig);
        this.set('printContent',{
          dataField :{
            "mediaLabelPrintList": mediaLabelPrintList,
          },
          parameterField :{
            "checkInFromDate" : searchCondition.checkInFromDate.toFormatString(true, false),
            "checkInToDate" : searchCondition.checkInToDate.toFormatString(true, false),
            "checkInNumber" : isEmpty(checkInStartNumber)?
              checkInStartNumber : checkInStartNumber + checkInEndNumber,
            "checkInStartNumber":searchCondition.checkInStartNumber,
            "checkInEndNumber":searchCondition.checkInEndNumber,
            "classificationIds" : isEmpty(classificationNames)? null: classificationNames.join(', '),
            // "checkInEndNumber" : searchCondition.checkInEndNumber,
            // "classificationIds" : Ember.isEmpty(searchCondition.classificationIds)? null: searchCondition.classificationIds.join(', '),
          }
        });
      },

      onLabelPrintClick(){
        const mediaInfo = [];
        const now = new Date(this.get('co_CommonService').getNow());
        if(isEmpty(this.get('selectedItems'))){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9260', 'F', 'Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        this.get('selectedItems').forEach(element => {
          if(isEmpty(element.subject)){
            return;
          }
          let loaction = element.issuedDepartment.displayCode;
          if(!isEmpty(element.ward)) {
            loaction = `${element.ward} / ${element.room} / ${element.bed}`;
          }
          const specimentName = `${element.classification.labelName} ${element.get('specimenType.name')}(${element.specimenType.containerName})`;
          mediaInfo.addObject({
            mediaNumber : element.mediaNumber,
            subjectNumber : element.get('subject.number'),
            subjectName : element.get('subject.name'),
            genderAge: `(${element.get('subject.gender')}/${element.get('subject.age')})`,
            birthday: this.get('fr_I18nService').formatDate(element.get('subject.birthday'), 'd'),
            mediaName : element.get('media.name'),
            issuedDepartment : element.get('issuedDepartment.displayCode'),
            checkInDate : element.checkInDate.getYear(),
            checkInNumber : element.checkInDate.getFullYear().toString().slice(2)
              + ("0" +(element.checkInDate.getMonth()+1)).slice(-2).toString()
              + ("0" + element.checkInDate.getDate()).slice(-2).toString() + ' - ' + element.checkInNumber,
            specimenName : specimentName,
            specimenNumber: element.specimenNumber,
            printDate: this.get('fr_I18nService').formatDate(now, 'g'),
            location: loaction,
            property: this._setProperty(element),
            progressTypeName: this._setProgressTypeName(element)
            // printDate: this.get('co_CommonService').getNow().toFormatString(true, false)
          });
        });
        // this.getPrinterName('B').then(printerBName=>{
        const printContent = {};
        printContent.dataField = { "mediaInfo": mediaInfo };
        this.set('printPopup', false);
        const printConfig = {
          printType: 1,
          printName: 'MediaLabel',
          // printerName: this.get('printerBName'),
          commonInformation : false
        };
        const printInfo = this.get('printerBName');
        if(!isEmpty(printInfo)) {
          if(!isEmpty(printInfo.printerB)) {
            printConfig.printerName = printInfo.printerB;
          } else if(!isEmpty(printInfo.printerDefault)) {
            printConfig.printerName = printInfo.printerDefault;
          }
          console.log('printInfo--', printInfo);
        }
        this.set('printConfig', printConfig);
        this.set('printContent',printContent);
        // }).catch(function(e){
        //   this._catchError(e);
        // }.bind(this));
      },
      onExcelPrintAction() {
        const itemsSource = this.get('mediasGridItemsSource');
        if(isEmpty(itemsSource)){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9264', 'F', '조회된 정보가 없습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        const gridSource=this.get('_gridControl');
        const reason = 'Excel export media label';
        const column = this.get('mediasGridColumns');
        const headers = column.map(function(item, index){
          return { left: index, top: 0, right: index, bottom: 0, value: item.title };
        });
        const fields = column.map(function(item){
          return { width: item.width, value: item.field };
        });
        gridSource.exportToExcel('media_label.xlsx', headers, fields, this, 'onExcelPrintAction',reason , itemsSource);
      }
    },
    _setProperty(res){
      //우선순위 progressTypeCode/isAlert/isNeedConsent/isNeedRequest
      let property = 'null';
      if(res.isAlert){
        property = `${this.getLanguageResource('571', 'S', '감염')}`;
      }
      if(res.isNeedConsent){
        property=`${this.getLanguageResource('11740', 'S', '동의서필요')}`;
      }
      if(res.isNeedRequest){
        property= `${this.getLanguageResource('17066', 'S', '의뢰서 필요')}`;
      }
      return property;
    },
    _setProgressTypeName(item) {
      let str = '';
      if(isPresent(item.progressTypeCode)) {
        if(item.progressTypeCode === 'F') {
          str = this.getLanguageResource('5725', 'F', '응급');
        }else if(item.progressTypeCode === 'D') {
          str = this.getLanguageResource('1880', 'F', '당일');
        }
      }
      return str;
    },
    // 5. Private methods Area
    _getMedias(){
      this.set('mediasGridItemsSource', emberA());
      const searchCondition= this.get('searchCondition');
      set(searchCondition, 'classificationIds', this.get('_classificationIdsCombobox.selectedItems').map(function(item){
        return item.code;
      }));
      if(isEmpty(searchCondition.classificationIds)){
        return;
      }
      const mediaGroupCodes= this.get('_mediaGroupCodesCombobox.selectedItems');
      set(searchCondition, 'mediaGroupCodes', isEmpty(mediaGroupCodes)? null : this.get('_mediaGroupCodesCombobox.selectedItems').map(function(item){
        return item.code;
      }));
      set(searchCondition, 'mediaUseGroupCodes', []);
      if(isEmpty(searchCondition.checkInFromDate) || isEmpty(searchCondition.checkInToDate)){
        this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9290', 'F', '날짜를 확인하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
        return;
      }
      set(searchCondition, 'checkInFromDate',
        new Date(searchCondition.checkInFromDate.getFullYear(), searchCondition.checkInFromDate.getMonth(), searchCondition.checkInFromDate.getDate(), 0, 0, 0));
      set(searchCondition, 'checkInToDate',
        new Date(searchCondition.checkInToDate.getFullYear(), searchCondition.checkInToDate.getMonth(), searchCondition.checkInToDate.getDate(), 0, 0, 0));

      set(searchCondition, 'classificationIds',
        isEmpty(searchCondition.classificationIds)? null: searchCondition.classificationIds);
      set(searchCondition, 'checkInStartNumber',
        isEmpty(searchCondition.checkInStartNumber)? null: searchCondition.checkInStartNumber);
      set(searchCondition, 'checkInEndNumber',
        isEmpty(searchCondition.checkInEndNumber)? null: searchCondition.checkInEndNumber);

      // searchCondition.mediaGroupCodes= null;
      this.set('isMediasGridShow', true);
      this.getList(this.get('defaultUrl') + 'specimen-examination-worklists/medias/search', null, searchCondition, false).then(res=>{
        this.set('isMediasGridShow', false);
        if(!isEmpty(res)) {
          res.forEach(e=>{
            set(e,'issuedDepartmentName', e.get('issuedDepartment.name'));
            set(e,'departmentName', e.get('department,name'));
            set(e,'orderedStaffName', e.get('orderedStaff.name'));
            set(e,'examinationName', e.get('examination.name'));
          });
          this.set('mediasGridItemsSource', res);
        }
      }).catch(function(e){
        this._catchError(e);
      }.bind(this));
    },

    _catchError(e){
      console.log('error', e);
      this.set('isLoaderShow',false);
      this.set('isSpecimenNumberDisabled', false);
      this.showResponseMessage(e);
    }
  });