/* eslint-disable max-lines */
/* eslint-disable no-unused-vars */
/* eslint-disable no-console */
import moment from 'moment';
import EmberObject,{ get, set } from '@ember/object';
import { A as emberA } from '@ember/array';
import { task } from 'ember-concurrency';
import { next } from '@ember/runloop';
import { isEmpty, isPresent } from '@ember/utils';
import { hash } from 'rsvp';
import { inject as service } from '@ember/service';
// import { copy } from '@ember/object/internals';
import $ from 'jquery';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'specimencheckin-module/app-config';
import PrintMixin from 'specimencheckin-module/mixins/specimen-check-in-print-mixin';
import MessageMixin from 'specimencheckin-module/mixins/specimen-check-in-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, PrintMixin, MessageMixin,
  {
    specimenCheckinService: service('specimen-check-in-service'),
    specimenSamplingService: service('specimen-sampling-service'),
    applicationCatalogUtilService: service('application-catalog-util-service'),
    layout,
    // 2. Property Area
    defaultUrl: null,
    settingInfo: null,
    //print
    printPopup:null,
    printConfig:null,
    printContent:null,
    dataPage: 1,
    dataTotalPage: 1,
    dataTotalCount: 0,
    takeCount: 100,
    isDateUpdated: false,
    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-check-in-refer-list');
      if(!isEmpty(this.getOpenMenuParams())){
        this.set('useTypeCode', this.getOpenMenuParams().useTypeCode);
      }
      //Set Stateful properties
      this.setStateProperties([
        'defaultUrl',
        'settingInfo',
        'useTypeCode',
        'examTypeItemsSource',
        'examTypeSelectedItem',
        'statusItemsSource'
      ]);
      if (this.hasState() === false) {
      //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimencheckin')
      + `specimen-checkin/${config.version}/`);
        this.set('consignedAgencyColumns',[
          { title: this.getLanguageResource('9880', 'F', '위탁기관'),field: 'consignedAgency.name', width: 65, bodyTemplateName: 'tooltip', align: 'center' },
          { title: this.getLanguageResource('5246', 'S','오더일'),field: 'orderDate', width: 80, type: 'date', dataFormat: 'd', align: 'center'},
          { title: this.getLanguageResource('6777', 'S','접수일'), field: 'checkInDate', width: 80, bodyTemplateName: 'dateTimeTooltip', align: 'center' },
          { title: this.getLanguageResource('859', 'S','검체번호'), field: 'specimenNumber', width: 85, align: 'center' },
          { title: this.getLanguageResource('6767', 'S','Check-in No.'), field: 'checkInNumber', align: 'center', width:60},
          { title: this.getLanguageResource('17105', 'S','주민번호'), field: 'subject.identifierNumber', width: 80, align: 'center'},
          { title: this.getLanguageResource('16881', 'S','Pt Name'), field: 'subject.name', align: 'center', bodyTemplateName: 'subjectNameTooltip', width: 80 },
          { title: this.getLanguageResource('8451', 'S','MRN'), field: 'subject.number', bodyTemplateName: 'bold', align: 'center', width: 65 },
          { title: this.getLanguageResource('3680', 'F','Sex'), field: 'subject.gender',align: 'center', width: 35 },
          { title: this.getLanguageResource('1662', 'S','Age'), field: 'subject.age', width: 35, align: 'center' },
          { title: this.getLanguageResource('4920', 'S','연락처'), field: 'subject.telephoneNumber', width: 95, align: 'center' },
          { title: this.getLanguageResource('16921', 'F','Specimen Name'),field: 'specimenType.name', width:100, headerTemplateName: 'barcolor01', bodyTemplateName: 'colfontTooltip' },
          { title: this.getLanguageResource('16920', 'S','Exam Name'), field: 'examination.name', width:100, headerTemplateName: 'barcolor01', bodyTemplateName: 'orderNameTooltip' },
          { title: this.getLanguageResource('5228', 'F','Order Comment'), field: 'orderComment', width: 60, bodyTemplateName: 'orderComment', align: 'center'},
          { title: this.getLanguageResource('7211', 'F', '채혈비고'), field: 'collectionComment', width: 60, bodyTemplateName: 'collectionComment', align: 'center' },
          { title: this.getLanguageResource('3452', 'F','상태'), field: 'progressStatus.name', align: 'center', width: 65},
          { title: this.getLanguageResource('13290', 'S','', '결과전송시간'), field: 'performDatetime', align: 'center', type: 'date', dataFormat: 'g', width: 100},
          { title: this.getLanguageResource('9881', 'S','전송상태'), field: 'sendStatus.name', align: 'center', width: 70},
          { title: this.getLanguageResource('13291', 'S','', '결과보고일시'), field: 'result.issuedDatetime', align: 'center', type: 'date', dataFormat: 'g', width: 100},
          { title: this.getLanguageResource('16887', 'S', '','검사자'), field: 'result.issuedStaff.name', align: 'center', bodyTemplateName: 'tooltip', width: 80 },
        ]);
        this.set('businessCodeListColumns', [
          { title:this.getLanguageResource('9833', 'F', '', '명칭'), field:'originalName', align: 'left', width: 100 },
        ]);
        this.set('businessRelateCodeListColumns', [
          { title:this.getLanguageResource('9833', 'F', '', '명칭'), field:'name', align: 'left', width: 100, bodyTemplateName: 'tooltip', },
        ]);
        this.set('selectionExcelColumns', [
          { title: this.getLanguageResource('17105', 'S','주민번호'), field: 'subject.identifierNumber', width: 80, align: 'center'},
          { title: this.getLanguageResource('16881', 'S','Pt Name'), field: 'subject.name', align: 'center', bodyTemplateName: 'subjectNameTooltip', width: 80 },
          { title: this.getLanguageResource('4920', 'S','연락처'), field: 'tel', width: 95, align: 'center' },
          { field: 'level', title: this.getLanguageResource('tempkey', 'S','', '급종'),align: 'center', width: 100, bodyTemplateName: 'tooltip'},
          { field: 'departmentCode', title: this.getLanguageResource('7111', 'S','진료과'),align: 'center', width: 100, bodyTemplateName: 'tooltip'},
          { title: this.getLanguageResource('859', 'S','검체번호'), field: 'specimenNumber', width: 85, align: 'center' },
          { field: 'orderCode1', title: this.getLanguageResource('tempkey', 'S','', '오더코드1'),align: 'center', width: 100, bodyTemplateName: 'tooltip'},
          { field: 'orderCode2', title: this.getLanguageResource('tempkey', 'S','', '오더코드2'),align: 'center', width: 100, bodyTemplateName: 'tooltip'},
          { field: 'consignedAgency.code', title: this.getLanguageResource('tempkey', 'S','', '계약처'),align: 'center', width: 100, bodyTemplateName: 'tooltip'},
          { field: 'orderComment', title: this.getLanguageResource('tempkey', 'F','', '오더비고'), bodyTemplateName: 'tooltip' }
        ]);
        this.set('manualExcelColumns', []);
        this.set('isInitGridShow', true);
        this.set('statusItemsSource', [
          {selected: true, code: 'All', name: this.getLanguageResource('6700', 'S','전체')},
          {selected: false, code: 'Send', name: this.getLanguageResource('16930', 'S','전송')},
          {selected: false, code: 'None', name: this.getLanguageResource('2471', 'S','미전송')}],
        );
        this.set('businessCodeListItems', []);
        this.set('businessRelateCodeListItems', []);
        this.set('isShowSelectionExcelButton', false);
        this.set('isNextPageSearch', false);
        this.set('isSettingPopupOpen', false);
        this.getPrinterName().then(function(res){
          this.set('printSetting', res);
        }.bind(this)).catch(function(error) {
          this._catchError(error);
        }.bind(this));
      }
    //Initialize Stateless properties
    },

    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1360');
      if (this.hasState() === false) {
        hash({
          businessCodes: this.getList(this.get('defaultUrl') + 'business-codes/search', null, {classificationCodes: ['ConsignedAgency','WorkListSearchCode', 'PandemicHospitalConsignedType', 'ConsignedAgencyDownLoadColumn']}, false),
          examTypeItemsSource: this.getList(this.get('defaultUrl') + 'classifications/search', {selectedOption: 'EncounterTypeCode', classificationType: 1}, null),
        },).then(function(result) {
          const consignedAgencyItemsSource= [];
          const searhConditionItemsSource= [];
          const pandemicHospitalConsignedTypes = [];
          const consignedAgencyDownLoadColumn = [];
          result.businessCodes.forEach(e=>{
            if(e.classificationCode == 'ConsignedAgency'){
              consignedAgencyItemsSource.addObject(e);
            }else if(e.classificationCode == 'WorkListSearchCode'){
              searhConditionItemsSource.addObject(e);
            }else if(e.classificationCode === 'PandemicHospitalConsignedType') {
              pandemicHospitalConsignedTypes.addObject(e);
            } else if(e.classificationCode === 'ConsignedAgencyDownLoadColumn') {
              consignedAgencyDownLoadColumn.addObject(e);
            }
          });
          if(!isEmpty(result.examTypeItemsSource)){
            result.examTypeItemsSource.insertAt(0, {displayCode: 'All', classificationId: 'All', name: this.getLanguageResource('6700', 'F', '', '전체')});
          }
          this.set('examTypeItemsSource', result.examTypeItemsSource);
          this.set('consignedAgencyItemsSource', consignedAgencyItemsSource);
          this.set('searhConditionItemsSource', searhConditionItemsSource);
          this.set('pandemicHospitalConsignedTypes', pandemicHospitalConsignedTypes);
          if(isPresent(consignedAgencyDownLoadColumn)) {
            consignedAgencyDownLoadColumn.map(d => {
              d.originalName = d.name;
            });
          }
          this.set('originDownloadExcelItems', consignedAgencyDownLoadColumn);
          // this.set('periodCategoryValue', 'checkindatecheck');
          // this.set('hpcSearchTypeCode', 'All');
          this._getPersonalizationInfo();
        }.bind(this)).catch(function(e){
          this.set('isInitGridShow',false);
          this._catchError(e);
        }.bind(this));
      }
    },

    async _getHospitalConfigSettingCodes() {
      try {
        const selectedConsignedAgencyCode = this.get('searchCondition.consignedAgencyCode');
        const hospitalId = this.get('co_CurrentUserService.user.hospital.hospitalId');
        const result = await this.get('co_CommonService').getConfigurationSettingInfo('HOSPITAL', hospitalId, 'specimen-check-in-refer-setting-codes');
        if(isEmpty(result.settingValue)) {
          this.set('businessRelateCodeListItems', []);
          this.set('settingCodesInfo', []);
        } else {
          const datas = JSON.parse(result.settingValue);
          this.set('settingCodesInfo', datas);
          const matchCodeItem = datas.find(d => d.agencyCode === selectedConsignedAgencyCode);
          if (isPresent(matchCodeItem)) {
            this.set('businessRelateCodeListItems', matchCodeItem.codeList);
          } else {
            this.set('businessRelateCodeListItems', []);
          }
        }
        this._setManualColumns();
        this._initBusinessCode();
      }catch(e) {
        this._catchError(e);
      }
    },
    _setManualColumns() {
      const manualExcelColumns = [];
      const businessRelateCodeListItems = this.get('businessRelateCodeListItems');
      if(isPresent(businessRelateCodeListItems)) {
        businessRelateCodeListItems.forEach(d => {
          manualExcelColumns.push(
            { field: d.code, title: d.name, width: 100, }
          );
        });
      }
      // let targetItems = this.get('businessRelateCodeListItems');
      // if(isEmpty(targetItems)) {
      //   targetItems = this.get('businessCodeListItems');
      // }
      // if(isPresent(targetItems)) {
      //   targetItems.forEach(d => {
      //     manualExcelColumns.push(
      //       { field: d.code, title: d.name, width: 100, }
      //     );
      //   });
      // }
      this.set('manualExcelColumns', manualExcelColumns);
    },
    async _setHospitalConfigSettingCodes() {
      try{
        const settingCodesInfo = this.get('settingCodesInfo');
        const selectedConsignedAgencyCode = this.get('searchCondition.consignedAgencyCode');
        const matchCodeItem = settingCodesInfo.find(d => d.agencyCode === selectedConsignedAgencyCode);
        const businessRelateCodeListItems = this.get('businessRelateCodeListItems');
        if(isPresent(businessRelateCodeListItems)) {
          businessRelateCodeListItems.map((item, index) => {
            item.displaySequence = index + 1;
          });
        }
        if(isPresent(settingCodesInfo) && isPresent(matchCodeItem)) {
          settingCodesInfo.forEach(d => {
            if(d.agencyCode === selectedConsignedAgencyCode) {
              set(d, 'codeList', businessRelateCodeListItems);
            }
          });
        } else {
          settingCodesInfo.addObject({
            agencyCode: selectedConsignedAgencyCode,
            codeList: businessRelateCodeListItems
          });
        }
        const hospitalId = this.get('co_CurrentUserService.user.hospital.hospitalId');
        await this.get('co_CommonService').setConfigurationSettingInfo('HOSPITAL', hospitalId, `specimen-check-in-refer-setting-codes`, JSON.stringify(settingCodesInfo), '위탁검체 기관 연결코드 저장');
        this.showToastSaved();
        this.set('isSettingPopupOpen', false);
      }catch(e) {
        this.showResponseMessage(e);
      }
    },

    _getPersonalizationInfo(){
      const today= this.get('co_CommonService').getNow();
      const searchCondition= { checkInFromDate: today, checkInToDate: today, sendStatus: 'All', hpcSearchTypeCode: 'All', periodCategoryValue: 'checkindatecheck'};
      this.get('co_PersonalizationService').getSettingInfo(`specimen-check-in-refer-list`).then((settingInfo) => {
        if(isEmpty(settingInfo.settingValue)){
          searchCondition.queryOption= this.get('searhConditionItemsSource.firstObject.code');
          searchCondition.consignedAgencyCode= this.get('consignedAgencyItemsSource.firstObject.code');
          searchCondition.classificationId = 'All';
          //2020.11.23 개인화설정 저장으로 추가
          searchCondition.periodCategoryValue = 'checkindatecheck';
          searchCondition.hpcSearchTypeCode= 'All';
          searchCondition.sendStatus = 'All';
          next(this,function(){
            set(searchCondition, 'classificationId', 'All');
          });
        }else{
          const data = JSON.parse(settingInfo.settingValue).conditionData.get('firstObject');
          this.set('settingInfo', data);
          searchCondition.queryOption= data.queryOption;
          searchCondition.consignedAgencyCode=data.consignedAgencyCode;
          searchCondition.classificationId= isEmpty(data.classificationId)? 'All' : data.classificationId;
          searchCondition.examinationIds=data.examinationIds;
          //2020.11.23 개인화설정 저장으로 추가
          searchCondition.periodCategoryValue = isEmpty(data.periodCategoryValue) ? 'checkindatecheck' : data.periodCategoryValue;
          searchCondition.hpcSearchTypeCode= isEmpty(data.hpcSearchTypeCode) ? 'All': data.hpcSearchTypeCode;
          searchCondition.sendStatus = isEmpty(data.sendStatus) ? 'All' : data.sendStatus;
        }
        if(searchCondition.consignedAgencyCode === 'SNU') {
          this.set('isShowSelectionExcelButton', true);
        } else {
          this.set('isShowSelectionExcelButton', false);
        }
        this.set('searchCondition', searchCondition);
        this._getHospitalConfigSettingCodes();
        this.getList(this.get('defaultUrl') + 'specimen-examinations/consigned-agency',{
          consignedAgencyCode: searchCondition.consignedAgencyCode,
          useTypeCode: isEmpty(this.get('useTypeCode'))? 'Laboratory': this.get('useTypeCode'),
          classificationId: searchCondition.classificationId == 'All'? null: searchCondition.classificationId,
        }, null).then(function(res){
          this.set('isInitGridShow', false);
          this.set('isResultGridShow', false);
          if(isEmpty(res)){
            this.set('examinationIdsItemsSource', null);
            return;
          }
          next(this,function(){
            if(!isEmpty(this.get('settingInfo.examinationIds'))){
              this.get('settingInfo.examinationIds').forEach(e=>{
                this.get('examinationIdsCombobox').selectItem(res.findBy('id', e));
              });
            }
          }.bind(this));
          this.set('examinationIdsItemsSource', res);
        }.bind(this)).catch(function(e){
          this._catchError(e);
          this.set('isInitGridShow',false);
        }.bind(this));
      }).catch(function(e){
        this.set('isInitGridShow',false);
        this._catchError(e);
      }.bind(this));
    },

    didInsertElement() {
      this._super(...arguments);
      // [TEST]
      // afterHideAccessPopup : broadcasting key
      if(this.get('mode') === 'worklist') {
        this.get('co_ContentMessageService').subscribeMessage('afterHideAccessPopup', this.get('viewId'), this, this._afterHideAccessPopup);
      }
    },

    // [TEST]
    _afterHideAccessPopup(param) {
      // broadcasting 에서 자신이 호출한 경우에만 로직 실행
      if(param.viewId === this.get('viewId')) {
        if(param.isConfirmed === true) {
          // "확인" 을 선택하여 닫힌 경우
          this.triggerAction('onMainWorkListContainerOpenStateChange', false, 'hide');
        } else {
          // "취소" 를 선택하여 닫힌 경우
        }
      }
    },
    _setSelectionExportData(itemsSource) {
      // const itemsSource = $.extend(true, [], this.get('consignedAgencyGridItemsSource'));
      const tel = this.get('pandemicHospitalConsignedTypes').find(d => d.code === 'Tel');
      const level = this.get('pandemicHospitalConsignedTypes').find(d => d.code === 'Level');
      const department = this.get('pandemicHospitalConsignedTypes').find(d => d.code === 'Department');
      itemsSource.map( d => {
        d.orderCode1 = d.agencySpecimenExaminationCode;
        d.orderCode2 = '';
        d.tel = tel.name;
        d.level = level.name;
        d.departmentCode = department.name;
      });
      const columns = this.get('selectionExcelColumns');
      this._getExportExcel(itemsSource, columns, `_lis_pandemic_export`);
    },
    _sendCustomDateExportExcel(itemsSource) {
      const columns = this.get('manualExcelColumns');
      const tempArr = [];
      itemsSource.forEach(d => {
        const tmpObj = $.extend(true, {}, d);
        for (const [key, value] of Object.entries(d)) {
          if(key.indexOf('Date') > -1 && isPresent(d[key])) {
            tmpObj[key] = moment(d[key]).format('YYYYMMDD');
          }
        }
        tempArr.push(tmpObj);
      });
      this._getExportExcel(tempArr, columns, `_lis_${this.get('searchCondition.consignedAgencyCode')}_export`);
    },
    async _consignmentSendUpdate(isNomalManual) {
      try {
        const selectedItems = this.get('consignedAgencyGrid.selectedItems');
        if(isEmpty(selectedItems)){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9260', 'F', 'Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        const columns = this.get('manualExcelColumns');
        if(isNomalManual && isEmpty(columns)) {
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('17412', 'F', '위탁기관 서식항목을 지정하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        const itemsSource = $.extend(true, [], this.get('consignedAgencyGrid.selectedItems'));
        // itemsSource.map(d => {
        //   for (const [key, value] of Object.entries(d)) {
        //     if(key.indexOf('Date') > -1 && isPresent(d[key])) {
        //       d[key] = moment(d[key]).format('YYYYMMDD');
        //     }
        //     // console.log(`${key}: ${value}`);
        //   }
        //   // d.checkInDateTime = moment(d.checkInDateTime).format('YYYYMMDD');
        // });
        const hasStatusCodeNotSendItems = selectedItems.filter(d => d.get('sendStatus.code') !== 'Send');
        if(isEmpty(hasStatusCodeNotSendItems)) {
          // this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9502', 'F', '진행상태를 확인하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
          if(!isNomalManual) {
            this._setSelectionExportData(itemsSource);
          } else {
            this._sendCustomDateExportExcel(itemsSource);
            // this._getExportExcel(tempArr, columns, `_lis_${this.get('searchCondition.consignedAgencyCode')}_export`);
          }
          return;
        }
        const tmp = [];
        hasStatusCodeNotSendItems.forEach(e=>{
          tmp.addObject({
            checkInId: e.checkInId,
            specimenId: e.specimenId,
            specimenNumber: e.specimenNumber,
            observationId: e.observationId,
            sendStatusCode: isEmpty(e.sendStatus)? "Send": e.sendStatus.code,
            receiveStatusCode: isEmpty(e.receieveStatus)? null: e.receieveStatus.code
          });
        });
        this.set('isSendDisabled', true);
        const createParams = {consignedAgencyRefers: tmp};
        await this.create(this.get('defaultUrl') + 'consigned-agency-refers', null, createParams);
        this.get('specimenCheckinService').onShowToast('save', this.getLanguageResource('9882', 'F', '전송되었습니다.'), '');
        this.set('isNextPageSearch', false);
        this.set('isSendDisabled', false);
        if(!isNomalManual) {
          this.set('isSelectionUpdated', true);
        } else {
          this.set('isManualUpdated', true);
        }
        this.set('updatedItems', itemsSource);
        this._searchWorkListcConsignedAgency();
      } catch(e) {
        this._catchError(e);
      }
    },
    _initBusinessCode() {
      //코드기준으로 겹치지 않는것만 다시 셋팅..
      const itemsSource = $.extend(true, [], this.get('originDownloadExcelItems'));
      let businessCodeListItems = itemsSource;
      if(isPresent(this.get('businessRelateCodeListItems'))) {
        businessCodeListItems = itemsSource.filter(x => !this.get('businessRelateCodeListItems').some(element => element.code === x.code));
      }
      this.set('businessCodeListItems', businessCodeListItems);
    },
    //왼쪽 List -> 오른쪽 List
    _addBusinessRelateCode(){
      const businessCodeListSelectedItems = this.get('businessCodeListSelectedItems');
      const businessRelateCodeListItemsSource = this.get('businessRelateCodeListItems');
      const businessCodeListItemsSource = this.get('businessCodeListItems');

      //순서는 복사되는(오른쪽)List 작업 -> 복사하는(왼쪽)List 작업
      businessCodeListSelectedItems.forEach(element => {
        businessRelateCodeListItemsSource.pushObject(element);
        businessCodeListItemsSource.removeObject(element);
      });
    },
    //오른쪽 List -> 왼쪽 List
    _deleteBusinessRelateCode(){
      const businessRelateCodeListSelectedItems = this.get('businessRelateCodeListSelectedItems');
      const businessRelateCodeListItemsSource = this.get('businessRelateCodeListItems');
      const businessCodeListItemsSource = this.get('businessCodeListItems');

      //작업순서는 복사되는(왼쪽)List 작업 -> 복사하는(오른쪽)List 작업
      businessRelateCodeListSelectedItems.forEach(element => {
        businessCodeListItemsSource.pushObject(element);
        businessRelateCodeListItemsSource.removeObject(element);
      });
    },
    // 4. Actions Area
    actions: {
      onSettingPopupOpened() {
        this._getHospitalConfigSettingCodes();
      },
      onAgencySettingClick(e) {
        this.set('placeTarget', e.originalEvent.currentTarget);
        this.set('isSettingPopupOpen', true);
      },
      onSelectionExcelPrintAction() {
        if(isEmpty(this.get('consignedAgencyGridItemsSource'))){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9264', 'F', '조회된 정보가 없습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        this._consignmentSendUpdate(false);
      },
      onManualSend() {
        if(isEmpty(this.get('consignedAgencyGridItemsSource'))){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9264', 'F', '조회된 정보가 없습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        this._setManualColumns();
        this._consignmentSendUpdate(true);
      },
      onBusinessCodeListSelectionChange(e){
        this.set('businessCodeListSelectedItems', e.selectedItems);
      },
      onAddBusinessRelateCode(){
        this._addBusinessRelateCode();
      },
      onDeleteBusinessRelateCode(){
        this._deleteBusinessRelateCode();
      },
      onBusinessRelateCodeListSelectionChange(e){
        this.set('businessRelateCodeListSelectedItems', e.selectedItems);
      },

      onConfirmClick(){
        //선택완료되었음. CallBack 보내줌..
        // this.get('onSelectedConfirmCB')();
        this._setHospitalConfigSettingCodes();
      },
      onGridSortingColumnsChanged(e) {
        const colList = this.get('consignedAgencyColumns');
        colList.forEach(col => {
          if(col.field === 'specimenType.name' || col.field === 'examination.name') {
            set(col, 'isSorted', false);
            if(!isEmpty(e.sortingColumns) && col.field === e.sortingColumns[0].column.field) {
              set(col, 'isSorted', true);
              set(col, 'sortClass', e.sortingColumns[0].direction);
            }
          }
        });
      },

      onExamTypeSelectedChanged(){
        set(this.get('searchCondition'), 'examinationIds', this.get('examinationIdsCombobox.selectedItems').mapBy('id'));
        // this._getReferList();
        this.set('isNextPageSearch', false);
        this._searchWorkListcConsignedAgency();
      },
      onHpcChanged(e){
        this.set('searchCondition.hpcSearchTypeCode', e.value);
        this._saveSearchConditions();
        this.set('isNextPageSearch', false);
        this._searchWorkListcConsignedAgency();
      },
      onCellDoubleClick(){
        if(this.get('mode') !== 'worklist') {
          return;
        }
        const selectedItem= this.get('gridSelectedItem');
        if(isEmpty(selectedItem)){
          return;
        }
        let worklists= {};
        this.ajaxSyncCall(this.get('defaultUrl') + 'specimen-examination-worklists/search', null,'POST',
          {specimenNumber:selectedItem.specimenNumber},false).done(function(res){
          if(isEmpty(res)){
            return;
          }
          worklists= res.get('firstObject');
        });
        this.get('specimenCheckinService').getDisplayView(selectedItem.specimenNumber, null).then(function(res){
          if(isEmpty(res)){
            this.get('specimenCheckinService')._showMessage('Display View Error', 'warning', 'Ok', 'Ok', '', 2000);
            return;
          }
          const globalItem = {
            patientChoicePath: 'Encounter',
            patientId: worklists.subjectId,
            encounterId: worklists.specimenOrders.get('firstObject.encounterId'),
            examination:{
              state: selectedItem.progressStatus.code,
              specimenId: selectedItem.specimenId,
            },
            patientSelectionSource: {viewId: 'specimen-check-in-refer-list'}
          };
          const m = emberA();
          let isPBS= false;
          res.forEach( e => {
            const temp={
              displayCode: e.viewId,
              stateType: null,
              parameters: {
                specimenNumber:selectedItem.specimenNumber,
                examinationCode:selectedItem.examination.displayCode
              }
            };
            if(e.viewId == "specimen-examination-report-blood-cell-morphology"){
              isPBS = true;
            }
            m.addObject(temp);
          });
          this.getList(this.get('defaultUrl') + 'specimen-checkins/requests/current-encounter', {procedureRequestId: worklists.specimenOrders.get('firstObject.basedOn.id')}, null, false).then(function(result) {
            if(!isEmpty(result) && !isEmpty(result.encounterId)){
              globalItem.encounterId = result.encounterId;
            }
            this.get('co_PatientManagerService').selectPatient(globalItem, isPBS ? m.reverse() : m);
          }.bind(this)).catch(function(e) {
            this._catchError(e);
            this.get('co_PatientManagerService').selectPatient(globalItem, isPBS ? m.reverse() : m);
          }.bind(this));
        }.bind(this)).catch(function(e){
          this._catchError(e);
        }.bind(this));
      },

      onConsignedAgencyGridLoad(e){
        this.set('consignedAgencyGrid', e.source);
      },

      onLoadCombobox(e){
        this.set('examinationIdsCombobox', e.source);
      },
      onExamTypeComboboxLoad(e){
        this.set('examTypeCombobox', e.source);
      },
      onConsignedAgencyComboboxLoad(e){
        this.set('consignedAgencyCombobox', e.source);
      },

      onConsignedAgencyChanged(e){
        this.set('searchCondition.consignedAgencyCode', e.item.code);
        this._saveSearchConditions();
        this._getHospitalConfigSettingCodes();
        if(e.item.code === 'SNU') {
          this.set('isShowSelectionExcelButton', true);
        } else {
          this.set('isShowSelectionExcelButton', false);
        }
        this.getList(this.get('defaultUrl') + 'specimen-examinations/consigned-agency', {
          consignedAgencyCode: e.item.code,
          // consignedAgencyCode: this.get('searchCondition.consignedAgencyCode'),
          useTypeCode: isEmpty(this.get('useTypeCode'))? 'Laboratory': this.get('useTypeCode'),
          classificationId: this.get('searchCondition.classificationId') == 'All'? null: this.get('searchCondition.classificationId'),
        }, null).then(function(res){
          if(isEmpty(res)){
            this.set('examinationIdsItemsSource', null);
            // return;
          } else {
            this.set('examinationIdsItemsSource', res);
          }
          this.set('isNextPageSearch', false);
          this._searchWorkListcConsignedAgency();
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      },

      onExamTypeChanged(e){
        this._saveSearchConditions();
        this.getList(this.get('defaultUrl') + 'specimen-examinations/consigned-agency', {
          // consignedAgencyCode: e.item.code,
          consignedAgencyCode: this.get('searchCondition.consignedAgencyCode'),
          useTypeCode: isEmpty(this.get('useTypeCode'))? 'Laboratory': this.get('useTypeCode'),
          classificationId: get(e, 'item.classificationId') == 'All'? null: get(e,'item.classificationId'),
        }, null).then(function(res){
          if(isEmpty(res)){
            this.set('examinationIdsItemsSource', null);
            // return;
          }else{
            this.set('examinationIdsItemsSource', res);
          }
          // this._getReferList();
          this.set('isNextPageSearch', false);
          this._searchWorkListcConsignedAgency();
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      },

      onSearchClick(){
        // this._getReferList();
        this._saveSearchConditions();
        this.set('isNextPageSearch', false);
        this._searchWorkListcConsignedAgency();
      },
      onFromToUpdated() {
        this.set('isDateUpdated', true);
        this.set('isNextPageSearch', false);
        this._searchWorkListcConsignedAgency();
      },

      onGridSelectionChanged(e){
        this.set('selectedItems', e.selectedItems);
      },

      onPrindBarcode(){
        // const selectedItems= this.get('selectedItems');
        const selectedItems = this.get('consignedAgencyGrid.selectedItems');
        if(isEmpty(selectedItems)){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9260', 'F', 'Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
          return false;
        }
        this.set('printDataFieldDefault', []);
        this.set('printDataFieldD', []);
        this.set('printDataFieldG', []);
        this.set('printDataFieldF', []);
        this.set('printDataField', []);
        this.set('printouts', null);

        this.set('isLabelPrint', true);
        // this.getPrinterName().then(function(res){
        // this.set('printSetting', res);
        const printSetting= this.get('printSetting');
        selectedItems.forEach(element => {
          set(element, 'index', this.get('consignedAgencyGrid').getItemIndex(element));
        });
        selectedItems.sortBy('index').forEach(element => {
          this._getSpecimenLabel(element);
        });
        next(this, function(){
          this.set('printPopup', false);
          if(isEmpty(this.get('printDataFieldG')) && isEmpty(this.get('printDataFieldD')) && isEmpty(this.get('printDataFieldF'))){
            this.set('printConfig', {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerDefault });
            this.set('printContent', {
              'parameterField': {},
              'dataField': { "specimenInfo" : this.get('printDataFieldDefault')}});
            this.set('printDataFieldDefault', null);
          }else{
            this._print();
          }
          const num= isEmpty(this.get('printouts'))? '': this.get('printouts');
          this.get('specimenCheckinService').onShowToast('save', this.getLanguageResource('16928', 'S', '출력매수') + ": \xa0"+ num , '',8000);
        }.bind(this));
        // }.bind(this));
      },

      onSendClick(){
        const tmp=[];
        //const updateTmp=[];
        // let isStatusChecked= false;
        let promise=null;
        //상태체크 후 재전송 방지
        // const selectedItems= this.get('selectedItems');
        const selectedItems = this.get('consignedAgencyGrid.selectedItems');
        if(isEmpty(selectedItems)){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9260', 'F', 'Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
          return false;
        }
        const hasStatusCodeSendItems = selectedItems.find(d => d.get('sendStatus.code') === 'Send');
        if(!isEmpty(hasStatusCodeSendItems)) {
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9502', 'F', '진행상태를 확인하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        selectedItems.forEach(e=>{
          // if(e.get('sendStatus.code') =='Send'){
          //   isStatusChecked = true;
          // }
          tmp.addObject({
            checkInId: e.checkInId,
            specimenId: e.specimenId,
            specimenNumber: e.specimenNumber,
            observationId: e.observationId,
            sendStatusCode: isEmpty(e.sendStatus)? "Send": e.sendStatus.code,
            receiveStatusCode: isEmpty(e.receieveStatus)? null: e.receieveStatus.code
          });
        });
        // if(isStatusChecked){
        //   this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9502', 'F', '진행상태를 확인하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
        //   return false;
        // }
        this.set('isSendDisabled', true);
        const createParams= {consignedAgencyRefers: tmp};
        if(!isEmpty(createParams)){
          promise= this.create(this.get('defaultUrl') + 'consigned-agency-refers', null, createParams);
        }
        if(!isEmpty(promise)){
          promise.then(function(){
            this.get('specimenCheckinService').onShowToast('save', this.getLanguageResource('9882', 'F', '전송되었습니다.'), '');
            // this._getReferList();
            this.set('isNextPageSearch', false);
            this.set('isSendDisabled', false);
            this._searchWorkListcConsignedAgency();
          }.bind(this)).catch(function(error){
            this._catchError(error);
          }.bind(this));
        }

      },
      onExcelPrintAction() {
        const itemsSource = this.get('consignedAgencyGridItemsSource');
        const columns = this.get('consignedAgencyColumns');
        if(isEmpty(itemsSource)){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9264', 'F', '조회된 정보가 없습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        this.get('applicationCatalogUtilService').showDownloadWarnningPopup('specimencheckin/export-consigned-agency', 'excel', function(_result){
          if(_result){
            const gridSource=this.get('consignedAgencyGrid');
            const reason = 'Excel export: refer list';
            const headers = columns.map(function(item, index){
              return { left: index, top: 0, right: index, bottom: 0, value: item.title };
            });
            const fields = columns.map(function(item){
              return { width: item.width, value: item.field };
            });
            gridSource.exportToExcel('refer_list.xlsx', headers, fields, this, 'onExcelPrintAction', reason , itemsSource);
          }
        }.bind(this));
      },
      onPrintReferralBtnClick(){
        if(this.get('consignedAgencyGrid').selectedItems.length > 1){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('10177', 'F', '하나의 행을 선택하세요'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        if(!isEmpty(this.get('gridSelectedItem.referralRecordNoteId'))){
          this.set('printReferralOpen', true);
        }else{
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9848', 'F', '출력할 정보가 없습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
        }
      },

      onExePrintAfterCB(){
        if(this.get('isLabelPrint')){
          this._print();
        }
      },

      onPrintBtnClick(){
        //그리드 출력
        // const selectedItems= this.get('selectedItems');
        const selectedItems = this.get('consignedAgencyGrid.selectedItems');
        if(isEmpty(selectedItems)){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9260', 'F', 'Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        const searchCondition =this.get('searchCondition');
        const consignedAgencyList = [];
        this.set('isLabelPrint', false);
        selectedItems.forEach(e=>{
          consignedAgencyList.addObject({
            "consignedAgencyName": e.consignedAgency.name,
            "orderDate" : e.orderDate.toFormatString(true, false),
            "checkInDateTime" : e.checkInDateTime.toFormatString(true, false),
            "specimenNumber" : e.specimenNumber,
            "subjectIdentifierNumber" : e.subject.identifierNumber,
            "subjectName" : e.subject.name,
            "subjectNumber" : e.subject.number,
            "subjectGender" : e.subject.gender,
            "subjectAge" : e.subject.age,
            "subjectTelephoneNumber" : e.subject.telephoneNumber,
            "specimenTypeName" : e.specimenType.name,
            //"examinationName" : e.examination.name,
            "examinationName" : e.examination.abbreviation,
            "orderComment" : e.orderComment,
            "collectionComment" : e.collectionComment,
            // "progressStatusName" : e.progressStatus.name
          });
        });
        this.set('printPopup',true);
        this.set('printConfig',{'printType': 2, 'commonInformation' : true, 'printName': "ConsignedAgencyList" });
        this.set('printContent',{
          dataField :{ "consignedAgencyList": consignedAgencyList},
          parameterField :{
            "checkInFromDate" : searchCondition.checkInFromDate.toFormatString(true, false),
            "checkInToDate" : searchCondition.checkInToDate.toFormatString(true, false),
            // "consignedAgencyNames": consignedAgencyName,
            // "classificationIds": examTypeName,
            // "examinationIds": examinationCodeNames,
            // "queryOption": searchCondition.queryOption,
          }
        });
        console.log(this.get('printContent'));
      },
      onGridScroll(e){
        if(this.get('dataTotalCount') === this.get('consignedAgencyGridItemsSource.length')) {
          return;
        }
        if (e.top !== 0 && Math.round(e.maxTop) <= Math.round(e.top) + 1){
          if(this.get('isValidPaging')){
            this.set('isValidPaging', false);
            this.set('isNextPageSearch', true);
            this._searchWorkListcConsignedAgency();
          }
        }
      }

    },
    // 5. Private methods Area,
    searchWorkListTask: task(function * (){
      // this._setClassOn();
      // if(isEmpty(this.get('examinationGroupCode')) && isEmpty(this.get('condition.selectedExaminationRoom'))){
      //   return;
      // }
      const isNextPageSearch = this.get('isNextPageSearch');
      if(isNextPageSearch) {
        if(this.get('dataTotalPage') <= this.get('dataPage')){
          return;
        }
        this.set('dataPage', this.get('dataPage') + 1 );
      } else {
        this._allClear();
      }

      this.set('isResultGridShow', true);
      const res = yield this.create(this.get('defaultUrl') + 'specimen-examination-worklists/consigned-agency-paging', null, this._getParam(), true);
      if (!isEmpty(res.response)){
        if(isNextPageSearch) {
          //TODO: paging logic
          this.get('consignedAgencyGridItemsSource').pushObjects(res.response);
        } else {
          const totalCount = JSON.parse(res.jqXHR.getResponseHeader('customdata')).totalCount;
          const takeCount = JSON.parse(res.jqXHR.getResponseHeader('customdata')).takeCount;
          this.set('dataTotalCount', totalCount);
          this.set('takeCount', takeCount);
          if(totalCount > 100){
            const page = parseInt(totalCount / takeCount) + 1;
            this.set('dataTotalPage', page);
          }
          res.response.forEach(e=>{
            set(e, 'orderNameTooltip', e.examination.displayCode +', ' + e.examination.name);
            if(isPresent(e.subject) && (e.subject.isPrivacyProtection || e.subject.isProtectionHealthInfo)) {
              set(e, 'isShowIconProtect', true);
            }
          });
          this.set('consignedAgencyGridItemsSource', res.response);
        }
        if(this.get('isSelectionUpdated')) {
          this._setSelectionExportData(this.get('updatedItems'));
        } else if(this.get('isManualUpdated')) {
          const columns = this.get('manualExcelColumns');
          if(!isEmpty(columns)) {
            this._sendCustomDateExportExcel(this.get('updatedItems'));
            // this._getExportExcel(this.get('updatedItems'), columns, `_lis_${this.get('searchCondition.consignedAgencyCode')}_export`);
          }
        }
      }
      // if(this.get('isDateUpdated')) {
      //   this._saveSearchConditions();
      // }
      next(this, function(){
        this.set('isDateUpdated', false);
        this.set('isValidPaging', true);
        this.set('isResultGridShow', false);
        this.set('isSelectionUpdated', false);
        this.set('isManualUpdated', false);
        if(isPresent(this.get('updatedItems'))) {
          this.get('updatedItems').forEach(d => {
            const findIndex = res.response.findIndex(r => r.observationId === d.observationId);
            if(findIndex > -1) {
              this.get('consignedAgencyGrid').selectRow(findIndex);
            }
          });
        }
        this.set('updatedItems', null);
      });
    }).restartable(),
    async _searchWorkListcConsignedAgency () {
      try {
        const isNextPageSearch = this.get('isNextPageSearch');
        if(isNextPageSearch) {
          if(this.get('dataTotalPage') <= this.get('dataPage')){
            return;
          }
          this.set('dataPage', this.get('dataPage') + 1 );
        } else {
          this._allClear();
        }
        this.set('isResultGridShow', true);
        const res = await this.create(this.get('defaultUrl') + 'specimen-examination-worklists/consigned-agency-paging', null, this._getParam(), true);
        if (!isEmpty(res.response)){
          if(isNextPageSearch) {
            //TODO: paging logic
            this.get('consignedAgencyGridItemsSource').pushObjects(res.response);
          } else {
            const totalCount = JSON.parse(res.jqXHR.getResponseHeader('customdata')).totalCount;
            const takeCount = JSON.parse(res.jqXHR.getResponseHeader('customdata')).takeCount;
            this.set('dataTotalCount', totalCount);
            this.set('takeCount', takeCount);
            if(totalCount > 100){
              const page = parseInt(totalCount / takeCount) + 1;
              this.set('dataTotalPage', page);
            }
            res.response.forEach(e=>{
              set(e, 'orderNameTooltip', e.examination.displayCode +', ' + e.examination.name);
              if(isPresent(e.subject) && (e.subject.isPrivacyProtection || e.subject.isProtectionHealthInfo)) {
                set(e, 'isShowIconProtect', true);
              }
            });
            this.set('consignedAgencyGridItemsSource', res.response);
          }
          if(this.get('isSelectionUpdated')) {
            this._setSelectionExportData(this.get('updatedItems'));
          } else if(this.get('isManualUpdated')) {
            const columns = this.get('manualExcelColumns');
            if(!isEmpty(columns)) {
              this._sendCustomDateExportExcel(this.get('updatedItems'));
            }
          }
        }
        this.set('isDateUpdated', false);
        this.set('isValidPaging', true);
        this.set('isResultGridShow', false);
        this.set('isSelectionUpdated', false);
        this.set('isManualUpdated', false);
        if(isPresent(this.get('updatedItems'))) {
          this.get('updatedItems').forEach(d => {
            const findIndex = res.response.findIndex(r => r.observationId === d.observationId);
            if(findIndex > -1) {
              this.get('consignedAgencyGrid').selectRow(findIndex);
            }
          });
        }
        this.set('updatedItems', null);
      } catch(e) {
        this._catchError(e);
      }
    },
    _allClear(){
      this.set('dataPage', 1);
      this.set('consignedAgencyGridItemsSource', emberA());
      // this.get('consignedAgencyGridItemsSource').clearSorting();
      const colList = this.get('consignedAgencyColumns');
      colList.forEach(col => {
        if(col.field === 'specimenType.name' || col.field === 'examination.name') {
          set(col, 'isSorted', false);
        }
      });
    },

    _getSpecimenLabel(e){
      const printSetting =this.get('printSetting');
      const printDataField = this.get('printDataField');
      this.get('specimenSamplingService').getSpecimenLabel(null, e.specimenNumber).then(res=>{
        if(!isEmpty(res)){
          this._setProperty(res);
          res.specimenTypes.forEach(function(r, idx) {
            this.set('printouts', this.get('printouts') + r.labelPrintCount);
            let specimenName = res.specimenTypes[idx].abbreviation;
            if(!isEmpty(res.specimenTypes[idx].containerName)){
              specimenName = specimenName + '(' + res.specimenTypes[idx].containerName + ')';
            }
            let u=0;
            while (u < r.labelPrintCount) {
              const resCopy= $.extend(true, EmberObject.create(), res);
              resCopy.specimenName= specimenName;
              if(res.progressTypeCode =="G"&& !isEmpty(printSetting.printerG)){
                if(printSetting.printerG == printSetting.printerDefault){
                  this.get('printDataFieldDefault').pushObject(resCopy);
                }else{
                  this.get('printDataFieldG').pushObject(resCopy);
                }
              }else if(res.progressTypeCode =="D" && !isEmpty(printSetting.printerD)){
                if(printSetting.printerD == printSetting.printerDefault){
                  this.get('printDataFieldDefault').pushObject(resCopy);
                }else{
                  this.get('printDataFieldD').pushObject(resCopy);
                }
              }else if(res.progressTypeCode =="F" && !isEmpty(printSetting.printerF)){
                if(printSetting.printerF == printSetting.printerDefault){
                  this.get('printDataFieldDefault').pushObject(resCopy);
                }else{
                  this.get('printDataFieldF').pushObject(resCopy);
                }
              }else{
                this.get('printDataFieldDefault').pushObject(resCopy);
              }
              u++;
            }
          }.bind(this));
        }
        this.set('printDataField', printDataField);
      }).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    _print(){
      const printSetting= this.get('printSetting');
      this.set('printPopup', false);
      if(!isEmpty(this.get('printDataFieldG'))){
        this.set('printConfig', {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerG });
        this.set('printContent', {
          'parameterField': {},
          'dataField': { "specimenInfo" : this.get('printDataFieldG')}});
        this.set('printDataFieldG' ,null);
        return;
      }
      if(!isEmpty(this.get('printDataFieldD'))){
        this.set('printConfig', {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerD });
        this.set('printContent', {
          'parameterField': {},
          'dataField': { "specimenInfo" : this.get('printDataFieldD')}});
        this.set('printDataFieldD' ,null);
        return;
      }
      if(!isEmpty(this.get('printDataFieldF'))){
        this.set('printConfig', {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerF });
        this.set('printContent', {
          'parameterField': {},
          'dataField': { "specimenInfo" : this.get('printDataFieldF')}});
        this.set('printDataFieldF' ,null);
        return;
      }
      if(!isEmpty(this.get('printDataFieldDefault'))){
        this.set('printConfig', {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerDefault });
        this.set('printContent', {
          'parameterField': {},
          'dataField': { "specimenInfo" : this.get('printDataFieldDefault')}});
        this.set('printDataFieldDefault' ,null);
      }
    },

    _getParam(){
      const searchCondition= this.get('searchCondition');
      if(isEmpty(searchCondition)){
        return;
      }
      set(searchCondition, 'examinationIds', this.get('examinationIdsCombobox.selectedItems').mapBy('id'));
      if(isEmpty(searchCondition.examinationIds)){
        set(searchCondition, 'examinationIds', null);
      }
      if(isEmpty(searchCondition.checkInFromDate) || isEmpty(searchCondition.checkInToDate)){
        this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9290', 'F', '날짜를 확인하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
        return;
      }
      const fromDate= new Date(searchCondition.checkInFromDate.getFullYear(), searchCondition.checkInFromDate.getMonth(), searchCondition.checkInFromDate.getDate(), 0, 0, 0);
      const toDate = new Date(searchCondition.checkInToDate.getFullYear(), searchCondition.checkInToDate.getMonth(), searchCondition.checkInToDate.getDate(), 0, 0, 0);
      set(searchCondition, 'checkInFromDate', fromDate);
      set(searchCondition, 'checkInToDate', toDate);
      set(searchCondition, 'performFromDate', fromDate);
      set(searchCondition, 'performToDate', toDate);
      if(this.get('searchCondition.periodCategoryValue') == 'performdatecheck'){
        //결과전송일별
        set(searchCondition, 'performdatecheck', true);
      }else{
        //접수일별
        set(searchCondition, 'performdatecheck', false);
        // set(searchCondition, 'performFromDate', fromDate);
        // set(searchCondition, 'performToDate', toDate);
      }
      const searchConditionCopy = $.extend(true, EmberObject.create(), searchCondition);
      if(searchConditionCopy.classificationId =='All'){
        set(searchConditionCopy, 'classificationId', null);
      }
      if(searchConditionCopy.sendStatus =='All'){
        set(searchConditionCopy, 'sendStatus', null);
      }
      //2020.11.17 건증 조건 추가(hpcSearchTypeCode)
      if(searchConditionCopy.hpcSearchTypeCode === 'All'){
        set(searchConditionCopy, 'hpcSearchTypeCode', null);
      }
      set(searchConditionCopy, 'skipIndex', this.get('dataPage'));
      set(searchConditionCopy, 'takeCount', this.get('takeCount'));
      return searchConditionCopy;
    },
    async _saveSearchConditions() {
      try{
        const searchCondition = this.get('searchCondition');
        await this.get('co_PersonalizationService').setSettingInfo(`specimen-check-in-refer-list`, JSON.stringify({conditionData: [searchCondition]}), '위탁검체 조회 설정 저장');
      }catch(e) {
        this.showResponseMessage(e);
      }
    },

    _getReferList(){
      const searchCondition = this.get('searchCondition');
      if(this.get('isInitGridShow')){
        return;
      }
      this.set('isResultGridShow', true);

      return this.create(this.get('defaultUrl') + 'specimen-examination-worklists/consigned-agency', null, this._getParam()).then(function(res){
        this.set('isResultGridShow', false);
        this.get('co_PersonalizationService').setSettingInfo(`specimen-check-in-refer-list`, JSON.stringify({conditionData: [searchCondition]}), '위탁검체 조회 설정 저장');
        if(isEmpty(res)){
          this.set('consignedAgencyGridItemsSource', null);
          return;
        }

        res.forEach(e=>{
          set(e, 'orderNameTooltip', e.examination.displayCode +', ' + e.examination.name);
          if(isPresent(e.subject) && (e.subject.isPrivacyProtection || e.subject.isProtectionHealthInfo)) {
            set(e, 'isShowIconProtect', true);
          }
        });
        this.set('consignedAgencyGridItemsSource', res);
      }.bind(this)).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    _catchError(e){
      console.log(e);
      this.set('isInitGridShow', false);
      this.set('isResultGridShow',false);
      this.showResponseMessage(e);
    }

  });