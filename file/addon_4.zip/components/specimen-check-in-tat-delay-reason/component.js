/* eslint-disable no-console */
import { isPresent, isEmpty } from '@ember/utils';
import { computed, observer } from '@ember/object';
// import { inject as service } from '@ember/service';
// import { next } from '@ember/runloop';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'specimencheckin-module/app-config';
import { getOwner } from '@ember/application';
import specimencheckinPrintMixin from 'specimencheckin-module/mixins/specimen-check-in-print-mixin';
import specimencheckinMessageMixin from 'specimencheckin-module/mixins/specimen-check-in-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,specimencheckinPrintMixin, specimencheckinMessageMixin,
  {
    layout,
    isSaveClick: false,
    reasonContent: null,
    isNotEtc: true,
    // specimenCheckinService: service('specimen-check-in-service'),
    specimenCheckinService: computed(function () {
      return getOwner(this).lookup('service:specimen-check-in-service');
    }),

    isSaveClickChanged: observer('isSaveClick', function() {
      if(this.get('isSaveClick') === true) {
        this._entryReason();
      }
    }),

    defaultUrl: null,
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-check-in-tat-delay-reason');
      this.setStateProperties([
        'defaultUrl',
      ]);
      if (this.hasState() === false) {
      //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimencheckin') + `specimen-checkin/${config.version}/`);
        this.set('currentUser', this.get('co_CurrentUserService.user'));
        this.set('isNotEtc', true);
      }
    //Initialize Stateless properties
    },

    onLoaded(){
      this._super(...arguments);
      if(isPresent(this.get('specimens')) && this.get('specimens.length') !== 1) {
        this._getReasonList();
      } else {
        this._getDelayReason();
      }
    },

    // 4. Actions Area
    actions: {
      onLoadCombobox(e){
        this.set('combobox', e.source);
      },
      onReasonChanged(e) {
        this.set('selectedReason', e.item.code);
        if(e.item.code.indexOf('999') > -1) {
          this.set('isNotEtc', false);
        } else {
          this.set('isNotEtc', true);
          this.set('reasonContent', null);
        }
        //
      },
    },
    // 5. Private methods Area
    async _getReasonList() {
      try {
        const result = await this.getList(this.get('defaultUrl') + 'business-codes/search', {classificationCode: 'TatDelayReason'}, null);
        this.set('reasonList', result);
        if(isPresent(result)) {
          const reasonId = isEmpty(this.get('savedReasonItem')) ? result[0].code : this.get('savedReasonItem.reasonId');
          this.set('selectedReason', reasonId);
        }
      }catch(e) {
        this._catchError(e);
      }
    },
    async _getDelayReason() {
      const params = {
        specimenId: this.get('specimenId'),
        checkinId: this.get('checkInId'),
      };
      try {
        const result = await this.getList(this.get('defaultUrl') + 'specimen-checkins/observation-delay-specimens', params, null);
        if(isPresent(result)) {
          this.set('savedReasonItem', result);
          if(result.reasonId.indexOf('999') > -1) {
            this.set('isNotEtc', false);
            this.set('reasonContent', result.reasonContent);
          }
          // if(this.get('selectedItemCB')) {
          //   this.get('selectedItemCB')();
          // }
        }
        this._getReasonList();
      }catch(e) {
        this._catchError(e);
      }
    },

    async _entryReason() {
      try {
        let specimens = this.get('specimens');
        if(isEmpty(this.get('specimens'))) {
          specimens = [{
            specimenId: this.get('specimenId'),
            checkinId: this.get('checkInId'),
          }];
        }
        const params = {
          specimens: specimens,
          registrationDatetime: this.get('co_CommonService').getNow(),
          registrationStaffId: this.get('currentUser.employeeId'),
          reasonId: this.get('selectedReason'),
          reasonContent: isEmpty(this.get('reasonContent')) ? this.get('combobox.selectedItem.name') : this.get('reasonContent')
        };
        await this.create(this.get('defaultUrl') + 'specimen-checkins/observation-delay-specimens', null, params);
        if(isPresent(this.get('saveSuccessCB'))) {
          this.get('saveSuccessCB')();
        }
      } catch(e) {
        this._catchError(e);
      }
    },

    _catchError(e){
      this.set('isSaveClick', false);
      this.set('isGridShow', false);
      this.showResponseMessage(e);
    }
  });