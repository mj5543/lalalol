/* eslint-disable max-lines */
/* eslint-disable no-console */
import { later } from '@ember/runloop';
import $ from 'jquery';
// import { set } from '@ember/object';
import { isEmpty, compare, isPresent } from '@ember/utils';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import specimencheckinMessageMixin from 'specimencheckin-module/mixins/specimen-check-in-message-mixin';
export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, specimencheckinMessageMixin,
  {
    specimenCheckinService: service('specimen-check-in-service'),
    layout,
    // 2. Property Area
    defaultUrl: null,
    popupInfo: null,
    popupReturn: null,
    examinationCategoryListItems: null,
    examinationCategoryListSelectedItem: null,
    examinationUnitListItems: null,
    examinationUnitListSelectedItem: null,
    examinationListItems: null,
    examinationListSelectedItem: null,
    examinationCategoryTagItems: null,
    examinationUnitTagItems: null,
    examinationText: null,
    examinationTagItems: null,
    examinationTagNameText: null,
    savedSettingGridColumns: null,
    savedSettingGridItems: null,
    savedSettingSelectedItem: null,
    savedSettingParams: null,
    conditionInfo: null,

    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId', 'specimen-check-in-work-list-find-setting');
      this.setStateProperties([
        'defaultUrl',
        'popupReturn',
        'examinationCategoryListItems',
        'examinationCategoryListSelectedItem',
        'examinationUnitListItems',
        'examinationUnitListSelectedItem',
        'examinationListItems',
        'examinationListSelectedItem',
        'examinationText',
        'examinationCategoryTagItems',
        'examinationUnitTagItems',
        'examinationTagItems',
        'examinationTagNameText',
        'savedSettingGridColumns',
        'savedSettingGridItems',
        'savedSettingSelectedItem',
        'savedSettingParams',
        'conditionInfo'
      ]);
      if (this.hasState() === false) {
        //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimencheckin')
        + `specimen-checkin/v0/`);
        this.set('popupReturn', {});

        this.set('savedSettingGridColumns',[
          { title: this.getLanguageResource('3718', 'F','세트'), field: 'name', align: 'left'},
          { title: this.getLanguageResource('3368', 'F','삭제'), bodyTemplateName: 'command', align: 'center', width: 60}
        ]);
        this.set('savedSettingParams', {});
        this._initTagList();
      }
    },

    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'wp100');

      if (this.hasState() === false) {
        this._setExaminationCategoryList();
        this._setSavedSettingGrid();

        //Test용.. 나중에 지워야됨!!!!
        if(this.get('popupInfo') === null){
          this.set('popupInfo', {});
          this.set('popupInfo.isOpen', true);
        }
      }
    },

    actions: {
      onSavedSettingGridLoad(e){
        this.set('savedSettingGrid', e.source);
      },
      onInitializeClick(){
        this._initializeClick();
      },

      onExaminationCategoryChanged(){
        this.set('isExamListboxShow', true);
        this._setExaminationUnitList();
      },
      onExaminationUnitChanged(){
        this._setExaminationList();
      },
      onExaminationChanged(){
        this.set('examinationText', null);
      },
      onExaminationTextSearch(){
        this._matchExaminationList();
      },
      onExaminationTextCommit(){
        this._matchExaminationList();
      },
      //Tag Save 이벤트
      onTagItemsSave() {
        // Tag가 1개이상 지정되어있고 이름이 지정되어 있어야함.
        if(this.get('tagList').length === 0){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('8945', 'F','필수값을 입력하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        if ((this.get('examinationTagNameText') === null) || (this.get('examinationTagNameText') === '')){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('8945', 'F','필수값을 입력하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        this._setSavedSettingParamsForCreate();
        //overview의 examset 콤보박스 재조회
        this.set('examSetRefresh', true);
        // this.toggleProperty('examSetRefresh');
      },
      onSetGridSelectionChanged(){
        const savedSettingSelectedItem = this.get('savedSettingSelectedItem');
        if (isEmpty(savedSettingSelectedItem)){
          return;
        }
        this._initTagList();
        this.set('examinationTagNameText', savedSettingSelectedItem.name);
        for(const k in savedSettingSelectedItem.property) {
          const items = savedSettingSelectedItem.property[k];
          if(isPresent(items)) {
            items.forEach(item => {
              this._addTagItems(this._getTagItemsType(k), item);
            });
          }
        }
      },
      onDeleteSavedSettingItems(item){
        //isValidDataRow = false로 update
        this._setSavedSettingParamsForUpdate(false, item.displaySequence, item);
      },
      onSavedSettingGridItemDragEnd(){
        this._updateSettingItemsSequence();
      },
      //최종선택 되어있는 Tag 전달해주기 (OverView)
      onTagItemsSelect(){
        this.set('popupReturn.tagName', this.get('examinationTagNameText'));
        this.set('popupReturn.tagList', this.get('tagList'));
        const savedSettingSelectedItem = this.get('savedSettingSelectedItem');
        let returnConfigId = null;
        if(!isEmpty(savedSettingSelectedItem)){
          if(!isEmpty(this.get('tagList'))){
            //set에서 선택된 아이템이 있을경우 examinationTagList와 비교해서 확인
            if(this._getCompareTagListIds(savedSettingSelectedItem) === 0){
              returnConfigId = this.get('savedSettingSelectedItem.workListFindConfigurationId');
            }
          }
        }
        this.set('popupReturn.workListFindConfigurationId', returnConfigId);
        this.set('popupReturn.isSelectionConfirmCB', true);
        this.get('findSettingCB')(this.get('popupReturn'));
        this.set('popupInfo.isOpen', false);
      },

      onPopupOpenedAction(){
        this.set('isPopupLoaderShow', true);
        this.set('popupReturn.isSelectionConfirmCB', false);
        this.set('examinationUnitListItems', []);
        this.set('examinationListItems', []);
        this.set('examSetRefresh', false);
        $('#examSearchText').on('input', this._matchExaminationList.bind(this));
        this._setPopupOpendDatas();
      },

      onPopupClosedAction(){
        $('#examSearchText').off('input', this._matchExaminationList.bind(this));
        this.set('examinationText', null);
        //2020.11.11 검색기능 개선으로 'closedCB' 주석처리함.
        // if(!isEmpty(this.get('closedCB'))){
        //   this.get('closedCB')(this.get('savedSettingSelectedItem'), this.get('tagList'));
        // }
        this._initializeSettingGrid();
      },
      onAddDbClick(type, e) {
        if (isEmpty(e)) {
          return;
        }
        this._addTagItems(type, e.item);
      },
      onGroupDeletedTagClick(type) {
        this._deleteTagItems(type);
      },
      onDeletedTagClick(item, type) {
        this._deleteTagItems(type, item);
      },
      onTagResetClick(){
        this._initTagList();
      }
    },
    _initializeSettingGrid(){
      this.set('savedSettingSelectedItem', null);
      this.set('examinationTagNameText', null);
    },

    _initializeClick(){
      this.set('examinationTagNameText', null);
      this._initTagList();
      this._setExaminationCategoryList();
      this._setSavedSettingGrid();
    },

    _initTagList(){
      this.set('conditionInfo', {});
      this.set('tagList', []);
    },

    _setPopupOpendDatas() {
      const savedSettingSelectedItem = this.get('examinationTagNameSelectedItem');
      if(isEmpty(savedSettingSelectedItem)) {
        //선택된 부모창의 tag list
        const examinationTagList = this.get('examinationTagList');
        if(this.get('mode') === 'overview' && isPresent(examinationTagList)){
          const newTagList = [];
          if(!isEmpty(examinationTagList)){
            examinationTagList.forEach(e=>{
              if(!isEmpty(e.items)){
                newTagList.addObject(e);
              }
            });
          }
          this.set('tagList', newTagList);
        }
        later(() => {
          this.set('examinationCategoryListSelectedItem', null);
          this.set('conditionInfo', {});
          if(!isEmpty(this.get('tagList'))){
            this.get('tagList').forEach(element=>{
              if(!isEmpty(element.items)){
                element.items.forEach(item=>{
                  this._addTagItems(element.type, item);
                });
              }
            });
          }
          this.set('isPopupLoaderShow', false);
        });
      } else {
        this.set('examinationTagNameText', savedSettingSelectedItem.name);
      }
      //설정팝업 오픈 시 세트설정 재조회
      this._setSavedSettingGrid();
    },

    async _setExaminationCategoryList(){
      try {
        const path = this.get('defaultUrl') + 'classifications/search';
        const params = {selectedOption: 0, classificationType: 1};
        const result = await this.getList(path, params, null, false);
        this.set('examinationCategoryListItems', result);
        this.set('examinationCategoryListSelectedItem', result.get('firstObject'));
      } catch(e) {
        this._catchError(e);
      }
    },
    async _setExaminationUnitList() {
      try {
        this.set('examinationText', null);
        const path = this.get('defaultUrl') + 'unitworks/search';
        const params = {
          classificationIds: [this.get('examinationCategoryListSelectedItem.classificationId')],
          searchKey: '',
          isAllIncluded:false
        };
        const result = await this.getList(path, null, params, false);
        this.set('examinationUnitListItems', result);
        this.set('examinationUnitListSelectedItem', result.get('firstObject'));
        this.set('isExamListboxShow',false);
      } catch(e) {
        this._catchError(e);
      }
    },
    async _setExaminationList() {
      try {
        this.set('examinationText', null);
        const path = this.get('defaultUrl') + 'specimen-examinations/search';
        const params = {
          classificationIds: [this.get('examinationCategoryListSelectedItem.classificationId')],
          unitWorkIds: [this.get('examinationUnitListSelectedItem.id')],
          isAllIncluded: false
        };
        const result = await this.getList(path, null, params, false);
        this.set('examinationListItems', result);
        this.set('examinationListItemsCopy', result);
        // this.set('examinationListSelectedItem', result.examinationListItems.get('firstObject'));
        this.set('isExamListboxShow', false);
      } catch(e) {
        this._catchError(e);
      }
    },
    //세트설정 Grid
    async _setSavedSettingGrid(index){
      try {
        const params = {staffId: this.get('co_CurrentUserService.user.employeeId')};
        const res = await this.getList(this.get('defaultUrl') + 'worklist-configurations/search', params, null, false);
        if(isEmpty(res)){
          this.set('examinationTagNameText', null);
          this.set('savedSettingSelectedItem',null);
          this.set('isPopupLoaderShow', false);
          this.set('savedSettingGridItems', null);
          return;
        }
        res.map(d => {
          d.name = d.displayName;
        });
        this.set('savedSettingGridItems', res);
        if(!isEmpty(index)){
          const findItem = res.find(d => d.displaySequence === index);
          this.set('savedSettingSelectedItem', findItem);
          this._callbackSettings(findItem.workListFindConfigurationId);
        } else if(this.get('isPopupLoaderShow') && isPresent(this.get('examinationTagNameSelectedItem'))) {
          const targetSelectItem = res.findBy('workListFindConfigurationId', this.get('examinationTagNameSelectedItem.workListFindConfigurationId'));
          this.set('savedSettingSelectedItem', targetSelectItem);
          this._initTagList();
          this.set('examinationTagNameText', targetSelectItem.displayName);
          this.set('examinationCategoryListSelectedItem', null);
          this.set('isPopupLoaderShow', false);
        }
      } catch(e) {
        this._catchError(e);
      }
    },

    async _setSavedSettingParamsForCreate(){
      try {
        let promise = null;
        let isCreateItem = false;
        let displaySequence = 1;
        const path = this.get('defaultUrl') + 'worklist-configurations';
        const currentSelectedSetItem = this.get('savedSettingSelectedItem');
        const currentGridItems = this.get('savedSettingGridItems');
        this.set('savedSettingParams', {});
        this.set('savedSettingParams.staffId', this.get('co_CurrentUserService.user.employeeId'));
        this.set('savedSettingParams.displayName', this.get('examinationTagNameText'));
        if(isPresent(currentGridItems)){
          displaySequence = currentGridItems.get('lastObject').displaySequence + 1;
        }
        this._setCurrentTagForCreate();
        if (isEmpty(currentSelectedSetItem)){
          isCreateItem = true;
          this.set('savedSettingParams.displaySequence', displaySequence);
          promise = this.create(path, null, this.get('savedSettingParams'));
        }else{
          promise = this.get('specimenCheckinService')._showMessage(`${currentSelectedSetItem.name} ${this.getLanguageResource('15446', 'F', null, '세트를 수정하시겠습니까?')}`, 'question', 'YesNo', 'Yes', '', null);
        }
        if(isCreateItem) {
          //세트등록
          await promise;
          this.get('specimenCheckinService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
          this._setSavedSettingGrid(displaySequence);
        } else {
          //세트수정
          const mesaggeResult = await promise;
          if(mesaggeResult === 'Yes') {
            this.set('isPopupLoaderShow', true);
            this.set('savedSettingParams.displaySequence', currentSelectedSetItem.displaySequence);
            this.set('savedSettingParams.workListFindConfigurationId', currentSelectedSetItem.workListFindConfigurationId);
            this.set('savedSettingParams.isValidDataRow', true);
            await this.update(path, null, false, this.get('savedSettingParams'));
            this.get('specimenCheckinService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
            this._setSavedSettingGrid(currentSelectedSetItem.displaySequence);
          }
        }
        this.set('isPopupLoaderShow', false);
      } catch(e) {
        this._catchError(e);
      }
    },

    async _setSavedSettingParamsForUpdate(isValidDataRow, displaySequence, item){
      try {
        const path = this.get('defaultUrl') + 'worklist-configurations';
        this.set('savedSettingParams',{});
        this.set('savedSettingParams.workListFindConfigurationId', item.workListFindConfigurationId);
        this.set('savedSettingParams.staffId', this.get('co_CurrentUserService.user.employeeId'));
        this.set('savedSettingParams.displayName', item.name);
        //시퀀스는 받아온걸로 따로 매겨줌..
        this.set('savedSettingParams.displaySequence', displaySequence);
        this.set('savedSettingParams.property', {});
        if(!isEmpty(item.property.classifications)){
          this.set('savedSettingParams.property.classificationId', item.property.classifications.mapBy('id'));
        }
        if(!isEmpty(item.property.unitWorks)){
          this.set('savedSettingParams.property.unitWorkId', item.property.unitWorks.mapBy('id'));
        }
        if(!isEmpty(item.property.observationExaminations)){
          this.set('savedSettingParams.property.observationExaminationId', item.property.observationExaminations.mapBy('id'));
        }
        //삭제여부도 받아온걸로 따로 매겨줌..
        this.set('savedSettingParams.isValidDataRow', isValidDataRow);
        const promise = await this.update(path, null, false, this.get('savedSettingParams'));
        if(isValidDataRow) {
          //시퀀스(순서변경)
          await promise;
        } else {
          //삭제
          const messageResult = await this.get('specimenCheckinService')._showMessage(`${item.name} ${this.getLanguageResource('11669', 'F', null, '삭제 하시겠습니까?')}`, 'question', 'YesNo', 'Yes', '', null);
          if(messageResult === 'Yes') {
            this.set('isSavedSettingGridShow', true);
            await promise;
            this.get('specimenCheckinService').onShowToast('delete', this.getLanguageResource('8944', 'F', 'Deleted'), '');
            this.set('isSavedSettingGridShow', false);
            this._callbackSettings(null);
          }
        }
      } catch(e) {
        this._catchError(e);
      }
    },
    //2020.11.12 업데이트 할 때마다 조회 api 호출하고 있었음.로직 변경 추가.
    async _updateSettingItemsSequence() {
      try {
        this.set('isPopupLoaderShow', true);
        await Promise.all(
          this.get('savedSettingGridItems').map(async (item, i) => {
            await this._setSavedSettingParamsForUpdate(true, i + 1, item);
          })
        );
        this.get('specimenCheckinService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
        this.set('isPopupLoaderShow', false);
        this._initializeClick();
      } catch(e) {
        this._catchError(e);
      }
    },
    _setTagList() {
      const newConditionList = [];
      const conditionInfo = this.get('conditionInfo');
      this.set('tagList', []);
      if (!isEmpty(conditionInfo.selectedCategoryList)) {
        newConditionList.push({type: 'category', items: conditionInfo.selectedCategoryList});
      }
      if (!isEmpty(conditionInfo.selectedUnitList)) {
        newConditionList.push({type: 'unit', items: conditionInfo.selectedUnitList});
      }
      if (!isEmpty(conditionInfo.selectedExamList)) {
        newConditionList.push({type: 'exam', items: conditionInfo.selectedExamList});
      }
      this.set('tagList', newConditionList);
    },
    _filterExaminationTagList(workListFindConfigurationId, property){
      const filterdExaminationTagList = [];
      filterdExaminationTagList.workListFindConfigurationId = workListFindConfigurationId;
      for(const k in property) {
        const items = property[k];
        if(isPresent(items)) {
          items.forEach(element => {
            filterdExaminationTagList.push({
              id: element.id,
              name: element.name,
              abbreviation: element.abbreviation,
              type: this._getTagItemsType(k)});
          });
        }
      }
      return filterdExaminationTagList;
    },
    _getTagItemsType(prop) {
      switch(prop) {
        case 'classifications':
          //검사분류
          return 'category';
        case 'unitWorks':
          //작업단위
          return 'unit';
        case 'observationExaminations':
          //검사항목
          return 'exam';
        default:
      }
    },
    _matchExaminationList(e){
      if(isEmpty(this.get('examinationListItemsCopy')) || isEmpty(e)){
        return;
      }
      const arr=[];
      if(isEmpty(e.target.value)){
        this.set('examinationListItems', this.get('examinationListItemsCopy'));
      }
      this.get('examinationListItemsCopy').forEach(element => {
        if(element.displayCode.toUpperCase().includes(e.target.value.toUpperCase()) ||
           element.name.toUpperCase().includes(e.target.value.toUpperCase())){
          arr.addObject(element);
          //매칭되면 아래에 tag추가해줌..
        }
        this.set('examinationListItems', arr);
      });
    },

    _addTagItems(type, e){
      if (isEmpty(e)) {
        return;
      }
      const targetList = this._getSelectionsProperty(type);
      if (isEmpty(this.get(`conditionInfo.${targetList}`))) {
        this.set(`conditionInfo.${targetList}`, []);
      }
      if (type === 'category') {
        if( (!isEmpty(e.classificationId) && !isEmpty(this.get('conditionInfo.selectedCategoryList').findBy('id', e.classificationId)))
         || (!isEmpty(e.id) && !isEmpty(this.get('conditionInfo.selectedCategoryList').findBy('id', e.id)))){
          //항목 이미 있는경우
          this.get('specimenCheckinService').onShowToast('error', this.getLanguageResource('9842', 'F', '중복데이터가 있습니다'), '');
          return;
        }
        this.get('conditionInfo.selectedCategoryList').push({
          id: isEmpty(e.classificationId) ? e.id: e.classificationId,
          name: e.name,
          abbreviation: e.abbreviation
        });
      } else if (type === 'unit') {
        if(!isEmpty(this.get('conditionInfo.selectedUnitList').findBy('id', e.id))){
          this.get('specimenCheckinService').onShowToast('error', this.getLanguageResource('9842', 'F', '중복데이터가 있습니다'), '');
          return;
        }
        this.get('conditionInfo.selectedUnitList').push({
          //abbreviation 없음
          id: e.id,
          name: e.name
        });
      } else if (type === 'exam') {
        if(!isEmpty(this.get('conditionInfo.selectedExamList').findBy('id', e.id))){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9226', 'F','이미 추가되어있습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        this.get('conditionInfo.selectedExamList').push({
          id: e.id,
          name: e.name,
          abbreviation: e.abbreviation
        });
      }
      this._setTagList();
    },
    _deleteTagItems(type, item) {
      const targetList = this._getSelectionsProperty(type);
      if(isPresent(item)) {
        const selectedItem = this.get(`conditionInfo.${targetList}`).find(d => d.id === item.id);
        this.get(`conditionInfo.${targetList}`).removeObject(selectedItem);
      } else {
        this.set(`conditionInfo.${targetList}`, []);
      }
      this._setTagList();
    },
    _getSelectionsProperty(type) {
      //type: category, unit, exam
      return `selected${type.charAt(0).toUpperCase() + type.slice(1)}List`;
    },
    _callbackSettings(configId) {
      this.set('popupReturn.tagName', this.get('examinationTagNameText'));
      this.set('popupReturn.tagList', this.get('tagList'));
      let returnConfigId = null;
      const selectedSettingsItem = this.get('savedSettingSelectedItem');
      const parentSelectedSettingsItem = this.get('examinationTagNameSelectedItem');
      if(!isEmpty(selectedSettingsItem)){
        if(!isEmpty(this.get('tagList'))){
          //set에서 선택된 아이템이 있을경우 examinationTagList와 비교해서 확인
          if(this._getCompareTagListIds(selectedSettingsItem) === 0){
            returnConfigId = selectedSettingsItem.workListFindConfigurationId;
          }else{
            returnConfigId = configId;
          }
          if(isPresent(parentSelectedSettingsItem) && parentSelectedSettingsItem.workListFindConfigurationId === configId) {
            this.set('popupInfo.isOpen', false);
            this.set('isPopupLoaderShow', false);
          }
        }
      }
      this.set('popupReturn.workListFindConfigurationId', returnConfigId);
      this.get('findSettingCB')(this.get('popupReturn'));
    },
    _getCompareTagListIds(settingItem) {
      const filterdExaminationTagList = this._filterExaminationTagList(
        settingItem.workListFindConfigurationId,
        settingItem.property);
      const compareIds = this.get('tagList')
        .map(e => e.items)
        .map(d => d.mapBy('id'));
      return compare(filterdExaminationTagList.mapBy('id').sort(), compareIds.flat().sort());
    },
    _setCurrentTagForCreate(){
      this.set('savedSettingParams.property', {});
      const selectedCategoryList = this.get('conditionInfo.selectedCategoryList');
      const selectedUnitList = this.get('conditionInfo.selectedUnitList');
      const selectedExamList = this.get('conditionInfo.selectedExamList');
      let classificationIds = [];
      let unitWorkIds = [];
      let observationExaminationIds = [];
      if(isPresent(selectedCategoryList)){
        classificationIds = selectedCategoryList.mapBy('id');
      }
      if(isPresent(selectedUnitList)){
        unitWorkIds = selectedUnitList.mapBy('id');
      }
      if(isPresent(selectedExamList)){
        observationExaminationIds = selectedExamList.mapBy('id');
      }
      this.set('savedSettingParams.property.classificationId', classificationIds);
      this.set('savedSettingParams.property.unitWorkId', unitWorkIds);
      this.set('savedSettingParams.property.observationExaminationId', observationExaminationIds);
    },
    _catchError(e){
      console.log(e);
      this.set('isPopupLoaderShow',false);
      this.set('isExamListboxShow',false);
      this.set('isSavedSettingGridShow',false);
      this.showResponseMessage(e);
    }
  });