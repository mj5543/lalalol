/* eslint-disable max-lines */
/* eslint-disable no-console */
import { next } from '@ember/runloop';
import { hash } from 'rsvp';
import { A } from '@ember/array';
import { isEmpty, compare, isPresent } from '@ember/utils';
import EmberObject, { computed, set, get } from '@ember/object';
import { inject as service } from '@ember/service';
import layout from './template';
import $ from 'jquery';
import CHIS from 'framework/chis-framework';
import specimencheckinPrintMixin from 'specimencheckin-module/mixins/specimen-check-in-print-mixin';
import specimencheckinMessageMixin from 'specimencheckin-module/mixins/specimen-check-in-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  specimencheckinPrintMixin,specimencheckinMessageMixin,
  {
    specimenCheckinService: service('specimen-check-in-service'),
    specimenSamplingService: service('specimen-sampling-service'),
    layout,
    // 2. Property Area
    defaultUrl: null,
    checkInTypeItems: null,
    dxListColumns: null,
    isAutoCheckIn: null,
    examListColumns: null,
    examDateSelectedDate: null,
    specimenNumber: null,
    specimenInfo: null,
    checkinInfoListColumns: null,
    checkinInfoListItemsSource: null,
    checkInNumber: null,
    checkInTime: null,
    isReasonsModalOpen: null,
    reasonsNameDisabled: null,
    selectedItems: null,
    subjectNumber: null,
    inappropriateReasonsSelectedItem: null,
    inappropriateReasonsDisabled: null,
    inappropriateReasonsInputDisabled: null,
    inappropriateReasonsnInputName: null,
    checkInId: null,
    isExamDateError: null,
    isExamDateShowTodayButton: null,
    currentUser: null,
    isSpecimenConfirm: false,
    isSettingOpen: false,
    patientGenderAge: computed('specimenInfo', function() {
      if(isEmpty(this.get('specimenInfo'))){
        return;
      }
      const res= this.get('specimenInfo').subjectGender + ' / ' + this.get('specimenInfo').age;
      return res;
    }),
    specimenInfoReferred: null,
    timer: null,
    initializeTimeVolume: null,
    printPopup:null,
    printConfig:null,
    printContent:null,
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-check-in-specimen-check-in');
      //Set Stateful properties
      this.setStateProperties([
        'defaultUrl',
        'menuClass',
        'checkInTypeItems',
        'dxListColumns',
        'examListColumns',
        'checkinInfoListColumns',
        'examListItemsSource',
        'dxListItemsSource',
        'checkinInfoListItemsSource',
        'examDateSelectedDate',
        'isAutoCheckIn',
        'isAutoPrint',
        'specimenNumber',
        'checkInNumber',
        'checkInTime',
        'isReasonsModalOpen',
        'reasonId',
        'reasonName',
        'subjectNumber',
        'specimenInfo',
        'isExamDateError',
        'isExamDateShowTodayButton',
        'currentUser',
        'specimenInfoReferred',
        'rejectReasonsItemsSource',
        'inappropriateReasonsItemsSource',
        'isSpecimenNumberDisabled',
        'examTypeItemsSource'
      ]);

      if (this.hasState() === false) {
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimencheckin') + `specimen-checkin/v0/`);
        this.set('samplingUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimensampling') + `specimen-sampling/v0/`);
        this.set('currentUser', this.get('co_CurrentUserService.user'));
        this.set('checkInTypeItems', [{ selected : false, text : 'Auto', value : '1'}, { selected : false, text : 'Manual', value : '2'}]);
        this._setGridColumns();
        this.set('isAutoCheckIn', true);
        this.set('isAutoPrint', false);
        this.set('examDateSelectedDate', this.get('co_CommonService').getNow());
        this.set('currentTime', this.get('co_CommonService').getNow());
        this.set('selectedItems', A());
        this.set('isReasonsModalOpen', false);
        this.set('checkinInfoListItemsSource', A());
        this.set('isExamDateError', false);
        this.set('isExamDateShowTodayButton', false);
        this.set('printPopup', false);
        this.getPrinterName().then(function(res){
          this.set('printSetting', res);
        }.bind(this)).catch(function(error) {
          this._catchError(error);
        }.bind(this));
      }
    },

    _setGridColumns(){
      this.set('dxListColumns', [
        { field: 'standardDisplayCode', title: this.getLanguageResource('7106', 'F','Diagnosis Code'), bodyTemplateName: 'tooltip', width:95},
        { field: 'diseaseTermName', title: this.getLanguageResource('9601', 'F','진단명'), bodyTemplateName: 'tooltip'},
        { field: 'registrationDate', title: this.getLanguageResource('7105', 'F','Diagnosis Date'), width:95, type: 'date', dataFormat: 'd'}
      ]);
      this.set('examListColumns', [
        { field: 'orderCode', title: this.getLanguageResource('16919', 'S','Exam Code'), width:90},
        { field: 'orderName', title: this.getLanguageResource('16920', 'S','Exam Name'), bodyTemplateName: 'tooltip'},
      ]);
      this.set('checkinInfoListColumns', [
        this._setPointColumns(),
        { field: 'classificationName', title: this.getLanguageResource('16892', 'S','Exam.Type'), width:100, bodyTemplateName: 'tooltip'},
        { field: 'checkInNumber', title: this.getLanguageResource('6767', 'S','Check-in No.'), headerTemplateName: 'barcolor02', bodyTemplateName: 'colfont',align: 'center', width:100},
        { field: 'subjectName', title: this.getLanguageResource('16881', 'F','Pt Name'), bodyTemplateName: 'boldTooltip',align: 'center', width:90},
        { field: 'subjectNumber', title: this.getLanguageResource('14851', 'F','MRN'), bodyTemplateName: 'bold',align: 'center', width:70},
        { field: 'specimenTypeName', title: this.getLanguageResource('16921', 'S','Specimen Name'), width:145, headerTemplateName: 'barcolor01', bodyTemplateName: 'colfontTooltip' },
        { field: 'issuedDepartmentCode', title: this.getLanguageResource('8827', 'S','발행처'),align: 'center', width: 100, bodyTemplateName: 'tooltip'},
        // { field: 'issuedDepartmentCode', title: this.getLanguageResource('3325', 'S','현위치'),align: 'center', width: 90, bodyTemplateName: 'tooltip'},
        { field: 'departmentCode', title: this.getLanguageResource('7111', 'S','진료과'),align: 'center', width: 100, bodyTemplateName: 'tooltip'},
        { field: 'orderedStaffName', title: this.getLanguageResource('9686', 'S','처방의'), align: 'center',width: 90, bodyTemplateName: 'tooltip'},
        { field: 'specimenNumber', title: this.getLanguageResource('859', 'S','Specimen No.'), headerTemplateName: 'barcolor02', bodyTemplateName: 'colfont', width:95, align: 'center' },
        { field: 'orderDate', title: this.getLanguageResource('5246', 'F','Order Date'), type: 'date', dataFormat: 'd', width:90 },
        { field: 'comments', title: this.getLanguageResource('16922', 'F','Comments'), bodyTemplateName: 'tooltip' }
      ]);
    },
    _setPointColumns(){
      return {field: '', title: this.getLanguageResource('3813', 'S','속성'), width: 60, readOnly: true, bodyTemplateName: 'icon', align: 'center',
        onBodyCellRender: function (context) {
          if(!isEmpty(context.item.point)){
            set(context.cellComponent, 'description', `${get(context.item, 'point')}`);
            set(context.cellComponent, 'descriptionStyle', 'font-weight: bold; width: 90px;');
          }
        }
      };
    },
    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1360');
      if (this.hasState() === false) {
        const defaultUrl= this.get('defaultUrl');
        this._getSettingInfo();
        hash({
          businessCodes: this.getList(defaultUrl + 'business-codes/search', null,{classificationCodes: ['CheckInRejectReason','InappropriateSpecimenReason','ObservationCancelReason']}, false),
          examTypeItemsSource: this.getList(defaultUrl + 'classifications/search', {selectedOption: 'EncounterTypeCode', classificationType: 1}, null),
        }).then(function(result){
          const specimenRejectReasonsItemsSource= [];
          const inappropriateReasonsItemsSource= [];
          const observationCancelReasonItemsSource= [];
          result.businessCodes.forEach(e=>{
            if(e.classificationCode == 'CheckInRejectReason'){
              specimenRejectReasonsItemsSource.addObject(e);
            }else if(e.classificationCode == 'InappropriateSpecimenReason'){
              inappropriateReasonsItemsSource.addObject(e);
            }else if(e.classificationCode == 'ObservationCancelReason'){
              observationCancelReasonItemsSource.addObject(e);
            }
          });
          if(!isEmpty(result.examTypeItemsSource)){
            result.examTypeItemsSource.insertAt(result.examTypeItemsSource.length, {displayCode: 'All', classificationId: 'All', name: this.getLanguageResource('6700', 'F', '', '전체')});
          }
          this.set('examTypeItemsSource', result.examTypeItemsSource);
          // this.set('examTypeSelectedItem', result.examTypeItemsSource.get('firstObject'));
          this.set('specimenRejectReasonsItemsSource', specimenRejectReasonsItemsSource);
          this.set('inappropriateReasonsItemsSource', inappropriateReasonsItemsSource);
          this.set('observationCancelReasonItemsSource', observationCancelReasonItemsSource);
          this.get('co_PersonalizationService').getSettingInfo(`specimen-check-in-specimen-check-in`).then(settingInfo => {
            if(isEmpty(settingInfo.settingValue)){
              this.set('examTypeSelectedItem', result.examTypeItemsSource.get('firstObject'));
            }else{
              const data = JSON.parse(settingInfo.settingValue);
              if(isEmpty(data)){
                this.set('examTypeSelectedItem', result.examTypeItemsSource.get('firstObject'));
              }else if(!isEmpty(data.examTypeSelectedItem)){
                next(this, function(){
                  this.set('examTypeSelectedItem', data.examTypeSelectedItem);
                }.bind(this));
              }else{
                this.set('examTypeSelectedItem', result.examTypeItemsSource.get('firstObject'));
              }
            }
          });

        }.bind(this)).catch(function(e){
          this._catchError(e);
        }.bind(this));
      }
    },

    // didInsertElement() {
    //   this._super(...arguments);
    //   this.$('[name*="checkInSpecimenNumber"] input').select();
    // },

    // 4. Actions Area
    actions: {
      onNumberInputLoaded(e) {
        this.set('inputSource', e.source);
      },
      onSettingClick() {
        this.set('isSettingOpen', true);
      },
      onSpecimenConfirmSave() {
        this._setSettingInfo();
      },
      onExePrintAfterCB(){
        this._print();
      },
      onExamTypeChangedAction(e){
        this.get('co_PersonalizationService').setSettingInfo(`specimen-check-in-specimen-check-in`,
          JSON.stringify({
            examTypeSelectedItem: e.item
          }), '검체접수 설정 저장');
      },

      onSpecimenNumberTextCommit(){
        if(!isEmpty(this.get('timer'))){
          clearTimeout(this.get('timer'));
        }
        if(isEmpty(this.get('specimenNumber'))){
          // this._showMessage(this.getLanguageResource('10105', 'F', '검체번호를 확인하세요.'), 'warning', 'Ok', 'Ok', '', null);
          return;
        }
        if(!this._checkDate()){
          return;
        }
        this._getSpecimenNumberCheck();
      },

      //접수 or 기접수확인
      onCheckinClick(){
        if(isEmpty(this.get('specimenNumber'))){
          this._showMessage(this.getLanguageResource('10105', 'F', '검체번호를 확인하세요.'), 'warning', 'Ok', 'Ok', '', null);
          return;
        }
        if(!isEmpty(this.get('timer'))){
          clearTimeout(this.get('timer'));
        }
        if(!this._checkDate()){
          return;
        }
        this._getSpecimenInfo().then(function(res){
          // this._setTimer('5000');
          if(isEmpty(res.get('firstObject.checkInNumber'))){
            if(isEmpty(this.get('examListItemsSource'))){
              this._showMessage(this.getLanguageResource('10105', 'F', '검체번호를 확인하세요.'), 'warning', 'Ok', 'Ok', '', null);
              return;
            }
            this._encounterValidationCheck(res);
          }else{
            this.set('checkInNumber', res.get('firstObject.checkInNumber'));
            this.set('checkInTime', this.get('fr_I18nService').formatDate(res.get('firstObject.checkInDatetime'), 'g'));
            this._showMessage(this.getLanguageResource('10724', 'F', '이미 접수된 검체입니다.')+ '<br>'
            + this.getLanguageResource('16890', 'S', '검사일') + ': '
            + this.get('fr_I18nService').formatDate(res.get('firstObject.checkInDate'), 'd'), 'warning', 'Ok', 'Ok', '', null);
            // this.set('specimenNumber', null);
            // this.$('[name*="checkInSpecimenNumber"] input').select();
          }
        }.bind(this)).catch(function(e){
          this._catchError(e);
        }.bind(this));
      },

      //  checkinInfo 그리드 Row 선택
      onCheckinInfoGridSelectionChange(e){
        this.set('selectedItems', e.selectedItems);
      },

      //초기화 버튼 클릭
      onInitializeClick(){
        this._initialize();
        this.set('specimenNumber', null);
        this.set('specimenInfoReferred', null);
        this.set('checkinInfoListItemsSource', null);
        this.set('examDateSelectedDate', this.get('co_CommonService').getNow());
        this.set('isAutoCheckIn', true);
        this.set('isAutoPrint', false);
        //time volume 초기화
        this._specimenNumberSelect();
        // this.$('[name*="checkInSpecimenNumber"] input').select();
        this.toggleProperty('initializeTimeVolume');
        this.set('examTypeSelectedItem', this.get('examTypeItemsSource.firstObject'));
      },

      onReturnSpecimenInfo(e){
        this.set('returnedSpecimenInfo', e);
        // progressStatus.code
      },

      onCancelClick(e){
        this.set('loaderType', 'progress');
        this.set('isLoaderShow', true);
        clearTimeout(this.get('timer'));
        if(this._cancelValidationCheck()==false){
          this.set('isLoaderShow', false);
          return;
        }
        this.set('cancelOption', e);

        this._getSpecimenInfo().then(res=>{
          // this._setTimer('5000');
          if(isEmpty(res.get('firstObject.checkInNumber')) || isEmpty(res.get('firstObject.checkInId'))){
            this._showMessage(this.getLanguageResource('9288', 'F', '검사상태를 확인해주시기 바랍니다.'), 'warning', 'Ok', 'Ok', '', null);
            this.set('isLoaderShow', false);
            return;
          }
          this.set('checkInId', res.get('firstObject.checkInId'));
          let rejectReasonsItemsSource=null;
          if(e=='observation'){
            //결과취소
            rejectReasonsItemsSource= this.get('observationCancelReasonItemsSource');
          }else if(e=='exam'){
            //검사취소
            this.set('isLoaderShow',false);
            this.get('specimenCheckinService')._showMessage(this.getLanguageResource('13246', 'F', null, '검사취소시 해당검사를 다시 진행할 수 없습니다. 진행하시겠습니까?'),
              'question', 'YesNo', 'Yes', '', null).then(function(result){
              if(result === 'Yes'){
                this.set('isLoaderShow', true);
                rejectReasonsItemsSource= this.get('specimenRejectReasonsItemsSource');
                this.set('isReasonsModalOpen', true);
                this.set('isLoaderShow', false);
                this.set('reasonsItemsSource', rejectReasonsItemsSource);
                this.set('reasonsSelectedItem', rejectReasonsItemsSource.get('firstObject'));
                this._initializeModal();
              }else{
                this._specimenNumberSelect();
                // this.$('[name*="checkInSpecimenNumber"] input').select();
              }
            }.bind(this)).catch(function(error){
              this._catchError(error);
            }.bind(this));
            return;
            // rejectReasonsItemsSource= this.get('specimenRejectReasonsItemsSource');
          }else{
            //접수취소
            rejectReasonsItemsSource= this.get('specimenRejectReasonsItemsSource');
          }
          this.set('isReasonsModalOpen', true);
          this.set('isLoaderShow', false);
          this.set('reasonsItemsSource', rejectReasonsItemsSource);
          this.set('reasonsSelectedItem', rejectReasonsItemsSource.get('firstObject'));
          this._initializeModal();
        }).catch(function(err){
          this.set('isLoaderShow',false);
          this.set('isSpecimenNumberDisabled', false);
          // this.get('specimenSamplingService').onShowToast('error', this.getLanguageResource('8947', 'F', null, '에러가 발생했습니다.'), '');
          this.showResponseMessage(err);
        }.bind(this));
      },

      //취소 사유 항목 선택
      onSpecimenRejectReasonsChanged(){
        if(this.get('reasonsSelectedItem.code') == '9999'){
          this.set('reasonsNameDisabled', false);
        }else{
          this.set('reasonsNameDisabled', true);
          this.set('specimenRejectReasonsName', null);
        }
      },

      //취소사유 modal OK 클릭
      onSpecimenRejectReasonsOKAction(){
        this.set('isLoaderShow', true);
        this.set('isReasonsModalOpen', false);
        this.set('reasonId', this.get('reasonsSelectedItem.code'));
        this.set('reasonName', this.get('reasonsSelectedItem.name'));
        if(isEmpty(this.get('reasonsSelectedItem.code'))){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('8945', 'F','필수값을 입력하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
          this.set('isLoaderShow', false);
          return;
        }
        this._checkInCancelClick().then(function(res){
          this.set('isLoaderShow', false);
          if(res === true){
            this._setTimer('5000');
            this.set('checkInNumber', null);
            this.set('checkInTime', null);
            this.set('specimenInfoReferred', null);
            this._initialize();
            // this.set('initializeTimeVolume', true);
            this.toggleProperty('initializeTimeVolume');
            this.get('specimenCheckinService').onShowToast('save', this.getLanguageResource('8943', 'F', '취소되었습니다.'), '');
            this.set('specimenNumber', null);
            this._specimenNumberSelect();
            // this.$('[name*="checkInSpecimenNumber"] input').select();
          }else{
            // this.get('specimenCheckinService')._showMessage(this.getLanguageResource('8947', 'F','에러가 발생했습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
          }
          // //overview 재조회
          // this.get('overViewReLoadCB')();
        }.bind(this)).catch(function(e){
          this._catchError(e).then(function(){
            this._specimenNumberSelect();
            // this.$('[name*="checkInSpecimenNumber"] input').select();
          }.bind(this));
        }.bind(this));
      },

      //부적합검체등록 버튼 클릭
      onInappropriateSpecimenRegistrationClick(){
        if(isEmpty(this.get('specimenNumber')) || isEmpty(this.get('specimenInfo.specimenId'))){
          this._showMessage(this.getLanguageResource('10105', 'F', '검체번호를 확인하세요.'), 'warning', 'Ok', 'Ok', '', null);

          return;
        }
        this.get('specimenCheckinService').getInappropriateInfo(this.get('specimenInfo.specimenId')).then(function(inappropriateInfo){
          if(!isEmpty(inappropriateInfo)){
            this._showMessage(this.getLanguageResource('10106', 'F', '이미 등록된 검체입니다. <br> 취소하고 다시 접수하시겠습니까?'),
              'question', 'YesNo', 'Yes', '', null).then(function(result){
              if(result === 'Yes'){
                this.set('inappropriateInfo', inappropriateInfo);
                this.set('isInappropriateRegistrationModalOpen', true);
                this._initializeisInappropriateRegistrationModal();
                // this.get('specimenCheckinService').deleteInappropriate(inappropriateInfo.get('firstObject.inappropriateSpecimenId')).then(function(res){
                //   if(res===true){
                //     this.set('isInappropriateRegistrationModalOpen', true);
                //     this._initializeisInappropriateRegistrationModal();
                //   }
                // }.bind(this));
              }
            }.bind(this)).catch(function(e){
              this._catchError(e);
            }.bind(this));
          }else{
            this.set('isInappropriateRegistrationModalOpen', true);
            this._initializeisInappropriateRegistrationModal();
            this.set('inappropriateInfo', null);
          }
        }.bind(this)).catch(function(e){
          this._catchError(e);
        }.bind(this));
      },

      //부적합검체등록 사유 선택
      // onInappropriateReasonsChanged(){
      //   if(this.get('inappropriateReasonsSelectedItem.code') == '9999'){
      //     this.set('inappropriateReasonsInputDisabled', false);
      //   }else{
      //     this.set('inappropriateReasonsInputDisabled', true);
      //     this.set('inappropriateReasonsnInputName', null);
      //   }
      // },

      //부적합검체등록 modal OK 클릭
      // onInappropriateRegistrationOKAction(){
      //   this.set('isInappropriateRegistrationModalOpen', false);
      //   this.set('specimenNumber', null);
      //   this.$('[name*="checkInSpecimenNumber"] input').select();
      // },

      onExamDateChangedAction(e){
        if(isEmpty(e.selectedDate)){
          return;
        }
        const examDateSelectedDate= this.get('fr_I18nService').formatDate(new Date(),'d');
        const selectedDate= this.get('fr_I18nService').formatDate(e.selectedDate,'d');

        if(compare(examDateSelectedDate, selectedDate) === 1){
          this.set('isExamDateError', true);
          this.set('isExamDateShowTodayButton', false);
          this._showMessage(this.getLanguageResource('9290', 'F', '날짜를 확인하세요.'), 'warning', 'Ok', 'Ok', '', null).then(function(){
            this.set('examDateSelectedDate', this.get('co_CommonService').getNow());
          }.bind(this)).catch(function(error){
            this._catchError(error);
          }.bind(this));

        }else if(compare(examDateSelectedDate, selectedDate) === -1){
          this.set('isExamDateShowTodayButton', true);
          this.set('isExamDateError', false);
        }else if(compare(examDateSelectedDate, selectedDate) === 0){
          this.set('isExamDateShowTodayButton', false);
          this.set('isExamDateError', false);
        }
      },

      onTodayClick(){
        this.set('examDateSelectedDate', this.get('co_CommonService').getNow());
      },

      onBarcodeBtnClick(){
        // this.getPrinterName().then(function(res){
        // this.set('printSetting', res);
        this._printBarcode();
        // }.bind(this)).catch(function(e){
        //   this._catchError(e);
        // }.bind(this));
      },

    },

    // 5. Private methods Area
    _initialize(){
      this.set('specimenInfo', null);
      this.set('checkInNumber', null);
      this.set('checkInTime', null);
      this.set('subjectNumber', null);
      this.set('examListItemsSource', null);
      this.set('dxListItemsSource', null);
      this.set('isSpecimenNumberDisabled', false);
      this.set('isAllergy', false);
      this.set('isInfection', false);
      this.set('isNeedConsent', false);
      this.set('isNeedRequest', false);
      this.set('isDischarge', false);
      this.set('progressTypeCode', false);
    },
    async _getSpecimenCollection(res) {
      try {
        //타도메인 호출
        const result = await this.getList(this.get('samplingUrl') + 'specimen-collections/search/'+this.get('specimenNumber'), null, null);
        if(!isEmpty(result) && isEmpty(result.receive.receivedDatetime)) {
          const response = await this.showConfirmMessage('', `<b>${this.getLanguageResource('13247', 'F', null, '미등록 검체입니다')}<br>${this.getLanguageResource('9222', 'F', null, '진행하시겠습니까?')}</b>`);
          if(response === 'Yes') {
            this._getDuplicationCheck(res);
          } else {
            this.set('isLoaderShow',false);
            this.set('isSpecimenNumberDisabled', false);
            this._specimenNumberSelect();
          }
        } else {
          //미접수 검체
          this._getDuplicationCheck(res);
        }
      } catch(e) {
        this._catchError(e);
        this._specimenNumberSelect();
        console.log(e);
      }
    },

    _specimenNumberSelect() {
      next(() => {
        if(this.isDestroyed || this.isDestroying) {
          return;
        }
        let inputElement = document.getElementById(this.get('inputSource.elementId')).getElementsByTagName('INPUT')[0];
        inputElement.focus();
        inputElement.select();
        inputElement = null;
      });
    },

    _getSpecimenNumberCheck() {
      this.set('isLoaderShow', true);
      this._initialize();
      this.set('isSpecimenNumberDisabled', true);
      this.toggleProperty('initializeTimeVolume');
      this._getSpecimenInfo().then(res=>{
        if(isEmpty(res)){
          this.set('isSpecimenNumberDisabled', false);
          this.set('isLoaderShow',false);
          // this._showMessage(this.getLanguageResource('10723', 'F', '접수가능한 검체가 아닙니다.'), 'warning', 'Ok', 'Ok', '', null);
          this._specimenNumberSelect();
        }else{
          //진단정보 조회
          this.ajaxSyncCall(this.get('defaultUrl') + 'patients/diagnosises/whole-dianosis-list', {patientId: res.get('firstObject.subjectId')}, 'GET', null, false).done(dianosisInfo=> {
            this.set('dxListItemsSource',dianosisInfo);
          }).catch(function(err){
            this.set('isLoaderShow',false);
            this.set('isSpecimenNumberDisabled', false);
            this.showResponseMessage(err);
          }.bind(this));
          const firstObject = res.get('firstObject');
          this.set('subjectNumber', firstObject.subjectNumber);
          this.set('specimenInfoReferred', firstObject.issuedDepartmentName +' / ' + firstObject.departmentName + ' / ' + firstObject.orderedStaffName);
          let occupyingBed= isEmpty(firstObject.wardName)? '' : firstObject.wardName;
          occupyingBed= isEmpty(firstObject.roomName)? occupyingBed : occupyingBed + ' / ' + firstObject.roomName;
          occupyingBed= isEmpty(firstObject.bedName)? occupyingBed : occupyingBed + ' / ' + firstObject.bedName;
          firstObject.occupyingBed= occupyingBed;
          this.set('specimenInfo', firstObject);
          this.set('examListItemsSource', res.toArray());
          if(this.get('isAutoCheckIn') === true){
            if(isEmpty(res.get('firstObject.checkInNumber'))){
              if(this.get('isSpecimenConfirm')) {
                this._getSpecimenCollection(res);
              } else {
                //미접수 검체
                this._getDuplicationCheck(res);
              }
            }else{
              //기접수 검체
              this.set('checkInNumber', res.get('firstObject.checkInNumber'));
              this.set('checkInTime', this.get('fr_I18nService').formatDate(res.get('firstObject.checkInDatetime'), 'g'));
              this._showMessage(this.getLanguageResource('10724', 'F', '이미 접수된 검체입니다.') + '<br>'
              + this.getLanguageResource('16890', 'S', '검사일')+ ': ' + this.get('fr_I18nService').formatDate(res.get('firstObject.checkInDate'), 'd'), 'warning', 'Ok', 'Ok', '', null);
              this.set('isLoaderShow',false);
              this.set('isSpecimenNumberDisabled', false);
              // this.set('specimenNumber', null);
              // this.$('[name*="checkInSpecimenNumber"] input').select();
            }
          }else{
            this.set('checkInNumber', res.get('firstObject.checkInNumber'));
            this.set('checkInTime', this.get('fr_I18nService').formatDate(res.get('firstObject.checkInDatetime'), 'g'));
            this.set('isAutoCheckIn', false);
            this.set('isLoaderShow',false);
            this.set('isSpecimenNumberDisabled', false);
            this._specimenNumberSelect();
          }
        }
      }).catch(function(e){
        console.log(e);
        this._catchError(e);
      }.bind(this));
    },
    async _showCheckInConfirm(res) {
      const message = `<b>${this.getLanguageResource('13248', 'F', '', '검사일이 미래일자입니다.')}<br>${this.getLanguageResource('11435', 'F', '', '접수하시겠습니까?')}</b>`;
      const result = await this.showConfirmMessage('', message);
      if(result === 'Yes') {
        this._encounterValidationCheck(res);
      } else {
        this.set('isSpecimenNumberDisabled', false);
        this.set('isLoaderShow',false);
        this._specimenNumberSelect();
      }
    },

    _getDuplicationCheck(res) {
      this._duplicationCheck(this.get('specimenNumber')).then(function(duplicationInfo){
        const today = this.get('fr_I18nService').formatDate(new Date(),'d');
        const selectedDate = this.get('fr_I18nService').formatDate(this.get('examDateSelectedDate'),'d');
        const compareCount = compare(today, selectedDate);
        if(duplicationInfo != false){
          //중복이면 채혈 취소가능한 화면으로 이동
          let exams= '';
          duplicationInfo.duplicationExaminations.forEach(function(e){
            exams= isEmpty(exams)? e.name: exams +'<br>'+ e.name;
          });
          const caption = `${this.getLanguageResource('809', 'S', '검사항목명')}: ${exams}`;
          const message = `<b>${this.getLanguageResource('12227', 'F', '', '중복검사가 있습니다.')}<br>${this.getLanguageResource('13250', 'F', '', '이대로 진행하시겠습니까?')}</b>`;
          // const message = `<b>${this.getLanguageResource('13250', 'F', '', '중복검사가 있습니다. 이대로 진행하시겠습니까/.')}</b>`;
          // this._showMessage(this.getLanguageResource('9842', 'F', '중복데이터가 있습니다')+'<br>'
          // + this.getLanguageResource('809', 'S', '검사항목명: ')+'<br>' + exams+'<br><br>'
          // +this.getLanguageResource('9258', 'F', '확인하시겠습니까?'), 'question', 'YesNo', 'Yes', '', null).then(function(result){
          //   if(result === 'Yes'){
          //     if(this.get('mode') =='worklist'){
          //       this.get('duplicationCB')({
          //         duplicationInfo: duplicationInfo,
          //         subjectNumber: this.get('specimenInfo.subjectNumber'),
          //         examDate: this.get('specimenInfo.orderDate'),
          //         encounterTypeCode: this.get('specimenInfo.encounterTypeCode')
          //       });
          //     }
          //     this.set('isSpecimenNumberDisabled', false);
          //     this.set('isLoaderShow',false);
          //   }else if(result === 'No'){
          //     //수진정보 체크
          //     this._encounterValidationCheck(res);
          //   }
          // }.bind(this)).catch(function(e){
          //   this._catchError(e);
          // }.bind(this));
          this.showConfirmMessage(caption, message).then(function(result){
            if(result === 'Yes'){
              if(compareCount < 0) {
                this._showCheckInConfirm(res);
              } else {
                //수진정보 체크
                this._encounterValidationCheck(res);
              }
            } else {
              if(this.get('mode') =='worklist'){
                this.get('duplicationCB')({
                  duplicationInfo: duplicationInfo,
                  subjectNumber: this.get('specimenInfo.subjectNumber'),
                  examDate: this.get('specimenInfo.orderDate'),
                  encounterTypeCode: this.get('specimenInfo.encounterTypeCode')
                });
              }
              this.set('isSpecimenNumberDisabled', false);
              this.set('isLoaderShow',false);
              this._specimenNumberSelect();
            }
          }.bind(this)).catch(function(e){
            this._catchError(e);
          }.bind(this));
        }else if(compareCount < 0){
          this._showCheckInConfirm(res);
        } else {
          //수진정보 체크
          this._encounterValidationCheck(res);
        }
      }.bind(this)).catch(function(e){
        console.log(e);
        this._catchError(e);
      }.bind(this));
    },
    _checkDate(){
      let res= true;
      const examDateSelectedDate= this.get('fr_I18nService').formatDate(new Date(),'d');
      const selectedDate= this.get('fr_I18nService').formatDate(this.get('examDateSelectedDate'),'d');

      if(compare(examDateSelectedDate, selectedDate) === 1){
        res= false;
        this._showMessage(this.getLanguageResource('9290', 'F', '날짜를 확인하세요.'), 'warning', 'Ok', 'Ok', '', null).then(function(){
          this.set('examDateSelectedDate', this.get('co_CommonService').getNow());
        }.bind(this)).catch(function(error){
          this._catchError(error);
        });
      }
      return res;
    },

    //접수취소사유 modal 초기화
    _initializeModal(){
      this.set('reasonsDisabled', false);
      this.set('reasonsNameDisabled', true);
      this.set('specimenRejectReasonsName', null);
    },

    //부적합검체등록 modal 초기화
    _initializeisInappropriateRegistrationModal(){
      const inappropriateReasonsItemsSource= this.get('inappropriateReasonsItemsSource');
      this.set('inappropriateReasonsSelectedItem', inappropriateReasonsItemsSource.get('firstObject'));
      this.set('inappropriateReasonsDisabled', false);
      this.set('inappropriateReasonsInputDisabled', true);
      this.set('inappropriateReasonsnInputName', null);
    },

    _duplicationCheck(specimenNumber){
      return this.ajaxSyncCall(this.get('defaultUrl') + 'specimen-checkins/check-duplication',{specimenNumber: specimenNumber}, 'GET', null, false).then(function(res){
        return res.isDuplicationExamination === true? res : false;
      }).catch(function(e){
        this._catchError(e);
      }.bind(this));
    },

    _encounterValidationCheck(specimenInfo){
      const item= specimenInfo.get('firstObject');
      let checkinDoubleCheck= false;
      if(item.encounterTypeCode=='O' || item.prescriptionTypeCode =='6'){
        // 외래 및 퇴원오더
        if(!isEmpty(item.admissionEncounterId)){
          //외래->입원 치환된경우 수납체크 안함
        }else if(item.paymentStatusCode !='Y'){
          //미수납인 경우
          checkinDoubleCheck= true;
        }
        // else if(item.prescriptionTypeCode =='6'){
        //퇴원오더
        //   checkinDoubleCheck= true;
        // }
      }
      if(item.prescriptionTypeCode =='8' || item.isHipass === 1 || item.isPayAfterExaminaion === 1 || item.isOutPatientPaypass === 1){
        //건증은 수납체크 안함
        checkinDoubleCheck= false;
      }

      if(checkinDoubleCheck == true){
        this.set('isSpecimenNumberDisabled',false);
        this.get('specimenCheckinService')._showMessage(this.getLanguageResource('10725', 'F', '수납되지 않았습니다.'), 'warning', 'Ok', 'Ok', '', null).then(function(){
          this.set('isLoaderShow',false);
          this._specimenNumberSelect();
          // this.$('[name*="checkInSpecimenNumber"] input').select();

        }.bind(this));
      }else{
        if(this.get('examTypeSelectedItem.classificationId') !='All' && this.get('examTypeSelectedItem.classificationId') != this.get('specimenInfo.classificationId')){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('13249', 'F', null, '검사분류를 확인하세요.'), 'warning', 'Ok', 'Ok', '', null);
          this.set('isLoaderShow',false);
          this.set('isSpecimenNumberDisabled', false);
          return;
        }
        this._createCheckIn();
      }
    },

    _createCheckIn(){
      const examDateSelectedDate= this.get('examDateSelectedDate');
      const params={
        specimenId: this.get('specimenInfo.specimenId'),
        checkInDate: new Date(
          examDateSelectedDate.getFullYear(),
          examDateSelectedDate.getMonth(),
          examDateSelectedDate.getDate(), 0, 0, 0),
        checkInStaffId: this.get('currentUser.employeeId')
      };
      return this.create(this.get('defaultUrl') + 'specimen-checkins', null, params, true).then(function(res) {
        if(res.response ===true){
          this._setTimer('5000');
          if(this.get('isAutoPrint')===true){
            //오버뷰 재조회
            this._printBarcode();
          }
          this._updateCheckinList();
        }else{
          // this.get('specimenCheckinService')._showMessage(this.getLanguageResource('8947', 'F','에러가 발생했습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
          this.set('isLoaderShow',false);
        }
        this.set('isSpecimenNumberDisabled', false);
        this.set('specimenNumber', null);
        this._specimenNumberSelect();
        // this.$('[name*="checkInSpecimenNumber"] input').select();
      }.bind(this)).catch(function(e){
        this._catchError(e);
      }.bind(this));
    },

    _updateCheckinList(){
      let checkinInfoListItemsSource= A();
      if(isPresent(this.get('checkinInfoListItemsSource'))){
        checkinInfoListItemsSource= this.get('checkinInfoListItemsSource');
      }
      this._getSpecimenInfo().then(postData => {
        if(isEmpty(postData)){
          // this._showMessage('Check-in information load Failed');
          this.set('isLoaderShow',false);
          return;
        }
        this.set('checkInNumber', postData.get('firstObject.checkInNumber'));
        this.set('checkInTime', this.get('fr_I18nService').formatDate( postData.get('firstObject.checkInDatetime'), 'g'));
        let comments = '';
        let isNeedConsent= false;
        let isNeedRequest= false;

        postData.forEach(element => {
          if(element.isNeedConsent){
            isNeedConsent= true;
          }
          if(element.isNeedRequest){
            isNeedRequest= true;
          }
          if(element.orderComment){
            comments= comments + ' ' + element.orderComment;
          }
        });
        // checkinInfoListItemsSource.unshiftObject(postData.get('firstObject'));
        const tmp= postData.get('firstObject');
        set(tmp, 'issuedDepartmentCode', tmp.issuedDepartmentName);
        set(tmp, 'departmentCode', tmp.departmentName);
        set(tmp, 'orderedStaffName', tmp.orderedStaffName);
        // comments= comments+ ' ' + tmp.orderComment;
        set(tmp, 'comments', comments);
        set(tmp, 'iconDisplay', this._setIconDisplay(tmp.progressTypeCode, isNeedConsent, isNeedRequest, tmp.isInfection, tmp.prescriptionTypeCode));
        set(tmp, 'point', this._setIconDisplayTooltip(tmp.progressTypeCode, isNeedConsent, isNeedRequest, tmp.isInfection, tmp.prescriptionTypeCode));
        checkinInfoListItemsSource.unshiftObject(tmp);
        this.set('checkinInfoListItemsSource', checkinInfoListItemsSource);
        this.set('isLoaderShow',false);
        this._specimenNumberSelect();
        // this.$('[name*="checkInSpecimenNumber"] input').select();
      }).catch(function(e){
        this._catchError(e);
      }.bind(this));
    },

    _setIconDisplay(progressTypeCode,isNeedConsent, isNeedRequest, isInfection, prescriptionTypeCode){
      //아이콘 표기 우선순위: isInfection > progressTypeCode"D","F" > isAllergy> isNeedConsent > isNeedRequest> prescriptionTypeCode
      let res = null;
      if(isInfection){
        res = 'isInfection';
      }else if(progressTypeCode === "F"){
        res = 'F';
      }else if(progressTypeCode === "D"){
        res = 'D';
      }else if(isNeedConsent){
        res = 'isNeedConsent';
      }else if(isNeedRequest){
        res = 'isNeedRequest';
      }else if(prescriptionTypeCode =='6'){
        res = 'isDischarge';
      }
      return res;
    },

    _setIconDisplayTooltip(progressTypeCode,isNeedConsent, isNeedRequest, isInfection, prescriptionTypeCode){
      let res=[];
      if(isInfection){
        res.addObject(this.getLanguageResource('581', 'S', 'Infection Precaution') + '<br>');
      }
      if( progressTypeCode === "F"){
        res.addObject(this.getLanguageResource('5725', 'F', '응급')+ '<br>');
      }
      if(progressTypeCode === "D" ){
        res.addObject(this.getLanguageResource('1880', 'F', '당일')+ '<br>');
      }
      // if(isAllergy){
      //   res.addObject(this.getLanguageResource('4682', 'F', 'Allergy') + '<br>');
      // }
      if(isNeedConsent){
        res.addObject(this.getLanguageResource('11740', 'S', '동의서 필요') + '<br>');
      }
      if(isNeedRequest){
        res.addObject(this.getLanguageResource('17066', 'S', '의뢰서 필요') + '<br>');
      }
      if(prescriptionTypeCode == '6'){
        res.addObject(this.getLanguageResource('11988', 'S', '퇴원오더') + '<br>');
      }
      if(res.length > 1){
        res=res.join('').toString();
      }else{
        res=[];
      }
      return res;
    },

    _cancelValidationCheck(){
      if(isEmpty(this.get('specimenNumber'))){
        this._showMessage(this.getLanguageResource('10105', 'F', '검체번호를 확인하세요.'), 'warning', 'Ok', 'Ok', '', null);

        return false;
      }
    },

    //검체번호 입력 commit
    _getSpecimenInfo(){
      const specimenNumber= this.get('specimenNumber').trim();
      return this.getList(this.get('defaultUrl') + 'specimen-checkins' , {specimenNumber: specimenNumber}, null).then(function(info){
        if(isEmpty(info)){
          return [];
        }
        let isNeedConsent = false;
        let isNeedRequest = false;
        info.forEach(e=>{
          if(e.isNeedConsent){
            isNeedConsent= true;
          }
          if(e.isNeedRequest){
            isNeedRequest= true;
          }
        });
        // if(!isEmpty(info.get('firstObject'))){
        const res= info.get('firstObject');
        this.set('isAllergy', res.isAllergy);
        this.set('isInfection', res.isInfection);
        this.set('isNeedConsent', isNeedConsent);
        this.set('isNeedRequest', isNeedRequest);
        this.set('isDischarge', res.prescriptionTypeCode=='6');
        this.set('progressTypeCode', res.progressTypeCode);
        // }
        // TODO: specimen-sampling-time-volume specimenNumber settting
        return info;
      }.bind(this)).catch(function(e){
        this._catchError(e);
      }.bind(this));
    },

    //chek-in 취소
    _checkInCancelClick(){
      let promise =null;
      if(this.get('cancelOption')== 'observation'){
        const specimenInfo= this.get('specimenInfo');
        const cancelDatetime= this.get('co_CommonService').getNow();
        const params= {
          specimenId: specimenInfo.specimenId,
          checkInId: specimenInfo.checkInId,
          cancelStaffId: this.get('currentUser.employeeId'),
          cancelDatetime: cancelDatetime,
          reasonId: this.get('reasonId'),
          reasonName: this.get('reasonName'),
          reasonEtcContents: this.get('reasonId')== "9999" ? this.get('specimenRejectReasonsName') : null
        };
        promise= this.create(this.get('defaultUrl') + 'specimen-checkins/observation-cancel', null, params);
      }else{
        promise= this.update(this.get('defaultUrl') + 'specimen-checkins', null, false, {
          checkInId: this.get('checkInId'),
          rejectStaffId: this.get('currentUser.employeeId'),
          rejectDatetime: this.get('co_CommonService').getNow(),
          reasonId: this.get('reasonId'),
          reasonName: this.get('reasonName'),
          reasonEtcContents: this.get('reasonId')== "9999" ? this.get('specimenRejectReasonsName') : null,
          isExaminationCancel: this.get('cancelOption')== 'exam'? true : false
        });
      }
      return promise.then(function(res){
        return res;
      }).catch(function(e){
        // this._catchError(e);
        this._catchError(e).then(function(){
          this._specimenNumberSelect();
          // this.$('[name*="checkInSpecimenNumber"] input').select();
        }.bind(this));
      }.bind(this));
    },

    _setTimer(sec){
      if(this.get('mode') !='worklist'){
        return;
      }
      this.set('timer',setTimeout(() => {
        this.get('overViewReLoadCB')();
      }, sec));
    },

    _printBarcode(){
      const specimenInfo= this.get('specimenInfo');
      const printSetting= this.get('printSetting');
      this.set('printouts', null);
      this.set('printDataFieldDefault', []);
      this.set('printDataFieldD', []);
      this.set('printDataFieldG', []);
      this.set('printDataFieldF', []);
      // this.set('printDataField', []);
      if(isEmpty(this.get('specimenInfo'))){
        // this._showMessage('검체정보를 먼저 조회하세요', 'warning', 'Ok', 'Ok', '', null);
        this.get('specimenCheckinService')._showMessage(this.getLanguageResource('10105', 'F','검체번호를 확인하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
        return;
      }
      this._getSpecimenLabel(specimenInfo);
      next(this, function(){
        if(isEmpty(this.get('printDataFieldG')) && isEmpty(this.get('printDataFieldD')) && isEmpty(this.get('printDataFieldF'))){
          // this.set('printPopup', false);
          this.set('printConfig', {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerDefault });
          this.set('printContent', {
            'parameterField': {},
            'dataField': { "specimenInfo" : this.get('printDataFieldDefault')}});
          console.log(this.get('printConfig'));
          console.log(this.get('printContent'));
          this.set('printDataFieldDefault' ,null);
        }else{
          this._print();
        }
        const num= isEmpty(this.get('printouts'))? '': this.get('printouts');
        this.get('specimenCheckinService').onShowToast('save', this.getLanguageResource('16928', 'S', '출력매수') + ": \xa0"+ num , '',8000);
      }.bind(this));
    },

    _print(){
      const printSetting= this.get('printSetting');
      // this.set('printPopup', false);
      if(!isEmpty(this.get('printDataFieldG'))){
        this.set('printConfig', {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerG });
        this.set('printContent', {
          'parameterField': {},
          'dataField': { "specimenInfo" : this.get('printDataFieldG')}});
        // console.log(this.get('printConfig'));
        // console.log(this.get('printContent'));

        this.set('printDataFieldG' ,null);
        return;
      }
      if(!isEmpty(this.get('printDataFieldD'))){
        this.set('printConfig', {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerD });
        this.set('printContent', {
          'parameterField': {},
          'dataField': { "specimenInfo" : this.get('printDataFieldD')}});
        // console.log(this.get('printConfig'));
        // console.log(this.get('printContent'));
        this.set('printDataFieldD' ,null);
        return;
      }
      if(!isEmpty(this.get('printDataFieldF'))){
        this.set('printConfig', {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerF });
        this.set('printContent', {
          'parameterField': {},
          'dataField': { "specimenInfo" : this.get('printDataFieldF')}});
        // console.log(this.get('printConfig'));
        // console.log(this.get('printContent'));
        this.set('printDataFieldF' ,null);
        return;
      }
      if(!isEmpty(this.get('printDataFieldDefault'))){
        this.set('printConfig', {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerDefault });
        this.set('printContent', {
          'parameterField': {},
          'dataField': { "specimenInfo" : this.get('printDataFieldDefault')}});
        // console.log(this.get('printConfig'));
        // console.log(this.get('printContent'));
        this.set('printDataFieldDefault' ,null);
      }
    },
    _getSpecimenLabel(e){
      const printSetting =this.get('printSetting');
      this.get('specimenSamplingService').getSpecimenLabel(null, e.specimenNumber).then(res=>{
        if(!isEmpty(res)){
          this._setProperty(res);
          res.specimenTypes.forEach(function(r, idx) {
            this.set('printouts', this.get('printouts') + r.labelPrintCount);
            let specimenName = res.specimenTypes[idx].abbreviation;
            if(!isEmpty(res.specimenTypes[idx].containerName)){
              specimenName = specimenName + '(' + res.specimenTypes[idx].containerName + ')';
            }
            let u=0;
            while (u < r.labelPrintCount) {
              const resCopy= $.extend(true, EmberObject.create(), res);
              resCopy.specimenName= specimenName;
              if(res.progressTypeCode =="G"&& !isEmpty(printSetting.printerG)){
                if(printSetting.printerG == printSetting.printerDefault){
                  this.get('printDataFieldDefault').pushObject(resCopy);
                }else{
                  this.get('printDataFieldG').pushObject(resCopy);
                }
              }else if(res.progressTypeCode =="D" && !isEmpty(printSetting.printerD)){
                if(printSetting.printerD == printSetting.printerDefault){
                  this.get('printDataFieldDefault').pushObject(resCopy);
                }else{
                  this.get('printDataFieldD').pushObject(resCopy);
                }
              }else if(res.progressTypeCode =="F" && !isEmpty(printSetting.printerF)){
                if(printSetting.printerF == printSetting.printerDefault){
                  this.get('printDataFieldDefault').pushObject(resCopy);
                }else{
                  this.get('printDataFieldF').pushObject(resCopy);
                }
              }else{
                this.get('printDataFieldDefault').pushObject(resCopy);
              }
              u++;
            }
          }.bind(this));
        }
      }).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    _showMessage(caption, messageBoxImage, messageBoxButton, messageBoxFocus, messageBoxText, messageboxInterval){
      const options = {
        'caption': caption,
        'messageBoxImage': messageBoxImage,
        'messageBoxButton': messageBoxButton,
        'messageBoxFocus': messageBoxFocus,
        'messageBoxText': messageBoxText,
        'messageboxInterval': messageboxInterval
      };

      return messageBox.show(this, options).then(function (result) {
        this._specimenNumberSelect();
        // this.$('[name*="checkInSpecimenNumber"] input').select();
        return result;
      }.bind(this)).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },
    async _setSettingInfo() {
      try {
        const settingData = {
          settingOptions: {
            isSpecimenConfirm: this.get('isSpecimenConfirm')
          }
        };
        const hospitalId = this.get('currentUser.hospital.hospitalId');
        await this.get('co_CommonService').setConfigurationSettingInfo('HOSPITAL', hospitalId, `specimen-chekin-setting`, JSON.stringify(settingData), '워크리스트 접수 탭 설정');
        this.showToastSaved();
        this.set('isSettingOpen', false);
      } catch(e) {
        console.log('_setSettingInfo Error::', e);
      }
    },
    async _getSettingInfo() {
      try {
        // const result = await this.get('co_PersonalizationService').getSettingInfo(`verification-report-print`);
        const hospitalId = this.get('currentUser.hospital.hospitalId');
        const result = await this.get('co_CommonService').getConfigurationSettingInfo('HOSPITAL', hospitalId, 'specimen-chekin-setting');
        this.set('settingResult', result);
        if(!isEmpty(result.settingValue)) {
          this.set('settingValue', JSON.parse(get(result, 'settingValue')));
          const settingValue = JSON.parse(get(result, 'settingValue'));
          this.set('isSpecimenConfirm', settingValue.settingOptions.isSpecimenConfirm);
        }
      } catch(e) {
        console.log('_getSettingInfo Error::', e);
      }
    },
    _catchError(e){
      this.set('isLoaderShow',false);
      this.set('isSpecimenNumberDisabled', false);
      return this.showResponseMessage(e);
    }

  });