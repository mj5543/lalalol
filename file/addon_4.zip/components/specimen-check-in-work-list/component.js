// import Ember from 'ember';
import layout from './template';
import CHIS from 'framework/chis-framework';
//if needed, import config object
//import config from 'specimencheckin-module/app-config';
//if needed, import model class
//import Patient from 'specimencheckin-module/models/patient';

export default CHIS.FR.Core.ComponentBase.extend(
  /* Only For Server-Call Component
  CHIS.FR.CrossCutting.ServerCallMixin,
  */
  {
    /* 1. Service define Area
     testService:Ember.inject.service(),
    */
    layout,
    // 2. Property Area
    defaultUrl: null,
    viewSet:null,

    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId', 'specimen-check-in-work-list');

      //Set Stateful properties
      this.setStateProperties([
        'defaultUrl'
      ]);
      if (this.hasState() === false) {
        //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimencheckin'));
        this.set('viewSet', {selectedComboBox : {displayName:'a'}, selectedTagSet:null});
        this.set('tabNameResource1', this.getLanguageResource('9271', 'F', '워크리스트'));
        this.set('tabNameResource2', this.getLanguageResource('6758', 'F', '접수'));
        this.set('tabNameResource3', this.getLanguageResource('9272', 'F','Specimen Status Search'));
        this.set('tabNameResource4', this.getLanguageResource('9273', 'F', 'Specimen Label Print'));
        this.set('tabNameResource5', this.getLanguageResource('16901', 'S', '위탁검체 목록'));
        // this.set('isWorkListGridShow', true);
      }
      //Initialize Stateless properties
    },

    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'wp100');
      if (this.hasState() === false) {
        // let url = this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'localServerUrl') + 'mr/biz1/patient/';
        // this.getItem(url, null, null).then(function(result){
        //   this.set('serverModel', result);
        // }.bind(this));
      }
    },

    // 4. Actions Area
    actions: {
      //OverView 콜백 이벤트 - Tag셋팅 변경
      onOverViewSettingCallBack(sResult){
        // messageBox.show(this, sResult);
        this.set('viewSet', sResult);
      },
      onOverViewReLoad(){
        // this.set('reLoadCB', true);
        this.toggleProperty('reLoadCB');
      },

      getDuplicationInfo(duplicationInfo){
        this.set('selectedTabName','item4');
        this.set('duplicationCB', duplicationInfo);
      },

      onselectedFirstTabCB(){
        //오버뷰클릭하면 워크리스트탭으로 이동
        this.set('selectedTabName', 'item1');
      },

      // deSelectOverviewCB(){

      // }
    },
    // 5. Private methods Area
    // _processCols() {
    // }
  });