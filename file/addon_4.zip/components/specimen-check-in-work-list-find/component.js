/* eslint-disable max-lines */
/* eslint-disable max-statements */
/* eslint-disable complexity */
/* eslint-disable no-console */
import { A } from '@ember/array';
import $ from 'jquery';
import { next, later } from '@ember/runloop';
import { copy } from '@ember/object/internals';
import { isEmpty, isPresent } from '@ember/utils';
import { hash } from 'rsvp';
import EmberObject, { computed, set, get } from '@ember/object';
import { inject as service } from '@ember/service';
// import { getOwner } from '@ember/application';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'specimencheckin-module/app-config';
import specimencheckinPrintMixin from 'specimencheckin-module/mixins/specimen-check-in-print-mixin';
import specimencheckinMessageMixin from 'specimencheckin-module/mixins/specimen-check-in-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,specimencheckinPrintMixin, specimencheckinMessageMixin,
  {
    // 1. Service define Area
    specimenSamplingService: service('specimen-sampling-service'),
    specimenCheckinService: service('specimen-check-in-service'),
    layout,
    // 2. Property Area
    defaultUrl: null,
    currentUser: null,
    searchCondition: null,
    unitWorkIdsNames: null,
    examinationIdsNames: null,
    worklistColumns: null,
    worklistDetailColumns: null,
    observationInfoColumns: null,
    searhConditionItemsSource: null,
    worklistDetailItemsSource: null,
    observationInfoItemsSource: null,
    worklistItemsSource: null,
    detailInfoListColumns: null,
    _gridControl: null,
    isSubSearchVisible: null,
    filterTATValue: null,
    //print
    printPopup:null,
    printConfig:null,
    printContent:null,
    isSaveClick: false,
    isCallBackViewSetChanged: computed('callBackViewSet', function() {
      if(isEmpty(this.get('callBackViewSet.examinationFromDate'))){
        return;
      }
      this._isCallBackViewSetChanged(this.get('callBackViewSet'));
    }),
    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-check-in-work-list-find');
      //Set Stateful properties
      this.setStateProperties([
        'menuClass',
        'defaultUrl',
        'currentUser',
        'unitWorkIdsNames',
        'examinationIdsNames',
        'examCodeItemsSource',
        'worklistColumns',
        'orderInfoDetailColumns',
        'observationInfoColumns',
        'searhConditionItemsSource',
        'worklistItemsSource',
        'detailInfoListColumns',
        'searchCondition',
        '_gridControl',
        'expandedDetailRowItems',
        'hpcSelectedValue',
      ]);
      if (this.hasState() === false) {
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimencheckin')
        + `specimen-checkin/${config.version}/`);
        this.set('currentUser', this.get('co_CurrentUserService.user'));
        this.setGridColumns();
        this.set('findSettingPopupInfo', {});
        this.set('isSubSearchVisible', false);
        this.set('isWorkListGridShow', true);
        this.set('recordSize', 300);
        this.set('currentPage', 1);
        this.set('gridContextMenuSource', [
          { action : this.actions.onTATReasonEntry.bind(this), text : this.getLanguageResource('15511', 'F', '', 'TAT 지연사유'), display : true, alias: 'tatReason', disabled: false},
        ]);
        this.getPrinterName().then(function(res){
          this.set('printSetting', res);
        }.bind(this)).catch(function(error) {
          this._catchError(error);
        }.bind(this));
      }
    },
    setGridColumns(){
      this.set('worklistColumns', [
        { title: '', field: '*', align: 'center', bodyTemplateName: 'index', width: 35, fixedOrder: true },
        { title: 'TAT', field: 'tatPercentSearchTypeCode', align: 'center', bodyTemplateName: 'tatPercentType', width: 45,},
        { field: 'progressType.code', title: this.getLanguageResource('3813', 'S','속성'), align: 'center', bodyTemplateName: 'icon', width: 39},
        { title: this.getLanguageResource('16890', 'S','Exam Date'), field: 'checkInDate', type: 'date', dataFormat: 'd',align: 'center', width: 80, bodyTemplateName: 'dateTimeTooltip', },
        { title: this.getLanguageResource('16892', 'S','Exam.Type'), field: 'classificationInfo', width: 105, bodyTemplateName: 'tooltip'},
        { title: this.getLanguageResource('16881', 'F','Pt Name'), field: 'subject.name', bodyTemplateName: 'subjectNameTooltip',align: 'center', width: 90 },
        { title: this.getLanguageResource('8451', 'S','MRN'), field: 'subject.number', bodyTemplateName: 'bold',align: 'center', width: 65 },
        { title: this.getLanguageResource('3680', 'F','Sex'), field: 'subject.gender',align: 'center', width: 35 },
        { title: this.getLanguageResource('1662', 'F','Age'), field: 'subject.age',align: 'center', width: 35 },
        { title: this.getLanguageResource('6767', 'S','Check-in No.'), field: 'checkInNumber',headerTemplateName: 'barcolor02', bodyTemplateName: 'colfont', align: 'center', width: 60, isSorted: false, sortClass: '' },
        { title: this.getLanguageResource('16921', 'F','Specimen Name'), field: 'specimenType.name', headerTemplateName: 'barcolor01', bodyTemplateName: 'colfontTooltip', width: 160, isSorted: false, sortClass: '' },
        { title: this.getLanguageResource('859', 'S','Specimen No.'), field: 'specimenNumber',headerTemplateName: 'barcolor02', bodyTemplateName: 'colfont', align: 'center', width: 90, isSorted: false, sortClass: '' },
        { title: this.getLanguageResource('5218', 'F','Order Name'), field: 'orderNames', hidden:true, width: 160},
        { title: this.getLanguageResource('3452', 'F','Status'), align: 'center', field: 'progressStatus.name', width: 80 },
        { field: 'issuedDepartmentCode', title: this.getLanguageResource('8827', 'S','발행처'),align: 'center', width: 80, bodyTemplateName: 'tooltip'},
        { field: 'occupyingBed', title: this.getLanguageResource('14751', 'S','현위치'),align: 'center', width: 70, bodyTemplateName: 'occupyingBedTooltip'},
        { field: 'departmentCode', title: this.getLanguageResource('7111', 'S','진료과'),align: 'center', width: 80, bodyTemplateName: 'tooltip'},
        { field: 'orderedStaffName', title: this.getLanguageResource('9686', 'S', '처방의'),align: 'center', width: 80, bodyTemplateName: 'tooltip'},
        { field: 'encounterTypeName', title: this.getLanguageResource('16963', 'S', '구분'),align: 'center', width: 60},
        { title: this.getLanguageResource('5228', 'F','Order Comment'), field: 'orderComment', width: 120, bodyTemplateName: 'tooltip' },
        { title: this.getLanguageResource('7211', 'F', '채혈비고'), field: 'collectionComment', width: 120, bodyTemplateName: 'tooltip' },
      ]);

      this.set('detailInfoListColumns', [
        { field: 'title', title: '', width: 80, },
        { field: 'staff', title: '', width: 90, bodyTemplateName: 'tooltip' },
        { field: 'dept', title: '', width: 130, bodyTemplateName: 'tooltip'},
        { field: 'date', title: '', width: 130, type: 'date', dataFormat: 'g' },
      ]);
      this.set('worklistDetailColumns',[
        { title: this.getLanguageResource('5259', 'F','Order Code'), field: 'orderCode', width: 50,align: 'center' },
        { title: this.getLanguageResource('5218', 'F','Order Name'), field: 'orderName', width: 250, bodyTemplateName: 'tooltip' },
      ]);
      this.set('observationInfoColumns',[
        { title: this.getLanguageResource('16919', 'S','Exam Code'), field: 'examinationCode', width: 75,align: 'center' },
        { title: this.getLanguageResource('16920', 'S','Exam Name'), field: 'examinationName', width: 250, bodyTemplateName: 'tooltip'},
      ]);
      this.set('tatListStyle', 'display:none;');
    },

    _setPontColumns(){
      return { field: 'progressType.code', title: this.getLanguageResource('3813', 'S','속성'), align: 'center', bodyTemplateName: 'icon', width: 39,
        onBodyCellRender: function (context) {
          if(!isEmpty(context.item.point)){
            set(context.cellComponent, 'description', `${get(context.item, 'point')}`);
            set(context.cellComponent, 'descriptionStyle', 'font-weight: bold; width: 90px;');
          }
        }
      };
    },
    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1360');
      if (this.hasState() === false) {
        const defaultUrl= this.get('defaultUrl');
        hash({
          examTypeItemsSource: this.getList(defaultUrl+ 'classifications/search', {selectedOption: 2, classificationType: 1}, null),
          examinationTagNameItemsSource: this.getList(this.get('defaultUrl') + 'worklist-configurations/search',
            {staffId: this.get('co_CurrentUserService.user.employeeId')}, null),
          businessCodes: this.getList(defaultUrl + 'business-codes/search', null,{
            classificationCodes: [
              'WorkListSearchCode','TatSearchCode','EncounterTypeCode', 'TatTimeMinute', 'WorkListReObservationSearchCode'
            ]
          }, false),
          tatPercentCodes: this.getList(defaultUrl + 'business-codes/search', {classificationCode: 'TatPercentSearchCode'}, null)
        }).then(function(result) {
          this.set('examTypeItemsSource', result.examTypeItemsSource);
          const searhConditionItemsSource=[];
          const tatSearchTypecodeItemsSource= [];
          const patientTypeItemsSource= [];
          const tatSearchTimeMinuteItemsSource= [];
          const workListReObservationSearchItems = [];
          if(!isEmpty(result.businessCodes)){
            result.businessCodes.forEach(e=>{
              if(e.classificationCode == 'WorkListSearchCode'){
                searhConditionItemsSource.addObject(e);
              }else if(e.classificationCode == 'TatSearchCode'){
                tatSearchTypecodeItemsSource.addObject(e);
              }else if(e.classificationCode == 'EncounterTypeCode'){
                patientTypeItemsSource.addObject(e);
              }else if(e.classificationCode == 'TatTimeMinute'){
                tatSearchTimeMinuteItemsSource.addObject(e);
              }else if(e.classificationCode === 'WorkListReObservationSearchCode') {
                workListReObservationSearchItems.addObject(e);
              }
            });
            this.set('searhConditionItemsSource', searhConditionItemsSource);
            this.set('tatPercentCodes', result.tatPercentCodes);
            this.get('tatPercentCodes').unshiftObject({code: 'A', name: this.getLanguageResource('6700', 'F', '', '전체')});
            this.set('tatSearchTypecodeItemsSource', tatSearchTypecodeItemsSource);
            this.set('patientTypeItemsSource', patientTypeItemsSource);
            this.set('tatSearchTimeMinuteItemsSource', tatSearchTimeMinuteItemsSource);
            this.set('WorkListReObservationSearchItems', workListReObservationSearchItems);
            this.set('examinationTagNameItemsSource', result.examinationTagNameItemsSource);
            this.set('hpcSelectedValue', 'All');
            // const filterdExaminationTagList=[];
            // if(!isEmpty(result.examinationTagNameItemsSource)){
            //   result.examinationTagNameItemsSource.forEach(e=>{
            //검사분류, 작업단위, 검사항목별로 나눠서 저장해둠
            // filterdExaminationTagList.addObject(this._filterExaminationTagList(
            //   e.workListFindConfigurationId, e.property.classifications, e.property.unitWorks, e.property.observationExaminations));
            // });
            // this.set('filterdExaminationTagList', filterdExaminationTagList);
            // }
            this._getPersonalSettingInfo();
            this._getDepartment();
          }
          // this.set('isWorkListGridShow', false);
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      }
    },
    didInsertElement() {
      this._super(...arguments);
      this.set('_internalClickEventHandler', function () {
        // event.stopPropagation();
        // event.preventDefault();
        if(this.get('tatListEl')) {
          if (this.get('tatListEl').style.display === 'block' && event.target !== this.get('tatInputEl')) {
            this.get('tatInputEl').blur();
            this.set('tatListStyle', 'display:none;');
          }
          if(event.target === this.get('tatInputEl')) {
            this.get('tatInputEl').select();
          }
        }
      }.bind(this));
      this.element.addEventListener('click', this._internalClickEventHandler, false);
      this.get('co_ContentMessageService').subscribeMessage('afterHideAccessPopup', this.get('viewId'), this, this._afterHideAccessPopup);
      this.get('co_ContentMessageService').subscribeMessage('EXAMINATION_SETTING_CALLBACK_LIST', this.get('viewId'), this, this._getExaminationSettings);
    },

    willDestroyElement() {
      this._super(...arguments);
      this.element.removeEventListener('click', this._internalClickEventHandler, false);
      this.get('co_ContentMessageService').unsubscribeMessage('EXAMINATION_SETTING_CALLBACK_LIST', this.get('viewId'), this, this._getExaminationSettings);
    },

    _getExaminationSettings(sResult) {
      if(sResult.isSelectionConfirmCB) {
        return;
      }
      let currentCongifId = null;
      const selectedSetItem = this.get('examinationTagNameSelectedItem');
      if(!isEmpty(selectedSetItem)) {
        currentCongifId = selectedSetItem.workListFindConfigurationId;
      }
      if(sResult.workListFindConfigurationId === currentCongifId) {
        let tagList = null;
        if(sResult.tagList === null) {
          tagList = this.get('examinationTagList');
        } else {
          tagList = sResult.tagList;
        }
        this.set('callBackViewSet.selectedTagSet', null);
        // this.set('examinationTagNameSelectedItem', null);
        this._setExaminationTagList(tagList);
        this.set('examinationCategoryTagItems', sResult.examinationCategoryTagItems);
        this.set('examinationUnitTagItems', sResult.examinationUnitTagItems);
        this.set('examinationTagItems', sResult.examinationTagItems);
        // const ids=[];
        if(!isEmpty(sResult.workListFindConfigurationId)){
          //저장된 세트를 선택한 경우
          this._setExaminationComboBox(sResult.workListFindConfigurationId);
          this.set('examSetRefresh', false);
        }else{
          this.set('examinationTagNameSelectedItem', null);
          this.set('examinationTagList', tagList);
        }
        this._selectedSearchCondition();
        this.set('isWorkListGridShow', true);
        const searchCondition= this.get('searchCondition');
        if(isEmpty(searchCondition.classificationIds) && isEmpty(searchCondition.unitWorkIds)
          && isEmpty(searchCondition.examinationIds) && isEmpty(searchCondition.subjectNumber)){
          this._setPersonalSettingInfo(this.get('searchCondition'));
          // this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9192', 'F', '검색 조건을 확인하세요'), 'warning', 'Ok', 'Ok', '', 2000);
          this.set('isWorkListGridShow', false);
          return;
        }
        this.getList(this.get('defaultUrl') + 'specimen-examination-worklists/search', null, searchCondition, false).then(res=>{
          this._setPersonalSettingInfo(this.get('searchCondition'));
          this.set('overViewSearchCondition', false);
          this.set('isWorkListGridShow', false);
          if(isEmpty(res)){
            this.set('worklistItemsSource', []);
            this.set('originalDatas', []);
            return;
          }
          this._setGridData(res);
        }).catch(function(error){
          this._catchError(error);
        }.bind(this));
      } else {
        this._setExaminationComboBox(currentCongifId);
      }

    },
    // 4. Actions Area
    actions: {
      onContextMenuOpen(e) {
        if(isEmpty(e.dataItem.item)) {
          set(e, 'cancel', true);
          return;
        }
        let isDisabled = false;
        const gridSelectedItems = this.get('_gridControl.selectedItems');
        if(isEmpty(gridSelectedItems)) {
          isDisabled = true;
        } else {
          const findItem = gridSelectedItems.find(d => d.checkInId === e.dataItem.item.checkInId);
          if(isEmpty(findItem)) {
            isDisabled = true;
          }
        }
        set(this.get('gridContextMenuSource').findBy('alias', 'tatReason'), 'disabled', isDisabled);
      },
      onTATReasonEntry(e) {
        console.log('onTATReasonEntry--', e);
        if(isEmpty(e.dataItem.item)) {
          set(e, 'cancel', true);
          return;
        }
        let checkInId = e.dataItem.item.checkInId;
        let specimenId = e.dataItem.item.specimenId;
        const gridSelectedItems = this.get('_gridControl.selectedItems');
        if(isPresent(gridSelectedItems)) {
          const specimens = [];
          gridSelectedItems.forEach(d => {
            specimens.push({
              specimenId: d.specimenId,
              checkinId: d.checkInId,
            });
          });
          this.set('reasonSpecimens', specimens);
          if(gridSelectedItems.length === 1) {
            checkInId = gridSelectedItems[0].checkInId;
            specimenId = gridSelectedItems[0].specimenId;
          }
        }
        this.set('checkInId', checkInId);
        this.set('specimenId', specimenId);
        this.set('isTATReasonOpen', true);
      },
      onReasonSaveSuccessCB() {
        this.set('isTATReasonOpen', false);
        this.set('isSaveClick', false);
        this.set('reasonSpecimens', null);
        this.set('checkInId', null);
        this.set('specimenId', null);
        this.showToastSaved();
      },
      onReasonSaveClick() {
        this.set('isSaveClick', true);
      },
      onTATReasonClosed() {
        this.set('isSaveClick', false);
      },
      onTatInputLoaded(e) {
        let inputdEl = document.getElementById(e.source.elementId).getElementsByTagName('input')[0];
        this.set('tatInputEl', inputdEl);
        inputdEl = null;
      },
      onTatListboxLoaded(e) {
        let inputdEl = document.getElementById(e.source.elementId);
        this.set('tatListEl', inputdEl);
        inputdEl = null;
      },
      onTATChanged(e) {
        this.set('tatDirectInputTimeMinute', e.item.name);
        this.set('tatListStyle', 'display:none;');
        this._getWorklkst(copy(this.get('searchCondition')));
        this.set('isTATListClick', false);
      },
      onTATFocusIn(e) {
        console.log('onTATFocusIn--', e);
        this.set('tatListStyle', 'display:block;');
      },
      onTATInputKeyDown() {
        // event.preventDefault();
        if(event.keyCode === 27) {
          this.get('tatInputEl').blur();
          this.set('tatListStyle', 'display:none;');
        }
      },
      onTATListClick() {
        this.set('isTATListClick', true);
      },
      onTATKeyDown(e) {
        const isBackspace = (event.keyCode === 8) || (event.keyCode === 46);
        const isNumberKey = (event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 109);
        if(isBackspace || isNumberKey || (event.keyCode === 13)) {
          if(event.keyCode === 13 && isPresent(this.get('filterTATValue'))) {
            set(e.source, 'isOpen', false);
            this._getWorklkst(copy(this.get('searchCondition')));
          }
        } else {
          let inputEl = document.getElementsByClassName('search-combobox')[0].getElementsByTagName('input')[0];
          inputEl.value = '';
          inputEl = null;
          later(() => {
            this.showToast('error', '', this.getLanguageResource('tempkey', 'F', '', '숫자만 입력해주세요.'));
            this.set('filterTATValue', '');
          });
        }
      },
      onGridScroll(e){
        if(this.get('originalDatas.length') === this.get('worklistItemsSource.length')) {
          return;
        }
        if(e.maxTop !== 0 && Math.round(e.maxTop) <= Math.round(e.top) + 1){
          this.set('currentPage', this.get('currentPage') + 1);
          const pageItems = this.getPageSource(this.get('originalDatas'));
          if(isPresent(pageItems)) {
            this.get('worklistItemsSource').addObjects(pageItems);
          }
        }
      },
      onGridSortingColumnsChanged(e) {
        const colList = this.get('worklistColumns');
        colList.forEach(col => {
          if(col.field === 'checkInNumber' || col.field === 'specimenType.name' || col.field === 'specimenNumber') {
            set(col, 'isSorted', false);
            if(!isEmpty(e.sortingColumns) && col.field === e.sortingColumns[0].column.field) {
              set(col, 'isSorted', true);
              set(col, 'sortClass', e.sortingColumns[0].direction);
            }
          }
        });
      },
      onHpcChanged(e){
        this.set('hpcSelectedValue',e.value);
        this._getWorklkst(copy(this.get('searchCondition')));
      },

      onLoadCombobox(e){
        // 발행처 콤보박스
        if (e.source.name =='issuedDepartment'){
          this.set('issuedDepartmentCombobox', e.source);
        }
      },
      onFoldClick() {
        this.set('isSubSearchVisible', !this.get('isSubSearchVisible'));
        this._setPersonalSettingInfo(this.get('searchCondition'));
      },
      onTatPercentCodeChanged(e) {
        this.set('searchCondition.tatPercentSearchTypeCode', e.item.code);
        this._getWorklkst(copy(this.get('searchCondition')));
      },
      onWorklistGridLoad(e) {
        this.set('_gridControl',e.source);
      },

      onExamSetChanged(e){
        if(e.source.name=='general'){
          set(this.get('searchCondition'), 'isStat', false);
          set(this.get('searchCondition'), 'isToday', false);
        }else{
          this.set('isGeneralChecked', false);
        }
        this._examSetSelectionChanged(e.item);

      },
      onExamSetSelectionChanged(e) {
        if(isEmpty(e.selectedItems)) {
          // this.set('worklistItemsSource', null);
          // this._setExaminationComboBox();
        }

      },
      onCheckOptionChanged(type, e) {
        if(e.checked) {
          if(type === 'general') {
            set(this.get('searchCondition'), 'isStat', false);
            set(this.get('searchCondition'), 'isToday', false);
          } else {
            this.set('isGeneralChecked', false);
          }
        }

      },
      onSearchClick(){
        if(this.get('overViewSearchCondition')==true){
          return;
        }
        const searchCondition= copy(this.get('searchCondition'));
        if(!isEmpty(this.get('callBackViewSet').selectedTagSet)){
          //태그 수정 후 overview에서 calllback한 경우
          this._setbyCallbackViewSet(searchCondition, this.get('callBackViewSet'));
        }else{
          this._selectedSearchCondition();
        }
        this.set('tatListStyle', 'display:none;');
        this.set('isTATListClick', false);
        this._getWorklkst(searchCondition);
        next(() => {
          this._setPersonalSettingInfo(this.get('searchCondition'));
        });
      },
      onSearchCodeChanged() {
        // if(this.get('searchCondition.queryOption') !== '1') {
        //   set(this.get('searchCondition'), 'reObservationOption', '1');
        // }
        const searchCondition= copy(this.get('searchCondition'));
        if(!isEmpty(this.get('callBackViewSet').selectedTagSet)){
          //태그 수정 후 overview에서 calllback한 경우
          this._setbyCallbackViewSet(searchCondition, this.get('callBackViewSet'));
        }else{
          this._selectedSearchCondition();
        }
        this.set('tatListStyle', 'display:none;');
        this.set('isTATListClick', false);
        this._getWorklkst(searchCondition);
        next(() => {
          this._setPersonalSettingInfo(this.get('searchCondition'));
        });
      },
      onReObsevationChanged(e) {
        set(this.get('searchCondition'), 'reObservationOption', e.item.code);
        // set(this.get('searchCondition'), 'queryOption', '1');
        const searchCondition= copy(this.get('searchCondition'));
        if(!isEmpty(this.get('callBackViewSet').selectedTagSet)){
          //태그 수정 후 overview에서 calllback한 경우
          this._setbyCallbackViewSet(searchCondition, this.get('callBackViewSet'));
        }else{
          this._selectedSearchCondition();
        }
        this.set('tatListStyle', 'display:none;');
        this.set('isTATListClick', false);
        this._getWorklkst(searchCondition);
      },

      onDateSelectionChanged(){
        const searchCondition= copy(this.get('searchCondition'));
        this._getWorklkst(searchCondition);
      },

      onGridSelectionChanged(e){
        this.set('selectedItems', e.selectedItems);
      },

      onPrintBarcodeClick(){
        const items= this.get('_gridControl.selectedItems');
        if(isEmpty(items)){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9260', 'F', 'Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        this.set('isLabelPrint', true);
        this.set('printouts', null);
        this.set('printDataFieldDefault', []);
        this.set('printDataFieldD', []);
        this.set('printDataFieldG', []);
        this.set('printDataFieldF', []);
        items.forEach(element => {
          set(element, 'index', this.get('_gridControl').getItemIndex(element));
        });
        // this.getPrinterName().then(function(res){
        // this.set('printSetting', res);
        items.sortBy('index').forEach(e => {
          this._getSpecimenLabel(e);
        });
        const printSetting= this.get('printSetting');
        next(this, function(){
          this.set('printPopup', false);
          if(isEmpty(this.get('printDataFieldG')) && isEmpty(this.get('printDataFieldD')) && isEmpty(this.get('printDataFieldF'))){
            this.set('printConfig', {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerDefault });
            this.set('printContent', {
              'parameterField': {},
              'dataField': { "specimenInfo" : this.get('printDataFieldDefault')}});
            console.log(this.get('printSetting'));
            console.log(this.get('printConfig'));
            console.log(this.get('printContent'));
            this.set('printDataFieldDefault' ,null);
          }else{
            this._print();
          }
          const num= isEmpty(this.get('printouts'))? '': this.get('printouts');
          this.get('specimenCheckinService').onShowToast('save', this.getLanguageResource('16928', 'S', '출력매수') + ": \xa0"+ num, '',8000);
        }.bind(this));
        // }.bind(this)).catch(function(error){
        //   this._catchError(error);
        // }.bind(this));
      },

      onCellDoubleClick(){
        const selectedItem= this.get('gridSelectedItem');
        if(isEmpty(selectedItem)){
          return;
        }
        this.get('specimenCheckinService').getDisplayView(selectedItem.specimenNumber, null).then(function(res){
          if(isEmpty(res)){
            this.get('specimenCheckinService')._showMessage('Display View Error', 'warning', 'Ok', 'Ok', '', 2000);
            return;
          }
          const globalItem = {
            patientChoicePath: 'Encounter',
            patientId: selectedItem.subjectId,
            encounterId: selectedItem.specimenOrders.get('firstObject.encounterId'),
            examination:{
              state: selectedItem.progressStatusCode,
              specimenId: selectedItem.specimenId,
            },
            patientSelectionSource: {viewId: 'specimen-check-in-work-list-find'}
          };
          const m = A();
          let isPBS= false;
          // const _menus = A([]);
          res.forEach( e => {
            const temp={
              displayCode: e.viewId,
              stateType: null,
              parameters: {
                specimenNumber:selectedItem.specimenNumber,
                examinationCode:selectedItem.observation.get('firstObject.examinationCode'),
                checkInId: selectedItem.checkInId
              }
            };
            if(e.viewId == "specimen-examination-report-blood-cell-morphology"){
              isPBS = true;
            }
            m.addObject(temp);
          });
          this.getList(this.get('defaultUrl') + 'specimen-checkins/requests/current-encounter',
            {procedureRequestId: selectedItem.specimenOrders.get('firstObject.basedOn.id')}, null, false).then(function(result) {
            if(!isEmpty(result) && !isEmpty(result.encounterId)){
              globalItem.encounterId = result.encounterId;
            }
            this.get('co_PatientManagerService').selectPatient(globalItem, isPBS ? m.reverse() : m);
          }.bind(this)).catch(function(error){
            this._catchError(error);
            this.get('co_PatientManagerService').selectPatient(globalItem, isPBS ? m.reverse() : m);
          }.bind(this));
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      },

      onGridBeforeClick(e){
        this.set('expandedDetailRowItem',e.source.getOriginalSource(e.originalEvent).item);
      },

      onDetailRowItemsChanged(e){
        const expandedDetailRowItem= this.get('expandedDetailRowItem');
        if(isEmpty(expandedDetailRowItem) || isEmpty(e.expandedDetailRowItems)){
          return;
        }
        this.set('isDetailGridShow', true);
        this.get('specimenCheckinService').getOverView(expandedDetailRowItem.specimenNumber).then(function(res) {
          this.set('isDetailGridShow', false);
          if(res){
            let gridDetailEl = document.getElementById(e.source.elementId).getElementsByClassName('c-gdetail');
            set(expandedDetailRowItem, 'overview', res);
            next(() => {
              $(gridDetailEl).find('.scrollbar-macosx').scrollbar();
              gridDetailEl = null;
            });
          }
        }.bind(this)).catch(function(error){
          this._catchError(error);
          this.set('isDetailGridShow', false);
        }.bind(this));
      },

      onPrintBtnClick(){
        // const selectedItems= this.get('selectedItems');//_gridControl
        const selectedItems = this.get('_gridControl.selectedItems');
        if(isEmpty(selectedItems)){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9260', 'F', 'Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        const originaDatas = this.get('originalDatas');
        let targetItems = selectedItems;
        if(selectedItems.length === this.get('worklistItemsSource').length) {
          targetItems = originaDatas;
        }

        this.set('isLabelPrint', false);
        const searchCondition =this.get('searchCondition');
        const worklist = [];
        targetItems.forEach(e=>{
          worklist.addObject({
            "checkInNumber" : e.checkInNumber,
            "checkInDate" : e.checkInDate.toFormatString(true, false),
            "subjectNumber" : e.subject.number,
            "subjectName" : e.subject.name,
            "issuedDepartmentName" : e.specimenOrders.get('firstObject.issuedDepartment.name'),
            "specimenTypeName" : e.specimenType.name,
            "classificationName" : e.orderNames,
            "specimenNumber" : e.specimenNumber,
            // "orderComment" : e.specimenOrders.get('firstObject.orderComment'),
            "orderComment" : e.orderComment,
            "collectionComment" : e.collectionComment,
            "ssn":"",
            "collectionEndDatetime": e.collectionEndDatetime.toFormatString(true, false),
          });
        });
        this.set('printPopup',true);
        this.set('printConfig',{'printType': 2, 'commonInformation' : true, 'printName': "DiagnosisExaminationWorklistPortrait" });
        const examinationTagList= this.get('examinationTagList');
        let tmpUnit=null;
        if(!isEmpty(examinationTagList)){
          if(!isEmpty(examinationTagList[1])){
            tmpUnit=examinationTagList[1].items.mapBy('name');
          }
        }
        this.set('printContent',{
          dataField :{ "worklist": worklist},
          parameterField :{
            "unitWorkIds": tmpUnit,
            "checkInFromDate" : searchCondition.checkInFromDate.toFormatString(true, false),
            "checkInToDate" : searchCondition.checkInToDate.toFormatString(true, false)
          }
        });

      },

      //2018-12-07 검색조건 UI수정
      onSearchPopupOnClick(e){
        this.set('findSettingPopupInfo.isOpen', !this.get('findSettingPopupInfo.isOpen'));
        this.set('findSettingPopupInfo.targetId', e.originalEvent.currentTarget);
        this.set('examinationTagList', copy(this.get('examinationTagList')));
        this._setExaminationTagList(this.get('examinationTagList'));
      },

      //팝업 콜백 이벤트
      onFindSettingCallBack(sResult){
        let currentCongifId = null;
        const selectedSetItem = this.get('examinationTagNameSelectedItem');
        if(!isEmpty(selectedSetItem)) {
          currentCongifId = selectedSetItem.workListFindConfigurationId;
        }
        if(sResult.workListFindConfigurationId !== currentCongifId && !sResult.isSelectionConfirmCB) {
          this._setExaminationComboBox(currentCongifId);
          this.get('co_ContentMessageService').sendMessage('EXAMINATION_SETTING_CALLBACK_OVERVIEW', sResult);
          this.get('co_ContentMessageService').sendMessage('EXAMINATION_SETTING_CALLBACK_BRIEF', sResult);
        } else {
          this.set('callBackViewSet.selectedTagSet', null);
          // this.set('examinationTagNameSelectedItem', null);
          this._setExaminationTagList(sResult.tagList);
          this.set('examinationCategoryTagItems', sResult.examinationCategoryTagItems);
          this.set('examinationUnitTagItems', sResult.examinationUnitTagItems);
          this.set('examinationTagItems', sResult.examinationTagItems);
          // const ids=[];
          if(!isEmpty(sResult.workListFindConfigurationId)){
            //저장된 세트를 선택한 경우
            this._setExaminationComboBox(sResult.workListFindConfigurationId);
            this.set('examSetRefresh', false);
          }else{
            this.set('examinationTagNameSelectedItem', null);
            this.set('examinationTagList', sResult.tagList);
          }
          this.get('co_ContentMessageService').sendMessage('EXAMINATION_SETTING_CALLBACK_OVERVIEW', sResult);
          this.get('co_ContentMessageService').sendMessage('EXAMINATION_SETTING_CALLBACK_BRIEF', sResult);
          this._selectedSearchCondition();
          this.set('isWorkListGridShow', true);
          const searchCondition= this.get('searchCondition');
          if(isEmpty(searchCondition.classificationIds) && isEmpty(searchCondition.unitWorkIds)
            && isEmpty(searchCondition.examinationIds) && isEmpty(searchCondition.subjectNumber)){
            this._setPersonalSettingInfo(this.get('searchCondition'));
            this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9192', 'F', '검색 조건을 확인하세요'), 'warning', 'Ok', 'Ok', '', 2000);
            this.set('isWorkListGridShow', false);
            return;
          }
          this.getList(this.get('defaultUrl') + 'specimen-examination-worklists/search', null, searchCondition, false).then(res=>{
            if(isEmpty(res)){
              this.set('worklistItemsSource', []);
              this.set('originalDatas', []);
            } else {
              this._setGridData(res);
            }
            this._setPersonalSettingInfo(this.get('searchCondition'));
            this.set('overViewSearchCondition', false);
            this.set('isWorkListGridShow', false);
            // this.get('co_ContentMessageService').sendMessage('EXAMINATION_SETTING_CALLBACK_OVERVIEW', sResult);
            // this.get('co_ContentMessageService').sendMessage('EXAMINATION_SETTING_CALLBACK_BRIEF', sResult);
          }).catch(function(error){
            this._catchError(error);
          }.bind(this));
        }
      },

      onEncounterTypeCodeChanged(){
        this._getDepartment();
      },

      onExcelPrintAction() {
        const itemsSource = this.get('originalDatas');
        const columns = $.extend(true, [], this.get('worklistColumns').map(function(e){
          return $.extend(true, {}, e);
        }));
        if(isEmpty(itemsSource)){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9264', 'F', '조회된 정보가 없습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        columns.removeObject(columns[0]);
        this._getExportExcel(itemsSource, columns);

        // const gridSource=this.get('_gridControl');
        // const reason = 'Excel export work list';
        // const headers=[];
        // const fields=[];

        // columns.forEach(function(item, index){
        //   const tmp= item.field== 'progressType.code'? 'progressType.name' : item.field;
        //   headers.addObject({ left: index, top: 0, right: index, bottom: 0, value: item.title });
        //   fields.addObject({ width: item.width, value: tmp });
        // });
        // gridSource.exportToExcel('work_list.xlsx', headers, fields, this, 'onExcelPrintAction', reason , itemsSource);
      },

      onPrintReferralBtnClick(){
        if(this.get('_gridControl.selectedItems').length != 1){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('10177', 'F', '하나의 행을 선택하세요'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        if(!isEmpty(this.get('gridSelectedItem.referralRecordNoteId'))){
          this.set('printReferralOpen', true);
          this.set('referralRecordNoteId', this.get('gridSelectedItem.referralRecordNoteId'));
        }else{
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9848', 'F', '출력할 정보가 없습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
        }
      },

      onExePrintAfterCB(){
        if(this.get('isLabelPrint')){
          this._print();
        }
      },

      onFindSettingClosedCB(){
        //셋팅 팝업 닫은 후 콜백 - 저장건이 있었으면 재조회
        // if(this.get('examSetRefresh')){
        //   this._setExaminationComboBox(this.get('examinationTagNameSelectedItem.workListFindConfigurationId'),'noUpdate');
        //   this.set('examSetRefresh', false);
        // }
      },

      onLinkedConsentClick(){
        if(this.get('_gridControl.selectedItems').length != 1){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('10177', 'F', '하나의 행을 선택하세요'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        this.set('isConsentPopupOpen', true);
      },

    },
    // 5. Private methods Area
    _print(){
      const printSetting= this.get('printSetting');
      // this.set('printPopup', false);
      if(!isEmpty(this.get('printDataFieldG'))){
        this.set('printConfig', {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerG });
        this.set('printContent', {
          'parameterField': {},
          'dataField': { "specimenInfo" : this.get('printDataFieldG')}});
        console.log(this.get('printConfig'));
        console.log(this.get('printContent'));
        this.set('printDataFieldG' ,null);
        return;
      }
      if(!isEmpty(this.get('printDataFieldD'))){
        this.set('printConfig', {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerD });
        this.set('printContent', {
          'parameterField': {},
          'dataField': { "specimenInfo" : this.get('printDataFieldD')}});
        console.log(this.get('printConfig'));
        console.log(this.get('printContent'));
        this.set('printDataFieldD' ,null);
        return;
      }
      if(!isEmpty(this.get('printDataFieldF'))){
        this.set('printConfig', {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerF });
        this.set('printContent', {
          'parameterField': {},
          'dataField': { "specimenInfo" : this.get('printDataFieldF')}});
        console.log(this.get('printConfig'));
        console.log(this.get('printContent'));
        this.set('printDataFieldF' ,null);
        return;
      }
      if(!isEmpty(this.get('printDataFieldDefault'))){
        this.set('printConfig', {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerDefault });
        this.set('printContent', {
          'parameterField': {},
          'dataField': { "specimenInfo" : this.get('printDataFieldDefault')}});
        console.log(this.get('printConfig'));
        console.log(this.get('printContent'));
        this.set('printDataFieldDefault' ,null);
      }
    },
    _getPersonalSettingInfo(){
      const today= this.get('co_CommonService').getNow();
      const fromTime = new Date(today.getFullYear(), today.getMonth(), today.getDate(), 0, 0, 0);
      const toTime = new Date(today.getFullYear(), today.getMonth(), today.getDate(), 23, 59, 59);
      // this.set('searchCondition',searchCondition);
      this.get('co_PersonalizationService').getSettingInfo(`specimen-check-in-work-list-find`).then(settingInfo => {
        const searchCondition= {
          checkInFromDate: today,
          checkInToDate: today,
          checkInFromDateTime: fromTime,
          checkInToDateTime: toTime,
          tatSearchTypecode: this.get('tatSearchTypecodeItemsSource.firstObject.code'),
          encounterTypeCode: this.get('patientTypeItemsSource.firstObject.code'),
          tatSearchTimeMinute: this.get('tatSearchTimeMinuteItemsSource.firstObject.code'),
          checkInStartNumber: null,
          checkInEndNumber: null,
          tatPercentSearchTypeCode: this.get('tatPercentCodes.firstObject.code')
        };
        this.set('tatDirectInputTimeMinute', searchCondition.tatSearchTimeMinute);
        if(isEmpty(settingInfo.settingValue)){
          this.set('examinationTagNameSelectedItem', this.get('examinationTagNameItemsSource.firstObject'));
          searchCondition.queryOption = "2";
          searchCondition.classificationIds = null;
          searchCondition.unitWorkIds = null;
          searchCondition.examinationIds = null;
          searchCondition.isStat = false;
          searchCondition.isToday = false;
          searchCondition.reObservationOption = '1';
        }else{
          const data = JSON.parse(settingInfo.settingValue).conditionData.get('firstObject');
          searchCondition.queryOption= data.queryOption;
          searchCondition.classificationIds= data.classificationIds;
          searchCondition.unitWorkIds= data.unitWorkIds;
          searchCondition.examinationIds= data.examinationIds;
          searchCondition.isStat= data.isStat;
          searchCondition.isToday= data.isToday;
          this.set('hpcSelectedValue', JSON.parse(settingInfo.settingValue).hpcSearchTypeCode);
          // searchCondition.reObservationOption = data.queryOption === '1' ? data.reObservationOption : '1';
          searchCondition.reObservationOption = data.reObservationOption;
          this.set('isSubSearchVisible', JSON.parse(settingInfo.settingValue).isSubSearchVisible);
          if(!isEmpty(JSON.parse(settingInfo.settingValue).conditionData[1])){
            if(!isEmpty(this.get('examinationTagNameItemsSource')) && !isEmpty(JSON.parse(settingInfo.settingValue).conditionData[1].workListFindConfigurationId)){
              this.set('examinationTagNameSelectedItem', this.get('examinationTagNameItemsSource').findBy('workListFindConfigurationId', JSON.parse(settingInfo.settingValue).conditionData[1].workListFindConfigurationId));
            }
          }else{
            this.set('examinationTagNameSelectedItem', JSON.parse(settingInfo.settingValue).conditionData[1]);
          }
          this.set('examinationTagList', JSON.parse(settingInfo.settingValue).conditionData[2]);
          next(this, function(){
            this.set('searchCondition', searchCondition);
          }.bind(this));
          return;
        }
        this.set('isWorkListGridShow', false);
        next(this, function(){
          this.set('searchCondition', searchCondition);
        }.bind(this));
      }).catch(function(error){
        this.set('searchCondition', {
          queryOption: "2",
          classificationIds: null,
          unitWorkIds: null,
          examinationIds: null,
          isStat: false,
          isToday: false
        });
        this._catchError(error);
      }.bind(this));
    },

    async _requestCurrentEncounter(procedureRequestId){
      await this.getList(this.get('defaultUrl') + 'specimen-checkins/requests/current-encounter', {procedureRequestId: procedureRequestId},null, false).then(function (result) {
        return result.encounterId;
      }).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    _setPersonalSettingInfo(searchCondition){
      this.get('co_PersonalizationService').setSettingInfo(`specimen-check-in-work-list-find`,
        JSON.stringify({
          conditionData:[ searchCondition, this.get('examinationTagNameSelectedItem'), this.get('examinationTagList')],
          hpcSearchTypeCode: this.get('hpcSelectedValue'),
          isSubSearchVisible: this.get('isSubSearchVisible')
        }), '진단검사워크리스트 조회 설정 저장');
      if(isEmpty(this.get('examinationTagList'))){
        this.get('co_PersonalizationService').setSettingInfo(`specimen-check-in-work-list-overview`,
          JSON.stringify({conditionData:[null, this.get('examinationTagNameItemsSource.firstObject'), searchCondition.queryOption]}),
          '진단검사 워크리스트 OverView 설정 저장');
      }else{
        this.get('co_PersonalizationService').setSettingInfo(`specimen-check-in-work-list-overview`,
          JSON.stringify({
            conditionData:[this.get('examinationTagList'), this.get('examinationTagNameSelectedItem'), searchCondition.queryOption],
            hpcSearchTypeCode: this.get('hpcSelectedValue')
          }), '진단검사 워크리스트 OverView 설정 저장');
      }
    },

    _examSetSelectionChanged(selectedItem){
      if(this.get('overViewSearchCondition')==true){
        return;
      }
      const examinationTagNameSelectedItem= isEmpty(selectedItem)? this.get('examinationTagNameSelectedItem'): selectedItem;
      if(!isEmpty(examinationTagNameSelectedItem)){
        this._setByselectedExamSet( examinationTagNameSelectedItem);
      }
      this._getWorklkst(copy(this.get('searchCondition')));

    },
    _setByselectedExamSet(examinationTagNameSelectedItem){
      const searchCondition= this.get('searchCondition');
      set(searchCondition, 'classificationIds', null);
      set(searchCondition, 'unitWorkIds', null);
      set(searchCondition, 'examinationIds', null);
      if(!isEmpty(examinationTagNameSelectedItem.property.classifications)){
        set(searchCondition, 'classificationIds', examinationTagNameSelectedItem.property.classifications.mapBy('id'));
      }
      if(!isEmpty(examinationTagNameSelectedItem.property.unitWorks)){
        set(searchCondition, 'unitWorkIds', examinationTagNameSelectedItem.property.unitWorks.mapBy('id'));
      }
      if(!isEmpty(examinationTagNameSelectedItem.property.observationExaminations)){
        set(searchCondition, 'examinationIds', examinationTagNameSelectedItem.property.observationExaminations.mapBy('id'));
      }
    },
    _selectedSearchCondition(){
      const examinationTagList= this.get('examinationTagList');
      const searchCondition= this.get('searchCondition');
      set(searchCondition, 'classificationIds', null);
      set(searchCondition, 'unitWorkIds', null);
      set(searchCondition, 'examinationIds', null);
      if(!isEmpty(examinationTagList)){
        examinationTagList.forEach(e=>{
          if(e.type=='category' && !isEmpty(e.items)){
            set(searchCondition, 'classificationIds', e.items.mapBy('id'));
          }else if(e.type=='unit' && !isEmpty(e.items)){
            set(searchCondition, 'unitWorkIds', e.items.mapBy('id'));
          }else if(e.type=='exam' && !isEmpty(e.items)){
            set(searchCondition, 'examinationIds', e.items.mapBy('id'));
          }
        });
      }
    },
    _isCallBackViewSetChanged(callBackViewSet){
      const examTypeItemsSource = this.get('examTypeItemsSource');
      if(isEmpty(examTypeItemsSource)){
        //onLoaded 전
        this.set('isWorkListGridShow', false);
        return;
      }
      this.set('examinationTagList', callBackViewSet.examinationTagList);
      const searchCondition= this.get('searchCondition');
      if(isEmpty(searchCondition)){
        this.set('isWorkListGridShow', false);
        return;
      }
      set(searchCondition, 'queryOption', callBackViewSet.workListSearchCode);
      let reObservationOption = '1';
      let isGeneralChecked = false;
      let isStat = false;
      let isToday = false;
      if(isPresent(callBackViewSet.progressTypeCode)) {
        if(callBackViewSet.progressTypeCode =='A') {
          reObservationOption = '1';
        }else if(callBackViewSet.progressTypeCode === 'ReObservation'){
          reObservationOption = '2';
        }else if(callBackViewSet.progressTypeCode === 'R'){
          reObservationOption = '3';
        }else if(callBackViewSet.progressTypeCode === 'C'){
          reObservationOption = '4';
        }else if(callBackViewSet.progressTypeCode === 'G'){
          isGeneralChecked = true;
          isStat = false;
          isToday = false;
          reObservationOption = '1';
        } else {
          isGeneralChecked = false;
          isStat = true;
          isToday = true;
        }
      }
      this.set('isGeneralChecked', isGeneralChecked);
      set(searchCondition, 'isStat', isStat);
      set(searchCondition, 'isToday', isToday);
      set(searchCondition, 'reObservationOption', reObservationOption);
      if(isEmpty(callBackViewSet)){
        set(searchCondition, 'queryOption', '1');
        this.set('isWorkListGridShow', false);
        return;
      }
      set(searchCondition, 'checkInFromDate', callBackViewSet.examinationFromDate);
      set(searchCondition, 'checkInToDate', callBackViewSet.examinationToDate);
      //TODO
      const fromDate = callBackViewSet.examinationFromDate;
      const toDate = callBackViewSet.examinationToDate;
      const fromTime = new Date(fromDate.getFullYear(), fromDate.getMonth(), fromDate.getDate(), 0, 0, 0);
      const toTime = new Date(toDate.getFullYear(), toDate.getMonth(), toDate.getDate(), 23, 59, 59);
      set(searchCondition, 'checkInFromDateTime', fromTime);
      set(searchCondition, 'checkInToDateTime', toTime);
      this.set('examinationTagNameSelectedItem', callBackViewSet.examinationTagNameSelectedItem);
      this._setbyCallbackViewSet(searchCondition, this.get('callBackViewSet'));
      if(!isEmpty(callBackViewSet.examinationTagNameSelectedItem)){
        this._setByselectedExamSet(callBackViewSet.examinationTagNameSelectedItem);
      }
      // if(isEmpty(callBackViewSet.selectedTagSet) || callBackViewSet.isNull){
      //   //카운트0 인 경우
      //   // this.set('examinationTagNameSelectedItem', callBackViewSet.examinationTagNameSelectedItem);
      //   this.set('isWorkListGridShow', false);
      //   this.set('worklistItemsSource', null);
      //   return;
      // }
      this.set('overViewSearchCondition', true);
      if(isEmpty(searchCondition.classificationIds) && isEmpty(searchCondition.unitWorkIds)
        && isEmpty(searchCondition.examinationIds) && isEmpty(searchCondition.subjectNumber)){
        this._setPersonalSettingInfo(this.get('searchCondition'));
        this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9192', 'F', '검색 조건을 확인하세요'), 'warning', 'Ok', 'Ok', '', 2000);
        // this.set('examinationTagNameItemsSource', false);
        this.set('isWorkListGridShow', false);
        return;
      }
      this._getWorklkst(copy(searchCondition));
      this.set('callBackViewSet.selectedTagSet', null);
    },

    _setExaminationTagList(getTagList){
      const examinationTagNameSelectedItem = this.get('examinationTagNameSelectedItem');
      if (getTagList !== null){
        this.set('examinationTagList', getTagList);
      } else if (examinationTagNameSelectedItem !== null){
        this._setByselectedExamSet(examinationTagNameSelectedItem);
      }
    },

    _setExaminationComboBox(workListFindConfigurationId){
      this.getList(this.get('defaultUrl') + 'worklist-configurations/search',
        {staffId: this.get('co_CurrentUserService.user.employeeId')}, null).then(function(res){
        this.set('examinationTagNameItemsSource', res);
        if(!isEmpty(res)){
          // const filterdExaminationTagList=[];
          res.forEach(e=>{
            if(e.workListFindConfigurationId===workListFindConfigurationId){

              next(this, function(){
                // this.set('examinationTagNameSelectedItem', this.get('examinationTagNameSelectedItem'));
                this.set('examinationTagNameSelectedItem', e);
              }.bind(this));
            }
            //검사분류, 작업단위, 검사항목별로 나눠서 저장해둠
            // filterdExaminationTagList.addObject(this._filterExaminationTagList(
            //   e.workListFindConfigurationId, e.property.classifications, e.property.unitWorks, e.property.observationExaminations));
          });
          // this.set('filterdExaminationTagList', filterdExaminationTagList);
        }
      }.bind(this)).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    _filterExaminationTagList(workListFindConfigurationId, examinationCategoryTagItems,examinationUnitTagItems,examinationTagItems){
      const filterdExaminationTagList= [];
      filterdExaminationTagList.workListFindConfigurationId=workListFindConfigurationId;
      if(!isEmpty(examinationCategoryTagItems)){
        examinationCategoryTagItems.forEach(element => {
          filterdExaminationTagList.push({id: element.id, name: element.name, abbreviation: element.abbreviation, type: 'category'});
        });
      }
      if(!isEmpty(examinationUnitTagItems)){
        examinationUnitTagItems.forEach(element => {
          filterdExaminationTagList.push({id: element.id, name: element.name, abbreviation: element.name, type: 'unit'});
        });
      }
      if(!isEmpty(examinationTagItems)){
        examinationTagItems.forEach(element => {
          filterdExaminationTagList.push({id: element.id, name: element.name, abbreviation: element.abbreviation, type: 'exam'});
        });
      }
      return filterdExaminationTagList;
    },

    _getWorklkst(searchCondition){
      if(!isEmpty(this.get('issuedDepartmentCombobox.selectedItems'))){
        set(searchCondition, 'issuedDepartmentIds', this.get('issuedDepartmentCombobox.selectedItems').mapBy('id'));
        if(isEmpty(searchCondition.issuedDepartmentIds)){
          searchCondition.issuedDepartmentIds= null;
        }
      }else{
        set(searchCondition, 'issuedDepartmentIds', null);
      }
      if(isEmpty(searchCondition.unitWorkIds) || searchCondition.unitWorkIds.includes("")){
        searchCondition.unitWorkIds= null;
      }
      if(isEmpty(searchCondition.examinationIds) || searchCondition.examinationIds.includes("")){
        searchCondition.examinationIds= null;
      }
      if(isEmpty(searchCondition.checkInFromDate) || isEmpty(searchCondition.checkInToDate)){
        this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9290', 'F', '날짜를 확인하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
        return;
      }
      //2021.01.04 TAT 직접입력 옵션 추가
      // if(!isEmpty(this.get('filterTATValue'))) {
      //   set(searchCondition, 'tatSearchTimeMinute', this.get('filterTATValue'));
      // }
      if(!isEmpty(this.get('tatDirectInputTimeMinute'))) {
        set(searchCondition, 'tatSearchTimeMinute', this.get('tatDirectInputTimeMinute'));
      }
      if(!isEmpty(searchCondition.subjectNumber)){
        searchCondition.subjectNumber= searchCondition.subjectNumber.trim();
      }
      searchCondition.checkInFromDate= new Date(searchCondition.checkInFromDate.getFullYear(), searchCondition.checkInFromDate.getMonth(), searchCondition.checkInFromDate.getDate(), 0, 0, 0);
      searchCondition.checkInToDate= new Date(searchCondition.checkInToDate.getFullYear(), searchCondition.checkInToDate.getMonth(), searchCondition.checkInToDate.getDate(), 0, 0, 0);
      searchCondition.subjectTypeCode= 'Patient';
      searchCondition.hpcSearchTypeCode= this.get('hpcSelectedValue')=='All'? null: this.get('hpcSelectedValue');
      this.set('searchCondition',searchCondition);
      this._setPersonalSettingInfo(searchCondition);
      this.set('isWorkListGridShow', true);
      this.getList(this.get('defaultUrl') + 'specimen-examination-worklists/search', null, searchCondition, false).then(res=>{
        if(isEmpty(res)){
          this.set('originalDatas', []);
          this.set('worklistItemsSource', []);
        } else {
          this._setGridData(res);
        }
        this.set('isWorkListGridShow', false);
        // this._setPersonalSettingInfo(searchCondition);
        this.set('overViewSearchCondition', false);
      }).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },
    _setbyCallbackViewSet(searchCondition, callBackViewSet){
      searchCondition.classificationIds=null;
      searchCondition.unitWorkIds=null;
      searchCondition.examinationIds=null;
      if(!isEmpty(callBackViewSet.selectedTagSet)){

        callBackViewSet.selectedTagSet.forEach(e=>{
          if(e.type=="category"){
            set(searchCondition, 'classificationIds', e.items.map(function(item){
              return item.id;
            }));
          }else if(e.type=="unit"){
            set(searchCondition, 'unitWorkIds', e.items.map(function(item){
              return item.id;
            }));
          }else if(e.type=="exam"){
            set(searchCondition, 'examinationIds', e.items.map(function(item){
              return item.id;
            }));
          }
        });
      }
    },
    getPageSource(datas) {
      if(isEmpty(datas)) {
        return;
      }
      const startAt = this.get('currentPage') * this.get('recordSize');
      const endAt = startAt + (this.get('recordSize') - 1);
      return datas.filter(item => item.rowNum >= startAt && item.rowNum <= endAt);
    },

    _setGridData(res){
      const tmp= [];
      // let ii=null;
      if(!isEmpty(res)){
        res.map(function(item, index){
          if(!this.get('searchCondition').isStat && this.get('isGeneralChecked') && item.progressTypeCode != "G"){
            // ii ++;
            return;
          }
          const specimenOrder = item.get('specimenOrders.firstObject');
          if(isEmpty(specimenOrder)){
            return;
          }
          item.rowNum = index;
          const orderNames=[];
          let isNeedConsent= false;
          let isNeedRequest= false;
          let orderComment = '';
          item.specimenOrders.forEach(i=>{
            orderNames.addObject(i.abbreviation);
            if(i.isNeedConsent){
              isNeedConsent= true;
            }
            if(i.isNeedRequest){
              isNeedRequest= true;
            }
            if(!isEmpty(i.referralRecordNoteId)){
              item.referralRecordNoteId= i.referralRecordNoteId;
            }
            if(!isEmpty(i.orderComment)){
              orderComment= orderComment + ' '+ i.orderComment;
            }
          });
          if(item.subject.isPrivacyProtection || item.subject.isProtectionHealthInfo) {
            set(item, 'isShowIconProtect', true);
          }
          item.orderComment= orderComment;
          item.orderNames= orderNames.join(', ').toString();
          item.examinationCode= item.observation.get('firstObject.examinationCode');
          item.examinationName= item.observation.get('firstObject.examinationName');
          item.classificationInfo= isEmpty(specimenOrder.classification)? null : specimenOrder.classification.name;
          item.issuedDepartmentCode= isEmpty(specimenOrder.issuedDepartment)? null : specimenOrder.issuedDepartment.name;
          item.departmentCode= isEmpty(specimenOrder.department)? null : specimenOrder.department.name;
          item.orderedStaffName= isEmpty(specimenOrder.orderedStaff)? null : specimenOrder.orderedStaff.name;
          // item.newIndex= index-ii+1;
          // item.detailInfo= [
          //   { title: this.getLanguageResource('5725', 'F','STAT'), staff: item.specimenOrders.get('firstObject.orderedStaff.name'), dept:item.issuedDepartmentCode, date: item.specimenOrders.get('firstObject.orderDate')},
          //   { title: this.getLanguageResource('5198', 'S','Order Info.'), staff: item.specimenOrders.get('firstObject.orderedStaff.name'), dept: item.issuedDepartmentCode, date:item.specimenOrders.get('firstObject.orderDate')},
          //   { title: this.getLanguageResource('16961', 'S','Draw Sample'), staff: isEmpty(item.collectionStaff)? null:item.collectionStaff.name, dept: isEmpty(item.collectionPlace)? null: item.collectionPlace.name, date:item.collectionEndDatetime},
          //   { title: this.getLanguageResource('6091', 'S','Receive'), staff: isEmpty(item.receivedStaff)? null: item.receivedStaff.name, dept:'',date:item.receivedDateTime },
          //   { title: this.getLanguageResource('788', 'S','Check-in'), staff: item.checkInStaff.name, dept: item.checkInNumber , date: item.checkInDateTime },
          //   { title: this.getLanguageResource('901', 'S','Report'), staff:  isEmpty(item.reportedStaff)? null: item.reportedStaff.name, dept:'' , date:item.reportedDateTime},
          // ];
          item.worklistDetailItemsSource= item.specimenOrders;
          item.observationInfoItemsSource= item.observation;
          // const indicatorInfo = this._getIndicatorInfo(item.progressType.code, isNeedConsent, isNeedRequest, item.subject.isInfection, item.prescriptionTypeCode);
          // item.iconDisplay = indicatorInfo.iconFlag;
          // item.point = indicatorInfo.tooltip;
          item.iconDisplay= this._setIconDisplay(item.progressType.code, isNeedConsent, isNeedRequest, item.subject.isInfection, item.prescriptionTypeCode);
          item.point= this._setIconDisplayTooltip(item.progressType.code, isNeedConsent, isNeedRequest, item.subject.isInfection, item.prescriptionTypeCode);
          item.isNeedConsent= specimenOrder.isNeedConsent;

          let occupyingBed= isEmpty(get(item, 'ward.displayCode'))? '' : get(item, 'ward.displayCode');
          occupyingBed= isEmpty(get(item, 'room.roomCode'))? occupyingBed : occupyingBed + '/' + get(item, 'room.roomCode');
          occupyingBed= isEmpty(get(item, 'bed.displayCode'))? occupyingBed : occupyingBed + '/' + get(item, 'bed.displayCode');
          item.occupyingBed= occupyingBed;

          let occupyingBedTooltip= isEmpty(get(item, 'ward.name'))? '' : get(item, 'ward.name');
          occupyingBedTooltip= isEmpty(get(item, 'room.roomName'))? occupyingBedTooltip : occupyingBedTooltip + '/' + get(item, 'room.roomName');
          occupyingBedTooltip= isEmpty(get(item, 'bed.name'))? occupyingBedTooltip : occupyingBedTooltip + '/' + get(item, 'bed.name');
          item.occupyingBedTooltip= occupyingBedTooltip;
          tmp.addObject(item);
        }.bind(this));
      }
      // this.set('worklistItemsSource', tmp);
      this.set('currentPage', 0);
      this.set('originalDatas', tmp);
      this.set('worklistItemsSource', this.getPageSource(tmp));
    },

    _getIndicatorInfo(progressTypeCode,isNeedConsent, isNeedRequest, isInfection, prescriptionTypeCode) {
      let tooltip = [];
      let iconFlag = null;
      if(isInfection){
        iconFlag = 'isInfection';
        tooltip.addObject(this.getLanguageResource('581', 'S', 'Infection Precaution') + '<br>');
      }
      if( progressTypeCode === "F"){
        iconFlag = 'F';
        tooltip.addObject(this.getLanguageResource('5725', 'F', '응급')+ '<br>');
      }
      if(progressTypeCode === "D" ){
        iconFlag = 'D';
        tooltip.addObject(this.getLanguageResource('1880', 'F', '당일')+ '<br>');
      }
      if(isNeedConsent){
        iconFlag = 'isNeedConsent';
        tooltip.addObject(this.getLanguageResource('11740', 'S', '동의서 필요') + '<br>');
      }
      if(isNeedRequest){
        iconFlag = 'isNeedRequest';
        tooltip.addObject(this.getLanguageResource('17066', 'S', '의뢰서 필요') + '<br>');
      }
      if(prescriptionTypeCode == '6'){
        iconFlag = 'isDischarge';
        tooltip.addObject(this.getLanguageResource('11988', 'S', '퇴원오더') + '<br>');
      }
      if(tooltip.length > 1){
        tooltip = tooltip.join('').toString();
      }else{
        tooltip = [];
      }
      return {tooltip, iconFlag};
    },

    _setIconDisplay(progressTypeCode,isNeedConsent, isNeedRequest, isInfection, prescriptionTypeCode){
      //아이콘 표기 우선순위: progressTypeCode"D","F" > isInfection > isAllergy > isNeedConsent > isNeedRequest
      let res = null;
      if(isInfection){
        res = 'isInfection';
      }else if(progressTypeCode === "F"){
        res = 'F';
      }else if(progressTypeCode === "D"){
        res = 'D';
      }else if(isNeedConsent){
        res = 'isNeedConsent';
      }else if(isNeedRequest){
        res = 'isNeedRequest';
      }else if(prescriptionTypeCode == '6'){
        res = 'isDischarge';
      }
      return res;
    },

    _setIconDisplayTooltip(progressTypeCode,isNeedConsent, isNeedRequest, isInfection, prescriptionTypeCode){
      let res=[];
      if(isInfection){
        res.addObject(this.getLanguageResource('581', 'S', 'Infection Precaution') + '<br>');
      }
      if( progressTypeCode === "F"){
        res.addObject(this.getLanguageResource('5725', 'F', '응급')+ '<br>');
      }
      if(progressTypeCode === "D" ){
        res.addObject(this.getLanguageResource('1880', 'F', '당일')+ '<br>');
      }
      // if(isAllergy){
      //   res.addObject(this.getLanguageResource('4682', 'F', 'Allergy') + '<br>');
      // }
      if(isNeedConsent){
        res.addObject(this.getLanguageResource('11740', 'S', '동의서 필요') + '<br>');
      }
      if(isNeedRequest){
        res.addObject(this.getLanguageResource('17066', 'S', '의뢰서 필요') + '<br>');
      }
      if(prescriptionTypeCode == '6'){
        res.addObject(this.getLanguageResource('11988', 'S', '퇴원오더') + '<br>');
      }

      if(res.length > 1){
        res=res.join('').toString();
      }else{
        res=[];
      }
      return res;
    },

    _getDepartment(){
      let encounterTypeCode= this.get('searchCondition.encounterTypeCode');
      if(isEmpty(encounterTypeCode)){
        encounterTypeCode='A';
      }else{
        this.getList(this.get('defaultUrl')+ 'departments/search', {encounterTypeCode: encounterTypeCode}, null).then(function(res){
          this.set('deptItemsSource', isEmpty(res)? null : res);
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      }
    },
    _getSpecimenLabel(e){
      // const printDataField = this.get('printDataField');
      const printSetting = this.get('printSetting');
      this.get('specimenSamplingService').getSpecimenLabel(null, e.specimenNumber).then(res=>{
        if(!isEmpty(res)){
          this._setProperty(res);
          res.specimenTypes.forEach(function(r, idx) {
            this.set('printouts', this.get('printouts') + r.labelPrintCount);
            let specimenName = res.specimenTypes[idx].abbreviation;
            if(!isEmpty(res.specimenTypes[idx].containerName)){
              specimenName = specimenName + '(' + res.specimenTypes[idx].containerName + ')';
            }
            let u=0;
            while (u < r.labelPrintCount) {
              const resCopy= $.extend(true, EmberObject.create(), res);
              resCopy.specimenName= specimenName;
              if(res.progressTypeCode =="G"&& !isEmpty(printSetting.printerG)){
                if(printSetting.printerG == printSetting.printerDefault){
                  this.get('printDataFieldDefault').pushObject(resCopy);
                }else{
                  this.get('printDataFieldG').pushObject(resCopy);
                }
              }else if(res.progressTypeCode =="D" && !isEmpty(printSetting.printerD)){
                if(printSetting.printerD == printSetting.printerDefault){
                  this.get('printDataFieldDefault').pushObject(resCopy);
                }else{
                  this.get('printDataFieldD').pushObject(resCopy);
                }
              }else if(res.progressTypeCode =="F" && !isEmpty(printSetting.printerF)){
                if(printSetting.printerF == printSetting.printerDefault){
                  this.get('printDataFieldDefault').pushObject(resCopy);
                }else{
                  this.get('printDataFieldF').pushObject(resCopy);
                }
              }else{
                this.get('printDataFieldDefault').pushObject(resCopy);
              }
              u++;
            }
          }.bind(this));
        }
      }).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },
    // _sendPrintMessage(){
    //   const printContent = {};
    //   printContent.parameterField = {};
    //   printContent.dataField = { "specimenInfo" : this.get('printDataField') };
    //   this.set('printPopup', false);
    //   this.set('printConfig', {'printType': 1, 'printName': 'SpecimenLabel'});
    //   this.set('printContent', printContent);
    // },

    // [TEST]
    _afterHideAccessPopup(param) {
      if(param.viewId === this.get('viewId')) {
        if(param.isConfirmed === true) {
          // "확인" 을 선택하여 닫힌 경우
          this.triggerAction('onMainWorkListContainerOpenStateChange', false, 'hide');
        } else {
          // "취소" 를 선택하여 닫힌 경우
        }
      }
    },

    _catchError(e){
      this.set('isWorkListGridShow',false);
      console.log('_catchError', e);
      this.showResponseMessage(e);
    }
  });