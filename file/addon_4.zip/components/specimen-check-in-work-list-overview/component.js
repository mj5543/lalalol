/* eslint-disable max-lines */
/* eslint-disable no-console */
import { copy } from '@ember/object/internals';
import { next, cancel, later } from '@ember/runloop';
import $ from 'jquery';
import { hash } from 'rsvp';
import { isEmpty, isPresent } from '@ember/utils';
import EmberObject, { computed, set } from '@ember/object';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import specimencheckinMessageMixin from 'specimencheckin-module/mixins/specimen-check-in-message-mixin';
export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, specimencheckinMessageMixin,
  {
    layout,
    specimenCheckinService: service('specimen-check-in-service'),
    defaultUrl: null,
    isAutoReset:null,
    autoResetTimer:null,
    findSettingPopupInfo:null,
    examinationTagNameItemsSource:null,
    examinationTagNameSelectedItem:null,
    examinationFromDate:null,
    examinationToDate:null,
    examinationTagNameItemsSourceCopy: null,
    reLoad: computed('reLoadCB', function() {
      if(!isEmpty(this.get('reLoadCB'))){
        this._setOverViewGetItems('autoReset');
      }
    }),
    queryOption: null,
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId', 'specimen-check-in-work-list-overview');
      this.set('previewPopupInfo', EmberObject.create());
      this.set('previewPopupInfo.isOpen', false);
      this.set('isPopover', false);
      this.setStateProperties([
        'defaultUrl',
        'isAutoReset',
        'autoResetTimer',
        'examinationTagNameItemsSource',
        'examinationTagNameSelectedItem',
        'examinationFromDate',
        'examinationToDate',
        'isAuto',
        'examinationTagNameItemsSourceCopy',
        'queryOption'
      ]);
      if (this.hasState() === false) {
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimencheckin') + `specimen-checkin/v0/`);
        this.set('isAutoReset', true);
        this.set('findSettingPopupInfo', {});
        this.set('findSettingPopupInfo.isOpen', false);
        const today= this.get('co_CommonService').getNow();
        this.set('examinationFromDate',today);
        this.set('examinationToDate',today);
      }
    },

    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'wp100');

      if (this.hasState() === false) {
        hash({
          examinationTagNameItemsSource: this.getList(this.get('defaultUrl') + 'worklist-configurations/search', {staffId: this.get('co_CurrentUserService.user.employeeId')}, null),
          settingInfo: this.get('co_PersonalizationService').getSettingInfo(`specimen-check-in-work-list-overview`),
        }).then(function(result){
          this.set('examinationTagNameItemsSource', result.examinationTagNameItemsSource);
          const examinationTagNameItemsSource= this.get('examinationTagNameItemsSource');
          if(!isEmpty(examinationTagNameItemsSource)){
            this.set('examinationTagNameItemsSourceCopy', $.extend(true, [], examinationTagNameItemsSource.map(function(e){
              return $.extend(true, {}, e);
            })));
          }else{
            this.set('examinationTagNameItemsSourceCopy', null);
          }
          const settingInfo = result.settingInfo;
          if(isEmpty(settingInfo.settingValue)){
            if(isEmpty(examinationTagNameItemsSource)){
              //최초 로그인
              this._setOverViewGetItems();
            }else{
              this.set('examinationTagNameSelectedItem', examinationTagNameItemsSource.get('firstObject') );
              next(this, function(){
                this._setExaminationTagList();
                this._setOverViewGetItems();
              }.bind(this));
            }
          }else{
            //개인화설정값 있는경우
            const data = JSON.parse(settingInfo.settingValue);
            //conditionData [examinationTagList, examinationTagNameSelectedItem, queryOption ]
            if(!isEmpty(data.conditionData)){
              if(isEmpty(data.conditionData.get('firstObject')) && isEmpty(data.conditionData[1])){
                //저장된 set 없거나, examinationTagNameSelectedItem, examinationTagList 없는경우
                if(!isEmpty(examinationTagNameItemsSource)) {
                  this.set('examinationTagNameSelectedItem', examinationTagNameItemsSource.get('firstObject') );

                }
                this._setExaminationTagList();
                this._setOverViewGetItems();
              }else if(isEmpty(data.conditionData[1])){
                //set 선택값 없는경우 examinationTagList로 조회
                this.set('examinationTagNameSelectedItem', null);
                this.set('examinationTagList',data.conditionData.get('firstObject'));
                this._setTagGroupList(this.get('examinationTagList'));
                if(!isEmpty(data.conditionData[2])){
                  this.set('queryOption', data.conditionData[2]);
                  this._setOverViewGetItems(data.conditionData[2]);
                }else{
                  this._setOverViewGetItems();
                }
              }else if(!isEmpty(data.conditionData[1])){
                //set 선택값 있는경우 examinationTagNameSelectedItem 값으로 조회
                // this.set('examinationTagList',data.conditionData.get('firstObject'));
                this.set('examinationTagNameSelectedItem', data.conditionData[1] );
                this._setExaminationTagList();
                this._setTagGroupList(this.get('examinationTagList'));
                // this.set('examinationTagNameSelectedItem', isEmpty(data.conditionData[1])? examinationTagNameItemsSource.get('firstObject') : data.conditionData[1] );
                if(!isEmpty(data.conditionData[2])){
                  this.set('queryOption', data.conditionData[2]);
                  this._setOverViewGetItems(data.conditionData[2]);
                }else{
                  this._setOverViewGetItems();
                }
              }
            }else{
              this._setOverViewGetItems();
            }
          }
          this._setAutoResetOverView();
          // }).catch(function(error) {
          //   this._catchError(error);
          // }.bind(this));
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      }
    },

    didInsertElement() {
      this._super(...arguments);
      this.get('co_ContentMessageService').subscribeMessage('EXAMINATION_SETTING_CALLBACK_OVERVIEW', this.get('viewId'), this, this._getExaminationSettings);
    },

    willDestroyElement() {
      this._super(...arguments);
      this.get('co_ContentMessageService').unsubscribeMessage('EXAMINATION_SETTING_CALLBACK_OVERVIEW', this.get('viewId'), this, this._getExaminationSettings);
      this.set('isAutoReset', false);
      cancel(this.get('autoResetTimer'));
    },

    _getExaminationSettings(sResult) {
      if(sResult.isSelectionConfirmCB) {
        return;
      }
      let currentCongifId = null;
      const selectedSetItem = this.get('examinationTagNameSelectedItem');
      if(!isEmpty(selectedSetItem)) {
        currentCongifId = selectedSetItem.workListFindConfigurationId;
      }
      // this.set('examinationTagNameSelectedItem', null);
      if(sResult.workListFindConfigurationId === currentCongifId) {
        let tagList = null;
        if(sResult.tagList === null) {
          tagList = this.get('examinationTagList');
        } else {
          tagList = sResult.tagList;
        }
        this._setExaminationTagList(tagList);
        if(sResult.tagGroupList !== null) {
          this.set('tagGroupList', sResult.tagGroupList);
        }
        if(!isEmpty(sResult.workListFindConfigurationId)){
          //저장된 세트를 선택한 경우
          this._setExaminationComboBox(sResult.workListFindConfigurationId, tagList);
          // this._setTagGroupList(sResult.tagList);
        }else{
          this._setExaminationComboBox(sResult.workListFindConfigurationId, null);
        }
      } else {
        this._setExaminationComboBox(currentCongifId, null);
      }
    },

    actions: {
      onOpenConditionPreview(isOpen) {
        if(isEmpty(this.get('tagGroupList'))){
          return;
        }
        if(this.get('tagGroupList').length >0){
          this.set('previewPopupInfo.isOpen', isOpen);
        }else{
          this.set('previewPopupInfo.isOpen', false);
        }
      },

      onReset() {
        this.set('examinationTagList', []);
        this.set('tagGroupList', []);
        this.set('previewPopupInfo.isOpen', false);
        this._setOverViewGetItems();
        this.set('examinationTagNameSelectedItem', null);
      },

      //자동-레프레시 토클버튼 클릭 이벤트
      onAutoResetChangeClick(){
        this._setAutoResetOverView();
      },
      //레프레시 버튼 클릭 이벤트
      onResetOverviewOnClick(){
        this._setOverViewGetItems();
      },
      onExamDateChangedAction(){
        this._setOverViewGetItems();
      },
      //콤보박스 변경 이벤트
      onExaminationTagNameChanged(e){
        // 2019-04-24 디자인 수정
        this.set('examinationTagNameSelectedItem', e);
        if(!isEmpty(e)){
          this.set('examinationTagList', null);
          this._setExaminationTagList();
        }
        this._setOverViewGetItems();
        this.set('isExamSetOpen', false);
      },

      onDeleteConditionGroup(deleteGroupItem) {
        const examinationTagList= this.get('examinationTagList');
        const tagGroupList= this.get('tagGroupList');
        const obj= examinationTagList.findBy('items', deleteGroupItem.items);
        examinationTagList.removeObject(obj);
        let newTagList = copy(examinationTagList);
        try {
          tagGroupList.removeObject(tagGroupList.findBy('type', deleteGroupItem.type));
          this.set('tagGroupList', tagGroupList);
          if(!isEmpty(deleteGroupItem.items)){
            deleteGroupItem.items.forEach(i=>{
              const item= examinationTagList.findBy('id', i.id);
              if(!isEmpty(item)){
                newTagList.removeObject(item);
              }
            });
          }else{
            newTagList=examinationTagList;
          }
          this.set('examinationTagList', newTagList);
        } catch (e) {
          //
        }
        this._setOverViewGetItems();
        this.set('examinationTagNameSelectedItem', null);
        if(this.get('tagGroupList').length <1){
          this.set('previewPopupInfo.isOpen', false);
        }
      },

      onDeleteCondition(index, subIndex, item) {
        const examinationTagList = $.extend(true, [], this.get('examinationTagList').map(function(e){
          return $.extend(true, {}, e);
        }));
        const newTagList = [];
        try {
          examinationTagList[index].items.removeObject(examinationTagList[index].items[subIndex]);
          examinationTagList.forEach(function(element) {
            if(!isEmpty(element.items)){
              //제거대상 아닌 경우
              newTagList.push(element);
              return;
            }
            if(!isEmpty(element.id) && (element.id !== item.id)){
              newTagList.push({
                id:element.id,
                name:element.name,
                abbreviation:element.abbreviation,
                type:element.type
              });
            }
          });
          this.set('examinationTagList', newTagList);
          this._setTagGroupList(newTagList);
        } catch (e) {
          //
        }
        this._setOverViewGetItems();
        this.set('examinationTagNameSelectedItem', null);
      },
      onSearchPopupOnClick(e){
        this.set('findSettingPopupInfo.isOpen', !this.get('findSettingPopupInfo.isOpen'));
        this.set('findSettingPopupInfo.targetId', e.originalEvent.currentTarget);
        this.set('examinationTagListCopy', copy(this.get('examinationTagList')));
      },

      //팝업 콜백 이벤트
      onFindSettingCallBack(sResult){
        let currentCongifId = null;
        const selectedSetItem = this.get('examinationTagNameSelectedItem');
        if(!isEmpty(selectedSetItem)) {
          currentCongifId = selectedSetItem.workListFindConfigurationId;
        }
        if(sResult.workListFindConfigurationId !== currentCongifId && !sResult.isSelectionConfirmCB) {
          this._setExaminationComboBox(currentCongifId);
        } else {
          this.set('examinationTagNameSelectedItem', null);
          this.set('tagGroupList', null);
          let tagList = null;
          if(sResult.tagList === null) {
            tagList = this.get('examinationTagList');
          } else {
            tagList = sResult.tagList;
          }
          this._setExaminationTagList(tagList);
          if(!isEmpty(sResult.workListFindConfigurationId)){
            //저장된 세트를 선택한 경우
            this._setExaminationComboBox(sResult.workListFindConfigurationId, tagList);
          }else{
            if(this.get('examSetRefresh')){
              this._setExaminationComboBox(sResult.workListFindConfigurationId, null);
            }
            this.set('examinationTagNameSelectedItem', null);
            this.set('examinationTagList', tagList);
            this._setTagGroupList(tagList);
            this._setOverViewGetItems();
          }
        }
        this.get('co_ContentMessageService').sendMessage('EXAMINATION_SETTING_CALLBACK_BRIEF', sResult);
        this.get('co_ContentMessageService').sendMessage('EXAMINATION_SETTING_CALLBACK_LIST', sResult);
      },

      onFindSettingClosed(savedSettingSelectedItem, tagList){
        //셋팅 팝업 닫은 후 콜백 - 저장or 수정건이 있었으면 재조회
        if(this.get('examSetRefresh')){
          if(!isEmpty(savedSettingSelectedItem) && !isEmpty(this.get('examinationTagNameSelectedItem'))){
            const currentWorkListFindConfigurationId= this.get('examinationTagNameSelectedItem.workListFindConfigurationId');
            if(savedSettingSelectedItem.workListFindConfigurationId == currentWorkListFindConfigurationId){
              this._setExaminationComboBox(currentWorkListFindConfigurationId, tagList);
              return;
            }
            this._setExaminationComboBox(currentWorkListFindConfigurationId, null);
          }
          this.set('examSetRefresh', false);
        }
      },

      onOverViewListItemClick(item){
        if(!isEmpty(this.get('selectedFirstTabCB'))){
          this.get('selectedFirstTabCB')();
        }
        if(!isEmpty(this.get('overViewList'))){
          this.get('overViewList').forEach(element => {
            set(element, '2depthStyle_stat', '');
            set(element, '2depthStyle_general', '');
            set(element, '2depthStyle_requested', '');
            set(element, '2depthStyle_completed', '');
          });
        }
        if(item.progressStatusCode === 'ReObservation') {
          this._setOverView(item, 'ReObservation');
        } else {
          this._setOverView(item, 'A');
        }
      },
      onDetailOverViewListItemClick(item, option){
        if(!isEmpty(this.get('selectedFirstTabCB'))){
          this.get('selectedFirstTabCB')();
        }
        if(!isEmpty(this.get('overViewList'))){
          this.get('overViewList').forEach(element => {
            set(element, '2depthStyle_stat', '');
            set(element, '2depthStyle_general', '');
            set(element, '2depthStyle_requested', '');
            set(element, '2depthStyle_completed', '');
          });
        }
        if(option == 'D'){
          //응급/당일
          set(item, '2depthStyle_stat', 'on');
        }else if(option == 'G'){
          set(item, '2depthStyle_general', 'on');
        }else if(option == 'R'){
          set(item, '2depthStyle_requested', 'on');
        }else if(option == 'C'){
          set(item, '2depthStyle_completed', 'on');
        }
        this._setOverView(item, option);
      },
    },
    // 5. Private methods Area
    _setOverView(item, option){
      if(isEmpty(item)){
        return;
      }
      this.set('queryOption', item.progressStatusCode);
      if(!isEmpty(this.get('overViewList'))){
        this.get('overViewList').forEach(element => {
          set(element, 'style', 'wl-db-row');
        });
      }
      //응급당일, 일반 클릭에 따른 그리드 조회
      if(!isEmpty(option)){
        this.set('progressTypeCode', option);
      }
      let isNull = false;
      if((item.generalCount === 0 && option ==='G') || (item.statTodayCount ===0 && (option == 'D'))){
        isNull= true;
      }
      let searchCode;
      if(item.progressStatusCode ==='Checkin'){
        searchCode = '2';
      }else if(item.progressStatusCode ==='Preliminary'){
        searchCode = '3';
      }else if(item.progressStatusCode ==='Execution'){
        searchCode = '5';
      }else if(item.progressStatusCode ==='Final'){
        searchCode = '4';
      }else if(item.progressStatusCode === 'ReObservation') {
        searchCode = '1';
      }
      this._callBackViewSettingCB(searchCode, isNull);
      set(item, 'style', 'wl-db-row on');
    },

    _setExaminationComboBox(workListFindConfigurationId, tagList){
      this.getList(this.get('defaultUrl') + 'worklist-configurations/search', {staffId: this.get('co_CurrentUserService.user.employeeId')}, null).then(function(res){
        this.set('examinationTagNameItemsSource', res);
        if(!isEmpty(res)){
          this.set('examinationTagNameSelectedItem', res.find(d => d.workListFindConfigurationId === workListFindConfigurationId));
          if(!isEmpty(tagList)){
            //setting 팝업 닫으면서 재조회할경우
            this.set('examinationTagList', tagList);
            this._setTagGroupList(tagList);
            this._setOverViewGetItems(null);
          }
        }
      }.bind(this)).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    _setExaminationTagList(getTagList){
      let examinationTagNameSelectedItem = this.get('examinationTagNameSelectedItem');
      const examinationTagList = this.get('examinationTagList');

      if(!isEmpty(examinationTagNameSelectedItem) && isEmpty(examinationTagList)){
        //최초
        this.set('examinationTagList', this._filterExaminationTagList(
          examinationTagNameSelectedItem.workListFindConfigurationId,
          examinationTagNameSelectedItem.property
        ));
        this._setTagGroupList(this.get('examinationTagList'));
      }else if(isEmpty(examinationTagNameSelectedItem) && !isEmpty(examinationTagList)){
        //콜백받은경우
        this.set('examinationTagList', getTagList);
        this._setTagGroupList(getTagList);
      }else if (!isEmpty(examinationTagNameSelectedItem)){
        //다시선택
        const examinationTagNameItemsSourceCopy= this.get('examinationTagNameItemsSourceCopy');
        examinationTagNameSelectedItem = examinationTagNameItemsSourceCopy.findBy('workListFindConfigurationId', examinationTagNameSelectedItem.workListFindConfigurationId);
        this.set('examinationTagList', this._filterExaminationTagList(
          examinationTagNameSelectedItem.workListFindConfigurationId,
          examinationTagNameSelectedItem.property
        ));
        this._setTagGroupList(this.get('examinationTagList'));
      }else if (!isEmpty(getTagList)){
        this.set('examinationTagList', getTagList);
      }
    },

    _setTagGroupList(tagList) {
      const tagGroupList= [];
      if(!isEmpty(tagList)){
        tagList.forEach(list => {
          if(isEmpty(list.items)){
            return;
          }
          if (list.items.length > 0) {
            let tempName = isEmpty(list.items[0].abbreviation)? list.items[0].name: list.items[0].abbreviation;
            if (list.items.length > 1) {
              tempName += '(+' + (list.items.length - 1) + ')';
            }
            tagGroupList.pushObject({ type: list.type, name: tempName, items: list.items });
          }
        });
      }
      this.set('tagGroupList', tagGroupList);
      if (tagGroupList.length == 0) {
        this.set('isPopover', false);
      } else {
        this.set('isPopover', true);
      }
    },
    //검사분류, 작업단위, 검사항목별로 나눠서 저장해둠
    _filterExaminationTagList(workListFindConfigurationId, property){
      const filterdExaminationTagList = [];
      filterdExaminationTagList.workListFindConfigurationId = workListFindConfigurationId;
      //검사분류
      if(!isEmpty(property.classifications)){
        filterdExaminationTagList.push({type: 'category', items: property.classifications });
      }
      //작업단위
      if(!isEmpty(property.unitWorks)){
        filterdExaminationTagList.push({type: 'unit', items: property.unitWorks });
      }
      //검사항목
      if(!isEmpty(property.observationExaminations)){
        filterdExaminationTagList.push({type: 'exam', items: property.observationExaminations});
      }
      return filterdExaminationTagList;
    },
    _setAutoResetOverView(){
      const isAuto = this.get('isAutoReset');
      const self = this;
      if(isAuto){
        this.set('autoResetTimer', later(function(){
          if(!isEmpty(self.get('tagGroupList'))){
            self._setOverViewGetItems('autoReset');
            self._setAutoResetOverView();
          }
        }, 60000));
      }else{
        cancel(this.get('autoResetTimer'));
      }
    },

    _getTodayCount(list, status) {
      return list
        .filter(item => item.progressStatusCode === status && item.progressTypeCode !== 'G')
        .reduce((total, item) => total + item.specimenCount, 0);
    },

    _getOverViewParams() {
      let params = null;
      const examinationTagList = this.get('examinationTagList');
      const examinationFromDate = this.get('examinationFromDate');
      const examinationToDate = this.get('examinationToDate');
      if(isEmpty(examinationFromDate) || isEmpty(examinationToDate)){
        this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9290', 'F', '날짜를 확인하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
        return;
      }
      params = {
        checkInFromDate: new Date(examinationFromDate.getFullYear(), examinationFromDate.getMonth(), examinationFromDate.getDate(), 0, 0, 0),
        checkInToDate: new Date(examinationToDate.getFullYear(), examinationToDate.getMonth(), examinationToDate.getDate(), 0, 0, 0),
      };
      const typeByIds = (type) => {
        const ids = examinationTagList
          .filter(tag => tag.type === type)
          .map(tag => tag.items.mapBy('id'));
        if(!isEmpty(ids)) {
          return ids.flat();
        }
      };
      if(!isEmpty(examinationTagList)){
        params.classificationIds = typeByIds('category');
        params.unitWorkIds = typeByIds('unit');
        params.examinationIds = typeByIds('exam');
      }
      return params;
    },
    async _setOverViewGetItems(mode) {
      try {
        const params = this._getOverViewParams();
        if(isEmpty(params)) {
          return;
        }
        this.set('isShowLoader', true);
        const result = await this.getList(this.get('defaultUrl') + 'specimen-examination-worklists/overview', null, params);
        const overviewItems = result
          .filter(item => item.progressTypeCode === 'G')
          .map(item => {
            const obj = {
              progressStatusCode: item.progressStatusCode,
              statusName: item.progressStatusName,
              generalCount: item.specimenCount,
              style: 'wl-db-row',
            };
            return obj;
          });
        overviewItems.map(item => {
          item.statTodayCount = this._getTodayCount(result, item.progressStatusCode);
          item.totalCount = item.generalCount + item.statTodayCount;
        });
        const reOsercations = result.filter(item => item.progressStatusCode === 'ReObservation');
        const rItem = result.find(d => d.progressTypeCode === 'Request');
        const citem = result.find(d => d.progressTypeCode === 'Complete');
        if(isPresent(reOsercations) && isPresent(rItem) && isPresent(citem)) {
          const reTestObj = {
            progressStatusCode: rItem.progressStatusCode,
            statusName: this.getLanguageResource('6530', 'F','재검'),
            rCount: rItem.specimenCount,
            cCount: citem.specimenCount,
            totalCount: rItem.totalCount,
            style: 'wl-db-row',
          };
          overviewItems.push(reTestObj);
        }
        this.set('isShowLoader', false);
        console.log('overviewItems---', overviewItems);
        if(!isEmpty(this.get('overViewList')) && mode === 'autoReset'){
          this.get('overViewList').forEach((item, index) => {
            if(!isEmpty(overviewItems[index])){
              set(item, 'generalCount', overviewItems[index].generalCount);
              set(item, 'totalCount', overviewItems[index].totalCount);
              set(item, 'statTodayCount', overviewItems[index].statTodayCount);
              set(item, 'rCount', overviewItems[index].rCount);
              set(item, 'cCount', overviewItems[index].cCount);
            }
          });
        } else {
          this.set('overViewList', overviewItems);
        }
        if(isEmpty(params.classificationIds) && isEmpty(params.unitWorkIds) && isEmpty(params.examinationIds)){
          //2020.11.02 개인화설정 초기화 저장 추가
          this._callBackViewSettingCB('A', false);
          this.set('previewPopupInfo.isOpen', false);
          // this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9192', 'F', null, 'Overview 검색 조건을 확인하세요'), 'warning', 'Ok', 'Ok', '', 2000);
          this.get('overViewList').forEach(e=>{
            set(e, 'generalCount', 0);
            set(e, 'totalCount', 0);
            set(e, 'statTodayCount', 0);
          });
          return;
        }
        let selectedOverView = this.get('overViewList').get('firstObject');
        if(mode === 'autoReset') {
          // 새로 바인딩 안하고 기존유지. 디자인만 유지
          return;
        }
        let option = null;
        if(mode === "1"){
          //개인화 설정된 queryOption 가 '전체'인 경우
          option = 'A';
          selectedOverView = null;
        }else if(mode === "2"){
          //개인화 설정된 queryOption 지정
          selectedOverView = this.get('overViewList').findBy('progressStatusCode', "Checkin");
        }else if(mode === "5" ){
          selectedOverView = this.get('overViewList').findBy('progressStatusCode', "Execution");
        }else if(mode === "3"){
          selectedOverView = this.get('overViewList').findBy('progressStatusCode', "Preliminary");
        }else if(mode === "4"){
          selectedOverView = this.get('overViewList').findBy('progressStatusCode', "Final");
        }else if(mode !== 'autoReset' && mode !== 'init'){
          //개인화저장 안한 최초조회일경우
          selectedOverView = this.get('overViewList').get('firstObject');
          option = 'A';
        }
        this._setOverView(selectedOverView, option);
        this.set('selectedOverView', selectedOverView);
      } catch(e) {
        this._catchError(e);
      }
    },
    _callBackViewSettingCB(WorkListSearchCode, isNull){
      const callBackSetting = {};
      callBackSetting.selectedComboBox = this.get('examinationTagNameSelectedItem');
      callBackSetting.selectedTagSet = this.get('examinationTagList');
      callBackSetting.workListSearchCode= WorkListSearchCode;
      callBackSetting.examinationFromDate= this.get('examinationFromDate');
      callBackSetting.examinationToDate= this.get('examinationToDate');
      callBackSetting.examinationTagNameSelectedItem= this.get('examinationTagNameSelectedItem');
      callBackSetting.examinationTagList= this.get('examinationTagList');
      callBackSetting.progressTypeCode= this.get('progressTypeCode');
      callBackSetting.isNull= isNull;
      //WorkList에서 조각UI로 열릴시에 변경값 탭으로 전달하는 콜백 이벤트
      this.get('ViewSettingCB')(callBackSetting);
    },

    _catchError(e){
      console.log('e', e);
      this.set('isShowLoader', false);
      this.showResponseMessage(e);
    }
  });