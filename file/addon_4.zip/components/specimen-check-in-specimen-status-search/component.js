/* eslint-disable max-lines */
import $ from 'jquery';
import { copy } from '@ember/object/internals';
import { next, later } from '@ember/runloop';
import { hash } from 'rsvp';
import { A } from '@ember/array';
import { isEmpty } from '@ember/utils';
import { computed, set } from '@ember/object';
import { inject as service } from '@ember/service';
// import { computed, set } from '@ember/object';
// import { getOwner } from '@ember/application';
import layout from './template';
import CHIS from 'framework/chis-framework';
import specimencheckinPrintMixin from 'specimencheckin-module/mixins/specimen-check-in-print-mixin';
import specimencheckinMessageMixin from 'specimencheckin-module/mixins/specimen-check-in-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,specimencheckinPrintMixin, specimencheckinMessageMixin,
  {
    specimenSamplingService: service('specimen-sampling-service'),
    specimenCheckinService: service('specimen-check-in-service'),
    layout,
    // 2. Property Area
    defaultUrl: null,
    currentUser: null,
    // worklistConfigurations: null,
    // relativeSource: null,
    statusListColumns: null,
    additionalInfo: null,
    additionalInfoListColumns: null,
    searchCondition: null,
    classificationNames: null,
    isSpecimenRejectReasonsModalOpen: null,
    specimenRejectReasonsNameDisabled: null,
    selectedItems: null,
    reasonId: null,
    reasonName: null,
    specimenRejectReasonsSelectedItem: null,
    inappropriateReasonsSelectedItem: null,
    inappropriateReasonsDisabled: null,
    inappropriateReasonsInputDisabled: null,
    inappropriateReasonsnInputName: null,
    patientTypeItemsSource: null,
    examTypeItemsSource: null,
    examStatusItemsSource: null,
    specimenRejectReasonsItemsSource: null,
    inappropriateReasonsItemsSource: null,
    statusListItemsSource: null,
    additionalField: null,
    additionalFieldColumns: null,
    _classificationIdsCombobox: null,
    isInitial: null,
    isCallBackViewSetChanged: computed('callBackViewSet', function() {
      if(isEmpty(this.get('callBackViewSet.selectedComboBox'))){
        return;
      }

      const examTypeItemsSource = this.get('examTypeItemsSource');
      //onLoaded 전
      if(isEmpty(examTypeItemsSource)){
        return;
      }
      this._setInitialParams(this.get('callBackViewSet.selectedComboBox.property'));
    }),
    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-check-in-specimen-status-search');
      this.setStateProperties([
        'defaultUrl', 'currentUser',
        'statusListColumns',
        'statusListItemsSource',
        'orderListColumns',
        'additionalInfo', 'additionalInfoListColumns',
        'patientTypeItemsSource',
        'examTypeItemsSource', 'examStatusItemsSource',
        'specimenRejectReasonsItemsSource',
        'inappropriateReasonsItemsSource',
        'selectedItems', 'additionalField',
        'classificationNames',
        '_classificationIdsCombobox',
        'searchCondition',
        'cancelOption'
      ]);
      if (this.hasState() === false) {
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimencheckin')
        + `specimen-checkin/v0/`);
        this.set('samplingUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimencheckin')
        + `specimen-sampling/v0/`);
        this.set('currentUser', this.get('co_CurrentUserService.user'));
        // this.set('specimenRoles',{code :"P", displayCode: "P", name: "Patient (default if blank component value)"});
        this.set('statusListColumns', [
          { field: 'checkInNumber', title: this.getLanguageResource('6767', 'F','Check-in No.'), width: 65,align: 'center' },
          { field: 'classificationInfo', title: this.getLanguageResource('16892', 'S','Exam.Type'), width: 100, bodyTemplateName: 'tooltip' },
          { field: 'subjectName', title: this.getLanguageResource('16881', 'F','Pt Name'), bodyTemplateName: 'boldTooltip',align: 'center', width: 70 },
          { field: 'subjectNumber', title: this.getLanguageResource('8451', 'F','MRN'), bodyTemplateName: 'bold',align: 'center', width: 65 },
          { field: 'progressStatus.name', title: this.getLanguageResource('3452', 'F','Status'),align: 'center', width: 70 },
          { field: 'specimenType.name', title:  this.getLanguageResource('16921', 'F','Specimen Name'), width: 110,headerTemplateName: 'tooltip', bodyTemplateName: 'tooltip' },
          { field: 'issuedDepartmentName', title: this.getLanguageResource('8827', 'S','발행처'),align: 'center', width: 80, bodyTemplateName: 'tooltip'},
          { field: 'departmentName', title: this.getLanguageResource('7111', 'S','진료과'),align: 'center', width: 80, bodyTemplateName: 'tooltip'},
          { field: 'orderedStaffName', title: this.getLanguageResource('9686', 'S','처방의'), align: 'center',width: 80, bodyTemplateName: 'tooltip'},
          { field: 'encounterTypeName', title: this.getLanguageResource('16963', 'S', '구분'),align: 'center', width: 38, bodyTemplateName: 'tooltip'},
          { field: 'physicianStaffName', title: this.getLanguageResource('8898', 'S','진료의'),align: 'center', width: 60, bodyTemplateName: 'tooltip' },
          { field: 'specimenNumber', title: this.getLanguageResource('859', 'S','Specimen No.'),align: 'center', width: 80 },
          { field: 'collectionEndDatetime', title: this.getLanguageResource('7213', 'F','채혈시간'),align: 'center', type: 'date', dataFormat: 'g', width: 105},
          { field: 'collectionStaff.name', title: this.getLanguageResource('7217', 'F','채혈자'),align: 'center', width: 60, bodyTemplateName: 'tooltip' },
          { field: 'collectionPlace.name', title: this.getLanguageResource('9270', 'F','채혈처'), width: 70, bodyTemplateName: 'tooltip',align: 'center'},
          { field: 'receivedDateTime', title: this.getLanguageResource('10765', 'F','등록시간'),align: 'center', type: 'date', dataFormat: 'g', width: 105},
          { field: 'receivedStaff.name', title:  this.getLanguageResource('2066', 'F','등록자'), width: 70,align: 'center', bodyTemplateName: 'tooltip'},
          { field: 'checkInDateTime', title: this.getLanguageResource('6770', 'F','접수시간'),align: 'center', type: 'date', dataFormat: 'g', width: 110},
          { field: 'progressType.name', title: this.getLanguageResource('3813', 'S','속성'), bodyTemplateName: 'stat',align: 'center', width: 35 },
          { field: 'orderDate', title: this.getLanguageResource('5246', 'F','Order Date'),align: 'center', type: 'date', dataFormat: 'd', width: 75 },
          { field: 'orderDateTime', title: this.getLanguageResource('12512', 'S', '오더발행일시'), type: 'date', dataFormat: 'g', width: 105},
          { field: 'IsExaminationCancel', title: this.getLanguageResource('801', 'S', '검사취소여부'), align: 'center', width: 55, bodyTemplateName: 'yesNo' },
        ]);
        this.set('additionalInfoListColumns', [{ field: 'title', title: '', width: 150 },{ field: 'value', title: '' }]);
        this.set('orderListColumns', [
          { field: 'orderCode', title: this.getLanguageResource('5259', 'F','Order Code'), width: 100 },
          { field: 'orderName', title: this.getLanguageResource('5218', 'F','Order Name'), width: 450 },
          { field: 'orderComment', title: this.getLanguageResource('5228', 'F','Remarks') }
        ]);
        this.set('selectedItems', A());
        this.set('isSpecimenRejectReasonsModalOpen', false);
        const today= this.get('co_CommonService').getNow();
        this.set('searchCondition',{ checkInFromDate: today, checkInToDate: today});
        this.set('isInitial', true);
        this.set('hpcSelectedValue', 'All');
        this.set('recordSize', 300);
        this.set('currentPage', 1);
      }
    },

    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1360');
      if (this.hasState() === false) {
        const defaultUrl= this.get('defaultUrl');

        hash({
          // worklistConfigurations: this.getList(defaultUrl + 'worklist-configurations/search', {staffId:this.get('currentUser.employeeId')}, null),
          examTypeItemsSource: this.getList(defaultUrl + 'classifications/search', {selectedOption: 0, classificationType: 1}, null),
          businessCodes: this.getList(defaultUrl + 'business-codes/search', null,{
            classificationCodes: [
              'EncounterTypeCode','SpecimenStatusSearchCode','CheckInRejectReason', 'InappropriateSpecimenReason'
            ]
          }, false),
        }).then(function(result){
          const patientTypeItemsSource=[];
          const examStatusItemsSource= [];
          const specimenRejectReasonsItemsSource= [];
          const inappropriateReasonsItemsSource= [];
          result.businessCodes.forEach(e=>{
            if(e.classificationCode == 'EncounterTypeCode'){
              patientTypeItemsSource.addObject(e);
            }else if(e.classificationCode == 'SpecimenStatusSearchCode'){
              examStatusItemsSource.addObject(e);
            }else if(e.classificationCode == 'CheckInRejectReason'){
              specimenRejectReasonsItemsSource.addObject(e);
            }else if(e.classificationCode == 'InappropriateSpecimenReason'){
              inappropriateReasonsItemsSource.addObject(e);
            }
          });
          if(!isEmpty(result.examTypeItemsSource)){
            result.examTypeItemsSource.insertAt(0, {displayCode: 'All', classificationId: 'All', name: 'All'});
          }
          this.set('examTypeItemsSource', result.examTypeItemsSource);
          next(this, function() {
            this.get('_classificationIdsCombobox').selectItem(0);
          }.bind(this));
          this.set('patientTypeItemsSource', patientTypeItemsSource);
          this.set('searchCondition.encounterTypeCode', patientTypeItemsSource.get('firstObject.code'));
          this.set('examStatusItemsSource', examStatusItemsSource);
          this.set('specimenRejectReasonsItemsSource', specimenRejectReasonsItemsSource);
          this.set('inappropriateReasonsItemsSource', inappropriateReasonsItemsSource);
          this.set('searchCondition.queryOption', examStatusItemsSource.get('firstObject.code'));
          // this._getStatusList();
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      }
    },

    // 4. Actions Area
    actions: {
      onLoadCombobox(e){
        this.set('_classificationIdsCombobox', e.source);
      },

      onExamTypeSelectedChanged(e){
        if(isEmpty(e)){
          return;
        }
        const _classificationIdsCombobox= this.get('_classificationIdsCombobox');
        if(isEmpty(e.selectedItems)){
          //전체선택해제
          if(isEmpty(this.get('searchCondition'))){
            this.set('searchCondition', {classificationIds: []});
          }
          // this.get('_classificationIdsCombobox').selectItem(0);
        }else if(e.selectedItems[0].name == 'All'){
          for (let index = 1; index < _classificationIdsCombobox.selectedItems.length; index++) {
            this.get('_classificationIdsCombobox').deselectItem(_classificationIdsCombobox.selectedItems[index]);
          }
          // }
        }else if(e.selectedItems[0].name != 'All'){
          // this.get('_classificationIdsCombobox').deselectItem(0);
        }
        this._getStatusList();

      },

      onExamTypeChanged(e){
        if(isEmpty(e)){
          return;
        }
        const _classificationIdsCombobox= this.get('_classificationIdsCombobox');
        if(e.selected){
          //추가
          if(e.item.name == 'All'){
            _classificationIdsCombobox.deselectAll();
            this.get('_classificationIdsCombobox').selectItem(0);
          }else{
            this.get('_classificationIdsCombobox').deselectItem(0);
          }
        }
        if(isEmpty(this.get('searchCondition'))){
          this.set('searchCondition', {classificationIds: []});
        }
        set(this.get('searchCondition'), 'classificationIds', this.get('_classificationIdsCombobox.selectedItems').mapBy('classificationId'));
        // this._getStatusList();
      },

      //검색조건 변경
      onSearchConditionChanged(){
        if(this.get('isInitial')=== false){
          return;
        }
        this._getStatusList();
      },

      onGridLoad(e){
        this.set('specimenLabelPrintGrid', e.source);
      },

      //Grid 선택
      onStatusGridSelectionChange(e){
        this.set('selectedItems', e.selectedItems);
      },

      //접수취소 버튼 클릭
      onCheckInCancelClick(){
        if(this._cancelValidationCheck('Checkin')==false){
          return;
        }
        this.set('cancelOption', 'Checkin');
        this.set('isSpecimenRejectReasonsModalOpen', true);
        this._initializeModal();
      },
      //접수취소 사유 항목 선택
      onSpecimenRejectReasonsChanged(){
        if(this.get('specimenRejectReasonsSelectedItem.code') == '9999'){
          this.set('specimenRejectReasonsNameDisabled', false);
        }else{
          this.set('specimenRejectReasonsNameDisabled', true);
          this.set('specimenRejectReasonsName', null);
        }
      },

      //접수 취소사유 modal OK 클릭
      onSpecimenRejectReasonsOKAction(){
        const now =this.get('co_CommonService').getNow();
        this.set('isSpecimenRejectReasonsModalOpen', false);
        this.set('reasonId', this.get('specimenRejectReasonsSelectedItem.code'));
        this.set('reasonName', this.get('specimenRejectReasonsSelectedItem.name'));
        const selectedItems= this.get('selectedItems');
        selectedItems.forEach(obj => {
          this.set('selectedItem', obj);
          this._cancel(now).then(res=>{
            if(res == true){
              this.get('specimenCheckinService').onShowToast('save', this.getLanguageResource('8943', 'F', '취소되었습니다.'), '');
              this._getStatusList();
            }else{
              // this.get('specimenCheckinService')._showMessage(this.getLanguageResource('8947', 'S','에러가 발생했습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
            }
          }).catch(function(error){
            this._catchError(error);
          }.bind(this));
        });
      },

      //부적합검체등록 버튼 클릭
      onInappropriateSpecimenRegistrationClick(){
        if(this._inappropriateRegistrationValidationCheck()==false){
          return;
        }
        this.set('inappropriateInfo', null);
        this.get('specimenCheckinService').getInappropriateInfo(this.get('statusListSelectedItem.specimenId')).then(function(inappropriateInfo){
          if(!isEmpty(inappropriateInfo)){
            this.get('specimenCheckinService')._showMessage(this.getLanguageResource('10106', 'F', '이미 등록된 검체입니다. <br> 취소하고 다시 접수하시겠습니까?'),
              'question', 'YesNo', 'Yes', '', null).then(function(result){
              if(result === 'Yes'){
                this.set('isInappropriateRegistrationModalOpen', true);
                this.set('inappropriateInfo', inappropriateInfo);
              }
            }.bind(this)).catch(function(error){
              this._catchError(error);
            }.bind(this));
          }else{
            this.set('isInappropriateRegistrationModalOpen', true);
            this._initializeisInappropriateRegistrationModal();
          }
        }.bind(this)).catch(function() {
          this.get('specimenCheckinService').onShowToast('error', this.getLanguageResource('8947', 'F', null, '에러가 발생했습니다.'), '');
          this.set('isResultGridShow',false);
        }.bind(this));

      },

      onGridBeforeClick(e){
        this.set('expandedDetailRowItem',e.source.getOriginalSource(e.originalEvent).item);
      },

      onDetailRowItemsChanged(e){
        const expandedDetailRowItem = this.get('expandedDetailRowItem');
        if(isEmpty(expandedDetailRowItem) || isEmpty(e.expandedDetailRowItems)){
          return;
        }
        this.set('isDetailGridLoaderShow', true);
        this.get('specimenCheckinService').getOverView(expandedDetailRowItem.specimenNumber).then(function(res) {
          let gridDetailEl = document.getElementById(e.source.elementId).getElementsByClassName('c-gdetail');
          set(expandedDetailRowItem, 'overview', res);
          this.set('isDetailGridLoaderShow',false);
          next(() => {
            $(gridDetailEl).find('.scrollbar-macosx').scrollbar();
            gridDetailEl = null;
          });
        }.bind(this)).catch(function(error){
          this._catchError(error);
          this.set('isDetailGridLoaderShow',false);
        }.bind(this));
      },
      onGridScroll(e){
        if(this.get('originalDatas.length') === this.get('statusListItemsSource.length')) {
          return;
        }
        if(e.maxTop !== 0 && Math.round(e.maxTop) <= Math.round(e.top) + 1){
          this.set('currentPage', this.get('currentPage') + 1);
          const pageItems = this.getPageSource(this.get('originalDatas'));
          if(isEmpty(pageItems)) {
            return;
          }
          this.get('statusListItemsSource').addObjects(pageItems);
        }
      },
      onExcelPrintAction() {
        const itemsSource = this.get('originalDatas');
        const columns = this.get('statusListColumns');
        if(isEmpty(itemsSource)){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9264', 'F', '조회된 정보가 없습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        this._getExportExcel(itemsSource, columns);
        // const gridSource=this.get('specimenLabelPrintGrid');
        // const reason = 'Excel export specimen status list';
        // const headers=[];
        // const fields=[];

        // columns.forEach(function(item, index){
        //   headers.addObject({ left: index, top: 0, right: index, bottom: 0, value: item.title });
        //   item.type == 'date'? fields.addObject({ width: 140, value: item.field }) : fields.addObject({ width: item.width, value: item.field });
        // });
        // gridSource.exportToExcel('specimen_status_list.xlsx', headers, fields, this, 'onExcelPrintAction', reason , itemsSource);
      },

      onCancelRegistrationClick(){
        //검체등록취소
        if(this._cancelValidationCheck('Received')==false){
          return;
        }
        this.set('cancelOption', 'Received');
        const now =this.get('co_CommonService').getNow();
        this._cancel(now).then(function(res){
          if(res){
            this.get('specimenCheckinService').onShowToast('save', this.getLanguageResource('8943', 'F', '취소되었습니다.'), '');
            later(function() {
              this._getStatusList();
            }.bind(this), 3000);
          }
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      },

      onSpecimenRejecttionCB(res){
        if(res == true){
          this._getStatusList();
        }else{
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('8947', 'S','에러가 발생했습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
        }
      },

      onHpcChanged(e){
        this.set('hpcSelectedValue',e.value);
        this._getStatusList();
      },
    },
    // 5. Private methods Area
    _setComboboxData(itemsSource){
      const arr=[];
      const name=[];
      const searchCondition= this.get('searchCondition');
      // const itemsSource= e.source.itemsSource;
      if(isEmpty(itemsSource)){
        return;
      }
      itemsSource.forEach(element => {
        if(element.selected== true){
          set(searchCondition, 'classificationIds', arr.addObject(element.classificationId));
          this.set('classificationNames', name.addObject(element.name));
        }
      });


    },

    //취소사유 modal 초기화
    _initializeModal(){
      const specimenRejectReasonsItemsSource= this.get('specimenRejectReasonsItemsSource');

      this.set('specimenRejectReasonsSelectedItem', specimenRejectReasonsItemsSource.get('firstObject'));
      this.set('specimenRejectReasonsDisabled', false);
      this.set('specimenRejectReasonsNameDisabled', true);
      this.set('specimenRejectReasonsName', null);
    },

    //부적합검체등록 modal 초기화
    _initializeisInappropriateRegistrationModal(){
      const inappropriateReasonsItemsSource= this.get('inappropriateReasonsItemsSource');

      this.set('inappropriateReasonsSelectedItem', inappropriateReasonsItemsSource.get('firstObject'));
      this.set('inappropriateReasonsDisabled', false);
      this.set('inappropriateReasonsInputDisabled', true);
      this.set('inappropriateReasonsnInputName', null);
    },

    // _getStatusList(){
    //   this.set('isInitial', false);
    //   const searchCondition= this.get('searchCondition');
    //   if(isEmpty(this.get('_classificationIdsCombobox.selectedItems'))){
    //     set(searchCondition, 'classificationIds', []);
    //   }else if(this.get('_classificationIdsCombobox.selectedItems.firstObject.name')=='All'){
    //     set(searchCondition, 'classificationIds', []);
    //   }else{
    //     set(searchCondition, 'classificationIds', this.get('_classificationIdsCombobox.selectedItems').map(function(item){
    //       return item.classificationId;
    //     }));
    //   }
    //   if(isEmpty(searchCondition.checkInFromDate) || isEmpty(searchCondition.checkInToDate)){
    //     this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9290', 'F', '날짜를 확인하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
    //     return;
    //   }
    //   const params= {
    //     seletedOption: '2',
    //     queryOption: searchCondition.queryOption,
    //     classificationIds: searchCondition.classificationIds,
    //     subjectNumber: isEmpty(searchCondition.subjectNumber)? null: searchCondition.subjectNumber.trim(),
    //     specimenNumber: isEmpty(searchCondition.specimenNumber)? null: searchCondition.specimenNumber.trim(),
    //     checkInStartNumber: searchCondition.checkInStartNumber,
    //     checkInEndNumber: searchCondition.checkInEndNumber,
    //     encounterTypeCode: searchCondition.encounterTypeCode,
    //     checkInFromDate: new Date(searchCondition.checkInFromDate.getFullYear(), searchCondition.checkInFromDate.getMonth(), searchCondition.checkInFromDate.getDate(), 0, 0, 0),
    //     checkInToDate: new Date(searchCondition.checkInToDate.getFullYear(), searchCondition.checkInToDate.getMonth(), searchCondition.checkInToDate.getDate(), 0, 0, 0),
    //     subjectTypeCode: "Patient",
    //     hpcSearchTypeCode: this.get('hpcSelectedValue')
    //   };
    //   this.set('isResultGridShow', true);
    //   params.encounterTypeCode= params.encounterTypeCode == 'A'? '' : params.encounterTypeCode;
    //   this.getList(this.get('defaultUrl') + 'specimen-checkins/search', null, params, false).then(function(res) {
    //     this.set('isResultGridShow', false);
    //     this.set('isInitial', true);
    //     if(isEmpty(res)){
    //       this.set('statusListItemsSource', null);
    //       return;
    //     }
    //     this._setGridData(res);
    //   }.bind(this)).catch(function(error){
    //     this._catchError(error);
    //   }.bind(this));
    // },

    // _setGridData(res){
    //   res.forEach(element => {
    //     set(element, 'subjectName', element.specimenOrders.get('firstObject.subject.name'));
    //     set(element, 'issuedDepartmentName', element.specimenOrders.get('firstObject.issuedDepartment.name'));
    //     set(element, 'departmentName', element.specimenOrders.get('firstObject.department.name'));
    //     set(element, 'orderedStaffName', element.specimenOrders.get('firstObject.orderedStaff.name'));
    //     set(element, 'physicianStaffName', element.specimenOrders.get('firstObject.physicianStaff.name'));
    //     set(element, 'orderDate', element.specimenOrders.get('firstObject.orderDate'));
    //     set(element, 'classificationInfo', element.specimenOrders.get('firstObject.classification.name'));
    //     set(element, 'orderDateTime', element.specimenOrders.get('firstObject.orderDateTime'));

    //     element.additionalInfo= [];
    //     element.additionalInfo.receivedDateTime= isEmpty(element.receivedDateTime)?
    //       element.additionalInfo.receivedDateTime: this.get('fr_I18nService').formatDate( element.receivedDateTime, 'u');
    //     element.additionalInfo.checkInDateTime= isEmpty(element.checkInDateTime) ?
    //       element.additionalInfo.checkInDateTime: this.get('fr_I18nService').formatDate( element.checkInDateTime, 'u');
    //     element.additionalInfo.reportedDateTime= isEmpty(element.reportedDateTime) ?
    //       element.additionalInfo.reportedDateTime: this.get('fr_I18nService').formatDate( element.reportedDateTime, 'u');
    //     element.additionalInfo.checkInRejectReason= isEmpty(element.checkInRejectReason) ?
    //       element.get('checkInRejectReason.firstObject.reasonName'): element.get('checkInRejectReason.firstObject.name');

    //     element.additionalInfo=[
    //       { title : this.getLanguageResource('3907', 'F','Received Date'), value : element.additionalInfo.receivedDateTime},
    //       { title : this.getLanguageResource('4124', 'F','Received By'), value : element.receivedStaff},
    //       { title : this.getLanguageResource('9512', 'S', '검체 도착방법'), value : element.receivedStaff},
    //       { title : this.getLanguageResource('6770', 'S','Check-In Time'), value : element.additionalInfo.checkInDateTime},
    //       { title : this.getLanguageResource('9283', 'S', '접수자'), value : element.get('checkInStaff.name')},
    //       { title : this.getLanguageResource('2873', 'F','Reported Time'), value : element.additionalInfo.reportedDateTime},
    //       { title : this.getLanguageResource('2874', 'F','Reported by'), value : element.get('reportedStaff.name')},
    //       { title : this.getLanguageResource('7591', 'F','Canceled Reason'), value : element.additionalInfo.checkInRejectReason},
    //       { title : this.getLanguageResource('7602', 'F','Canceled by'), value : element.get('checkInStaff.name')},
    //       // To-do element.others
    //       { title : 'Others', value : null},
    //     ];
    //   });
    //   this.set('statusListItemsSource', res);
    // },
    async _getStatusList(){
      try {
        this.set('isInitial', false);
        const searchCondition = this.get('searchCondition');
        if(isEmpty(this.get('_classificationIdsCombobox.selectedItems'))){
          set(searchCondition, 'classificationIds', []);
        }else if(this.get('_classificationIdsCombobox.selectedItems.firstObject.name')=='All'){
          set(searchCondition, 'classificationIds', []);
        }else{
          set(searchCondition, 'classificationIds', this.get('_classificationIdsCombobox.selectedItems').map(function(item){
            return item.classificationId;
          }));
        }
        if(isEmpty(searchCondition.checkInFromDate) || isEmpty(searchCondition.checkInToDate)){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9290', 'F', '날짜를 확인하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        const params= {
          seletedOption: '2',
          queryOption: searchCondition.queryOption,
          classificationIds: searchCondition.classificationIds,
          subjectNumber: isEmpty(searchCondition.subjectNumber)? null: searchCondition.subjectNumber.trim(),
          specimenNumber: isEmpty(searchCondition.specimenNumber)? null: searchCondition.specimenNumber.trim(),
          checkInStartNumber: searchCondition.checkInStartNumber,
          checkInEndNumber: searchCondition.checkInEndNumber,
          encounterTypeCode: searchCondition.encounterTypeCode,
          checkInFromDate: new Date(searchCondition.checkInFromDate.getFullYear(), searchCondition.checkInFromDate.getMonth(), searchCondition.checkInFromDate.getDate(), 0, 0, 0),
          checkInToDate: new Date(searchCondition.checkInToDate.getFullYear(), searchCondition.checkInToDate.getMonth(), searchCondition.checkInToDate.getDate(), 0, 0, 0),
          subjectTypeCode: "Patient",
          hpcSearchTypeCode: this.get('hpcSelectedValue')
        };
        this.set('isResultGridShow', true);
        params.encounterTypeCode = params.encounterTypeCode == 'A'? '' : params.encounterTypeCode;
        const res = await this.getList(this.get('defaultUrl') + 'specimen-checkins/search', null, params, false);
        if(isEmpty(res)){
          this.set('statusListItemsSource', []);
          this.set('originalDatas', []);
        } else {
          this._setGridData(res);
        }
        this.set('isResultGridShow', false);
        this.set('isInitial', true);
      } catch(e) {
        this._catchError(e);
      }
    },
    _setGridData(res){
      res.map((d, index) => {
        d.rowNum = index;
        if(!isEmpty(d.specimenOrders)) {
          const specimenOrders = d.specimenOrders[0];
          d.subjectName = specimenOrders.subject.name;
          d.issuedDepartmentName = specimenOrders.issuedDepartment.name;
          d.departmentName = specimenOrders.department.name;
          d.orderedStaffName = specimenOrders.orderedStaff.name;
          d.physicianStaffName = specimenOrders.physicianStaff.name;
          d.orderDate = specimenOrders.orderDate;
          d.classificationInfo = specimenOrders.classification.name;
          d.orderDateTime = specimenOrders.orderDateTime;
        }
      });
      this.set('currentPage', 0);
      this.set('originalDatas', res);
      this.set('statusListItemsSource', this.getPageSource(res));
    },
    getPageSource(datas) {
      if(isEmpty(datas)) {
        return;
      }
      const startAt = this.get('currentPage') * this.get('recordSize');
      const endAt = startAt + (this.get('recordSize') - 1);
      return datas.filter(item => item.rowNum >= startAt && item.rowNum <= endAt);
    },

    _cancelValidationCheck(status){
      let returnValue= false;
      const selectedItems= this.get('selectedItems');
      const item= copy(selectedItems);

      if(isEmpty(selectedItems)){
        this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9260', 'F', 'Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);

        return false;
      }

      selectedItems.forEach(obj =>{
        if(status == 'CheckIn' && obj.progressStatus.code!=status){
          this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9288', 'F', '검사상태를 확인해주시기 바랍니다.'), 'warning', 'Ok', 'Ok', '', 2000);
          item.popObject(obj);
        }else if (status == 'Received'){
          if(obj.progressStatus.code!=status){
            this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9288', 'F', '검사상태를 확인해주시기 바랍니다.'), 'warning', 'Ok', 'Ok', '', 2000);
            item.popObject(obj);
          }
        }
      });

      if(selectedItems.length == item.length){
        returnValue= true;
      }

      return returnValue;
    },

    _inappropriateRegistrationValidationCheck(){
      if(isEmpty(this.get('selectedItems'))){
        this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9260', 'F', 'Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);

        return false;
      }
    },

    //취소
    _cancel(now){
      let promise = null;
      if(this.get('cancelOption') =='Checkin'){
        //접수취소
        promise= this.update(this.get('defaultUrl') + 'specimen-checkins', null, false, this._setCheckInCancelParams(now));
      }else if(this.get('cancelOption') == 'Received'){
        //등록취소
        promise = this.update(`${this.get('samplingUrl')}specimen-collections`, null, false, this._setRegistrationCancelParams(now), true);
        // promise= this.get('specimenSamplingService').cancelSampling(this._setRegistrationCancelParams(now));
      }
      if(isEmpty(promise)){
        return this.get('specimenCheckinService')._showMessage(this.getLanguageResource('8947', 'S','에러가 발생했습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
      }else{
        return promise.then(function(res){
          return res;
        }).catch(function(error){
          this._catchError(error);
        }.bind(this));
      }
    },

    //취소 Param
    _setCheckInCancelParams(now){
      const selectedItem= this.get('selectedItem');
      return {
        checkInId: selectedItem.checkInId,
        rejectStaffId: this.get('currentUser.employeeId'),
        // rejectDatetime: new Date(),
        rejectDatetime: now,
        reasonId: this.get('reasonId'),
        reasonName: this.get('reasonName')
      };
    },

    _setRegistrationCancelParams(now){
      // const item = this.get('selectedItem');
      const selectedItems = this.get('selectedItems');
      const specimenAttributes = A();
      let params={};
      selectedItems.forEach(item => {
        specimenAttributes.addObject({
          specimenId:  item.specimenId,
          collectionComment: null,
          specimenComment: null,
          specimenProperty: item.specimenProperty
        });

      });
      params= {
        selectedModifyOption: "4",
        collectionStaffId: null,
        collectionStartDatetime: null,
        collectionEndDatetime: null,
        cancelStaffId: null,
        cancelDatetime: null,
        receivedTypeCode: null,
        receivedStaffId: null,
        receivedDatetime: null,
        receivedCancelStaffId : this.get('currentUser.employeeId'),
        receivedCancelDatetime: now,
        specimenAttributes: specimenAttributes
      };
      // }.bind(this));
      // promise = this.update(this.get('defaultUrl') + 'specimen-collections', null, false, params, true);
      return params;
      // return promise.then(res => {
      //   this.get('specimenSamplingService').onShowToast('save', this.getLanguageResource('8943', 'F', '취소되었습니다.'), '');
      //   return res.response;
      // }).catch(function(err) {
      //   this._catchError(err);
      // }.bind(this));
    },

    _catchError(e){
      this.set('isResultGridShow',false);
      this.set('isInitial', null);
      return this.showResponseMessage(e);
    }
  });