import { isEmpty } from '@ember/utils';
// import { set } from '@ember/object';
import { computed, set } from '@ember/object';
import { hash } from 'rsvp';
// import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'specimencheckin-module/app-config';
import { getOwner } from '@ember/application';
import specimencheckinPrintMixin from 'specimencheckin-module/mixins/specimen-check-in-print-mixin';
import specimencheckinMessageMixin from 'specimencheckin-module/mixins/specimen-check-in-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,specimencheckinPrintMixin, specimencheckinMessageMixin,
  {
  /* 1. Service define Area
  testService:Ember.inject.service(),
  */
    layout,
    // specimenCheckinService: service('specimen-check-in-service'),
    specimenCheckinService: computed(function () {
      return getOwner(this).lookup('service:specimen-check-in-service');
    }),

    // 2. Property Area
    defaultUrl: null,
    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-check-in-observation-delay-specimens');
      //Set Stateful properties
      this.setStateProperties([
        'defaultUrl',
        'searchCondition',
        'gridColumns',
        'gridItemsSource',
      ]);
      if (this.hasState() === false) {
      //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimencheckin') + `specimen-checkin/${config.version}/`);
        this.set('isInitShow', true);
        this.set('gridColumns',[
          { title: this.getLanguageResource('10238', 'F', '등록일'), field: 'registrationDatetime', width: 90, type: 'date', dataFormat: 'd', align: 'center' },
          { title: this.getLanguageResource('16963', 'S', '구분'), field: 'encounterType.name', align: 'center', width: 50},
          { title: this.getLanguageResource('16881', 'S','Pt Name'), field: 'subject.name', align: 'center', headerTemplateName: 'barcolor', bodyTemplateName: 'boldTooltip', width: 90 },
          { title: this.getLanguageResource('8451', 'S','MRN'), field: 'subject.displayNumber', headerTemplateName: 'barcolor', bodyTemplateName: 'bold', align: 'center', width: 65 },
          { title: this.getLanguageResource('3680', 'F','Sex'), field: 'subject.gender',align: 'center', width: 35 },
          { title: this.getLanguageResource('1662', 'S','Age'), field: 'subject.age', width: 35, align: 'center' },
          { title: this.getLanguageResource('16892', 'S','검사분류'), field: 'classification.name', bodyTemplateName: 'tooltip', width: 140 },
          { title: this.getLanguageResource('859', 'S','검체번호'), field: 'specimenNumber',headerTemplateName: 'barcolor', bodyTemplateName: 'colfont', width: 100, align: 'center' },
          { title: this.getLanguageResource('3332', 'S','사유'), field: 'reason.reasonContent', bodyTemplateName: 'tooltip' },
          { title: this.getLanguageResource('9413', 'S','등록자'), field: 'registrationStaff.name', bodyTemplateName: 'tooltip', width: 100, align: 'center' },
          // { title: this.getLanguageResource('8387', 'S','확인자'), field: 'verifiedStaff.name', width: 100, bodyTemplateName: 'tooltip', align: 'center' },
        ]);
      }
    //Initialize Stateless properties
    },

    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1180');
      if (this.hasState() === false) {
        const defaultUrl= this.get('defaultUrl');
        hash({
          worklistConfigurations: this.getList(defaultUrl + 'worklist-configurations/search', {staffId:this.get('co_CurrentUserService.user.employeeId')}, null),
          examTypeItemsSource: this.getList(defaultUrl + 'classifications/search', {selectedOption: 'EncounterTypeCode', classificationType: 1}, null),
          businessCodes: this.getList(defaultUrl + 'business-codes/search', null,{
            classificationCodes: [
              'EncounterTypeCode',
            ]
          }, false),
        }).then(function(result){
          this.set('examTypeItemsSource', result.examTypeItemsSource);
          this.set('worklistConfigurations', result.worklistConfigurations.get('firstObject.property'));

          const worklistConfigurations= this.get('worklistConfigurations');
          set(worklistConfigurations, 'classificationIds', isEmpty(worklistConfigurations) ? null : worklistConfigurations.classifications.mapBy('id'));
          const patientTypeItemsSource= [];
          result.businessCodes.forEach(e=>{
            if(e.classificationCode == 'EncounterTypeCode'){
              patientTypeItemsSource.addObject(e);
            }
          });
          this.set('patientTypeItemsSource', patientTypeItemsSource);
          const today= this.get('co_CommonService').getNow();
          const searchCondition= {
            fromDate: today,
            toDate: today,
            subjectNumber: null,
            specimenNumber: null,
            encounterTypeCode: patientTypeItemsSource.get('firstObject.code'),
            classificationIds: null,
          };

          this.set('searchCondition', searchCondition);
          this._getGridData();

          this.set('isInitShow', false);
        }.bind(this)).catch(function(e){
          this.set('isInitShow', false);
          this._catchError(e);
        }.bind(this));
      }
    },
    // 4. Actions Area
    actions: {
      onLoadCombobox(e){
        this.set('_classificationIdsCombobox', e.source);
      },
      onLoadGrid(e){
        this.set('gridSource', e.source);
      },

      onExamTypeSelectedChanged(e){
        if(!isEmpty(e.item)){
          if(!isEmpty(e.item.code)){
            //변경시
            set(this.get('searchCondition'), 'encounterTypeCode', e.item.code);
          }
        }
        set(this.get('searchCondition'), 'classificationIds', this.get('_classificationIdsCombobox.selectedItems').map(function(item){
          return item.classificationId;
        }));
        this._getGridData();
      },
      onSearchClick(){
        this._getGridData();
      },
      onExcelPrintAction() {
        const gridSource = this.get('gridSource');
        const reason = 'Excel export inappropriate specimen list.';
        const headers=[];
        const fields=[];
        this.get('gridColumns').forEach(function(item, index){
          headers.addObject({ left: index, top: 0, right: index, bottom: 0, value: item.title});
          item.type == 'date'? fields.addObject({ width: 140, value: item.field }) : fields.addObject({ width: item.width, value: item.field });
        });
        gridSource.exportToExcel('observation-delay-specimens.xlsx', headers, fields, this, 'onExcelPrintAction',reason , this.get('gridItemsSource'));
      },
    },
    // 5. Private methods Area
    _getGridData(){
      const searchCondition= this.get('searchCondition');
      if(isEmpty(searchCondition)){
        return;
      }
      if(isEmpty(searchCondition.fromDate) || isEmpty(searchCondition.toDate)){
        this.get('specimenCheckinService')._showMessage(this.getLanguageResource('9290', 'F', '날짜를 확인하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
        return;
      }

      set(this.get('searchCondition'), 'classificationIds', this.get('_classificationIdsCombobox.selectedItems').map(function(item){
        return item.classificationId;
      }));
      this.set('isGridShow', true);
      this.set('gridItemsSource', null);
      const params={
        fromDate: new Date(searchCondition.fromDate.getFullYear(), searchCondition.fromDate.getMonth(), searchCondition.fromDate.getDate(), 0, 0, 0).toFormatString(),
        toDate: new Date(searchCondition.toDate.getFullYear(), searchCondition.toDate.getMonth(), searchCondition.toDate.getDate(), 0, 0, 0).toFormatString(),
        specimenNumber: isEmpty(searchCondition.specimenNumber)? null: searchCondition.specimenNumber.trim(),
        specimenId: null,
        encounterTypeCode: searchCondition.encounterTypeCode =='A'? null: searchCondition.encounterTypeCode,
        subjectTypeCode: 'Patient',
        subjectNumber: isEmpty(searchCondition.subjectNumber)? null : searchCondition.subjectNumber.trim(),
        reasonId: null,
        classificationIds: isEmpty(searchCondition.classificationIds)? null : searchCondition.classificationIds.join('&classificationIds=')
      };
      this.getList(this.get('defaultUrl') + 'specimen-checkins/observation-delay-specimens/search', params, null).then(function(res){
        this.set('gridItemsSource', res);
        this.set('isGridShow', false);
      }.bind(this)).catch(function(e){
        this._catchError(e);
      }.bind(this));
    },

    _catchError(e){
      this.set('isGridShow', false);
      this.showResponseMessage(e);
    }
  });