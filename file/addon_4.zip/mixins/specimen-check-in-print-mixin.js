/* eslint-disable no-undef */
import { isEmpty } from '@ember/utils';
import Mixin from '@ember/object/mixin';
// import { get, } from '@ember/object';

export default Mixin.create({
  onPropertyInit() {
    this._super(...arguments);
  },

  getPrinterName(){
    let printerG =null;
    let printerD =null;
    let printerF =null;
    let printerB =null;
    let printerDefault = null;
    return this.get('co_PersonalizationService').getPersonalPrinterSetting('Laboratory', 'print').then(result =>{
      if(isEmpty(result)){
        return{
          'printerDefault': printerDefault,
          'printerG' : printerG,
          'printerD' : printerD,
          'printerB' : printerB,
          'printerF' : printerF
        };
      }
      const settingValue = JSON.parse(result.get('firstObject.settingValue'));
      if(isEmpty(settingValue)) {
        return{
          'printerDefault': printerDefault,
          'printerG' : printerG,
          'printerD' : printerD,
          'printerB' : printerB,
          'printerF' : printerF
        };
      }
      if(!isEmpty(settingValue.defaultLabelPrinter)){
        printerDefault=settingValue.defaultLabelPrinter;
      }
      if(!isEmpty(settingValue.item)){
        printerG = settingValue.item.findBy('printSettingCode', 'G');
        printerD = settingValue.item.findBy('printSettingCode', 'D');
        printerF = settingValue.item.findBy('printSettingCode', 'F');
        printerB = settingValue.item.findBy('printSettingCode', 'B');
      }
      return{
        'printerDefault': printerDefault,
        'printerG' : isEmpty(printerG.printerName)? printerDefault : printerG.printerName,
        'printerD' : isEmpty(printerD.printerName)? printerDefault : printerD.printerName,
        'printerB' : isEmpty(printerB.printerName)? printerDefault : printerB.printerName,
        'printerF' : isEmpty(printerF.printerName)? printerDefault : printerF.printerName
      };

    });

  },

  setPrintParams(printSetting, printDataFieldG, printDataFieldD, printDataFieldF, printDataFieldDefault){
    // const res=[];
    if(isEmpty(printDataFieldG) && isEmpty(printDataFieldD) && isEmpty(printDataFieldF)){
      return{
        printConfig: {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerDefault},
        printContent: {
          'parameterField': {}, 'dataField': { "specimenInfo" : printDataFieldDefault}
        }
      };
    }else{
      if(!isEmpty(printDataFieldG)){
        return{
          type: 'printDataFieldG',
          printConfig: {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerG },
          printContent: {
            'parameterField': {}, 'dataField': { "specimenInfo" : printDataFieldG}}
        };
      }
      if(!isEmpty(printDataFieldD)){
        return{
          type: 'printDataFieldD',
          printConfig: {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerD },
          printContent: {
            'parameterField': {}, 'dataField': { "specimenInfo" : printDataFieldD}}
        };
      }
      if(!isEmpty(printDataFieldF)){
        return{
          type: 'printDataFieldF',
          printConfig : {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerF },
          printContent : {
            'parameterField': {}, 'dataField': { "specimenInfo" : printDataFieldF}}
        };
      }
      if(!isEmpty(printDataFieldDefault)){
        return{
          type: 'printDataFieldDefault',
          printConfig: {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerDefault },
          printContent: {
            'parameterField': {}, 'dataField': { "specimenInfo" : printDataFieldDefault}}
        };
      }
    }
  },
  getExportByArrayTypeExcel(initial, itemList, colInfo, origin, name) {
    /* Initial row */
    const exportItemsWS = XLSX.utils.aoa_to_sheet(initial);
    if (!isEmpty(colInfo)) {
      exportItemsWS['!cols'] = colInfo;
    }

    XLSX.utils.sheet_add_aoa(exportItemsWS, itemList, {origin: isEmpty(origin) ? "A2" : origin});
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, exportItemsWS, 'sheet1');
    let fileName = this.get('fr_I18nService').formatDate(new Date(this.get('co_CommonService').getNow()), 'g');
    if(!isEmpty(name)) {
      fileName = `${this.get('fr_I18nService').formatDate(new Date(this.get('co_CommonService').getNow()), 'd')}${name}`;
    }
    XLSX.writeFile(wb, `${fileName}.xlsx`);
    this.auditExcelExport('getExportByArrayTypeExcel', 'specimecheckin', itemList.get('firstObject'));
  },
  _getExportExcel(gridItemsSource, columns, fileName) {
    const firstRow = [];
    const colInfo = [];
    columns.forEach(column => {
      if(!isEmpty(column.field)) {
        firstRow.push(column.title);
        colInfo.push({wpx: column.width});
      }
    });
    const initArr = [firstRow];
    const resultArr = [];
    gridItemsSource.forEach(datas => {
      const tempArr = [];
      columns.forEach(col => {
        if(!isEmpty(col.field)) {
          const fields = col.field.split('.');
          let fieldsData = datas[col.field];
          if(fields.length > 1) {
            if(isEmpty(datas[fields[0]])) {
              fieldsData = '';
            } else {
              fieldsData = datas[fields[0]][fields[1]];
            }
          }
          tempArr.push(fieldsData);
        }
      });
      resultArr.push(tempArr);
    });
    this.getExportByArrayTypeExcel(initArr, resultArr, colInfo, null, fileName);
  },
  _getExportExcelByRefer(gridItemsSource, columns) {
    const firstRow = [];
    const colInfo = [];
    columns.forEach(column => {
      if(!isEmpty(column.field)) {
        firstRow.push(column.title);
        colInfo.push({wpx: column.width});
      }
    });
    const initArr = [firstRow];
    const resultArr = [];
    gridItemsSource.forEach(datas => {
      const tempArr = [];
      columns.forEach(col => {
        if(!isEmpty(col.field)) {
          const fields = col.field.split('.');
          let fieldsData = datas[col.field];
          if(fields.length > 1) {
            if(isEmpty(datas[fields[0]])) {
              fieldsData = '';
            } else {
              fieldsData = datas[fields[0]][fields[1]];
            }
          }
          tempArr.push(fieldsData);
        }
      });
      resultArr.push(tempArr);
    });
    const exportItemsWS = XLSX.utils.aoa_to_sheet(initArr);
    if (!isEmpty(colInfo)) {
      exportItemsWS['!cols'] = colInfo;
    }

    XLSX.utils.sheet_add_aoa(exportItemsWS, resultArr, {origin: isEmpty(origin) ? "A2" : origin});
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, exportItemsWS, 'sheet1');
    const fileName = `${this.get('fr_I18nService').formatDate(new Date(this.get('co_CommonService').getNow()), 'd')}_lis_pandemic_export.xlsx`;
    XLSX.writeFile(wb, `${fileName}`);
    this.auditExcelExport('getExportByArrayTypeExcel', 'specimecheckin', resultArr.get('firstObject'));
  },

});