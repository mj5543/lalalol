import { isEmpty } from '@ember/utils';
import { inject as service } from '@ember/service';
// import { getOwner } from '@ember/application';
// import { computed } from '@ember/object';
// import { isEmpty } from '@ember/utils';
import CHIS from 'framework/chis-framework';
export default CHIS.FR.Core.ServiceBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, {
  domain: 'specimencheckin',
  // domain: 'specimensampling',
  urlPrefix: '',
  currentUser: null,
  toast: service('toast-service'),
  // toast: computed(function () {
  //   return getOwner(this).lookup('service:toast-service');
  // }),
  // specimenSamplingService: service('specimen-sampling-service'),
  init() {
    this._super(...arguments);

    const serverCallConfig = this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', this.get('domain'));
    this.set('urlPrefix', `${serverCallConfig}specimen-check-in/v0/`);
  },

  getDisplayView(specimenNumber, examinationId){
    return this.getList(`${this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimencheckin')}specimen-checkin/v0/specimen-examination-worklists/results/display-view`,
      {specimenNumber: specimenNumber,
        // isCollected: isCollected == true ? true : null}, null).then(function(res){
        examinationId: isEmpty(examinationId)? null : examinationId}, null).then(function(res){
      // }, null).then(function(res){
      return res;
    });
  },

  getOverView(specimenNumber){
    return this.getList(`${this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimencheckin')}specimen-checkin/v0/specimen-examination-worklists/specimens/overview`, {specimenNumber:specimenNumber}, null);
  },

  getInappropriateInfo(specimenId){
    return this.getList(`${this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimencheckin')}specimen-checkin/v0/specimen-checkins/inappropriate-specimens`,
      {specimenId: specimenId}, null).then(function(res){
      return res;
    });
  },
  deleteInappropriate(inappropriateSpecimenId){
    return this.delete(`${this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimencheckin')}specimen-checkin/v0/specimen-checkins/inappropriate-specimens/`+
    encodeURIComponent(inappropriateSpecimenId), null,{inappropriateRegistrationId: inappropriateSpecimenId},false).then(function(res){
      return res;
    });
  },

  getExamTypeItemsSource(){
    return this.getList(`${this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimencheckin')}specimen-checkin/v0/classifications/search`, {selectedOption: 'EncounterTypeCode', classificationType: 1}, null);
  },

  _showMessage(caption, messageBoxImage, messageBoxButton, messageBoxFocus, messageBoxText, messageboxInterval){
    const options = {
      'caption': caption,
      'messageBoxImage': messageBoxImage,
      'messageBoxButton': messageBoxButton,
      'messageBoxFocus': messageBoxFocus,
      'messageBoxText': messageBoxText,
      'messageboxInterval': messageboxInterval
    };

    return messageBox.show(this, options);
  },
  onShowToast(type, content, title) {
    this.get('toast').toastr({
      type: type,
      content: content,
      title: title,
      option: {
        closeButton: false,
        timeOut: 4000,
        positionClass: 'toast-bottom-center'
      }
    });
  },
});