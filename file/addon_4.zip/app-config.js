//configuration for biz
export default {
  version : "v0"
};