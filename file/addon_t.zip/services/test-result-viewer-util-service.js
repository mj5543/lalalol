// import Ember from 'ember';
import CHIS from 'framework/chis-framework';
// import config from '../app-config';

export default CHIS.FR.Core.ServiceBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, {

  init() {
    this._super(...arguments);
  },

});