/* eslint-disable chis/avoid-memory-leak */
import CHIS from 'framework/chis-framework';
import config from 'testresultviewer-module/app-config';
import { inject as service } from '@ember/service';

export default CHIS.FR.Core.ServiceBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, {

  checkinUrl: null,
  conductUrl: null,
  toast: service('toast-service'),

  init() {
    this._super(...arguments);
    const defaultUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', 'testresultviewer') +
    `test-result-viewer/${config.version}/`;

    this.set('defaultUrl', defaultUrl);
    const serverCallConfig = this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'testresultviewer');
    const patientexaminationUrl = `${serverCallConfig}patient-examination-report/${config.version}/`;
    this.set('patientexamination', patientexaminationUrl);
  },

  onGetPatientExamStatusColor(statusCode){
    let color = '';
    if (statusCode == 1) {
      color = '#0056cc';
    }else if (statusCode == 2) {
      color = '#df4db1';
    }else if (statusCode == 3) {
      color = '#00b104';
    }else if (statusCode == 4) {
      color = '#008fb3';
    }else if (statusCode == 5) {
      color = '#f67400';
    }else if (statusCode == 6) {
      color = '#a41ad2';
    }else if (statusCode == 7) {
      color = '#f71616';
    }else{
      color = '';
    }
    return color;
  },

  onShowToast(type, content, title) {
    this.get('toast').toastr({
      type: type,
      content: content,
      title: title,
      option: {
        closeButton: false,
        timeOut: 3000,
        positionClass: 'toast-bottom-center'
      }});
  },

  onDisplayMessage(type, caption, message, btype, focus, interval) {
    const options = {
      'caption': caption,
      'messageBoxButton': btype,
      'messageBoxImage': type,
      'messageBoxText': message,
      'messageBoxFocus': focus,
      'messageboxInterval': interval
    };

    messageBox.show(this, options);
  },

  showMessage(caption, messageBoxImage, messageBoxButton, messageBoxFocus, messageBoxText, messageboxInterval){
    const options = {
      'caption': caption,
      'messageBoxImage': messageBoxImage,
      'messageBoxButton': messageBoxButton,
      'messageBoxFocus': messageBoxFocus,
      'messageBoxText': messageBoxText,
      'messageboxInterval': messageboxInterval
    };

    return messageBox.show(this, options);
  },

  getImageList(params) {
    const path = this.get('defaultUrl') + 'examinations/file-note';
    return this.getList(path, params, null);
  },
  getDiagnosticReportsImages(params) {
    const path = this.get('patientexamination') + 'diagnostic-reports/images';
    return this.getList(path, null, params, false);
  },

});