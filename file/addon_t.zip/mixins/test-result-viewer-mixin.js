/* eslint-disable chis/require-js-permitted-expression */
/* eslint-disable no-console */
/* eslint-disable max-lines-per-function */
import moment from 'moment';
import Mixin from '@ember/object/mixin';
import $ from 'jquery';
import { inject as service } from '@ember/service';
import { isEmpty, isPresent } from '@ember/utils';
import EmberObject, { set } from '@ember/object';
import { A as emberA } from '@ember/array';

export default Mixin.create({
  loaderType: 'spinner',
  loaderDimed: false,
  isShowLoader: false,
  calendarSelectedDate: null,
  selectedDate: null,
  selectedPartId: null,
  pacsInfo: null,
  apiService: service('testresultviewer-service'),
  demographicService: service('patient-demographic-service'),
  toast: service('toast-service'),
  pacsService: service('pacs-service'),
  isCurrentLocaleByKr: true,

  onPropertyInit() {
    this._super(...arguments);
    if(this.get('fr_I18nService.currentLocale') !== 'ko-kr') {
      this.set('isCurrentLocaleByKr', false);
    }
  },

  periodTypeList() {
    const periodTypes = [
      {value: 'T', content: this.getLanguageResource('1880', 'F', '', '당일'), index: 0},
      {value: '1w', content: this.getLanguageResource('9675', 'F', '', '1주 전'), index: 1},
      {value: '2w', content: this.getLanguageResource('9791', 'F', '', '2주 전'), index: 2},
      {value: '1m', content: this.getLanguageResource('9676', 'F', '', '1개월 전'), index: 3},
      {value: '3m', content: this.getLanguageResource('10713', 'F', '', '3개월 전'), index: 4},
      {value: '6m', content: this.getLanguageResource('9792', 'F', '', '6개월 전'), index: 5},
      {value: '1y', content: this.getLanguageResource('9677', 'F', '', '1년 전'), index: 6},
      {value: '3y', content: this.getLanguageResource('9793', 'F', '', '3년 전'), index: 7},
      {value: 'All', content: this.getLanguageResource('6700', 'F', '', '전체'), index: 8},
    ];
    return periodTypes;
  },
  actions: {
    onPeriodDateChanged(e){
      if(isEmpty(this.get('searchCondition.fromDate')) || isEmpty(this.get('searchCondition.toDate'))){
        return;
      }
      if (this.get('isPopoverFirstOpen')) {
        return;
      }
      if (this.get('customPeriod.fromDate') === e.selectedFromDate && this.get('customPeriod.toDate') === e.selectedToDate) {
        return;
      }
      if(this.get('searchCondition.selectedPeriodType.value') === 'custom'){
        this.set('searchCondition.selectedPeriodType.content'
          , this.get('fr_I18nService').formatDate(this.get('searchCondition.fromDate'), 'd')+ ' ~ ' + this.get('fr_I18nService').formatDate(this.get('searchCondition.toDate'), 'd'));
        this._setTagList();
        if (this.get('customPeriod.fromDate') !== e.selectedFromDate || this.get('customPeriod.toDate') !== e.selectedToDate) {
          const picker = this.get('fromToPicker');
          set(picker, 'isOpen', false);
          this._periodChangedRefresh();
        }
      }
    },
    onGridCopySelection(e) {
      let content = '';
      content = e.content.replace(/undefined/giu, '\t');
      content = content.replace(/null/giu, '\t');
      set(e, 'content', content);
    },
    onSettingClick() {
      this.set('isSettingOpen', true);
    },
  },

  _setExaminationTootip(examimnationName, orderer, reporter) {
    let ordererName = '';
    if(!isEmpty(orderer)) {
      ordererName = `<br>${this.getLanguageResource('9686', 'S', '처방의')}: ${orderer}`;
    }
    let reporterName = '';
    if(!isEmpty(reporter)) {
      reporterName = `<br>${this.getLanguageResource('10845', 'S', '검사자')}: ${reporter}`;
    }
    return `${examimnationName}${ordererName}${reporterName}`;
  },

  setSpecimenexaminationGridColumns() {
    let isColumnHidden = true;
    let isCommentsHidden = false;
    let resultWidth = 80;
    if(this.get('isDisplay2xMode')) {
      isColumnHidden = false;
      isCommentsHidden = true;
      resultWidth = 100;
    }
    return [
      { field: 'checkInId', title: this.getLanguageResource('9919', 'S', '접수일시'), width: 120, merge: true, bodyTemplateName:'regDate', headerTemplateName: 'sortHeader', fixedOrder: true },
      { field: 'reportedDateTime', title: this.getLanguageResource('2873', 'S', '보고일시'), width: 120, hidden: isColumnHidden,align: 'center', type: 'date', dataFormat: 'g', headerTemplateName: 'sortHeader' },
      { field: 'orderDate', title: this.getLanguageResource('5246', 'S', '오더일'), width: 120, hidden: isColumnHidden, align: 'center', type: 'date', dataFormat: 'd', headerTemplateName: 'sortHeader'},
      { field: 'examination.abbreviation', title: this.getLanguageResource('16920', 'S', '검사항목'), width:130, bodyTemplateName: 'examinationTooltip', headerTemplateName: 'sortHeader'},
      { field: 'displayResult', title: this.getLanguageResource('890', 'S', '결과'), align: 'center', width:resultWidth, bodyTemplateName:'detailview', fixedOrder: true, headerTemplateName:'headerTitle' },
      { field: 'recentDisplayResult', title: this.getLanguageResource('6034', 'S'), align: 'center', width:resultWidth, bodyTemplateName: 'prevDetailview', fixedOrder: true, headerTemplateName:'headerTitle'},
      { field: 'commentText', title: this.getLanguageResource('3173', 'F'), align: 'center', width:55, hidden: isCommentsHidden, bodyTemplateName: 'comments', headerTemplateName: 'sortHeader',},
      { field: 'flag.displayCode', title: this.getLanguageResource('14749', 'S', '참고'), align: 'center', width:38, bodyTemplateName:'flagSymbol', headerTemplateName: 'sortHeader' },
      { field: 'subjectReferenceRange', title: this.getLanguageResource('10109', 'S', '참고치'), align: 'center', width:125, bodyTemplateName: 'subjectReferenceRange', headerTemplateName: 'sortHeader'},
      { field: 'resultComment', title: this.getLanguageResource('906', 'S'), align: 'center', hidden: isColumnHidden, width:80, bodyTemplateName: 'resultComment', headerTemplateName: 'sortHeader'},
      { field: 'orderComment', title: this.getLanguageResource('5228', 'S'), align: 'center', hidden: isColumnHidden, width:80, bodyTemplateName: 'orderComment', headerTemplateName: 'sortHeader'},
    ];
  },

  getSearchParamsDate() {
    return new Date(this.get('selectedDate').getFullYear(), this.get('selectedDate').getMonth(), this.get('selectedDate').getDate()).toFormatString();
  },
  showMessage(caption, messageBoxImage, messageBoxButton, messageBoxFocus, messageBoxText, messageboxInterval){
    const options = {
      'caption': caption,
      'messageBoxImage': messageBoxImage,
      'messageBoxButton': messageBoxButton,
      'messageBoxFocus': messageBoxFocus,
      'messageBoxText': messageBoxText,
      'messageboxInterval': messageboxInterval
    };

    return messageBox.show(this, options);
  },

  showConfirm(caption, messageBoxText){
    const options = {
      'caption': caption,
      'messageBoxButton': 'YesNo',
      'messageBoxImage': 'question',
      'messageBoxText': messageBoxText,
      'messageBoxFocus': 'No'
    };
    return messageBox.show(this, options);
  },
  showWarningMessage(message, interval) {
    return this.showMessage(message, 'warning', 'Ok', 'Ok', '', interval);
  },
  showMessagebox(caption, message, type, interval) {
    return this.showMessage(caption, type, 'Ok', 'Ok', message, interval);
  },
  showToast(type, content, title){
    this.get('toast').toastr({type: type, content: content, title: title,
      option: {
        closeButton: false,
        timeOut: 3000,
        positionClass: 'toast-bottom-center'
      }
    });
  },
  showConfirmMeaage(message){
    return this.showConfirm(message, '');
  },
  showToastErrorOccurred() {
    this.showToast('error', '', this.getLanguageResource('8947', 'F', '', '에러가 발생했습니다.'));
  },
  showToastSearchhWordError() {
    this.showToast('error', '', this.getLanguageResource('10869', 'F', '', '검색어에러'));
  },
  showToastApiError() {
    this.showToast('error', '', this.getLanguageResource('10867', 'F', '', 'api에러'));
  },
  _showError(e) {
    if(e.status === 500) {
      this.showToastApiError();
    } else if(e.status === 400 && !isEmpty(e.responseJSON)) {
      this.showMessagebox('', e.responseJSON.messages[0], 'warning');
    } else {
      this.showToastErrorOccurred();
    }
    console.log(e);
  },
  
  //2021.05.21 PACSLINK 이전로직 삭제예정
  async _getPacsUrlOld(type) {
    try{
      const patientInfo = this.get('patientGlobalInformation');
      let patientId = patientInfo.patientId;
      let examinationPlanId = null;
      if(isPresent(this.get('patientExamItem'))) {
        examinationPlanId = this.get('patientExamItem.examinationPlanId');
      }
      if(this.get('hasOtherCompParam')) {
        patientId = this.get('model.patientId');
      }
      const pacsParams = {
        patientId: patientId,
        examinationPlanId: examinationPlanId,
        employeeId: this.get('userGlobalInformation.employeeId'),
        interfaceTypeCode: type,
        linkAddress : 'TestResultViewer'
      };
      const result = await this.getList(`${this.get('defaultUrl')}patient-examination-reports/interface-information`, pacsParams, null);
      if(isPresent(result)) {
        const pacsMessage = {
          'Type': result.viewTypeCode,
          'Id': result.employeePacsId,
          'PatientId': patientInfo.patientDisplayId,
          'AccessionNumber': result.accessNumber,
          'StudyDate': result.studyDate,
          'WorkList': result.maxNumber,
          'Modality': result.modality,
          'Password': result.password,
          'Inst': result.inst
        };
        if(isEmpty(result.employeePacsId) && result.isMandotoryUserInfo) {
          this.showMessagebox(this.getLanguageResource('12680', 'F', '', 'PACS 사용자정보가 없습니다'), this.getLanguageResource('12681', 'F', '', '직원정보에서 PACS 사용정보를 등록해주세요.'), 'warning');
          return;
        }
        this.get('pacsService').sendPacket(this, pacsMessage, result.linkedTypeCode);
      }
    } catch(e) {
      console.error(e);
    }
  },

  async _getPacsUrl(type) {
    try{
      const patientInfo = this.get('patientGlobalInformation');
      let examinationPlanId = null;
      let patientId = null;
      if(isPresent(patientInfo)) {
        patientId = patientInfo.patientId;
      }
      if(isPresent(this.get('patientExamItem'))) {
        examinationPlanId = this.get('patientExamItem.examinationPlanId');
      }
      if(this.get('hasOtherCompParam')) {
        patientId = this.get('model.patientId');
      }
      const pacsParams = {
        patientId: patientId,
        examinationPlanId: examinationPlanId,
        employeeId: this.get('userGlobalInformation.employeeId'),
        interfaceTypeCode: type,
        linkAddress : 'TestResultViewer'
      };
      // const result = await this.getList(`${this.get('defaultUrl')}patient-examination-reports/interface-address`, pacsParams, null);
      const result = await this.getList(`${this.get('defaultUrl')}patient-examination-reports/pacs-link`, pacsParams, null);
      if(isPresent(result)) {
        const pacsMessage = EmberObject.create();
        result.forEach(e => {
          set(pacsMessage, e.displayCode, e.resultValue);
        });
        if(isEmpty(pacsMessage.Id) && (pacsMessage.IsMandotoryUserInfo == 'Y')){
          this.showMessagebox(this.getLanguageResource('12680', 'F', '', 'PACS 사용자정보가 없습니다'), this.getLanguageResource('12681', 'F', '', '직원정보에서 PACS 사용정보를 등록해주세요.'), 'warning');
          return;
        }
        this.get('pacsService').sendPacket(this, pacsMessage, pacsMessage.LinkedTypeCode);
      }
    } catch(e) {
      console.error(e);
    }
  },
  _dateValidation() {
    const now = new Date(this.get('co_CommonService').getNow());
    const nowString = `${now.getFullYear()}${now.getMonth()}${now.getDate()}`;
    const compareDate = `${this.get('selectedDate').getFullYear()}${this.get('selectedDate').getMonth()}${this.get('selectedDate').getDate()}`;
    if (nowString !== compareDate) {
      return false;
    } else {
      return true;
    }
  },

  getSearchDate() {
    let fromDate = null;
    let toDate = null;

    if(!isEmpty(this.get('searchCondition.fromDate')) && !isEmpty(this.get('searchCondition.toDate'))) {
      fromDate = new Date(this.get('searchCondition.fromDate').getFullYear(), this.get('searchCondition.fromDate').getMonth(), this.get('searchCondition.fromDate').getDate(), 0, 0, 0).toFormatString();
      toDate = new Date(this.get('searchCondition.toDate').getFullYear(), this.get('searchCondition.toDate').getMonth(), this.get('searchCondition.toDate').getDate(), 0, 0, 0).toFormatString();
    }
    return {fromDate, toDate};
  },

  getDateFormatString(date) {
    return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 0, 0).toFormatString();
  },

  setSearchConditionFromToDate(type, now) {
    let disalbleFromToDate = true;
    let content ='';
    let tooltip = null;
    let index = 0;
    let utcNow = null;
    if(!isEmpty(now)) {
      //date service api 중복호출방지
      utcNow = now;
    } else {
      utcNow = new Date(this.get('co_CommonService').getNow());
    }
    let searchFromDate = null;
    let searchToDate = utcNow;
    switch (type){
      case 'T':
        searchFromDate = utcNow;
        content = this.getLanguageResource('1880', 'F', '', '당일');
        tooltip = this.getLanguageResource('1880', 'F', '', '당일');
        index = 0;
        break;
      case '1w':
        searchFromDate = utcNow.addDays(-7);
        content = this.getLanguageResource('9675', 'F', '', '1주 전');
        tooltip = this.getLanguageResource('10445', 'F', '', '1주');
        index = 1;
        break;
      case '2w':
        searchFromDate = utcNow.addDays(-14);
        content = this.getLanguageResource('9791', 'F', '', '2주 전');
        tooltip = this.getLanguageResource('10446', 'F', '', '2주');
        index = 2;
        break;
      case '1m':
        searchFromDate = utcNow.addMonths(-1);
        content = this.getLanguageResource('9676', 'F', '', '1개월 전');
        tooltip = this.getLanguageResource('12726', 'F', '', '1월');
        index = 3;
        break;
      case '3m':
        searchFromDate = utcNow.addMonths(-3);
        content = this.getLanguageResource('10713', 'F', '', '3개월 전');
        tooltip = this.getLanguageResource('12729', 'F', '', '3월');
        index = 4;
        break;
      case '6m':
        searchFromDate = utcNow.addMonths(-6);
        content = this.getLanguageResource('9792', 'F', '', '6개월 전');
        tooltip = this.getLanguageResource('12728', 'F', '', '6월');
        index = 5;
        break;
      case '1y':
        searchFromDate = utcNow.addYears(-1);
        content = this.getLanguageResource('9677', 'F', '', '1년 전');
        tooltip = this.getLanguageResource('10449', 'F', '', '1년');
        index = 6;
        break;
      case '3y':
        searchFromDate = utcNow.addYears(-3);
        content = this.getLanguageResource('9793', 'F', '', '3년 전');
        tooltip = this.getLanguageResource('12727', 'F', '', '1년');
        index = 7;
        break;
      case 'All':
        searchFromDate = null;
        searchToDate = null;
        content = this.getLanguageResource('6700', 'F', '', '전체');
        tooltip = this.getLanguageResource('6700', 'F', '', '전체');
        index = 8;
        break;
      case 'custom':
        disalbleFromToDate = false;
        searchFromDate = null;
        searchToDate = null;
        // this.set('searchCondition.disalbleFromToDate', false);
        break;
      default:
    }
    return {
      isDisable: disalbleFromToDate,
      fromDate: searchFromDate,
      toDate: searchToDate,
      content: content,
      tooltip: tooltip,
      tickIndex: index
    };
  },
  _getSelectedExaminationIds(obj) {
    let examinationIds = null;
    if(obj.field === 'checkInId') {
      examinationIds = obj.itemsSource
        .filter(i => i.checkInId === obj.eventItem.checkInId)
        .map(i => i.examination.id);
    } else {
      examinationIds = [obj.eventItem.examination.id];
    }
    return examinationIds;
  },

  _groupBy(data, prop) {
    return data.reduce((acc, obj) => {
      const key = obj[prop];
      if(!acc[key]) {
        acc[key] = [];
      }
      acc[key].push(obj);
      return acc;
    }, {});
  },

  _parseSummaryGridData(){
    const resultList = [];
    const res = this.get('specimenSummaryResult');
    res.map((d) => {
      d.displayDate = this.get('fr_I18nService').formatDate(d.checkInDateTime, 'd');
      d.displayDateTime = this.get('fr_I18nService').formatDate(d.checkInDateTime, 'G');
      d.examinationId = d.examination.id;
      d.chartDisplayResult = d.resultQuantity && d.resultQuantity.value !== null ? d.resultQuantity.value : '';
      d.checkInDateTime = d.checkInDateTime.toString();
      resultList.push(d);
    });
    const uniqExaminationList = resultList.uniqBy('examinationId');
    const uniqDateTimeList = resultList.uniqBy('checkInDateTime');

    // const grouped = this.groupBy(resultList, item => item.examinationId);
    const grouped = this._groupBy(resultList, 'examinationId');
    const groupList = [];
    uniqExaminationList.forEach((item) => {
      // groupList.push(grouped.get(item.examinationId));
      groupList.push(grouped[item.examinationId]);
    });
    // const dateTimeGrouped = this.groupBy(resultList, item => item.checkInDateTime);
    const dateTimeGrouped = this._groupBy(resultList, 'checkInDateTime');
    const dateTimeGroupList = [];
    uniqDateTimeList.forEach((item) => {
      // dateTimeGroupList.push(dateTimeGrouped.get(item.checkInDateTime));
      dateTimeGroupList.push(dateTimeGrouped[item.checkInDateTime]);
    });
    const tempArr = [];
    groupList.forEach((item) => {
      item.map((child)=> {
        // multi chart color
        child.color = '#'+Math.random().toString(16).substr(2,6);
        if(!isEmpty(child.subjectReferenceRange) && (child.subjectReferenceRange.indexOf('\n') > -1)) {
          child.subjectReferenceRangeTooltip = child.subjectReferenceRange.replace(/\n|\r\n/giu, '<br>');
        }
        const targetIndex = dateTimeGroupList.findIndex(d => d[0].checkInDateTime === child.checkInDateTime);
        const customColumn = `checkinDate${targetIndex}`;
        const targetExamination = tempArr.find(d => d.examination.id === child.examination.id);
        if(targetExamination && targetExamination.examination.id === child.examination.id) {
          tempArr.map((obj) => {
            if(obj.examination.id === child.examination.id) {
              obj[customColumn] = child;
            }
          });
        } else {
          tempArr.push({
            [customColumn]: child,
            checkInDateTime: child.checkInDateTime,
            examination: child.examination,
            checkInId: child.checkInId,
            displayResult: child.displayResult,
            specimenId: child.specimenId,
            subjectReferenceRange: child.subjectReferenceRange,
            isTextRecordNoteResult: child.isTextRecordNoteResult,
            recoredNoteId: child.recoredNoteId
          });
        }
      });
    });

    return tempArr;
  },

  _setPickersTick() {
    const ticks = emberA();
    const now = this.get('co_CommonService').getNow();
    const startMoment = moment(moment(now).format('YYYY-MM-DD'), 'YYYY-MM-DD');
    const tagetTickIndex = this.get('model.selectedTickIndex');
    ticks.addObject({ label: this.getLanguageResource('1880', 'S', '', '당일'), value: 'T', startPoint: true, tooltip: this.getLanguageResource('1880', 'F', '', '당일'), fromDate: startMoment.toDate(), toDate: startMoment.clone().add(1, 'd').toDate() });
    ticks.addObject({ label: this.getLanguageResource('10445', 'S', '', '1주'), value: '1w', tooltip: null, fromDate: null, toDate: null });
    ticks.addObject({ label: this.getLanguageResource('10446', 'S', '', '2주'), value: '2w', tooltip: null, fromDate: null, toDate: null });
    ticks.addObject({ label: this.getLanguageResource('12726', 'S', '', '1월'), value: '1m', tooltip: null, fromDate: null, toDate: null });
    ticks.addObject({ label: this.getLanguageResource('12729', 'S', '', '3월'), value: '3m', tooltip: null, fromDate: null, toDate: null });
    ticks.addObject({ label: this.getLanguageResource('12728', 'S', '', '6월'), value: '6m', tooltip: null, fromDate: null, toDate:null });
    ticks.addObject({ label: this.getLanguageResource('10449', 'S', '', '1년'), value: '1y', tooltip: null, fromDate: null, toDate: null });
    ticks.addObject({ label: this.getLanguageResource('12727', 'S', '', '1년'), value: '3y', tooltip: null, fromDate: null, toDate: null });
    ticks.addObject({ label: this.getLanguageResource('6700', 'S', '', '전체'), value: 'All', tooltip: null, fromDate: null, toDate: null });
    ticks.map((d, ind) => {
      const returnObj = this.setSearchConditionFromToDate(d.value, now);
      d.index = ind;
      d.tooltip = returnObj.tooltip;
      d.fromDate = returnObj.fromDate;
      d.toDate = returnObj.toDate;
      if(ind === tagetTickIndex) {
        d.defaultPoint = true;
      }
    });
    return ticks;
  },

  groupBy(list, keyGetter) {
    const map = new Map();
    list.forEach((item) => {
      const key = keyGetter(item);
      const collection = map.get(key);
      if (!collection) {
        map.set(key, [item]);
      } else {
        collection.push(item);
      }
    });
    return map;
  },

  // copyToClipboard(content) {
  //   const textArea = document.createElement('textarea');
  //   textArea.value = content;
  //   document.body.appendChild(textArea);
  //   textArea.focus();
  //   textArea.select();
  //   try {
  //     document.execCommand('copy');
  //   } catch (err) {
  //     console.log(err);
  //   }
  //   document.body.removeChild(textArea);
  // },

  setSliderTicksElementStyle(fromToEl) {
    let slideTickrEl = null;
    let componentEl = $(this.element);
    slideTickrEl = componentEl.find('.c-fromtopicker .slider-container .slider-tick');
    if(!isEmpty(fromToEl)) {
      slideTickrEl = $(`#${fromToEl.elementId}`).find('.slider-container .slider-tick');
    }
    if(!isEmpty(slideTickrEl) && !isEmpty(slideTickrEl[0].firstElementChild)) {
      const fristElClass = this.get('isCurrentLocaleByKr') ? {width: '20px'} : {marginLeft: '-3px'};
      $(slideTickrEl[0].firstElementChild.children).css(fristElClass);
      $(slideTickrEl[0].lastElementChild.children).css({width: '20px', marginLeft: '5px'});
    }
    componentEl = null;
    slideTickrEl= null;

  },

});