import { helper as buildHelper } from '@ember/component/helper';

export function buttonSelectedClass([selectedStr, value]) {
  return selectedStr === value ? 'btn-check mb-5 on' : 'btn-check mb-5';
}

export default buildHelper(buttonSelectedClass);
