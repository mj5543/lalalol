import { isNone } from '@ember/utils';
import { htmlSafe } from '@ember/template';
import { helper } from '@ember/component/helper';

export function specimentFilterStyleHelper(params) {
  const param0 = params[0], param1 = params[1], param2 = params[2];
  if (typeof param1 === 'string') {
    try {
      if (!isNone(param2)) {
        return htmlSafe(param0.replace(new RegExp(param1.split('').join('[, ]*'), 'giu'), param2));
      }
      const replaceHtml = param0.replace(new RegExp(param1.split('').join('[, ]*'), 'giu'), '<font style="font-weight: bold; color: #000;">$&</font>');
      // const returnHtml = htmlSafe(`<div style='font-color:#000 !important;font-size:13px;'>${replaceHtml}</div>`);
      const returnHtml = htmlSafe(`${replaceHtml}`);
      return returnHtml;
    } catch (exception) {
      // empty block
    }
  }
}

export default helper(specimentFilterStyleHelper);
