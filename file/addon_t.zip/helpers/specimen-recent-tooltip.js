import { helper as buildHelper } from '@ember/component/helper';
import { isEmpty } from '@ember/utils';

export function specimenRecentTooltip([checkinDate, remark]) {
  let comment = checkinDate;

  if(!isEmpty(remark)){
    comment = comment + '<br >' + remark;
  }
  return comment;
}

export default buildHelper(specimenRecentTooltip);
