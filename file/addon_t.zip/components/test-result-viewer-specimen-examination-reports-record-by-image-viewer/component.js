/* eslint-disable chis/avoid-memory-leak */
/* eslint-disable no-console */
import { inject as service } from '@ember/service';
import { isEmpty, isPresent } from '@ember/utils';
import { A as emberA } from '@ember/array';
import layout from './template';
import CHIS from 'framework/chis-framework';
import { observer, set } from '@ember/object';
import 'lazysizes';

export default CHIS.FR.Core.ComponentBase.extend(
  {
    layout,
    model: null,
    isImgViewerOpen: false,
    viewerItemSource: null,
    isDisabledImgViewer: true,
    recordNoteId: null,
    height: null,
    apiService: service('testresultviewer-service'),
    isRecordShowLoader: false,
    recordIdChanged: observer('recordId', function() {
      this._getImageList();
    }),

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId','test-result-viewer-specimen-examination-reports-record-by-image-viewer');

      this.setStateProperties([
        'model',
        'defaultUrl',
        'isImgViewerOpen',
        'isDisabledImgViewer',
        'heightStyle',
        'containerStyle',
        'recordId',
        'recordExportStyle',
        'selectedImage'
      ]);

      if(this.hasState()===false) {
        this.set('heightStyle', '');
        this.set('containerStyle', '');
        this.set('recordExportStyle', 'height:100%;width:100%');
      }
      const userInfoSets = this.get('co_CurrentUserService.user');
      let hospitalId = null;
      let tenantId = null;
      if(!isEmpty(userInfoSets)){
        hospitalId = userInfoSets.hospital.hospitalId;
        tenantId = userInfoSets.tenant.tenantId;
      }
      this.set('fileuploadUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'technicalServiceUrl'));
      this.set('fileUrl', this.get('fileuploadUrl')+'file/v4/'+tenantId+'/'+hospitalId+'/view');

    },
    onLoaded() {
      this._super(...arguments);
      if(!isEmpty(this.get('height'))) {
        this.set('heightStyle', `height:${this.get('height')}px;padding-top: 0px`);
      }
      this.set('recordId', this.get('recordNoteId'));
      if(isEmpty(this.get('recordeDetailStyle'))) {
        this.set('recordeDetailStyle', 'height:100%');
      }
      // this._getImageList();
    },
    didReceiveAttrs() {
      this._super(...arguments);
      this.set('recordId', this.get('recordNoteId'));
      // this._getImageList();
    },

    actions: {
      onImageViewerClick(){
        this.set('isImgViewerOpen', true);
      },

      onImageSelectionChanged(e){
        console.log(e);
      },
      onViewerLoaded(e) {
        console.log('onViewerLoaded--', e);
      },
      getHeaderSendToRecordCB() {
        return `<span class="two-tit">${this.get('recordsHeader')}</span>`;
      },
      onImageClick(item) {
        this.get('viewerItemSource').forEach(d => {
          set(d, 'isSelectItem', false);
        });
        set(item, 'isSelectItem', true);
        this.set('viewImage', item);
        this.set('viewImageItemsSource', {src: item.filePath});
      },
      onDetailViewreDoubleClcik() {
        // this.set('isImgViewerOpen', false);
      },
      onViewerOpened() {
        const viewerItemSource = this.get('viewerItemSource');
        if(isEmpty(viewerItemSource)) {
          return;
        }
        this.get('viewerItemSource').forEach((d, index) => {
          let isSelectItem = false;
          if(index === 0) {
            isSelectItem = true;
            this.set('viewImage', d);
            this.set('viewImageItemsSource', {src: d.filePath});
          }
          set(d, 'isSelectItem', isSelectItem);
        });
      },
      onViewerClosed() {
        this.set('viewImage', null);
        this.set('viewImageItemsSource', null);
      },
    },

    async _getImageList(){
      //이미지결과 조회
      try {
        this.set('isDisabledImgViewer', true);
        this.set('recordExportStyle', 'height:100%;width:100%');
        this.set('containerStyle', '');
        // this.set('isRecordShowLoader', true);
        const queryParams = {
          recordNoteId: this.get('recordNoteId')
        };
        this.set('viewerItemSource', null);
        this.set('viewImage', null);
        this.set('viewImageItemsSource', null);
        let recordDetailStyle = 'height:100%';
        const res = await this.get('apiService').getImageList(queryParams);
        if (!isEmpty(res) && !isEmpty(res.contents)){
          let detailTitle = '';
          if(isPresent(this.get('recordsHeader'))) {
            detailTitle = this.get('recordsHeader');
          }
          const fileUrl = this.get('fileUrl');
          this.set('recordExportStyle', 'height:calc(100% - 31px);width:100%');
          const imgViewers = emberA();
          res.contents.forEach((e, index) => {
            const tempArr = e.fileName.split('.');
            let isSelectItem = false;
            if(index === 0) {
              isSelectItem = true;
            }
            const imgViewer = {
              type: e.contentType,
              src: `${fileUrl}/${e.filePath}`,
              filePath: e.filePath,
              thumbnail: e.filePath,
              fileType: tempArr[1],
              fileName: e.fileName,
              title: detailTitle,
              isSelectItem: isSelectItem,
            };
            imgViewers.pushObject(imgViewer);
          });
          this.set('viewerItemSource', imgViewers);
          // this.set('viewImage', imgViewers[0]);
          // this.set('viewImageItemsSource', {src: imgViewers[0].filePath});
          this.set('selectedImage', [imgViewers[0]]);
          this.set('isDisabledImgViewer', false);
          if(!isEmpty(this.get('customStyle'))) {
            this.set('containerStyle', this.get('customStyle'));
          }
          if(this.get('isModlaView')) {
            recordDetailStyle = 'max-height:750px;';
          }
        }
        if(isEmpty(res) && this.get('isModlaView')) {
          recordDetailStyle = 'max-height:780px;';
        }
        if(!isEmpty(this.get('fileNoteLoadedCB'))) {
          this.get('fileNoteLoadedCB')();
        }
        this.set('recordeDetailStyle', recordDetailStyle);
      // this.set('isRecordShowLoader', false);
      } catch(e) {
        // this.set('isRecordShowLoader', false);
        console.log('_getImageList Error::', e);
      }
    },
  });