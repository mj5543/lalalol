/* eslint-disable no-console */
import { isEmpty } from '@ember/utils';
import EmberObject, {set} from '@ember/object';
import { A as emberA } from '@ember/array';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'testresultviewer-module/app-config';
import TestResultViewerMixin from '../../mixins/test-result-viewer-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  TestResultViewerMixin,
  {
    layout,
    model: null,
    examinationGroupCode: null,
    pathologyColumns: null,
    pathologyexaminationGridList: null,
    pathologyList: null,
    gridId: null,
    resultView: null,
    isPathologyExamDetailOpen: false,
    recordNoteTarget: null,
    isPageLoader: false,
    isShowEmpty: false,
    isListComplete: false,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId','test-result-viewer-summary-sheet-pathology-examination');

      this.setStateProperties([
        'defaultUrl',
        'examinationGroupCode',
        'pathologyColumns',
        'pathologyList',
        'pathologyexaminationGridList',
        'resultView',
        'isPathologyExamDetailOpen',
        'popupTarget'
      ]);

      if(this.hasState()===false) {
        const defaultUrl = this.get('fr_HostConfigService')
          .getEnvConfig('ServerCallConfig', 'testresultviewer') +
          `test-result-viewer/${config.version}/`;

        this.set('defaultUrl', defaultUrl);
        this.set('model',{
          patientId: null,
          selectedGridItem: null,
          selectedGridItems: null,
          selectedItem: null,
        });

        this.set('pathologyColumns', [
          { field: 'checkInDateTime', title: this.getLanguageResource('6777', 'F'), width:120, type: 'date', dataFormat: 'd' , align: 'center'},
          { field: 'pathologyNumber', title: this.getLanguageResource('2796', 'F'), align: 'center'},
          { field: 'reportedDatetime', title: this.getLanguageResource('2873', 'F'), align: 'center'},
          { field: 'classificationName', title: this.getLanguageResource('16920', 'S')},
        ]);
        this.set('pathologyList', emberA());
        this.set('resultView', EmberObject.create({
          title: null,
          recordNoteId: null,
        }));

        this.set('pathologyexaminationGridList', {selectedItem:{}, totalCount:null});
        this.set('model', {listBoxBodySite: emberA(), listBoxModality: emberA(), listBoxInterpretationPart: emberA(), listBoxExaminationGroup: emberA()});
      }
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w680');
      if(!isEmpty(this.get('co_CurrentUserService.user'))){
        this.set('userGlobalInformation', this.get('co_CurrentUserService.user'));
      }

      if(!isEmpty(this.get('co_PatientManagerService.selectedPatient'))){
        this.set('patientGlobalInformation', this.get('co_PatientManagerService.selectedPatient'));
      }
      if(!isEmpty(this.get('parameters'))) {
        console.log('pathology onLoaded---', this.get('parameters'));
        this.set('model.patientId', this.get('parameters.outbounds.patientId'));
        this.set('model.limitCount', this.get('parameters.outbounds.searchLimitCount'));
        this.set('parameters.inbounds.reloadFunction', this._pathologyExaminationList);
      }
      // this.set('model.patientId', 'a6daf6ba-2ef7-4d14-9cfc-2ad47b027f06');
      this._pathologyExaminationList();
    },

    didRender() {
      this._super(...arguments);
      this.set('popupTarget', `#${this.element.id}`);
    },

    actions: {
      onDoubleClickExmaintion(e){
        if(!isEmpty(e.item)){
          if(e.item.recordNoteId !== null){
            if(!this.get('isPathologyExamDetailOpen')){
              this.set('resultView', EmberObject.create({
                title: e.item.examinationName,
                recordNoteId: e.item.recordNoteId,
              }));
              this.set('isPathologyExamDetailOpen', true);
              this.set('recordNoteTarget', `#${e.originalSource.parentView.parentView.elementId}`);
            }
          }else{
            this.set('isPathologyExamDetailOpen', false);
          }
        }
      },

      onResultViewClosed(){
        this.set('resultView', EmberObject.create({
          title: null,
          recordNoteId: null,
        }));
      },
      // onRecordDetatilClick(item) {
      //   if(!isEmpty(item)){
      //     if(item.recordNoteId !== null){
      //       if(!this.get('isPathologyExamDetailOpen')){
      //         this.set('resultView', EmberObject.create({
      //           title: item.examinationName,
      //           recordNoteId: item.recordNoteId,
      //         }));
      //         this.set('isPathologyExamDetailOpen', true);
      //       }
      //     }else{
      //       this.set('isPathologyExamDetailOpen', false);
      //     }
      //   }
      // },
      onRecordDetatilClick(item) {
        if(this.get('resultView.recordNoteId') === item.recordNoteId && item.isRecordOpen) {
          set(item, 'isRecordOpen', false);
          return;
        }
        const pathologyList = this.get('pathologyList');
        pathologyList.forEach(data => {
          set(data, 'isRecordOpen', false);
        });
        if(item.recordNoteId !== null){
          console.log('resultView--', this.get('resultView.recordNoteId'));
          if(!item.isRecordOpen){
            this.set('resultView', EmberObject.create({
              title: item.examinationName,
              recordNoteId: item.recordNoteId,
            }));
            set(item, 'isRecordOpen', true);
          } else {
            set(item, 'isRecordOpen', false);
          }
        }
      },

      onCopyToClipboard() {
        this._getCopyContent(this.get('pathologyList'));
      }

    },

    async _pathologyExaminationList(){
      try {
        // if(isEmpty(this.get('patientGlobalInformation'))){
        //   return;
        // }
        this.set('pathologyList', emberA());
        const params = this.getPathologyExaminationParam();
        const path = this.get('defaultUrl') + 'pathology-examination-reports/search';
        this.set('isPageLoader', true);
        const res = await this.getList(path, null, params, false);
        if(!isEmpty(res)) {
          res.map(data => {
            let statusColor = '';
            if(!isEmpty(data.orderProgressStatusCode)) {
              if(data.orderProgressStatusCode === 2) {
                statusColor = '#008fb3';
              } else if(data.orderProgressStatusCode === 3) {
                statusColor = '#f67400';
              } else if(data.orderProgressStatusCode === 4 || data.orderProgressStatusCode === 5) {
                statusColor = '#a41ad2';
              }
            }
            data.statusColor = statusColor;
            data.isRecordOpen = false;
            const limitCount = this.get('parameters.outbounds.searchLimitCount') === 0 ? 5 : this.get('parameters.outbounds.searchLimitCount');
            const limitData = [];
            if(limitCount < res.length) {
              for(let i = 0; limitCount > i; i++) {
                limitData.push(res[i]);
              }
              this.set('pathologyList', limitData);
            } else {
              this.set('pathologyList', res);
            }
            this.set('parameters.inbounds.selectCount', res.length);
          });
        } else {
          this.set('isShowEmpty', true);
        }
        this.set('isListComplete', true);
        this.set('isPageLoader', false);
      } catch(e) {
        this.set('isPageLoader', false);
        this._showError(e);
        // this.showToast('error', '', this.getLanguageResource('tempkey', 'F', '', '기능검사 조회실패'));
        console.log('_pathologyExaminationList Error::: ', e);
      }

    },
    getPathologyExaminationParam(){
      // let departmentId = null;
      let orderedStaffId = null;

      // const {fromDate, toDate} = this.getSearchDate();

      // const condition = this.get('searchCondition.selectedCondition.value');

      // if(condition === "order"){
      //   orderedStaffId = this.get('userGlobalInformation.employeeId');
      // }
      // if(condition === "dept"){
      //   departmentId = this.get('userGlobalInformation.hospital.appointmentDepartmentId');
      // }
      if(this.get('parameters.outbounds.searchType') === 'Personal'){
        orderedStaffId = this.get('userGlobalInformation.employeeId');
      }
      let queryParam = {};
      const patientId = this.get('model.patientId');

      queryParam = EmberObject.create({
        patientId: patientId,
        fromDate: null,
        toDate: null,
        departmentId: null,
        orderedStaffId: orderedStaffId,
      });
      return queryParam;
    },

    getSearchDate() {
      let fromDate = null;
      let toDate = null;

      if(!isEmpty(this.get('searchCondition.fromDate')) && !isEmpty(this.get('searchCondition.toDate'))){
        fromDate = new Date(this.get('searchCondition.fromDate').getFullYear(), this.get('searchCondition.fromDate').getMonth(), this.get('searchCondition.fromDate').getDate(), 0, 0, 0).toFormatString();
        toDate = new Date(this.get('searchCondition.toDate').getFullYear(), this.get('searchCondition.toDate').getMonth(), this.get('searchCondition.toDate').getDate(), 0, 0, 0).toFormatString();
      }

      return {fromDate, toDate};

    },
    _getCopyContent(dataList) {
      let content = '';
      dataList.forEach(item => {
        let department = '';
        if(!isEmpty(item.departmentCode)) {
          department = `[${item.departmentCode}]`;
        }
        content += `${item.examinationName}\t${item.checkInDateTime}\t${item.ordererDisplayName} ${department}\r\n`;
      });
      this.copyToClipboard(content);
    }

  });