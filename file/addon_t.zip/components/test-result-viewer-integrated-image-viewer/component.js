/* eslint-disable max-lines */
/* eslint-disable no-console */
/* eslint-disable chis/require-template-forced-expression */
import $ from 'jquery';
import moment from 'moment';
import layout from './template';
import CHIS from 'framework/chis-framework';
import { isEmpty, isPresent } from '@ember/utils';
import { A as emberA } from '@ember/array';
import TestResultViewerMixin from '../../mixins/test-result-viewer-mixin';
import { set, get } from '@ember/object';
import { later } from '@ember/runloop';
import 'lazysizes';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  TestResultViewerMixin,
  {
    layout,
    isAreaChanging: false,
    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId','test-result-viewer-integrated-image-viewer');
      this.setStateProperties([
        'isDetailOpen',
      ]);

      if (!this.hasState()) {
        this.set('searchCondition', {
          selectedPeriodType:{value: null, content: null},
          fromDate: null,
          toDate: null,
          disalbleFromToDate: true,
        });
        this.set('model', {
          selectedTickIndex: null,
        });
        this.set('isDetailOpen', false);
        this.set('treeItemsSource', null);
        this.set('fileuploadUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'technicalServiceUrl'));
        const userInfoSets = this.get('co_CurrentUserService.user');
        let hospitalId = null;
        let tenantId = null;
        if(!isEmpty(userInfoSets)){
          hospitalId = userInfoSets.hospital.hospitalId;
          tenantId = userInfoSets.tenant.tenantId;
        }
        this.set('fileUrl', this.get('fileuploadUrl')+'file/v4/'+tenantId+'/'+hospitalId+'/view');
      }
      this.set('isAllChecked', true);
      this.set('isShowDetaiImage', false);
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1360');
      const selectedPatient = this.get('co_PatientManagerService.selectedPatient');
      this.set('grobalPatient', selectedPatient);
      this._getSettingInfo();
    },
    onPatientChanged(Patient) {
      this._super(...arguments);
      if(isEmpty(Patient)){
        return;
      }
      this.set('grobalPatient', Patient);
      if(this.checkPatientDataClear() === true){
        this.set('treeItemsSource', null);
        this.set('viewerItemSource', null);
        this.set('viewImage', null);
        this.set('isShowDetaiImage', false);
      } else {
        this.set('isPickerLoading', true);
        if(isEmpty(this.get('settingInfo')) && this.get('fromToPicker.fixedSlider') === false){
          this._getSettingInfo();
        } else {
          this._getDatas();
        }
      }
    },
    async _getSettingInfo() {
      try {
        const result = await this.get('co_PersonalizationService').getSettingInfo(`test-result-viewer-integrated-image-viewer`);
        if(!isEmpty(result.settingValue)) {
          this._setDefaultSetting(result);
        } else{
          this.set('searchCondition.isShowSlider', false);
          this._setPeriodType('2w');
        }
        this._getDatas();
      } catch(e) {
        this._showError(e);
      }
    },
    _setDefaultSetting(result) {
      try {
        if(!isEmpty(this.get('fromToPicker')) && this.get('fromToPicker.fixedSlider')) {
          this.set('isPickerLoading', false);
          return;
        }
        if(isEmpty(result)) {
          return;
        }
        this.set('settingInfo', result);
        this.set('settingValue', JSON.parse(get(result, 'settingValue')));
        const settingValue = JSON.parse(get(result, 'settingValue'));
        if(!isEmpty(settingValue) && !isEmpty(settingValue.conditionData)) {
          const settingOption = settingValue.conditionData[0];
          this.set('searchCondition.isShowSlider', false);
          if (this.get('patientGlobalInformation') && this.get('patientGlobalInformation.encounterClassCode') === 'I') {
            this._setPeriodType(settingOption.periodTypes.in);
          } else {
            this._setPeriodType(settingOption.periodTypes.out);
          }
        }
      } catch(e) {
        console.log('_setDefaultSetting error::', e);
      }
    },

    actions: {
      onDetailViewreDoubleClcik() {
        this.set('isShowDetaiImage', false);
        if(this.get('thumnailScrollTop') !== null) {
          this.set('isAreaChanging', true);
        }
        later(() => {
          const viewImage = $.extend(true, {}, this.get('viewImage'));
          this._setImagesOutline(viewImage);
          this.set('viewImage', null);
          this.set('viewImageItemsSource', null);
        });
      },
      onPopupClosedAction() {
        // this._setImagesOutline();
      },
      onImageClick(item) {
        if(!this.get('isShowDetaiImage')) {
          return;
        }
        this._setDetailViewImages(item);
      },
      onImageDoubleClick(item) {
        if(this.get('isShowDetaiImage')) {
          return;
        }
        let containerEl = document.getElementById(`image-list-${this.elementId}`);
        let scrollbarEl = containerEl.querySelector('.scrollbar-macosx > .scroll-element.scroll-y .scroll-bar');
        let scrollEl = containerEl.querySelector('.scroll-wrapper>.scrollbar-macosx');
        if(scrollbarEl.scrollHeight === 0) {
          this.set('thumnailScrollTop', null);
        } else {
          this.set('thumnailScrollTop', scrollEl.scrollTop);
        }
        scrollbarEl = null;
        scrollEl = null;
        containerEl = null;
        this._setDetailViewImages(item);
      },
      onArrowClick(type) {
        const detailViewImages = this.get('detailViewImages');
        if(isEmpty(detailViewImages)) {
          return;
        }
        const currentImage = $.extend(true, {}, this.get('viewImage'));
        const currentItemIndex = detailViewImages.findIndex(d => d.recordNoteId === currentImage.recordNoteId && d.index === currentImage.index);
        let targetIndex = null;
        if(type === 'left') {
          targetIndex = currentItemIndex - 1;
        } else {
          targetIndex = currentItemIndex + 1;
        }
        if(isPresent(detailViewImages[targetIndex])) {
          if(detailViewImages[targetIndex].fileType !== currentImage.fileType) {
            this.set('viewImage', null);
          }
          later(() => {
            if(this.isDestroyed || this.isDestroying) {
              return;
            }
            this._setImagesOutline(detailViewImages[targetIndex]);
            this.set('viewImage', detailViewImages[targetIndex]);
            this.set('viewImageItemsSource', {src: detailViewImages[targetIndex].filePath});
          });
        }
      },
      onTreeLoaded(e) {
        this.set('treeControl', e.source);
      },
      onTreeTextClick(item) {
        const clickItem = $.extend(true, {}, item);
        set(item, 'checked', !clickItem.checked);
        if(item.hasOwnProperty('imageReportExaminations')) {
          item.imageReportExaminations.forEach(d => {
            set(d, 'isSelectItem', false);
            set(d, 'checked', !clickItem.checked);
          });
        } else {
          set(item, 'isSelectItem', false);
        }
        this._setDisplayImages(item, clickItem.checked);
      },
      onTreeChecked(e) {
        this._setDisplayImages(e.item, false);
      },
      onTreeUnchecked(e) {
        set(e.item, 'isSelectItem', false);
        if(e.item.hasOwnProperty('imageReportExaminations')) {
          e.item.imageReportExaminations.forEach(d => {
            set(d, 'isSelectItem', false);
          });
        }
        this._setDisplayImages(e.item, true);
      },
      onFromToPickerLoaded(e) {
        this.set('fromToPicker', e.source);
      },
      onUpdateDate(e) {
        if(!isEmpty(e.source.selectedFromDate)) {
          const selectedFromDate = moment(e.source.selectedFromDate).format('YYYY-MM-DD');
          const changedItem = this.get('ticks').find(d => moment(d.fromDate).format('YYYY-MM-DD') === selectedFromDate);
          if(!isEmpty(changedItem)) {
            this.set('model.selectedTickIndex', changedItem.index);
          }
        } else {
          this.set('model.selectedTickIndex', 8);
        }
        const treeItemsSource = $.extend(true, [], this.get('treeItemsSource'));
        const preTreeItemsSource = this.get('preTreeItemsSource');
        if(isPresent(preTreeItemsSource)) {
          treeItemsSource.forEach(d => {
            const groupItem = preTreeItemsSource.find(p => p.examinationGroupCode === d.examinationGroupCode);
            if(isEmpty(groupItem)) {
              preTreeItemsSource.addObject(d);
            } else {
              d.imageReportExaminations.forEach(c => {
                preTreeItemsSource.forEach(item => {
                  if(groupItem.examinationGroupCode === item.examinationGroupCode) {
                    set(item, 'checked', d.checked);
                  }
                  const listItem = groupItem.imageReportExaminations.find(r => r.patientExaminationId === c.patientExaminationId);
                  if(isEmpty(listItem)) {
                    item.imageReportExaminations.addObject(c);
                  } else {
                    item.imageReportExaminations.forEach(g => {
                      if(listItem.patientExaminationId === g.patientExaminationId) {
                        set(g, 'checked', c.checked);
                      }
                    });
                  }
                });
              });
            }
          });
        } else {
          this.set('preTreeItemsSource', treeItemsSource);
        }
        this._getDatas();
      },
      onSearchData() {
        this.set('isAllChecked', true);
        this.set('isShowDetaiImage', false);
        this.set('preTreeItemsSource', null);
        this._getDatas();
      },
      onSettingChanged(info) {
        console.log(info);
        if(!isEmpty(this.get('fromToPicker')) && this.get('fromToPicker.fixedSlider')) {
          return;
        }
        this.set('searchCondition.isShowSlider', false);
        this.set('isPickerLoading', true);
        this._setDefaultSetting(info);
        this._getDatas();
      },
      onAllCheckToggleChanged() {
        const treeItemsSource = this.get('treeItemsSource');
        if(isEmpty(treeItemsSource)) {
          return;
        }
        const isShowDetaiImage = this.get('isShowDetaiImage');
        const isAllChecked = this.get('isAllChecked');
        for(let i = 0; i < treeItemsSource.length; i++) {
          set(treeItemsSource[i], 'checked', isAllChecked);
          treeItemsSource[i].imageReportExaminations.forEach((d, ind) => {
            set(d, 'checked', isAllChecked);
            if(!isAllChecked) {
              set(d, 'isSelectItem', false);
            } else if(isShowDetaiImage && isAllChecked && i === 0 && ind === 0) {
              set(d, 'isSelectItem', true);
              set(this.get('treeControl'), 'selectedItem', d);
            }
          });
        }
        if(!isAllChecked) {
          this.set('viewImage', null);
          this.set('viewImageItemsSource', null);
          // this.set('detailViewImages', null);
          set(this.get('treeControl'), 'selectedItem', null);
        }
        this.get('viewerItemSource').forEach((d, ind) => {
          if(!isAllChecked) {
            set(d, 'isSelectItem', false);
          }else if(isShowDetaiImage && isAllChecked && ind === 0) {
            set(d, 'isSelectItem', true);
            this.set('viewImage', d);
            this.set('viewImageItemsSource', {src: d.filePath});
          }
          set(d, 'isHide', !isAllChecked);
        });
        const viewerItemSource = $.extend(true, [], this.get('viewerItemSource'));
        this.set('detailViewImages', viewerItemSource.filter(d => !d.isHide));
      },
    },
    async _getDatas(){
      //통합이미지뷰어 조회
      try {
        this.set('viewerItemSource', null);
        this.set('viewImage', null);
        this.set('viewImageItemsSource', null);
        if(isEmpty(this.get('grobalPatient'))) {
          return;
        }
        this.set('isShowLoader', true);
        const searchCondition = this.get('searchCondition');
        const queryParams = {
          patientId: this.get('grobalPatient.patientId'),
          fromDate: searchCondition.fromDate,
          toDate: searchCondition.toDate
        };
        const res = await this.get('apiService').getDiagnosticReportsImages(queryParams);
        if (isPresent(res)){
          this._setViewDatas(res);
        } else {
          this.set('treeItemsSource', null);
          this.set('isShowLoader', false);
        }
      } catch(e) {
        if(this.isDestroyed || this.isDestroying) {
          return;
        }
        this.set('treeItemsSource', null);
        this.set('isShowLoader', false);
        this._showError(e);
      }
    },
    _setViewDatas(res) {
      const fileUrl = this.get('fileUrl');
      const imgViewers = emberA();
      const preTreeItemsSource = this.get('preTreeItemsSource');
      const hasBeforeItems = isPresent(preTreeItemsSource);
      let imageIndex = 0;
      res.map(d => {
        d.text = d.examinationGroupName;
        d.value = d.examinationGroupCode;
        let beforeGroupItem = null;
        let groupChecked = true;
        if(hasBeforeItems) {
          beforeGroupItem = preTreeItemsSource.find(r => r.examinationGroupCode === d.examinationGroupCode);
          if(isPresent(beforeGroupItem)) {
            groupChecked = beforeGroupItem.checked;
          }
        }
        d.checked = groupChecked;
        d.imageReportExaminations.map((c, examIndex) => {
          let listChecked = true;
          let beforeItem = null;
          if(isPresent(beforeGroupItem)) {
            beforeItem = beforeGroupItem.imageReportExaminations.find(r => r.patientExaminationId === c.patientExaminationId);
            if(isPresent(beforeItem)) {
              listChecked = beforeItem.checked;
            }
          }
          c.checked = listChecked;
          c.text = c.orderName;
          c.value = c.recordNoteId;
          c.imageGroupIndex = examIndex;
          c.imageReports.forEach(e => {
            e.isHide = !listChecked;
            const tempArr = e.fileName.split('.');
            const imgViewer = {
              index: imageIndex,
              type: e.contentType,
              src: `${fileUrl}/${e.filePath}`,
              filePath: e.filePath,
              fileName: e.fileName,
              fileType: tempArr[1],
              title: this.get('fr_I18nService').formatDate(c.executeDateTime, 'g'),
              tooltip: c.orderName,
              recordNoteId: c.recordNoteId,
              examinationGroupCode: d.examinationGroupCode,
              imageGroupIndex: examIndex,
              isSelectItem: false,
              isHide: !listChecked,
              id: `image-item-${imageIndex}`,
            };
            imgViewers.pushObject(imgViewer);
            imageIndex++;
          });
        });
      });
      this.set('treeItemsSource', res);
      this.set('viewerItemSource', imgViewers);
      const viewerItemSource = $.extend(true, [], imgViewers);
      this.set('detailViewImages', viewerItemSource.filter(d => !d.isHide));
      later(() => {
        if(this.isDestroyed || this.isDestroying) {
          return;
        }
        this.get('treeControl').expandAll();
        this.set('isShowLoader', false);
      });
    },
    _setDisplayImages(item, isUnchecked) {
      const viewerItems = this.get('viewerItemSource');
      if(isEmpty(viewerItems)) {
        return;
      }
      const isGroup = isPresent(item.examinationGroupName);
      viewerItems.forEach(d => {
        if((isGroup && d.examinationGroupCode === item.examinationGroupCode)
        || (!isGroup && d.recordNoteId === item.recordNoteId && d.imageGroupIndex === item.imageGroupIndex)) {
          set(d, 'isHide', isUnchecked);
          if(isUnchecked && d.isSelectItem) {
            this.set('viewImage', null);
            this.set('viewImageItemsSource', null);
            set(d, 'isSelectItem', false);
          }
        }
      });
      const viewerItemSource = $.extend(true, [], this.get('viewerItemSource'));
      this.set('detailViewImages', viewerItemSource.filter(d => !d.isHide));
    },
    _setDetailViewImages(item) {
      const viewerItemSource = $.extend(true, [], this.get('viewerItemSource'));
      this.set('detailViewImages', viewerItemSource.filter(d => !d.isHide));
      // this.set('isDetailOpen', true);
      this.set('isShowDetaiImage', true);
      later(() => {
        if(this.isDestroyed || this.isDestroying) {
          return;
        }
        this._setImagesOutline(item);
        this.set('viewImage', item);
        this.set('viewImageItemsSource', {src: item.filePath});
      });
    },
    _setImagesOutline(item) {
      let seletedImageId = null;
      let selectedItem = null;
      this.get('viewerItemSource').forEach(d => {
        let isSelectItem = false;
        if(d.recordNoteId === item.recordNoteId && d.index === item.index) {
          isSelectItem = true;
          seletedImageId = d.id;
          selectedItem = d;
        }
        set(d, 'isSelectItem', isSelectItem);
      });
      if(isPresent(selectedItem)) {
        const treeItemsSource = this.get('treeItemsSource');
        treeItemsSource.forEach(treeItem => {
          let isGroupSelected = false;
          if(treeItem.examinationGroupCode === selectedItem.examinationGroupCode) {
            isGroupSelected = true;
          }
          set(treeItem, 'isSelected', isGroupSelected);
          treeItem.imageReportExaminations.forEach(d => {
            let isSelectedListItem = false;
            if(d.recordNoteId === selectedItem.recordNoteId && d.imageGroupIndex === selectedItem.imageGroupIndex) {
              isSelectedListItem = true;
              set(this.get('treeControl'), 'selectedItem', d);
            }
            set(d, 'isSelectItem', isSelectedListItem);
          });
        });
      }
      this._setScrollPosition(seletedImageId);
    },
    _setScrollPosition(seletedImageId) {
      let containerEl = document.getElementById(`image-list-${this.elementId}`);
      let targetEl = containerEl.querySelector(`#${seletedImageId}`);
      if(targetEl) {
        let scrollEl = containerEl.querySelector('.scroll-wrapper>.scrollbar-macosx');
        if(this.get('isShowDetaiImage')) {
          targetEl.scrollIntoView({block: "nearest"});
          const rect = targetEl.getBoundingClientRect();
          if(rect.top > 800) {
            scrollEl.scrollTop += 60;
          } else if(rect.top <= 147) {
            scrollEl.scrollTop -= 60;
          }
        } else if(this.get('thumnailScrollTop') !== null){
          scrollEl.scrollTop = this.get('thumnailScrollTop');
          later(() => {
            this.set('isAreaChanging', false);
          });
        }
        scrollEl = null;
      }
      targetEl = null;
      containerEl = null;
    },
    _setPeriodType(item){
      const periodConditions = this.setSearchConditionFromToDate(item);
      this.set('model.selectedTickIndex', periodConditions.tickIndex);
      // if(isEmpty(this.get('model.selectedTickIndex'))) {
      //   this.set('model.selectedTickIndex', periodConditions.tickIndex);
      // }
      const ticks = this._setPickersTick();
      this.set('ticks', ticks);
      this.set('searchCondition.disalbleFromToDate', periodConditions.isDisable);
      this.set('searchCondition.fromDate', periodConditions.fromDate);
      this.set('searchCondition.toDate', periodConditions.toDate);
      later(this, function() {
        this.setSliderTicksElementStyle(this.get('fromToPicker'));
      });
    },

  });