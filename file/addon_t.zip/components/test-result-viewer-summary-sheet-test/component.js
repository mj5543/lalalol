/* eslint-disable no-console */
import layout from './template';

import CHIS from 'framework/chis-framework';

export default CHIS.FR.Core.ComponentBase.extend({
  layout,
  model: null,

  onPropertyInit() {
    this._super(...arguments);
    this.set('viewId','test-result-viewer-summary-sheet-test');
    this.setStateProperties([
      'model'
    ]);

    if (this.hasState()===false) {
      this.set('model', {
        parameters: {
          outbounds: {
            // patientId: 'a6daf6ba-2ef7-4d14-9cfc-2ad47b027f06',
            patientId: '6502031a-2849-4fba-b502-b496eb71ad52',
            registrationActorId: null,
            searchType: null,
            searchLimitCount: 5,
            element: [
              {
                id: null,
                code: null
              }
            ]
          },
          inbounds: {
            selectCount: null,
            reloadeFunction: null
          },
          arguments: {
            viewerParameter: {partialType: 'Functional'},
            commons: null
          },
        }
      });
    }
  },

  onLoaded() {
    this._super(...arguments);
    this.set('menuClass', 'w680');
  },

  didInsertElement(){
    this._super(...arguments);
  },

  didRender() {
    this._super(...arguments);
  },

  didUpdateAttrs() {
    this._super(...arguments);
  },

  willDestroyElement() {
    this._super(...arguments);
    console.log('willDestroyElement()');
  },

  actions: {

  },


});
