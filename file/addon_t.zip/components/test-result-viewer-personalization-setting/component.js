/* eslint-disable chis/avoid-memory-leak */
/* eslint-disable no-console */
import $ from 'jquery';
import { inject as service } from '@ember/service';
import { isEmpty } from '@ember/utils';
import layout from './template';
import CHIS from 'framework/chis-framework';

export default CHIS.FR.Core.ComponentBase.extend(
  CHIS.FR.CrossCutting.ServerCallMixin,
  {
    layout,
    model: null,
    settingInfo: null,
    settingResult: null,
    selectedDateType: null,
    isSettingOpen: false,
    trService: service('testresultviewer-service'),

    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId', 'test-result-viewer-personalization-setting');
      //Set Stateful properties
      this.setStateProperties([
        'inItemsSource',
        'outItemsSource',
        'specimenDateType'
      ]);
      if (this.hasState() === false) {
        this.set('model', {
          selectedInValue: null,
          selectedOutValue: null,
        });
        const periodTypes = [
          {value: '1w', content: this.getLanguageResource('9675', 'S', '', '1주 전')},
          {value: '2w', content: this.getLanguageResource('9791', 'S', '', '2주 전')},
          {value: '1m', content: this.getLanguageResource('9676', 'S', '', '1개월 전')},
          {value: '3m', content: this.getLanguageResource('10713', 'S', '', '3개월 전')},
          {value: '6m', content: this.getLanguageResource('9792', 'S', '', '6개월 전')},
          {value: '1y', content: this.getLanguageResource('9677', 'S', '', '1년 전')},
          {value: '3y', content: this.getLanguageResource('9793', 'S', '', '3년 전')},
          {value: 'All', content: this.getLanguageResource('6700', 'F', '', '전체'),},
        ];
        this.set('inItemsSource', $.extend(true, [], periodTypes));
        this.set('outItemsSource', $.extend(true, [], periodTypes));
        this.set('selectedDateType', 'CheckIn');
        this.set('model.selectedInValue', '2w');
        this.set('model.selectedOutValue', '3m');
      }
    },

    onLoaded(){
      this._super(...arguments);
      // this._getSettingInfo();
    },

    actions: {
      onOpendPopup() {
        if(!isEmpty(this.get('settingValue')) && !isEmpty(this.get('settingValue.conditionData'))) {
          const settingOption = this.get('settingValue.conditionData')[0];
          this.set('selectedDateType', settingOption.specimenDateType.selectedDateType);
          this.set('isNotReported', settingOption.specimenDateType.isNotReported);
          this.set('model.selectedInValue', settingOption.periodTypes.in);
          this.set('model.selectedOutValue', settingOption.periodTypes.out);
        }
      },
      onChangedDateTypeBySetting(){
        if(this.get('selectedDateType') !== 'CheckIn'){
          this.set('isNotReported', false);
        }
      },
      onDeleteClick() {
        this.get('deletePatientCB')(this.get('model'));
      },
      onSaveClick() {
        this._goSettingService();
      },
    },
    async _setSettingInfo() {
      try {
        const settingData = {
          conditionData: [
            {
              specimenDateType: {
                selectedDateType: this.get('selectedDateType'),
                isNotReported: this.get('isNotReported'),
              },
              periodTypes: {in: this.get('model.selectedInValue'), out: this.get('model.selectedOutValue')},
            }
          ]
        };
        let discription = '검사결과조회 설정 저장';
        let viewName = `test-result-viewer-management`;
        if(!this.get('isMain')) {
          discription = '기능검사 통합이미지뷰어';
          viewName = 'test-result-viewer-integrated-image-viewer';
        }
        await this.get('co_PersonalizationService').setSettingInfo(viewName, JSON.stringify(settingData), discription);
        this.get('trService').onShowToast('save', this.getLanguageResource('8942', 'F', null, '저장되었습니다.'), '');
      } catch(e) {
        console.log('_setSettingInfo Error::', e);
      }
    },

    async _getSettingInfo() {
      try {
        let viewName = `test-result-viewer-management`;
        if(!this.get('isMain')) {
          viewName = 'test-result-viewer-integrated-image-viewer';
        }
        const result = await this.get('co_PersonalizationService').getSettingInfo(viewName);
        this.set('settingResult', result);
      } catch(e) {
        console.log('_getSettingInfo Error::', e);
      }
    },

    async _goSettingService() {
      try {
        await this._setSettingInfo();
        await this._getSettingInfo();
        this.set('isSettingOpen', false);
        if(!isEmpty(this.get('settingResultCB'))) {
          this.get('settingResultCB')(this.get('settingResult'));
        }
      } catch(e) {
        console.log('_goSettingService Error::', e);
      }
    },
  });