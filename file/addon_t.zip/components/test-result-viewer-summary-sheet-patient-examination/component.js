/* eslint-disable no-console */
import { isEmpty } from '@ember/utils';
import EmberObject, { set } from '@ember/object';
import { A as emberA } from '@ember/array';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'testresultviewer-module/app-config';
import TestResultViewerMixin from '../../mixins/test-result-viewer-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  TestResultViewerMixin,
  {
    layout,
    model: null,
    isPageLoader: false,
    examinationGroupCode: null,
    patientexaminationGridListColumns: null,
    patientexaminationGridList: null,
    patientexaminationGridListItemsSource: null,
    radiologyFilterItem: null,
    radiologySelectedFilter:null,
    clinicFilterItem: null,
    clinicSelectedFilter: null,
    isPopupRadiologyOpen: false,
    radiofilterCount: null,
    isPopupClinicOpen: false,
    clinicfilterCount: null,
    gridId: null,
    placementTarget: null,
    isPatientExamDetailOpen: false,
    resultView: null,
    recordNoteTarget: null,
    contextMenuSource: null,
    radiologyList: null,
    isShowEmpty: false,
    isListComplete: false,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId','test-result-viewer-summary-sheet-patient-examination');

      this.setStateProperties([
        'defaultUrl',
        'examinationGroupCode',
        'patientexaminationGridListColumns',
        'patientexaminationGridListItemsSource',
        'patientexaminationGridList',
        'radiologyFilterItem',
        'radiologySelectedFilter',
        'clinicFilterItem',
        'clinicSelectedFilter',
        'placementTarget',
        'resultView',
        'isPatientExamDetailOpen',
        'radiologyList',
        'clinicList',
        'popupTarget',
        'partialType'
      ]);

      if(this.hasState()===false) {
        const defaultUrl = this.get('fr_HostConfigService')
          .getEnvConfig('ServerCallConfig', 'testresultviewer') +
          `test-result-viewer/${config.version}/`;

        this.set('defaultUrl', defaultUrl);
        this.set('model',{
          patientId: null,
          limitCount: null,
        });
      }
      this.set('resultView', EmberObject.create({
        title: null,
        recordNoteId: null,
      }));
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w680');
      if(!isEmpty(this.get('co_CurrentUserService.user'))){
        this.set('userGlobalInformation', this.get('co_CurrentUserService.user'));
      }

      if(!isEmpty(this.get('co_PatientManagerService.selectedPatient'))){
        this.set('patientGlobalInformation', this.get('co_PatientManagerService.selectedPatient'));
      }
      console.log('patient onLoaded---', this.get('parameters'));
      if(!isEmpty(this.get('parameters'))) {
        this.set('model.patientId', this.get('parameters.outbounds.patientId'));
        this.set('model.limitCount', this.get('parameters.outbounds.searchLimitCount'));
        this.set('partialType', this.get('parameters.arguments.viewerParameter.partialType'));
        this.set('parameters.inbounds.reloadFunction', this._init);
      }
      // this.set('model.patientId', 'a6daf6ba-2ef7-4d14-9cfc-2ad47b027f06');
      this._init();
    },

    didRender() {
      this._super(...arguments);
      this.set('popupTarget', `#${this.element.id}`);
    },

    actions: {
      // onRecordDetatilClick(item) {
      //   if(!isEmpty(item)){
      //     if(item.recordNoteId !== null){
      //       if(!this.get('isPatientExamDetailOpen')){
      //         this.set('resultView', EmberObject.create({
      //           title: item.examinationName,
      //           recordNoteId: item.recordNoteId,
      //         }));
      //         // this.set('recordNoteTarget', `#${item.originalSource.elementId}`);
      //         this.set('isPatientExamDetailOpen', true);
      //       }
      //     }else{
      //       this.set('isPatientExamDetailOpen', false);
      //     }
      //   }
      // },

      onRecordDetatilClick(item, type) {
        if(this.get('resultView.recordNoteId') === item.recordNoteId && item.isRecordOpen) {
          set(item, 'isRecordOpen', false);
          return;
        }
        let list = null;
        if(type === 'radiology') {
          list = this.get('radiologyList');
        } else {
          list = this.get('clinicList');
        }
        list.forEach(data => {
          set(data, 'isRecordOpen', false);
        });

        if(item.recordNoteId !== null){
          if(!item.isRecordOpen){
            this.set('resultView', EmberObject.create({
              title: item.examinationName,
              recordNoteId: item.recordNoteId,
            }));
            set(item, 'isRecordOpen', true);
          } else {
            set(item, 'isRecordOpen', false);

          }
        }
      },

      onResultViewClosed(){
        this.set('resultView', EmberObject.create({
          title: null,
          recordNoteId: null,
        }));
      },
      onCopyToClipboard(list) {
        this._getCopyContent(list);
      }
    },

    _init() {
      if(this.get('partialType') === 'Image') {
        this._patientExaminationList('DR');
      } else {
        this._patientExaminationList('Clinic');
      }
    },

    async _patientExaminationList(examinationGroupCode){
      try {
        // if(isEmpty(this.get('patientGlobalInformation'))){
        //   return;
        // }
        const params = this.getPatientExaminationParam(examinationGroupCode);
        const path = this.get('defaultUrl') + 'patient-examination-reports/search';
        this.set('isPageLoader', true);
        const result = await this.getList(path, null, params, false);
        if(!isEmpty(result)) {
          result.map(data => {
            if(!isEmpty(data.statusCode)) {
              data.statusColor = this.get('apiService').onGetPatientExamStatusColor(data.statusCode);
              data.isRecordOpen = false;
            }
          });
          const limitCount = this.get('parameters.outbounds.searchLimitCount') === 0 ? 5 : this.get('parameters.outbounds.searchLimitCount');
          const limitData = [];
          let resultList = null;
          if(limitCount < result.length) {
            for(let i = 0; limitCount > i; i++) {
              limitData.push(result[i]);
            }
            resultList = limitData;
          } else {
            resultList = result;
          }
          this.set('parameters.inbounds.selectCount', result.length);
          if(examinationGroupCode=='DR'){
            this.set('radiologyList', resultList);
            // this.set('model.radiologyCount', ' (' + result.length + ')');
          }else{
            this.set('clinicList', resultList);
            // this.set('model.clinicCount', ' (' + result.length +')');
          }
          console.log('resultList--', resultList, 'partialType::', this.get('partialType'));
        } else {
          this.set('isShowEmpty', true);
        }
        this.set('isListComplete', true);
        this.set('isPageLoader', false);
      } catch(e) {
        this.set('isPageLoader', false);
        this._showError(e);
        // if(examinationGroupCode === 'DR') {
        //   this.showToast('error', '', this.getLanguageResource('tempkey', 'F', '', '영상검사 조회실패'));
        // } else {
        //   this.showToast('error', '', this.getLanguageResource('tempkey', 'F', '', '기능검사 조회실패'));
        // }
        console.log('_patientExaminationList Error::: ', e);

      }
    },

    getPatientExaminationParam(examinationGroupCode){
      // let departmentId = null;
      let orderedStaffId = null;
      let bodysite = emberA();
      let modality = emberA();
      let interpretationPart = emberA();
      let examinationGroup = emberA();

      // const {fromDate, toDate} = this.getSearchDate();
      if(this.get('parameters.outbounds.searchType') === 'Personal'){
        orderedStaffId = this.get('userGlobalInformation.employeeId');
      }


      if(examinationGroupCode==='DR'){
        if(!isEmpty(this.get('model.radiologySelectedFilter.bodysite'))){
          bodysite = this.get('model.radiologySelectedFilter.bodysite');
        }else if(!isEmpty(this.get('model.radiologySelectedFilter.modality'))){
          modality = this.get('model.radiologySelectedFilter.modality');
        }else if(!isEmpty(this.get('model.radiologySelectedFilter.interpretationPart'))){
          interpretationPart = this.get('model.radiologySelectedFilter.interpretationPart');
        }
      }else if(examinationGroupCode==='Clinic'){
        if(!isEmpty(this.get('model.clinicSelectedFilter.examinationGroup'))){
          examinationGroup = this.get('model.clinicSelectedFilter.examinationGroup');
        }
      }
      let queryParam = {};
      queryParam = EmberObject.create({
        patientId: this.get('model.patientId'),
        fromDate: null,
        toDate: null,
        departmentId: null,
        orderedStaffId: orderedStaffId,
        examinationGroupCode: examinationGroupCode,
        anatomicalSiteCode: bodysite,
        modalityCode: modality,
        interpretationPartCode: interpretationPart,
        examinationGroup: examinationGroup,
      });
      return queryParam;
    },
    getSearchDate() {
      let fromDate = null;
      let toDate = null;

      if(!isEmpty(this.get('searchCondition.fromDate')) && !isEmpty(this.get('searchCondition.toDate'))){
        fromDate = new Date(this.get('searchCondition.fromDate').getFullYear(), this.get('searchCondition.fromDate').getMonth(), this.get('searchCondition.fromDate').getDate(), 0, 0, 0).toFormatString();
        toDate = new Date(this.get('searchCondition.toDate').getFullYear(), this.get('searchCondition.toDate').getMonth(), this.get('searchCondition.toDate').getDate(), 0, 0, 0).toFormatString();
      }

      return {fromDate, toDate};
    },

    _sendMessageInterpretation(item) {
      const parameters = {
        patientId: item.patientId,
        examinationPlanId: item.examinationPlanId,
        examinationGroupCode: item.examinationGroupCode
      };

      this.get('co_MenuManagerService').openMenu('patient-examination-report-interpretation', parameters);
      this.get('co_ContentMessageService').sendMessage('messageResultViewerInterpretation', parameters);
    },

    _getCopyContent(dataList) {
      let content = '';
      dataList.forEach(item => {
        let department = '';
        if(!isEmpty(item.departmentCode)) {
          department = `[${item.departmentCode}]`;
        }
        content += `${item.examinationName}\t${item.executeDate}\t${item.ordererDisplayName} ${department}\r\n`;
      });
      this.copyToClipboard(content);
    }
  });