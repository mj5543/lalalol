/* eslint-disable max-lines */
/* eslint-disable no-console */
import $ from 'jquery';
import EmberObject, { set, get, observer } from '@ember/object';
import { next, once, later } from '@ember/runloop';
import { A as emberA } from '@ember/array';
import { isEmpty, isPresent } from '@ember/utils';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'testresultviewer-module/app-config';
import TestResultViewerMixin from '../../mixins/test-result-viewer-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  TestResultViewerMixin,
  {
    layout,
    model: null,
    defaultUrl: null,
    searchCondition: null,
    parentSearchCondition: null,
    specimenexaminationGridListColumns: null,
    specimenexaminationGridListItemsSource: null,
    specimenSelectedFilter: null,
    specimenFilterAbnormal: null,
    filterCount: null,
    specimenDateType: null,
    specimenContext: null,
    selectedExaminationIds: null,
    patientGlobalInformation: null,
    specimenSummaryResult: null,
    isSpecimenExamSummaryOpen: false,
    specimenExamSummaryItemsSource: null,
    specimenExamSummaryColumns: null,
    selectedExaminationData: null,
    isPopupToggleDisabled: false,
    isPopupChecked: false,
    actionMode: null,
    isValidPaging: true,
    isChangedPopupCondition: null,
    specimenExamSummaryParams: null,
    summaryPopupTarget: null,
    isShowDropDownLoader: false,
    isRecordDetailOpen: false,
    isRecentRecordOpen: false,
    isGridRowChanged: false,
    activeTab: null,
    originSelectedCell: null,
    isRecentRecordDetailOpen: false,
    isShowGridLoader: false,
    isSameCell: false,
    isGridDisabled: false,
    isAllChecked: true,
    isFilterOpen: false,
    isAllCheckReadOnly: true,
    isShowDimmed: false,
    isEnterSearch: false,
    isKeywordReadOnly: false,
    originalInputVal: null,
    currentFilterVal: null,
    activeTabChanged: observer('activeTab', 'isDisplay2xMode', function() {
      once(this, '_setComponentContentsStyle');
    }),
    filterItemChanged: observer('specimenFilterItem', function() {
      if(isEmpty(this.get('specimenFilterItem')) && (isEmpty(this.get('specimenFilterAbnormal')) || this.get('specimenFilterAbnormal') !== 'All')) {
        this.set('specimenFilterAbnormal', 'All');
      }
      once(this, '_setListboxSelection');
    }),
    gridItemChanged: observer('specimenexaminationGridListItemsSource', function() {
      this._setGridItemsReset();
    }),
    isPageLoaderUpdated: observer('isPageLoader', function() {
      if(this.get('isPageLoader')) {
        this._pagingInit();
      } else {
        this.set('originalItems', this.get('specimenexaminationGridListItemsSource'));
        this._getCheckInDateLineStyle();
        next(() => {
          if(this.isDestroyed || this.isDestroying) {
            return;
          }
          this._setRowsDateLine();
          // this._setGridScrollDisplay();
          this.set('isShowDimmed', false);
        });
      }
    }),
    _setGridScrollDisplay() {
      if(!isEmpty(this.get('scrollPosition'))) {
        this.get('specimenGrid').setScrollTop(this.get('scrollPosition'));
        this.get('gridScrollbar').style.display = '';
      }
    },
    _setGridItemsReset() {
      const specimenGrid = this.get('specimenGrid');
      if(!isEmpty(specimenGrid) && isEmpty(this.get('specimenexaminationGridListItemsSource'))) {
        this._setHiddenColumns();
        this.set('originalItems', emberA());
        this.set('clickHeaderColumn', null);
        this.set('scrollPosition', null);
        this.set('selectedExaminationIds', emberA());
        specimenGrid.clearSorting();
        this.get('specimenGrid').setScrollTop(0);
        this._checkInColumnReset();
        this.setColumnsSortClass(emberA());
      }
    },

    _pagingInit() {
      this.get('specimenGrid').collapseAllDetailRow();
      this.get('specimenGrid').deselectAll();
      // this.set('gridColumns', this.setSpecimenexaminationGridColumns());
    },

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId','test-result-viewer-specimen-examination');

      this.setStateProperties([
        'model',
        'defaultUrl',
        'searchCondition',
        'parentSearchCondition',
        'specimenexaminationGridListColumns',
        'specimenexaminationGridListItemsSource',
        'specimenSelectedFilter',
        'specimenFilterAbnormal',
        'filterCount',
        'specimenDateType',
        'specimenContext',
        'selectedExaminationIds',
        'patientGlobalInformation',
        'specimenSummaryResult',
        'isSpecimenExamSummaryOpen',
        'specimenExamSummaryItemsSource',
        'selectedExaminationData',
        'isPopupToggleDisabled',
        'isPopupChecked',
        'actionMode',
        'isChangedPopupCondition',
        'gridStyles',
        'expandersRecordId',
        'expandersRecentRecordId',
        'recordExaminationId',
        'searchTextItems'
      ]);

      if(this.hasState()===false) {
        const defaultUrl = this.get('fr_HostConfigService')
          .getEnvConfig('ServerCallConfig', 'testresultviewer') +
          `test-result-viewer/${config.version}/`;

        this.set('defaultUrl', defaultUrl);
        this.set('specimenexaminationGridListItemsSource', emberA());
        this.set('model',{
          isPopupSpecimen: false,
          listBoxSpecimen: emberA(),
          selectedGridItem: null,
          selectedGridCells: null,
          searchText: null,
        });

        this.set('searchCondition', EmberObject.create({
          selectedDateType: {value: 'CheckIn', content: this.getLanguageResource('12682', 'S', '접수일별')},
          isNotReported: false,
          selectedPeriodType:{value: null, content: null},
          fromDate: null,
          toDate: null,
          disalbleFromToDate: true,
        }));

        this.set('specimenFilterAbnormal', 'All');
        this.set('specimenContext', emberA([
          EmberObject.create({ action : this.actions.searchSpecimenAll.bind(this), text : this.getLanguageResource('11047', 'S', '누적결과'), alias: 'summary', disabled : false, display : true}),
          EmberObject.create({ action : this.actions.sendToRecord.bind(this), text : this.getLanguageResource('1498', 'S', '기록으로 보내기'), alias: 'report', disabled : false, display : true}),
        ]));
      }
      this.set('gridColumns', this.get('specimenexaminationGridListColumns'));
      this.set('specimenExamSummaryItemsSource', emberA());
      this.set('isChangedPopupCondition', false);
      this.set('serchTextStyle', 'font-size:13px;font-weight:500;width:41%;');
      this.set('dropDownWidth', 380);
      this.set('searchPlaceHolder', `${this.getLanguageResource('14647', 'F','', '키워드 검색')}`);
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w680');
    },
    didReceiveAttrs() {
      this._super(...arguments);
      if(this.get('activeTabName') === 'Specimen') {
        this.set('activeTab', this.get('activeTabName'));
      }
    },
    didRender() {
      this._super(...arguments);
      this._setRowsDateLine();
      if(isPresent(this.get('gridElement'))) {
        let targetRow = this.get('gridElement').getElementsByClassName('c-gdetail');
        if(isPresent(targetRow)) {
          let gridLinEl = targetRow[0].getElementsByClassName('c-gdetail-line');
          if(isPresent(gridLinEl[0].innerText)) {
            $(targetRow).find('.scrollbar-macosx').scrollbar();
          }
          gridLinEl = null;
        }
        targetRow = null;
      }
    },
    actions: {
      // onRegDateRender(e) {
      //   const tr = e.target.closest('tr');
      //   if (tr && tr.getAttribute('data-body-row-index') !== '0') {
      //     const liner = tr.querySelector('.c-gtd-liner');
      //     if (liner) {
      //       liner.style.borderTop = '1px solid #000';
      //     }
      //   }
      // },
      onFilterCloseClick() {
        this.set('isFilterOpen', false);
        this.set('model.isPopupSpecimen', false);
      },
      onSpecimenGridLoaded(e) {
        this.set('specimenGrid', e.source);
        let gridEl = document.getElementById(e.source.elementId);
        this.set('gridElement', gridEl);
        gridEl = null;
      },
      onloadListboxSpecimen(e){
        this.set('model.listBoxSpecimen', e.source);
      },
      onGridBeforeKeyDown(e) {
        const cells = this.get('specimenGrid.selectedCells');
        let isCellsRecordOpened = false;
        if(!isEmpty(cells)) {
          cells.forEach(d => {
            if(d.item.isRecordOpen) {
              isCellsRecordOpened = true;
            }
          });
        }
        if(isCellsRecordOpened) {
          return;
        }
        if(e.originalEvent.ctrlKey && e.originalEvent.keyCode === 67 ) {
          this._getCopyContent(this.get('specimenGrid.selectedCells'));
        }
      },

      onStatusChanged(){
        this._setFilter();
      },

      onFilterPopover(){
        this._setListboxSelection();
      },

      onListboxChanged() {
        this.set('isAllChecked', false);
        this.set('isAllCheckReadOnly', false);
        this._setFilter();
        this._setListboxSelection();
      },

      onContextMenuOpen(e) {
        if(isEmpty(e.dataItem.column)) {
          set(e, 'cancel', true);
          return;
        }
        const contextItem = e.dataItem.item;
        if(isEmpty(contextItem)) {
          if(isPresent(this.get('selectedExaminationIds'))) {
            this.get('specimenGrid').deselectAll();
          }
          this._setSpecimenContextDisable(true);
          return;
        }
        this._setSpecimenContextDisable(false);
        const currentSelectedItems = this.get('model.selectedGridCells');
        if(!isEmpty(currentSelectedItems)) {
          const includeExaminationsIdItems = currentSelectedItems.filter(d => d.item.checkInId === contextItem.checkInId && d.item.examination.id === contextItem.examination.id && d.item.observationId === contextItem.observationId);
          if(isEmpty(includeExaminationsIdItems) || e.dataItem.column.field === 'checkInId') {
            this.get('specimenGrid').deselectAll();
            this.get('specimenGrid').selectCell(contextItem, e.dataItem.column);
          }
        } else {
          this.get('specimenGrid').selectCell(contextItem, e.dataItem.column);
        }
      },

      onInitFilter(){
        if (!isEmpty(this.get('model.listBoxSpecimen.selectedItems'))) {
          this.get('model.listBoxSpecimen').deselectAll();
        }
        this._setFilter();
      },
      onTogglebuttonLoaded(e) {
        this.set('toggleSource', e.source);
        this.set('filterTarget', `#${e.source.elementId}`);
      },
      onAllCheckChanged(e) {
        if(e.checked) {
          if (!isEmpty(this.get('model.listBoxSpecimen.selectedItems'))) {
            this.get('model.listBoxSpecimen').deselectAll();
          }
          this.set('isAllCheckReadOnly', true);
          this._setFilter();
        }
      },
      onFilterToggleChanged() {
        this.set('model.isPopupSpecimen', this.get('isFilterOpen'));
      },
      onChangedDateType(){
        this._getSearchCallBack();
      },

      onGridScroll(e){
        if(this.get('specimenTotalCount') === this.get('specimenexaminationGridListItemsSource.length')) {
          return;
        }
        if(e.maxTop !== 0 && Math.round(e.maxTop) <= Math.round(e.top) + 1){
          if(this.get('isValidPaging')){
            this.set('isValidPaging', false);
            this.set('isShowDimmed', true);
            if(!isEmpty(this.get('clickHeaderColumn'))) {
              // this.set('scrollPosition', e.top);
              // const scrollElements = document.getElementById(this.get('specimenGrid.elementId')).getElementsByClassName('scroll-bar');
              // for(const scroll of scrollElements) {
              //   if(scroll.clientHeight > 0) {
              //     this.set('gridScrollbar', scroll);
              //     scroll.style.display = 'none';
              //   }
              // }
              this.set('specimenexaminationGridListItemsSource', $.extend(true, [], this.get('originalItems')));
            }
            this.get('getSpecimenListPagingCB')();
          }
        }
      },
      onHeaderClick(col) {
        const gridSource = this.get('specimenGrid');
        if(isEmpty(gridSource.itemsSource)) {
          return;
        }
        this.set('clickHeaderColumn', null);
        this.set('isShowDimmed', true);
        // this.set('isGridDisabled', true);
        if(!isEmpty(gridSource.expandedDetailRowItems)) {
          gridSource.collapseAllDetailRow();
          this._changeBackGridCellStyle();
          this.get('specimenGrid').deselectAll();
        }
        if(col.field === 'checkInId') {
          if(isEmpty(col.sortClass)) {
            gridSource.clearSorting();
            this.set('originalItems', $.extend(true, [], this.get('specimenexaminationGridListItemsSource')));
            set(col, 'isSorted', true);
            set(col, 'sortClass', 'asc');
          } else if(col.sortClass === 'asc') {
            set(col, 'isSorted', true);
            set(col, 'sortClass', 'desc');
          } else if(col.sortClass === 'desc') {
            set(col, 'isSorted', false);
            set(col, 'sortClass', '');
          }
          this.set('clickHeaderColumn', col);
          this._getCheckInDateLineStyle();
        } else {
          set(gridSource, 'itemsSource', $.extend(true, [], this.get('originalItems')));
        }
      },
      onGridSortingColumnsChanged(e) {
        if(isEmpty(e.source.itemsSource)) {
          return;
        }
        this.setColumnsSortClass(e.sortingColumns);
        this._getCheckInDateLineStyle();
      },

      searchSpecimenAll(){
        this.set('summaryPopupTarget', `#${this.element.id}`);
        this.set('isSpecimenExamSummaryOpen', true);
      },

      sendToRecord(e){
        let targetData = this.get('specimenGrid.selectedCells');
        if(isEmpty(targetData)) {
          targetData = [e.dataItem];
        }
        if(!isEmpty(e.dataItem.column)) {
          this._getCopyTableContent(targetData);
        }
      },
      onGridBeforeMouseDown() {
        this.set('isSpecimenExamSummaryOpen', false);
      },
      onGridCellDoubleClick(e) {
        const relayObj = {itemsSource: e.source.itemsSource, eventItem: e.item, field: e.column.field};
        this.set('selectedExaminationIds', this._getSelectedExaminationIds(relayObj));
        this.set('isSpecimenExamSummaryOpen', true);
      },
      onGridCellClick(e) {
        this.set('isRendered', false);
        const field = e.column.field;
        const gridSource = e.source;
        const gridElement = this.get('gridElement');
        const tableRows = gridElement.getElementsByClassName('c-gtr');
        set(e.item, 'isRecordOpen', false);
        const selectedCellsItem = e.item;
        this.set('recordExaminationId', null);
        this.set('recordExaminationName', null);
        this.set('recordsHeader', null);
        // gridSource.collapseAllDetailRow();
        this._changeBackGridCellStyle();
        if(!isEmpty(selectedCellsItem)) {
          const hasRecordFiled = !isEmpty(selectedCellsItem.recoredNoteId) && field === 'displayResult';
          const hasRecentRecord = !isEmpty(selectedCellsItem.recentRecoredNoteId) && field === 'recentDisplayResult';
          const currentItemIndex = gridSource.getItemIndex(e.item);
          if(hasRecordFiled || hasRecentRecord) {
            const targetRowIndex = this._getTargetRowIndex(e, currentItemIndex, tableRows);
            if(this.get('targetRowIndex') !== targetRowIndex) {
              this.set('isRecordDetailOpen', false);
              this.set('isRecentRecordDetailOpen', false);
            }
            if(this.get('expandersRecordId') !== selectedCellsItem.recoredNoteId) {
              this.set('isRecordDetailOpen', false);
            }
            if(this.get('expandersRecentRecordId') !== selectedCellsItem.recentRecoredNoteId) {
              this.set('isRecentRecordDetailOpen', false);
            }
            if(hasRecordFiled && this.get('isRecordDetailOpen')) {
              gridSource.collapseAllDetailRow();
              this.set('isRecordDetailOpen', false);
              this.set('isSameCell', true);
              return;
            }
            if(hasRecentRecord && this.get('isRecentRecordDetailOpen')) {
              gridSource.collapseAllDetailRow();
              this.set('isRecentRecordDetailOpen', false);
              this.set('isSameCell', true);
              return;
            }
            set(e.item, 'isRecordOpen', true);
            const selectionInfo = {
              cellsItem: selectedCellsItem,
              currentItemIndex: currentItemIndex,
              tableRows: tableRows,
              targetRowIndex: targetRowIndex,
              hasRecordFiled: hasRecordFiled,
            };
            this.set('isShowGridLoader', true);
            this._setExpandDetailRow(selectionInfo);
            later(() => {
              if(this.isDestroyed || this.isDestroying) {
                return;
              }
              this._addEmptyCell(gridElement, targetRowIndex);
            });
          } else {
            this.set('targetRowIndex', null);
            this.set('isRecordDetailOpen', false);
            this.set('isRecentRecordDetailOpen', false);
            gridSource.collapseAllDetailRow();
          }
        }
      },
      onGridSelectedCell(e){
        this.set('selectedExaminationIds', emberA());
        const selectedCells = e.selectedCells;
        const detailItem = this.get('specimenGrid.expandedDetailRowItems');
        const currentCell = this.get('originSelectedCell');
        if(isEmpty(selectedCells) && !isEmpty(detailItem) && !isEmpty(currentCell)) {
          const columnIndex = this.get('gridColumns').findIndex(d => d.field === currentCell.column.field);
          this.get('specimenGrid').selectCell(currentCell.item, columnIndex);
          return;
        }
        this.set('model.selectedGridCells', selectedCells);
        if(selectedCells.length !== 1) {
          this.get('specimenexaminationGridListItemsSource').forEach(d => {
            set(d, 'isRecordOpen', false);
          });
          this.set('expandersRecordId', null);
          this.set('expandersRecentRecordId', null);
          this.set('targetRowIndex', null);
          e.source.collapseAllDetailRow();
          this._changeBackGridCellStyle();
        }
        if(!isEmpty(selectedCells)) {
          let selectedIds = null;
          selectedIds = selectedCells.map(cell => cell.item.examination.id);
          if(selectedCells.length === 1) {
            this.set('isGridRowChanged', true);
            set(selectedCells[0], 'isRecordOpen', !selectedCells[0].isRecordOpen);
            const relayObj = {itemsSource: e.source.itemsSource, eventItem: selectedCells[0].item, field: selectedCells[0].column.field};
            selectedIds = this._getSelectedExaminationIds(relayObj);
          }
          const uniqueIds = selectedIds.filter((v, i, a) => a.indexOf(v) === i);
          this.set('selectedExaminationIds', uniqueIds);
        }
      },
      onGridCopySelection(e) {
        const textAreaEl = $('#max-wormhole-container').find('textarea');
        if(!isEmpty(textAreaEl)) {
          $('#max-wormhole-container').find('textarea').remove();
        }
        set(e, 'cancel', true);
      },
      onSearchValueChanged(e) {
        // console.log('onSearchValueChanged--', e);
        if(isPresent(e.item)){
          this.get('getSpecimenSearchKeywordCB')([e.item]);
        }
      },
      onKeywordKeyDown(e) {
        if(event.keyCode === 13) {
          set(e.source, 'isOpen', false);
          if(isPresent(event.target.value)) {
            if(this.get('currentFilterVal') !== event.target.value) {
              this.set('isEnterSearch', true);
              this.set('isKeywordReadOnly', true);
              this.set('isShowDropDownLoader', true);
              this._getSearchTextItems(event.target.value);
            } else {
              this.get('getSpecimenSearchKeywordCB')(this.get('searchTextItems'));
            }
          } else {
            this.set('searchTextItems', emberA());
            this.get('getSpecimenSearchKeywordCB')();
          }
        }
        this.set('originalInputVal', event.target.value);
      },
      onKeywordFilterChanged(e) {
        if(isPresent(e.filterValue) && this.get('currentFilterVal') === e.filterValue) {
          return;
        }
        this.set('currentFilterVal', e.filterValue);
        if(isEmpty(e.filterValue)) {
          set(e.source, 'isOpen', false);
          this.set('searchTextItems', emberA());
          return;
        }
        if(this.get('originalInputVal') !== e.filterValue) {
          this._getSearchTextItems(e.filterValue);
        }
      },
      onSearchTextCleared() {
        if(isEmpty(this.get('searchTextItems'))) {
          return;
        }
        this.set('searchTextItems', emberA());
        this.get('getSpecimenSearchKeywordCB')();
      },
      onSearchFocusIn() {
        this.set('searchPlaceHolder', ' ');
      },
      onSearchFocusOut() {
        this.set('searchPlaceHolder', `${this.getLanguageResource('14647', 'F','', '키워드 검색')}`);
      },
    },

    async _getSearchTextItems(value) {
      try {
        if(isEmpty(this.get('patientGlobalInformation'))) {
          return;
        }
        const callUrl = this.get('fr_HostConfigService')
          .getEnvConfig('ServerCallConfig', 'testresultviewer') +
          `specimen-examination-report/${config.version}/`;
        this.set('searchTextItems', emberA());
        this.set('isShowDropDownLoader', true);
        const path = `${callUrl}specimen-examinations/search-keyword`;
        const params = {
          valueType: null,
          keywordValue:value
        };
        // const result = await this.getList(path, null, params, false);
        const result = await this.getList(path, params, null);
        if(!isEmpty(result)) {
          this.set('searchTextItems', result);
        }
        if(this.get('isEnterSearch')) {
          this.get('getSpecimenSearchKeywordCB')(result);
        }
        this.set('isShowDropDownLoader', false);
        this.set('isKeywordReadOnly', false);
        this.set('isEnterSearch', false);
      } catch(e) {
        console.log(e);
      }
    },
    _setSpecimenContextDisable(isDisabled) {
      set(this.get('specimenContext').findBy('alias', 'summary'), 'disabled', isDisabled);
      set(this.get('specimenContext').findBy('alias', 'report'), 'disabled', isDisabled);
    },
    _getSearchCallBack(){
      if(this.get('searchCondition.selectedDateType.value') !== 'CheckIn'){
        this.set('searchCondition.isNotReported', false);
      }
      //초기화
      this._filterInit();
      if(!isEmpty(this.get('getSpecimenListbyFilterCB'))){
        this.get('getSpecimenListbyFilterCB')('Filter');
      }
    },

    _filterInit(){
      this.set('filterCount', null);
      this.set('specimenSelectedFilter', {classificationIds: null, status: null});
    },

    _setFilter(){
      let statusList = {};
      if (!isEmpty(this.get('specimenFilterAbnormal'))) {
        statusList = EmberObject.create({
          code: this.get('specimenFilterAbnormal'),
          type: 'status'
        });
      }
      let filter = [];
      let filterCountStr = '';
      const filterSelectedItems = this.get('model.listBoxSpecimen.selectedItems');
      if (isPresent(filterSelectedItems)) {
        filter = filterSelectedItems.map(item => item.id);
        filterCountStr = `(${filter.length})`;
      }
      this.set('filterCount', filterCountStr);

      this.set('specimenSelectedFilter', {
        classificationIds: filter,
        status: statusList
      });
      if(!isEmpty(this.get('getSpecimenListbyFilterCB'))){
        this.get('getSpecimenListbyFilterCB')();
      }
    },
    _setComponentContentsStyle() {
      const specimenGrid = this.get('specimenGrid');
      if(isEmpty(specimenGrid)) {
        return;
      }
      this.set('isShowGridLoader', isPresent(this.get('specimenexaminationGridListItemsSource')));
      this._setHiddenColumns();
      this._setLayout();
      later(() => {
        if(this.isDestroyed || this.isDestroying) {
          return;
        }
        this._setCellsRowSpan();
      });
    },

    _setLayout() {
      if(!isEmpty(this.get('specimenexaminationGridListItemsSource'))) {
        const currentCells = this.get('specimenGrid.selectedCells');
        if(currentCells.length === 1) {
          this.set('originSelectedCell', currentCells[0]);
        }
      }
      if(this.get('isDisplay2xMode')) {
        this.set('gridStyles', 'width:calc(100% - 220px);float:right;');
        this.set('typeAreaStyle', 'margin-left: 220px;height:23px;');
        this.set('serchTextStyle', 'width:50%;font-size:12px;font-weight:500;');
        this.set('dropDownWidth', 620);
        this._setListboxSelection();
      } else {
        this.set('serchTextStyle', 'width:41%;font-size:12px;font-weight:500;');
        this.set('dropDownWidth', 380);
        this.set('gridStyles', '');
        this.set('typeAreaStyle', '');
      }
    },
    _getCheckInDateLineStyle() {
      if(isPresent(this.get('specimenGrid._sortingColumns'))) {
        this._setSortingItemsIndex();
      } else {
        this._setItemStylesIndex();
      }
      later(() => {
        if(this.isDestroyed || this.isDestroying) {
          return;
        }
        this.set('isShowDimmed', false);
      });
    },

    _setItemStylesIndex() {
      const gridSource = this.get('specimenGrid');
      const col = this.get('clickHeaderColumn');
      const isCheckInSorting = isPresent(col);
      let itemList = gridSource.itemsSource;
      let direction = null;
      if(isCheckInSorting) {
        direction = col.sortClass;
      }
      if(isCheckInSorting && isEmpty(direction)) {
        itemList = this.get('originalItems');
      }
      const groupList = [];
      const groupKeyList = [];
      const returnList = [];
      const dateGroupResult = [];
      if(!isEmpty(itemList)) {
        const grouped = this.groupBy(itemList, item => item.checkInId);
        const uniqList = itemList.uniqBy('checkInId');
        uniqList.forEach((item) => {
          const groupItems = grouped.get(item.checkInId);
          groupList.push(groupItems);
          groupKeyList.push({key: groupItems[0].stringDate, value: groupItems});
        });
        // 접수일 정렬일 때는 내부 바인딩이 checkInId 로 되어있으므로 보여지는 접수일로 데이터 정렬 셋팅
        if (isCheckInSorting) {
          if(direction === 'desc') {
            groupKeyList.sort(function(a, b) {
              if (a.key < b.key) {
                return -1;
              }
              if (a.key > b.key) {
                return 1;
              }
              return 0;
            });
          } else if(direction === 'asc') {
            groupKeyList.sort(function(a, b) {
              if (a.key > b.key) {
                return -1;
              }
              if (a.key < b.key) {
                return 1;
              }
              return 0;
            });
          }
        }
        groupList.forEach(items => {
          const itemSize = items.length;
          items.map((item, ind) => {
            item.itemIndx = ind;
            item.lastIndex = itemSize - 1;
            returnList.push(item);
          });
        });
        const dateGroupList = [];
        if(isCheckInSorting && !isEmpty(direction)) {
          const keyUniqList = groupKeyList.uniqBy('key');
          const dateSortList = [];
          groupKeyList.forEach(group => {
            group.value.map(item => {
              dateSortList.push(item);
            });
          });
          const keyGrouped = this._groupBy(dateSortList, 'stringDate');
          keyUniqList.forEach(d => {
            const dateGroupItems = keyGrouped[d.key];
            if(!isEmpty(dateGroupItems)) {
              const itemSize = dateGroupItems.length;
              dateGroupItems.map((obj, index) => {
                obj.dateIndex = index;
                obj.lastDateIndex = itemSize - 1;
                dateGroupResult.push(obj);
              });
            }
          });
        } else {
          const dateGrouped = this.groupBy(returnList, item => item.stringDate);
          const dateUniqList = itemList.uniqBy('stringDate');
          dateUniqList.forEach((item) => {
            dateGroupList.push(dateGrouped.get(item.stringDate));
          });
          dateGroupList.forEach(items => {
            const itemSize = items.length;
            items.map((item, ind) => {
              item.dateIndex = ind;
              item.lastDateIndex = itemSize - 1;
              dateGroupResult.push(item);
            });
          });
        }
        set(gridSource, 'itemsSource', dateGroupResult);
      }
    },
    _setSortingItemsIndex() {
      const tempDateItems = emberA();
      const tempItems = emberA();
      this.get('specimenGrid').items.map((item, index) => {
        set(item, 'lastIndex', null);
        set(item, 'lastDateIndex', null);
        if(isEmpty(tempDateItems) || (tempDateItems[index-1].stringDate !== item.stringDate)) {
          set(item, 'dateIndex', 0);
        } else if(tempDateItems[index-1].stringDate === item.stringDate) {
          set(item, 'dateIndex', tempDateItems[index-1].dateIndex+1);
        }
        tempDateItems.addObject(item);
        if(isEmpty(tempItems) || (tempItems[index-1].checkInId !== item.checkInId)) {
          set(item, 'itemIndx', 0);
        } else if(tempItems[index-1].checkInId === item.checkInId) {
          set(item, 'itemIndx', tempItems[index-1].itemIndx+1);
        }
        tempItems.addObject(item);
      });
    },
    _getTargetRowIndex(e, currentItemIndex, tableRows) {
      let targetRowIndex = currentItemIndex - e.item.itemIndx;
      if(!isEmpty(this.get('specimenGrid._sortingColumns'))) {
        const itemList = $.extend(true, emberA(), e.source.items);
        itemList.map(item => {
          item.itemIndx = null;
        });
        const indexTargetItems = [];
        for(let i = 0; i < tableRows.length; i++) {
          const itemCells = tableRows[i].getElementsByClassName('c-gtd');
          if(!isEmpty(itemCells[1].dataset) && !isEmpty(itemCells[1].dataset.bodyCellIndex) && itemCells[1].dataset.bodyCellIndex === '0') {
            const findItem = itemList[i];
            findItem.itemIndx = 0;
            indexTargetItems.push(findItem);
          }
        }
        let index;
        itemList.map(item => {
          const targetItem = indexTargetItems.find(d => d.checkInId === item.checkInId && d.examination.id === item.examination.id);
          if(!isEmpty(targetItem)) {
            index = 0;
          }
          item.itemIndx = index++;
        });
        const findIndexItem = itemList.find(d => d.checkInId === e.item.checkInId && d.examination.id === e.item.examination.id);
        targetRowIndex = currentItemIndex - findIndexItem.itemIndx;
      }
      return targetRowIndex;
    },

    _setRowsDateLine() {
      const gridComp = this.get('specimenGrid');
      if(!isEmpty(gridComp) && !isEmpty(gridComp.items)) {
        const gridRows = this.get('gridElement').getElementsByClassName('c-gtr');
        for (const row of gridRows) {
          const dataRowIndex = row.getAttribute('data-body-row-index');
          const gridItem = gridComp.items[dataRowIndex];
          let liner = row.querySelector('.c-gtd-liner');
          if(!isEmpty(gridItem) && liner) {
            if(!isEmpty(dataRowIndex) && dataRowIndex !== '0' && gridItem.dateIndex === 0) {
              liner.style.borderTop = '1.5px solid #d7dae0';
              // liner.classList.add('check-in-date-line');
            } else {
              liner.style.borderTop = '';
              // liner.classList.remove('check-in-date-line');
            }
          }
          liner = null;
        }
      }
    },

    _setHiddenColumns() {
      const targetColumns = ['reportedDateTime', 'orderDate', 'resultComment', 'orderComment'];
      const isDisplay2xMode = this.get('isDisplay2xMode');
      for(const column of this.get('gridColumns')) {
        if(targetColumns.includes(column.field)) {
          set(column, 'hidden', !isDisplay2xMode);
        } else if(column.field === 'commentText') {
          set(column, 'hidden', isDisplay2xMode);
        }
      }
    },

    _addEmptyCell(gridElement, targetRowIndex) {
      const emptyCell = `<td class="c-gtd empty-cell" style="z-index:0;">
      <div class="c-gtd-line none-right" style="overflow:visible;min-height:0px;"></div></td>`;
      let targetRow = gridElement.getElementsByClassName('c-gdetail');
      if(!isEmpty(targetRow) && isEmpty(gridElement.getElementsByClassName('empty-cell'))) {
        // $(targetRow).addClass('none');
        if((this.get('targetRowIndex') !== targetRowIndex)
        || (this.get('targetRowIndex') === targetRowIndex && this.get('isSameCell'))) {
          $(targetRow).prepend($(emptyCell));
          this.set('isSameCell', false);
        } else if(!this.get('isSameCell') && (this.get('targetRowIndex') === targetRowIndex)){
          $(targetRow).prepend($(emptyCell));
        }
        // $(targetRow).removeClass('none');
        targetRow = null;
        this.set('targetRowIndex', targetRowIndex);
      }
      later(() => {
        if(this.isDestroyed || this.isDestroying) {
          return;
        }
        this.set('isShowGridLoader', false);
        this.set('isRendered', true);
      });

    },

    _setExpandDetailRow(info) {
      // this.set('isShowGridLoader', true);
      this.get('specimenGrid').expandDetailRow(info.currentItemIndex);
      this.set('recordDate', null);
      if(info.cellsItem.statusCode.code === 'preliminary') {
        this.set('recordDate', info.cellsItem.reportedDateTime);
      }
      this.set('expandersRecordId', info.cellsItem.recoredNoteId);
      this.set('expandersRecentRecordId', info.cellsItem.recentRecoredNoteId);
      this.set('recentRecordDate', info.cellsItem.recentReportedDateTime);
      this.set('recordExaminationName', info.cellsItem.examination.abbreviation);
      this.set('recordsHeader', `${info.cellsItem.examination.abbreviation} / ${this.get('fr_I18nService').formatDate(info.cellsItem.checkInDateTime, 'g')}`);
      this.set('recordExaminationId', info.cellsItem.examination.id);
      if(info.hasRecordFiled) {
        this.set('isRecordDetailOpen', true);
        this.set('isRecentRecordDetailOpen', false);
      } else {
        this.set('isRecentRecordDetailOpen', true);
        this.set('isRecordDetailOpen', false);
      }
      const itemIndexRow = info.tableRows[info.targetRowIndex];
      const itemCells = itemIndexRow.getElementsByClassName('c-gtd');
      if(!isEmpty(itemCells[1].dataset.bodyCellIndex) && itemCells[1].dataset.bodyCellIndex === '0') {
        const currentRowSpan = itemCells[1].rowSpan;
        this.set('rowSpanCellEl', itemCells[1]);
        set(itemCells[1], 'rowSpan', currentRowSpan+1);
      }
      this.set('isGridRowChanged', false);
    },

    _setCellsRowSpan() {
      const specimenGrid = this.get('specimenGrid');
      const gridElement = this.get('gridElement');
      const gridDetail = gridElement.getElementsByClassName('c-gdetail');
      if(!isEmpty(gridDetail)) {
        const targetRowIndex = this.get('targetRowIndex');
        const tableRows = gridElement.getElementsByClassName('c-gtr');
        const itemIndexRow = tableRows[targetRowIndex];
        const itemCells = itemIndexRow.getElementsByClassName('c-gtd');
        const currentRowSpan = itemCells[1].rowSpan;
        this.set('rowSpanCellEl', itemCells[1]);
        let vaildNextItem = false;
        const targetNextItem = specimenGrid.items[targetRowIndex+1];
        if(isEmpty(targetNextItem) || (isPresent(targetNextItem) && targetNextItem.itemIndx !== 0)) {
          vaildNextItem = true;
        }
        if((specimenGrid.items[targetRowIndex].itemIndx === 0 && vaildNextItem)
        || (specimenGrid.expandedDetailRowItems.itemIndx > 0)) {
          set(itemCells[1], 'rowSpan', currentRowSpan+1);
        }
      }
      this.set('isShowGridLoader', false);
    },

    _changeBackGridCellStyle() {
      const rowSpanCellEl = this.get('rowSpanCellEl');
      if(!isEmpty(rowSpanCellEl)) {
        set(rowSpanCellEl, 'rowSpan', rowSpanCellEl.rowSpan-1);
      }
      this.set('rowSpanCellEl', null);
    },

    setColumnsSortClass(sortingColumns) {
      const allowedField = ['checkInId', 'reportedDateTime', 'orderDate', 'examination.abbreviation', 'flag.displayCode', 'subjectReferenceRange', 'commentText', 'resultComment', 'orderComment'];
      this.get('gridColumns').forEach(col => {
        if(allowedField.includes(col.field)) {
          set(col, 'isSorted', false);
          set(col, 'sortClass', '');
          if(!isEmpty(sortingColumns) && col.field === sortingColumns[0].column.field) {
            set(col, 'isSorted', true);
            set(col, 'sortClass', sortingColumns[0].direction);
          }
        }
      });
    },

    _checkInColumnReset() {
      const column = this.get('gridColumns').findBy('field', 'checkInId');
      set(column, 'isSorted', false);
      set(column, 'sortClass', '');
    },
    _setListboxSelection() {
      if(isEmpty(this.get('specimenFilterItem'))) {
        this.set('filterCount', '');
        return;
      }
      if(!isEmpty(this.get('specimenSelectedFilter.classificationIds'))){
        this.get('specimenFilterItem').forEach(function(e,index){
          if(this.get('specimenSelectedFilter.classificationIds').includes(e.id)){
            this.get('model.listBoxSpecimen').selectItem(index);
          }
        }.bind(this));
        later(() => {
          if(isPresent(this.get('model.listBoxSpecimen.selectedItems'))) {
            this.set('filterCount', '(' +this.get('model.listBoxSpecimen.selectedItems').length + ')');
          }
        });
      } else {
        this.set('isAllCheckReadOnly', true);
        this.set('isAllChecked', true);
      }
    },
    _getCellContent(cell) {
      let cellCotent = get(cell.item, cell.column.field);
      if(cell.column.field === 'checkInId') {
        cellCotent = this.get('fr_I18nService').formatDate(cell.item.checkInDateTime, 'g');
      }
      if(isEmpty(cellCotent)) {
        let emptyTab = '\t\t';
        if(cell.column.field === 'subjectReferenceRange') {
          emptyTab = '\t\t\t';
        } else if(cell.column.field === 'flag.displayCode') {
          emptyTab = '\t';
        }
        cellCotent = emptyTab;
      } else {
        cellCotent = $.trim(cellCotent);
        let contentTab = '\t';
        if(cell.column.field === 'recentDisplayResult' || (cell.column.field === 'subjectReferenceRange' && cellCotent.length < 18)) {
          contentTab = '\t\t';
        }
        if(cell.column.field === 'subjectReferenceRange' && cellCotent.length < 8) {
          contentTab = '\t\t\t';
        }
        // if(cell.column.field === 'displayResult' && !isEmpty(get(cell.item, 'resultQuantity'))) {
        if(cell.column.field === 'displayResult' && (!isNaN(Number(cellCotent)) || cellCotent.length < 9)) {
          contentTab = '\t\t';
        }
        if(cell.column.field === 'examination.abbreviation') {
          const tempTextArr = cell.item.examination.abbreviation.split('.');
          if((cell.item.examination.abbreviation.indexOf('.') < 0 && cell.item.examination.abbreviation.length > 8)
          || (tempTextArr.length > 2 && cell.item.examination.abbreviation.length >= 10)
          || (tempTextArr.length === 2 && cell.item.examination.abbreviation.length > 8)) {
            contentTab = '\t';
          } else {
            contentTab = '\t\t';
          }
        }
        cellCotent = `${cellCotent}${contentTab}`;
      }
      return cellCotent;

    },
    _getCopyContent(dataList) {
      try {
        // if(dataList.length === 1 && (dataList[0].column.field === 'displayResult' || dataList[0].column.field === 'recentDisplayResult')) {
        //   return;
        // }
        let content = '';
        let tempItem = null;
        dataList.forEach(cell => {
          if (tempItem !== cell.item) {
            tempItem = cell.item;
            if (content.length > 0) {
              content = content.substring(0, content.length - 1) + '\r\n';
            }
          }
          const cellCotent = this._getCellContent(cell);
          content += `${cellCotent.replace(/\n|\r\n/gu, ' ')}`;
        });
        content = content.substring(0, content.length - 1);
        this.copyToClipboard(content);
      } catch(e) {
        this._showError(e);
      }
    },

    _getTableHeader(uniqColIndexList) {
      let colContent = '';
      const checkInTitle = this.getLanguageResource('6776', 'S', '접수일');
      const examinationTitle = this.getLanguageResource('16920', 'S', '검사항목');
      const tableStyle = 'border: 1px solid #444444;border-collapse: collapse;';
      const borderStyle = 'border: 1px solid #444444;';
      let isFixOnly = false;
      const tableTagContent = `<table style="${tableStyle}"><thead><tr style="background:#f0f1f3;text-align:center;"><th style="width:140px;${borderStyle}">${checkInTitle}</th><th style="width:140px;${borderStyle}">${examinationTitle}</th>`;
      uniqColIndexList.forEach(col => {
        if(col.column.field !== 'checkInId' && col.column.field !== 'examination.abbreviation') {
          if(colContent.length === 0) {
            colContent = tableTagContent;
          }
          colContent += `<th style="width:${col.column.width}px;${borderStyle}">${col.column.title}</th>`;
        }
        if (uniqColIndexList.length === 1 && (col.column.field === 'checkInId' || col.column.field === 'examination.abbreviation')) {
          colContent = tableTagContent;
        }
      });
      if(colContent.length < 1) {
        isFixOnly = true;
        colContent = tableTagContent;
      }
      colContent += '</tr></thead>';
      return {
        colContent: colContent,
        isFixOnly: isFixOnly
      };
    },
    _getCopyTableContent(dataList) {
      try {
        let content = '';
        let tempItem = null;
        const uniqColIndexList = dataList.uniqBy('column.index');
        const borderStyle = 'border: 1px solid #444444;';
        let allContent = '';
        const headers = this._getTableHeader(uniqColIndexList);
        const colContent = headers.colContent;
        const uniqCellItems = dataList.uniqBy('item');
        const groupList = this.groupBy(uniqCellItems, data => data.item.checkInId);
        dataList.forEach((cell) => {
          const checkInDate = this.get('fr_I18nService').formatDate(cell.item.checkInDateTime, 'g');
          const checkInContent = `${checkInDate}<br>[${cell.item.classification.abbreviation}] [${cell.item.specimenType.abbreviation}]`;
          const groups = groupList.get(cell.item.checkInId);
          const checkInContentTag = `<td style="${borderStyle}" rowspan="${groups.length}">${checkInContent}</td>`;
          const examinationTdTag = `<td style="${borderStyle}">${cell.item.examination.abbreviation}</td>`;
          if (cell.column.field !== 'checkInId' && cell.column.field !== 'examination.abbreviation') {
            if (tempItem !== cell.item) {
              tempItem = cell.item;
              let checkInHtml = '';
              if(groups[0].item.examination.id === cell.item.examination.id) {
                checkInHtml = checkInContentTag;
              }
              if(content.length > 0) {
                content += `</tr><tr>${checkInHtml}${examinationTdTag}`;
              } else {
                content += `<tr>${checkInHtml}${examinationTdTag}`;
              }
            }
            let cellCotent = get(cell.item, cell.column.field);
            const textAlign = cell.column.align;
            cellCotent = isEmpty(cellCotent) ? '' : cellCotent;
            if(cell.column.field === 'displayResult' && !isEmpty(cell.item.recoredNoteId)) {
              cellCotent = '';
            }
            if(cell.column.field === 'recentDisplayResult' && !isEmpty(cell.item.recentRecoredNoteId)) {
              cellCotent = '';
            }
            content += `<td style="${borderStyle}text-align:${textAlign};">${cellCotent}</td>`;
          }
          if(headers.isFixOnly || (uniqColIndexList.length === 1 && (cell.column.field === 'checkInId' || cell.column.field === 'examination.abbreviation'))) {
            if (tempItem !== cell.item) {
              tempItem = cell.item;
              let checkInHtml = '';
              if(groups[0].item.examination.id === cell.item.examination.id) {
                checkInHtml = checkInContentTag;
              }
              if(content.length > 0) {
                content += `</tr><tr>${checkInHtml}${examinationTdTag}`;
              } else {
                content += `<tr>${checkInHtml}${examinationTdTag}`;
              }
            }
          }
        });
        allContent = `${colContent}`;
        allContent +=` <tbody>${content}</tr></tbody></table>`;
        this.get('co_ContentMessageService').sendMessage('D2EDITOR_SEND_CONTENTS', allContent);
      } catch(e) {
        this._showError(e);
      }
    },
    copyToClipboard(content) {
      try {
        const textArea = $('<textarea>').appendTo(`#${this.elementId}`);
        event.preventDefault();
        textArea.val(content).select();
        document.execCommand('copy');
        later(() => {
          textArea.remove();
        });
      } catch(e) {
        console.error(e);
      }
    },
  });