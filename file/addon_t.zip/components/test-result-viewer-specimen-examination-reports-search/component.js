/* eslint-disable max-lines */
/* eslint-disable chis/require-js-permitted-expression */
/* eslint-disable no-console */
/* eslint-disable no-undef */
import $ from 'jquery';
import { isEmpty, isPresent } from '@ember/utils';
import { A as emberA } from '@ember/array';
import { next, later } from '@ember/runloop';
import EmberObject, { set, get } from '@ember/object';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'testresultviewer-module/app-config';
import TestResultViewerMixin from '../../mixins/test-result-viewer-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  TestResultViewerMixin,
  {
    layout,
    model: null,
    defaultUrl: null,
    searchCondition: null,
    parentSearchCondition: null,
    selectedExaminationIds: null,
    patientGlobalInformation: null,
    specimenSummaryResult: null,
    isSpecimenExamSummaryOpen: false,
    specimenExamSummaryItemsSource: null,
    specimenExamSummaryColumns: null,
    selectedExaminationData: null,
    isPopupToggleDisabled: false,
    isPopupChecked: false,
    chartTimePointer: null,
    actionMode: null,
    isValidPaging: true,
    customHeaders: null,
    isChangedPopupCondition: null,
    specimenExamSummaryParams: null,
    patientId: null,
    periodType: null,
    specimenExaminationParam: null,
    examinationIds: null,
    //print
    printPopup:null,
    printConfig:null,
    printContent:null,
    placementTarget: null,
    attachment: null,
    targetAttachment: null,
    popupOption: null,
    cellDetailTarget: null,
    isDisabledImgViewer: true,
    verticalOffset: null,
    horizontalOffset: null,
    isPopoverFirstOpen: true,
    currentOnClassElement: null,
    isShowLoader: false,
    resultGrid: null,
    isCompleted: false,
    isSwitchChecked: true,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId','test-result-viewer-specimen-examination-reports-search');

      this.setStateProperties([
        'model',
        'defaultUrl',
        'searchCondition',
        'parentSearchCondition',
        'selectedExaminationIds',
        'patientGlobalInformation',
        'specimenSummaryResult',
        'isSpecimenExamSummaryOpen',
        'specimenExamSummaryItemsSource',
        'selectedExaminationData',
        'isPopupToggleDisabled',
        'isPopupChecked',
        'chartTimePointer',
        'actionMode',
        'customHeaders',
        'isChangedPopupCondition',
        'customPeriod',
        'fromToPicker',
        'ticks',
        'gridContext'
      ]);

      if(this.hasState()===false) {
        const defaultUrl = this.get('fr_HostConfigService')
          .getEnvConfig('ServerCallConfig', 'testresultviewer') +
          `test-result-viewer/${config.version}/`;

        this.set('defaultUrl', defaultUrl);
        if(!isEmpty(this.get('co_CurrentUserService.user'))){
          this.set('userGlobalInformation', this.get('co_CurrentUserService.user'));
        }
        if(!isEmpty(this.get('co_PatientManagerService.selectedPatient'))){
          this.set('patientGlobalInformation', this.get('co_PatientManagerService.selectedPatient'));
        }
        this.set('model',{
          isByPeriodOpen: false,
          isPopupSpecimen: false,
          listBoxSpecimen: emberA(),
          patientId: null,
          selectedGridItem: null,
          specimenDateType: null,
          selectedTickIndex: null,
          selectedExaminationIds: null,
        });

        this.set('searchCondition', EmberObject.create({
          selectedDateType: {value: 'CheckIn', content: this.getLanguageResource('12682', 'S', '접수일별')},
          isNotReported: false,
          selectedPeriodType:{value: null, content: null},
          fromDate: null,
          toDate: null,
          disalbleFromToDate: true,
          isShowSlider: false,
        }));
        this.set('customPeriod', emberA({
          fromDate: null,
          toDate: null,
        }));
        this.set('gridContext', emberA([
          EmberObject.create({ action : this.actions.sendToRecord.bind(this), text : this.getLanguageResource('1498', 'S', '기록으로 보내기'), alias: 'report', disabled : false, display : true}),
        ]));

      }
      this.set('toggleSizeLabel', 'x2');
      this.set('isSizeToggleChecked', false);
      this.set('isMinToggleChecked', false);
      this.set('isMaxToggleChecked', false);
      this.set('chartAxisViewMode', 'isSync');
      this.set('isRefresh', true);
      this.set('chartWidth', 750);
      this.set('containerSize', 'width:800px;height:760px;');
      // const ticks = this._setPickersTick();
      // this.set('ticks', $.extend(true, emberA(), ticks));
      // const customXAxis = d => {
      //   d.substring(0, 10);//this.get('fr_I18nService').formatDate(d.title, 'd')
      // };
      // this.set('customXAxisTickFormat', x => x.substring(0, 10));
      this.set('customXAxisTickFormat', x => this.get('fr_I18nService').formatDate(x, 'd'));
      this._gridReset();
      this.set('isChangedPopupCondition', false);
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w680');
      this.set('specimenDateType', this.get('searchCondition'));
      this.set('charHeight', 300);
      if (isEmpty(this.get('verticalOffset'))) {
        this.set('verticalOffset', 2);
        this.set('horizontalOffset', 0);
      }
      if (isEmpty(this.get('attachment'))) {
        this.set('attachment', 'middle center');
      }
      if (isEmpty(this.get('targetAttachment'))) {
        this.set('targetAttachment', 'middle center');
      }
      if(isEmpty(this.get('placementTarget'))) {
        this.set('placementTarget', 'body');
      }
    },
    didRender() {
      this._super(...arguments);
      if(!isEmpty(this.get('fromToPicker'))) {
        this.setSliderTicksElementStyle(this.get('fromToPicker'));
      }
      // let offsetWidth = this.element.offsetWidth;
      // this.set('chartWidth', offsetWidth);
      // offsetWidth = null;
    },
    _mousedownEvent() {
      console.log('_mousedownEvent--', event);
    },
    _mouseupEvent(event) {
      console.log('_mouseupEvent--', event);
      const copyData = $.extend([], this.get('selectedExaminationData'));
      const innerPannel = event.path.find(d => d.className === 'panel-secondary ember-view');
      if(!isEmpty(innerPannel) && !isEmpty(innerPannel.offsetHeight)) {
        this.set('selectedExaminationData', null);
        if(innerPannel.offsetHeight > 320) {
          this.set('charHeight', innerPannel.offsetHeight-20);
        } else {
          this.set('charHeight', 300);
        }
        next(() => {
          this.set('selectedExaminationData', copyData);
        });
      }
    },
    setAddEvent () {
      document.addEventListener('keydown', this._keydownEvent);
    },

    removeEvent() {
      document.removeEventListener('keydown', this._keydownEvent);
    },
    _keydownEvent() {
      if(event && event.keyCode) {
        let gridEl = document.getElementById(this.get('resultGrid.elementId'));
        if(isEmpty(gridEl)) {
          this.removeEvent();
          return;
        }
        let currentDelay = 100, repeat = true;
        let scrollTarget = gridEl.querySelector(':scope>.c-grid-body-container>.unlock>.scroll-wrapper>.scrollbar-macosx');
        let increaseValue = function() {
          if (!this.isDestroying && !this.isDestroyed && repeat) {
            if(event.keyCode === 39) {
              scrollTarget.scrollLeft += 30;
            } else if(event.keyCode === 37){
              scrollTarget.scrollLeft -= 30;
            }
            later(increaseValue, currentDelay);
            if (20 < currentDelay) {
              currentDelay -= 20;
            }
            repeat = null;
          } else {
            scrollTarget = null;
            currentDelay = null;
            increaseValue = null;
            gridEl = null;
          }
        }.bind(this);
        increaseValue();
      }
    },
    _getChartWidth(length) {
      const minWidth = 620;
      const maxWidth = 1200;
      // const defaulWidth = 750;
      let chartWidth = null;
      if(length <= 5 ) {
        chartWidth = minWidth;
      // } else if(length > 5 && length <= 10) {
      //   chartWidth = defaulWidth;
      } else if(length > 5) {
        chartWidth = maxWidth;
      }
      return chartWidth;
    },
    _setAxisMode() {
      if(this.get('isSwitchChecked')) {
        if(this.get('prop2') === 0) {
          this.set('chartAxisViewMode', 'auto');
        } else if(this.get('prop2') !== 0) {
          this.set('chartAxisViewMode', 'isSync');
        }
      }
    },
    _setRowsStyle() {
      const gridComp = this.get('resultGrid');
      const selectedItemIndex = this.get('selectedItemIndex');
      if(!isEmpty(gridComp) && !isEmpty(gridComp.items)) {
        let gridRows = this.get('gridElement').getElementsByClassName('c-gtr');
        for (const row of gridRows) {
          const dataRowIndex = row.getAttribute('data-body-row-index');
          let cellElements = row.getElementsByClassName('c-gdc');
          if(selectedItemIndex === Number(dataRowIndex)) {
            for(const cell of cellElements) {
              $(cell).addClass('cell-active');
            }
          } else {
            for(const cell of cellElements) {
              $(cell).removeClass('cell-active');
            }
          }
          cellElements = null;
        }
        gridRows = null;
      }
    },
    actions: {
      onGridScroll(e) {
        if(this.get('isRefresh') && !this.get('isSwitchChecked')) {
          this.set('chartAxisViewMode', 'auto');
          this.set('isRefresh', false);
        }
        //그리드 가로영역 블록
        let gridUnlockBlock = e.source.element.querySelector('.unlock .scroll-content');
        if (gridUnlockBlock) {
          //그리드 가로영역 넓이
          const gridWidth = gridUnlockBlock.clientWidth;
          //가로스크롤 최대값
          const scrollWidth = gridUnlockBlock.scrollWidth;
          //현재 가로스크롤 위치
          const scrollLeft = gridUnlockBlock.scrollLeft;
          //차트 콘텐츠 영역 넓이 (leftPadding: 50, rightPadding: 20)
          const chartWidth = this.get('chartWidth') - 50 - 20;
          //그리드 가로영역 대비 차트 표시영역 크기
          const selectorSize = chartWidth * gridWidth / scrollWidth;
          //가로스크롤 1픽셀 증가시 차트 이동 거리
          const pixelSize = 0 < (scrollWidth - gridWidth) ? (chartWidth - selectorSize) / (scrollWidth - gridWidth) : 0;
          //(leftPadding: 50) + (가로스크롤 현재위치 * 픽셀당 차트 이동거리)
          const selector1 = 50 + (scrollLeft * pixelSize);
          //selector 시작 위치 + 그리드 가로영역 대비 차트 표시영역 크기
          const selector2 = selector1 + selectorSize;

          this.set('prop1', selector1);
          this.set('prop2', selector2);
        }
        gridUnlockBlock = null;
      },
      onSwitchChanged(e) {
        const copyData = $.extend([], this.get('selectedExaminationData'));
        const chartWidth = this._getChartWidth(copyData.length);
        this.set('selectedExaminationData', null);
        if(e.checked || this.get('prop2') === 0) {
          if(this.get('prop2') === 0) {
            this.set('chartAxisViewMode', 'auto');
            this.set('legendPosition', 'bottom');
          } else if(this.get('prop2') !== 0 && copyData.length <= 5) {
            this.set('chartAxisViewMode', 'auto');
            this.set('legendPosition', 'bottom');
          } else if(this.get('prop2') !== 0 && copyData.length > 5) {
            this.set('chartAxisViewMode', 'isSync');
            this.set('legendPosition', 'left');
          }
        } else if(!e.checked) {
          this.set('chartAxisViewMode', 'auto');
          this.set('legendPosition', 'bottom');
        }
        if(this.get('chartWidth') <= chartWidth) {
          this.set('containerSize', `width:${chartWidth + 50}px;height:760px;`);
          this.set('chartWidth', chartWidth);
        }
        next(() => {
          if(this.isDestroyed || this.isDestroying) {
            return;
          }
          this.set('selectedExaminationData', copyData);
        });
      },
      onSplitterLoaded(e) {
        let targetEl = document.getElementById(e.source.elementId);
        if (targetEl) {
          // targetEl.addEventListener('mousedown', this._mousedownEvent);
          // targetEl.addEventListener('mouseup', this._mouseupEvent);
        }
        targetEl = null;
      },
      onSplitterUnload(e) {
        let targetEl = document.getElementById(e.source.elementId);
        if (targetEl) {
          // targetEl.removeEventListener('mousedown', this._mousedownEvent);
          // targetEl.removeEventListener('mouseup', this._mouseupEvent);
        }
        targetEl = null;
      },
      onGridLoaded(e) {
        this.set('resultGrid', e.source);
        let gridEl = document.getElementById(e.source.elementId);
        this.set('gridElement', gridEl);
        gridEl = null;
      },
      onChartMovedCB(x) {
        if(this.get('isSwitchChecked')) {
          return;
        }
        this.get('resultGrid').setScrollLeft(x);
      },
      onHtmlChange() {
        this._parseExcelData();
      },
      onGridBeforeKeyDown() {
        // if(e.originalEvent.ctrlKey && e.originalEvent.keyCode == 67 ) {
        //   this._getCopyTableContent(this.get('resultGrid.selectedItems'));
        // }
      },
      onPickerLoaded(e) {
        this.set('fromToPicker', e.source);
      },
      onPopupOpend() {
        this.set('model.patientId', this.get('patientId'));
        if(!isEmpty(this.get('specimenDateType'))) {
          this.set('model.specimenDateType', this.get('specimenDateType'));
        }
        this.set('model.selectedExaminationIds', this.get('selectedExaminationIds'));
        const periodType = isEmpty(this.get('specimenExaminationParam')) ? '3y' : this.get('periodType');
        console.log('periodType---', periodType);
        if(isEmpty(periodType)) {
          this.set('model.selectedTickIndex', 1);
          this._setPeriodType('1w');
        } else {
          // set(this.get('fromToPicker'), 'enableSlider', this.get('enableSlider'));
          this._setPeriodType(periodType);
        }
        this._summaryResult();
        this.setAddEvent();
      },
      onChangedPopupSelectedItem(e){
        this.set('selectedExaminationData', null);
        const selectedItem = e.selectedItems[0];
        this.set('actionMode', 'update');
        if (selectedItem){
          this.set('selectedExaminationData', this._getChartData(selectedItem));
        }
      },
      onGridSelectionChangedCell(e){
        //TODO  color #f9e8ea
        this.set('selectedExaminationData', null);
        this.set('actionMode', 'update');
        this.set('selectedItemIndex', null);
        const selectedCells = e.selectedCells;
        if (!isEmpty(selectedCells)){
          if(selectedCells.length === 1){
            this.set('selectedItemIndex', this.get('resultGrid').getItemIndex(e.selectedCells[0].item));
          }
          this._setRowsStyle();
          const chartDatas = this._getChartData(selectedCells.get('lastObject.item'));
          const dataColSize = this.get('specimenExamSummaryColumns.length') - 2;
          const chartWidth = this._getChartWidth(chartDatas.length);
          if(this.get('chartWidth') <= chartWidth || dataColSize <= 5) {
            this.set('containerSize', `width:${chartWidth + 50}px;height:760px;`);
            this.set('chartWidth', chartWidth);
          }
          if(chartDatas.length <= 5 || this.get('prop2') === 0) {
            this.set('chartAxisViewMode', 'auto');
          } else if(chartDatas.length > 5 && this.get('isSwitchChecked') && this.get('prop2') !== 0) {
            this.set('chartAxisViewMode', 'isSync');
          }
          if(this.get('prop2') !== 0 && this.get('prop2') > this.get('chartWidth')) {
            this.set('prop2', chartDatas.length*45);
          }
          next(() => {
            if(this.isDestroyed || this.isDestroying) {
              return;
            }
            // this.get('resultGrid').setScrollLeft(this.get('gridScrollLeft')+20);
            this.set('selectedExaminationData', chartDatas);
          });
        }
      },

      onCellClickItem(e) {
        // console.log('onCellClickItem--', e);
        const filedArr = e.column.field.split('.');
        const selectedItem = e.item;
        const targetItem = selectedItem[filedArr[0]];
        if(isEmpty(targetItem)) {
          return;
        }
        this.set('cellDetailTarget', `#${e.originalSource.elementId}`);
        if (targetItem.recoredNoteId && targetItem.isTextRecordNoteResult === true) {
          set(targetItem, 'isDetailOpen', false);
          let recordDate = null;
          if(targetItem.statusCode.code === 'preliminary') {
            recordDate = targetItem.reportedDateTime;
          }
          this.set('isSpecimenExamDetailOpen', true);
          this.set('detailView', EmberObject.create({
            title: targetItem.examination.abbreviation,
            recordNoteId: targetItem.recoredNoteId,
            examinationId: targetItem.examination.id,
            recordDate: recordDate
          }));
        }

      },
      onDetailViewClosed(){
        set(this.get('detailView'), 'title', null);
        set(this.get('detailView'), 'recordNoteId', null);
        set(this.get('detailView'), 'examinationId', null);
        set(this.get('detailView'), 'recordDate', null);
      },
      onPopupClose() {
        this.set('isCompleted', false);
        this.set('isPopupToggleDisabled', false);
        this.set('isPopupChecked', false);
        this.set('selectedExaminationData', []);
        this.set('isChangedPopupCondition', false);
        this.set('examinationIds', emberA());
        this.set('isPopoverFirstOpen', true);
        this.set('searchCondition.isShowSlider', false);
        this.set('searchCondition.fromDate', null);
        this.set('searchCondition.toDate', null);
        // this.set('selectedExaminationIds', emberA());
        this.set('model.selectedTickIndex', null);
        if(!isEmpty(this.get('model.patientId'))) {
          this.set('model.patientId', null);
        }
        this._gridReset();
        this.set('isSwitchChecked', true);
        this.set('chartAxisViewMode', 'auto');
        this.set('legendPosition', 'bottom');
        this.set('containerSize', `width:${620 + 50}px;height:760px;`);
        this.set('chartWidth', 620);
        this.removeEvent();
      },
      onPopupPrint() {
        this.sendPrintMessage();
      },
      onUpdateFromToDate(e) {
        this.set('isChangedPopupCondition', true);
        if(!isEmpty(e.source.selectedFromDate)) {
          const selectedFromDate = moment(e.source.selectedFromDate).format('YYYY-MM-DD');
          const changedItem = this.get('ticks').find(d => moment(d.fromDate).format('YYYY-MM-DD') === selectedFromDate);
          if(!isEmpty(changedItem)) {
            this.set('model.selectedTickIndex', changedItem.index);
            this.set('searchCondition.selectedTickIndex', changedItem.index);
          }
        } else {
          this.set('model.selectedTickIndex', 8);
          this.set('searchCondition.selectedTickIndex', 8);
        }
        this.set('isRefresh', true);
        // this._summaryResult();
        if(this.get('isCompleted')) {
          this._summaryResult();
        }
      },
      onRefreshClick() {
        this.set('isRefresh', true);
        this._summaryResult();
      },
      sendToRecord(){
        // this._getCopyTableContent(this.get('resultGrid.selectedItems'));
        this._getCopyTableContent(this.get('resultGrid.selectedCells'));
      },
    },

    _gridReset() {
      this.set('specimenExamSummaryColumns', [
        { field: 'examination.abbreviation', title: this.getLanguageResource('16920', 'S', '검사명'), width:100, locked: true},
        { field: 'subjectReferenceRange', title: this.getLanguageResource('10109', 'S', '참고치'), width:100, locked: true},
      ]);
      this.set('specimenExamSummaryItemsSource', emberA());
    },

    //mixin asctions function
    _periodChangedRefresh() {
      this.set('model.isByPeriodOpen', false);
      this._summaryResult();
    },

    _getChartData(item){
      const dataList = this.get('specimenSummaryResult');
      const targetData = emberA();
      const tmpData = [];
      const xAxisTicks = [];

      if (dataList && dataList.length > 0) {
        dataList.forEach(data => {
          if(data.examination && data.examination.id === item.examination.id && data.chartDisplayResult !== ''){
            targetData.pushObject(data);
          }
        });
        if(isPresent(targetData)) {
          const specimenExamSummaryColumns = this.get('specimenExamSummaryColumns');
          specimenExamSummaryColumns.forEach((d, index) => {
            if(index === 0 || index === 1) {
              return;
            }
            const titleDate = this.get('fr_I18nService').formatDate(d.title, 'd');
            const findItem = targetData.find(data => data.displayDateTime === d.title.toString());
            if(isPresent(findItem)) {
              tmpData.push(findItem);
            } else if(isEmpty(findItem)){
              const tempItem = {
                chartDisplayResult: null,
                displayDate: titleDate,
                displayDateTime: this.get('fr_I18nService').formatDate(d.title, 'G'),
                examination: targetData[0].examination,
                color: targetData[0].color,
              };
              tmpData.push(tempItem);
            }
            xAxisTicks.push(titleDate);
          });
        }
      }
      return tmpData;
    },

    _setPeriodType(item){
      try {
        //기간이 바뀌면 fromtopicker가 변경되고 onPeriodDateChanged()로 재조회가 진행
        const periodConditions = this.setSearchConditionFromToDate(item);
        const parentSearchCondition = this.get('parentSearchCondition');
        this.set('model.selectedTickIndex', periodConditions.tickIndex);
        const ticks = this._setPickersTick();
        this.set('ticks', $.extend(true, emberA(), ticks));
        this.set('searchCondition.disalbleFromToDate', periodConditions.isDisable);
        if(isPresent(parentSearchCondition)) {
          set(this.get('fromToPicker'), 'enableSlider', this.get('enableSlider'));
        } else {
          this.set('searchCondition.isShowSlider', true);
        }
        if(isPresent(parentSearchCondition) && !parentSearchCondition.enableSlider) {
          this.set('searchCondition.fromDate', parentSearchCondition.fromDate);
          this.set('searchCondition.toDate', parentSearchCondition.toDate);
        } else {
          this.set('searchCondition.fromDate', periodConditions.fromDate);
          this.set('searchCondition.toDate', periodConditions.toDate);
        }
        next(this, function() {
          if(this.isDestroyed || this.isDestroying) {
            return;
          }
          this.setSliderTicksElementStyle(this.get('fromToPicker'));
        });

        // if(item !== 'custom'){
        //   this.set('searchCondition.selectedPeriodType', {value: item, content: periodConditions.content });
        // }else{
        //   this.set('searchCondition.selectedPeriodType', {value: item, content: null });
        //   if (!this.get('isChangedPopupCondition')) {
        //     this.set('searchCondition.selectedPeriodType.value', parentSearchCondition.selectedPeriodType.value);
        //     this.set('searchCondition.selectedPeriodType.content', parentSearchCondition.selectedPeriodType.content);
        //   }
        // }
      } catch(e) {
        this._showError(e);
      }
    },

    async _summaryResult(){
      try {
        this.set('isShowLoader', true);
        this._gridReset();
        this.set('specimenSummaryResult', emberA());
        let params = {};
        if (isEmpty(this.get('specimenExaminationParam'))) {
          params = this._getDefaultParam();
        } else {
          params = this.get('specimenExaminationParam');
          delete params.specimenIds;
          let fromDate = null;
          let toDate = null;
          let searchCondition = this.get('parentSearchCondition');
          if (this.get('isChangedPopupCondition') === true) {
            searchCondition = this.get('searchCondition');
          } else {
            // this.set('searchCondition.selectedPeriodType.value', searchCondition.selectedPeriodType.value);
            // this.set('searchCondition.selectedPeriodType.content', searchCondition.selectedPeriodType.content);
            if(searchCondition.selectedTickIndex > -1) {
              this.set('searchCondition.isShowSlider', true);
            }
            this.set('searchCondition.fromDate', searchCondition.fromDate);
            this.set('searchCondition.toDate', searchCondition.toDate);
          }
          if (!isEmpty(searchCondition.fromDate) && !isEmpty(searchCondition.toDate)) {
            fromDate = this.getDateFormatString(searchCondition.fromDate);
            toDate = this.getDateFormatString(searchCondition.toDate);
          }
          if(this.get('isShowResultLinkTag') === true && fromDate === null) {
            params.fromDate = this.get('searchCondition.fromDate');
            params.toDate = this.get('searchCondition.toDate');
          } else {
            params.fromDate = fromDate;
            params.toDate = toDate;
          }

          params.examinationIds = this.get('model.selectedExaminationIds');
          params.requestRange = null;
          // return;
        }
        const path = this.get('defaultUrl') + 'specimen-examination-reports/search';
        const res = await this.getList(path, null, params, false);
        if(!isEmpty(res)) {
          // this.set('specimenSummaryResult', res.sortBy('displaySequence'));
          this.set('specimenSummaryResult', res);
          this._gridSettings();
        }
        this.set('isShowLoader', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowLoader', false);
          this._showError(e);
          console.log('_summaryResult Error::', e);
        }
      }
    },

    _getDefaultParam() {
      let periodType = 'CheckIn';
      let isNotReported = false;
      if(!isEmpty(this.get('model.specimenDateType'))) {
        periodType = this.get('model.specimenDateType.selectedDateType.value');
        isNotReported = this.get('model.specimenDateType.isNotReported');
      }
      const {fromDate, toDate} = this.getSearchDate();
      const queryParam = EmberObject.create({
        subjectTypeCode: "Patient",
        subjectId: this.get('model.patientId'),
        periodTypeCode: periodType,
        fromDate: fromDate,
        toDate: toDate,
        departmentId: null,
        orderedStaffId: null,
        isViewUnReportExamination: isNotReported,
        isTextResult: null,
        isAbnormalResult: null,
        isExcludePointOfCare: null,
        classificationIds: null,
        examinationIds: this.get('examinationIds'),
        requestRange: null,
      });

      return queryParam;
    },

    _gridSettings(){
      try {
        const popupGridData = this._parseSummaryGridData();
        this._setGridColumn();
        this.set('specimenExamSummaryItemsSource', popupGridData);
        next(() => {
          if(this.isDestroyed || this.isDestroying) {
            return;
          }
          this.set('isCompleted', true);
          this.get('resultGrid').selectCell(0, 0);
        });
      } catch(e) {
        console.log('_gridSettings error::', e);
      }
    },

    _setGridColumn() {
      const res = this.get('specimenSummaryResult');
      const uniqSpecimenList = res.uniqBy('specimenId');
      const uniqCheckInDateList = [];
      uniqSpecimenList.forEach((item) => {
        uniqCheckInDateList.push(item.checkInDateTime);
      });
      this.set('chartTimePointer', uniqCheckInDateList);
      const resultColumns = [];
      const columnWidth = 80;
      uniqCheckInDateList.forEach((date ,index) => {
        const customColumn = `checkinDate${index}`;
        // const displayDate = date.toString();
        const colummnDate = new Date(date);
        resultColumns.push({ fieldKey: customColumn, field: `${customColumn}.displayResult`, title: colummnDate, align: 'center', width: columnWidth, headerTemplateName: 'customHeaders',
          bodyTemplateName: 'result',
          // onBodyCellRender: (context) => {
          //   const cellItem = context.item;
          //   if(!isEmpty(cellItem[customColumn])) {
          //     if (cellItem[customColumn].isTextRecordNoteResult === true &&
          //       !isEmpty(cellItem[customColumn].recoredNoteId) &&
          //       displayDate === cellItem[customColumn].checkInDateTime){
          //       set(cellItem[customColumn], 'displayResult', '');
          //       const innerHtml = `<div class="c-gtd-line"><div class="c-gdt"><div class="c-gdc"><i class="icon-rc-new" style="display:inline-block;vertical-align:middle;margin-top:-3px;margin-left:3px;cursor: pointer;"}}></i></div></div></div>`;
          //       context.cellComponent.$().html(innerHtml);
          //     }
          //   }
          // },
        });
      });
      this.set('customHeaders', resultColumns);
      this.set('specimenExamSummaryColumns', [
        { field: 'examination.abbreviation', title: this.getLanguageResource('16920', 'S', '검사명'), width: 90, locked: true, bodyTemplateName: 'tooltip'},
        { field: 'subjectReferenceRange', title: this.getLanguageResource('10109', 'S', '참고치'), width: 100, locked: true, align:'center', bodyTemplateName: 'subjectReferenceRange' },
        ...resultColumns
      ]);
      const chartWidth = this._getChartWidth(resultColumns.length);
      this.set('containerSize', `width:${chartWidth + 50}px;height:760px;`);
      this.set('chartWidth', chartWidth);
    },

    sendPrintMessage(){
      const resultInfo = [];
      const popupDataList = this.get('specimenSummaryResult');
      popupDataList.forEach(item => {
        resultInfo.addObject({
          examinationAbbreviation : item.examination.name,
          subjectReferenceRange : item.subjectReferenceRange,
          checkInDateTime : item.checkInDateTime,
          displayResult : item.displayResult,
        });
      });
      const parameterField = {};
      const printContent = {};
      printContent.dataField = { "resultInfo": resultInfo };
      printContent.parameterField = parameterField;

      const printConfig = {
        'printType': 2,
        'printName': 'SpecimenExamSummary',
      };
      this.set('printPopup', true);
      this.set('printConfig', printConfig);
      this.set('printContent', printContent);
    },
    _parseExcelData() {
      const controlResultColumns = this.get('specimenExamSummaryColumns');
      const itemsSource = this.get('specimenExamSummaryItemsSource');
      const tempArr = [];

      itemsSource.forEach(datas => {
        const tempObj = {};
        controlResultColumns.forEach(column => {
          const title = column.title.toString();
          const partsField = column.field.split('.');
          tempObj[title] = null;
          let formatDate = null;
          if (partsField[0] === 'examination') {
            tempObj[title] = datas.examination.name;
          }
          if(!isEmpty(datas[partsField[0]]) && partsField[0] !== 'examination') {
            const itemsDateTime = datas[partsField[0]].checkInDateTime;
            formatDate = itemsDateTime;
            // formatDate = this.get('fr_I18nService').formatDate(new Date(itemsDateTime), this.get('headerFormatType'));
          }
          const fieldTitle = this.getLanguageResource('10011', 'S', '검사명');
          const targetObj = tempArr.find(d => d[fieldTitle] === datas.examination.name);
          if(targetObj && tempObj[fieldTitle] === datas.examination.name) {
            tempArr.map((obj) => {
              if(title === formatDate && obj[fieldTitle] === datas.examination.name) {
                obj[title] = datas[partsField[0]].displayResult;
              }
            });
          } else {
            tempArr.push(tempObj);
          }
        });
      });
      this._getExportExcel(tempArr, null);
    },
    _getExportExcel(itemList, colInfo) {
      /* make the worksheet */
      const exportItemsWS = XLSX.utils.json_to_sheet(itemList, {cellDates: true, dateNF: 'YYYY-MM-DD HH:mm:ss'});
      if (!isEmpty(colInfo)) {
        exportItemsWS['!cols'] = colInfo;
      }
      const exportHtml = XLSX.utils.sheet_to_html(exportItemsWS);
      console.log('exportHtml--', exportHtml);
      copy(exportHtml);
      /* add to workbook */
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, exportItemsWS, 'sheet1');
      const fileName = new Date(this.get('co_CommonService').getNow());
      /* generate an XLSX file */
      XLSX.writeFile(wb, `${fileName}.xlsx`);
    },
    _getCopyContent(dataList) {
      let content = '';
      dataList.forEach(item => {
        let department = '';
        if(!isEmpty(item.departmentCode)) {
          department = `[${item.departmentCode}]`;
        }
        content += `${item.examinationName}\t${item.checkInDateTime}\t${item.ordererDisplayName} ${department}\r\n`;
      });
      this.copyToClipboard(content);
    },
    _getCopyTableContent(dataList) {
      try {
        let content = '';
        let tempItem = null;
        const unigColIndexList = dataList.uniqBy('column.index');
        let colContent = '';
        const examinationTitle = this.getLanguageResource('16920', 'S', '검사항목');
        const tableStyle = 'border: 1px solid #444444;border-collapse: collapse;';
        const borderStyle = 'border: 1px solid #444444;';
        unigColIndexList.forEach(col => {
          if(col.column.field !== 'examination.abbreviation') {
            if(colContent.length === 0) {
              colContent = `<table style="${tableStyle}"><thead><tr style="background:#f0f1f3;"><th style="width:140px;${borderStyle}">${examinationTitle}</th>`;
              colContent += `<th style="width:${col.column.width}px;${borderStyle}">${col.column.title}</th>`;
            } else {
              colContent += `<th style="width:${col.column.width}px;${borderStyle}">${col.column.title}</th>`;
            }
          }
          if (unigColIndexList.length === 1 && col.column.field === 'examination.abbreviation') {
            colContent = `<table style="${tableStyle}"><thead><tr style="background:#f0f1f3;"><th style="width:140px;${borderStyle}">${examinationTitle}</th>`;
          }
        });
        colContent += '</tr></thead>';
        let allContent = '';
        dataList.forEach((cell) => {
          if (cell.column.field !== 'examination.abbreviation') {
            if (tempItem !== cell.item) {
              tempItem = cell.item;
              if(content.length > 0) {
                content += `</tr><tr><td style="${borderStyle}">${cell.item.examination.abbreviation}</td>`;
              } else {
                content += `<tr><td style="${borderStyle}">${cell.item.examination.abbreviation}</td>`;
              }
            }
            let cellCotent = '';
            const isCheckCell = cell.column.field !== 'examination.abbreviation' && cell.column.field !== 'subjectReferenceRange';
            let resultItem = cell.item;
            if(!isCheckCell) {
              cellCotent = get(cell.item, cell.column.field);
            } else {
              const cellField = cell.column.field.split('.');
              resultItem = cell.item[cellField[0]];
              if(!isEmpty(resultItem)) {
                cellCotent = get(resultItem, 'displayResult');
              }
            }
            const textAlign = cell.column.align;
            if(!isEmpty(resultItem)) {
              cellCotent = isEmpty(cellCotent) ? '' : cellCotent;
              if(isCheckCell && !isEmpty(resultItem.recoredNoteId)) {
                cellCotent = '';
              }
            }
            content += `<td style="${borderStyle}text-align:${textAlign};">${cellCotent}</td>`;
          }
          if (unigColIndexList.length === 1 && cell.column.field === 'examination.abbreviation') {
            content += `<tr><td style="${borderStyle}">${cell.item.examination.abbreviation}</td>`;
          }
        });
        allContent = `${colContent}`;
        allContent +=` <tbody>${content}</tr></tbody></table>`;
        this.get('co_ContentMessageService').sendMessage('D2EDITOR_SEND_CONTENTS', allContent);
      } catch(e) {
        this._showError(e);
      }

    },

    copyToClipboard(content) {
      const textArea = $('<textarea>').appendTo(`#${this.elementId}`);
      textArea.val(content).select();
      document.execCommand('copy');
      setTimeout(() => {
        textArea.val(content).select();
        document.execCommand('copy');
      }, 1000);
    },
  });