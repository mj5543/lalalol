/* eslint-disable complexity */
/* eslint-disable max-lines-per-function */
/* eslint-disable no-console */
import EmberObject, { set } from '@ember/object';
import { A as emberA } from '@ember/array';
import { isEmpty } from '@ember/utils';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'testresultviewer-module/app-config';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  {
    layout,
    model: null,
    defaultUrl: null,
    searchCondition: null,
    parentSearchCondition: null,
    specimenexaminationGridListColumns: null,
    specimenexaminationGridList: null,
    specimenexaminationGridListItemsSource: null,
    specimenSelectedFilter: null,
    specimenFilterAbnormal: null,
    filterCount: null,
    specimenDateType: null,
    detailView: null,
    specimenContext: null,
    specimenPaging: null,
    selectedExaminationIds: null,
    patientGlobalInformation: null,
    specimenSummaryResult: null,
    isSpecimenExamSummaryOpen: false,
    specimenExamSummaryItemsSource: null,
    specimenExamSummaryColumns: null,
    selectedExaminationData: null,
    isPopupToggleDisabled: false,
    isPopupChecked: false,
    chartTimePointer: null,
    actionMode: null,
    isValidPaging: true,
    customHeaders: null,
    isChangedPopupCondition: null,
    specimenExamSummaryParams: null,
    recordNoteTarget: null,
    summaryPopupTarget: null,
    //print
    printPopup:null,
    printConfig:null,
    printContent:null,

    isRecordDetailOpen: false,
    isRecentRecordOpen: false,
    isGridRowChanged: false,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId','test-result-viewer-specimen-examination');

      this.setStateProperties([
        'model',
        'defaultUrl',
        'searchCondition',
        'parentSearchCondition',
        'specimenexaminationGridListColumns',
        'specimenexaminationGridList',
        'specimenexaminationGridListItemsSource',
        'specimenSelectedFilter',
        'specimenFilterAbnormal',
        'specimenPaging',
        'filterCount',
        'specimenDateType',
        'specimenContext',
        'detailView',
        'selectedExaminationIds',
        'patientGlobalInformation',
        'specimenSummaryResult',
        'isSpecimenExamSummaryOpen',
        'specimenExamSummaryItemsSource',
        'selectedExaminationData',
        'isPopupToggleDisabled',
        'isPopupChecked',
        'chartTimePointer',
        'actionMode',
        'customHeaders',
        'isChangedPopupCondition',
        'gridStyles',
        'expandersRecordId',
        'expandersRecentRecordId',
      ]);

      if(this.hasState()===false) {
        const defaultUrl = this.get('fr_HostConfigService')
          .getEnvConfig('ServerCallConfig', 'testresultviewer') +
          `test-result-viewer/${config.version}/`;

        this.set('defaultUrl', defaultUrl);
        // this.set('specimenexaminationGridListColumns', [
        //   { field: 'checkInId', title: this.getLanguageResource('6776', 'S', '접수일'), width: 130, merge: true, bodyTemplateName:'regDate' },
        //   { field: 'examination.abbreviation', title: this.getLanguageResource('16920', 'S', '검사항목'), width:110, bodyTemplateName: 'textTooltip'},
        //   { field: 'displayResult', title: this.getLanguageResource('890', 'S', '결과'), align: 'center', width:85, bodyTemplateName:'detailview' },
        //   { field: 'recentDisplayResult', title: this.getLanguageResource('6034', 'S'), align: 'center', width:85, bodyTemplateName: 'prevDetailview'},
        //   { field: 'flag.displayCode', title: '참고', align: 'center', width:60, bodyTemplateName:'flagSymbol' },
        //   { field: 'subjectReferenceRange', title: this.getLanguageResource('10109', 'S', '참고치'), align: 'center', width:130, bodyTemplateName: 'textTooltip'},
        //   { field: 'commentText', title: this.getLanguageResource('3173', 'S'), align: 'center', width:80, bodyTemplateName: 'comments'}
        // ]);
        this.set('specimenexaminationGridListItemsSource', emberA());
        this.set('specimenexaminationGridList', {totalCount:null});
        this.set('model',{
          isByPeriodOpen: false,
          isPopupSpecimen: false,
          listBoxSpecimen: emberA(),
          selectedGridItem: null,
          selectedGridCells: null,
        });

        this.set('searchCondition', EmberObject.create({
          selectedDateType: {value: 'CheckIn', content: this.getLanguageResource('tempkey', 'S', '접수일별')},
          isNotReported: false,
          selectedPeriodType:{value: null, content: null},
          fromDate: null,
          toDate: null,
          disalbleFromToDate: true,
        }));

        this.set('specimenFilterAbnormal', {value:'All'});
        this.set('specimenContext', emberA([
          EmberObject.create({ action : this.actions.searchSpecimenAll.bind(this), text : this.getLanguageResource('11047', 'S', '누적결과'), alias: 'summary', disabled : false, display : true}),
          /* EmberObject.create({ action : this.actions.sendToRecord.bind(this), text : this.getLanguageResource('1498', 'S', '기록으로 보내기'), alias: 'report', disabled : true, display : true}), */
        ]));
        this.set('detailView', EmberObject.create({
          title: null,
          recordNoteId: null,
        }));
      }
      this.set('specimenTwiceSizeColumns', [
        { field: 'checkInId', title: this.getLanguageResource('6776', 'S', '접수일'), width: 140, merge: true, bodyTemplateName:'regDate' },
        { field: 'reportedDateTime', title: this.getLanguageResource('2872', 'S', '보고일'), width: 120, align: 'center', type: 'date', dataFormat: 'd', },
        { field: 'orderDate', title: this.getLanguageResource('5246', 'S', '오더일'), width: 120, align: 'center', type: 'date', dataFormat: 'd',},
        { field: 'examination.abbreviation', title: this.getLanguageResource('16920', 'S', '검사항목'), width:140, bodyTemplateName: 'textTooltip'},
        { field: 'displayResult', title: this.getLanguageResource('890', 'S', '결과'), align: 'center', width:100, bodyTemplateName:'detailview' },
        { field: 'recentDisplayResult', title: this.getLanguageResource('6034', 'S'), align: 'center', width:100, bodyTemplateName: 'prevDetailview'},
        { field: 'flag.displayCode', title: this.getLanguageResource('1579', 'S', '참고'), align: 'center', width:50, bodyTemplateName:'flagSymbol' },
        { field: 'subjectReferenceRange', title: this.getLanguageResource('10109', 'S', '참고치'), align: 'center', width:140, bodyTemplateName: 'textTooltip'},
        { title: this.getLanguageResource('906', 'S'), align: 'center', width:80, bodyTemplateName: 'resultComment'},
        { title: this.getLanguageResource('5228', 'S'), align: 'center', width:80, bodyTemplateName: 'orderComment'},
      ]);

      this.set('gridColumns', this.get('specimenexaminationGridListColumns'));
      this.set('specimenExamSummaryItemsSource', emberA());
      this.set('isChangedPopupCondition', false);
      // this._setTagList();
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w680');
      // this.set('specimenDateType', this.get('searchCondition'));
    },
    didReceiveAttrs() {
      this._super(...arguments);
      console.log('didReceiveAttrs---', this.get('specimenDateType.selectedDateType.value'));
      const gridComp = this.get('specimenGrid');
      if(!isEmpty(gridComp)) {
        if(this.get('isDisplay2xMode')) {
          this.set('gridColumns', this.get('specimenTwiceSizeColumns'));
          this.set('gridStyles', 'width:calc(100% - 220px);float:right;');
        } else {
          this.set('gridColumns', this.get('specimenexaminationGridListColumns'));
          this.set('gridStyles', '');
        }
      }
    },
    // didRender() {
    //   this._super(...arguments);
    //   console.log('didRender---');

    // },
    actions: {
      onSpecimenGridLoaded(e) {
        this.set('specimenGrid', e.source);
      },
      onloadListboxSpecimen(e){
        this.set('model.listBoxSpecimen', e.source);
      },

      onSearchByFilter(){
        this._setFilter();
        this._specimenFilterOpenChanged();
      },

      onStatusChanged(item){
        this.set('specimenFilterAbnormal.value', item.value);
      },

      onFilterPopover(){
        if(!isEmpty(this.get('specimenSelectedFilter.classificationIds'))){
          this.get('specimenFilterItem').forEach(function(e,index){
            if(this.get('specimenSelectedFilter.classificationIds').includes(e.id)){
              this.get('model.listBoxSpecimen').selectItem(index);
            }
          }.bind(this));
        }
      },

      /*       onSpecimenOpenChanged(){
        if(isEmpty(this.get('co_PatientManagerService.selectedPatient'))){
          //환자를 선택하세요.
          this.get('apiService').onDisplayMessage('warning', this.getLanguageResource('8946'), '', 'Ok', 'Ok', 0);
          return;
        }
        this._specimenFilterOpenChanged();
      }, */
      onContextMenuOpen(e) {
        const contextItem = e.dataItem.item;
        // const currentSelectedItems = this.get('specimenGrid').selectedItems;
        const currentSelectedItems = this.get('model.selectedGridCells');
        let isIncludeExaminationsId = false;
        if(!isEmpty(currentSelectedItems)) {
          currentSelectedItems.forEach(d => {
            if(d.item.checkInId === contextItem.checkInId && d.item.examination.id === contextItem.examination.id && d.item.observationId === contextItem.observationId) {
              isIncludeExaminationsId = true;
            }
          });
          if(!isIncludeExaminationsId) {
            this.get('specimenGrid').deselectAll();
            // this.get('specimenGrid').selectRow(contextItem);
            this.get('specimenGrid').selectCell(contextItem, e.dataItem.column);
          }
        }
        set(this.get('specimenContext').findBy('alias', 'summary'), 'disabled', false);
        if(isEmpty(this.get('selectedExaminationIds'))) {
          set(this.get('specimenContext').findBy('alias', 'summary'), 'disabled', true);
        }
        // this.set('recordNoteTarget', `#${e.originalSource.elementId}`);
      },
      // onDetailClick(item, col){
      //   // this.set('recordNoteTarget', `#${this.element.id}`);
      //   // const gridComp = this.get('specimenGrid');
      //   // gridComp.collapseAllDetailRow();
      //   // const targetIndex = gridComp.getItemIndex(item);
      //   // if(!isEmpty(item)){
      //   //   if(col === 'Result'){
      //   //     if(item.recoredNoteId !== null){
      //   //       this.set('isRecordOpen', true);
      //   //       this.set('isRecentRecordOpen', false);
      //   //       if(!isEmpty(item.isRecordOpen) && item.isRecordOpen) {
      //   //         set(item, 'isRecordOpen', false);
      //   //       } else if(!isEmpty(item.isRecordOpen) && !item.isRecordOpen) {
      //   //         set(item, 'isRecordOpen', true);
      //   //         gridComp.expandDetailRow(targetIndex);
      //   //       }
      //   //       if(isEmpty(item.isRecordOpen)) {
      //   //         set(item, 'isRecordOpen', true);
      //   //         gridComp.expandDetailRow(targetIndex);
      //   //       }
      //   //       // set(item, 'isDetailOpen', false);
      //   //       // this.set('isSpecimenExamDetailOpen', true);
      //   //       // this.set('detailView', EmberObject.create({
      //   //       //   title: item.examination.abbreviation,
      //   //       //   recordNoteId: item.recoredNoteId,
      //   //       // }));
      //   //     } else {
      //   //       gridComp.collapseAllDetailRow();
      //   //     }
      //   //   }
      //   //   if(col === 'Prev. Result'){
      //   //     if(item.recentRecoredNoteId !== null){
      //   //       this.set('isRecordOpen', false);
      //   //       this.set('isRecentRecordOpen', true);
      //   //       if(!isEmpty(item.isRecordOpen) && item.isRecordOpen) {
      //   //         set(item, 'isRecordOpen', false);
      //   //       } else if(!isEmpty(item.isRecordOpen) && !item.isRecordOpen) {
      //   //         set(item, 'isRecordOpen', true);
      //   //         gridComp.expandDetailRow(targetIndex);
      //   //       }
      //   //       if(isEmpty(item.isRecordOpen)) {
      //   //         set(item, 'isRecordOpen', true);
      //   //         gridComp.expandDetailRow(targetIndex);
      //   //       }
      //   //       // set(item, 'isPrevDetailOpen', false);
      //   //       // this.set('isSpecimenExamDetailOpen', true);
      //   //       // this.set('detailView', EmberObject.create({
      //   //       //   title: item.examination.abbreviation + " [Prev. Result]",
      //   //       //   recordNoteId: item.recentRecoredNoteId,
      //   //       // }));
      //   //     } else {
      //   //       gridComp.collapseAllDetailRow();
      //   //     }
      //   //   }
      //   // }
      // },

      onDetailViewClosed(){
        set(this.get('detailView'), 'title', null);
        set(this.get('detailView'), 'recordNoteId', null);
      },

      onInitFilter(){
        if (!isEmpty(this.get('model.listBoxSpecimen.selectedItems'))) {
          this.get('model.listBoxSpecimen').deselectAll();
        }
      },

      onSearchByPeriod(){
        this.set('isByPeriodOpen', !this.get('isByPeriodOpen'));
      },

      onChangedDateType(){
        this._getSearchCallBack();
      },

      //TODO: scroll paging event
      onGridScroll(e){
        if(e.maxTop !== 0 && e.top >= e.maxTop){
          if(this.get('isValidPaging')){
            this.set('isValidPaging', false);
            this.get('getSpecimenListPagingCB')();
          }
        }
      },

      searchSpecimenAll(){
        this.set('summaryPopupTarget', `#${this.element.id}`);
        this.set('isSpecimenExamSummaryOpen', true);
      },

      sendToRecord(){
        //
      },
      onGridBeforeMouseDown() {
        this.set('isSpecimenExamSummaryOpen', false);

      },
      onGridCellClick(e) {
        console.log('onGridCellClick--', e);
        const field = e.column.field;
        this.set('recordNoteTarget', `#${e.originalSource.elementId}`);
        // const gridItem = this.get('model.selectedGridItem');
        // if(!this.get('isGridRowChanged') && gridItem.checkInId !== e.item.checkInId && gridItem.itemIndex !== e.item.itemIndex) {
        //   set(e.item, 'isRecordOpen', false);
        // }
        const selectedCellsItem = e.item;
        if(this.get('isGridRowChanged')) {
          set(e.item, 'isRecordOpen', false);
        }
        this.set('expandersRecordId', null);
        this.set('expandersRecentRecordId', null);
        const gridComp = e.source;
        gridComp.collapseAllDetailRow();
        if(!isEmpty(selectedCellsItem)) {
          const hasRecordFiled = !isEmpty(selectedCellsItem.recoredNoteId) && field === 'displayResult';
          const hasRecentRecord = !isEmpty(selectedCellsItem.recentRecoredNoteId) && field === 'recentDisplayResult';
          console.log('hasRecordFiled::', hasRecordFiled, 'hasRecentRecord:::', hasRecentRecord, 'isRecordOpen::', e.item.isRecordOpen);
          if(hasRecordFiled || hasRecentRecord) {
            this.set('expandersRecordId', selectedCellsItem.recoredNoteId);
            this.set('expandersRecentRecordId', selectedCellsItem.recentRecoredNoteId);
            const targetIndex = gridComp.getItemIndex(e.item) +e.item.lastIndex- e.item.itemIndx;
            if(!isEmpty(e.item.isRecordOpen) && e.item.isRecordOpen) {
              if(hasRecentRecord && this.get('isRecordDetailOpen')) {
                this.set('isRecordDetailOpen', false);
                gridComp.expandDetailRow(targetIndex);
              } else if(hasRecordFiled && !this.get('isRecordDetailOpen')){
                this.set('isRecordDetailOpen', true);
                gridComp.expandDetailRow(targetIndex);
              } else {
                set(e.item, 'isRecordOpen', false);
              }
            } else if(!isEmpty(e.item.isRecordOpen) && !e.item.isRecordOpen) {
              if(hasRecentRecord) {
                this.set('isRecordDetailOpen', false);
              } else {
                this.set('isRecordDetailOpen', true);
              }
              set(e.item, 'isRecordOpen', true);
              gridComp.expandDetailRow(targetIndex);
            }
            if(isEmpty(e.item.isRecordOpen)) {
              if(hasRecentRecord) {
                this.set('isRecordDetailOpen', false);
              } else {
                this.set('isRecordDetailOpen', true);
              }
              set(e.item, 'isRecordOpen', true);
              gridComp.expandDetailRow(targetIndex);
            }
            this.set('isGridRowChanged', false);
          } else {
            gridComp.collapseAllDetailRow();
          }
        }

      },

      onGridDetailRowItemsChanged(e) {
        console.log('onGridDetailRowItemsChanged--', e);

      },

      onGridSelectedCell(e){
        this.set('selectedExaminationIds', emberA());
        const selectedCells = e.selectedCells;
        this.set('model.selectedGridCells', selectedCells);
        if(!isEmpty(selectedCells)) {
          if(selectedCells.length === 1) {
            this.set('isGridRowChanged', true);
            set(selectedCells[0], 'isRecordOpen', false);
          }
          const selectedIds = [];
          selectedCells.forEach((cell) => {
            selectedIds.push(cell.item.examination.id);
          });
          const uniqueIds = selectedIds.filter((v, i, a) => a.indexOf(v) === i);
          this.set('selectedExaminationIds', uniqueIds);
        }
      },
      onGridSelectedRows(e){
        console.log('onGridSelectedRows--', e);
        this.set('selectedExaminationIds', emberA());
        const selectedItems = e.selectedItems;
        if(!isEmpty(selectedItems)) {
          if(selectedItems.length === 1) {
            this.set('model.selectedGridItem', selectedItems[0]);
            this.set('isGridRowChanged', true);
            set(selectedItems[0], 'isRecordOpen', false);
          }
          // const gridComp = e.source;
          // const targetIndex = gridComp.getItemIndex(selectedItems[0]);
          // gridComp.expandDetailRow(targetIndex);
          const selectedIds = [];
          selectedItems.forEach((item) => {
            selectedIds.push(item.examination.id);
          });
          this.set('selectedExaminationIds', selectedIds);
        }
      },

    },

    _specimenFilterOpenChanged(){
      this.set('model.isPopupSpecimen', !this.get('model.isPopupSpecimen'));
    },

    _getSearchCallBack(){
      if(this.get('searchCondition.selectedDateType.value') !== 'CheckIn'){
        this.set('searchCondition.isNotReported', false);
      }

      //초기화
      this._filterInit();
      // this.set('specimenDateType', this.get('searchCondition'));
      if(!isEmpty(this.get('getSpecimenListbyFilterCB'))){
        this.get('getSpecimenListbyFilterCB')('Filter');
      }
    },

    _filterInit(){
      this.set('filterCount', null);
      this.set('specimenSelectedFilter', {classificationIds: null, status: null});
    },

    _setFilter(){
      let statusList = {};
      if (!isEmpty(this.get('specimenFilterAbnormal.value'))) {
        statusList = EmberObject.create({
          code: this.get('specimenFilterAbnormal.value'),
          type: 'status'
        });
      }

      const filter = [];
      if (!isEmpty(this.get('model.listBoxSpecimen.selectedItems'))) {
        this.get('model.listBoxSpecimen.selectedItems').forEach(e => {
          filter.pushObject(e.id);
        });
        this.set('filterCount', '(' + this.get('model.listBoxSpecimen.selectedItems').length + ')');
      }else{
        this.set('filterCount', '');
      }

      this.set('specimenSelectedFilter', {
        classificationIds: filter,
        status: statusList
      });
      if(!isEmpty(this.get('getSpecimenListbyFilterCB'))){
        this.get('getSpecimenListbyFilterCB')();
      }
    },
  });