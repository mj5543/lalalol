/* eslint-disable chis/avoid-memory-leak */
/* eslint-disable no-console */
/* eslint-disable max-lines-per-function */
import $ from 'jquery';
import { inject as service } from '@ember/service';
import EmberObject, { defineProperty, computed, set, observer } from '@ember/object';
import { A as emberA } from '@ember/array';
import { isEmpty, isPresent } from '@ember/utils';
import { once, later } from '@ember/runloop';
import layout from './template';
import CHIS from 'framework/chis-framework';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  {
    layout,
    model: null,
    userGlobalInformation: null,
    examinationGroupCode: null,
    patientexaminationGridListColumns: null,
    patientexaminationGridList: null,
    patientexaminationGridListItemsSource: null,
    radiologyFilterItem: null,
    radiologySelectedFilter:null,
    clinicFilterItem: null,
    clinicSelectedFilter: null,
    isPopupRadiologyOpen: false,
    radiofilterCount: null,
    isPopupClinicOpen: false,
    clinicfilterCount: null,
    gridId: null,
    resultView: null,
    contextMenuSource: null,
    isRecordDetailOpen: false,
    activeTab: null,
    isRadiologyFilterOpen: false,
    isClinicFilterOpen: false,
    isShowGridLoader: false,
    isShoRecordLoader: false,
    isGridDisabled: false,
    apiService: service('testresultviewer-service'),
    activeTabChanged: observer('activeTab', 'isDisplay2xMode', function() {
      once(this, '_setLayout');
    }),
    gridListChanged: observer('patientexaminationGridListItemsSource', function() {
      this.set('isRecordDetailOpen', false);
      const patientGrid = this.get('patientGrid');
      if(!isEmpty(patientGrid) && isEmpty(this.get('specimenexaminationGridListItemsSource'))) {
        // if(this.get('activeTabName') === 'Clinic') {
        //   this.set('isPopupClinicOpen', false);
        //   this.set('isClinicFilterOpen', false);
        // } else {
        //   this.set('isPopupRadiologyOpen', false);
        //   this.set('isRadiologyFilterOpen', false);
        // }
        patientGrid.clearSorting();
      }
    }),
    radiologyFilterItemChanged: observer('radiologyFilterItem', function() {
      once(this, '_setRadiologyListboxSelection');
    }),
    clinicFilterItemChanged: observer('clinicFilterItem', function() {
      once(this, '_setClinicListboxSelection');
    }),

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId','test-result-viewer-patient-examination');

      this.setStateProperties([
        'examinationGroupCode',
        'patientexaminationGridListColumns',
        'patientexaminationGridListItemsSource',
        'patientexaminationGridList',
        'radiologyFilterItem',
        'radiologySelectedFilter',
        'clinicFilterItem',
        'clinicSelectedFilter',
        'resultView',
        'patientGrid',
        'gridStyles',
        'activeTabName'
      ]);

      if(this.hasState()===false) {
        const defaultUrl = this.get('fr_HostConfigService')
          .getEnvConfig('ServerCallConfig', 'testresultviewer') +
          `test-result-viewer/v0/`;

        this.set('defaultUrl', defaultUrl);
        if(!isEmpty(this.get('co_CurrentUserService.user'))){
          this.set('userGlobalInformation', this.get('co_CurrentUserService.user'));
        }

        this.set('patientexaminationGridListItemsSource', emberA());

        this.set('patientexaminationGridList', {selectedItem:{}, totalCount:null});
        this.set('model', {
          clickCellItem: null,
          listBoxBodySite: emberA(),
          listBoxModality: emberA(),
          listBoxInterpretationPart: emberA(),
          listBoxExaminationGroup: emberA()
        });
        this.set('radiologyFilterItem', EmberObject.create({anatomicalSite: emberA(), modality: emberA(), interpretationPart: emberA()}));
        this.set('radiologySelectedFilter' , EmberObject.create({anatomicalSite: emberA(), modality: emberA(), interpretationPart: emberA()}));
      }
      this.set('resultView', EmberObject.create({
        title: null,
        recordNoteId: null,
        recordsHeader: null,
      }));
      if (this.get('examinationGroupCode') === 'Clinic') {
        this.set('contextMenuSource', [
          { text: this.getLanguageResource('14909', 'F', '', '판독하기'), disabled : false, display : true, action: function (e) {
            if(!isEmpty(e.dataItem.item)) {
              this._sendMessageInterpretation(e.dataItem.item);
            }
          }.bind(this) },
        ]);
      }
      this.set('contentStyle', 'height:calc(100% - 35px);margin-top:10px;');
      // let executeDateColumn = null;
      // if(this.get('examinationGroupCode') === 'DR'){
      //   executeDateColumn = { field: 'executeDate', title: this.getLanguageResource('9925', 'S'), width:120, type: 'date', dataFormat: 'g' , align: 'center'};
      // }else{
      //   executeDateColumn = { field: 'executeDate', title: this.getLanguageResource('9947', 'S'), width:120, type: 'date', dataFormat: 'd' , align: 'center'};
      // }
      const dateFormat = this.get('examinationGroupCode') === 'DR' ? 'g' : 'd';
      const resourceKey = this.get('examinationGroupCode') === 'DR' ? '17047' : '9947';
      this.set('patientexaminationGridListColumns', [
        { field: 'examinationName', title: this.getLanguageResource('16920', 'S'), align: 'left', bodyTemplateName: 'examinationTooltip'},
        //2020.09.16 영문화 요청으로 9925로 변경
        // executeDateColumn,
        { field: 'executeDate', title: this.getLanguageResource(resourceKey, 'S'), width:120, type: 'date', dataFormat: dateFormat, align: 'center'},
        { field: 'interpretationDate', title: this.getLanguageResource('2872', 'S'), width:120, type: 'date', dataFormat: 'd', align: 'center'},
        { field: 'statusName', title: this.getLanguageResource('732', 'S'), width: 85, align: 'center',
          onBodyCellInit: function (context) {
            const apiService = this.get('apiService');
            const cellComponent = context.cellComponent;
            defineProperty(context.cellComponent, 'observedProperty', computed('item.statusCode', function () {
              $(`#${cellComponent.elementId}`).css('color', apiService.onGetPatientExamStatusColor(this.get('item.statusCode')));
              $(`#${cellComponent.elementId}`).css('font-weight', 'bolder');
            }));
          }.bind(this)
        }
      ]);
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w680');
    },
    didReceiveAttrs() {
      this._super(...arguments);
      if(this.get('activeTabName') === 'Radiology' || this.get('activeTabName') === 'Clinic') {
        this.set('activeTab', this.get('activeTabName'));
      }
    },
    didRender() {
      this._super(...arguments);
      if(isPresent(this.get('gridElement'))) {
        let targetRow = this.get('gridElement').getElementsByClassName('c-gdetail');
        if(isPresent(targetRow)) {
          let gridLinEl = targetRow[0].getElementsByClassName('c-gdetail-line');
          if(isEmpty(gridLinEl[0].innerText)) {
            $(targetRow).addClass('none');
          } else if(isPresent(gridLinEl[0].innerText)){
            $(targetRow).find('.scrollbar-macosx').scrollbar();
            $(targetRow).removeClass('none');
            this.set('isGridDisabled', false);
          }
          gridLinEl = null;
        }
        targetRow = null;
      }
    },

    actions: {
      onFilterCloseClick(group) {
        if(group === 'DR') {
          this.set('isPopupRadiologyOpen', false);
          this.set('isRadiologyFilterOpen', false);
        } else {
          this.set('isPopupClinicOpen', false);
          this.set('isClinicFilterOpen', false);
        }
      },
      onGridLoaded(e) {
        this.set('patientGrid', e.source);
        let gridEl = document.getElementById(e.source.elementId);
        this.set('gridElement', gridEl);
        gridEl = null;
      },
      onGridContextMenuOpen(e) {
        if(isEmpty(e.dataItem.item)) {
          set(e, 'cancel', true);
        }
      },
      onRadiologyFilterClick(){
        if(isEmpty(this.get('co_PatientManagerService.selectedPatient'))){
          //환자를 선택하세요.
          this.get('apiService').onDisplayMessage('warning', this.getLanguageResource('8946'), '', 'Ok', 'Ok', 0);
          return;
        }
        this.set('isPopupRadiologyOpen' ,!this.get('isPopupRadiologyOpen'));
      },

      onClinicFilterClick(){
        if(isEmpty(this.get('co_PatientManagerService.selectedPatient'))){
          //환자를 선택하세요.
          this.get('apiService').onDisplayMessage('warning', this.getLanguageResource('8946'), '', 'Ok', 'Ok', 0);
          return;
        }
        this.set('isPopupClinicOpen' ,!this.get('isPopupClinicOpen'));
      },

      onloadListboxBodySite(e){
        this.set('model.listBoxBodySite', e.source);
      },

      onloadListboxModality(e){
        this.set('model.listBoxModality', e.source);
      },

      onloadListboxInterpretationPart(e){
        this.set('model.listBoxInterpretationPart', e.source);
      },

      onloadListboxExaminationGroup(e){
        this.set('model.listBoxExaminationGroup', e.source);
      },

      onListSelectionChange(e){
        switch (e) {
          case 'AnatomicalSite':
            this.get('model.listBoxModality').deselectAll();
            this.get('model.listBoxInterpretationPart').deselectAll();
            break;
          case 'Modality':
            this.get('model.listBoxBodySite').deselectAll();
            this.get('model.listBoxInterpretationPart').deselectAll();
            break;
          case 'InterpretationPart':
            this.get('model.listBoxBodySite').deselectAll();
            this.get('model.listBoxModality').deselectAll();
            break;
          default:
            break;
        }
        this._setRadiologyFilter();
      },

      onRadiologyFilterPopover(){
        this._setRadiologyListboxSelection();
      },

      onClinicFilterPopover(){
        this._setClinicListboxSelection();
      },

      onFilterPopover(group){
        if(group === 'DR') {
          this._setRadiologyListboxSelection();
        } else {
          this._setClinicListboxSelection();
        }
      },

      onListboxhByClinicChanged() {
        this._setClinicFilter();
      },

      onListboxhByRadiologyChanged() {
        this._setRadiologyFilter();
      },
      onFileNoteLoaded() {
        this.set('isShowGridLoader', false);
      },
      onGridCellClick(e){
        this.set('isRecordDetailOpen', false);
        const selectedGridItem = this.get('patientexaminationGridList.selectedItem');
        if(!isEmpty(e.item)){
          if(isPresent(this.get('patientSelectedCB'))) {
            this.get('patientSelectedCB')(e.item);
          }
          if(!isEmpty(selectedGridItem) && (e.item !== selectedGridItem)) {
            set(selectedGridItem, 'isRecordOpen', false);
          }
          const gridComp = e.source;
          if(!isEmpty(e.item.recordNoteId)) {
            let formatType = 'd';
            if(this.get('examinationGroupCode') === 'DR') {
              formatType = 'g';
            }
            this.set('recordsHeader', `${e.item.examinationName} / ${this.get('fr_I18nService').formatDate(e.item.executeDate, formatType)}`);
            if(!this.get('isDisplay2xMode')) {
              this.set('isShowGridLoader', true);
              gridComp.collapseAllDetailRow();
              const targetIndex = gridComp.getItemIndex(e.item);
              if(!isEmpty(e.item.isRecordOpen) && e.item.isRecordOpen) {
                set(e.item, 'isRecordOpen', false);
              } else if((isPresent(e.item.isRecordOpen) && !e.item.isRecordOpen) || isEmpty(e.item.isRecordOpen)) {
                set(e.item, 'isRecordOpen', true);
                this.set('isGridDisabled', true);
                gridComp.expandDetailRow(targetIndex);
              }
            } else {
              this.set('isShoRecordLoader', true);
              this.set('resultView', EmberObject.create({
                title: e.item.examinationName,
                recordNoteId: e.item.recordNoteId,
                recordsHeader: e.item.examinationName
              }));
              this.set('isRecordDetailOpen', true);
            }
          } else {
            gridComp.collapseAllDetailRow();
          }
        }
      },
      onSearchByRadiologyFilter(){
        // this._setRadiologyFilter();
        this.set('isPopupRadiologyOpen', false);
      },

      onSearchByClinicFilter(){
        // this._setClinicFilter();
        this.set('isPopupClinicOpen', false);
      },

      onInitRadiologyFilter(){
        if (!isEmpty(this.get('model.listBoxBodySite.selectedItems'))) {
          this.get('model.listBoxBodySite').deselectAll();
        }
        if (!isEmpty(this.get('model.listBoxModality.selectedItems'))) {
          this.get('model.listBoxModality').deselectAll();
        }
        if (!isEmpty(this.get('model.listBoxInterpretationPart.selectedItems'))) {
          this.get('model.listBoxInterpretationPart').deselectAll();
        }
        this._setRadiologyFilter();
      },

      onInitClinicFilter(){
        if (!isEmpty(this.get('model.listBoxExaminationGroup.selectedItems'))) {
          this.get('model.listBoxExaminationGroup').deselectAll();
        }
        this._setClinicFilter();
      },
      onTogglebuttonLoaded(e) {
        this.set('filterTarget', `#${e.source.elementId}`);
      },
      onFilterToggleChanged(group) {
        if(group === 'DR') {
          this.set('isPopupRadiologyOpen', this.get('isRadiologyFilterOpen'));
        } else {
          this.set('isPopupClinicOpen', this.get('isClinicFilterOpen'));
        }
      },

    },
    _setRadiologyListboxSelection() {
      if(!isEmpty(this.get('radiologySelectedFilter.anatomicalSite'))){
        this.get('radiologyFilterItem.anatomicalSite').forEach(function(e,index){
          if(this.get('radiologySelectedFilter.anatomicalSite').includes(e.code)){
            this.get('model.listBoxBodySite').selectItem(index);
          }
        }.bind(this));
      }
      if(!isEmpty(this.get('radiologySelectedFilter.modality'))){
        this.get('radiologyFilterItem.modality').forEach(function(e,index){
          if(this.get('radiologySelectedFilter.modality').includes(e.code)){
            this.get('model.listBoxModality').selectItem(index);
          }
        }.bind(this));
      }
      if(!isEmpty(this.get('radiologySelectedFilter.interpretationPart'))){
        this.get('radiologyFilterItem.interpretationPart').forEach(function(e,index){
          if(this.get('radiologySelectedFilter.interpretationPart').includes(e.code)){
            this.get('model.listBoxInterpretationPart').selectItem(index);
          }
        }.bind(this));
      }
      later(() => {
        this._setRadiologyFilterCount();
      });
    },
    _setClinicListboxSelection() {
      if(isEmpty(this.get('clinicFilterItem'))){
        this.set('clinicfilterCount', '');
        return;
      }
      if(!isEmpty(this.get('clinicSelectedFilter'))){
        this.get('clinicFilterItem').forEach(function(e,index){
          if(this.get('clinicSelectedFilter').includes(e.code)){
            this.get('model.listBoxExaminationGroup').selectItem(index);
          }
        }.bind(this));
        later(() => {
          if(isPresent(this.get('model.listBoxExaminationGroup.selectedItems'))) {
            this.set('clinicfilterCount', '(' +this.get('model.listBoxExaminationGroup.selectedItems').length + ')');
          }
        });
      }
    },

    _setRadiologyFilter(){
      const bodySite = [];
      const modality = [];
      const interpretationPart = [];

      if (!isEmpty(this.get('model.listBoxBodySite.selectedItems'))) {
        this.get('model.listBoxBodySite.selectedItems').forEach(e => {
          bodySite.pushObject(e.code);
        });
      }
      if (!isEmpty(this.get('model.listBoxModality.selectedItems'))) {
        this.get('model.listBoxModality.selectedItems').forEach(e => {
          modality.pushObject(e.code);
        });
      }
      if (!isEmpty(this.get('model.listBoxInterpretationPart.selectedItems'))) {
        this.get('model.listBoxInterpretationPart.selectedItems').forEach(e => {
          interpretationPart.pushObject(e.code);
        });
      }
      this._setRadiologyFilterCount();

      this.set('radiologySelectedFilter', EmberObject.create({
        anatomicalSite: bodySite,
        modality: modality,
        interpretationPart: interpretationPart
      }));
      if(!isEmpty(this.get('getPatientExamListbyFilterCB'))){
        this.get('getPatientExamListbyFilterCB')('DR');
      }
    },

    _setRadiologyFilterCount() {
      let filterCount = '';
      if (!isEmpty(this.get('model.listBoxBodySite.selectedItems'))) {
        filterCount = this.get('model.listBoxBodySite.selectedItems').length;
      }
      if (!isEmpty(this.get('model.listBoxModality.selectedItems'))) {
        filterCount = this.get('model.listBoxModality.selectedItems').length;
      }
      if (!isEmpty(this.get('model.listBoxInterpretationPart.selectedItems'))) {
        filterCount = this.get('model.listBoxInterpretationPart.selectedItems').length;
      }

      if(!isEmpty(filterCount)){
        this.set('radiofilterCount', '(' + filterCount +')');
      }else{
        this.set('radiofilterCount', '');
      }
    },

    _setClinicFilter(){
      const clinicSelectedFilter = [];

      if (!isEmpty(this.get('model.listBoxExaminationGroup.selectedItems'))) {
        this.get('model.listBoxExaminationGroup.selectedItems').forEach(e => {
          clinicSelectedFilter.pushObject(e.code);
        });
        this.set('clinicfilterCount', '(' + this.get('model.listBoxExaminationGroup.selectedItems').length +')');
      }else{
        this.set('clinicfilterCount', '');
      }
      this.set('clinicSelectedFilter', clinicSelectedFilter);
      if(!isEmpty(this.get('getPatientExamListbyFilterCB'))){
        this.get('getPatientExamListbyFilterCB')('Clinic');
      }
    },
    _sendMessageInterpretation(item) {
      const parameters = {
        patientId: item.patientId,
        examinationPlanId: item.examinationPlanId,
        examinationGroupCode: item.examinationGroupCode
      };
      this.get('co_MenuManagerService').openMenu('patient-examination-report-interpretation', parameters);
      this.get('co_ContentMessageService').sendMessage('messageResultViewerInterpretation', parameters);
    },

    _setLayout() {
      this.set('isRecordDetailOpen', false);
      const gridComp = this.get('patientGrid');
      const activeTabName = this.get('activeTabName');
      if(!isEmpty(gridComp)) {
        gridComp.collapseAllDetailRow();
        const selectedGridItem = this.get('patientexaminationGridList.selectedItem');
        const hasRecordNodeId = isPresent(selectedGridItem) && isPresent(selectedGridItem.recordNoteId);
        if(this.get('isDisplay2xMode')) {
          this.set('contentStyle', 'height:100%;');
          this.set('gridStyles', 'width:calc(100% - 870px);float:left;');
          this.set('filterAreaStyles', 'width:calc(100% - 650px);float:left;');
          if(hasRecordNodeId) {
            this.set('resultView', EmberObject.create({
              title:selectedGridItem.examinationName,
              recordNoteId: selectedGridItem.recordNoteId,
              recordsHeader: selectedGridItem.examinationName
            }));
            this.set('isRecordDetailOpen', true);
          }
          if(activeTabName === 'Clinic') {
            this._setClinicListboxSelection();
          } else {
            this._setRadiologyListboxSelection();
          }
        } else {
          this.set('contentStyle', 'height:calc(100% - 35px);margin-top:10px;');
          this.set('gridStyles', '');
          this.set('filterAreaStyles', '');
          if(hasRecordNodeId) {
            const targetIndex = gridComp.getItemIndex(selectedGridItem);
            gridComp.expandDetailRow(targetIndex);
          }
        }
      }
    }
  });