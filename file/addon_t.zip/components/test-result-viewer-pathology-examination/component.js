/* eslint-disable chis/avoid-memory-leak */
import $ from 'jquery';
import EmberObject, {set, observer} from '@ember/object';
import { isEmpty, isPresent } from '@ember/utils';
import { A as emberA } from '@ember/array';
import { once } from '@ember/runloop';
import layout from './template';
import CHIS from 'framework/chis-framework';

export default CHIS.FR.Core.ComponentBase.extend(
  {
    layout,
    model: null,
    examinationGroupCode: null,
    pathologyexaminationGridListColumns: null,
    pathologyexaminationGridList: null,
    pathologyexaminationGridListItemsSource: null,
    gridId: null,
    resultView: null,
    isRecordDetailOpen: false,
    activeTab: null,
    isGridDisabled: false,
    activeTabChanged: observer('activeTab', 'isDisplay2xMode', function() {
      once(this, '_setLayout');
    }),
    gridListChanged: observer('pathologyexaminationGridListItemsSource', function() {
      this.set('isRecordDetailOpen', false);
      const pathologyGrid = this.get('pathologyGrid');
      if(!isEmpty(pathologyGrid) && isEmpty(this.get('specimenexaminationGridListItemsSource'))) {
        pathologyGrid.clearSorting();
      }
    }),

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId','test-result-viewer-pathology-examination');

      this.setStateProperties([
        'examinationGroupCode',
        'pathologyexaminationGridListColumns',
        'pathologyexaminationGridListItemsSource',
        'pathologyexaminationGridList',
        'resultView',
        'pathologyGrid',
        'gridStyles'
      ]);

      if(this.hasState()===false) {

        this.set('pathologyexaminationGridListColumns', [
          { field: 'checkInDateTime', title: this.getLanguageResource('6777', 'F'), width:120, type: 'date', dataFormat: 'd' , align: 'center'},
          { field: 'pathologyNumber', title: this.getLanguageResource('2796', 'F'), align: 'center'},
          { field: 'reportedDatetime', title: this.getLanguageResource('2873', 'F'), align: 'center'},
          { field: 'classificationName', title: this.getLanguageResource('16920', 'S'), bodyTemplateName: 'examinationTooltip'},
        ]);
        this.set('pathologyexaminationGridListItemsSource', emberA());
        this.set('resultView', EmberObject.create({
          title: null,
          recordNoteId: null,
          recordsHeader: null,
        }));

        this.set('pathologyexaminationGridList', {selectedItem:{}, totalCount:null});
        this.set('model', {listBoxBodySite: emberA(), listBoxModality: emberA(), listBoxInterpretationPart: emberA(), listBoxExaminationGroup: emberA()});
      }
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w680');
    },
    didReceiveAttrs() {
      this._super(...arguments);
      if(this.get('activeTabName') === 'Pathology') {
        this.set('activeTab', this.get('activeTabName'));
      }
    },
    didRender() {
      this._super(...arguments);
      if(isPresent(this.get('gridElement'))) {
        let targetRow = this.get('gridElement').getElementsByClassName('c-gdetail');
        if(isPresent(targetRow)) {
          let gridLinEl = targetRow[0].getElementsByClassName('c-gdetail-line');
          if(isEmpty(gridLinEl[0].innerText)) {
            $(targetRow).addClass('none');
          } else if(isPresent(gridLinEl[0].innerText)){
            $(targetRow).find('.scrollbar-macosx').scrollbar();
            $(targetRow).removeClass('none');
            this.set('isGridDisabled', false);
          }
          gridLinEl = null;
        }
        targetRow = null;
      }
    },

    actions: {
      onGridLoaded(e) {
        this.set('pathologyGrid', e.source);
        let gridEl = document.getElementById(e.source.elementId);
        this.set('gridElement', gridEl);
        gridEl = null;
      },
      onGridCellClick(e){
        this.set('isRecordDetailOpen', false);
        if(!isEmpty(e.item)){
          const gridComp = e.source;
          const selectedGridItem = this.get('pathologyexaminationGridList.selectedItem');
          if((e.item !== selectedGridItem) && !isEmpty(selectedGridItem)) {
            set(selectedGridItem, 'isRecordOpen', false);
          }
          if(!isEmpty(e.item.recordNoteId)) {
            this.set('recordsHeader', `${e.item.classificationName} (${e.item.pathologyNumber}) / ${this.get('fr_I18nService').formatDate(e.item.checkInDateTime, 'd')}`);
            if(!this.get('isDisplay2xMode')) {
              gridComp.collapseAllDetailRow();
              const targetIndex = gridComp.getItemIndex(e.item);
              if(!isEmpty(e.item.isRecordOpen) && e.item.isRecordOpen) {
                set(e.item, 'isRecordOpen', false);
              } else if((!isEmpty(e.item.isRecordOpen) && !e.item.isRecordOpen) || isEmpty(e.item.isRecordOpen)) {
                set(e.item, 'isRecordOpen', true);
                this.set('isGridDisabled', true);
                gridComp.expandDetailRow(targetIndex);
              }
              // if(isEmpty(e.item.isRecordOpen)) {
              //   set(e.item, 'isRecordOpen', true);
              //   gridComp.expandDetailRow(targetIndex);
              // }
            } else {
              this.set('resultView', EmberObject.create({
                title: e.item.examinationName,
                recordNoteId: e.item.recordNoteId,
                recordsHeader: e.item.examinationName
              }));
              this.set('isRecordDetailOpen', true);
            }
          } else {
            gridComp.collapseAllDetailRow();
          }
        }
      },

    },

    _setLayout() {
      const gridComp = this.get('pathologyGrid');
      this.set('isRecordDetailOpen', false);
      if(!isEmpty(gridComp)) {
        gridComp.collapseAllDetailRow();
        const selectedGridItem = this.get('pathologyexaminationGridList.selectedItem');
        const hasRecordNodeId = isPresent(selectedGridItem) && isPresent(selectedGridItem.recordNoteId);
        if(this.get('isDisplay2xMode')) {
          this.set('gridStyles', 'width:calc(100% - 750px);float:left;');
          if(hasRecordNodeId) {
            this.set('resultView', EmberObject.create({
              title:selectedGridItem.examinationName,
              recordNoteId: selectedGridItem.recordNoteId,
              recordsHeader: selectedGridItem.examinationName
            }));
            this.set('isRecordDetailOpen', true);
          }
        } else {
          this.set('gridStyles', '');
          if(hasRecordNodeId) {
            const targetIndex = gridComp.getItemIndex(selectedGridItem);
            gridComp.expandDetailRow(targetIndex);
          }
        }
      }

    }
  });