/* eslint-disable max-lines */
/* eslint-disable no-console */
import $ from 'jquery';
import moment from 'moment';
import { isEmpty, isPresent } from '@ember/utils';
import EmberObject, { set, get, observer } from '@ember/object';
import { A as emberA } from '@ember/array';
import { later } from '@ember/runloop';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'testresultviewer-module/app-config';
import TestResultViewerMixin from '../../mixins/test-result-viewer-mixin';
import PacsMixin from 'co-interface/mixins/pacs-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  TestResultViewerMixin,
  PacsMixin,
  {
    layout,
    defaultUrl: null,
    model: null,
    userGlobalInformation: null,
    patientGlobalInformation: null,
    isPageLoader: false,
    specimenExaminationParam: null,
    hasOtherCompParam: false,
    otherCompParams: null,
    recieveParams: null,
    isShowPatientInfo: false,
    hasRecieveParams: false,
    isShowResultLinkTag: false,
    isPopoverFirstOpen: true,
    fromToPicker: null,
    customPeriod: null,
    isPopupManagement: false,
    isSettingOpen: false,
    settingInfo: null,
    settingValue: null,
    isPatientChanged: false,
    isCompLoaded: false,
    pacsUrl: null,
    isPacsViewerDisabled: true,
    isPickerLoading: true,
    isShowTabLoader: false,
    isDisplay2xMode: false,
    copyPicker: null,
    isActiveSlider: true,
    isCpacsUsed: false,
    patientExamItem: null,
    activeTabChanged: observer('isActiveSlider', function() {
      if(this.get('isActiveSlider')) {
        //TODO
        // once(this, '_setPickersTick');
      }
    }),

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'test-result-viewer-management');

      this.setStateProperties([
        'model',
        'defaultUrl',
        'searchCondition',
        'userGlobalInformation',
        'patientGlobalInformation',
        'ticks',
        'copyTicks',
        'periodTypeItems'
      ]);

      if(this.hasState()===false) {
        const envConfig = this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'testresultviewer');
        const defaultUrl = `${envConfig}test-result-viewer/${config.version}/`;
        const specimenUrl = `${envConfig}specimen-examination-report/${config.version}/`;

        this.set('defaultUrl', defaultUrl);
        this.set('specimenUrl', specimenUrl);
        if(!isEmpty(this.get('co_CurrentUserService.user'))){
          this.set('userGlobalInformation', this.get('co_CurrentUserService.user'));
        }
        if(!isEmpty(this.get('co_PatientManagerService.selectedPatient'))){
          this.set('patientGlobalInformation', this.get('co_PatientManagerService.selectedPatient'));
        }
        this.set('model', {
          isPeriodOpen:  false,
          isConditionOpen: false,
          selectedTabName  : 'Specimen',
          specimenTab: this.getLanguageResource('15299', 'F', '검체'),
          specimenCount: null,
          specimenOriginalCount: null,
          radiologyTab: this.getLanguageResource('4961', 'F', '영상'),
          radiologyCount: null,
          clinicTab: this.getLanguageResource('1476', 'F', '기능'),
          clinicCount: null,
          pathologyTab: this.getLanguageResource('2785', 'F', '병리'),
          pathologyCount: null,
          filterCount: null,
          specimenPaging: 1,
          specimenTotalPaging: 1,
          specimenItemSource: emberA(),
          specimenFilterItem: emberA(),
          specimenDateType: {
            selectedDateType: {value: 'CheckIn', content: this.getLanguageResource('12682', 'S', '접수일별')},
            isNotReported: false,
          },
          specimenSelectedFilter: {},
          isSpecimenExamDetailOpen: false,
          radiologyItemSource: emberA(),
          clinicItemSource: emberA(),
          radiologyFilterItem: {},
          radiologySelectedFilter: {},
          radiogyDetailOpen: false,
          clinicFilterItem: {},
          clinicSelectedFilter: [],
          clinicDetailOpen: false,
          radiofilterCount: null,
          clinicfilterCount: null,
          isValidPaging: true,
          isPathologyExamDetailOpen:false,
          specimenExamSummaryOpen: false,
          patientId: null,
          genderName: null,
          age: null,
          patientName: null,
          patientInfoByButton: null,
          patientInfoByText: null,
          selectedTickIndex: null,
          specimenGridColumns: null,
        });
        this.set('model.specimenGridColumns', this.setSpecimenexaminationGridColumns());

        this.set('searchCondition', emberA({
          selectedCondition:{value: null, content: null},
          selectedPeriodType:{value: null, content: null},
          fromDate: null,
          toDate: null,
          disalbleFromToDate: true,
          isDeptChecked: false,
          isOrderChecked: false,
          isShowSlider: false,
          //just use parentSearchCondition
          selectedTickIndex: null,
          ticks: null,
          enableSlider: true,
        }));
        this.set('customPeriod', emberA({
          fromDate: null,
          toDate: null,
        }));
        this.set('journeymapCondition', emberA({
          fromDate: null,
          toDate: null,
        }));
        this.set('periodTypeItems', this.periodTypeList());

        const ticks = this._setPickersTick();
        this.set('copyTicks', $.extend(true, emberA(), ticks));
        this._specimenFilterInit();
        this._patientFilterInit();
      }
    },
    async _getSettingInfo() {
      try {
        const result = await this.get('co_PersonalizationService').getSettingInfo(`test-result-viewer-management`);
        if(!isEmpty(result.settingValue)) {
          this._setDefaultSetting(result);
        } else{
          this.set('searchCondition.isShowSlider', false);
          this._setPeriodType('2w');
        }
        if(this.get('isPatientChanged') === true) {
          this._specimenExamfilterSetting();
          this._patientExamfilterSetting('Clinic');
          this._onSearchAll();
        } else {
          this._patientExamfilterSetting();
          this._specimenExamfilterSetting();
          this._onSearchAll();
          // tab selection changed 가 먼저 돌기 때문에 초기 loaded체크로직 추가
          this.set('isCompLoaded', true);
        }
      } catch(e) {
        this._showError(e);
      }
    },

    _setDefaultSetting(result) {
      try {
        if(!isEmpty(this.get('fromToPicker')) && this.get('fromToPicker.fixedSlider')) {
          this.set('isPickerLoading', false);
          return;
        }
        if(isEmpty(result)) {
          return;
        }
        this.set('settingInfo', result);
        this.set('settingValue', JSON.parse(get(result, 'settingValue')));
        const settingValue = JSON.parse(get(result, 'settingValue'));
        if(!isEmpty(settingValue.conditionData)) {
          const settingOption = settingValue.conditionData[0];
          this.set('model.specimenDateType.selectedDateType.value', settingOption.specimenDateType.selectedDateType);
          this.set('model.specimenDateType.isNotReported', settingOption.specimenDateType.isNotReported);
          this.set('searchCondition.isShowSlider', false);
          if (this.get('patientGlobalInformation') && this.get('patientGlobalInformation.encounterClassCode') === 'I') {
            this._setPeriodType(settingOption.periodTypes.in);
          } else {
            this._setPeriodType(settingOption.periodTypes.out);
          }
        }
      } catch(e) {
        console.log('_setDefaultSetting error::', e);
      }
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w680');
      this._getCPacsUseYN();
      if(!isEmpty(this.get('co_CurrentUserService.user'))){
        this.set('userGlobalInformation', this.get('co_CurrentUserService.user'));
      }
      if (this.get('isPopupManagement')) {
        let toggleEl = this.element.getElementsByClassName('box-func');
        this.element.removeChild(toggleEl[0]);
        toggleEl = null;
        this.set('patientGlobalInformation', this.get('patientInformation'));
      } else if(!isEmpty(this.get('co_PatientManagerService.selectedPatient'))
        && !this.get('isPopupManagement')){
        this.set('patientGlobalInformation', this.get('co_PatientManagerService.selectedPatient'));
      }
      const recieveParams = this.get('recieveParams');
      this.set('commentIconStyle', '');
      console.log('recieveParams--', recieveParams);
      if (!isEmpty(recieveParams)) {
        this.set('isPickerLoading', false);
        this.set('hasRecieveParams', true);
        this.setOtherCompParams(recieveParams);
        this.set('commentIconStyle', 'background-size: 13px 13px;width: 13px;');
      } else if(!this.get('isPopupManagement')){
        this._getSettingInfo();
      }
    },

    async _getCPacsUseYN() {
      const result = await this.getList(`${this.get('defaultUrl')}patient-examination-reports/regions/hospital-attribute`, {businessCode: 'CPACS USE YN'}, null);
      if(isPresent(result)) {
        this.set('isCpacsUsed', true);
      }
    },

    didInsertElement() {
      this._super(...arguments);
      if(!this.get('isPopupManagement')) {
        this.get('co_ContentMessageService').subscribeMessage('__main_journeymap_select_examination', this.get('currentMenuId'), this, this.setOtherCompParams);
        this.get('co_ContentMessageService').subscribeMessage('test_result_viewer_refresh_specimen', this.get('currentMenuId'), this, this._specimenExaminationRefresh);
        this.get('co_ContentMessageService').subscribeMessage('test_result_viewer_refresh_all', this.get('currentMenuId'), this, this._onSearchAll);
      } else {
        this.get('co_ContentMessageService').subscribeMessage('popup_management_init', this.get('currentMenuId'), this, this._popupViewInit);
      }
    },
    didRender() {
      this._super(...arguments);
      if(!isEmpty(this.get('fromToPicker')) && !this.get('isPickerLoading')) {
        this.setSliderTicksElementStyle(this.get('fromToPicker'));
      } else {
        this.setSliderTicksElementStyle(this.get('copyPicker'));
      }
    },
    willDestroyElement() {
      this._super(...arguments);
      if(!this.get('isPopupManagement')) {
        this.get('co_ContentMessageService').unsubscribeMessage('__main_journeymap_select_examination', this.get('currentMenuId'), this, this.setOtherCompParams);
        this.get('co_ContentMessageService').unsubscribeMessage('test_result_viewer_refresh_specimen', this.get('currentMenuId'), this, this._specimenExaminationRefresh);
        this.get('co_ContentMessageService').unsubscribeMessage('test_result_viewer_refresh_all', this.get('currentMenuId'), this, this._onSearchAll);
      } else {
        this.get('co_ContentMessageService').unsubscribeMessage('popup_management_init', this.get('currentMenuId'), this, this._popupViewInit);
      }
    },

    _popupViewInit(){
      if(this.get('isPopupManagement')){
        this.set('isPickerLoading', true);
        this.set('patientGlobalInformation', this.get('patientInformation'));
        this.set('commentIconStyle', 'background-size: 13px 13px;width: 13px;');
        this._getSettingInfo();
      }
    },

    _specimenExaminationRefresh() {
      this._specimenExamfilterSetting();
      this._specimenExaminationList();
    },

    setOtherCompParams(e) {
      if(isEmpty(this.get('userGlobalInformation'))) {
        this.set('userGlobalInformation', e.globalUserInfo);
      }
      if (isEmpty(e.examinationIds) && isEmpty(e.specimenIds) && isEmpty(e.patientExaminationIds) && isEmpty(e.pathologyCheckInIds)) {
        this.set('model.radiologyCount', ' (0)');
        this.set('model.clinicCount', ' (0)');
        this.set('model.specimenCount', ' (0)');
        this.set('model.pathologyCount', ' (0)');
        this.initGrid();
        return;
      }
      this.set('hasOtherCompParam', true);
      this.set('isShowResultLinkTag', true);
      this.set('otherCompParams', e);
      if (isEmpty(this.get('patientGlobalInformation')) || this.get('patientGlobalInformation.patientId') !== e.patientId) {
        //inbox에서 호출할 때 환자버튼정보 안보이게함
        if(!this.get('hasRecieveParams')) {
          this._getPatientBasicInfo();
        }
        this.set('model.patientId', e.patientId);
      }
      this._refreshFromOtherComp();
    },

    actions: {
      onImageOpenClick() {
        this.get('co_MenuManagerService').openMenu('test-result-viewer-integrated-image-viewer');
      },
      onFromToPickerLoaded(e) {
        this.set('fromToPicker', e.source);
      },
      onCopyPickerLoaded(e) {
        this.set('copyPicker', e.source);

      },
      onDisplaySizeChange() {
        if(this.get('isDisplay2xMode')) {
          this.set('menuClass', 'w1360');
        } else {
          this.set('menuClass', 'w680');
        }
      },
      onPacsViewerOpen(type) {
        // const message = this.get('pacsInfo');
        // console.log('pacsInfo---', message);
        // if(!isEmpty(message)) {
        //   if(isEmpty(message.Id)) {
        //     this.showMessagebox(this.getLanguageResource('12680', 'F', '', 'PACS 사용자정보가 없습니다'), this.getLanguageResource('12681', 'F', '', '직원정보에서 PACS 사용정보를 등록해주세요.'), 'warning');
        //     return;
        //   }
        //   this.get('pacsService').sendPacket(this, message);
        // }
        this._getPacsUrl(type);
      },

      //2021.05.21 PACSLINK 이전로직 삭제예정
      onPacsViewerOpenOld(type) {
        this._getPacsUrlOld(type);
      },

      onPatientSelectionChanged(item) {
        this.set('patientExamItem', item);
        // this.set('isPacsViewerDisabled', false);
        // this.set('pacsInfo', info);
      },
      onSpecimenSearchKeywordChanged(items) {
        this.set('searchKeywordResultItems', items);
        this._specimenExaminationRefresh();
      },
      onSettingChanged(info) {
        console.log(info);
        if(!isEmpty(this.get('fromToPicker')) && this.get('fromToPicker.fixedSlider')) {
          return;
        }
        this.set('searchCondition.isShowSlider', false);
        this.set('isPickerLoading', true);
        this._setDefaultSetting(info);
        this._specimenExamfilterSetting();
        this._patientExamfilterSetting('Clinic');
        this._onSearchAll();
      },
      onSettingClick() {
        this.set('isSettingOpen', true);
      },
      onUpdateFromToDate(e) {
        const isInvalidDate = isNaN(e.source.selectedFromDate);
        // let changeTargetTick = this.get('ticks.lastObject');
        if(!isInvalidDate) {
          if(!isEmpty(e.source.selectedFromDate)) {
            const formatDate = function(date) {
              return moment(date).format('YYYY-MM-DD');
            };
            const changedItem = this.get('ticks').find(d => formatDate(d.fromDate) === formatDate(e.source.selectedFromDate));
            if(!isEmpty(changedItem)) {
              this.set('model.selectedTickIndex', changedItem.index);
              this.set('searchCondition.selectedTickIndex', changedItem.index);
              this.set('searchCondition.selectedPeriodType', {value: changedItem.value, content: changedItem.tooltip });
            }
          } else {
            const periodItem = this.get('ticks').find(d => d.index === 8);
            this.set('model.selectedTickIndex', periodItem.index);
            this.set('searchCondition.selectedTickIndex', periodItem.index);
            this.set('searchCondition.selectedPeriodType', {value: periodItem.value, content: periodItem.tooltip });
          }
        } else {
          const periodItem = this.get('ticks').find(d => d.index === 8);
          this.set('searchCondition.fromDate', null);
          this.set('searchCondition.toDate', null);
          this.set('model.selectedTickIndex', periodItem.index);
          this.set('searchCondition.selectedTickIndex', periodItem.index);
          this.set('searchCondition.selectedPeriodType', {value: periodItem.value, content: periodItem.tooltip });
        }
        this.set('searchCondition.enableSlider', e.source.enableSlider);
        this._specimenExamfilterSetting();
        this._patientExamfilterSetting('Clinic');
        this._onSearchAll();
      },
      onPickerLoaded(e) {
        this.set('fromToPicker', e.source);
      },
      onSearchAll(){
        //전체조회
        this._onSearchAll();
      },
      onSelectionTabChanged(){
        this._openPopupClose();
        this.set('patientExamItem', null);
        if(!this.get('isShowResultLinkTag') && this.get('isCompLoaded')) {
          //해당탭만 조회
          this._onSearchList();
        }
      },
      onDeletedLinkResultTagClick() {
        this.set('isPickerLoading', true);
        this.set('isCompLoaded', true);
        this.set('model.selectedTabName', 'Specimen');
        if (!this.get('hasRecieveParams')) {
          this.set('hasOtherCompParam', false);
          this.set('otherCompParams', null);
          this.set('model.patientInfoByButton', null);
          this.set('isShowPatientInfo', false);
        }
        this.set('isShowResultLinkTag', false);
        this._getSettingInfo();
      },
      onToggleConditionChanged(type){
        if (type === 'order') {
          this.set('searchCondition.isDeptChecked', false);
        } else {
          this.set('searchCondition.isOrderChecked', false);
        }
        // this._setCondition(type);
        this._refresh();
      },

      getPatientExamListbyFilter(examinationGroup){
        this._patientExaminationList(examinationGroup);
      },

      getSpecimenExamListbyFilter(item){
        if(item=== 'Filter'){
          this._specimenExamfilterSetting();
        }
        this._specimenExaminationList();
      },

      getSpecimenListPaging(){
        this._specimenExaminationList('paging');
      },
      onRefreshClick() {
        this._specimenFilterInit();
        this._patientFilterInit();
        this._specimenExamfilterSetting();
        this._patientExamfilterSetting();
        this._patientExamfilterSetting('Clinic');
        this._onSearchAll();
      },
    },
    //mixin asctions function
    _periodChangedRefresh() {
      this.set('model.isPeriodOpen', false);
      this._refresh();
    },

    _refreshFromOtherComp() {
      this._specimenFilterInit();
      this._patientFilterInit();
      this._specimenExamfilterSetting();
      this._patientExamfilterSetting('Clinic');
      this._totalCount();
    },

    onPatientChanged(Patient){
      this._super(...arguments);
      if(isEmpty(Patient)){
        return;
      }
      if(!isEmpty(this.get('recieveParams'))) {
        return;
      }
      if(this.get('isPopupManagement') === true) {
        return;
      }
      if(this.checkPatientDataClear() === true){
        this.initControl();
        this.initGrid();
        this.set('patientGlobalInformation', null);
      } else {
        if(!isEmpty(this.get('recieveParams'))) {
          return;
        }
        this.set('isPatientChanged', true);
        //같은환자 접근시 재조회 안하도록 변경
        this.initControl();
        this.set('hasOtherCompParam', false);
        this.set('model.selectedTabName', 'Specimen');
        this.set('patientGlobalInformation', Patient);
        this.set('isPickerLoading', true);
        if(isEmpty(this.get('settingInfo')) && this.get('fromToPicker.fixedSlider') === false) {
          this._getSettingInfo();
        } else {
          this._setDefaultSetting(this.get('settingInfo'));
          this._specimenExamfilterSetting();
          this._patientExamfilterSetting('Clinic');
          this._onSearchAll();
        }
      }
    },

    _specimenFilterInit(){
      set(this.get('model'), 'specimenSelectedFilter', {classificationIds: null, status: null});
      set(this.get('model'), 'filterCount', null);
    },

    _patientFilterInit(){
      set(this.get('model'), 'radiologySelectedFilter', {anatomicalSite: emberA(), modality: emberA(), interpretationPart: emberA()});
      set(this.get('model'), 'radiofilterCount', null);
      // set(this.get('model'), 'radiologySelectedFilter', emberA());
      set(this.get('model'), 'clinicfilterCount', null);
      set(this.get('model'), 'clinicSelectedFilter', emberA());
    },

    _onSearchAll(){
      this.set('pacsInfo', null);
      this.set('isPacsViewerDisabled', true);
      this.set('patientExamItem', null);
      if(isEmpty(this.get('patientGlobalInformation')) && !this.get('hasOtherCompParam')){
        return;
      }
      // this._getPacsUrl();
      //전체 건수 조회함수 호출
      this._totalCount();
      //탭별조회
      this._onSearchList();
    },

    initControl(){
      this.set('model.specimenCount', null);
      this.set('model.specimenOriginalCount', null);
      this.set('model.radiologyCount', null);
      this.set('model.clinicCount', null);
      this.set('model.pathologyCount', null);
    },

    initGrid(){
      this.set('model.specimenItemSource', emberA());
      this.set('model.radiologyItemSource', emberA());
      this.set('model.clinicItemSource', emberA());
      this.set('model.pathologyItemSource', emberA());
    },
    _onFilterBySearchAll() {
      this._specimenExamfilterSetting();
      this._patientExamfilterSetting('Clinic');
      this._onSearchAll();
    },

    // _setCondition(item){
    //   let content = '';
    //   if(item === "dept"){
    //     content = this.getLanguageResource('1732', 'S', '내진료과');
    //   }else{
    //     content = this.getLanguageResource('1722', 'S', '내오더');
    //   }
    //   this.set('searchCondition.selectedCondition', {value: item, content: content});
    // },

    _setPeriodType(item){
      //기간이 바뀌면 fromtopicker가 변경되고 onPeriodDateChanged()로 재조회가 진행
      try {
        if(!isEmpty(this.get('fromToPicker')) && this.get('fromToPicker.fixedSlider')) {
          this.set('isPickerLoading', false);
          return;
        }
        const periodConditions = this.setSearchConditionFromToDate(item);
        this.set('model.selectedTickIndex', periodConditions.tickIndex);
        const ticks = this._setPickersTick();
        this.set('ticks', $.extend(true, emberA(), ticks));
        this.set('copyTicks', this.get('ticks'));
        this.set('searchCondition.ticks', ticks);
        this.set('searchCondition.disalbleFromToDate', periodConditions.isDisable);
        this.set('searchCondition.fromDate', periodConditions.fromDate);
        this.set('searchCondition.toDate', periodConditions.toDate);
        later(this, function() {
          if(this.isDestroyed || this.isDestroying) {
            return;
          }
          this.set('searchCondition.isShowSlider', true);
          this.set('isPickerLoading', false);
          // this.setSliderTicksElementStyle();
        });
        if(item !== 'custom'){
          this.set('searchCondition.selectedPeriodType', {value: item, content: periodConditions.content });
          this._specimenFilterInit();
          this._patientFilterInit();
        }else{
          this.set('searchCondition.selectedPeriodType', {value: item, content: null });
        }
      } catch(e) {
        console.log('_setPeriodType Error:::', e);
      }
    },

    _openPopupClose(){
      this.set('model.isSpecimenExamDetailOpen', false);
      this.set('model.clinicDetailOpen', false);
      this.set('model.radiogyDetailOpen', false);
      this.set('model.isPathologyExamDetailOpen', false);
      this.set('model.specimenExamSummaryOpen', false);
    },

    _refresh(){
      if (this.get('searchCondition.selectedPeriodType.value') === 'custom') {
        this.set('customPeriod.fromDate', this.get('searchCondition.fromDate'));
        this.set('customPeriod.toDate', this.get('searchCondition.toDate'));
      }
      if(!this.get('hasRecieveParams')) {
        this.set('hasOtherCompParam', false);
      }
      this.set('model.selectedTabName', 'Specimen');
      this._specimenFilterInit();
      this._patientFilterInit();
      this._specimenExamfilterSetting();
      this._patientExamfilterSetting('Clinic');
      this._onSearchAll();
    },

    async _totalCount(){
      if(isEmpty(this.get('patientGlobalInformation')) && !this.get('hasOtherCompParam')){
        return;
      }
      try {
        this.set('isShowTabLoader', true);
        this.initControl();
        const radiologyParams = this.getPatientExaminationParam('DR');
        const clinicParams = this.getPatientExaminationParam('Clinic');
        const patientPath = this.get('defaultUrl') + 'patient-examination-reports/search-count';
        const specimenParam = this.getSpecimenExaminationParam();
        const specimenPath = this.get('defaultUrl') + 'specimen-examination-reports/search-count';
        const pathologyParam = this.getPathologyExaminationParam();
        const pathologyPath = this.get('defaultUrl') + 'pathology-examination-reports/search-count';
        const [radiologyData, clinicData, specimenData, pathologyData] = await Promise.all([
          await this.getList(patientPath, null, radiologyParams, false),
          await this.getList(patientPath, null, clinicParams, false),
          await this.getList(specimenPath, null, specimenParam, false),
          await this.getList(pathologyPath, null, pathologyParam, false)
        ]);
        const countDatas = {
          radiologyData,
          clinicData,
          specimenData,
          pathologyData
        };
        this.set('isShowTabLoader', false);
        if (this.get('hasOtherCompParam') && this.get('isShowResultLinkTag')) {
          this._setRadiologyAndClinic(countDatas);
          this._getActiveApiCall();
        } else {
          this.set('model.radiologyCount', ' (' + radiologyData + ')');
          this.set('model.clinicCount', ' (' + clinicData+')');
          this.set('model.specimenCount', ' (' + specimenData+')');
          this.set('model.specimenOriginalCount', specimenData);
          this.set('model.pathologyCount', ' ('+ pathologyData +')');
        }
      } catch(e) {
        console.log('_totalCount Error::::', e);
      }
    },

    _setActiveTab(res) {
      if (res.radiologyData !== 0) {
        this.set('model.selectedTabName', 'Specimen');
      } else if(res.specimenData !== 0) {
        this.set('model.selectedTabName', 'Radiology');
      } else if(res.clinicData !== 0) {
        this.set('model.selectedTabName', 'Clinic');
      } else if(res.pathologyData !== 0) {
        this.set('model.selectedTabName', 'Pathology');
      }
      this._onSearchList();
    },

    _setRadiologyAndClinic(res) {
      if (res.radiologyData !== 0) {
        this.set('model.selectedTabName', 'Radiology');
        this.set('model.clinicCount', ' (0)');
      } else if(res.clinicData !== 0) {
        this.set('model.selectedTabName', 'Clinic');
        this.set('model.radiologyCount', ' (0)');
      } else if(res.radiologyData === 0 && res.clinicData === 0) {
        this.set('model.clinicCount', ' (0)');
        this.set('model.radiologyCount', ' (0)');
      }
    },

    _getActiveApiCall() {
      const relayParams = this.get('otherCompParams');
      const isSpacimen = !isEmpty(relayParams.specimenIds);
      const isRadiologyAndClinic = !isEmpty(relayParams.patientExaminationIds);
      const isPathology = !isEmpty(relayParams.pathologyCheckInIds);
      if (isSpacimen) {
        this.set('model.radiologyCount', ' (0)');
        this.set('model.clinicCount', ' (0)');
        this.set('model.pathologyCount', ' (0)');
        this.set('model.selectedTabName', 'Specimen');
      } else if (isRadiologyAndClinic) {
        this.set('model.specimenCount', ' (0)');
        this.set('model.pathologyCount', ' (0)');
      } else if(isPathology) {
        this.set('model.radiologyCount', ' (0)');
        this.set('model.clinicCount', ' (0)');
        this.set('model.specimenCount', ' (0)');
        this.set('model.selectedTabName', 'Pathology');
      }
      this._onSearchList();
    },

    _onSearchList(){
      this.set('isPacsViewerDisabled', true);
      if(isEmpty(this.get('patientGlobalInformation')) && !this.get('hasOtherCompParam')){
        return;
      }
      if(isEmpty(this.get('model.selectedTabName'))) {
        return;
      }
      //초기화
      this.initGrid();
      this._openPopupClose();

      switch (this.get('model.selectedTabName')){
        case 'Specimen':
          this._specimenExaminationList();
          break;
        case 'Radiology':
          this._patientExaminationList('DR');
          break;
        case 'Clinic':
          this._patientExaminationList('Clinic');
          break;
        case 'Pathology':
          this._pathologyExaminationList();
          break;
        default:
          break;
      }
    },

    async _specimenCount(param){
      //paging처리가 추가됨에따라 필터검색시 건수를 별도조회하는 방식으로 변경
      //타 탭은 리스트 조회시 바로 건수 바인딩.
      try {
        const specimenParam = param;
        const specimenPath = this.get('defaultUrl') + 'specimen-examination-reports/search-count';
        const resultCount = await this.getList(specimenPath, null, specimenParam, false);
        this.set('model.specimenCount', ' (' + resultCount+')');
        this.set('model.specimenOriginalCount', resultCount);
        if(resultCount > 100){
          const page = parseInt(resultCount / 100)+1;
          this.set('model.specimenTotalPaging', page);
        }
      } catch(e) {
        this._showError(e);
      }
    },

    async _specimenExaminationList(type){
      try {
        if(isEmpty(this.get('patientGlobalInformation')) && !this.get('hasOtherCompParam')){
          return;
        }
        const params = this.getSpecimenExaminationParam();
        if(type === 'paging'){
          if(this.get('model.specimenTotalPaging') <= this.get('model.specimenPaging')){
            return;
          }
          this.set('model.specimenPaging', this.get('model.specimenPaging') + 1);
          set(params, 'requestRange', this.get('model.specimenPaging'));
        }else{
          this.set('model.specimenItemSource', emberA());
          //건수집계
          this._specimenCount(params);
          this.set('model.specimenPaging', 1);
          set(params, 'requestRange', this.get('model.specimenPaging'));
        }
        // const path = this.get('defaultUrl') + 'specimen-examination-reports/search';
        //API 용량 경량화 관련하여 Back-End Proxy 호출되는 부분을 제거하고 원도메인으로 교체함
        const path = this.get('specimenUrl') + 'diagnostic-report/search';
        this.set('isPageLoader', true);
        const res = await this.getList(path, null, params, false);
        if(!isEmpty(res)){
          res.map(item => {
            //test 용
            // if(index === 0) {
            //   set(item, 'subjectReferenceRange', `0 ~ 0.05  ng/mL\n0.05< ~ <0.5 :국소감염 가능성이 있습니다.  0.5≤ ~ <2.0 :전신감염 가능성이 있습니다.  2.0≤ ~ <10.0 :패혈증 위험성이 높습니다.  10.0 ≤ :패혈증, 패혈증 쇼크의 가능성이 있습니다.`);
            // }
            // const regInfo = this.get('fr_I18nService').formatDate(item.checkInDateTime, 'g')
            //   + ' ['+ item.classification.abbreviation + '] [' + item.specimenType.abbreviation +']';
            const regInfo = `${this.get('fr_I18nService').formatDate(item.checkInDateTime, 'g')}<br>[${item.classification.abbreviation}] [${item.specimenType.abbreviation}]`;
            const recordTitleTooltip = `${this.get('fr_I18nService').formatDate(item.checkInDateTime, 'g')} [${item.classification.abbreviation}] [${item.specimenType.abbreviation}]`;
            item.regInfo = regInfo;
            item.recordTitleTooltip = recordTitleTooltip;
            item.examinationTooltip = this._setExaminationTootip(item.examination.name, item.ordererName, item.reporterName);
            item.isDetailOpen = false;
            item.isPrevDetailOpen = false;
            if(isEmpty(item.flag)){
              item.flag = {displayCode: ""};
            }
            let remarkText = '';
            let orderCommentText = '';
            let recentTooltip = null;
            if(!isEmpty(item.orderComment)) {
              orderCommentText = item.orderComment;
            }
            if(!isEmpty(item.recentDisplayResult)) {
              let recentRemark = '';
              if(!isEmpty(item.recentRemark)) {
                recentRemark = `<br>${item.recentRemark}`;
              }
              recentTooltip = `${this.get('fr_I18nService').formatDate(item.recentCheckInDateTime, 'g')}${recentRemark}`;
            }
            item.recentTooltip = recentTooltip;
            if(!isEmpty(item.subjectReferenceRange) && (item.subjectReferenceRange.indexOf('\n') > -1)) {
              item.subjectReferenceRangeTooltip = item.subjectReferenceRange.replace(/\n|\r\n/giu, '<br>');
              item.isSubjectReferenceRangeIcon = true;
            }
            if(!isEmpty(item.remark)) {
              remarkText = item.remark;
            }
            if(!isEmpty(item.remark) && !isEmpty(item.orderComment)) {
              item.isDisplayIcons = true;
            }
            item.commentText = `${remarkText}  ${orderCommentText}`;
          });
        }
        this.set('model.specimenGridColumns', this.setSpecimenexaminationGridColumns());
        if (type === 'paging'){
          this.get('model.specimenItemSource').pushObjects(this._setItemGroupsIndex(res));
        }else{
          this.set('model.specimenItemSource', this._setItemGroupsIndex(res));
        }
        this.set('model.isValidPaging', true);
        this.set('isPageLoader', false);
      } catch(e) {
        this._showListError(e);
      }
    },
    _setItemGroupsIndex(result) {
      // 접수일 기준선, 보고서형 데이터 셀 내부 오픈 위한 inddex setting
      const itemList = result;
      const groupList = [];
      const returnList = [];
      const dateGroupResult = [];
      if(!isEmpty(itemList)) {
        const grouped = this.groupBy(itemList, item => item.checkInId);
        const uniqList = itemList.uniqBy('checkInId');
        uniqList.forEach((item) => {
          groupList.push(grouped.get(item.checkInId));
        });
        groupList.forEach(items => {
          const itemSize = items.length;
          items.map((item, ind) => {
            // item.displayDateTime = this.get('fr_I18nService').formatDate(item.checkInDateTime, 'g');
            item.stringDate = this.get('fr_I18nService').formatDate(item.checkInDateTime, 'd');
            item.itemIndx = ind;
            item.lastIndex = itemSize - 1;
            returnList.push(item);
          });
        });
        const dateGroupList = [];
        const dateGrouped = this.groupBy(returnList, item => item.stringDate);
        const dateUniqList = itemList.uniqBy('stringDate');
        dateUniqList.forEach((item) => {
          dateGroupList.push(dateGrouped.get(item.stringDate));
        });
        dateGroupList.forEach(items => {
          const itemSize = items.length;
          items.map((item, ind) => {
            item.dateIndex = ind;
            item.lastDateIndex = itemSize - 1;
            dateGroupResult.push(item);
          });
        });
      }
      return dateGroupResult;
    },

    async _patientExaminationList(examinationGroupCode){
      try {
        if(isEmpty(this.get('patientGlobalInformation')) && !this.get('hasOtherCompParam')){
          return;
        }
        if(examinationGroupCode ==='DR'){
          this.set('model.radiologyItemSource', emberA());
        }else{
          this.set('model.clinicItemSource', emberA());
        }
        const params = this.getPatientExaminationParam(examinationGroupCode);
        const path = this.get('defaultUrl') + 'patient-examination-reports/search';
        this.set('isPageLoader', true);
        const result = await this.getList(path, null, params, false);
        if(!isEmpty(result)) {
          result.map(d => {
            d.isRecordOpen = false;
            d.examinationTooltip = this._setExaminationTootip(d.examinationName, d.ordererDisplayName, d.executeStaffName);
          });
        }
        if(examinationGroupCode ==='DR'){
          this.set('model.radiologyItemSource', result);
          this.set('model.radiologyCount', ' (' + result.length + ')');
        }else{
          this.set('model.clinicItemSource', result);
          this.set('model.clinicCount', ' (' + result.length +')');
        }
        this.set('isPageLoader', false);
      } catch(e) {
        this._showListError(e);
      }
    },

    getPatientExaminationParam(examinationGroupCode){
      let departmentId = null;
      let orderedStaffId = null;
      let anatomicalSite = emberA();
      let modality = emberA();
      let interpretationPart = emberA();
      let examinationGroup = emberA();

      const {fromDate, toDate} = this.getSearchDate();

      if(examinationGroupCode === 'DR'){
        if(!isEmpty(this.get('model.radiologySelectedFilter.anatomicalSite'))){
          anatomicalSite = this.get('model.radiologySelectedFilter.anatomicalSite');
        }else if(!isEmpty(this.get('model.radiologySelectedFilter.modality'))){
          modality = this.get('model.radiologySelectedFilter.modality');
        }else if(!isEmpty(this.get('model.radiologySelectedFilter.interpretationPart'))){
          interpretationPart = this.get('model.radiologySelectedFilter.interpretationPart');
        }
      } else if(examinationGroupCode === 'Clinic'){
        if(!isEmpty(this.get('model.clinicSelectedFilter'))){
          examinationGroup = this.get('model.clinicSelectedFilter');
        }
      }

      if(this.get('searchCondition.isOrderChecked')){
        orderedStaffId = this.get('userGlobalInformation.employeeId');
      }
      if(this.get('searchCondition.isDeptChecked')){
        departmentId = this.get('userGlobalInformation.hospital.appointmentDepartmentId');
      }
      let queryParam = {};

      const patientId = this.get('hasRecieveParams') ? this.get('otherCompParams.patientId') : this.get('patientGlobalInformation.patientId');

      queryParam = EmberObject.create({
        patientId: patientId,
        fromDate: fromDate,
        toDate: toDate,
        departmentId: departmentId,
        orderedStaffId: orderedStaffId,
        examinationGroupCode: examinationGroupCode,
        anatomicalSiteCode: anatomicalSite,
        modalityCode: modality,
        interpretationPartCode: interpretationPart,
        examinationGroup: examinationGroup,
      });
      if (this.get('hasOtherCompParam')
        && !isEmpty(this.get('otherCompParams.patientExaminationIds'))
        && this.get('isShowResultLinkTag')) {
        queryParam.fromDate = null;
        queryParam.toDate = null;
        queryParam.patientId = this.get('otherCompParams.patientId');
        queryParam.patientExaminationIds = this.get('otherCompParams.patientExaminationIds');
      } else if(this.get('hasOtherCompParam')
        && isEmpty(this.get('otherCompParams.patientExaminationIds'))
        && this.get('isShowResultLinkTag')) {
        queryParam.patientExaminationIds = [];
        queryParam.patientId = this.get('otherCompParams.patientId');
        this.set('model.radiologyItemSource', emberA());
        this.set('model.clinicItemSource', emberA());
      }

      return queryParam;
    },

    getSpecimenExaminationParam(){
      let departmentId = null;
      let orderedStaffId = null;

      const {fromDate, toDate} = this.getSearchDate();

      const filter = this.get('model.specimenSelectedFilter');
      let classificationIds = null;
      if(!isEmpty(filter.classificationIds)){
        classificationIds = filter.classificationIds;
      }
      let isAbnormalResult = null;
      if(!isEmpty(filter.status)){
        if( filter.status.code === 'Abnormal'){
          isAbnormalResult = true;
        }
      }
      if(this.get('searchCondition.isOrderChecked')){
        orderedStaffId = this.get('userGlobalInformation.employeeId');
      }
      if(this.get('searchCondition.isDeptChecked')){
        departmentId = this.get('userGlobalInformation.hospital.appointmentDepartmentId');
      }

      let queryParam = {};
      const patientId = this.get('hasRecieveParams') ? this.get('otherCompParams.patientId') : this.get('patientGlobalInformation.patientId');

      queryParam = EmberObject.create({
        subjectTypeCode: "Patient",
        subjectId: patientId,
        periodTypeCode: this.get('model.specimenDateType.selectedDateType.value'),
        fromDate: fromDate,
        toDate: toDate,
        departmentId: departmentId,
        orderedStaffId: orderedStaffId,
        isViewUnReportExamination: this.get('model.specimenDateType.isNotReported'),
        isTextResult: null,
        isAbnormalResult: isAbnormalResult,
        isExcludePointOfCare: null,
        classificationIds: classificationIds,
        examinationIds: null,
        requestRange: null,
      });
      const keywordItems = this.get('searchKeywordResultItems');
      if(!isEmpty(keywordItems)) {
        queryParam.examinationIds = keywordItems.map(d => d.specimenExaminationId);
        // queryParam.examinationIds = [keywordItems.specimenExaminationId];
        if(keywordItems.length === 1) {
          queryParam.isOrderable = keywordItems[0].isOrderable;
        }
      }
      if (this.get('hasOtherCompParam')
      && !isEmpty(this.get('otherCompParams.specimenIds'))
      && this.get('isShowResultLinkTag')) {
        queryParam.fromDate = null;
        queryParam.toDate = null;
        queryParam.subjectId = this.get('otherCompParams.patientId');
        queryParam.specimenIds = this.get('otherCompParams.specimenIds');
        queryParam.examinationIds = this.get('otherCompParams.examinationIds');
      } else if (this.get('hasOtherCompParam')
      && isEmpty(this.get('otherCompParams.specimenIds'))
      && this.get('isShowResultLinkTag')) {
        queryParam.specimenIds = [];
        queryParam.examinationIds = [];
        queryParam.specimenIds = this.get('otherCompParams.specimenIds');
        this.set('model.specimenItemSource', emberA());
      }

      this.set('specimenExaminationParam', queryParam);

      return queryParam;
    },

    async _pathologyExaminationList(){
      try {
        if(isEmpty(this.get('patientGlobalInformation')) && !this.get('hasOtherCompParam')){
          return;
        }
        this.set('model.pathologyItemSource', emberA());
        // this.set('model.pathologyCount', null);
        const params = this.getPathologyExaminationParam();
        const path = this.get('defaultUrl') + 'pathology-examination-reports/search';
        this.set('isPageLoader', true);
        const res = await this.getList(path, null, params, false);
        if(!isEmpty(res)) {
          res.map(d => {
            d.isRecordOpen = false;
            d.examinationTooltip = this._setExaminationTootip(d.classificationName, d.ordererDisplayName, d.executeStaffName);
          });
        }
        this.set('model.pathologyItemSource', res);
        if(this.get('isShowResultLinkTag')) {
          this.set('model.pathologyCount', ' ('+ res.length +')');
        }
        this.set('isPageLoader', false);
      } catch(e) {
        this._showListError(e);
      }

    },

    getPathologyExaminationParam(){
      let departmentId = null;
      let orderedStaffId = null;

      const {fromDate, toDate} = this.getSearchDate();

      if(this.get('searchCondition.isOrderChecked')){
        orderedStaffId = this.get('userGlobalInformation.employeeId');
      }
      if(this.get('searchCondition.isDeptChecked')){
        departmentId = this.get('userGlobalInformation.hospital.appointmentDepartmentId');
      }
      let queryParam = {};
      const patientId = this.get('hasRecieveParams') ? this.get('otherCompParams.patientId') : this.get('patientGlobalInformation.patientId');

      queryParam = EmberObject.create({
        patientId: patientId,
        fromDate: fromDate,
        toDate: toDate,
        departmentId: departmentId,
        orderedStaffId: orderedStaffId,
      });
      if (this.get('hasOtherCompParam')
      && !isEmpty(this.get('otherCompParams.pathologyCheckInIds'))
      && this.get('isShowResultLinkTag')) {
        queryParam.fromDate = null;
        queryParam.toDate = null;
        queryParam.patientId = this.get('otherCompParams.patientId');
        queryParam.pathologyCheckInIds = this.get('otherCompParams.pathologyCheckInIds');
      } else if (this.get('hasOtherCompParam')
      && isEmpty(this.get('otherCompParams.pathologyCheckInIds'))
      && this.get('isShowResultLinkTag')) {
        queryParam.patientId = null;
        queryParam.pathologyCheckInIds = [];
        this.set('model.pathologyItemSource', emberA());
      }

      return queryParam;
    },

    async _specimenExamfilterSetting(){
      try {
        this.set('model.specimenFilterItem', emberA());
        if(isEmpty(this.get('patientGlobalInformation')) && !this.get('hasOtherCompParam')){
          return;
        }
        const params = this.getSpecimenExaminationParam();
        set(params, 'classificationIds', null);
        const path = this.get('defaultUrl') + 'specimen-examination-reports/specimen-filter';
        const result = await this.getList(path, null, params, false);
        if(!isEmpty(result)) {
          this.set('model.specimenFilterItem', result);
        }
      } catch(e) {
        console.error(e);
      }
    },

    async _patientExamfilterSetting(item){
      try {
        if(item !=='Clinic'){
          this.set('model.radiologyFilterItem', emberA());
          const radioPath = this.get('defaultUrl') + 'patient-examination-reports/radiology-filter';
          const result = await this.getList(radioPath, null, null, false);
          if(!isEmpty(result)) {
            this.set('model.radiologyFilterItem', result);
          }
        }
        if(isEmpty(this.get('patientGlobalInformation')) && !this.get('hasOtherCompParam')){
          return;
        }
        this.set('model.clinicFilterItem', emberA());
        const clinicParams = this.getPatientExaminationParam('Clinic');
        set(clinicParams, 'examinationGroupCode', null);
        set(clinicParams, 'examinationGroup', []);
        const path = this.get('defaultUrl') + 'patient-examination-reports/clinic-filter';
        const clinicResult = await this.getList(path, null, clinicParams, false);
        if(!isEmpty(clinicResult)) {
          this.set('model.clinicFilterItem', clinicResult);
        }
      } catch(e) {
        console.log('_patientExamfilterSetting Error::', e);
      }
    },

    _getPatientBasicInfo() {
      if (!isEmpty(this.get('model.patientId'))) {
        this.get('demographicService').getPatientBasicIntegration(this.get('model.patientId')).then(_result => {
          if (_result) {
            const patientInfoByButton = `${_result.patientNamePrimary}/${_result.gender.name}/${_result.medicalAge}세`;
            const patientInfoByText = `${_result.patientNamePrimary} (${_result.patientPrivateDisplayId}/${_result.gender.name}/${_result.medicalAge}세)`;
            this.set('model.patientInfoByButton', patientInfoByButton);
            this.set('model.patientInfoByText', patientInfoByText);
            this.set('isShowPatientInfo', true);
          }
        });
      }
    },

    _showListError(e) {
      if(this.isDestroyed || this.isDestroying) {
        return;
      }
      this.set('isPageLoader', false);
      this._showError(e);
    }
  });