/* eslint-disable no-console */
import { isEmpty, isPresent } from '@ember/utils';
import { observer } from '@ember/object';
import { once, later } from '@ember/runloop';
import { A as emberA } from '@ember/array';
import layout from './template';
import CHIS from 'framework/chis-framework';

export default CHIS.FR.Core.ComponentBase.extend({
  chart: null,
  layout,
  actionMode: null,
  chartType: null,
  colorOptions: null,
  yAxisOptions: null,
  customYAxis: null,
  customYAxisOptions: null,
  data: null,
  reload: null,
  selectedItem: null,
  yAxisPosition: null,
  strokeColor: null,
  strokeWidth: null,
  symbolColor: null,
  symbolSize: null,
  symbolType: null,
  symbolTypeOptions: null,
  selectedExaminationData: null,
  newSeries: null,
  removeSeriesNo: null,
  multiLineData: null,
  isShowLegend: true,
  axisViewMode: null,
  containerClass: null,
  leftScrollPosition: null,
  prop1: null,
  prop2: null,
  barRange: null,

  positionChanged: observer('prop1', 'prop2', function() {
    once(this, 'chartMove');
  }),
  axisViewModeChanged: observer('chartAxisViewMode', function() {
    this.set('axisViewMode', this.get('chartAxisViewMode'));
    this.set('actionMode', 'update');
  }),

  onPropertyInit() {
    this._super(...arguments);
    this.set('viewId','test-result-viewer-specimen-examination-chart');
    console.log('test-result-viewer-specimen-examination-chart.onPropertyInit()');
    this.setStateProperties([
      'actionMode', 'chartType', 'chartTypeOptions',
      'colorOptions', 'yAxisOptions', 'customYAxis', 'customYAxisOptions',
      'data', 'reload', 'selectedItem', 'strokeColor', 'strokeWidth', 'symbolColor', 'symbolSize',
      'symbolType', 'symbolTypeOptions', 'selectedExaminationData',
      'chartTimePointer', 'chart', 'c3Data', 'size', 'legend','multiLineData', 'legendPosition','lineWidth', 'lineHeight',
      'legendWidth'
    ]);

    if (this.hasState()===false) {
      // this._setLineChart();
      this.set('actionMode', null);
      this.set('lineWidth', '770');
      this.set('lineHeight', '290');
      this.set('chartType', 'line');
      // this.set('axisViewMode', 'auto');
      // this.set('axisViewMode', 'auto');
      this.set('containerClass', '');
    }
  },

  onLoaded() {
    this._super(...arguments);
    if(!isEmpty(this.get('chartWidth'))) {
      this.set('lineWidth', this.get('chartWidth'));
    }
    if(!isEmpty(this.get('charHeight'))) {
      this.set('lineHeight', this.get('charHeight'));
    }
    if(!isEmpty(this.get('chartAxisViewMode'))) {
      this.set('axisViewMode', this.get('chartAxisViewMode'));
      // console.log('axisViewMode------', this.get('chartAxisViewMode'));
    } else {
      this.set('axisViewMode', 'auto');
    }
    if(!this.get('isSync')) {
      this.set('containerClass', 'sync-container');
    }
    this.set('actionMode', 'update');
    if(!isEmpty(this.get('selectedExaminationData'))) {
      this._setLineChart();
    }
    if(!isEmpty(this.get('multiLineData'))) {
      this._setLineChart();
    }
  },

  didInsertElement(){
    this._super(...arguments);
  },

  didRender() {
    this._super(...arguments);
    let chartEl = document.getElementById(this.get('chartComponent.elementId'));
    if(isPresent(chartEl.getElementsByClassName('selection'))) {
      chartEl.getElementsByClassName('selection')[0].setAttribute('fill', 'none');
      chartEl.getElementsByClassName('selection')[0].setAttribute('cursor', 'unset');
    }
    if(isPresent(chartEl.getElementsByClassName('overlay'))) {
      chartEl.getElementsByClassName('overlay')[0].style.display = 'none';
    }
    if(isPresent(chartEl.getElementsByClassName('handle--w'))) {
      chartEl.getElementsByClassName('handle--w')[0].style.display = 'none';
    }
    if(isPresent(chartEl.getElementsByClassName('handle--e'))) {
      chartEl.getElementsByClassName('handle--e')[0].style.display = 'none';
    }
    if(isPresent(chartEl.getElementsByClassName('handle--custom'))) {
      chartEl.getElementsByClassName('handle--custom')[0].style.display = 'none';
      chartEl.getElementsByClassName('handle--custom')[1].style.display = 'none';
    }
    chartEl = null;
    console.log('chart-sample.didRender()');
  },

  didUpdateAttrs() {
    this._super(...arguments);
    // this.set('actionMode', 'update');
    this._setLineChart();
  },
  didReceiveAttrs() {
    this._super(...arguments);
  },

  willDestroyElement() {
    this._super(...arguments);
    console.log('willDestroyElement()');
  },

  actions: {
    _getCustomYAxis(prefix, count) {
      const result = emberA();

      for(let i = 0; i < count; i++) {
        result.pushObject(prefix + i);
      }

      return result;
    },

    _getSigleSeriesData(type, requireTimeData) {
      const propertyX = this.get('_dataPropertyX');
      const propertyY = this.get('_dataPropertyY');
      let seriesData = null;
      const tooltipTemplate = '<div style=\'text-align: center;padding: 2px;font: 12px sans-serif;background: lightsteelblue;border: 1px;border-radius: 8px;pointer-events: none;\'>{{tweets}}</div>';

      if(type === 'line') {
        const obj = {
          dropdownData: this._getDropdownData(),
          xAxisProperty: propertyX,
          yAxisProperty: propertyY,
          yAxisPosition: this.get('yAxisPosition'),
          tooltipProperty: propertyY,
          tooltipTemplate: tooltipTemplate
        };
        if(requireTimeData) {
          seriesData = this._addTimeLineSeries(obj);
        } else {
          seriesData = this._addLineSeries(obj);
        }
      }

      return seriesData;
    },
    onChartLoaded(e) {
      this.set('chartComponent', e.source);
    },
    onChartMoved(e) {
      // console.log('onChartMoved--', e);
      // console.log('onChartMoved--', e.selection[1]-e.selection[0]);
      if(isPresent(this.get('barRange')) && this.get('barRange') !== e.selection[1]-e.selection[0]) {
        // this.get('chartComponent').moveBrush([this.get('prop1'), this.get('barRange')+this.get('prop1')]);
      }
    }
  },

  chartMove() {
    // if(this.get('axisViewMode') === 'auto') {
    //   return;
    // }
    if(isEmpty(this.get('prop2'))) {
      return;
    }
    if(this.get('lineWidth') - 20 < this.get('prop2')) {
      return;
    }
    this.get('chartComponent').moveBrush([this.get('prop1'), this.get('prop2')]);
  },

  _setLineChart(){
    try {
      const lineChart = {};
      // const today = this.get('co_CommonService').getNow();
      lineChart.xAxisOrient = 'bottom';
      lineChart.yAxisOrient = 'left';
      lineChart.tooltipSize = 1;
      lineChart.isSortedData = false;
      lineChart.isGroupLegend = false;
      lineChart.isCollapsibleLegend = false;
      lineChart.isCollapseLegendPane = false;
      lineChart.isCustomYAxis = false;
      lineChart.isTimeXAxis = false;
      lineChart.readOnly = true;
      lineChart.legendPosition = isEmpty(this.get('legendPosition')) ? 'bottom' : this.get('legendPosition');
      // lineChart.timeDomain = [today.addMonths(-24), today.addMonths(12)];
      if(isPresent(this.get('legendWidth'))) {
        lineChart.legendWidth = this.get('legendWidth');
      }
      if(isPresent(this.get('legendPadding'))) {
        lineChart.legendPadding = this.get('legendPadding');
      }
      lineChart.timeFormat = emberA();
      const format = {};
      format.xAxisTickFormat = emberA();
      if(isPresent(this.get('customXAxisTickFormat'))) {
        lineChart.customXAxisTickFormat = this.get('customXAxisTickFormat');
      }
      let temp = {};
      temp = {};
      temp.type = 'minute';
      temp.format = '%p %I';
      format.xAxisTickFormat.pushObject(temp);
      lineChart.timeFormat.pushObject({dataFormat: 'f', xAxisTickFormat: format.xAxisTickFormat});
      lineChart.series = emberA();
      if(!isEmpty(this.get('multiLineData'))) {
        const multiArr = this.get('multiLineData');
        multiArr.forEach((data, index) => {
          if(!isEmpty(data)) {
            lineChart.series.pushObject(this._lineSeries(data, index+1));
          }
        });
      } else if(!isEmpty(this.get('selectedExaminationData'))){
        lineChart.series.pushObject(this._lineSeries());
      }
      if(isEmpty(this.get('selectedExaminationData')) && isEmpty(this.get('multiLineData'))) {
        this.set('actionMode', null);
        this.set('lineData', null);
      } else {
        this.set('actionMode', 'update');
        this.set('lineData', lineChart);
      }
      if(this.get('addSeriesCB')) {
        this.get('addSeriesCB')(lineChart.series);
      }
      later(() => {
        if(this.isDestroyed || this.isDestroying) {
          return;
        }
        this.chartMove();
      });
    }catch(e) {
      console.log('_setLineChart error', e);
    }
  },

  _lineSeries(multidata, index){
    try {
      const resultLanguageResource = this.getLanguageResource('890', 'S', '', '결과');
      // const tooltipTemplate = '<div style=\'text-align: center;padding: 2px;font: 12px sans-serif;background: lightsteelblue;border: 1px;border-radius: 8px;pointer-events: none;\'>{{chartDisplayResult}}</div>';
      let tooltipTemplate = '<div class=\'wrap-balloon type-btm\'><div class=\'balloon\'><div>'+this.getLanguageResource('16890', 'S', '', '검사일')+' : {{displayDate}}</div><div style=\'text-align: left;\'>'+resultLanguageResource+' : {{chartDisplayResult}}</div></div></div>';
      if(isEmpty(this.get('xAxisProp')) || isPresent(this.get('tooltipDate'))) {
        tooltipTemplate = '<div class=\'wrap-balloon type-btm\'><div class=\'balloon\'><div>'+this.getLanguageResource('9946', 'S', '', '검사일시')+' : {{displayDateTime}}</div><div style=\'text-align: left;\'>'+resultLanguageResource+' : {{chartDisplayResult}}</div></div></div>';
      }
      if(isEmpty(this.get('selectedExaminationData')) && isEmpty(this.get('multiLineData'))) {
        return;
      }
      let examinationName = null;
      if(!isEmpty(this.get('selectedExaminationData'))) {
        examinationName = this.get('selectedExaminationData').get('firstObject').examination.name;
      }
      const defaultColor = '#5c879e';
      const lineSeriesConfig = {
        no: isEmpty(multidata) ? 1 : index,
        name: isEmpty(multidata) ? examinationName : multidata[0].examination.name,
        //#6495ED, #5c879e #0719b2
        config: {
          type: 'line',
          xAxisProperty: isEmpty(this.get('xAxisProp')) ? 'displayDateTime' : this.get('xAxisProp'),
          yAxisProperty: 'chartDisplayResult',
          yAxisPosition: 1,
          labelProperty: 'chartDisplayResult',
          strokeColor: isEmpty(multidata) ? defaultColor : multidata[0].color,
          strokeWidth: 1,
          symbolSize: 2,
          symbolColor: isEmpty(multidata) ? defaultColor : multidata[0].color,
          symbolType: 'material-icons-fiber_manual_record',
          // symbolType: 'material-icons-star',
          tooltipProperty: null,
          tooltipTemplate: tooltipTemplate,
          noDisplaySymbol: false,
          groupLegendNo: 1,
          isCustomYAxis: isEmpty(this.get('customYAxisValue')) ? false : true,
          isSelectSymbol: false,
          isSelectLegend: true,
          interpolateNulls: true,
          yAxis: this.get('customYAxisValue'),
          // 'radious':400,
        },
        data: isEmpty(multidata) ? this.get('selectedExaminationData') : multidata
      };
      return lineSeriesConfig;
    } catch(e) {
      console.log('_lineSeries error', e);
    }
  },
  _addSeries() {
    // this.set('actionMode', 'add');
    // if(!isEmpty(this.get('selectedExaminationData'))) {
    //   // const lineData = this.get('lineData');
    //   // const strArray = lineData.series;

    //   // const findDuplicates = (arr) => arr.filter((item, index) => arr.indexOf(item) != index);

    //   // console.log(findDuplicates(strArray));
    //   this.set('newSeries', this._lineSeries());
    //   if(this.get('addSeriesCB')) {
    //     this.get('addSeriesCB')(this.get('lineData.series'));
    //   }
    //   // this._removeSeries();
    // }
    const multiArr = this.get('multiLineData');
    multiArr.forEach((data, index) => {
      if(index !== 0) {
        this.set('actionMode', 'add');
        this.set('newSeries', this._lineSeries(data, index+1));
      }
    });
  },
  _removeSeries() {
    // const seriesNo = this.get('seriesNo');
    // const lineData = this.get('lineData');
    // lineData.series.forEach(data => {
    //   if(data.name === this.get('selectedExaminationData.examination.name')) {
    //     this.set('actionMode', 'remove');
    //     this.set('removeSeriesNo', data.no);
    //   }
    // });
    this.set('removeSeriesNo', this.get('removeSeriesNo'));
  },
});
