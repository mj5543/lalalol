/* eslint-disable no-console */
/* eslint-disable chis/avoid-memory-leak */
import { inject as service } from '@ember/service';
import { isEmpty, isPresent } from '@ember/utils';
import { set, observer } from '@ember/object';
import layout from './template';
import { later } from '@ember/runloop';
import CHIS from 'framework/chis-framework';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  {
    layout,
    model: null,
    searchPatientId: null,
    isTestResultViewerOpen: false,
    isModalOpen: false,
    isComponentVisibility: false,
    isShowContentLoader: false,
    isPopupOpen: false,
    dataLoadCompleted: false,
    demographicService: service('patient-demographic-service'),

    patientIdChanged: observer('searchPatientId', function() {
      this._getPatientBasicInfo();
    }),

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId','test-result-viewer-management-by-popup');

      this.setStateProperties([
        'model',
        'patientInformation'
      ]);

      if(this.hasState()===false) {
        this.set('model', {
          patientName: null,
          patientInfoByText: null,
        });
      }
      this.set('patientGlobalInfo', this.get('co_PatientManagerService.selectedPatient'));
    },

    onLoaded() {
      this._super(...arguments);
      // this.set('menuClass', 'w680');
      if (isEmpty(this.get('verticalOffset'))) {
        this.set('verticalOffset', 2);
        this.set('horizontalOffset', 0);
      }
      if (isEmpty(this.get('attachment'))) {
        this.set('attachment', 'middle center');
      }
      if (isEmpty(this.get('targetAttachment'))) {
        this.set('targetAttachment', 'middle center');
      }
      if(!this.get('isModalOpen')) {
        this.set('isPopupOpen', true);
      }
      this._getPatientBasicInfo();
    },

    onPatientChanged(Patient){
      this._super(...arguments);
      if(isEmpty(Patient)){
        return;
      }
      if(this.checkPatientDataClear() === true) {
        this.set('isTestResultViewerOpen', false);
      }
      this.set('patientGlobalInfo', Patient);
    },

    actions: {
      onPopupOpend() {
        const patientInformation = this.get('patientInformation');
        if(!this.get('dataLoadCompleted') && isPresent(patientInformation) && patientInformation.patientId === this.get('searchPatientId')) {
          this.set('isComponentVisibility', true);
          this.get('co_ContentMessageService').sendMessage('popup_management_init');
        }
      },
      onManagementPopupClosed() {
        this.set('isComponentVisibility', false);
        this.set('dataLoadCompleted', false);
      },
    },
    async _getPatientBasicInfo() {
      try {
        if(isEmpty(this.get('searchPatientId'))) {
          return;
        }
        this.set('isShowContentLoader', true);
        this.set('patientInformation', {patientId: this.get('searchPatientId'), patientDisplayId: null});
        const _result = await this.get('demographicService').getPatientBasicIntegration(this.get('searchPatientId'));
        if (_result) {
          const patientInfoByText = `(${_result.patientPrivateDisplayId}/${_result.gender.name}/${_result.medicalAge}${this.getLanguageResource('3703', 'F', '', '세')})`;
          set(this.get('patientInformation'), 'patientDisplayId', _result.patientPrivateDisplayId);
          let encounterClassCode = _result.nearEncounterClassCode;
          if(!this.get('isModalOpen')) {
            encounterClassCode = this.get('patientGlobalInfo.encounterClassCode');
          }
          set(this.get('patientInformation'), 'encounterClassCode', encounterClassCode);
          this.set('model.patientName', _result.patientNamePrimary);
          this.set('model.patientInfoByText', patientInfoByText);
        }
        this.get('co_ContentMessageService').sendMessage('popup_management_init');
        this.set('dataLoadCompleted', true);
        later(() => {
          if(this.isDestroyed || this.isDestroying) {
            return;
          }
          this.set('isComponentVisibility', true);
          this.set('isShowContentLoader', false);
        });
      } catch(e) {
        if(this.isDestroyed || this.isDestroying) {
          return;
        }
        console.log('_getPatientBasicInfo Error::::', e);
      }
    },

  });