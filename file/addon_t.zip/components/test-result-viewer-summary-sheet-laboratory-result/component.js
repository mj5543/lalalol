/* eslint-disable max-lines */
/* eslint-disable no-console */
import moment from 'moment';
// import $ from 'jquery';
import { next } from '@ember/runloop';
import { A as emberA } from '@ember/array';
import { isEmpty, isPresent } from '@ember/utils';
import EmberObject, { set, get } from '@ember/object';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'testresultviewer-module/app-config';
import TestResultViewerMixin from '../../mixins/test-result-viewer-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  TestResultViewerMixin,
  {
    layout,
    model: null,
    defaultUrl: null,
    searchCondition: null,
    parentSearchCondition: null,
    selectedExaminationIds: null,
    patientGlobalInformation: null,
    specimenSummaryResult: null,
    isSpecimenExamSummaryOpen: false,
    gridItemsSource: null,
    gridColumns: null,
    selectedExaminationData: null,
    isPopupToggleDisabled: false,
    isPopupChecked: false,
    chartTimePointer: null,
    actionMode: null,
    isValidPaging: true,
    customHeaders: null,
    isChangedPopupCondition: null,
    specimenExamSummaryParams: null,
    patientId: null,
    periodType: null,
    specimenExaminationParam: null,
    examinationIds: null,
    placementTarget: null,
    attachment: null,
    targetAttachment: null,
    popupOption: null,
    cellDetailTarget: null,
    isDisabledImgViewer: true,
    verticalOffset: null,
    horizontalOffset: null,
    isPopoverFirstOpen: true,
    currentOnClassElement: null,
    isShowLoader: false,
    multiListData: null,
    customYAxisValue: null,
    isResultPopupOpen: false,
    isPopup: false,
    isChartReady: false,
    isChartInvalid: false,
    isFirstLoaded: true,
    isShowEmpty: false,
    //강민주책임님 휴가중이셔서 대신 작업합니다. - 2019-09-10 유재광
    examinationIdArray: null,
    parseResult: null,
    fromToPicker: null,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId','test-result-viewer-summary-sheet-laboratory-result');

      this.setStateProperties([
        'model',
        'defaultUrl',
        'searchCondition',
        'parentSearchCondition',
        'selectedExaminationIds',
        'patientGlobalInformation',
        'specimenSummaryResult',
        'isSpecimenExamSummaryOpen',
        'gridItemsSource',
        'selectedExaminationData',
        'isPopupToggleDisabled',
        'isPopupChecked',
        'chartTimePointer',
        'actionMode',
        'customHeaders',
        'isChangedPopupCondition',
        'customPeriod',
        'fromToPicker',
        'gridControl',
        'isExpanded',
        'ticks',
        //강민주책임님 휴가중이셔서 대신 작업합니다. - 2019-09-10 유재광
        'examinationIdArray',
        'dateMaxNumbers',
        'filterItems'
      ]);

      if(this.hasState()===false) {
        const defaultUrl = this.get('fr_HostConfigService')
          .getEnvConfig('ServerCallConfig', 'testresultviewer') +
          `test-result-viewer/${config.version}/`;

        this.set('defaultUrl', defaultUrl);
        if(!isEmpty(this.get('co_CurrentUserService.user'))){
          this.set('userGlobalInformation', this.get('co_CurrentUserService.user'));
        }
        if(!isEmpty(this.get('co_PatientManagerService.selectedPatient'))){
          this.set('patientGlobalInformation', this.get('co_PatientManagerService.selectedPatient'));
        }
        this.set('model',{
          isByPeriodOpen: false,
          isPopupSpecimen: false,
          listBoxSpecimen: emberA(),
          patientId: null,
          selectedGridItem: null,
          selectedGridItems: null,
          limitCount: null,
          selectedTickIndex: null,
        });

        this.set('searchCondition', EmberObject.create({
          selectedDateType: {value: 'CheckIn', content: this.getLanguageResource('12682', 'S', '접수일별')},
          isNotReported: false,
          selectedPeriodType:{value: null, content: null},
          fromDate: null,
          toDate: null,
          disalbleFromToDate: true,
        }));
        this.set('customPeriod', emberA({
          fromDate: null,
          toDate: null,
        }));
        // this.set('model.selectedTickIndex', 1);
        const now = this.get('co_CommonService').getNow();
        this.set('searchCondition.fromDate', this.get('co_CommonService').getNow().addDays(-7));
        this.set('searchCondition.toDate', now);
      }

      this.set('gridColumns', [
        { field: 'examination.abbreviation', title: this.getLanguageResource('10011', 'S', '검사명'), width:120, locked: true},
        { field: 'subjectReferenceRange', title: this.getLanguageResource('10109', 'S', '참고치') },
      ]);
      this.set('gridContext', emberA([
        EmberObject.create({ action : this.actions.sendToRecord.bind(this), text : this.getLanguageResource('1498', 'S', '기록으로 보내기'), alias: 'report', disabled : false, display : true}),
      ]));

      this.set('selectedExaminationData', emberA());
      this.set('gridItemsSource', emberA());
      this.set('isChangedPopupCondition', false);
      this.set('isExpanded', false);
      this._setTagList();
      this.set('periodTypeItems', this.periodTypeList());
      // this._setPeriodType('1w');
    },

    onLoaded() {
      this._super(...arguments);
      this.set('specimenDateType', this.get('searchCondition'));
      console.log('onLoaded---', this.get('parameters'));
      if(!isEmpty(this.get('parameters'))) {
        if(this.get('parameters.outbounds.isPopup')) {
          this.set('searchCondition.fromDate', this.get('parameters.arguments.commons.period.fromDate'));
          this.set('searchCondition.toDate', this.get('parameters.arguments.commons.period.toDate'));
          this.set('model.selectedTickIndex', this.get('parameters.arguments.commons.period.tickIndex'));
          const ticks = this._setPickersTick();
          this.set('ticks', ticks);
          this.set('isPopup', true);
          this.set('chartWidth', 874);
          this.set('isChartReady', true);
        } else {
          //강민주책임님 휴가중이셔서 대신 작업합니다. - 2019-09-10 유재광
          // this.set('examinationIdArray', ['GUID_L2001', 'GUID_L2002', 'GUID_L2003', 'GUID_L3041', 'GUID_L3014', 'GUID_L3015']);

          // const periodType= isEmpty(this.get('specimenExaminationParam')) ? '3y' : this.get('periodType');
          // this._setPeriodType('1w');
          this._setDefaultPeriod();
          this.set('model.limitCount', this.get('parameters.outbounds.searchLimitCount'));
          this.set('parameters.inbounds.reloadFunction', this._summaryResult);
          this._setArgumentsCommons();
        }
        this.set('model.patientId', this.get('parameters.outbounds.patientId'));
      }
      // this.set('model.patientId', 'a6daf6ba-2ef7-4d14-9cfc-2ad47b027f06');
      this._summaryResult();
    },
    _setDefaultPeriod() {
      if (this.get('patientGlobalInformation') && this.get('patientGlobalInformation.encounterClassCode') === 'I') {
        this._setPeriodType('2w');
      } else {
        this._setPeriodType('3m');
      }
    },

    didReceiveAttrs() {
      this._super(...arguments);
      // console.log('didReceiveAttrs---', this.get('parameters'));
    },
    didUpdateAttrs() {
      this._super(...arguments);
      // console.log('didUpdateAttrs---', this.get('parameters'));
    },
    didRender() {
      this._super(...arguments);
      if(!isEmpty(this.get('fromToPicker'))) {
        this.setSliderTicksElementStyle(this.get('fromToPicker'));
        // const selectedTickIndex = this.get('fromToPicker.selectedTickIndex');
        // if(this.get('model.selectedTickIndex') !== selectedTickIndex) {
        //   const currentType = this.get('periodTypeItems').find(d => d.index === selectedTickIndex);
        //   if(!isEmpty(currentType)) {
        //     const currentTick = this.get('ticks').find(d => d.value === currentType.value);
        //     // this.set('searchCondition.selectedPeriodType', {value: currentType.value, content: currentType.content });
        //     if(selectedTickIndex === 8) {
        //       this.set('searchCondition.fromDate', null);
        //       this.set('searchCondition.toDate', null);
        //     } else if(!isEmpty(currentTick)) {
        //       this.set('searchCondition.fromDate', currentTick.fromDate);
        //       this.set('searchCondition.toDate', currentTick.toDate);
        //     }
        //   }
        //   this.set('model.selectedTickIndex', selectedTickIndex);
        //   if(!this.get('isPopup')) {
        //     this._setArgumentsCommons();
        //   }
        //   this._summaryResult();
        // }
      }
      if(!this.get('isPopup')) {
        let currentElement = this.element;
        this.set('chartWidth', currentElement.offsetWidth);
        this.set('chartHeight', currentElement.offsetHeight/4);
        this.set('isChartReady', true);
        currentElement = null;
      }
    },

    actions: {
      onSilderUpdated(e) {
        console.log('onSilderUpdated--', e);
      },
      sendToRecord(){
        this._getCopyTableContent(this.get('gridControl.selectedItems'));
      },
      onFromToPickerLoaded(e) {
        this.set('fromToPicker', e.source);
      },
      onUpdateDate(e) {
        console.log('onUpdateDate--', e);
        // const selectedTickIndex = e.source.selectedTickIndex;
        // if(!this.get('isPopup')) {
        //   this.set('model.selectedTickIndex', selectedTickIndex);
        //   this._setArgumentsCommons();
        // }
        // if(selectedTickIndex === 8) {
        //   this.set('searchCondition.fromDate', null);
        //   this.set('searchCondition.toDate', null);
        // }
        if(!this.get('isPopup')) {
          if(!isEmpty(e.source.selectedFromDate)) {
            const selectedFromDate = moment(e.source.selectedFromDate).format('YYYY-MM-DD');
            const changedItem = this.get('ticks').find(d => moment(d.fromDate).format('YYYY-MM-DD') === selectedFromDate);
            if(!isEmpty(changedItem)) {
              this.set('model.selectedTickIndex', changedItem.index);
            }
          } else {
            this.set('model.selectedTickIndex', 8);
          }
          this._setArgumentsCommons();
        }
        this._summaryResult();
      },
      onExpandComplete() {
        //
      },
      onCollapseComplete() {
        //
      },
      onOpenResultPopup() {
        this.set('isResultPopupOpen', true);
      },
      onAddSeriesCallback(result) {
        if(this.get('isChartInvalid') === true && result.length === 15) {
          this.get('apiService').onDisplayMessage('warning', '15항목 이상 선택할 수 없습니다.', '', 'Ok', 'Ok', 1000);
          this.set('isChartInvalid', false);
        }
      },
      onGridLoaded(e) {
        this.set('gridControl', e.source);
      },
      onPickerLoaded(e) {
        this.set('fromToPicker', e.source);
      },
      onPopupOpend() {
        this.set('model.patientId', this.get('patientId'));
        const periodType= isEmpty(this.get('specimenExaminationParam')) ? '3y' : this.get('periodType');
        this._setPeriodType(periodType);
        this._summaryResult();
      },
      onChangedPopupSelectedItem(e){
        const gridComponent = e.source;
        this.set('selectedExaminationData', null);
        if(e.selectedItems.length > 15 && this.get('gridItemsSource').length === e.selectedItems.length) {
          gridComponent.deselectAll();
          this.get('apiService').onDisplayMessage('warning', '15항목 이상 선택할 수 없습니다.', '', 'Ok', 'Ok', 1000);
          return;
        }
        this.set('model.selectedGridItems', e.selectedItems);
        next(this, function () {
          try{
            const multiListData = this._getMultiLineData();
            if(!isEmpty(multiListData) && multiListData.length > 15) {
              this.set('isChartInvalid', true);
              gridComponent.deselectRow(gridComponent.selectedItem);
              return;
            }
            // if(isEmpty(multiListData)) {
            //   this.set('isExpanded', false);
            // } else {
            //   this.set('isExpanded', true);
            // }
            this.set('multiListData', multiListData);
          } catch(err) {
            console.log('not Complete!!::', err);
          }
        }.bind(this));
      },

      onCellClickItem(e) {
        // console.log('onCellClickItem--', e);
        const filedArr = e.column.field.split('.');
        const selectedItem = e.item;
        const targetItem = selectedItem[filedArr[0]];
        if(isEmpty(targetItem)) {
          return;
        }
        this.set('cellDetailTarget', `#${e.originalSource.parentView.parentView.parentView.elementId}`);
        if (targetItem.recoredNoteId && targetItem.isTextRecordNoteResult === true) {
          set(targetItem, 'isDetailOpen', false);
          this.set('isSpecimenExamDetailOpen', true);
          this.set('detailView', EmberObject.create({
            title: targetItem.examination.abbreviation,
            recordNoteId: targetItem.recoredNoteId,
            examinationId: targetItem.examination.id
          }));
        }

      },
      onDetailViewClosed(){
        set(this.get('detailView'), 'title', null);
        set(this.get('detailView'), 'recordNoteId', null);
        set(this.get('detailView'), 'examinationId', null);
      },
      onPopupClose() {
        this.set('isPopupToggleDisabled', false);
        this.set('isPopupChecked', false);
        this.set('selectedExaminationData', []);
        this.set('gridItemsSource', null);
        this.set('isChangedPopupCondition', false);
        this.set('examinationIds', emberA());
        // this.set('selectedExaminationIds', emberA());
        if(!isEmpty(this.get('model.patientId'))) {
          this.set('model.patientId', null);
        }
      },
      onPeriodTypeChanged(type, e){
        this.set('isPopoverFirstOpen', false);
        //기간선택시 체크표기 class 적용위함
        e.originalEvent.target.parentElement.parentElement.childNodes.forEach(item => {
          if(item.tagName === 'LI'){
            item.children[0].classList.remove('on');
          }
        });
        e.originalEvent.target.classList.add('on');
        this._setPeriodType(type);
        if (this.get('searchCondition.selectedPeriodType.value') === 'custom') {
          this.set('searchCondition.fromDate', null);
          this.set('searchCondition.toDate', null);
        } else {
          this.set('model.isByPeriodOpen', false);
          this.set('customPeriod.fromDate', null);
          this.set('customPeriod.toDate', null);
        }
      },

      onPeriodDateChanged(e){
        if(isEmpty(this.get('searchCondition.fromDate')) || isEmpty(this.get('searchCondition.toDate'))){
          return;
        }
        if (this.get('customPeriod.fromDate') === e.selectedFromDate && this.get('customPeriod.toDate') === e.selectedToDate) {
          return;
        }

        if(this.get('searchCondition.selectedPeriodType.value') === 'custom'){
          this.set('searchCondition.selectedPeriodType.content'
            , this.get('fr_I18nService').formatDate(this.get('searchCondition.fromDate'), 'd')+ ' ~ ' + this.get('fr_I18nService').formatDate(this.get('searchCondition.toDate'), 'd'));
          this._setTagList();
          if (this.get('customPeriod.fromDate') !== e.selectedFromDate || this.get('customPeriod.toDate') !== e.selectedToDate) {
            const picker = this.get('fromToPicker');
            set(picker, 'isOpen', false);
            this.set('model.isByPeriodOpen', false);
          }
        }
        this.set('isChangedPopupCondition', true);
        this._summaryResult();
      },

      onDeletedTagClick(item) {
        this.set('isChangedPopupCondition', true);

        if (item.type == 'periodType' && this.get('searchCondition.selectedPeriodType.value') == item.code) {
          this.set('searchCondition.selectedPeriodType', EmberObject.create({value: null, content: null}));
          this.set('searchCondition.fromDate', null);
          this.set('searchCondition.toDate', null);
        }
        this.set('gridItemsSource', emberA());
        this._setTagList();
        this._summaryResult();
      },
      onRefreshClick() {
        this._summaryResult();
      },
    },

    _getMultiLineData() {
      this.set('customYAxisValue', null);
      const list = this.get('model.selectedGridItems');
      const tempArr = [];
      const chartValue = [];
      list.forEach(item => {
        const result = this._getChartData(item);
        if(!isEmpty(result)) {
          result.map(d => {
            chartValue.push(d.chartDisplayResult);
          });
          tempArr.push(result);
        }
      });
      if(tempArr.length > 1 && !isEmpty(chartValue)) {
        const max = chartValue.reduce( function (previous, current) {
          return previous > current ? previous:current;
        });
        const min = chartValue.reduce( function (previous, current) {
          return previous > current ? current:previous;
        });
        const targetLength = 6;
        const avg = max/targetLength;
        let targetValue = 0;
        const axisValue = [];
        for(let i=1; targetLength+1> i; i++) {
          if(i === 1) {
            targetValue = avg + min;
            axisValue.push(Math.floor(min*10)/10);
            axisValue.push(Math.floor(targetValue*10)/10);
          } else {
            axisValue.push(Math.floor(((avg*i)+min)*10)/10);
          }
        }
        this.set('customYAxisValue', axisValue);
        // console.log('max::', max, 'min::', min, 'avg::', avg);
      }
      return tempArr;
    },

    _getChartData(item){
      const dataList = this.get('filterItems');
      const targetData = emberA();
      const tmpData = [];
      const xAxisTicks = [];

      if (dataList && dataList.length > 0) {
        dataList.forEach(data => {
          if(data.examination && data.examination.id === item.examination.id && data.chartDisplayResult !== ''){
            targetData.pushObject(data);
          }
        });
        if(isPresent(targetData)) {
          const gridColumns = this.get('gridColumns');
          gridColumns.forEach((d, index) => {
            if(index === 0 || index === 1) {
              return;
            }
            const titleDate = this.get('fr_I18nService').formatDate(d.title, 'd');
            const findItem = targetData.find(data => data.displayDate === d.title.toString());
            if(isPresent(findItem)) {
              tmpData.push(findItem);
            } else if(isEmpty(findItem)){
              const tempItem = {
                chartDisplayResult: null,
                displayDate: titleDate,
                displayDateTime: this.get('fr_I18nService').formatDate(d.title, 'G'),
                examination: targetData[0].examination,
                color: targetData[0].color,
              };
              tmpData.push(tempItem);
            }
            xAxisTicks.push(titleDate);
          });
        }
      }
      return tmpData;
    },

    _setTagList() {
      const newConditionList = [];

      this.set('tagList', []);
      if (!isEmpty(this.get('searchCondition.selectedPeriodType.value'))) {
        newConditionList.push({
          code: this.get('searchCondition.selectedPeriodType.value'),
          name: this.get('searchCondition.selectedPeriodType.content'),
          type: 'periodType'
        });
      }
      this.set('tagList', newConditionList);
    },

    _setPeriodType(item){
      //기간이 바뀌면 fromtopicker가 변경되고 onPeriodDateChanged()로 재조회가 진행
      const periodConditions = this.setSearchConditionFromToDate(item);
      if(isEmpty(this.get('model.selectedTickIndex'))) {
        this.set('model.selectedTickIndex', periodConditions.tickIndex);
      }
      const ticks = this._setPickersTick();
      this.set('ticks', ticks);
      this.set('searchCondition.disalbleFromToDate', periodConditions.isDisable);
      this.set('searchCondition.fromDate', periodConditions.fromDate);
      this.set('searchCondition.toDate', periodConditions.toDate);
      // this.set('model.selectedTickIndex', 1);
      next(this, function() {
        this.setSliderTicksElementStyle(this.get('fromToPicker'));
      });

      if(item !== 'custom'){
        this.set('searchCondition.selectedPeriodType', {value: item, content: periodConditions.content });
        this._setTagList();
      }else{
        this.set('searchCondition.selectedPeriodType', {value: item, content: null });
        if (!this.get('isChangedPopupCondition')) {
          const searchCondition = this.get('parentSearchCondition');
          this.set('searchCondition.selectedPeriodType.value', searchCondition.selectedPeriodType.value);
          this.set('searchCondition.selectedPeriodType.content', searchCondition.selectedPeriodType.content);
          this._setTagList();
        }
      }
    },

    async _summaryResult(){
      try {
        // this.set('isShowEmpty', false);
        this.set('isShowLoader', true);
        this.set('specimenSummaryResult', emberA());
        this.set('gridItemsSource', emberA());

        const params = this._getDefaultParam();

        //강민주책임님 휴가중이셔서 대신 작업합니다. - 2019-09-10 유재광
        //특정검사만 조회하게 할경우 지정해줌!!
        if(this.get('examinationIdArray') !== null){
          params.examinationIds = this.get('examinationIdArray');
        }

        const path = this.get('defaultUrl') + 'specimen-examination-reports/search';
        const res = await this.getList(path, null, params, false);
        if(!isEmpty(res)) {
          this.set('isShowEmpty', false);
          this.set('specimenSummaryResult', res);
          this._gridSettings();
          this.set('isFirstLoaded', false);
        } else {
          //강민주책임님 휴가중이셔서 대신 작업합니다. - 2019-09-10 유재광
          //특정검사만 조회하게 했는데 아무것도 안나왔다?! - 건수만 재조회..
          if(this.get('examinationIdArray') !== null){
            this._summaryResultDefaultSearch();
          } else{
            this.set('parameters.inbounds.selectCount', 0);
          }
          this.set('isShowEmpty', true);
        }
        this.set('isShowLoader', false);
      } catch(e) {
        this.set('isShowLoader', false);
        this._showError(e);
        // this.showToast('error', '', this.getLanguageResource('tempkey', 'F', '', '진단검사 조회실패'));
        console.log('_summaryResult() Error:::', e);
      }
    },

    //강민주책임님 휴가중이셔서 대신 작업합니다. - 2019-09-10 유재광
    //전체기준으로 건수만 찾는용..(검사로 조회 할 경우만 호출 됨)
    async _summaryResultDefaultSearch(){
      try {
        const params = this._getDefaultParam();
        const path = this.get('defaultUrl') + 'specimen-examination-reports/search';
        const res = await this.getList(path, null, params, false);
        if(!isEmpty(res)) {
          const originSpecimenSummaryResult = this.get('specimenSummaryResult');

          this.set('specimenSummaryResult', res);
          const popupGridData2 = this._parseGridData();
          this.set('parameters.inbounds.selectCount', popupGridData2.length);

          this.set('specimenSummaryResult', originSpecimenSummaryResult);
        } else {
          this.set('parameters.inbounds.selectCount', 0);
        }
      } catch(e) {
        console.log('_summaryResult() Error:::', e);
      }
    },

    _getDefaultParam() {
      let orderedStaffId = null;
      if(this.get('parameters.outbounds.searchType') === 'Personal'){
        orderedStaffId = this.get('userGlobalInformation.employeeId');
      }
      const {fromDate, toDate} = this.getSearchDate();
      const queryParam = EmberObject.create({
        subjectTypeCode: "Patient",
        subjectId: this.get('model.patientId'),
        periodTypeCode: 'CheckIn',
        fromDate: fromDate,
        toDate: toDate,
        departmentId: null,
        orderedStaffId: orderedStaffId,
        isViewUnReportExamination: false,
        isTextResult: null,
        isAbnormalResult: null,
        isExcludePointOfCare: null,
        classificationIds: null,
        examinationIds: null,
        requestRange: null,
      });

      return queryParam;
    },

    _gridSettings(){
      const popupGridData = this._parseGridData();
      popupGridData.map((data, index) => {
        data.no = index+1;
      });
      this._setGridColumn();
      const limitCount = this.get('parameters.outbounds.searchLimitCount') === 0 ? 5 : this.get('parameters.outbounds.searchLimitCount');
      const limitData = [];
      if(!this.get('isPopup') && limitCount < popupGridData.length) {
        for(let i = 0; limitCount > i; i++) {
          limitData.push(popupGridData[i]);
        }
        this.set('gridItemsSource', limitData);
      } else {
        this.set('gridItemsSource', popupGridData);

      }

      //강민주책임님 휴가중이셔서 대신 작업합니다. - 2019-09-10 유재광
      //조회건수가 특정검사건수를 지정하게되면 딱 그 건수(6건)만 보여지고 있어요.. -> 전체기준으로 다시 재조회를 합니다..
      if(this.get('examinationIdArray') !== null){
        this._summaryResultDefaultSearch();
      } else{
        this.set('parameters.inbounds.selectCount', popupGridData.length);
      }

      const selectedItem = popupGridData[0];
      this.set('model.selectedGridItem', selectedItem);
      // this.set('selectedExaminationData', this._getChartData(selectedItem));
    },

    _setGridColumn() {
      const res = this.get('specimenSummaryResult');
      // const uniqSpecimenList = res.uniqBy('specimenId');
      const dateNumberList = this.get('dateMaxNumbers');
      const uniqCheckInDateList = [];
      dateNumberList.forEach((d) => {
        const findObj = res.find(item => item.numberDate === d);
        uniqCheckInDateList.push(findObj.checkInDateTime);
      });
      const resultColumns = [];
      const columnWidth = 100;
      uniqCheckInDateList.forEach((date ,index) => {
        const customColumn = `checkinDate${index}`;
        // const displayDate = moment(date).format('YYYY-MM-DD');
        const displayDate = this.get('fr_I18nService').formatDate(date, 'd');
        resultColumns.push({ field: `${customColumn}.displayResult`, title: displayDate, align: 'center', width: columnWidth, headerTemplateName: 'customHeaders',
          onBodyCellRender: function (context) {
            const cellItem = context.item;
            if(!isEmpty(cellItem[customColumn])) {
              if (cellItem[customColumn].isTextRecordNoteResult === true &&
                !isEmpty(cellItem[customColumn].recoredNoteId) &&
                displayDate === cellItem[customColumn].displayDate){
                set(cellItem[customColumn], 'displayResult', '');
                // const innerHtml = `<div class="clear"><i class="icon-rc-new" style="display:inline-block;vertical-align:middle;margin-top:-3px;margin-left:3px;cursor: pointer;"}}></i></div>`;
                const innerHtml = `<div class="c-gtd-line"><div class="c-gdt"><div class="c-gdc"><i class="icon-rc-new" style="display:inline-block;vertical-align:middle;margin-top:-3px;margin-left:3px;cursor: pointer;"}}></i></div></div></div>`;
                context.cellComponent.$().html(innerHtml);
              }
            }
          },
        });
      });
      this.set('customHeaders', resultColumns);
      this.set('gridColumns', [
        { field: 'examination.abbreviation', title: this.getLanguageResource('17062', 'S', '검사명'), width: 100, locked: true, bodyTemplateName: 'tooltip'},
        { field: 'subjectReferenceRange', title: this.getLanguageResource('10109', 'S', '참고치'), width: 100, align: 'center', locked: true, bodyTemplateName: 'tooltip'},
        ...resultColumns
      ]);
    },

    _setArgumentsCommons() {
      const changedTickIndex = this.get('model.selectedTickIndex');
      const dateParams = {
        fromDate: changedTickIndex === 8 ? null : this.get('searchCondition.fromDate'),
        toDate: changedTickIndex === 8 ? null : this.get('searchCondition.toDate'),
        tickIndex: changedTickIndex
      };
      this.set('parameters.arguments.commons', {period: dateParams});

    },
    _parseGridData(){
      const resultList = [];
      const res = this.get('specimenSummaryResult');
      res.map((d) => {
        // d.displayDate = this.get('fr_I18nService').formatDate(d.checkInDateTime, 'd');
        d.displayDate = this.get('fr_I18nService').formatDate(d.checkInDateTime, 'd');
        d.examinationId = d.examination.id;
        d.chartDisplayResult = d.resultQuantity && d.resultQuantity.value !== null ? d.resultQuantity.value : '';
        d.checkInDateTime = d.checkInDateTime.toString();
        const strDateTime = moment(d.checkInDateTime).format('YYYYMMDDHHmmss');
        const numberDate = Number(strDateTime);
        d.numberDate = numberDate;
        d.checkInDate = moment(d.checkInDateTime).format('YYYY-MM-DD');
        resultList.push(d);
      });
      const uniqExaminationList = resultList.uniqBy('examinationId');
      const uniqDateTimeList = resultList.uniqBy('checkInDateTime');
      const uniqDateList = resultList.uniqBy('checkInDate');
      const grouped = this.groupBy(resultList, item => item.examinationId);
      const examGroupList = [];
      uniqExaminationList.forEach((item) => {
        examGroupList.push(grouped.get(item.examinationId));
      });
      const dateTimeGrouped = this.groupBy(resultList, item => item.checkInDateTime);
      const dateGrouped = this.groupBy(resultList, item => item.checkInDate);
      const dateTimeGroupList = [];
      const dateGroupList = [];
      // const dateNumbersGroup = [];
      uniqDateTimeList.forEach((item) => {
        dateTimeGroupList.push(dateTimeGrouped.get(item.checkInDateTime));
      });
      uniqDateList.forEach((item) => {
        dateGroupList.push(dateGrouped.get(item.checkInDate));
      });
      const dateMaxNumbers = [];
      dateGroupList.forEach(group => {
        const groupNumbers = [];
        group.forEach(d => {
          groupNumbers.push(d.numberDate);
        });
        dateMaxNumbers.push(Math.max(...groupNumbers));
        // dateNumbersGroup.push(groupNumbers);
      });
      this.set('dateMaxNumbers', dateMaxNumbers);
      const tempArr = [];
      const filterItems = [];
      examGroupList.forEach((item) => {
        const itemsNumbnerDateArr = [];
        item.forEach(obj => {
          itemsNumbnerDateArr.push(obj.numberDate);
        });
        const dateGroup = this.groupBy(item, d => d.checkInDate);
        item.map((child)=> {
          const dateGroupItems = dateGroup.get(child.checkInDate);
          const targetItem = item.find(obj2 => obj2.numberDate === dateGroupItems[0].numberDate);
          if(!isEmpty(targetItem) && targetItem.numberDate === child.numberDate) {
            item.numberDates = itemsNumbnerDateArr;
            child.color = '#'+Math.random().toString(16).substr(2,6);
            const dateTargetIndex = dateGroupList.findIndex(g => g[0].checkInDate === child.checkInDate);
            if(dateTargetIndex > -1) {
              const customColumn = `checkinDate${dateTargetIndex}`;
              const targetExamination = tempArr.find((d) => d.examination.id === child.examination.id);
              if(targetExamination && targetExamination.examination.id === child.examination.id) {
                tempArr.map((obj) => {
                  if(obj.examination.id === child.examination.id) {
                    obj[customColumn] = child;
                  }
                });
              } else {
                tempArr.push({
                  [customColumn]: child,
                  checkInDateTime: child.checkInDateTime,
                  examination: child.examination,
                  checkInId: child.checkInId,
                  displayResult: child.displayResult,
                  specimenId: child.specimenId,
                  subjectReferenceRange: child.subjectReferenceRange,
                  isTextRecordNoteResult: child.isTextRecordNoteResult,
                  recoredNoteId: child.recoredNoteId
                });
              }
              filterItems.push(targetItem);
            }
          }

        });
      });
      this.set('filterItems', filterItems);
      return tempArr;
    },
    _getCopyTableContent(dataList) {
      try {
        const tableStyle = 'border: 1px solid #444444;border-collapse: collapse;';
        const borderStyle = 'border: 1px solid #444444;';
        let content = '';
        let allContent = '';
        let columnsTag = '';
        let headerContent = `<table style="${tableStyle}"><thead><tr style="background:#f0f1f3;">`;
        const _bindingColumns = this.get('gridColumns');
        dataList.forEach(function (item) {
          columnsTag = '';
          _bindingColumns.forEach(function (column) {
            const textAlign = column.align;
            columnsTag += `<th style="width:${column.width}px;${borderStyle}">${column.title}</th>`;
            let cellCotent = get(item, column.field);
            cellCotent = isEmpty(cellCotent) ? '' : cellCotent;
            if((column.field !== 'examination.abbreviation' && column.field !== 'subjectReferenceRange') && !isEmpty(item.recoredNoteId)) {
              cellCotent = '';
            }
            if (column.field === 'examination.abbreviation') {
              content += '<tr>';
            }
            content += `<td style="${borderStyle}text-align:${textAlign};">${cellCotent}</td>`;
          });
          content += '</tr>';
        });
        headerContent += columnsTag;
        headerContent += '</tr></thead>';
        allContent = `${headerContent}`;
        allContent +=` <tbody>${content}</tbody></table>`;
        console.log('allContent---', allContent);
        this.get('co_ContentMessageService').sendMessage('D2EDITOR_SEND_CONTENTS', allContent);
      } catch(e) {
        this._showError(e);
      }
    },
  });