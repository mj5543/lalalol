/* eslint-disable max-lines */
/* eslint-disable no-undef */
/* eslint-disable no-console */
import $ from 'jquery';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'testresultviewer-module/app-config';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  {
    layout,
    model: null,
    defaultUrl: null,
    searchCondition: null,
    parentSearchCondition: null,
    selectedExaminationIds: null,
    patientGlobalInformation: null,
    specimenSummaryResult: null,
    isSpecimenExamSummaryOpen: false,
    gridItemsSource: null,
    gridColumns: null,
    selectedExaminationData: null,
    isPopupToggleDisabled: false,
    isPopupChecked: false,
    chartTimePointer: null,
    actionMode: null,
    isValidPaging: true,
    customHeaders: null,
    isChangedPopupCondition: null,
    specimenExamSummaryParams: null,
    patientId: null,
    periodType: null,
    specimenExaminationParam: null,
    examinationIds: null,
    placementTarget: null,
    attachment: null,
    targetAttachment: null,
    popupOption: null,
    cellDetailTarget: null,
    isDisabledImgViewer: true,
    verticalOffset: null,
    horizontalOffset: null,
    isPopoverFirstOpen: true,
    currentOnClassElement: null,
    isShowLoader: false,
    multiListData: null,
    customYAxisValue: null,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId','test-result-viewer-summary-sheet-laboratory-result-popup');

      this.setStateProperties([
        'model',
        'defaultUrl',
        'searchCondition',
        'parentSearchCondition',
        'selectedExaminationIds',
        'patientGlobalInformation',
        'specimenSummaryResult',
        'isSpecimenExamSummaryOpen',
        'gridItemsSource',
        'selectedExaminationData',
        'isPopupToggleDisabled',
        'isPopupChecked',
        'chartTimePointer',
        'actionMode',
        'customHeaders',
        'isChangedPopupCondition',
        'customPeriod',
        'fromToPicker',
        'gridControl',
        'periodParameter'
      ]);

      if(this.hasState()===false) {
        const defaultUrl = this.get('fr_HostConfigService')
          .getEnvConfig('ServerCallConfig', 'testresultviewer') +
          `test-result-viewer/${config.version}/`;

        this.set('defaultUrl', defaultUrl);
        this.set('model',{
          isByPeriodOpen: false,
          isPopupSpecimen: false,
          listBoxSpecimen: emberA(),
          patientId: null,
          selectedGridItem: null,
          selectedGridItems: null,
          parameters: null,
        });
      }


    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w680');
      $(this.element).addClass('hp100');

    },

    actions: {
      onOpenPopupAction01() {
        this.set('isPopupOpen01', true);
      },
      onOpenCenterAction() {
        this.set('isCenterOpen', true);
      },
      onOpenTemplateAction() {
        this.set('isPopupTemplateOpen', true);
      },
      onPopupOpenedAction() {
        if(!isEmpty(this.get('parameters'))) {
          this.set('model.parameters', this.get('parameters'));
          this.set('periodParameter', this.get('parameters.arguments.commons.period'));
        }
      },
      onPopupClosedAction() {
        //
      },

    },

  });