/* eslint-disable no-console */
import layout from './template';
import CHIS from 'framework/chis-framework';
import { isEmpty, isPresent } from '@ember/utils';
import { set } from '@ember/object';

export default CHIS.FR.Core.ComponentBase.extend(
  CHIS.FR.CrossCutting.ServerCallMixin,
  {
    layout,
    isShowLoader: false,
    listKeyword: null,
    toggleChecked: true,
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','intelligence-summary-integrated-result');
      this.set('conditionItemsSource', []);
      this.set('conditionColumns', [
        { field: 'parameterName', title: this.getLanguageResource('tempkey', 'F', '', '검색조건'), width: 120, readOnly: true, bodyTemplateName: 'txtRequired'},
        { field: 'parameterValue', title: this.getLanguageResource('tempkey', 'F', '', '검색조건값'), bodyTemplateName: 'customCell'},
      ]);
    },

    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1624');
      this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'intelligencesummary') + 'intelligence-summary/v0/');
      this._init();
    },
    didRender() {
      this._super(...arguments);
    },
    actions: {
      onToggleChanged (e) {
        let nodeContainer = document.getElementById('nodeList');
        let nodeEle = nodeContainer.getElementsByClassName('caret');
        let nodeListEle = nodeContainer.getElementsByClassName('nested');
        let foldElements = nodeContainer.getElementsByClassName('node-fold');
        if(e.checked) {
          for(let i = 0; i < nodeEle.length; i++) {
            nodeEle[i].classList.add('caret-down');
          }
          for(let i = 0; i < nodeListEle.length; i++) {
            nodeListEle[i].classList.add('active');
          }
          for(let i = 0; i < foldElements.length; i++) {
            foldElements[i].classList.add('fold-on');
          }
        } else {
          for(let i = 0; i < nodeListEle.length; i++) {
            nodeListEle[i].classList.remove('active');
          }
          for(let i = 0; i < nodeEle.length; i++) {
            nodeEle[i].classList.remove('caret-down');
          }
          for(let i = 0; i < foldElements.length; i++) {
            foldElements[i].classList.remove('fold-on');
          }
        }
        nodeContainer = null;
        nodeEle = null;
        nodeListEle = null;
        foldElements = null;
      },
      onTreeClick() {
        event.target.parentElement.querySelector(".nested").classList.toggle("active");
        event.target.parentElement.querySelector(".node-fold").classList.toggle("fold-on");
        event.target.parentElement.querySelector(".caret").classList.toggle("caret-down");
        // event.target.classList.toggle("caret-down");
      },
      onCategoryClick() {
        event.target.parentElement.parentElement.querySelector(".nested").classList.toggle("active");
        event.target.parentElement.querySelector(".node-title").querySelector(".node-fold").classList.toggle("fold-on");
        event.target.parentElement.querySelector(".caret").classList.toggle("caret-down");
        this._setSelectedClass(event);
      },
      onResultListClick(item) {
        this.set('integratedResultId', item.integratedResultId);
        this._getResultParameters();
        this._getResultHeaderList();
        this._setSelectedClass(event);
        //TODO: timeCheck
        this.set('invalidTime', false);
        if(isPresent(item.unavailableTime)) {
          if(isEmpty(item.unavailableTime.startDateTime) || isEmpty(item.unavailableTime.endDateTime)) {
            return;
          }
          const now = this.get('co_CommonService').getNow();
          const startDate = new Date(item.unavailableTime.startDateTime).setFullYear(now.getFullYear(), now.getMonth(), now.getDate());
          const endDate = new Date(item.unavailableTime.endDateTime).setFullYear(now.getFullYear(), now.getMonth(), now.getDate());
          if((new Date(now).getTime() >= startDate)
          && (new Date(now).getTime() <= endDate) && !item.isWeekEnd) {
            this.set('invalidTime', true);
            this.showMessage(this.getLanguageResource('tempkey', 'F', '', '조회가 불가합니다.'), 'warning', 'Ok', 'Ok', '', 2000);
          } else if((new Date(now).getTime() >= startDate) && (new Date(now).getTime() <= endDate) && item.isWeekEnd && !item.unavailableTime.isExceptWeekend) {
            this.set('invalidTime', true);
            this.showMessage(this.getLanguageResource('tempkey', 'F', '', '조회가 불가합니다.'), 'warning', 'Ok', 'Ok', '', 2000);
          }
        }
      },
      onGridSelectionChanged() {
        //
      },
      onSearchData() {
        this._init();
      },
      onSearchTextCleared() {
        this.set('listKeyword', null);
        this._init();
      },
      onInputSearchClick(e) {
        this.set('listKeyword', e.searchText);
        this._init();
      },
      onLoadCombobox(item, e) {
        this.set(`${item.integratedResultParameterId}Combobox`, e.source);
      },
      onComboboxChanged(item) {
        let paramValue = null;
        const selectedItems = this.get(`${item.integratedResultParameterId}Combobox.selectedItems`);
        if(isPresent(selectedItems)) {
          paramValue = selectedItems.map(d => d.selectedValuePath);
        }
        set(item, 'parameterValue', paramValue);
      },
      onComboboxSingleChanged(item) {
        let paramValue = null;
        const selectedItems = this.get(`${item.integratedResultParameterId}Combobox.selectedItems`);
        if(isPresent(selectedItems)) {
          paramValue = selectedItems[0].selectedValuePath;
        }
        set(item, 'parameterValue', paramValue);
      },
      onResultSearchClick() {
        if(this.get('invalidTime')) {
          this.showMessage(this.getLanguageResource('tempkey', 'F', '', '조회가 불가합니다.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        const requiredItems = this.conditionItemsSource.filter(d => d.isRequired);
        if(isPresent(requiredItems) && isPresent(requiredItems.filter(d => isEmpty(d.parameterValue)))) {
          this.showMessage(this.getLanguageResource('8945', 'F', '필수값을 입력하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        this._getResultSearch();
      },
      onResultGridLoaded(e) {
        this.set('resultGrid', e.source);
      },
      onBeforeKeyDown(e) {
        if (e.originalEvent.keyCode === 9) {
          let gridComponent = e.source,
            currentCell = gridComponent.getCurrentCell(),
            itemIndex = gridComponent.getItemIndex(currentCell.item);
          const columnIndex = gridComponent.getColumnIndex(currentCell.column);
          if(currentCell.column.field === 'parameterValue' && itemIndex !== -1 && columnIndex !== -1) {
            itemIndex = itemIndex + 1;
            e.cancel = true;
            gridComponent.selectRow(itemIndex);
            gridComponent.focusCell(itemIndex, columnIndex);
            gridComponent.editCell(itemIndex, columnIndex);
          }
          gridComponent = null;
          currentCell = null;
        }
      },
      onExcelPrintAction() {
        const itemsSource = this.get('resultItemsSource');
        if(isEmpty(itemsSource)){
          return;
        }
        const gridSource = this.get('resultGrid');
        const reason = 'Excel export integrated result';
        const column = this.get('resultColumns');
        const headers = column.map(function(item, index){
          return { left: index, top: 0, right: index, bottom: 0, value: item.title };
        });
        const fields = column.map(function(item){
          return { width: item.width, value: item.field };
        });
        gridSource.exportToExcel('integrated_result.xlsx', headers, fields, this, 'onExcelPrintAction',reason , itemsSource);
      }
    },
    _init() {
      this.set('resultList', null);
      this.set('conditionItemsSource', []);
      this.set('resultItemsSource', null);
      this.set('integratedResultId', null);
      this.set('resultColumns', null);
      this._getResultList();
    },
    async _getResultList() {
      try {
        this.set('isShowLoader', true);
        const params = {
          keyword: this.get('listKeyword'),
          addQuery: false,
        };
        // const result = await this.getList(this.get('defaultUrl') + 'integrated-result/list', null, null);
        const result = await this.getList(this.get('defaultUrl') + 'integrated-result/search', params, null);
        this.set('resultList', result);
        this.set('isShowLoader', false);
      }catch(e) {
        this.set('isShowLoader', false);
      }
    },
    async _getResultParameters() {
      try {
        this.set('isShowLoader', true);
        this.set('resultItemsSource', null);
        this.set('resultColumns', null);
        const id = this.get('integratedResultId');
        if(isEmpty(id)) {
          return;
        }
        const result = await this.getList(this.get('defaultUrl') + 'integrated-result/parameter', {integratedResultId: id}, null);
        if(isPresent(result)) {
          const now = this.get('co_CommonService').getNow();
          result.forEach(d => {
            let parameterValue = null;
            if(d.paramTypeCode === 'DateTime') {
              parameterValue = now;
            }
            set(d, 'parameterValue', parameterValue);
          });
        }
        this.set('conditionItemsSource', result);
        this.set('isShowLoader', false);
      }catch(e) {
        this.set('isShowLoader', false);
      }
    },
    async _getResultHeaderList() {
      try {
        this.set('isShowLoader', true);
        const id = this.get('integratedResultId');
        if(isEmpty(id)) {
          return;
        }
        const result = await this.getList(this.get('defaultUrl') + 'integrated-result/header', {integratedResultId: id}, null);
        console.log('result--', result);
        const tempArr = [];
        if(isPresent(result)) {
          result.forEach(d => {
            if(d.typeCode === 'date') {
              tempArr.push(
                { field: d.fieldName, tooltipFIeld: d.fieldName, title: d.headerTitle, type: 'date', width: d.headerWidth, dataFormat: d.dataFormatCode, align: d.alignCode, bodyTemplateName: 'tooltip', isShowTooltip: d.isToolTipContainer}
              );
            } else {
              tempArr.push(
                { field: d.fieldName, tooltipFIeld: `${d.fieldName}Tooltip`, title: d.headerTitle, width: d.headerWidth, align: d.alignCode, bodyTemplateName: 'tooltip', isShowTooltip: d.isToolTipContainer}
              );
            }
          });
        }
        this.set('resultHeaders', tempArr);
        this.set('isShowLoader', false);
      }catch(e) {
        this.set('isShowLoader', false);
      }
    },
    async _getResultSearch() {
      try {
        this.set('resultItemsSource', null);
        // if(isEmpty(this.conditionItemsSource)) {
        //   return;
        // }
        const paramsters = this._getSearchParameters();
        if(isPresent(paramsters)) {
          const targetDateItems = paramsters.filter(d => d.parameterDataType === 'DateTime' && isPresent(d.intervalCheck));
          let diffCount = 0;
          let interval = null;
          if(isPresent(targetDateItems)) {
            targetDateItems.forEach(item => {
              const sdt = new Date(item.parameterValue);
              const endTargetDateItem = paramsters.find(d => d.parameterCode === item.intervalCheck.parameterCode);
              const edt = new Date(endTargetDateItem.parameterValue);
              const dateDiff = Math.ceil((edt.getTime()-sdt.getTime())/(1000*3600*24));
              if(item.intervalCheck.interval - dateDiff < 0) {
                interval = item.intervalCheck.interval;
                diffCount++;
              }
            });
          }
          if(diffCount > 0) {
            this.showMessage(this.getLanguageResource('tempkey', 'F', '', `${interval}일 이상 조회가 불가합니다.`), 'warning', 'Ok', 'Ok', '', 2000);
            return;
          }
        }
        this.set('isShowLoader', true);
        const params = {
          integratedResultId: this.get('integratedResultId'),
          parameters: paramsters
        };
        this.set('searchParams', params);
        const result = await this.getList(this.get('defaultUrl') + 'integrated-result/search', null, params, false);
        this._setResultGridColumns(result);
        result.map(obj => {
          for(const key in obj) {
            if(typeof obj[key] === 'string') {
              obj[`${key}Tooltip`] = obj[key].replace(/\n|\r\n/giu, '<br>');
            }
          }
        });
        this.set('resultItemsSource', result);
        this.auditCustomTypeLog('_getResultSearch','intelligencesummary integrated result search' , params, 'statisticsSearch');
        this.set('isShowLoader', false);
      }catch(e) {
        this.set('isShowLoader', false);
        console.log(e);
      }
    },
    _setResultGridColumns(result) {
      const resultHeaders = this.get('resultHeaders');
      if(isEmpty(resultHeaders) && isPresent(result)) {
        const columnObj = result[0];
        const tempArr = [];
        for(const key in columnObj) {
          if(typeof columnObj[key] !== 'function') {
            tempArr.push(
              { field: key, tooltipFIeld: `${key}Tooltip`,title: key, align: 'center', width: 100, bodyTemplateName: 'tooltip'}
            );
          }
        }
        this.set('resultColumns', tempArr);
      } else {
        this.set('resultColumns', resultHeaders);
      }
    },
    _getSearchParameters() {
      const tempArr = [];
      if(isPresent(this.conditionItemsSource)) {
        this.conditionItemsSource.forEach(d => {
          // let parameterValue = d.parameterValue;
          // if(d.paramTypeCode === 'DateTime') {
          //   parameterValue = this.get('fr_I18nService').formatDate(new Date(d.parameterValue), 'd');
          // }
          tempArr.push({
            parameterDataType: d.parameterDataType,
            parameterCode: d.parameterCode,
            parameterValue: d.parameterValue,
            intervalCheck: d.intervalCheck
          });
        });
      }
      return tempArr;
    },
    _setSelectedClass(evt) {
      let selectedElemnt = document.getElementById('nodeList').querySelector('.selected');
      if(isPresent(selectedElemnt)) {
        selectedElemnt.classList.remove('selected');
      }
      selectedElemnt = null;
      if(evt.target.className.indexOf('fold') > -1) {
        evt.target.parentElement.classList.add('selected');
      } else {
        evt.target.classList.add('selected');
      }
    },

    showMessage(caption, messageBoxImage, messageBoxButton, messageBoxFocus, messageBoxText, messageboxInterval){
      const options = {
        'caption': caption,
        'messageBoxImage': messageBoxImage,
        'messageBoxButton': messageBoxButton,
        'messageBoxFocus': messageBoxFocus,
        'messageBoxText': messageBoxText,
        'messageboxInterval': messageboxInterval
      };
      return messageBox.show(this, options);
    },
  });