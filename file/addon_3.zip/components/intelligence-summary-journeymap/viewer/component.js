import { set } from '@ember/object';
import { isEmpty } from '@ember/utils';
import { inject as service } from '@ember/service';
import { next } from '@ember/runloop';
import layout from './template';
import CHIS from 'framework/chis-framework';
import JourneyMapModel from 'intelligencesummary-module/models/journeymap-model';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  {
    layout,
    // http service
    httpService: service('journeymap-http-service'),
    model: null,
    tempCount: null,
    openCheck: false,
    // on properties init
    onPropertyInit() {
      this._super(...arguments);
      this._setProperties();
      this.set('viewId', 'intelligence-summary-journeymap/viewer');
      this.set('currentMenuId', '__main-intelligence-summary-journeymap');
      this.set('tempCount', null);
    },
    // onloaded
    onLoaded() {
      this._super(...arguments);
      this._setPropertiesData();
      this.set('tempCount', 0);
    },
    // insert element
    didInsertElement() {
      this._super(...arguments);
      this.get('co_ContentMessageService').subscribeMessage('main-time_line_openState', this.get('currentMenuId'), this, this._refreshJourneymap);
    },
    // destroy element
    willDestroyElement() {
      this._super(...arguments);
      this.get('co_ContentMessageService').unsubscribeMessage('main-time_line_openState', this.get('currentMenuId'), this, this._refreshJourneymap);
    },
    // time line width
    /*
    didRender() {
      this._super(...arguments);
      if (this.get('model.isShow')) {
        const current = this;

        Ember.run.scheduleOnce('afterRender', this, function() {
          if (!isNaN(current.$('#patient-list-timeline').width())) {
            current.set('model.timelineWidth', Number(current.$('#patient-list-timeline').width()));
          }
        });
      }
    },
    */
    actions: {
      onDataDoubleClick(e) {
        if (isEmpty(e) || isEmpty(e.series) || isEmpty(e.series.config) || isEmpty(e.series.config.type)) {
          return;
        }
        if (isEmpty(e.data)) {
          return;
        }
        const patientGlobalInformation = this.get('co_PatientManagerService.selectedPatient');

        if (isEmpty(patientGlobalInformation)) {
          return;
        }
        const selectedData = {
          encounterId: e.data.encounterId,
          encounterClassCode: e.data.encounterClassCode,
          procedureExecution: e.data.procedureExecutionList
        };

        if (e.series.config.type === 'point') {
          selectedData.startDate = e.data.day;
          selectedData.endDate = e.data.day;
        } else {
          selectedData.startDate = e.data.dayFrom;
          selectedData.endDate = e.data.dayTo;
        }
        // record 팀에서 사용(수진일때만 발생)
        if (!e.data.isExamination) {
          // 의무기록 조회
          this.get('co_MenuManagerService').openMenu('general-record-viewer', null);
          // 오더조회
          this.get('co_MenuManagerService').openMenu('ordering-order-viewer', null);

          this.get('co_ContentMessageService').sendMessage('__main_journeymap_select', selectedData);
          // 오더 조회 오류로 기능 새창 열면서 연동 보류
          //next(() => {
          //  this.get('co_ContentMessageService').sendMessage('__main_journeymap_select', selectedData);
          //});
        } else {
          // 검사결과 조회
          this.get('co_MenuManagerService').openMenu('test-result-viewer-management', null);
          next(() => {
            // examination 팀에서 사용
            this.get('co_ContentMessageService').sendMessage('__main_journeymap_select_examination', {
              patientId: patientGlobalInformation.patientId,
              // 검체
              specimenIds: !isEmpty(e.data.specimens) && e.data.specimens.length > 0 ? this._getArrayListByType('specimens', e.data.specimens) : [],
              // 영상, 기능
              patientExaminationIds: !isEmpty(e.data.radiologies) && e.data.radiologies.length > 0 ? this._getArrayListByType('radiologies', e.data.radiologies) : [],
              // 병리
              pathologyNumbers: !isEmpty(e.data.pathologies) && e.data.pathologies.length > 0 ? this._getArrayListByType('pathologies', e.data.pathologies) : []
            });
          });
        }
      }
    },
    // on patient changed
    onPatientChanged() {
      if (this.get('openCheck')) {
        this._setPropertiesData();
        this.set('tempCount', 0);
      }
    },
    // refresh journeymap
    _refreshJourneymap(isOpen) {
      this.set('openCheck', isOpen);
      if (isOpen === true) {
        this._setPropertiesData();
        this.set('tempCount', 0);
      }
    },
    // get array list
    _getArrayListByType(type, list) {
      const returnList = [];

      if (type === 'specimens') {
        list.forEach(item => {
          returnList.push(item.specimenId);
        });
      } else if (type === 'radiologies') {
        list.forEach(item => {
          returnList.push(item.patientExaminationId);
        });
      } else if (type === 'specialClinics') {
        list.forEach(item => {
          returnList.push(item.basedOnId);
        });
      } else if (type === 'pathologies') {
        list.forEach(item => {
          returnList.push(item.pathologyNumber);
        });
      }
      return returnList;
    },
    // set properties
    _setProperties() {
      this.set('model', JourneyMapModel.create());
      this.set('model.isShow', false);
    },
    // set properties data
    _setPropertiesData() {
      const currentUser = this.get('co_CurrentUserService.user');
      const patientGlobalInformation = this.get('co_PatientManagerService.selectedPatient');

      this.set('model.actionMode', 'update');
      this.set('model.timelineData', null);
      if (isEmpty(currentUser) || isEmpty(patientGlobalInformation)) {
        return;
      }
      const params = {
        privateUserId: currentUser.employeeId,
        patientId: patientGlobalInformation.patientId
      };
      this.set('model.loader', true);
      this.get('httpService').getJourneyMapData(params, (result) => {
        if (isEmpty(result)) {
          this.set('model.loader', false);
          this.set('model.timelineData', null);
          return;
        }
        for (const g of result) {
          for (const c of g.chapterListView) {
            for (const e of c.explorerListView) {
              set(e, 'visitStartDateTimeString', this._changeDateFormat(e.visitStartDateTime, 'd'));
            }
          }
        }
        this.get('httpService').getJourneyMapMultiData(params, (subResult) => {
          this.set('model.timelineMultiData', subResult);
          for (const g of subResult) {
            set(g, 'visitStartDateTimeString', this._changeDateFormat(g.visitStartDateTime, 'd'));
          }
          this._setJourneyMapData(result);
        });
      });
    },
    // set journey map data
    _setJourneyMapData(result) {
      const groupList = [], series = [];
      let groupCount = 1, minDate = null, maxDate = null, tweetNum = 1;
      for (const row of result) {
        let itemCount = 1;
        if (!isEmpty(row.minDateTime) && !isEmpty(row.maxDateTime)) {
          minDate = row.minDateTime;
          maxDate = row.maxDateTime;
        }
        groupList.push({ no: groupCount, name: row.guideName });
        for (const item of row.chapterListView) {
          if (isEmpty(item.explorerListView) || item.explorerListView.length < 1) {
            continue;
          }
          const itemType = this._getItemType(item.explorerListView[0].visitEndDateTime), symbolType = this._getSymbolType(item.explorerListView[0].visitEndDateTime, item.icon), symbolColor = this._getSymbolColor(item.icon);
          let dataCount = 1;
          const structure = this._getDataStructure(tweetNum, item.spotName, itemType, symbolColor, symbolType, groupCount), dataList = [];
          for (const point of item.explorerListView) {
            const domId = 'timeline-' + groupCount + '-' + itemCount + '-' + dataCount, data = this._getTimelineData(domId, groupCount, '', itemType, point, row.guideBookId, this._getIsExamination(item.spotId), item.spotType);
            if (!isEmpty(data)) {
              data.tooltipTemplate = this._getToolTipTemplete(point.traceListView.length, row.guideBookId, point.visitStartDateTimeString, item.spotType);
              dataList.push(data);
              dataCount++;
            }
          }
          structure.data = dataList;
          series.push(structure);
          itemCount++;
          tweetNum++;
        }
        groupCount++;
      }
      const timelineData = this._getTimelineStructure();
      if (!isEmpty(minDate) && !isEmpty(maxDate)) {
        timelineData.timeDomain.push(minDate);
        timelineData.timeDomain.push(maxDate);
      }
      timelineData.groupLegend = groupList;
      timelineData.series = series;
      this.set('model.timelineData', timelineData);
      this.set('model.isShow', true);
      this.set('model.loader', false);
    },
    // get item type
    _getItemType(visitEndDateTime) {
      if (isEmpty(visitEndDateTime)) {
        return 'point';
      } else {
        return 'fromTo';
      }
    },
    // get symbol type
    _getSymbolType(visitEndDateTime, icon) {
      let symbolType = null;
      if (isEmpty(visitEndDateTime)) {
        symbolType = 'material-icons-favorite';
      } else {
        symbolType = 'material-icons-clear_all';
      }
      if (!isEmpty(icon) && !isEmpty(icon.class)) {
        symbolType = icon.class;
      }
      return symbolType;
    },
    // get symbol color
    _getSymbolColor(icon) {
      if (!isEmpty(icon) && !isEmpty(icon.content)) {
        return icon.content;
      }
      return '#000000';
    },
    _getDataStructure(tweetNum, spotName, itemType, symbolColor, symbolType, groupCount) {
      return {
        'no': tweetNum, 'name': spotName, 'data': [],
        'config': {
          'type': itemType, 'xAxisProperty': 'day', 'yAxisProperty': 'tweets', 'strokeColor': null, 'strokeWidth': null,
          'symbolColor': symbolColor, 'symbolSize': 4, 'symbolType': symbolType, 'idProperty': 'id', 'tooltipProperty': 'remark',
          'tooltipTemplate': '', 'groupLegendNo': groupCount, 'isSelectSymbol': false, 'isSelectLegend': false
        }
      };
    },
    _getTimelineStructure() {
      return {
        'xAxisOrient': 'bottom',
        'yAxisOrient': 'left',
        'tooltipSize': 12,
        'isSortedData': false,
        'isTimeXAxis': true,
        'isShowNowBar': true,
        'isGroupLegend': true,
        'isCollapsibleLegend': true,
        'isCustomYAxis': false,
        'collapsibleLegendWidth': 140,
        'isCollapseLegendPane': true,
        'groupLegend': [],
        'timeDomain': [],
        'timeFormat': {
          'dataFormat': 'f',
          'xAxisTickFormat': [
            {
              'type': 'year',
              'format': '%Y'
            },
            {
              'type': 'month',
              'format': '%Y %b'
            },
            {
              'type': 'week',
              'format': '%y %b %e'
            },
            {
              'type': 'day',
              'format': '%b %e'
            },
            {
              'type': 'hour',
              'format': '%e %p %I'
            },
            {
              'type': 'minute',
              'format': '%p %I'
            }
          ]
        },
        'series': []
      };
    },
    // get is examination
    _getIsExamination(spotId) {
      if (spotId === '10001' || spotId === '10002' || spotId === '10003' || spotId === '10005') {
        return false;
      } else {
        return true;
      }
    },
    // get time line data
    _getTimelineData(id, groupNo, remark, itemType, point, guideBookId, isExamination, spotType) {
      let itemIndex = 1;
      const returnData = {
        id: id,
        tweets: groupNo,
        remark: remark,
        procedureExecutionList: point.procedureExecutionListView,
        radiologies: this._getData('radiologies', guideBookId, point.visitStartDateTimeString),
        specimens: this._getData('specimens', guideBookId, point.visitStartDateTimeString),
        pathologies: this._getData('pathologies', guideBookId, point.visitStartDateTimeString),
        specialClinics: this._getData('specialClinics', guideBookId, point.visitStartDateTimeString),
        encounterId: point.encounterId,
        encounterClassCode: point.classCode,
        isExamination: isExamination
      };
      const multiList = this._getMultiDataList(guideBookId, point.visitStartDateTimeString, spotType);

      if (itemType === 'point') {
        returnData.day = point.visitStartDateTime;
      } else {
        returnData.dayFrom = point.visitStartDateTime;
        returnData.dayTo = point.visitEndDateTime;
      }
      if (multiList.length <= 1) {
        if (point.spotId === '10002') {
          for (const traceItem of point.traceListView) {
            returnData['title' + itemIndex] = traceItem.traceTypeName;
            if (traceItem.displayDataType === 'date') {
              returnData['content' + itemIndex] = this._changeDateFormat(traceItem.content, 'd');
            } else if (traceItem.displayDataType === 'datetime') {
              returnData['content' + itemIndex] = this._changeDateFormat(traceItem.content, 'G');
            } else if (traceItem.displayDataType === 'time') {
              returnData['content' + itemIndex] = this._changeDateFormat(traceItem.content, 't');
            } else {
              returnData['content' + itemIndex] = traceItem.content;
            }
            itemIndex++;
          }
        } else {
          for (const traceItem of point.traceListView) {
            returnData['title' + itemIndex] = traceItem.traceTypeName;
            if (traceItem.displayDataType === 'date') {
              returnData['content' + itemIndex] = this._changeDateFormat(traceItem.content, 'd');
            } else if (traceItem.displayDataType === 'datetime') {
              returnData['content' + itemIndex] = this._changeDateFormat(traceItem.content, 'g');
            } else if (traceItem.displayDataType === 'time') {
              returnData['content' + itemIndex] = this._changeDateFormat(traceItem.content, 't');
            } else {
              returnData['content' + itemIndex] = traceItem.content;
            }
            itemIndex++;
          }
        }
      } else {
        for (const traceItem of multiList) {
          returnData['content' + itemIndex] = traceItem.traceContent;
          itemIndex++;
        }
      }
      return returnData;
    },
    // get tool tip template
    _getToolTipTemplete(lengthCnt, guideBookId, visitStartDateTimeString, spotType) {
      let html = null;
      const multiCount = this._getMultiDataList(guideBookId, visitStartDateTimeString, spotType).length;

      html = "<div class='boxsp-type06' style='height:auto; width: 250px;'>";
      html += "<div class='tbl-row'>";
      html += " <table style='font-size:11px;'>";
      if (multiCount <= 1) {
        html += "   <caption></caption>";
        html += "   <colgroup>";
        html += "     <col width='40%'>";
        html += "     <col width='*'>";
        html += "   </colgroup>";
        html += "   <tbody>";
        for (let i = 0; i < lengthCnt; i++) {
          html += "   <tr>";
          html += "     <th style='height:auto;padding:3px 5px;text-align:left' scope='row'>{{title" + (i + 1) + "}}</th>";
          html += "     <td style='height:auto;padding:3px 5px;text-align:left'>{{content" + (i + 1) + "}}</td>";
          html += "   </tr>";
        }
      } else {
        html += "   <tbody>";
        for (let i = 0; i < multiCount; i++) {
          html += "   <tr>";
          html += "     <td style='height:auto;padding:3px 5px;text-align:left'>{{content" + (i + 1) + "}}</td>";
          html += "   </tr>";
        }
      }
      html += "   </tbody>";
      html += " </table>";
      html += "</div>";
      html += "</div>";
      return html;
    },
    // get data
    _getData(type, guideBookId, visitStartDateTimeString) {
      if (isEmpty(this.get('model.timelineMultiData'))) {
        return [];
      }
      for (const item of this.get('model.timelineMultiData').filterBy('guideBookId', guideBookId)) {
        if (visitStartDateTimeString === item.visitStartDateTimeString) {
          return item[type];
        }
      }
      return [];
    },
    // get multi data list
    _getMultiDataList(guideBookId, visitStartDateTimeString, spotType) {
      if (isEmpty(this.get('model.timelineMultiData'))) {
        return [];
      }
      for (const item of this.get('model.timelineMultiData').filterBy('isMulti', true).filterBy('guideBookId', guideBookId).filterBy('traceType', spotType)) {
        if (visitStartDateTimeString === item.visitStartDateTimeString) {
          return item.contents;
        }
      }
      return [];
    },
    // change data format
    _changeDateFormat(data, type) {
      if (isEmpty(data)) {
        return '';
      }
      this.set('tempCount', this.get('tempCount') + 1);
      let resultData = null;

      try {
        resultData = this.get('fr_I18nService').formatDate(data, type);
      } catch (e) {
        console.log(e);
        resultData = data;
      }
      return resultData;
    }
  });