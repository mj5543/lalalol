import { isEmpty } from '@ember/utils';
import layout from './template';
import CHIS from 'framework/chis-framework';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, {
  layout,
  model: null,
  selectedItem: null,
  // init
  onPropertyInit(){
    this._super(...arguments);
    this.set('viewId', 'intelligence-summary-journeymap/configuration/share/optionpopup');
    this._setProperties();
  },
  // onload
  onLoaded(){
    this._super(...arguments);
    this._setPropertiesData();
  },
  actions: {
    // selected icon action
    onSelectedIconAction(e) {
      if (isEmpty(e) || isEmpty(e.symbolColor) || isEmpty(e.symbolType)) {
        return;
      }
      const params = this.get('optionPopup.params');

      this.set('optionPopup.isOpen', false);
      this.get('setIconColorCB')({
        index: params.index,
        subIndex: params.subIndex,
        shape: e.symbolType,
        color: e.symbolColor,
        path: e.symbolPath
      });
    }
  },
  // set properties
  _setProperties() {
    this.set('emptyModel', null);
  },
  // set properties data
  _setPropertiesData() {
    this.set('emptyModel', null);
  }
});