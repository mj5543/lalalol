import EmberObject from '@ember/object';
import layout from './template';
import CHIS from 'framework/chis-framework';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, {
  layout,
  model: null,
  // init
  onPropertyInit(){
    this._super(...arguments);
    this._setProperties();
  },
  // onload
  onLoaded(){
    this._super(...arguments);
    this._setPropertiesData();
  },
  actions: {
    treeContextMenuOpen() {
      this.set('emptyModel', EmberObject.create());
    }
  },
  // set properties
  _setProperties() {
    this.set('emptyModel', EmberObject.create());
  },
  // set properties data
  _setPropertiesData() {
    this.set('emptyModel', EmberObject.create());
  }
});