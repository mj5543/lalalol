import EmberObject, { set } from '@ember/object';
import layout from './template';
import CHIS from 'framework/chis-framework';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, {
  layout,
  model: null,
  type: null,
  // init
  onPropertyInit(){
    this._super(...arguments);
    this._setProperties();
    this.set('viewId', 'intelligence-summary-journeymap/configuration/share/guidebook');
    if (this.get('co_CurrentUserService.user.employeeId') === 'GUID_10001' || this.get('type') === 'custom') {
      this.set('allowedUpdateForCommon', true);
    } else {
      this.set('allowedUpdateForCommon', false);
    }
  },
  // onload
  onLoaded(){
    this._super(...arguments);
    this._setPropertiesData();
  },
  actions: {
    onClickDetailPopup(index, subIndex) {
      if (!this.get('allowedUpdateForCommon')) {
        return;
      }
      this.set('optionPopup.targetId', '#journeymap-configuration-item-' + this.get('type') + '-' + index);
      this.set('optionPopup.params', {
        index: index,
        subIndex: subIndex
      });
      this.set('optionPopup.isOpen', true);
    },
    onClickRemove(index, subIndex) {
      this.set('optionPopup.params', {
        index: index,
        subIndex: subIndex
      });
      this.get('model.list')[index].chapterList.removeObject(this.get('model.list')[index].chapterList[subIndex]);
    },
    onClickSave() {
      this.get('saveJourneymapSettingCB')();
    },
    onClickCopy(index) {
      if (!this.get('allowedUpdateForCommon')) {
        return;
      }
      this.get('copySelectedTreeItemCB')(index);
    },
    onClickSelectedItem(item) {
      if (!this.get('allowedUpdateForCommon')) {
        return;
      }
      for (const itemData of this.get('model.list')) {
        set(itemData, 'className', null);
      }
      set(item, 'className', 'on');
    }
  },
  // set properties
  _setProperties() {
    this.set('emptyModel', EmberObject.create());
  },
  // set properties data
  _setPropertiesData() {
    this.set('emptyModel', EmberObject.create());
  },
  _getGuidebookListData() {
    this.get('getGuidebookListCB')();
  }
});