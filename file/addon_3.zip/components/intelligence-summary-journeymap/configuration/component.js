import { isEmpty } from '@ember/utils';
import EmberObject, { set } from '@ember/object';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import ConfigurationModel from 'intelligencesummary-module/models/journeymap-configuration-model';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, {
  layout,
  model: null,
  toast: service('toast-service'),
  service: service('journeymap-configuration-http-service'),
  // init
  onPropertyInit(){
    this._super(...arguments);
    this.set('viewId', 'intelligence-summary-journeymap/configuration');
    this._setProperties();
  },
  // onload
  onLoaded(){
    this._super(...arguments);
    this._setPropertiesData();
    this.set('menuClass', 'w800');
  },
  actions: {
    // get custom list
    getGuidebookList() {
      this._getGuidebookList();
    },
    //on selection changed action
    onSelectionChangedAction() {
      this.set('emptyModel', EmberObject.create());
    },
    // save journeymap setting
    saveJourneymapSetting() {
      const selectedTab = this.get('model.selectedTabName').replace('journeymap-configuration-', ''), saveList = this.get(`model.${selectedTab}.guidebook.list`);
      const userId = selectedTab === 'common' ? 'Public' : this.get('co_CurrentUserService.user.employeeId'), bookType = selectedTab === 'common' ? 0 : 1;
      const params = { guideBooks: [], privateUserId: userId, isBasic: this.get(`model.${selectedTab}.guidebook.isBasic`) };
      let bookIndex = 1, chapterIndex = 1, isErrorChapter = false, isErrorName = false;
      saveList.forEach(item => {
        chapterIndex = 1;
        const chapterList = [];
        item.chapterList.forEach(subItem => {
          chapterList.push({
            chapterId: subItem.chapterId, spotId: subItem.spotId, guideBookId: item.guideBookId, displaySequence: String(chapterIndex), isValidDataRow: true,
            icon: {
              iconId: isEmpty(subItem.icon) ? null : subItem.icon.iconId, spotId: subItem.spotId, guideBookType: bookType,
              class: isEmpty(subItem.icon) ? null : subItem.icon.class, content: isEmpty(subItem.icon) ? null : subItem.icon.content,
              path: isEmpty(subItem.icon) ? null : subItem.icon.path
            }
          });
          chapterIndex++;
        });
        if (chapterList.length > 0 && !isEmpty(item.name)) {
          params.guideBooks.pushObject({ guideBookId: item.guideBookId, guideBookType: bookType, code: item.code, name: item.name, displaySequence: bookIndex, isValidDataRow: true, chapterList: chapterList });
          bookIndex++;
        }
        if (chapterList.length > 0 && isEmpty(item.name)) {
          isErrorName = true;
        }
        if (chapterList.length === 0 && !isEmpty(item.name)) {
          isErrorChapter = true;
        }
      });
      if (isErrorName) {
        messageBox.show(this, {caption: this.getLanguageResource('12653', 'F', '', '축 이름을 확인하세요.'),messageBoxButton: 'Ok',messageBoxImage: 'warning',messageBoxText: '',messageBoxFocus: 'Ok',messageboxInterval: 2000});
        return;
      }
      if (isErrorChapter) {
        messageBox.show(this, {caption: this.getLanguageResource('12654', 'F', '', '챕터항목을 확인하세요.'),messageBoxButton: 'Ok',messageBoxImage: 'warning',messageBoxText: '',messageBoxFocus: 'Ok',messageboxInterval: 2000});
        return;
      }
      // validation
      this.get('service').setGuidebookList(params).then(() => {
        this.get('toast').toastr({ type: 'save', content: this.getLanguageResource('8942', 'F', '', 'Saved.'), title: '', option: { closeButton: false, timeOut: 3000, positionClass: 'toast-bottom-center' } });
        if (selectedTab === 'common') {
          this._getGuidebookList({privateUserId: 'Public'});
        } else {
          this._getGuidebookList({privateUserId: this.get('co_CurrentUserService.user.employeeId')});
        }
      });
    },
    // copy selected tree item
    copySelectedTreeItem(index) {
      const selectedTab = this.get('model.selectedTabName').replace('journeymap-configuration-', '');
      const selectedItem = this.get(`model.${selectedTab}.spot.selectedItem`);
      let isExistSpot = false;

      if (isEmpty(selectedItem)) {
        messageBox.show(this, {caption: this.getLanguageResource('12655', 'F', '', '아이템을 선택해주세요.'),messageBoxButton: 'Ok',messageBoxImage: 'warning',messageBoxText: '',messageBoxFocus: 'Ok',messageboxInterval: 2000});
        return;
      }
      this.get(`model.${selectedTab}.guidebook.list`).forEach(item => {
        if (item.chapterList.filterBy('spotId', selectedItem.spotId).length > 0) {
          isExistSpot = true;
        }
      });
      if (isExistSpot) {
        messageBox.show(this, {caption: this.getLanguageResource('12656', 'F', '', '이미 존재하는 아이템입니다.'),messageBoxButton: 'Ok',messageBoxImage: 'warning',messageBoxText: '',messageBoxFocus: 'Ok',messageboxInterval: 2000});
        return;
      }
      this.get(`model.${selectedTab}.guidebook.list`)[index].chapterList.pushObject({
        chapterId: null,
        displaySequence: null,
        guideBookId: null,
        icon: {
          iconId: null,
          content: null,
          class: null,
          path: null
        },
        isValidDataRow: true,
        spotId: selectedItem.spotId,
        spotName: selectedItem.name
      });
    },
    // set icon color
    setIconColor(result) {
      const selectedTab = this.get('model.selectedTabName').replace('journeymap-configuration-', '');

      if (isEmpty(this.get(`model.${selectedTab}.guidebook.list`)[result.index].chapterList[result.subIndex].icon)) {
        set(this.get(`model.${selectedTab}.guidebook.list`)[result.index].chapterList[result.subIndex], 'icon', {
          iconId: null,
          content: result.color,
          class: result.shape,
          path: result.path
        });
      } else {
        set(this.get(`model.${selectedTab}.guidebook.list`)[result.index].chapterList[result.subIndex].icon, 'class', result.shape);
        set(this.get(`model.${selectedTab}.guidebook.list`)[result.index].chapterList[result.subIndex].icon, 'content', result.color);
        set(this.get(`model.${selectedTab}.guidebook.list`)[result.index].chapterList[result.subIndex].icon, 'path', result.path);
      }
    }
  },
  // set properties
  _setProperties() {
    this.set('model', ConfigurationModel.create());
  },
  // set properties data
  _setPropertiesData() {
    this.set('emptyModel', EmberObject.create());
    this._getSpotList(null);
    this._getGuidebookList({privateUserId: 'Public'});
    this._getGuidebookList({privateUserId: this.get('co_CurrentUserService.user.employeeId')});
  },
  // get spot list
  _getSpotList(params) {
    this.get('service').getSpotList(params).then((result) => {
      this.set('model.common.spot.list', result);
      this.set('model.custom.spot.list', result);
    });
  },
  // get guide book list
  _getGuidebookList(params) {
    this.get('service').getGuidebookList(params).then((result) => {
      const addLength = 4 - (isEmpty(result) ? 0 : result.length);
      let resultList = result;

      if (isEmpty(resultList)) {
        resultList = [];
      }
      for (let i = 0; i < addLength; i++) {
        resultList.push({
          chapterList: [],
          code: null,
          displaySequence: null,
          guideBookId: null,
          guideBookType: null,
          isValidDataRow: false,
          name: null,
          privateUserId: null,
          className: '',
          isBasic: false
        });
      }
      if (params.privateUserId === 'Public') {
        this.set('model.common.guidebook.list', resultList);
        this.set('model.common.guidebook.isBasic', resultList[0].isBasic);
      } else {
        this.set('model.custom.guidebook.list', resultList);
        this.set('model.custom.guidebook.isBasic', resultList[0].isBasic);
      }
    });
  }
});