/* eslint-disable max-lines */
/* eslint-disable prefer-object-spread */
/* eslint-disable no-console */
import layout from './template';
import CHIS from 'framework/chis-framework';
import { isEmpty, isPresent } from '@ember/utils';
import { set } from '@ember/object';
import { inject as service } from '@ember/service';

export default CHIS.FR.Core.ComponentBase.extend(
  CHIS.FR.CrossCutting.ServerCallMixin,
  {
    toast: service('toast-service'),
    layout,
    isShowLoader: false,
    categoryNameOpend: false,
    queryDetailPopupOpen: false,
    toggleChecked: true,
    serviceCodeDisabled: false,
    queryDetailDatePopupOpen: false,
    numClicks: 0,
    isPrevent: false,
    singleClickTimer: 0,
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','intelligence-summary-integrated-result-management');
    },

    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1624');
      this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'intelligencesummary') + 'intelligence-summary/v0/');
      this._getBusinessCodes();
      this._init();
    },
    actions: {
      onRefreshClick() {
        this._init();
      },
      onDeleteListItem() {
        this.showConfirmDelete().then((res) => {
          if(res === 'Yes') {
            this._deleteCategory();
          }
        });
      },
      onAddListItem(e) {
        this.set('inputCategoryServiceCode', null);
        this.set('categotyPopupTarget', e.originalEvent.currentTarget);
        this.set('selectedCategoryItem', {id: null, name: null, serviceCode: null});
        this.set('categoryServiceDisabled', false);
        this.set('categoryNameOpend', true);
      },
      onCagetoryNameSave() {
        if(isEmpty(this.get('selectedCategoryItem.id'))) {
          this._createCategory();
        } else {
          this._updateCategory();
        }
      },
      onLoadCagetoryCombobox(e) {
        this.set('categoryCombobox', e.source);
      },
      onCategoryChanged(e) {
        if(isPresent(e.item)) {
          this.set('categoryId', e.item.id);
        }
      },
      onToggleChanged (e) {
        let nodeContainer = document.getElementById('editNodeList');
        let nodeEle = nodeContainer.getElementsByClassName('caret');
        let editNodeListEle = nodeContainer.getElementsByClassName('nested');
        let foldElements = nodeContainer.getElementsByClassName('node-fold');
        if(e.checked) {
          for(let i = 0; i < nodeEle.length; i++) {
            nodeEle[i].classList.add('caret-down');
          }
          for(let i = 0; i < editNodeListEle.length; i++) {
            editNodeListEle[i].classList.add('active');
          }
          for(let i = 0; i < foldElements.length; i++) {
            foldElements[i].classList.add('fold-on');
          }
        } else {
          for(let i = 0; i < editNodeListEle.length; i++) {
            editNodeListEle[i].classList.remove('active');
          }
          for(let i = 0; i < nodeEle.length; i++) {
            nodeEle[i].classList.remove('caret-down');
          }
          for(let i = 0; i < foldElements.length; i++) {
            foldElements[i].classList.remove('fold-on');
          }
        }
        nodeContainer = null;
        nodeEle = null;
        editNodeListEle = null;
        foldElements = null;
      },
      onTreeClick() {
        event.target.parentElement.querySelector(".nested").classList.toggle("active");
        event.target.parentElement.querySelector(".node-fold").classList.toggle("fold-on");
        event.target.classList.toggle("caret-down");
      },
      onCategoryClick(item) {
        this.set('inputCategoryServiceCode', null);
        const evt = event;
        this.numClicks++;
        if (this.numClicks === 1) {
          this.singleClickTimer = setTimeout(() => {
            this.numClicks = 0;
            evt.target.parentElement.querySelector(".nested").classList.toggle("active");
            evt.target.parentElement.querySelector(".node-fold").classList.toggle("fold-on");
            evt.target.parentElement.querySelector(".caret").classList.toggle("caret-down");
            this.set('selectedCategoryItem', item);
            this._setSelectedClass(evt);
          }, 400);
        } else if (this.numClicks === 2) {
          clearTimeout(this.singleClickTimer);
          this.numClicks = 0;
          this.set('categotyPopupTarget', evt.currentTarget);
          this.set('selectedCategoryItem', item);
          this.set('categoryNameOpend', true);
          if(isPresent(item.serviceCode)) {
            this.set('categoryServiceDisabled', true);
            this.set('inputCategoryServiceCode', item.serviceCode.split('category-')[1]);
          }
        }
      },
      onTreeDoubleClick(item) {
        this.set('categotyPopupTarget', event.currentTarget);
        this.set('selectedCategoryItem', item);
        this.set('categoryNameOpend', true);
      },
      onResultListClick(item, categoryId) {
        this.set('inputServiceCode', null);
        this.set('unavailableTime', {startDateTime: null, endDateTime: null, isExceptWeekend: false,});
        this.set('integratedResultId', null);
        this.set('integratedResultName', null);
        this.set('queryDetail', null);
        this.set('categoryId', categoryId);
        this.set('selectedCategoryItem', null);
        this.set('integratedResultId', item.integratedResultId);
        this.set('serviceCodeDisabled', true);
        if(isPresent(item.serviceCode)) {
          this.set('inputServiceCode', item.serviceCode.split('find-')[1]);
        }
        if(isPresent(item.unavailableTime)) {
          this.set('unavailableTime', item.unavailableTime);
        }
        this.set('integratedResultName', item.name);
        this.set('queryDetail', item.queryDetail);
        this._getResultParameters();
        this._getResultHeaderList();
        this._setSelectedClass(event);
      },
      onGridSelectionChanged() {
        //
      },
      onGridLoaded(type, e) {
        this.set(`${type}Grid`, e.source);
      },
      onGridCellClick(e) {
        if(isEmpty(e.item)){
          return;
        }
        if(e.column.field === 'queryDetail' && (e.item.paramTypeCode === "Combo_Multi" || e.item.paramTypeCode === "Combo_Single")) {
          this.set('queryDetailText', e.item.queryDetail);
          this.set('queryDetailTarget', `#${e.originalSource.elementId}`);
          this.set('queryDetailPopupOpen', true);
        }
        if(e.column.field === 'queryDetail' && e.item.paramTypeCode === "DateTime") {
          const dateItemItems = this.conditionItems.filter(d => d.paramTypeCode === "DateTime");
          this.set('dateParameterItems', dateItemItems.filter(d => d.parameterCode !== e.item.parameterCode));
          if(isEmpty(e.item.intervalCheck)) {
            this.set('tagetDateSetItem', {parameterName: e.item.parameterName, intervalCheck:{interval: null, parameterCode: null}});
          } else {
            this.set('tagetDateSetItem', {parameterName: e.item.parameterName, intervalCheck: {interval: e.item.intervalCheck.interval, parameterCode: e.item.intervalCheck.parameterCode}});
          }
          this.set('queryDetailTarget', `#${e.originalSource.elementId}`);
          this.set('queryDetailDatePopupOpen', true);
        } else if(e.column.field === 'pickerTypeCode' && e.item.paramTypeCode === "DateTime") {
          set(this.get('conditionColumns').find(d => d.field === 'pickerTypeCode'), 'readOnly', false);
        } else if(e.column.field === 'pickerTypeCode' && e.item.paramTypeCode !== "DateTime") {
          set(this.get('conditionColumns').find(d => d.field === 'pickerTypeCode'), 'readOnly', true);
        }
      },
      onGridEditEnd(e) {
        console.log('onGridEditEnd--', e);
        if(e.item.paramTypeCode !== "DateTime") {
          set(e.item, 'pickerTypeCode', null);
        }
      },
      onDetailConfirm() {
        set(this.get('selectedConditionItem'), 'queryDetail', this.get('queryDetailText'));
        this.set('queryDetailPopupOpen', false);
      },
      onIntervalConfirm() {
        const intervalCheck = this.get('tagetDateSetItem.intervalCheck');
        if(isEmpty(intervalCheck.interval) && isPresent(intervalCheck.parameterCode)) {
          return;
        }
        if(isPresent(intervalCheck.interval) && isEmpty(intervalCheck.parameterCode)) {
          return;
        }
        if(isEmpty(intervalCheck.interval) && isEmpty(intervalCheck.parameterCode)) {
          set(this.get('selectedConditionItem'), 'intervalCheck', null);
          this.set('queryDetailDatePopupOpen', false);
          return;
        }
        this.conditionItems.forEach(d => {
          if(d.parameterCode === intervalCheck.parameterCode) {
            set(d, 'intervalCheck', null);
          }
        });
        set(this.get('selectedConditionItem'), 'intervalCheck', intervalCheck);
        this.set('queryDetailDatePopupOpen', false);
      },
      onDeleteGridItem(type) {
        const gridSource = this.get(`${type}Grid`);
        const selectedItems = gridSource.selectedItems;
        if(isEmpty(selectedItems)) {
          return;
        }
        if(type === 'condition' && isPresent(selectedItems[0].integratedResultParameterId)) {
          this.get('deleteParameterIds').addObject(selectedItems[0].integratedResultParameterId);
        } else if(type === 'header' && isPresent(selectedItems[0].integratedResultHeaderId)) {
          this.get('deleteHeaderIds').addObject(selectedItems[0].integratedResultHeaderId);
        }
        this.get(`${type}Items`).removeObject(selectedItems[0]);
        // gridSource.selectRow(this.get(`${type}Items.lastObject`));
      },
      onAddGridItem(type) {
        let integratedResultId = null;
        if(isPresent(this.get('integratedResultId'))) {
          integratedResultId = this.get('integratedResultId');
        }
        let obj = null;
        if(type === 'condition') {
          obj = {
            integratedResultId: integratedResultId,
            integratedResultParameterId: null,
            parameterCode: null,
            parameterName: null,
            parameterDataType: null,
            queryDetail: null,
            isRequired: false,
            intervalCheck: null,
            pickerTypeCode: null,
          };
        } else {
          obj = {
            integratedResultId: integratedResultId,
            integratedResultHeaderId: null,
            headerTitle: null,
            fieldName: null,
            alignCode: null,
            headerWidth: null,
            typeCode: null,
            dataFormatCode: null,
            isToolTipContainer: false,
          };
        }
        this.get(`${type}Items`).addObject(obj);
        this.get(`${type}Grid`).selectRow(obj);
      },
      onBeforeKeyDown(e) {
        if (e.originalEvent.keyCode === 9) {
          let gridComponent = e.source,
            currentCell = gridComponent.getCurrentCell(),
            itemIndex = gridComponent.getItemIndex(currentCell.item);
          const columnIndex = gridComponent.getColumnIndex(currentCell.column);
          if(currentCell.column.field === 'parameterValue' && itemIndex !== -1 && columnIndex !== -1) {
            itemIndex = itemIndex + 1;
            e.cancel = true;
            gridComponent.selectRow(itemIndex);
            gridComponent.focusCell(itemIndex, columnIndex);
            gridComponent.editCell(itemIndex, columnIndex);
          }
          gridComponent = null;
          currentCell = null;
        }
      },
      onDeleteClick() {
        if(isEmpty(this.get('integratedResultId'))) {
          return;
        }
        this.showConfirmDelete().then((res) => {
          if(res === 'Yes') {
            this._deleteResult();
          }
        });
      },
      onSaveClick() {
        if(isEmpty(this.categoryId) || isEmpty(this.inputServiceCode) || isEmpty(this.queryDetail)) {
          this.showMessage(this.getLanguageResource('8945', 'F', '필수값을 입력하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        if(isEmpty(this.get('integratedResultId'))) {
          this._createResult();
        } else {
          this._updateResult();
        }
      },
      onResetClick() {
        let selectedElemnt = document.getElementById('editNodeList').querySelector('.selected');
        if(isPresent(selectedElemnt)) {
          selectedElemnt.classList.remove('selected');
        }
        selectedElemnt = null;
        this.set('conditionItems', []);
        this.set('headerItems', []);
        this._parameterReset();
      },
    },
    _init() {
      this.set('resultList', null);
      this.set('conditionItems', []);
      this.set('headerItems', []);
      this._getResultList();
    },
    _parameterReset() {
      this.set('deleteParameterIds', []);
      this.set('deleteHeaderIds', []);
      this.set('inputServiceCode', null);
      this.set('integratedResultId', null);
      this.set('integratedResultName', null);
      this.set('queryDetail', null);
      this.set('serviceCodeDisabled', false);
      this.set('unavailableTime', {startDateTime: null, endDateTime: null, isExceptWeekend: false,});
    },
    async _getBusinessCodes() {
      try {
        const [parameterDataTypeList, alignCodeList, typeCodeList, dataFormatCodeList, pickerTypeCodeList] = await Promise.all([
          this._getBusinessCode('ParameterDataType'),
          this._getBusinessCode('AlignCode'),
          this._getBusinessCode('TypeCode'),
          this._getBusinessCode('DataFormatCode'),
          this._getBusinessCode('PickerTypeCode')
        ]);
        this.set('alignCodeList', alignCodeList);
        this.set('typeCodeList', typeCodeList);
        this.set('dataFormatCodeList', dataFormatCodeList);
        this.set('parameterDataTypeList', parameterDataTypeList);
        this.set('pickerTypeCodeList', pickerTypeCodeList);
        this._setGridColumns();
      }catch(e) {
        this.set('isShowLoader', false);
      }
    },
    _setGridColumns() {
      this.set('conditionColumns', [
        { field: 'parameterCode', title: this.getLanguageResource('tempkey', 'F', '', '변수'), width: 130, readOnly: false,},
        { field: 'parameterName', title: this.getLanguageResource('tempkey', 'F', '', '변수명'), width: 100,},
        { field: 'paramTypeCode', title: this.getLanguageResource('tempkey', 'F', '', '타입'), width: 80,type: 'dropdown', selectedValuePath: 'displayCode', displayMemberPath: 'name', itemsSource:this.get('parameterDataTypeList')},
        { field: 'pickerTypeCode', title: this.getLanguageResource('tempkey', 'F', '', '날짜타입'), width: 70,type: 'dropdown', readOnly: true, selectedValuePath: 'displayCode', displayMemberPath: 'name', itemsSource:this.get('pickerTypeCodeList')},
        { field: 'queryDetail', title: this.getLanguageResource('tempkey', 'F', '', '상세설정'), width: 60, align: 'center', bodyTemplateName: 'detail'},
        { field: 'isRequired', title: this.getLanguageResource('tempkey', 'F', '', '필수'), width: 40, align: 'center', type: 'boolean', },
      ]);
      this.set('headerColumns', [
        { field: 'headerTitle', title: this.getLanguageResource('tempkey', 'F', '', '항목명'), width: 100, readOnly: false,},
        { field: 'fieldName', title: this.getLanguageResource('tempkey', 'F', '', '필드명'), width: 140,},
        { field: 'alignCode', title: this.getLanguageResource('tempkey', 'F', '', '정렬'), width: 50, type: 'dropdown', selectedValuePath: 'displayCode', displayMemberPath: 'displayCode', itemsSource:this.get('alignCodeList')},
        { field: 'headerWidth', title: this.getLanguageResource('tempkey', 'F', '', '너비'), width: 50, align: 'center'},
        { field: 'typeCode', title: this.getLanguageResource('tempkey', 'F', '', '타입'), width: 50,type: 'dropdown', selectedValuePath: 'displayCode', displayMemberPath: 'displayCode', itemsSource:this.get('typeCodeList')},
        { field: 'dataFormatCode', title: this.getLanguageResource('tempkey', 'F', '', '날짜포멧'), width: 60,align: 'center',type: 'dropdown', selectedValuePath: 'displayCode', displayMemberPath: 'displayCode', itemsSource:this.get('dataFormatCodeList')},
        { field: 'isToolTipContainer', title: this.getLanguageResource('tempkey', 'F', '', '툴팁'), width: 40, align: 'center', type: 'boolean', },
      ]);
    },
    _getBusinessCode(code) {
      return this.getList(this.get('defaultUrl') + 'integrated-result/businesscodes', {classificationCode: code}, null);
    },
    async _getResultList() {
      try {
        this._parameterReset();
        this.set('categoryId', null);
        this.set('isShowLoader', true);
        const params = {
          addQuery: true,
        };
        const result = await this.getList(this.get('defaultUrl') + 'integrated-result/search', params, null);
        this.set('resultList', result);
        this.set('isShowLoader', false);
      }catch(e) {
        this.set('isShowLoader', false);
      }
    },
    async _createCategory() {
      try{
        if(isEmpty(this.get('selectedCategoryItem.name') || isEmpty(this.get('inputCategoryServiceCode')))) {
          this.showMessage(this.getLanguageResource('8945', 'F', '필수값을 입력하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        this.set('isShowLoader', true);
        const params = {
          name: this.get('selectedCategoryItem.name'),
          serviceCode: `intelligencesummary/integrated-result/category-${this.get('inputCategoryServiceCode')}`,
        };
        await this.create(this.get('defaultUrl') + `integrated-result/category`, null, params);
        this.set('categoryNameOpend', false);
        this.showToastSaved();
        this._getResultList();
      }catch(e) {
        this.showToastSaveFail();
        this.set('isShowLoader', false);
      }
    },
    async _updateCategory() {
      try {
        if(isEmpty(this.get('selectedCategoryItem')) || isEmpty(this.get('selectedCategoryItem.name'))) {
          return;
        }
        this.set('isShowLoader', true);
        const params = {
          integratedResultCategoryId: this.get('selectedCategoryItem.id'),
          name: this.get('selectedCategoryItem.name'),
          serviceCode: `intelligencesummary/integrated-result/category-${this.get('inputCategoryServiceCode')}`,
        };
        await this.update(this.get('defaultUrl') + 'integrated-result/category', null, false, params);
        this.showToastSaved();
        this.set('categoryNameOpend', false);
        this._getResultList();
      } catch(e) {
        this.showToastSaveFail();
        this.set('isShowLoader', false);
      }
    },
    async _deleteCategory(){
      try{
        if(isEmpty(this.get('selectedCategoryItem.id'))) {
          return;
        }
        this.set('isShowLoader', true);
        await this.delete(this.get('defaultUrl') + `integrated-result/category`, null, {integratedResultCategoryId: this.get('selectedCategoryItem.id')});
        this._getResultList();
        this.showToastDeleted();
      }catch(e) {
        this.showToastSaveFail();
        this.set('isShowLoader', false);
      }
    },
    async _createResult(){
      try{
        const params = this._getSaveParameters();
        this.set('isShowLoader', true);
        await this.create(this.get('defaultUrl') + `integrated-result`, null, params);
        this.showToastSaved();
        this._init();
      }catch(e) {
        this.showToastSaveFail();
        this.set('isShowLoader', false);
      }
    },
    async _updateResult() {
      try {
        this.set('isShowLoader', true);
        await this._deleteCondition();
        await this._deleteHeader();
        const params = Object.assign({integratedResultId: this.integratedResultId}, this._getSaveParameters());
        await this.update(this.get('defaultUrl') + 'integrated-result', null, false, params);
        this.showToastSaved();
        this._init();
      } catch(e) {
        this.showToastSaveFail();
        this.set('isShowLoader', false);
      }
    },
    _getSaveParameters() {
      return {
        name: this.get('integratedResultName'),
        serviceCode: `intelligencesummary/integrated-result/find-${this.inputServiceCode}`,
        displaySequence: 0,
        queryDetail: this.queryDetail.replace(/"/giu, "\""),
        integratedResultCategoryId: this.categoryId,
        integratedResultHeaders: this._getResultHeadersParams(),
        integratedResultParameters: this._getIntegratedResultParameters(),
        unavailableTime: isEmpty(this.get('unavailableTime.startDateTime')) ? null : this.get('unavailableTime')
      };
    },
    _getResultHeadersParams() {
      const tempArr = [];
      if(isPresent(this.get('headerItems'))) {
        this.headerItems.forEach((d, index) => {
          tempArr.push({
            integratedResultHeaderId: d.integratedResultHeaderId,
            headerTitle: d.headerTitle,
            fieldName: d.fieldName,
            alignCode: d.alignCode,
            headerWidth: d.headerWidth,
            typeCode: d.typeCode,
            dataFormatCode: d.dataFormatCode,
            isToolTipContainer: d.isToolTipContainer,
            displaySequence: index
          });
        });
      }
      return tempArr;
    },
    _getIntegratedResultParameters() {
      const tempArr = [];
      if(isPresent(this.get('conditionItems'))) {
        this.conditionItems.forEach((d, index) => {
          tempArr.push({
            integratedResultParameterId: d.integratedResultParameterId,
            parameterCode: d.parameterCode,
            parameterName: d.parameterName,
            paramTypeCode: d.paramTypeCode,
            queryDetail: d.queryDetail,
            isRequired: d.isRequired,
            // linkAttirbute: {
            //   viewId: "string",
            //   callBackName: "string",
            //   selectedValuePath: "string",
            //   displayMemberPath: "string"
            // },
            linkAttirbute: null,
            intervalCheck: d.intervalCheck,
            displaySequence: index,
            pickerTypeCode: d.pickerTypeCode,

          });
        });
      }
      return tempArr;
    },
    async _deleteResult(){
      try{
        this.set('isShowLoader', true);
        await this.delete(this.get('defaultUrl') + `integrated-result`, null, {integratedResultId: this.get('integratedResultId')});
        this._getResultList();
      }catch(e) {
        this.set('isShowLoader', false);
      }
    },
    async _deleteCondition(){
      try{
        if(isEmpty(this.get('deleteParameterIds'))) {
          return;
        }
        const param = {
          integratedResultParameterIds: this.get('deleteParameterIds')
        };
        await this.delete(this.get('defaultUrl') + `integrated-result/parameter`, null, param);
      }catch(e) {
        console.log('error::', e);
      }
    },
    async _deleteHeader(){
      try{
        if(isEmpty(this.get('deleteHeaderIds'))) {
          return;
        }
        const param = {
          integratedResultHeaderIds: this.get('deleteHeaderIds')
        };
        await this.delete(this.get('defaultUrl') + `integrated-result/header`, null, param);
      }catch(e) {
        console.log('error::', e);
      }
    },
    async _getResultParameters() {
      try {
        this.set('isShowLoader', true);
        this.set('conditionItems', null);
        const id = this.get('integratedResultId');
        if(isEmpty(id)) {
          return;
        }
        const result = await this.getList(this.get('defaultUrl') + 'integrated-result/parameter', {integratedResultId: id, addResult: false}, null);
        this.set('conditionItems', result);
        this.set('isShowLoader', false);
      }catch(e) {
        this.set('isShowLoader', false);
      }
    },
    async _getResultHeaderList() {
      try {
        this.set('isShowLoader', true);
        const id = this.get('integratedResultId');
        if(isEmpty(id)) {
          return;
        }
        const result = await this.getList(this.get('defaultUrl') + 'integrated-result/header', {integratedResultId: id}, null);
        this.set('headerItems', result);
        this.set('isShowLoader', false);
      }catch(e) {
        this.set('isShowLoader', false);
      }
    },
    _setSelectedClass(evt) {
      let selectedElemnt = document.getElementById('editNodeList').querySelector('.selected');
      if(isPresent(selectedElemnt)) {
        selectedElemnt.classList.remove('selected');
      }
      selectedElemnt = null;
      if(evt.target.className.indexOf('fold') > -1) {
        evt.target.parentElement.classList.add('selected');
      } else {
        evt.target.classList.add('selected');
      }
    },

    showMessage(caption, messageBoxImage, messageBoxButton, messageBoxFocus, messageBoxText, messageboxInterval){
      const options = {
        'caption': caption,
        'messageBoxImage': messageBoxImage,
        'messageBoxButton': messageBoxButton,
        'messageBoxFocus': messageBoxFocus,
        'messageBoxText': messageBoxText,
        'messageboxInterval': messageboxInterval
      };
      return messageBox.show(this, options);
    },
    showConfirm(caption, messageBoxText){
      const options = {
        'caption': caption,
        'messageBoxButton': 'YesNo',
        'messageBoxImage': 'question',
        'messageBoxText': messageBoxText,
        'messageBoxFocus': 'No'
      };
      return messageBox.show(this, options);
    },
    showConfirmDelete(){
      return this.showConfirm(this.getLanguageResource('8929', 'F', null, '삭제하시겠습니까?'), '');
    },
    showToast(type, content, title){
      this.get('toast').toastr({type: type, content: content, title: title,
        option: {
          closeButton: false,
          timeOut: 3000,
          positionClass: 'toast-bottom-center'
        }
      });
    },
    showToastSaved() {
      return this.showToast('save', this.getLanguageResource('8942', 'F', null, '저장되었습니다.'), '');
    },
    showToastSaveFail() {
      this.showToast('error', '', this.getLanguageResource('9195', 'F', '', '저장에 실패하였습니다'));
    },
    showToastDeleted() {
      return this.showToast('delete', '', this.getLanguageResource('8944', 'F', null, '삭제되었습니다'));
    },
  });