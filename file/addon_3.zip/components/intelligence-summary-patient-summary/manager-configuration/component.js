import { isEmpty } from '@ember/utils';
import { set } from '@ember/object';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import ManagerModel from 'intelligencesummary-module/models/summary-manager-configuration-model';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  {
    toast: service('toast-service'),
    httpService: service('summary-manager-configuration-http-service'),
    layout,
    model: null,
    // init
    onPropertyInit() {
      this._super(...arguments);
      this._setProperties();
    },
    // onload
    onLoaded() {
      this._super(...arguments);
      this._setPropertiesData();
    },
    actions: {
      onLoadedSheetGrid(e) {
        this.set('model.sheetGridControl', e);
      },
      onLoadDetailContentsGrid(e) {
        this.set('model.contentsDetailInfo.gridControl', e.source);
      },
      // click search
      onClickSearch() {
        this._initPropertiesData('basicInfo');
        this._initPropertiesData('contentsInfoIncludeList');
        this._initPropertiesData('contentsDetailInfo');
        this._getGridList(true);
      },
      // click add
      onClickAdd() {
        this.set('model.grid.selectedItem', null);
        this._initPropertiesData('basicInfo');
        this._initPropertiesData('contentsInfoIncludeList');
        this._initPropertiesData('contentsDetailInfo');
      },
      // cell click
      onCellClickItem(e) {
        if (isEmpty(e) || isEmpty(e.item)) {
          return;
        }
        this.set('model.grid.selectedItem', e.item);
        this._getInfoData();
      },
      // click delete contents
      onClickDeleteContents() {
        if (!isEmpty(this.get('model.contentsInfo.selectedItem'))) {
          this.get('model.contentsInfo.list').removeObject(this.get('model.contentsInfo.selectedItem'));
        }
      },
      // click add contents
      onClickAddContents() {
        this.set('model.contentsInfo.popupInfo.isOpen', true);
      },
      // cell click contents
      onCellClickContents(e) {
        if (isEmpty(e) || isEmpty(e.item)) {
          return;
        }
        this.set('model.contentsInfo.selectedItem', e.item);
      },
      // click delete contents detail
      onClickDeleteContentsDetail() {
        const contentsItem = this.get('model.contentsInfo.selectedItem');
        if (isEmpty(contentsItem) === true) {
          return;
        }
        if (isEmpty(contentsItem.members) === true) {
          return;
        }
        if (isEmpty(this.get('model.contentsDetailInfo.gridControl.selectedItems')) === true) {
          return;
        }
        const list = contentsItem.members.toArray();
        list.forEach(itm => {
          const isExists = this.get('model.contentsDetailInfo.gridControl.selectedItems').some(i => i === itm);
          if (isExists === true) {
            contentsItem.members.removeObject(itm);
          }
        });

      },
      // click add contents detail
      onClickAddContentsDetail() {
        const contentsItem = this.get('model.contentsInfo.selectedItem');
        if (isEmpty(contentsItem) === true) {
          return;
        }
        if (contentsItem.contentTypeCode === 'C0003' || contentsItem.contentTypeCode === 'C0004' || contentsItem.contentTypeCode === 'C0005' || contentsItem.contentTypeCode === 'C0006') {
          //examinationTypeCode : Laboratory(진검) / Pathology(병리) / Radiology(영상) / Clinic(기능) / 핵체외(NuclearMedicineInVitro) / 핵체내(NuclearMedicineInVivo)
          switch(contentsItem.contentTypeCode) {
            //C0003 : 진단검사
            case 'C0003':
              this.set('model.contentsDetailInfo.popupInfo.examinationTypeCode', 'Laboratory');
              break;
            case 'C0004':
              //C0004 : 병리검사
              this.set('model.contentsDetailInfo.popupInfo.examinationTypeCode', 'Pathology');
              break;
            case 'C0005':
              //C0005 : 영상검사
              this.set('model.contentsDetailInfo.popupInfo.examinationTypeCode', 'Radiology');
              break;
            case 'C0006':
              //C0006 : 기능검사
              this.set('model.contentsDetailInfo.popupInfo.examinationTypeCode', 'Clinic');
              break;
            default:
              return;
          }
          this.set('model.contentsDetailInfo.popupInfo.isExaminationOpen', true);
        }
      },
      // cell click contents detail
      onCellClickContentsDetail() {
        this.set('emptyModel', null);
      },
      // select item
      selectItem(item) {
        // 같은 contents 도 지금은 등록가능.
        //const isExist = this.get('model.contentsInfo.list').filterBy('contentsId', item.contentsId).length > 0 ? true : false;
        this.set('model.contentsInfo.popupInfo.isOpen', false);
        //if (!isExist) {
        this._addContentsItem(item);
        //}
      },
      //컨텐츠 상세 팝업 아이템 선택
      onSelectItemContentsDetail(type, item) {
        const contentsItem = this.get('model.contentsInfo.selectedItem');
        if (isEmpty(contentsItem) === true) {
          return;
        }
        if (isEmpty(contentsItem.members) === true) {
          set(contentsItem, 'members', []);
        }
        if (type === 'Examination') {
          //검사
          contentsItem.members.pushObject({
            memberId: null,
            memberTypeCode: 0,
            elementId: item.examinationId,
            elementCode: item.examinationCode,
            elementName: item.examinationName,
            sheetMapId: contentsItem.sheetMapId,
            isValidDataRow: true
          });
        }
        this.set('model.contentsDetailInfo.popupInfo.isExaminationOpen', false);
      },
      // click new
      onClickNew() {
        this.set('model.grid.selectedItem', null);
        this._initPropertiesData('basicInfo');
        this._initPropertiesData('contentsInfoIncludeList');
        this._initPropertiesData('contentsDetailInfo');
      },
      // click copy
      onClickCopy() {
        this.set('emptyModel', null);
      },
      // click delete
      onClickDelete() {
        this._deleteManager();
      },
      // click save
      onClickSave() {
        this._saveManager();
      }
    },
    // set properties
    _setProperties() {
      this.set('viewId', 'intelligence-summary-patient-summary/manager-configuration');
      this.set('model', ManagerModel.create());
    },
    // set properties data
    _setPropertiesData() {
      this.set('menuClass', 'w1180');
      this._setColumns();
      this._getShareTargetList();
      this._getShareInformationList('Department');
      this._getShareInformationList('Personal');
      this._getShareInformationList('Ward');
      this._getGridList();
    },
    // init properties data
    _initPropertiesData(type) {
      if (type === 'grid') {
        this.set('model.grid.selectedUserType', null);
        this.set('model.grid.searchTtext', null);
        this.set('model.grid.selectedItem', null);
      } else if (type === 'basicInfo') {
        this.set('model.basicInfo.sheetName', null);
        this.set('model.basicInfo.isDefault', false);
        if (!isEmpty(this.get('model.basicInfo.shareList'))) {
          this.set('model.basicInfo.selectedShare', this.get('model.basicInfo.shareList')[0].shareTargetDisplayCode);
        }
        if (!isEmpty(this.get('model.basicInfo.departmentList'))) {
          this.set('model.basicInfo.selectedDepartment', this.get('model.basicInfo.departmentList')[0].departmentId);
        }
        if (!isEmpty(this.get('model.basicInfo.employeeList'))) {
          this.set('model.basicInfo.selectedEmployee', this.get('model.basicInfo.employeeList')[0].employeeId);
        }
        if (!isEmpty(this.get('model.basicInfo.wardList'))) {
          this.set('model.basicInfo.selectedWard', this.get('model.basicInfo.wardList')[0].departmentId);
        }
        this.set('model.basicInfo.content', null);
      } else if (type === 'contentsInfo') {
        this.set('selectedContentsIndex', null);
        this.set('model.contentsInfo.selectedItem', null);
      } else if (type === 'contentsInfoIncludeList') {
        this.set('selectedContentsIndex', null);
        this.set('model.contentsInfo.list', []);
        this.set('model.contentsInfo.selectedItem', null);
      }
      // else if (type === 'contentsDetailInfo') {
      //   this.set('model.contentsDetailInfo.selectedItem', null);
      // }
    },
    // delete manager
    _deleteManager() {
      const params = {
        summarySheetId: isEmpty(this.get('model.grid.selectedItem')) ? null : this.get('model.grid.selectedItem.summarySheetId')
      };

      if (isEmpty(params.summarySheetId)) {
        return;
      }
      this.get('httpService').deleteManager(params).then(() => {
        this.get('toast').toastr({
          type: 'delete',
          content: 'Deleted.',
          title: '',
          option: {
            closeButton: false,
            timeOut: 3000,
            positionClass: 'toast-bottom-center'
          }
        });
        this._getGridList();
        this.set('model.grid.selectedItem', null);
        this._initPropertiesData('basicInfo');
        this._initPropertiesData('contentsInfoIncludeList');
        this._initPropertiesData('contentsDetailInfo');
      });
    },
    // add contents item
    _addContentsItem(item) {
      this.get('model.contentsInfo.list').pushObject({
        contentsName: item.displayName,
        content: item.content,
        contentsId: item.contentsId,
        searchTypeName: item.searchTypeName,
        typeName: item.typeName
      });
    },
    // save manager
    _saveManager() {
      const params = {
        summarySheetId: isEmpty(this.get('model.grid.selectedItem')) ? null : this.get('model.grid.selectedItem.summarySheetId'),
        displayName: this.get('model.basicInfo.sheetName'), isBasic: this.get('model.basicInfo.isDefault'), content: this.get('model.basicInfo.content'),
        share: { shareTargetCode: this.get('httpService').getShareSeqByCode(this.get('model.basicInfo.selectedShare')) }
      };
      if (!isEmpty(this.get('model.contentsInfo.list'))) {
        const sheetMaps = [];
        let index = 0;
        this.get('model.contentsInfo.list').forEach(item => {
          sheetMaps.pushObject({
            contentsId: item.contentsId, displaySequence: index,
            summarySheetId: isEmpty(this.get('model.grid.selectedItem')) ? null : this.get('model.grid.selectedItem.summarySheetId'),
            content: item.content, members: item.members, isValidDataRow: true
          });
          index++;
        });
        params.sheetMaps = sheetMaps;
      }
      if (params.share.shareTargetCode === 2) {
        params.share.shareTargetId = this.get('model.basicInfo.selectedEmployee');
      } else if (params.share.shareTargetCode === 1) {
        params.share.shareTargetId = this.get('model.basicInfo.selectedEmployee');
      } else if (params.share.shareTargetCode === 3) {
        params.share.shareTargetId = this.get('model.basicInfo.selectedWard');
      } else if (params.share.shareTargetCode === 0) {
        params.share.shareTargetId = null;
      }
      this.get('httpService').saveManager(params).then(() => {
        this.get('toast').toastr({ type: 'save', content: 'Saved.', title: '', option: { closeButton: false, timeOut: 3000, positionClass: 'toast-bottom-center' } });
        this.set('model.grid.selectedItem', null);
        this._initPropertiesData('basicInfo');
        this._initPropertiesData('contentsInfoIncludeList');
        this._initPropertiesData('contentsDetailInfo');
        this._getGridList();
      });
    },
    // get share target list
    _getShareTargetList() {
      this.get('httpService').getShareTargetList().then((result) => {
        this.set('model.basicInfo.shareList', result);
        this.set('model.grid.userTypeList', result);
        if (!isEmpty(result)) {
          this.set('model.basicInfo.selectedShare', result[0].shareTargetDisplayCode);
          this.set('model.grid.selectedUserType', result[0].shareTargetDisplayCode);
        }
      });
    },
    // get share information list
    _getShareInformationList(type) {
      this.get('httpService').getShareInformationList({ groupCode: type }).then((result) => {
        if (type == 'Department') {
          this.set('model.grid.departmentList', result);
          this.set('model.basicInfo.departmentList', result);
          if (!isEmpty(result)) {
            this.set('model.grid.selectedDepartment', result[0].departmentId);
            this.set('model.basicInfo.selectedDepartment', result[0].departmentId);
          }
        } else if (type === 'Personal') {
          this.set('model.grid.employeeList', result);
          this.set('model.basicInfo.employeeList', result);
          if (!isEmpty(result)) {
            this.set('model.grid.selectedEmployee', result[0].employeeId);
            this.set('model.basicInfo.selectedEmployee', result[0].employeeId);
          }
        } else if (type === 'Ward') {
          this.set('model.grid.wardList', result);
          this.set('model.basicInfo.wardList', result);
          if (!isEmpty(result)) {
            this.set('model.grid.selectedWard', result[0].departmentId);
            this.set('model.basicInfo.selectedWard', result[0].departmentId);
          }
        }
      });
    },
    // get grid list
    _getGridList(isSearch) {
      this.set('model.loader.grid', true);
      this.set('model.grid.selectedItem', null);
      const params = {
        shareTargetCode: this.get('httpService').getShareSeqByCode(this.get('model.grid.selectedUserType')),
        content: this.get('model.grid.searchTtext')
      };
      this.get('httpService').getGridList(params).then((result) => {
        if (isEmpty(result)) {
          this.set('model.grid.list', []);
          this.set('model.loader.grid', false);
          if (isSearch) {
            messageBox.show(this, {caption: this.getLanguageResource('8948', 'F', '', '해당정보가 없습니다'),messageBoxButton: 'Ok',messageBoxImage: 'warning',messageBoxText: '',messageBoxFocus: 'Ok',messageboxInterval: 2000});
          }
          return;
        }
        this.set('model.grid.list', result);
        this.set('model.loader.grid', false);
      });
    },
    // get info data
    _getInfoData() {
      if (isEmpty(this.get('model.grid.selectedItem'))) {
        return;
      }
      if (isEmpty(this.get('model.grid.selectedItem.summarySheetId'))) {
        return;
      }
      this.set('model.loader.info', true);
      const params = {
        summarySheetId: this.get('model.grid.selectedItem').summarySheetId
      };

      this.get('httpService').getInfoData(params).then((result) => {
        if (isEmpty(result)) {
          this._initPropertiesData('basicInfo');
          return;
        }
        result.shareTargetDisplayCode = this.get('httpService').getShareCodeBySeq(result.shareTargetCode);
        this.set('model.basicInfo.sheetName', result.displayName);
        this.set('model.basicInfo.isDefault', result.isBasic);
        this.set('model.basicInfo.selectedShare', result.shareTargetDisplayCode);
        if (result.shareTargetDisplayCode === 'Department') {
          this.set('model.basicInfo.selectedDepartment', result.shareTargetId);
        }
        if (result.shareTargetDisplayCode === 'Personal') {
          this.set('model.basicInfo.selectedEmployee', result.shareTargetId);
        }
        if (result.shareTargetDisplayCode === 'Ward') {
          this.set('model.basicInfo.selectedWard', result.shareTargetId);
        }
        this.set('model.basicInfo.content', result.content);
        // 컨텐츠 리스트
        this.set('model.contentsInfo.list', result.sheetMaps);
        this.set('model.loader.info', false);
      });
    },
    // set columns
    _setColumns() {
      this.set('model.grid.columns', [
        { field: 'summarySheetId', hidden: true },
        { title: this.getLanguageResource('12412', 'F', null, 'Sheet명'), field: 'displayName', align: 'center', width: 120 },
        { title: this.getLanguageResource('1098', 'F', null, '공유'), field: 'shareTargetName', width: 100 },
        { title: this.getLanguageResource('1514', 'F', null, '기본'), field: 'isBasic', align: 'center', width: 80, type: 'boolean' },
        { title: this.getLanguageResource('12418', 'F', null, '내용'), field: 'content', width: 300 }
      ]);
      this.set('model.contentsInfo.columns', [
        { field: 'contentsId', hidden: true },
        { title: this.getLanguageResource('3607', 'F', null, '선택'), align: 'center', width: 60, bodyTemplateName: 'select', hidden: true },
        { title: this.getLanguageResource('9671', 'F', null, '분류'), field: 'typeName', width: 100 },
        { title: this.getLanguageResource('12406', 'F', null, '컨텐츠명'), field:'contentsName', align: 'center', width: 80 },
        { title: this.getLanguageResource('6956', 'F', null, '조회유형'), field: 'searchTypeName', width: 130 },
        { title: this.getLanguageResource('12418', 'F', null, '내용'), field: 'content', width: 200 }
      ]);
      this.set('model.contentsDetailInfo.columns', [
        { title: this.getLanguageResource('7674', 'F', null, '코드'), field: 'elementCode', align: 'center', width: 150 },
        { title: this.getLanguageResource('7684', 'F', null, '코드명'), field: 'elementName' },
      ]);
    }
  });