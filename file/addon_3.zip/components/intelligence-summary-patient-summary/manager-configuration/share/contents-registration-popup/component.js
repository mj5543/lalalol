import { isEmpty } from '@ember/utils';
import EmberObject from '@ember/object';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  {
    httpContentsService: service('summary-contents-configuration-http-service'),
    layout,
    model: null,
    // init
    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'intelligence-summary-patient-summary/manager-configuration/share/contents-registration-popup');
      this.set('model', EmberObject.create());
    },
    // onload
    onLoaded() {
      this._super(...arguments);
      this.set('model.gridColumns', [
        { field: 'contentsId', hidden: true },
        { title: this.getLanguageResource('9671', 'F', null, '분류'), field: 'typeName', align: 'center', width: 80 },
        { title: this.getLanguageResource('12406', 'F', null, '컨텐츠명'), field: 'displayName', width: 120 },
        { title: this.getLanguageResource('12411', 'F', null, '상세유무'), field: 'isExaminationDetail', type: 'boolean', align: 'center', width: 80 },
        { title: this.getLanguageResource('12315', 'F', null, '검색기간'), field: 'searchPeriod', align: 'center', width: 120 },
        { title: this.getLanguageResource('6956', 'F', null, '조회유형'), field: 'searchTypeName', align: 'center', width: 100 },
        { title: this.getLanguageResource('12407', 'F', null, '구성요소'), field: 'componentViewId', width: 100 },
        { title: this.getLanguageResource('12418', 'F', null, '내용'), field: 'content', width: 60 }
      ]);
      this._getContentsTypeList();
      this._getContentsList();
    },
    // action
    actions: {
      // on cell click contents
      onCellClickContents(isNext, e) {
        if (isEmpty(e) || isEmpty(e.item)) {
          return;
        }
        this.set('model.selectedItem', e.item);
        if (isNext) {
          this._selectItem();
        }
      },
      // on click select
      onClickSelect() {
        this._selectItem();
      },
      // on click search
      onClickSearch() {
        this._getContentsList();
      }
    },
    // get contents list
    _getContentsList() {
      const params = {
        typeCode: this.get('model.searchType'),
        content: this.get('model.searchText')
      };

      this.get('httpContentsService').getContentsList(params).then((result) => {
        if(!isEmpty(result) && !isEmpty(this.get('addedContentList'))){
          const newResults = [];
          //이미 추가되어 있는 항목은 조회 항목에서 제외함.
          result.forEach(item => {
            const isExist = this.get('addedContentList').filterBy('contentsId', item.contentsId).length > 0 ? true : false;
            if (!isExist){
              newResults.push(item);
            }
          });
          this.set('model.gridList', newResults);
          if (newResults.length === 0){
            const msg = this.getLanguageResource('15396', 'F', '', '더 이상 추가할 컨텐츠가 없습니다.');
            messageBox.show(this, {
              caption: msg,
              messageBoxButton: 'Ok',
              messageBoxImage: 'information',
              messageBoxText: '',
              messageBoxFocus: 'Ok',
              messageboxInterval: 5000});
          }
        } else {
          this.set('model.gridList', result);
        }
      });
    },
    // get contents type list
    _getContentsTypeList() {
      this.get('httpContentsService').getComboDataList('Contents').then((result) => {
        const allItem = {
          summaryCommonItemId: '',
          summaryCommonItemCode: '',
          summaryCommonItemName: this.getLanguageResource('6700','F',null,'전체'),
          applyValue: ''
        };

        if (isEmpty(result)) {
          this.set('model.searchTypeList', [allItem]);
        } else {
          this.set('model.searchTypeList', result);
          this.get('model.searchTypeList').unshift(allItem);
        }
        if (!isEmpty(result)) {
          this.set('model.searchType', result[0].summaryCommonItemCode);
        }
      });
    },
    // select item
    _selectItem() {
      if (isEmpty(this.get('model.selectedItem'))) {
        return;
      }
      this.get('selectItemCB')(this.get('model.selectedItem'));
    }
  });