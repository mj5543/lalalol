import EmberObject from '@ember/object';
import { isEmpty } from '@ember/utils';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import ViewerModel from 'intelligencesummary-module/models/summary-contents-viewer-model';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  {
    toast: service('toast-service'),
    httpService: service('summary-contents-viewer-http-service'),
    utilService: service('summary-contents-viewer-service'),
    layout,
    // on init
    onPropertyInit() {
      this._super(...arguments);
      this._setProperties();
    },
    // onload
    onLoaded() {
      this._super(...arguments);
      this._setPropertiesData();
    },
    actions: {
      // copy data
      copyData(data) {
        this.get('utilService').copyToClipboard(data);
        if (isEmpty(data)) {
          return;
        }
        this.get('toast').toastr({type: 'save',content: this.getLanguageResource('10457', 'F', null, 'Copied'),title: '',option: {closeButton: false,timeOut: 3000,positionClass: 'toast-bottom-center'}});
      },
      // click go top
      onClickGoTop() {
        this.$('#summary_sheet_frame').animate({ scrollTop: 0 }, 200);
      },
      // go down
      onClickGoDown() {
        let fullHeight = this.$('#summary_sheet_full').height();
        let frameHeight = this.$('#summary_sheet_frame').height();

        this.$('#summary_sheet_frame').animate({ scrollTop: fullHeight - frameHeight + 20 }, 200);
        fullHeight = null;
        frameHeight = null;
      },
      // before element
      onClickGoBeforeElement() {
        let beforeHeight = 0;
        let done = false;
        let tempHeightList = this._setComponentHeightList();
        let nowScrollTop = this.$('#summary_sheet_frame').scrollTop();

        if (nowScrollTop === 0) {
          tempHeightList = null;
          nowScrollTop = null;
          return;
        }
        if (!isEmpty(tempHeightList)) {
          tempHeightList.forEach(h => {
            if (!done) {
              beforeHeight += h;
            }
            if (nowScrollTop <= beforeHeight + 10) {
              done = true;
              beforeHeight -= h;
            }
          });
        }
        this.$('#summary_sheet_frame').animate({ scrollTop: beforeHeight === 0 ? 0 : beforeHeight + 10 }, 200);
        tempHeightList = null;
        nowScrollTop = null;
      },
      // next element
      onClickGoNextElement() {
        let nextHeight = 0;
        let done = false;
        let tempHeightList = this._setComponentHeightList();
        let nowScrollTop = this.$('#summary_sheet_frame').scrollTop();
        let fullHeight = this.$('#summary_sheet_full').height();
        let frameHeight = this.$('#summary_sheet_frame').height();

        if (nowScrollTop - (fullHeight - frameHeight) - 20 >= 0) {
          tempHeightList = null;
          nowScrollTop = null;
          fullHeight = null;
          frameHeight = null;
          return;
        }
        if (!isEmpty(tempHeightList)) {
          tempHeightList.forEach(h => {
            if (!done) {
              nextHeight += h;
            }
            if (nowScrollTop < nextHeight + 10) {
              done = true;
            }
          });
        }
        this.$('#summary_sheet_frame').animate({ scrollTop: nextHeight + 10 }, 200);
        tempHeightList = null;
        nowScrollTop = null;
        fullHeight = null;
        frameHeight = null;
      },
      // selection changed search type
      onSelectionChangedSearchType(parameters) {
        if (isEmpty(parameters)) {
          return;
        }
        if (isEmpty(parameters.inbounds)) {
          return;
        }
        if (isEmpty(parameters.inbounds.reloadFunction)) {
          return;
        }
        if (typeof parameters.inbounds.reloadFunction !== 'function') {
          return;
        }
        parameters.inbounds.reloadFunction();
      },
      // click more
      onClickMore(sheet) {
        this.set('model.morePopup.parameters', {
          outbounds: {
            patientId: sheet.parameters.outbounds.patientId,
            registrationActorId: sheet.parameters.outbounds.registrationActorId,
            searchType: this._getDefaultSearchType(sheet.sheetId),
            searchLimitCount: null,
            isPopup: true,
            element: sheet.parameters.outbounds.element
          },
          inbounds: {
            selectCount: 0,
            reloadFunction: null
          },
          arguments: sheet.parameters.arguments
        });
        this.set('model.morePopup.title', sheet.title);
        this.set('model.morePopup.component', sheet.popup.component);
        this.set('model.morePopup.height', sheet.popup.height);
        this.set('model.morePopup.width', sheet.popup.width);
        this.set('model.morePopup.targetId', '#' + sheet.elementId);
        this.set('model.morePopup.searchTypeList', sheet.searchTypeList);
        this.set('model.morePopup.isOpen', true);
      }
    },
    // on patient changed
    onPatientChanged() {
      if(this.checkPatientDataClear() === false){
        this._getSheetList();
      }
      else{
        this.set('model.sheetList', []);
      }
    },
    // set properties
    _setProperties() {
      this.set('viewId', 'intelligence-summary-patient-summary/summary-sheet');
      this.set('model', ViewerModel.create());
      this.set('model.morePopup', EmberObject.create());
    },
    // set properties data
    _setPropertiesData() {
      this.set('menuClass', 'w680');
      if (!isEmpty(this.get('co_CurrentUserService.user')) && !isEmpty(this.get('co_PatientManagerService.selectedPatient'))) {
        this._getSheetList();
      } else {
        this.closeMenu();
      }
    },
    // set component height list
    _setComponentHeightList() {
      let index = 1;
      const resultList = [];

      this.get('model.sheetList').forEach(() => {
        resultList.push(this.$('#summary_sheet_' + index).height());
        index++;
      });
      return resultList;
    },
    // get sheet list
    _getSheetList() {
      const patient = isEmpty(this.get('co_PatientManagerService.selectedPatient')) ? null : this.get('co_PatientManagerService.selectedPatient');
      const userId = isEmpty(this.get('co_CurrentUserService.user')) ? null : this.get('co_CurrentUserService.user.employeeId');
      let departmentId = null;
      if (patient.encounterClassCode === 'I' && !isEmpty(patient.inpatient)) {
        departmentId = patient.inpatient.departmentId;
      } else if (patient.encounterClassCode === 'O' && !isEmpty(patient.outpatient)) {
        departmentId = patient.outpatient.departmentId;
      } else if (patient.encounterClassCode === 'E' && !isEmpty(patient.emergencyDepartmentPatient)) {
        departmentId = patient.emergencyDepartmentPatient.departmentId;
      }
      this.get('httpService').getSheetList({departmentId:departmentId, employeeId:userId}).then((result) => {
        if (isEmpty(result[0]) || isEmpty(result[0].sheetMaps)) {
          this.set('model.sheetList', []);
          return;
        }
        const sheetList = [];
        let index = 1;
        result[0].sheetMaps.forEach(item => {
          if (!isEmpty(item.contentsInformation)) {
            const structure = this._getSheetStructure(item, index, patient.patientId, userId);
            if (item.contentsInformation.searchType === 1) {
              structure.searchTypeList = [
                {key: 'Personal', value: this.getLanguageResource('8951', 'F', '','개인')},{key: 'All', value: this.getLanguageResource('6700', 'F', null, '전체')}
              ];
            }
            if (!isEmpty(structure.component)) {
              sheetList.pushObject(structure);
              index++;
            }
          }
        });
        //console.log(sheetList);
        this.set('model.sheetList', sheetList);
      });
    },
    _getSheetStructure(item, index, patient, userId) {
      const result = {
        sheetId: item.contentsId,
        component: item.contentsInformation.componentViewId,
        popup: {
          component: item.contentsInformation.popUp.componentViewId,
          height: item.contentsInformation.popUp.applyHeight,
          width: item.contentsInformation.popUp.applyWidth
        },
        elementId: 'summary_sheet_' + index,
        title: item.contentsInformation.displayName,
        isMore: item.contentsInformation.isExaminationDetail,
        searchTypeList: [],
        parameters: {
          outbounds: {
            patientId: patient,
            registrationActorId: userId,
            searchType: item.contentsInformation.searchType === 0 ? 'All' : 'Personal',
            searchPeriod: item.contentsInformation.searchPeriod,
            searchLimitCount: item.contentsInformation.searchCount,
            isPopup: false,
            element: []
          },
          inbounds: {
            selectCount: 0,
            reloadFunction: null
          },
          arguments: {
            viewerParameter: null,
            commons: null
          }
        }
      };
      if (!isEmpty(item.contentsInformation.popUp) && !isEmpty(item.contentsInformation.popUp.argument)) {
        result.parameters.arguments.viewerParameter = JSON.parse(item.contentsInformation.popUp.argument);
      }
      return result;
    },
    // get default search type
    _getDefaultSearchType(sheetId) {
      if (isEmpty(sheetId)) {
        return null;
      }
      if (isEmpty(this.get('model.tempSheetList'))) {
        return null;
      }
      const resultItem = this.get('model.tempSheetList').filterBy('sheetId', sheetId);

      return isEmpty(resultItem) ? null : resultItem[0].parameters.outbounds.searchType;
    }
  });