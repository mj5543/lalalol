import EmberObject from '@ember/object';
import { isEmpty } from '@ember/utils';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import ConfigurationModel from 'intelligencesummary-module/models/summary-contents-configuration-model';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  {
    toast: service('toast-service'),
    service: service('summary-contents-configuration-http-service'),
    layout,
    model: null,
    compomentPopupInfo: null,
    selectedComponentType: null,
    // init
    onPropertyInit(){
      this._super(...arguments);
      this._setProperties();
    },
    // on load
    onLoaded(){
      this._super(...arguments);
      this._setPropertiesData();
    },
    // actions
    actions: {
      // component confirm
      componentConfirm(res) {
        if (!isEmpty(res)) {
          if (this.get('selectedComponentType') === 'main') {
            this.set('model.registration.selectedComponent', res[0].displayCode);
          } else {
            this.set('model.registration.selectedPopupComponent', res[0].displayCode);
          }
        }
        this.set('compomentPopupInfo.isOpen', false);
      },
      // component cancel
      componentCancel() {
        this.set('compomentPopupInfo.isOpen', false);
      },
      // text search
      onTextSearch(type) {
        this.set('selectedComponentType', type);
        this.set('compomentPopupInfo.isOpen', true);
      },
      // 그리드 클릭
      onCellClickContents(e) {
        if (isEmpty(e) || isEmpty(e.item)) {
          return;
        }
        this.set('model.grid.selectedContents', e.item);
        this._getContents();
      },
      // 검색버튼 클릭
      onClickSearch() {
        this._getContentsList(true);
      },
      // 신규
      onClickNew() {
        this._initProperties('registration');
        this.set('model.grid.selectedContents', null);
      },
      // 삭제
      onClickDelete() {
        this._deleteContents();
      },
      // 저장
      onClickSave() {
        this._saveContents();
      }
    },
    // set properties
    _setProperties() {
      this.set('viewId', 'intelligence-summary-patient-summary/contents-configuration');
      this.set('model', ConfigurationModel.create());
      this.set('compomentPopupInfo', EmberObject.create());
    },
    // set properties data
    _setPropertiesData() {
      // 그리드 리스트 가져오기
      this._setColumns();
      this._getContentsList(true);
      this._getRegistrationBasicData();
      this._getIsMoreList();
      this.set('menuClass', 'w1000');
    },
    // set is more data list
    _getIsMoreList() {
      this.set('model.registration.isMoreList', [
        {key: 'Y', value: 'Y'},
        {key: 'N', value: 'N'}
      ]);
      this.set('model.registration.selectedIsMore', 'Y');
    },
    // init grid
    _initGrid() {
      if (!isEmpty(this.get('model.grid.searchTypeList'))) {
        this.set('model.grid.selectedSearchType', this.get('model.grid.searchTypeList')[0].summaryCommonItemCode);
      } else {
        this.set('model.grid.selectedSearchType', null);
      }
      this.set('model.grid.searchText', null);
      this.set('model.grid.selectedContents', null);
    },
    // init registration
    _initRegistration() {
      this.set('model.registration.contentsName', null);
      if (!isEmpty(this.get('model.registration.contentsTypeList'))) {
        this.set('model.registration.selectedContentsType', this.get('model.registration.contentsTypeList')[0].summaryCommonItemCode);
      } else {
        this.set('model.registration.selectedContentsType', null);
      }
      this.set('model.registration.selectedFromDate', null);
      this.set('model.registration.selectedToDate', null);
      if (!isEmpty(this.get('model.registration.isDetailList'))) {
        this.set('model.registration.seletectIsDetail', this.get('model.registration.isDetailList')[0].applyValue);
      } else {
        this.set('model.registration.seletectIsDetail', null);
      }
      if (!isEmpty(this.get('model.registration.searchDateTypeList'))) {
        this.set('model.registration.selectedSearchDateType', this.get('model.registration.searchDateTypeList')[0].applyValue);
      } else {
        this.set('model.registration.selectedSearchDateType', null);
      }
      if (!isEmpty(this.get('model.registration.checkContentsList'))) {
        this.set('model.registration.selectedCheckContents', this.get('model.registration.checkContentsList')[0].searchType);
      } else {
        this.set('model.registration.selectedCheckContents', null);
      }
      this.set('model.registration.content', null);
      this.set('model.registration.arguments', null);
      this.set('model.registration.selectedComponent', null);
      this.set('model.registration.selectedPopupComponent', null);
      this.set('model.registration.searchCount', null);
      this.set('model.registration.popup', EmberObject.create());
    },
    // init properties
    _initProperties(type) {
      if (type === 'grid') {
        this._initGrid();
      } else if (type === 'registration') {
        this._initRegistration();
      } else if (type === 'all') {
        this._initGrid();
        this._initRegistration();
      }
    },
    // 분류 리스트 가져오기
    _getContentsTypeList() {
      this.get('service').getComboDataList('Contents').then((result) => {
        this.set('model.registration.contentsTypeList', result);
        if (!isEmpty(result)) {
          this.set('model.registration.selectedContentsType', result[0].summaryCommonItemCode);
        }
      });
    },
    // 상세유무 리스트 가져오기
    _getIsDetailList() {
      this.get('service').getComboDataList('ExaminationDetail').then((result) => {
        this.set('model.registration.isDetailList', result);
        if (!isEmpty(result)) {
          this.set('model.registration.seletectIsDetail', result[0].applyValue);
        }
      });
    },
    // 검색기간유형 리스트 가져오기
    _getSearchDateTypeList() {
      this.get('service').getComboDataList('SelectPeriod').then((result) => {
        if (isEmpty(result)) {
          this.set('model.registration.searchDateTypeList', []);
          return;
        }
        result.forEach((item) => {
          item.applyValue = String(item.applyValue);
        });
        this.set('model.registration.searchDateTypeList', result);
        if (!isEmpty(result)) {
          this.set('model.registration.selectedSearchDateType', result[0].applyValue);
        }
      });
    },
    // 내용식별유형 리스트 가져오기
    _getCheckContentsList() {
      this.set('model.registration.checkContentsList', []);
    },
    // get contents type list for grid
    _getContentsTypeListForGrid() {
      this.get('service').getComboDataList('Contents').then((result) => {
        const allItem = {
          summaryCommonItemId: '',
          summaryCommonItemCode: '',
          summaryCommonItemName: this.getLanguageResource('6700','F',null,'전체'),
          applyValue: ''
        };

        if (isEmpty(result)) {
          this.set('model.grid.searchTypeList', [allItem]);
        } else {
          this.set('model.grid.searchTypeList', result);
          this.get('model.grid.searchTypeList').unshift(allItem);
        }
        if (!isEmpty(result)) {
          this.set('model.grid.selectedSearchType', result[0].summaryCommonItemCode);
        }
      });
    },
    // get registration basic data
    _getRegistrationBasicData() {
      this._getContentsTypeListForGrid();
      this._getContentsTypeList();
      this._getIsDetailList();
      this._getSearchDateTypeList();
      this._getCheckContentsList();
      this._getSearchTypeList();
    },
    // get search type list
    _getSearchTypeList() {
      this.set('model.loader.contents', true);
      this.get('service').getSearchTypeList().then((result) => {
        this.set('model.registration.checkContentsList', result);
        if (!isEmpty(result)) {
          this.set('model.registration.selectedCheckContents', result[0].searchType);
        }
        this.set('model.loader.contents', false);
      });
    },
    // get contenst list
    _getContentsList(isSearch) {
      const params = {
        typeCode: this.get('model.grid.selectedSearchType'),
        content: this.get('model.grid.searchText')
      };

      this.set('model.loader.gridList', true);
      this.get('service').getContentsList(params).then((result) => {
        if (isEmpty(result)) {
          this.set('model.grid.contentsList', []);
          this.set('model.loader.gridList', false);
          if (isSearch) {
            messageBox.show(this, {caption: this.getLanguageResource('8948', 'F', '', '해당정보가 없습니다'),messageBoxButton: 'Ok',messageBoxImage: 'warning',messageBoxText: '',messageBoxFocus: 'Ok',messageboxInterval: 2000});
          }
          return;
        }
        result.forEach((item) => {
          if (item.searchPeriod === 6) {
            item.searchPeriod = '6개월';
          } else if (item.searchPeriod === 0) {
            item.searchPeriod = '전체';
          }
        });
        this.set('model.grid.contentsList', result);
        this.set('model.loader.gridList', false);
      });
    },
    // get contenst
    _getContents() {
      const params = {
        contentsId: isEmpty(this.get('model.grid.selectedContents')) ? null : this.get('model.grid.selectedContents').contentsId
      };
      this.set('model.loader.contents', true);
      this.get('service').getContents(params).then((result) => {
        if (isEmpty(result)) {
          this._initProperties();
          return;
        }
        this.set('model.registration.contentsName', result.displayName);
        this.set('model.registration.selectedContentsType', result.typeCode);
        this.set('model.registration.selectedComponent', result.componentViewId);
        this.set('model.registration.selectedFromDate', result.validStartDateTime);
        this.set('model.registration.selectedToDate', result.validEndDateTime);
        this.set('model.registration.seletectIsDetail', result.isExaminationDetail);
        this.set('model.registration.selectedSearchDateType', String(result.searchPeriod));
        this.set('model.registration.selectedCheckContents', result.searchType);
        this.set('model.registration.content', result.content);
        if (!isEmpty(result.popUp)) {
          this.set('model.registration.selectedPopupComponent', result.popUp.componentViewId);
          this.set('model.registration.popupHeight', result.popUp.applyHeight);
          this.set('model.registration.popupWidth', result.popUp.applyWidth);
          this.set('model.registration.arguments', result.popUp.argument);
        } else {
          this.set('model.registration.selectedPopupComponent', null);
          this.set('model.registration.popupHeight', null);
          this.set('model.registration.popupWidth', null);
        }
        this.set('model.registration.limitCount', result.searchCount);
        this.set('model.loader.contents', false);
      });
    },
    // save contenst
    _saveContents() {
      const params = {
        contentsId: isEmpty(this.get('model.grid.selectedContents')) ? null : this.get('model.grid.selectedContents').contentsId,
        displayName: this.get('model.registration.contentsName'),
        typeCode: this.get('model.registration.selectedContentsType'),
        componentViewId: this.get('model.registration.selectedComponent'),
        validStartDateTime: this.get('model.registration.selectedFromDate'),
        validEndDateTime: this.get('model.registration.selectedToDate'),
        isExaminationDetail: this.get('model.registration.seletectIsDetail'),
        searchPeriod: this.get('model.registration.selectedSearchDateType'),
        searchType: this.get('model.registration.selectedCheckContents'),
        searchCount: this.get('model.registration.limitCount'),
        content: this.get('model.registration.content'),
        popup: {
          componentViewId: this.get('model.registration.selectedPopupComponent'),
          applyHeight: this.get('model.registration.popupHeight'),
          applyWidth: this.get('model.registration.popupWidth'),
          argument: this.get('model.registration.arguments')
        }
      };
      this.get('service').saveContents(params).then(() => {
        this.get('toast').toastr({
          type: 'save',
          content: 'Saved.',
          title: '',
          option: {
            closeButton: false,
            timeOut: 3000,
            positionClass: 'toast-bottom-center'
          }
        });
        this.set('model.grid.selectedContents', null);
        this._initProperties('registration');
        this._getContentsList();
      });
    },
    // delete contents
    _deleteContents() {
      const params = {
        contentsId: isEmpty(this.get('model.grid.selectedContents')) ? null : this.get('model.grid.selectedContents').contentsId
      };

      if (isEmpty(params.contentsId)) {
        return;
      }
      this.get('service').deleteContents(params).then(() => {
        this.get('toast').toastr({
          type: 'delete',
          content: 'Deleted.',
          title: '',
          option: {
            closeButton: false,
            timeOut: 3000,
            positionClass: 'toast-bottom-center'
          }
        });
        this._getContentsList();
        this.set('model.grid.selectedContents', null);
      });
    },
    // set columns
    _setColumns() {
      this.set('model.grid.columns', [
        { field: 'contentsId', hidden: true },
        { title: this.getLanguageResource('9671', 'F', null, '분류'), field: 'typeName', align: 'center', width: 80 },
        { title: this.getLanguageResource('12406', 'F', null, '컨텐츠명'), field: 'displayName', width: 120 },
        { title: this.getLanguageResource('12411', 'F', null, '상세유무'), field: 'isExaminationDetail', type: 'boolean', align: 'center', width: 65 },
        { title: this.getLanguageResource('12315', 'F', null, '검색기간'), field: 'searchPeriod', align: 'center', width: 72 },
        { title: this.getLanguageResource('6956', 'F', null, '조회유형'), field: 'searchTypeName', width: 65 },
        { title: this.getLanguageResource('12407', 'F', null, '구성요소'), field: 'componentViewId', width: 100 },
        { title: this.getLanguageResource('12418', 'F', null, '내용'), field: 'content', width: 60 }
      ]);
    }
  });