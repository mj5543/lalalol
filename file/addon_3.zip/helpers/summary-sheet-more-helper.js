import { helper } from '@ember/component/helper';

export function summarySheetMoreHelper(params) {
  const limitCount = params[0];
  const totalCount = params[1];

  if (isNaN(limitCount) || isNaN(totalCount)) {
    return true;
  }
  if (totalCount <= limitCount) {
    return true;
  }
  return false;
}

export default helper(summarySheetMoreHelper);
