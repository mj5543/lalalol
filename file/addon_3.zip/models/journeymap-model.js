import CHIS from 'framework/chis-framework';
export default CHIS.FR.Core.ModelBase.extend({
  timelineData: null,
  actionMode: null,
  newSeries: null,
  removeSeriesNo: null,
  loader: null,
  init() {
    // time line data
    this.set('timelineData', null);
    this.set('actionMode', null);
    this.set('newSeries', null);
    this.set('removeSeriesNo', null);
    this.set('loader', false);
  }
});
