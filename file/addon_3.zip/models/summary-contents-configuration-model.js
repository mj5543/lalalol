import EmberObject from '@ember/object';
import CHIS from 'framework/chis-framework';
export default CHIS.FR.Core.ModelBase.extend({
  grid: null,
  registration: null,
  loader: null,
  init() {
    /* 그리드 영역 */
    this.set('grid', EmberObject.create());
    this.set('loader', EmberObject.create());
    // 분류
    this.set('grid.searchTypeList', []);
    this.set('grid.selectedSearchType', null);
    // 검색내용
    this.set('grid.searchText', null);
    // 그리드
    this.set('grid.contentsList', []);
    this.set('grid.columns', []);
    this.set('grid.selectedContents', null);
    /* 등록 영역 */
    this.set('registration', EmberObject.create());
    // 컨텐츠명
    this.set('registration.contentsName', null);
    // 분류
    this.set('registration.contentsTypeList', []);
    this.set('registration.selectedContentsType', null);
    // 컴포넌트
    this.set('registration.componentList', []);
    this.set('registration.selectedComponent', null);
    this.set('registration.selectedPopupComponent', null);
    this.set('registration.popupHeight', null);
    this.set('registration.popupWidth', null);
    // is more
    this.set('registration.isMoreList', []);
    this.set('registration.selectedIsMore', null);
    // 유효기간
    this.set('registration.selectedFromDate', null);
    this.set('registration.selectedToDate', null);
    // 상세유무
    this.set('registration.isDetailList', []);
    this.set('registration.seletectIsDetail', null);
    // 검색기간유형
    this.set('registration.searchDateTypeList', []);
    this.set('registration.selectedSearchDateType', null);
    // 내용식별유형
    this.set('registration.checkContentsList', []);
    this.set('registration.selectedCheckContents', null);
    // 내용
    this.set('registration.content', null);
    this.set('registration.limitCount', null);
  }
});
