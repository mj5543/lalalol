import EmberObject from '@ember/object';
import CHIS from 'framework/chis-framework';
export default CHIS.FR.Core.ModelBase.extend({
  loader: null,
  grid: null,
  info: null,
  init() {
    // 로더
    this.set('loader', EmberObject.create());
    // 그리드
    this.set('grid', EmberObject.create());
    this.set('grid.userTypeList', []);
    this.set('grid.selectedUserType', null);
    this.set('grid.searchTtext', null);
    this.set('grid.list', []);
    this.set('grid.columns', []);
    this.set('grid.selectedItem', null);
    this.set('grid.departmentList', null);
    this.set('grid.wardList', null);
    this.set('grid.selectedDepartment', null);
    this.set('grid.employeeList', null);
    this.set('grid.selectedEmployee', null);
    // 기본정보, 컨텐츠정보, 상세정보
    this.set('basicInfo', EmberObject.create());
    this.set('basicInfo.sheetName', null);
    this.set('basicInfo.isDefault', null);
    this.set('basicInfo.shareList', []);
    this.set('basicInfo.selectedShare', null);
    this.set('basicInfo.departmentList', null);
    this.set('basicInfo.selectedDepartment', null);
    this.set('basicInfo.wardList', null);
    this.set('basicInfo.selectedWard', null);
    this.set('basicInfo.employeeList', null);
    this.set('basicInfo.selectedEmployee', null);
    this.set('basicInfo.content', null);
    this.set('basicInfo.selectedWard', null);
    // 컨텐츠정보
    this.set('contentsInfo', EmberObject.create());
    this.set('contentsInfo.list', []);
    this.set('contentsInfo.columns', []);
    this.set('contentsInfo.selectedItem', null);
    this.set('contentsInfo.popupInfo', EmberObject.create());
    // 컨텐츠상세정보
    this.set('contentsDetailInfo', EmberObject.create());
    this.set('contentsDetailInfo.gridControl', null);
    this.set('contentsDetailInfo.list', []);
    this.set('contentsDetailInfo.columns', []);
    this.set('contentsDetailInfo.popupInfo', EmberObject.create());
  }
});
