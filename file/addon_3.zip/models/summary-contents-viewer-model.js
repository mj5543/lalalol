import EmberObject from '@ember/object';
import CHIS from 'framework/chis-framework';
export default CHIS.FR.Core.ModelBase.extend({
  sheetList: null,
  loader: null,
  parameters: null,
  init() {
    this.set('sheetList', []);
    this.set('loader', EmberObject.create());
    this.set('parameters', EmberObject.create());
  }
});
