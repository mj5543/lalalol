import EmberObject from '@ember/object';
import CHIS from 'framework/chis-framework';
export default CHIS.FR.Core.ModelBase.extend({
  // selected tab name
  selectedTabName: null,
  common: null,
  custom: null,
  checkedDefault: null,
  option: null,
  commonData: null,
  init() {
    this.set('selectedTabName', null);
    this.set('common', EmberObject.create());
    this.set('custom', EmberObject.create());
    this.set('checkedDefault', EmberObject.create());
    this.set('option', EmberObject.create());
    this.set('commonData', EmberObject.create());
    this._setNextOneStepModel();
  },
  // set next one step model
  _setNextOneStepModel() {
    this.set('common.spot', EmberObject.create());
    this.set('common.guidebook', EmberObject.create());
    this.set('custom.spot', EmberObject.create());
    this.set('custom.guidebook', EmberObject.create());
    this._setNextTwoStepModel();
  },
  // set next two step model
  _setNextTwoStepModel() {
    this.set('common.spot.list', []);
    this.set('common.guidebook.list', []);
    this.set('custom.spot.list', []);
    this.set('custom.guidebook.list', []);
  }
});
