import CHIS from 'framework/chis-framework';
export default CHIS.FR.Core.ServiceBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, {
  defaultUrl: null,
  init () {
    this._super(...arguments);
    this._setProperties();
  },
  // set properties
  _setProperties() {
    this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'intelligencesummary') + 'intelligence-summary/v0/');
  },
  // copy to clipboard
  copyToClipboard(content) {
    let textArea = document.createElement("textarea");
    textArea.value = content;
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    try {
      document.execCommand('copy');
    } catch (err) {
      console.log(err);
    }
    document.body.removeChild(textArea);
    textArea = null;
  }
});