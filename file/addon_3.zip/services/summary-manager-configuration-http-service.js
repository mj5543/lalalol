import { isEmpty } from '@ember/utils';
import CHIS from 'framework/chis-framework';
export default CHIS.FR.Core.ServiceBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, {
  defaultUrl: null,
  init () {
    this._super(...arguments);
    this._setProperties();
  },
  // set properties
  _setProperties() {
    this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'intelligencesummary') + 'intelligence-summary/v0/');
  },
  // get grid list
  getGridList(params) {
    const httpPath = this.get('defaultUrl') + 'summary-sheets/manager-lists';

    return this.getList(httpPath, params, null, false).then(function (result) {
      if (isEmpty(result)) {
        return null;
      }
      const updatedModel = [];

      for (const item of result) {
        let struct = {};

        struct = {
          summarySheetId: item.summarySheetId,
          displayCode: item.displayCode,
          displayName: item.displayName,
          typeCode: item.typeCode,
          typeName: item.typeName,
          isBasic: item.isBasic,
          shareTargetCode: item.shareTargetCode,
          shareTargetName: item.shareTargetName,
          content: item.content
        };
        updatedModel.push(struct);
      }
      return updatedModel;
    });
  },
  // get grid list
  getInfoData(params) {
    const httpPath = this.get('defaultUrl') + 'summary-sheets/managers';

    return this.getList(httpPath, params, null, false).then(function (result) {
      if (isEmpty(result)) {
        return null;
      }
      return {
        summarySheetId: result.summarySheetId,
        displayCode: result.displayCode,
        displayName: result.displayName,
        typeCode: result.typeCode,
        typeName: result.typeName,
        isBasic: result.isBasic,
        shareTargetId: result.shareTargetId,
        shareTargetCode: result.shareTargetCode,
        shareTargetName: result.shareTargetName,
        sheetMaps: result.sheetMaps,
        content: result.content
      };
    });
  },
  // get share target list
  getShareTargetList() {
    const urlPath = this.get('defaultUrl') + 'summary-sheets/share/target-lists';

    return this.getList(urlPath, null, null, false).then((result) => {
      const updatedModel = [];

      if (isEmpty(result)) {
        return updatedModel;
      }
      for (const item of result) {
        const struct = {
          'shareTargetCode': item.shareTargetCode,
          'shareTargetName': item.shareTargetName,
          'shareTargetDisplayCode': this.getShareCodeBySeq(item.shareTargetCode)
        };
        updatedModel.push(struct);
      }
      return updatedModel;
    });
  },
  // get share information list
  getShareInformationList(params) {
    if (params.groupCode === 'Department' || params.groupCode === 'Ward') {
      const tempType = params.groupCode === 'Department' ? 'AMD' : 'WARD';
      const urlPath = this.get('defaultUrl') + `summary-sheets/departments/${tempType}`;

      return this.getList(urlPath, null, null, false).then((result) => {
        const updatedModel = [];

        if (isEmpty(result)) {
          return updatedModel;
        }
        for (const item of result) {
          const struct = {
            'departmentId': item.departmentId,
            'departmentName': item.departmentName
          };
          updatedModel.push(struct);
        }
        return updatedModel;
      });
    } else if (params.groupCode === 'Personal') {
      const urlPath = this.get('defaultUrl') + 'summary-sheets/employees';

      return this.getList(urlPath, null, null, false).then((result) => {
        const updatedModel = [];

        if (isEmpty(result)) {
          return updatedModel;
        }
        for (const item of result) {
          const struct = {
            'displayId': item.displayId,
            'fullName': item.fullName + '(' + item.displayId + ')',
            'employeeId': item.employeeId
          };
          updatedModel.push(struct);
        }
        return updatedModel;
      });
    }
  },
  // delete manager
  deleteManager(params) {
    return this.delete(this.get('defaultUrl') + 'summary-sheets/manager', null, params, false).then();
  },
  // save data
  saveManager(params) {
    if (isEmpty(params.summarySheetId)) {
      return this.create(this.get('defaultUrl') + 'summary-sheets/manager', null, params, false).then();
    } else {
      return this.update(this.get('defaultUrl') + 'summary-sheets/manager', null, false, params, false).then();
    }
  },
  getShareCodeBySeq(index) {
    if (index === 0) {
      return 'All';
    } else if (index === 1) {
      return 'Personal';
    } else if (index === 2) {
      return 'Department';
    } else if (index === 3) {
      return 'Ward';
    }
  },
  getShareSeqByCode(code) {
    if (code === 'All') {
      return 0;
    } else if (code === 'Personal') {
      return 1;
    } else if (code === 'Department') {
      return 2;
    } else if (code === 'Ward') {
      return 3;
    }
  }
});