import { isEmpty } from '@ember/utils';
import CHIS from 'framework/chis-framework';
export default CHIS.FR.Core.ServiceBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, {
  defaultUrl: null,
  init () {
    this._super(...arguments);
    this._setProperties();
  },
  // get sheet list
  getSheetList(params) {
    const httpPath = this.get('defaultUrl') + `summary-sheets/${params.employeeId}/sheet-lists`;

    return this.getList(httpPath, params, null, false).then(function (result) {
      if (isEmpty(result)) {
        return null;
      }
      const updatedModel = [];

      for (const item of result) {
        let struct = {};
        struct = {
          summarySheetId: item.summarySheetId,
          displayCode: item.displayCode,
          displayName: item.displayName,
          isBasic: item.isBasic,
          sheetMaps: item.sheetMaps
        };
        updatedModel.push(struct);
      }
      return updatedModel;
    });
  },
  // set properties
  _setProperties() {
    this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'intelligencesummary') + 'intelligence-summary/v0/');
  }
});