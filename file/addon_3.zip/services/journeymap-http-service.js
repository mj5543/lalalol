import CHIS from 'framework/chis-framework';
export default CHIS.FR.Core.ServiceBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, {
  defaultUrl: null,
  init () {
    this._super(...arguments);
    this._setProperties();
  },
  // get journey map data
  getJourneyMapData(params, callback) {
    const httpPath = this.get('defaultUrl') + 'journeymap';

    this.getList(httpPath, params, null, false).then(function (result) {
      callback(result);
    });
  },
  // get journey map multi data
  getJourneyMapMultiData(params, callback) {
    const httpPath = this.get('defaultUrl') + 'journeymap/trace/summary-lists';

    this.getList(httpPath, params, null, false).then(function (result) {
      callback(result);
    });
  },
  _setProperties() {
    this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'intelligencesummary') + 'intelligence-summary/v0/');
  }
});