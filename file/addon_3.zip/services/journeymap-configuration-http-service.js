import { isEmpty } from '@ember/utils';
import CHIS from 'framework/chis-framework';

export default CHIS.FR.Core.ServiceBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, {
  /* http services */
  defaultUrl: null,
  init () {
    this._super(...arguments);
    this._setProperties();
  },
  // get spot list
  getSpotList(params) {
    const httpPath = this.get('defaultUrl') + 'journeymap/spot';
    const current = this;
    const resultList = [];

    return this.getList(httpPath, params, null, false).then(function (result) {
      if (isEmpty(result)) {
        return null;
      }
      for (const item of result) {
        if (!item.isRoot) {
          continue;
        }
        let childList = [];

        if (!item.isLeaf) {
          childList = current.getSpotChild(result, item.spotId);
        }
        resultList.push({
          spotId: item.spotId,
          name: item.name,
          spotType: item.spotType,
          parentId: item.parentId,
          ancestorId: item.ancestorId,
          node: item.node,
          displaySequence: item.displaySequence,
          isRoot: item.isRoot,
          isLeaf: item.isLeaf,
          isValidDataRow: item.isValidDataRow,
          icon: item.icon,
          childList: childList,
          isExistChild: childList.length == 0 ? true : false
        });
      }
      return resultList;
    });
  },
  // get spot child
  getSpotChild(list, id) {
    const resultList = [];

    for (const item of list) {
      if (id != item.parentId) {
        continue;
      }
      let childList = [];

      if (!item.isLeaf) {
        childList = this.getSpotChild(list, item.spotId);
      }
      resultList.push({
        spotId: item.spotId,
        name: item.name,
        spotType: item.spotType,
        parentId: item.parentId,
        ancestorId: item.ancestorId,
        node: item.node,
        displaySequence: item.displaySequence,
        isRoot: item.isRoot,
        isLeaf: item.isLeaf,
        isValidDataRow: item.isValidDataRow,
        icon: item.icon,
        childList: childList,
        isExistChild: childList.length == 0 ? true : false
      });
    }
    return resultList;
  },
  // get guide book list
  getGuidebookList(params) {
    const httpPath = this.get('defaultUrl') + 'journeymap/guidebook';

    return this.getList(httpPath, params, null, false).then(function (result) {
      if (isEmpty(result)) {
        return null;
      }
      const updatedModel = [];

      for (const item of result) {
        let struct = {};

        struct = {
          chapterList: item.chapterList,
          code: item.code,
          displaySequence: item.displaySequence,
          guideBookId: item.guideBookId,
          guideBookType: item.guideBookType,
          isValidDataRow: item.isValidDataRow,
          name: item.name,
          privateUserId: item.privateUserId,
          className: '',
          isBasic: item.isBasic
        };
        updatedModel.push(struct);
      }
      return updatedModel;
    });
  },
  setGuidebookList(params) {
    const httpPath = this.get('defaultUrl') + 'journeymap/guide-books';

    return this.create(httpPath, null, params, false).then(function (result) {
      return result;
    });
  },
  _setProperties() {
    this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'intelligencesummary') + 'intelligence-summary/v0/');
  }
});