import { isEmpty } from '@ember/utils';
import CHIS from 'framework/chis-framework';
export default CHIS.FR.Core.ServiceBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, {
  defaultUrl: null,
  init () {
    this._super(...arguments);
    this._setProperties();
  },
  // set properties
  _setProperties() {
    this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'intelligencesummary') + 'intelligence-summary/v0/');
  },
  // get contents list
  getContentsList(params) {
    const httpPath = this.get('defaultUrl') + 'summary-sheets/contents-lists';

    return this.getList(httpPath, params, null, false).then(function (result) {
      if (isEmpty(result)) {
        return null;
      }
      const updatedModel = [];

      for (const item of result) {
        let struct = {};

        struct = {
          contentsId: item.contentsId,
          displayName: item.displayName,
          typeCode: item.typeCode,
          typeName: item.typeName,
          componentViewId: item.componentViewId,
          isExaminationDetail: item.isExaminationDetail,
          searchPeriod: item.searchPeriod,
          searchTypeName: item.searchTypeName,
          content: item.content
        };
        updatedModel.push(struct);
      }
      return updatedModel;
    });
  },
  // get contents list
  getContents(params) {
    const httpPath = this.get('defaultUrl') + 'summary-sheets/contents';

    return this.getList(httpPath, params, null, false).then(function (result) {
      if (isEmpty(result)) {
        return null;
      }
      return {
        contentsId: result.contentsId,
        displayName: result.displayName,
        typeCode: result.typeCode,
        componentViewId: result.componentViewId,
        validStartDateTime: result.validStartDateTime,
        validEndDateTime: result.validEndDateTime,
        isExaminationDetail: result.isExaminationDetail,
        searchPeriod: result.searchPeriod,
        searchCount: result.searchCount,
        searchType: result.searchType,
        content: result.content,
        popUp: result.popUp
      };
    });
  },
  // save contents
  saveContents(params) {
    const httpPath = this.get('defaultUrl') + 'summary-sheets/contents';

    if (isEmpty(params.contentsId)) {
      return this.create(httpPath, null, params, false).then(function (result) {
        return result;
      });
    } else {
      return this.update(httpPath, null, false, params, false).then(function (result) {
        return result;
      });
    }
  },
  // save contents
  deleteContents(params) {
    const httpPath = this.get('defaultUrl') + 'summary-sheets/contents';

    return this.delete(httpPath, null, params, false).then(function (result) {
      return result;
    });
  },
  // get contents type list
  getComboDataList(typeCode) {
    const httpPath = this.get('defaultUrl') + `summary-sheets/summary-common-types/${typeCode}/summary-common-items`;

    return this.getList(httpPath, {typeCode: typeCode}, null, false).then(function (result) {
      if (isEmpty(result)) {
        return null;
      }
      const updatedModel = [];

      for (const item of result) {
        let struct = {};

        struct = {
          summaryCommonItemId: item.summaryCommonItemId,
          summaryCommonItemCode: item.summaryCommonItemCode,
          summaryCommonItemName: item.summaryCommonItemName,
          applyValue: item.applyValue
        };
        updatedModel.push(struct);
      }
      return updatedModel;
    });
  },
  // get contents type list
  getSearchTypeList() {
    const httpPath = this.get('defaultUrl') + 'summary-sheets/contents/search-type';

    return this.getList(httpPath, null, null, false).then(function (result) {
      if (isEmpty(result)) {
        return null;
      }
      const updatedModel = [];

      for (const item of result) {
        let struct = {};

        struct = {
          searchType: item.searchType,
          searchTypeName: item.searchTypeName
        };
        updatedModel.push(struct);
      }
      return updatedModel;
    });
  }
});