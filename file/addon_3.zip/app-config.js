//configuration for biz
export default {
  config1 : "config value1"
};