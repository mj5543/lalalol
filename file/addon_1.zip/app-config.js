//configuration for biz
export default {
  version : "v0",
  service: 'specimenexaminationreport'
};