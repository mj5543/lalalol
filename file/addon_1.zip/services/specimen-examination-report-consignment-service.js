import CHIS from 'framework/chis-framework';
import config from '../app-config';

export default CHIS.FR.Core.ServiceBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, {

  urlPrefix: '',

  init() {
    this._super(...arguments);
    const serverCallConfig = this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', config.service);

    const defaultUrl = serverCallConfig + `specimen-examination-report/${config.version}`;
    const pathologyExamination = `${serverCallConfig}pathology-examination-report/${config.version}`;
    this.set('pathologyExamination', pathologyExamination);
    this.set('urlPrefix', defaultUrl);
  },
  getSpecimenCheckInConsignment(param) {
    const callUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', config.service);
    return this.getList(callUrl + 'specimen-checkin/v0/specimen-examination-worklists/consigned-agency', null, param, false);
  },

  getObservationsResult(params) {
    return this.getList(`${this.get('urlPrefix')}/observations/results`, params, null);

  },
  getResultWorkListSearch(params) {
    return this.getList(`${this.get('urlPrefix')}/result-worklists/search`, null, params, false);

  },
  createObservationsResultsConsignments(params) {
    return this.create(`${this.get('urlPrefix')}/observations/results/consignments`, null, params, false);
  },

  getSearchConsignedAgency(params) {
    return this.getList(`${this.get('urlPrefix')}/specimen-examinations/search-consigned-agency`, params, null);

  },

  getConsignedAgency() {
    const param = {classificationCode: 'ConsignedAgency'};
    return this.getList(`${this.get('urlPrefix')}/business-codes/search`, param, null);
  },
  createPathologyConsignments(params) {
    return this.create(`${this.get('pathologyExamination')}/consignment-upload`, null, params, false);
  },
  createObservationsConsignments(params) {
    return this.create(`${this.get('urlPrefix')}/observations/results/consignments`, null, params, false);
  },

});