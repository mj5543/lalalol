import CHIS from 'framework/chis-framework';
import config from '../app-config';

export default CHIS.FR.Core.ServiceBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, {

  urlPrefix: '',

  init() {
    this._super(...arguments);

    const defaultUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', config.service) +
      `specimen-examination-report/${config.version}`;

    this.set('urlPrefix', defaultUrl);
  },

  getSpecimenCheckInOverview(param) {
    const callUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', config.service);
    return this.getList(callUrl + 'specimen-checkin/v0/specimen-examination-worklists/specimens/overview', param, null);
  },

  getSpecimenCheckInConfigurations(param) {
    const callUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', config.service);
    return this.getList(callUrl + 'specimen-checkin/v0/worklist-configurations/search', param, null);
  },

  getSpeciallistPhysicans(params) {
    return this.getList(`${this.get('urlPrefix')}/result-worklists/observations/specialist-physicians`, null, params, false);
  },

  createSpeciallistPhysicans(params) {
    return this.create(`${this.get('urlPrefix')}/observations/results/specialist-physicians`, null, params, false);
  },

  deleteSpeciallistPhysicans(params) {
    return this.delete(`${this.get('urlPrefix')}/observations/results/specialist-physicians`, null, params, false);
  },

  getSpecimenExaminations(params) {
    return this.getList(`${this.get('urlPrefix')}/specimen-examinations`, params, null);
  },

  getExaminationUnits(id) {
    return this.getList(`${this.get('urlPrefix')}/examination-units/${id}`, null, null, false);
  },

  getResultWorkListsSearch(params) {
    return this.getList(`${this.get('urlPrefix')}/result-worklists/search`, null, params, false);
  },

  getObservationsResultsCultures(params) {
    return this.getList(`${this.get('urlPrefix')}/observations/results/cultures`, params, null);
  },

  getObservationsFileNotes(params) {
    return this.getList(`${this.get('urlPrefix')}/observations/results/file-notes`, params, null);
  },

  createObservationsResultsCultures(params) {
    return this.create(`${this.get('urlPrefix')}/observations/results/cultures`, null, params, false);
  },

  getDianosticReportSearchStain(params) {
    return this.getList(`${this.get('urlPrefix')}/diagnostic-report/search-stain`, params, null);
  },

  getBacterialIdentifications(params) {
    return this.getList(`${this.get('urlPrefix')}/bacterial-identifications`, params, null);
  },

  getSusceptibilitys(params) {
    return this.getList(`${this.get('urlPrefix')}/susceptibilitys/search`, null, params, false);
  },

  getCulturesBacterialIdentifications(params) {
    return this.getList(`${this.get('urlPrefix')}/observations/results/cultures/bacterial-identifications`, params, null);
  },

  createCulturesBacterialIdentifications(params) {
    return this.create(`${this.get('urlPrefix')}/observations/results/cultures/bacterial-identifications`, null, params, false);
  },

  deleteCulturesBacterialIdentifications(params) {
    return this.delete(`${this.get('urlPrefix')}/observations/results/cultures/bacterial-identifications`, null, params, false);
  },

  getCulturesBacterialIdentificationsSpecimenExaminations(params) {
    return this.getList(`${this.get('urlPrefix')}/observations/results/cultures/bacterial-identifications/specimen-examinations`, params, null);
  },

  getCulturesBacterialIdentificationsSusceptibilitys(params) {
    return this.getList(`${this.get('urlPrefix')}/observations/results/cultures/bacterial-identifications/susceptibilitys`, params, null);
  },

  createCulturesBacterialIdentificationsSusceptibilitys(params) {
    return this.create(`${this.get('urlPrefix')}/observations/results/cultures/bacterial-identifications/susceptibilitys`, null, params, false);
  },

  deleteCulturesBacterialIdentificationsSusceptibilitys(params) {
    return this.delete(`${this.get('urlPrefix')}/observations/results/cultures/bacterial-identifications/susceptibilitys`, null, params, false);
  },

  getObservationsResultRemarks(worksResultsSelectedItem, type){
    const params = {
      remarkTypeCode: type,
      subjectId: worksResultsSelectedItem.subjectId,
      specimenId: worksResultsSelectedItem.specimenId,
      specimenNumber: null,
      subjectTypeCode : 'Patient'
    };

    return this.getList(`${this.get('urlPrefix')}/observations/results/remarks`, params, null);
  },

  getObservationsExamples(params) {
    return this.getList(`${this.get('urlPrefix')}/observations/examples`, params, null);
  },

  getDiagnosticReportSearchCulture(params) {
    return this.getList(`${this.get('urlPrefix')}/diagnostic-report/search-culture`, params, null);
  },

  getSusceptibilitysCalculate(params) {
    return this.getList(`${this.get('urlPrefix')}/observations/results/cultures/bacterial-identifications/susceptibilitys/calculate`, null, params, null);

  },

  getBusinessCodesSearch(param) {
    return this.getList(`${this.get('urlPrefix')}/business-codes/search`, param, null);
  },

  getBusinessCodeList(params) {
    return this.getList(`${this.get('urlPrefix')}/business-codes/search`, null, params, false);
  },

  getObservationsResults(params){
    return this.getList(`${this.get('urlPrefix')}/observations/results`, params, null);
  },

  getDepartmentsSearch(param) {
    return this.getList(`${this.get('urlPrefix')}/departments/search`, param, null);

  },

});