import CHIS from 'framework/chis-framework';
import config from '../app-config';

export default CHIS.FR.Core.ServiceBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, {

  urlPrefix: '',
  serviceUrl: null,

  init() {
    this._super(...arguments);

    const defaultUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', config.service) +
      `specimen-examination-report/${config.version}`;

    this.set('urlPrefix', defaultUrl);
    this.set('serviceUrl', `${defaultUrl}/verification-interpretative-report`);
  },

  getVerificationReportWorkList(params) {
    return this.getList(`${this.get('serviceUrl')}/verification-worklist`, params, null);
  },
  getVerificationCount(params) {
    return this.getList(`${this.get('serviceUrl')}/verification-count`, params, null);
  },
  getVerificationReportCalendarList(params) {
    return this.getList(`${this.get('serviceUrl')}/interpreted-calendar-list`, params, null);
  },
  getVerificationReportPatientList(params) {
    return this.getList(`${this.get('serviceUrl')}/interpreted-patient-list`, params, null);
  },
  getVerificationInterpretedReport(params) {
    return this.getList(`${this.get('serviceUrl')}/interpreted-report`, params, null);
  },
  getVerificationReport(params) {
    return this.getList(`${this.get('serviceUrl')}/search`, null, params, false);
  },
  createInterpretedReport(params) {
    return this.create(`${this.get('serviceUrl')}/report`, null, params, false);
  },
  updateInterpretedReport(param) {
    return this.update(`${this.get('serviceUrl')}/modify-report`, null, false, param, false);
  },
  deleteCancellation(param) {
    return this.delete(`${this.get('serviceUrl')}/cancellation`, null, param, false);
  },
  // getResultWorkListSearch(params) {
  //   return this.getList(`${this.get('urlPrefix')}/result-worklists/search`, null, params, false);

  // },
  // createObservationsResultsConsignments(params) {
  //   return this.create(`${this.get('urlPrefix')}/observations/results/consignments`, null, params, false);
  // },


  getBusinessCodes(code) {
    const param = {classificationCode: code};
    return this.getList(`${this.get('urlPrefix')}/business-codes/search`, param, null);
  },
  getBusinessCodeList(params) {
    return this.getList(`${this.get('urlPrefix')}/business-codes/search`, null, params, false);
  },

});