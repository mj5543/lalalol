import CHIS from 'framework/chis-framework';
import config from '../app-config';

export default CHIS.FR.Core.ServiceBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, {

  urlPrefix: '',
  serviceUrl: null,

  init() {
    this._super(...arguments);

    const defaultUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', config.service) +
      `specimen-examination-report/${config.version}`;

    this.set('urlPrefix', defaultUrl);
    this.set('serviceUrl', `${defaultUrl}/blood-cell-morphology`);
  },

  getBloodCellMorphologyResult(params) {
    return this.getList(`${this.get('serviceUrl')}/result`, params, null);
  },
  createBloodCellMorphologyResult(params) {
    return this.create(`${this.get('serviceUrl')}/result`, null, params, false);
  },
  getBloodCellMorphologyWorklist(params) {
    return this.getList(`${this.get('serviceUrl')}/worklist`, params, null);
  },
  getBloodCellMorphologyWorklistValues(params) {
    return this.getList(`${this.get('serviceUrl')}/worklist-values`, params, null);
  },
  getModifyResult(param) {
    return this.update(`${this.get('serviceUrl')}/modify-result`, null, false, param, false);
  },
  getRemoveResult(param) {
    return this.delete(`${this.get('serviceUrl')}/remove-result`, null, param, false);
  },
  getBusinessCodes(code) {
    const param = {classificationCode: code};
    return this.getList(`${this.get('urlPrefix')}/business-codes/search`, param, null);
  },

});