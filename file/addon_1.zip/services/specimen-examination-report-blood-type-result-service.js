import CHIS from 'framework/chis-framework';
import config from '../app-config';

export default CHIS.FR.Core.ServiceBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, {

  urlPrefix: '',

  init() {
    this._super(...arguments);

    const defaultUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', config.service) +
      `specimen-examination-report/${config.version}`;

    this.set('urlPrefix', defaultUrl);
  },
  getSpecimenReportsSearch(param) {
    const callUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', config.service);
    return this.getList(callUrl + 'test-result-viewer/v0/specimen-examination-reports/search', null, param, false);
  },

  getSpecimenCheckInDisplayView(param) {
    const callUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', config.service);
    return this.getList(callUrl + 'specimen-checkin/v0/specimen-examination-worklists/results/display-view', param, null);
  },

  getSpecimenExaminations(param) {
    return this.getList(`${this.get('urlPrefix')}/specimen-examinations`, param, null);
  },

  getObservationsResults(params) {
    return this.getList(`${this.get('urlPrefix')}/observations/results`, params, null);
  },

  getObservationsResultsAboRh(params) {
    return this.getList(`${this.get('urlPrefix')}/observations/results/abo-rh`, params, null);
  },

  getObservationsExamplesSearch(params) {
    return this.getList(`${this.get('urlPrefix')}/observations/examples/search`, null, params, false);
  },

  createBloodTypes(param) {
    return this.create(`${this.get('urlPrefix')}/observations/results/blood-types`, null, param, false);
  },

  getBloodTypesSearch(params) {
    return this.getList(`${this.get('urlPrefix')}/observations/results/blood-types/search`, params, null);

  },

  getBloodTypesCompare(params) {
    return this.getList(`${this.get('urlPrefix')}/observations/results/blood-types/compare`, null, params, false);

  },
  getBusinessCodesSearch(param) {
    return this.getList(`${this.get('urlPrefix')}/business-codes/search`, param, null);
  },

});