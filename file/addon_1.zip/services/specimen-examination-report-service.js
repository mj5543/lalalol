/* eslint-disable max-lines */
/* eslint-disable no-console */
import { set } from '@ember/object';
import { A } from '@ember/array';
import { Promise } from 'rsvp';
import { copy } from '@ember/object/internals';
import { isEmpty } from '@ember/utils';
import { inject as service } from '@ember/service';
import CHIS from 'framework/chis-framework';
import MessageMixin from '../mixins/specimen-examination-report-message-mixin';
export default CHIS.FR.Core.ServiceBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MessageMixin,{
  domain: 'specimenexaminationreport',
  urlPrefix: '',
  currentUser: null,
  toast: service('toast-service'),
  returnComment: null,

  init() {
    this._super(...arguments);
    const serverCallConfig = this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', this.get('domain'));
    this.set('urlPrefix', `${serverCallConfig}specimen-examination-report/v0/`);
    this.set('currentUser', this.get('co_CurrentUserService.user'));
    // this.set('toast', service('toast-service'));
  },

  getDepartmentComments(resultListSelectedItem){
    const returnComment= {
      notification:false,
      isCommentsExpanded: false,
      displayDepartmentComment: null,
      displayDepartmentComments: null,
      deptComments: null,
      deptCommentsHistory: null,
      deptCommentsCount: 0,
    };
    if(isEmpty(resultListSelectedItem)){
      returnComment.isCommentsExpanded= false;
      return returnComment;
    }
    if(!isEmpty(resultListSelectedItem.orderComment) || !isEmpty(resultListSelectedItem.collectionComment)){
      returnComment.isCommentsExpanded= true;
      returnComment.notification= true;
    }
    if(!isEmpty(resultListSelectedItem.deptCommentsCount)){
      return returnComment;
    }
    const params={
      remarkTypeCode: 'remark',
      subjectId: resultListSelectedItem.subjectId,
      specimenId: null, specimenNumber: null,
      subjectTypeCode : 'Patient'
    };
    return this.getList(`${this.get('urlPrefix')}observations/results/remarks`, params, null).then(res=>{
      if(isEmpty(res)){
        return returnComment;
      }
      res.forEach(element => {
        if(!isEmpty(element.orderComment)|| !isEmpty(element.remark)){
          returnComment.notification= true;
          returnComment.isCommentsExpanded= true;
        }
        if(element.specimenNumber == resultListSelectedItem.specimenNumber){
          res.removeObject(element);
          returnComment.displayDepartmentComment=element;
          returnComment.deptComments=element.remark;
        }
      });
      returnComment.displayDepartmentComments=res;
      returnComment.deptCommentsCount=res.length;
      returnComment.deptCommentsHistory=res;
      return returnComment;

    });
  },

  setObservationResultParams(e, value,isCorrected,inputStatus,performer,currentDatetime,changeReasonRemark){
    let remark =e.remark;
    if(!isEmpty(changeReasonRemark)){
      //선택한 수정사유 콜백 후
      remark= isEmpty(remark)? changeReasonRemark : changeReasonRemark;
    }
    return {
      checkInId: e.checkInId,
      observationId: e.observationId,
      unitWorkId: e.unitWorkId,
      examinationId: e.examinationId,
      basedOnTypeCode: 'ProcedureRequest',
      subjectTypeCode: 'Patient',
      basedOnId: e.basedOnId,
      subjectId: e.subjectId,
      specimenId: e.specimenId,
      specimenNumber: e.specimenNumber,
      statusCode: isCorrected? 'corrected': inputStatus,
      effectiveDatetime: e.effectiveDatetime,
      effectivePeriod: e.effectivePeriod,
      performer: {
        typeCode: "Practitioner",
        id: performer.employeeId,
        displaySequence: 0,
        performDatetime: currentDatetime
      },
      valueTypeCode: e.valueTypeCode,
      value: {
        quantity: value.quantity,
        codeableConcept: value.codeableConcept,
        valueDecimal: e.value.valueDecimal? e.value.valueDecimal : null,
        // valueDecimal: 0,
        valueString: value.valueString,
        recordNoteId: value.recordNoteId,
        valueTextString: value.valueTextString
      },

      interpretation: e.interpretation,
      remark: remark,
      deviceCode: e.deviceCode,
      displaySequence: e.displaySequence,
      check: e.check,
      relatedTypeCode: null,
      targetObservationResultId: null,
      inputSubType: null,
      isReport: e.isReport
    };
  },

  getTLA(resultListSelectedItem){
    // const resultListSelectedItem= this.get('resultListSelectedItem');
    const params={
      remarkTypeCode: 'tlanumber',
      subjectId: resultListSelectedItem.subjectId,
      specimenId: resultListSelectedItem.specimenId,
      specimenNumber: null,
      subjectTypeCode : 'Patient'
    };

    return this.getList(`${this.get('urlPrefix')}observations/results/remarks`, params, null).then(function(res){
      return res;
    });

  },

  saveUnit(createParams){
    return this.create(`${this.get('urlPrefix')}examination-units/`, null, createParams);
  },

  updateUnit(updateParams){
    return this.update(`${this.get('urlPrefix')}examination-units/`, null, false, updateParams);
  },

  departmentCommentSave(workListParams, comments, isValidDataRow){
    if(isEmpty(comments.displayDepartmentComment) && !isEmpty(workListParams)){
      //등록
      const createParams={
        subjectId: workListParams.subjectId,
        specimenId: workListParams.specimenId,
        specimenNumber: workListParams.specimenNumber,
        remarkTypeCode: 'remark',
        remark: comments.deptComments,
        entryStaffId: this.get('currentUser.employeeId'),
        subjectTypeCode :  'Patient'
      };

      return this.create(`${this.get('urlPrefix')}observations/results/remarks`, null, createParams);
    }else {
      const updateParams={
        //isEmpty(workListParams):삭제
        observationRemarkId: isEmpty(workListParams)? comments.observationRemarkId : comments.displayDepartmentComment.observationRemarkId,
        remark: isEmpty(workListParams)? comments.remark : comments.deptComments,
        isValidDataRow: isValidDataRow
      };
      return this.update(`${this.get('urlPrefix')}observations/results/remarks`, null, false, updateParams);
    }
  },

  //항목별검사결과입력 조회
  getResultListbyItem(paramsTemp){
    const params= copy(paramsTemp);
    params.checkInFromDate=new Date(params.checkInFromDate.getFullYear(), params.checkInFromDate.getMonth(), params.checkInFromDate.getDate(), 0, 0, 0);
    params.checkInToDate=new Date(params.checkInToDate.getFullYear(), params.checkInToDate.getMonth(), params.checkInToDate.getDate(), 0, 0, 0);

    params.encounterTypeCode = params.encounterTypeCode == 'A'? '' : params.encounterTypeCode;
    return this.getList(`${this.get('urlPrefix')}result-worklists/observations/search`, null, params, true).then(function(res){
      if(res){
        const promise = new Promise((resolve)=>{
          if(res.response.length ){
            resolve(A(res.response));
          } else{
            resolve(A([]));
          }
        });

        return promise;
      }
    });

  },

  resultSave(inputType, isCorrected, inputStatus, observationResults,observationResultChange){
    const params={
      inputStatus: isCorrected? 'corrected': inputStatus,
      inputType: inputType,
      issuedStaffId: this.get('currentUser.employeeId'),
      observationResults: observationResults
    };
    if(isCorrected){
      if(isEmpty(observationResultChange)){
        return this._showMessage(this.getLanguageResource('10740', 'F', '수정사유를 입력하세요'), 'warning', 'Ok', 'Ok', '', 2000);

      }
      params.observationResultChange= {
        reasonCode: observationResultChange.code,
        reasonContent: observationResultChange.name
      };
    }
    // return this.update(`${this.get('urlPrefix')}observations/results`, null, false, params);
    return this.ajaxCall(`${this.get('urlPrefix')}observations/results`, null, 'PUT', params, false);
  },

  getNegativeCodeableConcept(classificationCode){
    return this.ajaxCall(`${this.get('urlPrefix')}business-codes/search`, {classificationCode: classificationCode}, 'GET', null, false);
  },

  //Grid 관련
  getKeyBoardEventType(e) {
    const keyCodeEsc = 27;
    // const keyCodeAlt = 18;

    // const eventTypes = [
    //   // 'edit',
    //   // 'enter',
    //   // 'esc',
    // ];

    let result = 'noEdit';

    if(e.keyCode === keyCodeEsc) {
      result = 'esc';
    }else if(e.keyCode === 13) {
      result = 'enter';
    }else if(this._isEditableKeyCode(e.keyCode)) {
      // result = eventTypes[0];
      result = 'edit';
    }else if(e.keyCode === 18) {
      result = 'alt';
    }

    return result;
  },

  _isEditableKeyCode(keyCode) {
    // space
    const keyCodeSpace = 32;
    // 숫자
    const keyCodeZero = 48;
    const keyCodeNine = 57;
    // 숫자 keypad
    const keyCodeZero2 = 96;
    const keyCodeNine2 = 105;
    // 대소문자 동일
    const keyCodeA = 65;
    const keyCodeZ = 90;
    //
    //keypad

    let result = false;

    if( keyCode === keyCodeSpace) {
      result = true;
    } else if(keyCode >= keyCodeZero && keyCode <= keyCodeNine) {
      result = true;
    } else if(keyCode >= keyCodeA && keyCode <= keyCodeZ) {
      result = true;
    } else if(keyCode >= keyCodeZero2 && keyCode <= keyCodeNine2) {
      result = true;
    }

    return result;
  },

  changeSequence(url, list, seq, dropItem){
    // const changeDisplaySequences=[];
    const dropItemSeq= dropItem.displaySequence;
    let index = null;
    let targetSize = null;
    if(seq < dropItemSeq){
      index = seq;
      targetSize = dropItemSeq+2;
      //아래로 드래그
    }else{
      //위로 드래그
      index = dropItemSeq-1;
      targetSize = seq+1;
    }
    const changeDisplaySequences = this._getChangedDisplaySequences(index, targetSize, list);
    // if(seq < dropItemSeq){
    //   //아래로 드래그
    //   for (let index= seq; index < dropItemSeq+2; index++) {
    //     if(!isEmpty(list[index])){
    //       changeDisplaySequences.addObject({
    //         id: list[index].id,
    //         displaySequence: index,
    //         name: list[index].name,
    //       });
    //     }
    //   }
    // }else if(seq >= dropItemSeq){
    //   //위로 드래그
    //   for (let index= dropItemSeq-1; index < seq+1; index++) {
    //     if(!isEmpty(list[index])){
    //       changeDisplaySequences.addObject({
    //         id: list[index].id,
    //         displaySequence: index,
    //         name: list[index].name,
    //       });
    //     }
    //   }
    // }
    if(isEmpty(changeDisplaySequences)){
      return;
    }
    return this.update(`${this.get('urlPrefix')}`+url, null, false, {changeDisplaySequences}, false);
  },

  //sonarcube major code smell로 해당 코드 추가
  _getChangedDisplaySequences(ind, targetSize, list) {
    const returnList = [];
    for (let index = ind; index < targetSize; index++) {
      if(!isEmpty(list[index])){
        returnList.addObject({
          id: list[index].id,
          displaySequence: index,
          name: list[index].name,
        });
      }
    }
    return returnList;
  },
  _calculate(inputModeType, isFunctionKey, workListParams, resultListItemsSource){
    // const workListParams= this.get('workListParams');
    const observationResults= [];
    const observationResultsForSave =[];
    let value={};
    if(isEmpty(resultListItemsSource)){
      return;
    }
    const now= this.get('co_CommonService').getNow();
    resultListItemsSource.forEach(e=>{
      value= isEmpty(e.get('value'))? {} : e.get('value');
      value= this._updatedValue(e, now);
      if(inputModeType != 'Rule'){
        observationResults.addObject(this._setCalculateObservationResults(e, value, true));
        observationResultsForSave.addObject(e);
      }else if((!e.isUpdated && inputModeType != 'Rule') || e.isValueChanged!=true){
        //calculate 대상 아닌 경우
        observationResults.addObject(this._setCalculateObservationResults(e, value, false));
        // return;
      }else{
        observationResults.addObject(this._setCalculateObservationResults(e, value, true));
        observationResultsForSave.addObject(e);
      }
    });

    const params={
      inputModeType: inputModeType,
      isPossibleInputItemId: true,
      subjectId: workListParams.subjectId,
      subjectTypeCode : 'Patient',
      specimenNumber: workListParams.specimenNumber,
      observationResults: observationResults
    };
    if(observationResultsForSave.length ==0){
      return;
    }

    return this.create(`${this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')}specimen-examination-report/v0/observations/results/calculate`, null, params).then(function(res){
    // return this.ajaxSyncCall(`${this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')}specimen-examination-report/v0/observations/results/calculate`,
    //   null,'POST',params,false).done(function(res){
      if(isEmpty(res)){
        // this.set('isResultGridShow', false);
        return;
      }
      resultListItemsSource.forEach(function(gridItem, gridItemIndex){
        let item=null;
        const changedItem=res.findBy('examinationId', gridItem.examinationId);
        if (!isEmpty(changedItem)){
          item= changedItem;
          if(inputModeType == "Slide"){
            //slide는 remark가 있는 경우만 업데이트
            this._inputCallBackSetting(inputModeType, gridItem,item);
          }else{
            set(gridItem, 'isUpdated', true);
          }

          if(item.valueTypeCode=='Quantity' && (gridItem.statusCode =='final' || gridItem.statusCode =='corrected')
            && (this._setValueString(item) == gridItem.valueValueString)){
            //검증상태이고 value가 같으면 isUpdated 업데이트 안함
            set(gridItem, 'isUpdated', false);
          }
        }else if(this.get('mode')=='results-by-item'){
          item=res[gridItemIndex];
        }else{
          return;
        }
        if(!isEmpty(item.value)){
          set(gridItem, 'valueValueString', this._setValueString(item));
          set(gridItem, 'numericCellInputValue', this._setValueString(item));
          set(gridItem, 'value', item.value);
        }
        set(gridItem, 'interpretation', item.interpretation);
        if(!isEmpty(item.interpretation)){
          set(gridItem, 'interpretation.code', item.interpretation.coding.get('firstObject.code'));
        }
        set(gridItem, 'valueTypeCode', item.valueTypeCode);
        set(gridItem, 'isValueChanged', false);
        this._inputCallBackSetting(inputModeType, gridItem, item);
        if(!isEmpty(item.remark)){
          set(gridItem, 'remarkTooltip', item.remark.replace(/\n|\r\n/giu, '<br>'));
        }
      }.bind(this));
      return resultListItemsSource;
    }.bind(this)).catch(function(error){
      this._catchError(error);
    }.bind(this));
  },

  _updatedValue(e, now){
    // const now= this.get('co_CommonService').getNow();
    let value= isEmpty(e.get('value'))? {} : e.get('value');
    switch(e.valueTypeCode){
      case 'Quantity':
        if(!isEmpty(value)){
          value={
            quantity: {
              value: e.get('value.quantity.value'),
              comparatorCode: isEmpty(e.value.quantity.comparatorCode)? '-': e.get('value.quantity.comparatorCode'),
              unitCode: e.get('examinationUnit.code')? e.get('examinationUnit.code'): null,
              unitName: e.get('examinationUnit.name')? e.get('examinationUnit.name'): null
            },
            codeableConcept: null,
            valueString: isEmpty(e.value.valueString)? null : e.value.valueString
          };
        }
        break;
      case 'CodeableConcept':
        if(!isEmpty(value)){
          if(!isEmpty(value.codeableConcept)){
            if(!isEmpty(value.codeableConcept.coding)){
              value.codeableConcept.coding.forEach(i=>{
                set(i,'dataFirstRegisteredDateTimeUtc', now);
                set(i,'dataLastModifiedDateTimeUtc', now);
              });
              set(e,'value.codeableConcept.dataFirstRegisteredDateTimeUtc', now);
              set(e,'value.codeableConcept.dataLastModifiedDateTimeUtc', now);
            }
          }
        }
        break;
      default:
        break;
    }
    return value;
  },
  _setCalculateObservationResults(e, value, isChange){
    return{
      isChange: isChange,
      examinationId: e.examinationId,
      observationResultId: e.observationResultId,
      valueTypeCode: e.valueTypeCode,
      recentObservationResultId: isEmpty(e.recentObservationResult)? null: e.recentObservationResult.observationResultId,
      value:{
        quantity: value.quantity,
        codeableConcept: value.codeableConcept,
        valueDecimal: isEmpty(value.valueDecimal)? 0 : value.valueDecimal,
        valueString: value.valueString,
        valueBool: true,
      },
    };
  },

  _inputCallBackSetting(inputModeType, gridItem,item ){
    const diffArr= this.get('diffArr');
    if(!isEmpty(diffArr)){
      //diff 클릭 후remark 세팅
      const obj= diffArr.findBy('examinationId', gridItem.examinationId);
      if(!isEmpty(obj)){
        set(gridItem, 'remark', obj.get('value.valueString'));
        set(gridItem, 'isValueChanged', false);
      }
      //check에서 isNotAnalyticalMeasurementRange, isRecheck 빼고 update
      if(!isEmpty(item.check)){
        set(gridItem, 'check.isCritical', item.check.isCritical);
        set(gridItem, 'check.isDelta', item.check.isDelta);
        set(gridItem, 'check.isPanic', item.check.isPanic);
        // if(gridItem.statusCode == "waiting"){
        if(gridItem.check.isNotAnalyticalMeasurementRange != item.check.isNotAnalyticalMeasurementRange){
          //calculate 후 달라졌을 경우만 업데이트
          set(gridItem, 'check.isNotAnalyticalMeasurementRange', item.check.isNotAnalyticalMeasurementRange);
        }
        set(gridItem, 'check.isRecentCritical', item.check.isRecentCritical);
      }
      set(gridItem, 'interpretation', item.interpretation);
      if(!isEmpty(item.interpretation)){
        set(gridItem, 'interpretation.code', item.interpretation.coding.get('firstObject.code'));
      }
    }else if(inputModeType == "Slide" ){
      //slide는 remark만 업데이트
      if(!isEmpty(item.remark)){
        set(gridItem, 'remark', item.remark);
        set(gridItem, 'isUpdated', true);
      }
    }else if(inputModeType == "Stick" || inputModeType == "Rule" || inputModeType == "Micro"){
      // set(gridItem, 'check', item.check);
      if(!isEmpty(item.check)){
        set(gridItem, 'check.isCritical', item.check.isCritical);
        set(gridItem, 'check.isDelta', item.check.isDelta);
        set(gridItem, 'check.isPanic', item.check.isPanic);
        // if(gridItem.statusCode == "waiting"){
        if(gridItem.check.isNotAnalyticalMeasurementRange != item.check.isNotAnalyticalMeasurementRange){
          //calculate 후 달라졌을 경우만 업데이트
          set(gridItem, 'check.isNotAnalyticalMeasurementRange', item.check.isNotAnalyticalMeasurementRange);
        }
        set(gridItem, 'check.isRecentCritical', item.check.isRecentCritical);
      }
      if(isEmpty(item.value)){
        set(gridItem, 'value', {quantity : {value: null},codeableConcept : {coding:null}});
        set(gridItem, 'valueTypeCode', item.valueTypeCode);
      }
    }
  },

  _setResultValue(element){
    const recentValue= isEmpty(element.recentObservationResult)? [] : element.recentObservationResult;
    recentValue.remark= isEmpty(recentValue.remark)? '': recentValue.remark;
    let valueValueString= '';
    if(isEmpty(element.value)){
      set(element, 'value', {quantity: {value: null}, codeableConcept: {coding: [{code:null, displayName: null}]}, valueString: null, valueDecimal: 0 });
    }
    if(element.valueTypeCode == 'Quantity'){
      const value= element.value.quantity.value;
      if(isEmpty(value)){
        set(element, 'valueValueString', '');
      }else{
        //저장된 값 있을 경우
        valueValueString = this._setComparator(element.value.quantity.comparatorCode) + ' ' + value + ' ' + this._nullCheck(element.value.valueString);
        set(element, 'valueValueString', valueValueString.trim());
        set(element, 'numericCellInputValue', valueValueString.trim());
      }
    }else if(element.valueTypeCode=='CodeableConcept' && !isEmpty(element.value.codeableConcept)){
      if(isEmpty(element.value.codeableConcept.coding) && isEmpty(element.valueValueString)){
        set(element, 'value', {codeableConcept: {coding: [{code:null, displayName: null}]}, valueString: null, valueDecimal: 0 });
      }
      if(!isEmpty(element.value.codeableConcept.coding)){
        if(!isEmpty(element.value.codeableConcept.coding.get('firstObject.code'))){
          //저장된 값 있을 경우
          let displayName= '';
          displayName= element.value.codeableConcept.displayContent;
          valueValueString= displayName + ' '+ this._nullCheck(element.value.valueString).trim();
          set(element, 'valueValueString', valueValueString.trim());
          set(element, 'numericCellInputValue', valueValueString.trim());
        }
      }
    }else if(element.valueTypeCode=='ValueString' || (element.valueTypeCode=='ValueTextString' && isEmpty(element.value.recordNoteId))){
      valueValueString= this._nullCheck(element.value.valueString).trim();
      set(element, 'valueValueString', valueValueString);
      set(element, 'numericCellInputValue', valueValueString.trim());
    }
    this._setRecentValue(element);
    return element;
  },

  _setValueString(element){
    let valueValueString= '';
    if(isEmpty(element.value)){
      set(element, 'value', {quantity: {value: null}, codeableConcept: {coding: [{code:null, displayName: null}]}, valueString: null, valueDecimal: 0 });
    }
    if(element.valueTypeCode == 'Quantity'){
      if(isEmpty(element.value.quantity)){
        set(element, 'value', {quantity: {value: null}, codeableConcept: {coding: [{code:null, displayName: null}]}, valueString: null, valueDecimal: 0 });
      }
      const value= element.value.quantity.value;
      if(isEmpty(value)){
        // set(element, 'valueValueString', '');
      }else{
        //저장된 값 있을 경우
        valueValueString= this._setQuantityValueValueString(element);
      }
    }else if(element.valueTypeCode=='CodeableConcept' && !isEmpty(element.value.codeableConcept)){
      if(!isEmpty(element.value.codeableConcept.coding)){
        if(!isEmpty(element.value.codeableConcept.coding.get('firstObject.code'))){
          //저장된 값 있을 경우
          valueValueString= this._setCodeValueValueString(element);
        }else if(element.value.valueString){
          valueValueString= this._setCodeValueValueString(element);
        }
      }else if(element.value.valueString){
        valueValueString= this._setCodeValueValueString(element);
      }
    }else if(element.valueTypeCode=='ValueString' || (element.valueTypeCode=='ValueTextString' && isEmpty(element.value.recordNoteId))){
      let valueString= element.value.valueString;
      if(isEmpty(valueString)){
        valueString= '';
      }else{
        valueValueString= valueString.trim();
      }
    }
    return valueValueString.trim();
  },

  _setRecentValue(element){
    let recentValue= isEmpty(element.recentObservationResult)? []: element.recentObservationResult;
    if(isEmpty(recentValue.displayResult)){
      recentValue = null;
    }else{
      recentValue =recentValue.displayResult;
    }
    // if(isEmpty(recentValue.value)){
    //   recentValue = null;
    // }else if(recentValue.valueTypeCode == 'Quantity'){
    //   recentValue = recentValue.displayResult;
    //   recentValue = isEmpty(recentValue.value)? null: this._setQuantityValueValueString(recentValue);
    // }else if(recentValue.valueTypeCode == 'CodeableConcept'){
    //   if (!isEmpty(recentValue.displayResult)){
    //     recentValue = recentValue.displayResult;
    //   }else if (!isEmpty(recentValue.value.codeableConcept)){
    //     recentValue = recentValue.value.codeableConcept.coding.get('firstObject.displayName');
    //   }else{
    //     recentValue = null;
    //   }
    // }else if(recentValue.valueTypeCode == 'ValueString' && !isEmpty(recentValue.value.valueString)){
    //   recentValue = recentValue.value.valueString;
    // }else if(recentValue.valueTypeCode == 'ValueTextString' && !isEmpty(recentValue.value.valueString)){
    //   recentValue = recentValue.value.valueString;
    // }else if(recentValue.valueTypeCode == 'ValueTextString' && !isEmpty(recentValue.value.valueTextString)){
    //   recentValue = recentValue.value.valueTextString;
    // }
    // else{
    //   recentValue = null;
    // }
    return recentValue;
  },

  _setQuantityValueValueString(item){
    let quantityValue= item.value.quantity.value;
    let comparator=item.value.quantity.comparatorCode;
    let valueString= item.value.valueString;
    if(isEmpty(quantityValue)){
      quantityValue= '';
    }
    if(comparator =='-' || isEmpty(comparator)){
      comparator= '';
    }
    if(isEmpty(valueString)){
      valueString= '';
    }
    return comparator+ ' ' + quantityValue + ' ' + valueString;
  },

  _setCodeValueValueString(item){
    let displayContent=null;
    if(!isEmpty(item.value)){
      displayContent= item.value.codeableConcept.displayContent;
    }
    let valueString= item.value.valueString;
    if(isEmpty(displayContent)){
      displayContent= '';
    }
    if(isEmpty(valueString)){
      valueString= '';
    }
    return displayContent + ' '+ valueString;
  },

  _setComparator(comparator){
    if(comparator =='-' || isEmpty(comparator)){
      return '';
    }else{
      return comparator;
    }
  },

  _nullCheck(a){
    return isEmpty(a)? '': a;
  },

  _setCurrentCell(tmp, originalSource){
    const top = tmp.$('#' + originalSource.elementId).height() * -1;

    return {
      item : originalSource.item,
      element : tmp.$('#' + originalSource.elementId),
      field : originalSource.column.field,
      rowIndex : originalSource.rowIndex,
      cellIndex: this.get('_gridControl').getColumnIndex(originalSource.column),
      offset : {top : top + 'px', left : 0 + 'px'},
    };
  },

  onShowToast(type, content, title) {
    this.get('toast').toastr({
      type: type,
      content: content,
      title: title,
      option: {
        closeButton: false,
        timeOut: 4000,
        positionClass: 'toast-bottom-center'
      }
    });
  },

  _showMessage(caption, messageBoxImage, messageBoxButton, messageBoxFocus, messageBoxText, messageboxInterval){
    const options = {
      'caption': caption,
      'messageBoxImage': messageBoxImage,
      'messageBoxButton': messageBoxButton,
      'messageBoxFocus': messageBoxFocus,
      'messageBoxText': messageBoxText,
      'messageboxInterval': messageboxInterval
    };

    return messageBox.show(this, options);
  },

});

