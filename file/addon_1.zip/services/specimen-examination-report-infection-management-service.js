import CHIS from 'framework/chis-framework';
import config from '../app-config';

export default CHIS.FR.Core.ServiceBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, {

  urlPrefix: '',
  serviceUrl: null,

  init() {
    this._super(...arguments);

    const defaultUrl = this.get('fr_HostConfigService')
      .getEnvConfig('ServerCallConfig', config.service) +
      `specimen-examination-report/${config.version}`;

    this.set('urlPrefix', defaultUrl);
    this.set('serviceUrl', `${defaultUrl}/infection-management`);
  },

  getPathogenClassification(params) {
    return this.getList(`${this.get('serviceUrl')}/pathogen/classification-list`, params, null);
  },
  getPathogenExaminationResult(params) {
    return this.getList(`${this.get('serviceUrl')}/pathogen/examination-result-list`, params, null);
  },
  createPathogenExaminationMapping(params) {
    return this.create(`${this.get('serviceUrl')}/pathogen/examination-mapping`, null, params, false);
  },
  createPathogenDeclare(params) {
    return this.create(`${this.get('serviceUrl')}/pathogen/declaration`, null, params, false);
  },
  getBusinessCodes(code) {
    const param = {classificationCode: code};
    return this.getList(`${this.get('urlPrefix')}/business-codes/search`, param, null);
  },
  getBusinessCodeList(params) {
    return this.getList(`${this.get('urlPrefix')}/business-codes/search`, null, params, false);
  },
  getPathogenMappingOrganization(params) {
    return this.getList(`${this.get('serviceUrl')}/pathogen-mapping/organization`, params, null);
  },
  getPathogenMappingExaminationList(params) {
    return this.getList(`${this.get('serviceUrl')}/pathogen-mapping/examination-list`, params, null);
  },
  getPathogenMappingResultList(params) {
    return this.getList(`${this.get('serviceUrl')}/pathogen-mapping/result-list`, params, null);
  },
  getPathogenMappingValueList(params) {
    return this.getList(`${this.get('serviceUrl')}/pathogen-mapping/value-list`, params, null);
  },

});