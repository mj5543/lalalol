/* eslint-disable no-console */
import $ from 'jquery';
import { isEmpty, isPresent } from '@ember/utils';
import { later } from '@ember/runloop';
import { A as emberA } from '@ember/array';
import { set } from '@ember/object';
import layout from './template';
import CHIS from 'framework/chis-framework';
import VerificationMixin from '../../mixins/specimen-examination-report-verification-mixin';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(
  VerificationMixin,
  MessageMixin,
  {
    layout,
    specimenNumber: null,
    examinationCode: null,
    isShowLoader: false,
    searchPatientId: null,
    searchPatientInfo: null,
    menuOpenedPatient: null,
    isShowEmpty: false,
    isDRGChecked: true,

    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-verification-report-patient-search');
      this.setStateProperties([
        'model',
        'globalPatient',
        'tableItems',
        'historytableItems',
        'gridColumns',
        'historyGridColumns',
        'hospitalUnitItems'
      ]);
      if (this.hasState() === false) {
        this.set('model', {
          selectedGridItem: null,
        });
        this.set('tableItems', emberA());
        this.set('verificationCount', 0);
        this.set('historytableItems', emberA());
        this.set('gridColumns', [
          { field: 'patient.displayNumber', title: this.getLanguageResource('8451', 'F', '', '환자번호'), width: 48, align: 'center', bodyTemplateName:'textTooltip'},
          { field: 'patient.name', title: this.getLanguageResource('16881', 'F', '', '환자명'), width: 35, align: 'center',bodyTemplateName:'textTooltip'},
          // { field: '', title: this.getLanguageResource('tempkey', 'F', '', '병동/병실'), width: 110},
          // { field: '', title: this.getLanguageResource('8898', 'F', '', '진료의'), width: 110, align: 'center',},
          { field: 'attendingDepartment.name', title: this.getLanguageResource('7111', 'S', '', '진료과'), width: 43, align: 'center',bodyTemplateName:'textTooltip'},
          { field: 'isInterpretated', title: this.getLanguageResource('7940', 'F', '', '판독'), width: 20, align:'center', bodyTemplateName:'interpretatedYN'},
        ]);
        this.set('historyGridColumns', [
          { field: '', title: this.getLanguageResource('6366', 'F', '', '입원일'), width: 130, align: 'center', type: 'date', dataFormat: 'd',},
          { field: '', title: this.getLanguageResource('2872', 'F', '', '보고일'), width: 130, align: 'center', type: 'date', dataFormat: 'd',},
          { field: '', title: this.getLanguageResource('2874', 'F', '', '보고자'), width: 110, align: 'center',},
        ]);
        this.set('hospitalUnitItems', emberA());
      }
    },

    onLoaded(){
      this._super(...arguments);
      // this.set('menuClass', 'w680');
      this._init();
    },
    didInsertElement() {
      this._super(...arguments);
      this.get('co_ContentMessageService').subscribeMessage('verification_worklist_resfresh', this.get('currentMenuId'), this, this.updateRefreshMessage);
      this.get('co_ContentMessageService').subscribeMessage('verification_worklist_selectedData', this.get('currentMenuId'), this, this._sendSelectedDataInfo);
      // this.get('co_ContentMessageService').subscribeMessage('verification_set_on_class', this.get('currentMenuId'), this, this._setOnClass);
    },

    willDestroyElement() {
      this._super(...arguments);
      this.get('co_ContentMessageService').unsubscribeMessage('verification_worklist_resfresh', this.get('currentMenuId'), this, this.updateRefreshMessage);
      this.get('co_ContentMessageService').unsubscribeMessage('verification_worklist_selectedData', this.get('currentMenuId'), this, this._sendSelectedDataInfo);
      // this.get('co_ContentMessageService').unsubscribeMessage('verification_set_on_class', this.get('currentMenuId'), this, this._setOnClass);
    },

    _sendSelectedDataInfo() {
      const menuOpenedParameters = this.get('menuOpenedParameters');
      if(!isEmpty(menuOpenedParameters)) {
        this.get('co_ContentMessageService').sendMessage('verification_selectedData', menuOpenedParameters);
      }
    },

    _setOnClass() {
      if(isEmpty(this.get('globalPatient'))) {
        return;
      }
      const itemList = this.get('tableItems');
      if(!isEmpty(itemList)) {
        itemList.map(data => {
          set(data, 'class', '');
          if(data.patient.displayNumber === this.get('globalPatient.patientDisplayId')) {
            set(data, 'class', 'on');
          }
        });
      }
    },

    updateRefreshMessage(){
      this.getDatas(true);
    },

    onPatientChanged(Patient){
      this._super(...arguments);
      this.set('globalPatient', Patient);
      const itemList = this.get('tableItems');
      this._setOnClass();
      const selectedPatient = this.get('menuOpenedPatient');
      if(!isEmpty(selectedPatient) && !isEmpty(itemList)) {
        if(selectedPatient.patientId !== Patient.patientId) {
          this.set('menuOpenedParameters', null);
          itemList.map(data => {
            set(data, 'class', '');
          });
        }
      }
      if(isEmpty(Patient)){
        this.get('co_MenuManagerService').closeMenu('specimen-examination-report-verification-report-interpretation');
        // return;
      }
    },
    actions: {
      onGetPatient(item) {
        this.set('searchPatientInfo', item);
        // this.getDatas();
      },
      onCleareSearch() {
        this.set('searchPatientInfo', null);
      },
      onSearchClick() {
        this.getDatas();
      },
      onPickerChanged() {
        this.getDatas();
      },
      onGridCellDoubleClick() {
        this._getOpenMenu();
      },
      onTableItemDoubleClick(item) {
        this.set('selectedTableItem', item);
        // const itemList = this.get('tableItems');
        // itemList.map(data => {
        //   set(data, 'class', '');
        // });
        // set(item, 'class', 'on');
        this._getOpenMenu(item);
      },
      onDRGCheckChanged(e) {
        if(isEmpty(this.get('originalList'))) {
          return;
        }
        this.set('isShowLoader', true);
        const listItem = $.extend(true, [], this.get('originalList'));
        let filterItems = listItem;
        if(e.checked) {
          filterItems = listItem.filter(d => d.isDrgTarget === !e.checked);
        }
        this.set('tableItems', filterItems);
        later(() => {
          this.set('isShowLoader', false);
        });
      },

    },
    _getOpenMenu(item) {
      // const item = this.get('model.selectedGridItem');
      if (!isEmpty(item)) {
        let examinationState = null;
        if(isPresent(item.statusCode.code)) {
          examinationState = item.statusCode.code.charAt(0).toUpperCase() + item.statusCode.code.slice(1);
        }
        console.log('examinationState--', examinationState);
        const globalItem = {
          patientGlobalPathType: 'Encounter',
          patientChoicePath: 'Encounter',
          patientId: item.patient.patientId,
          encounterId: item.encounterId,
          examination: {
            state: examinationState
          },
          patientSelectionSource: {
            viewId: this.get('viewId')
          }
        };
        const menu = [{
          displayCode: 'specimen-examination-report-verification-report-interpretation',
          stateType: null,
          parameters: {
            subjectId: item.subjectId,
            patient: item.patient,
            encounterId: item.encounterId,
            activationDate: item.activationDate,
            attendingDepartmentId: item.attendingDepartment.id,
            specimens: item.specimens,
            statusCode: item.statusCode
          }
        }];
        this.set('menuOpenedPatient', item.patient);
        this.set('menuOpenedParameters', menu[0].parameters);
        this.get('co_PatientManagerService').selectPatient(globalItem, menu);
      }
    },
    _init() {
      this._dataReset();
      this.getDatas();
    },

    _dataReset() {
      this.set('formReset', !this.get('formReset'));
      this.set('searchPatientInfo', null);
      this.set('searchPatientId', null);
    },
    async getDatas(isUpdateRefresh) {
      try {
        this.set('tableItems', emberA());
        this.set('isShowLoader', true);
        const params = {
          patientId: this.get('searchPatientInfo.patientId'),
          stayDate: this.getSearchParamsDate()
          // stayDate: '2019-05-20 00:00:00'
        };
        const result = await this.get('apiService').getVerificationReportWorkList(params);
        // let count = 0;
        this.getCount();
        if(!isEmpty(result)) {
          this.set('isShowEmpty', false);
          result.map(item => {
            item.class = '';
            if(isUpdateRefresh && (item.patient.displayNumber === this.get('selectedTableItem.patient.displayNumber'))) {
              item.class = 'on';
            }
            if(item.patient.isPrivacyProtection || item.patient.isProtectionHealthInfo) {
              item.isShowIconProtect = true;
            }
          });
          // this.set('verificationCount', count);
          this.set('originalList', result);
          let items = result;
          if(this.get('isDRGChecked')) {
            items = result.filter(d => !d.isDrgTarget);
          }
          if(isEmpty(items)) {
            this.set('isShowEmpty', true);
          } else {
            this.set('tableItems', items);
          }
        } else {
          this.set('isShowEmpty', true);
        }
        this.set('isShowLoader', false);
      } catch(e) {
        this._showError(e);
        console.error(e);
      }

    },
    async getCount() {
      try {
        const params = {
          searchDate: this.getSearchParamsDate()
          // stayDate: '2019-05-20 00:00:00'
        };
        const result = await this.get('apiService').getVerificationCount(params);
        if(!isEmpty(result)) {
          this.set('verificationCount', result);
        } else {
          this.set('verificationCount', 0);
        }
      } catch(e) {
        if(!this.get('isDestoryed')) {
          this.set('verificationCount', '');
        }
        this._showError(e);
        console.error(e);
      }
    },


  });