import { isEmpty, isPresent } from '@ember/utils';
// import { set } from '@ember/object';
import { set } from '@ember/object';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from '../../app-config';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';
import PrintMixin from '../../mixins/specimen-examination-report-print-mixin';
import ValueSettingMixin from '../../mixins/specimen-examination-resport-result-value-setting-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  PrintMixin,
  MessageMixin,
  ValueSettingMixin,
  {
    layout,
    // 2. Property Area
    defaultUrl: null,
    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-re-test-search');
      //Set Stateful properties
      this.setStateProperties([
        'defaultUrl',
        'searchCondition',
        'gridColumns',
        'gridItemsSource',
      ]);
      if (this.hasState() === false) {
      //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')
        +`specimen-examination-report/${config.version}/`);
        this.set('gridColumns',[
          { title: this.getLanguageResource('16890', 'F', '검사일'), field: 'checkInDate', width: 90, type: 'date', dataFormat: 'd', align: 'center' },
          { title: this.getLanguageResource('16892', 'S','검사분류'), field: 'classification.name', bodyTemplateName: 'tooltip', width: 140 },
          { title: this.getLanguageResource('16920', 'S', '검사항목'), field: 'examination.name', width: 150, bodyTemplateName:'orderNameTooltip'},
          { title: this.getLanguageResource('16881', 'S','Pt Name'), field: 'subject.name', align: 'center', bodyTemplateName: 'boldTooltip', width: 90 },
          { title: this.getLanguageResource('8451', 'S','MRN'), field: 'subject.displayNumber', bodyTemplateName: 'bold', align: 'center', width: 70 },
          { title: this.getLanguageResource('16921', 'S','검체명'), field: 'specimenType.name', bodyTemplateName: 'tooltip', width: 100, },
          { title: this.getLanguageResource('859', 'S','검체번호'), field: 'specimenNumber', bodyTemplateName: 'colfont', width: 100, align: 'center' },
          { title: this.getLanguageResource('tempkey', 'F', '', '1차결과'), field: 'displayValue',align: 'center', width: 100 },
          { title: this.getLanguageResource('tempkey', 'F', '', '최종결과'), field: 'displayLastValue',align: 'center', width: 100 },
          { title: this.getLanguageResource('8827', 'S','발행처'), field: 'issuedDepartment.name', width: 100, align: 'center', bodyTemplateName: 'tooltip' },
          { title: this.getLanguageResource('1113', 'S','진료과'), field: 'department.name', width: 100, align: 'center', bodyTemplateName: 'tooltip' },
          { title: this.getLanguageResource('9686', 'S','처방의'), field: 'physicianStaff.name', bodyTemplateName: 'tooltip', width: 90, align: 'center' },
        ]);
      }
    //Initialize Stateless properties
    },

    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1180');
      if (this.hasState() === false) {
        const today= this.get('co_CommonService').getNow();
        const searchCondition = {
          fromDate: today,
          toDate: today,
          subjectNumber: null,
          specimenNumber: null,
          classificationIds: null,
        };
        this.set('searchCondition', searchCondition);
        this._getClassifications();
      }
    },
    async _getClassifications() {
      this.set('selectedClassificationId', null);
      const result = await this.getList(this.get('defaultUrl') + 'classifications', {selectedOption: 0, classificationType: 1}, null);
      if(isPresent(result)) {
        this.set('comboboxItems', result);
      }
      this._getGridData();
    },
    // 4. Actions Area
    actions: {
      onLoadCombobox(e){
        this.set('_classificationIdsCombobox', e.source);
      },
      onLoadGrid(e){
        this.set('gridSource', e.source);
      },

      onExamTypeSelectedChanged(){
        set(this.get('searchCondition'), 'classificationIds', this.get('_classificationIdsCombobox.selectedItems').map(function(item){
          return item.classificationId;
        }));
        this._getGridData();
      },
      onSearchClick(){
        this._getGridData();
      },
      onExcelPrintAction() {
        const gridSource = this.get('gridSource');
        const reason = 'Excel export specimen-examination-report-re-test list.';
        const headers = [];
        const fields = [];
        this.get('gridColumns').forEach(function(item, index){
          headers.addObject({ left: index, top: 0, right: index, bottom: 0, value: item.title});
          item.type == 'date'? fields.addObject({ width: 140, value: item.field }) : fields.addObject({ width: item.width, value: item.field });
        });
        gridSource.exportToExcel('specimen-examination-report-re-test.xlsx', headers, fields, this, 'onExcelPrintAction',reason , this.get('gridItemsSource'));
      },
    },
    // 5. Private methods Area
    async _getGridData(){
      try {
        const searchCondition= this.get('searchCondition');
        if(isEmpty(searchCondition)){
          return;
        }
        set(this.get('searchCondition'), 'classificationIds', this.get('_classificationIdsCombobox.selectedItems').map(function(item){
          return item.classificationId;
        }));
        this.set('isGridShow', true);
        this.set('gridItemsSource', null);
        const params={
          checkInFromDate: new Date(searchCondition.fromDate.getFullYear(), searchCondition.fromDate.getMonth(), searchCondition.fromDate.getDate(), 0, 0, 0).toFormatString(),
          checkInToDate: new Date(searchCondition.toDate.getFullYear(), searchCondition.toDate.getMonth(), searchCondition.toDate.getDate(), 0, 0, 0).toFormatString(),
          specimenNumber: isEmpty(searchCondition.specimenNumber)? null: searchCondition.specimenNumber.trim(),
          subjectTypeCode: 'Patient',
          subjectNumber: isEmpty(searchCondition.subjectNumber)? null : searchCondition.subjectNumber.trim(),
          classificationIds: isEmpty(searchCondition.classificationIds)? null : searchCondition.classificationIds
        };
        const res = await this.getList(this.get('defaultUrl') + 'observations/reobservations/search', null, params, false);
        if(isPresent(res)) {
          res.map(d => {
            d.displayValue = this._setValueString(d, 'value');
            d.displayLastValue = this._setValueString(d, 'lastValue');
            d.orderNameTooltip = d.examination.displayCode + ', '+ d.examination.name;
          });
          this.set('gridItemsSource', res);
        }
        this.set('isGridShow', false);
      } catch(e) {
        this.set('isGridShow', false);
        this.showResponseMessage(e);
      }
    }
  });