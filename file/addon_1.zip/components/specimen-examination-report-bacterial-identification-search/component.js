import { next } from '@ember/runloop';
import { copy } from '@ember/object/internals';
import { hash } from 'rsvp';
import { isEmpty } from '@ember/utils';
import $ from 'jquery';
import EmberObject, { computed, set } from '@ember/object';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import { A } from '@ember/array';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MessageMixin,
  {
    layout,
    specimenexaminationreportService: service('specimen-examination-report-service'),
    // 2. Property Area
    defaultUrl: null,
    itemChanged: computed('updatedSelectedItem', function() {
      this._itemChanged();
    }),

    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-germ-search');
      //Set Stateful properties
      this.setStateProperties([
        'defaultUrl',
        'gridColumns',
        'gridItemsSource',
        'gridSelectedItem',
        'searchCondition',
        'typeItemsSource',
        'subTypeItemsSource',
        // 'enableReorderRow',
        'isSelectBtnVisibie',
      ]);
      if (this.hasState() === false) {
      //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')
        + `specimen-examination-report/v0/`);
        this.set('gridColumns', [
          { title: this.getLanguageResource('7674', 'F', 'Code'), field:'displayCode', width: 80},
          { title: this.getLanguageResource('5930', 'F', 'name'), bodyTemplateName: 'tooltip', field:'name'},
          { title: this.getLanguageResource('9761', 'S','감수성'), field:'susceptibility.name', fixedOrder: true, bodyTemplateName: 'tooltip', width: 100,align: 'center'},
          { title: this.getLanguageResource('1258', 'F', 'Type'), field:'bacterialType.name', fixedOrder: true, bodyTemplateName: 'tooltip', width: 90,align: 'center'},
          { title: this.getLanguageResource('9762', 'S', 'Gram'), field:'bacterialSubType.name', fixedOrder: true, bodyTemplateName: 'tooltip', width: 70,align: 'center'},
        ]);
        this.set('searchCondition', {
          type: null,
          subtype: null
        });
      }
    //Initialize Stateless properties
    },
    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w500');
      if (this.hasState() === false) {
        const defaultUrl = this.get('defaultUrl');
        hash({
          businessCodes: this.getList(defaultUrl + 'business-codes/search', null,{classificationCodes: ['BacterialTypeCode','BacterialSubTypeCode']}, false),
        }).then(function(result) {
          const typeItemsSource= [];
          const subtypeItemsSource= [];
          result.businessCodes.forEach(e=>{
            if(e.classificationCode == 'BacterialTypeCode'){
              typeItemsSource.addObject(e);
            }else if(e.classificationCode == 'BacterialSubTypeCode'){
              subtypeItemsSource.addObject(e);
            }
          });
          const searchCondition= this.get('searchCondition');
          this.set('typeItemsSource', typeItemsSource);
          this.set('subtypeItemsSource', subtypeItemsSource);
          set(searchCondition, 'type', typeItemsSource.get('firstObject.code') );
          set(searchCondition, 'subtype', subtypeItemsSource.get('firstObject.code') );
          this._getGridList();
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      }
    },

    getListCB(){
      this._getGridList();
    },

    actions: {
      onGridLoad(e){
        this.set('gridControl', e.source);
      },

      onTypeChanged(e){
        set(this.get('searchCondition'), 'type', e.item.code );
        this.set('gridSelectedItem', null);
        this._getGridList();
      },
      onSubTypeChanged(e){
        set(this.get('searchCondition'), 'subtype', e.item.code);
        this.set('gridSelectedItem', null);
        this._getGridList(this.get('searchCondition.code'));
      },

      onSortCommit(e){
        // if(this.get('key')==e.source.value){
        //   return;
        // }
        if(!isEmpty(e.source.value)){
          this.set('gridItemsSource', this._filtering(e.source.value));
        }else{
          this.set('gridItemsSource', this.get('allGridItemsSource'));
        }
        if(!isEmpty(this.get('gridItemsSource'))){
          this.set('gridSelectedItem', this.get('gridItemsSource.firstObject'));
        }else{
          this.set('gridSelectedItem', null);
        }
        // this.get('returnIdentificationCB')(this.get('gridSelectedItem'));
        this.set('key', e.source.value);
      },

      // onRowDragStart(e){
      //   // this.set('dragItem', e.dragItems.get('firstObject'));
      //   this.set('dragItemIndex', this.get('gridControl').getItemIndex(e.dragItems[0]));
      // },

      // onRowDragEnd(e){
      //   this.set('dropItem', e.dropItem);
      //   this.get('specimenexaminationreportService').changeSequence(
      //     'bacterial-identifications/change-display-sequence',
      //     this.get('gridItemsSource'),
      //     $.extend(true, EmberObject.create(), e.dropItem),
      //     $.extend(true, EmberObject.create(), this.get('dragItem'))
      //   ).then(function(){
      //     this._getGridList();
      //   }.bind(this)).catch(function(error){
      //     this._catchError(error);
      //   }.bind(this));
      // },

      onSelectClick(){
        if(!isEmpty(this.get('gridSelectedItem'))){
          if(!isEmpty(this.get('returnIdentificationCB'))){
            this.get('returnIdentificationCB')(this.get('gridSelectedItem'));
          }
        }else{
          this.get('specimenexaminationreportService')._showMessage( this.getLanguageResource('9260', 'F','Select an item.'));
        }
      },
    },
    // 5. Private methods Area
    _itemChanged(){
      if(!isEmpty(this.get('updatedSelectedItem'))){
        this.set('searchCondition.code', null);
        this._getGridList();
      }else if(!isEmpty(this.get('gridControl'))){
        //삭제시
        this.get('gridControl').selectRow(0);
      }
    },

    _filtering(text){
      //현재 그리드 내에서 필터링
      const sortedGridItemsSource= copy(this.get('allGridItemsSource'));
      if(isEmpty(sortedGridItemsSource)){
        return;
      }
      const tmp=[];
      sortedGridItemsSource.forEach(element => {
        //현재 그리드에서 해당하는 것 추가
        if(element.name.toLocaleLowerCase().includes(text.toLocaleLowerCase()) || element.displayCode.toLocaleLowerCase().includes(text.toLocaleLowerCase())){
          tmp.addObject(element);
        }
      });
      return tmp;
    },

    _getGridList(searchKey){
      const searchCondition= this.get('searchCondition');
      this.set('isSearchGridShow', true);
      this.getList(this.get('defaultUrl') + 'bacterial-identifications',{
        bacterialTypeCode: searchCondition.type , bacterialSubTypeCode: searchCondition.subtype,} , null,true).then(function(res){
        this.set('isSearchGridShow', false);
        if(res){
          const promise = new Promise((resolve)=>{
            if(res.response.length){
              resolve(A(res.response));
              this.set('sortedGridItemsSource', res.response);
              const jsonArray = res.response.map(function(e){
                return $.extend(true, {}, e);
              });
              this.set('allGridItemsSource', $.extend(true, [], jsonArray));
              this.set('gridItemsSource', this.get('allGridItemsSource'));
              if(!isEmpty(searchKey)){
                this.set('gridItemsSource', this._filtering(searchKey));
              }
              next(this, function () {
                if(this.get('mode') !='management' || isEmpty(this.get('gridItemsSource'))){
                  return;
                }
                if(isEmpty(this.get('dragItem'))){
                  this.set('gridSelectedItem', this.get('gridItemsSource.firstObject'));
                  this.get('gridControl').selectRow(0);
                }else{
                  this.get('gridControl').selectRow(this.get('dropItem.displaySequence')-1);
                }
                if(!isEmpty(this.get('gridSelectedItem'))){
                  this.get('returnIdentificationCB')($.extend(true, EmberObject.create(), this.get('gridSelectedItem')));
                }
              }.bind(this));
            } else{
              resolve(A([]));
              this.set('gridItemsSource', null);
              next(this, function () {
                this.set('gridSelectedItem', {
                  displayCode: null,
                  name: null,
                  bacterialType: {displayCode: null, name: null},
                  bacterialSubType: {displayCode: null, name: null},
                  susceptibility: {displayCode: null, name: null},
                  displaySequence: 1,
                });
              }.bind(this));
            }
          });
          return promise;
        }
      }.bind(this)).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    _catchError(e){
      this.set('isSearchGridShow',false);
      this.showResponseMessage(e);
    }
  });