import { next } from '@ember/runloop';
import { A as emberA } from '@ember/array';
// import $ from 'jquery';
import { set } from '@ember/object';
import { isEmpty } from '@ember/utils';
// import { hash } from 'rsvp';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'specimenexaminationreport-module/app-config';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MessageMixin,
  /* Only For Server-Call Component
  CHIS.FR.CrossCutting.ServerCallMixin,
  */
  {
    specimenexaminationreportService: service('specimen-examination-report-service'),
    layout,
    // 2. Property Area
    examListColumns: null,
    examListItemsSource: null,
    isCodeSeachOpen: null,
    functionApplyCodeList: null,
    // dataAbsentReasonList: null,
    functionTypeCodeList: null,
    gridControl: null,
    previousItem: null,
    currentItem: null,
    _currentCell: null,
    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-diff-entry-item-management');
      //Set Stateful properties
      this.setStateProperties([
        'defaultUrl',
        'isCodeSeachOpen',
        'examListColumns',
        'examListItemsSource',
        'examListSelectedItem',
        'functionApplyCodeList',
        // 'dataAbsentReasonList',
        'functionTypeCodeList',
      ]);
      if (this.hasState() === false) {
        //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')
        + `specimen-examination-report/${config.version}/`);
        this.set('examListColumns', [
          { field: 'examination.displayCode', title: this.getLanguageResource('16919', 'S','Exam Code'), width:110, readOnly: true,align: 'center'},
          { field: 'examination.name', title: this.getLanguageResource('16920', 'S','Exam Name'), width:305, readOnly: true },
          { field: 'isPrescribable', title: this.getLanguageResource('17156', 'F','Function Key'), width:150, bodyTemplateName: 'functionKey' },
          { field: 'dataAbsentReason', title: this.getLanguageResource('906', 'S','Result Comment'), width:435, bodyTemplateName: 'resultComments'},
          { field: 'isPrescribable', title: this.getLanguageResource('17157', 'S','Calculation Method'), width:150, bodyTemplateName: 'sum' },
          { field: 'quantityValue', title: this.getLanguageResource('588', 'S','Value'), width:97 },
          { field: 'isPrescribable', title: '', width:116, bodyTemplateName: 'save'},
        ]);
      }
    //Initialize Stateless properties
    },
    _setReasonColumns(){
      return {field: 'dataAbsentReason', title: this.getLanguageResource('906', 'S','Result Comment'), width:445, bodyTemplateName: 'resultComments',
        onBodyCellRender: function (context) {
          if(!isEmpty(context.item.dataAbsentReason)){
            // set(context.cellComponent, 'description', `${get(context.item, 'point')}`);
            // set(context.cellComponent, 'descriptionStyle', 'font-weight: bold; width: 90px;');

          }
        }
      };
    },
    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1360');
      this._init();
    },
    // 4. Actions Area
    actions: {
      onRefreshClick() {
        this._getExamListItemsSource();
      },
      onGridLoad(e){
        this.set('gridControl', e.source);
      },

      onAddClick(){
        this.set('isCodeSeachOpen', true);
      },

      returnCodeValue(returnItem){
        if(isEmpty(returnItem)){
          return;
        }
        const tmp={
          examination:{
            displayCode: returnItem.displayCode,
            name: returnItem.name
          },
          property: returnItem.property,
          specimenExaminationId: returnItem.specimenExaminationId,
          displaySequence: returnItem.displaySequence,
          value:{}
        };
        let examListItemsSource= this.get('examListItemsSource');
        if(!isEmpty(examListItemsSource)){
          if(examListItemsSource.length > 0){
            if(!isEmpty(examListItemsSource.find(function(e){
              return e.examinationId== returnItem.specimenExaminationId;
            }))){
              this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9226', 'F', '이미 추가되어있습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
              return;
            }else {
              examListItemsSource.unshiftObject(tmp);
            }
          }else {
            examListItemsSource=[tmp];
          }
        }else{
          // 최초추가
          examListItemsSource=[tmp];
        }
        this.set('examListItemsSource', examListItemsSource);
        this.set('isCodeSeachOpen', false);
      },

      onSaveClick(item){
        if(isEmpty(item.functionKey) || isEmpty(isEmpty(item.quantityValue))){
          // this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('8945', 'F', '필수값을 입력하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
          // return;
        }

        if(isEmpty(item.id)){
          const params={
            exampleTypeCode: "DiffEntry",
            examinationId: item.specimenExaminationId,
            valueTypeCode: isEmpty(item.valueTypeCode)? this._returnValueType(item): item.valueTypeCode,
            value: {
              quantity: {
                value: parseInt(item.quantityValue),
                comparatorCode: null,
                unitCode: null,
                unitName: null
              },
              codeableConcept: null,
              valueDecimal: null,
              valueString: item.dataAbsentReason,
              valueBool: true,
            },
            functionTypeCode: item.functionTypeCode,
            functionApplyCode: item.functionKey,
            // displaySequence: this.get('examListItemsSource')? this.get('examListItemsSource.length')+1 : 1
            displaySequence: this.get('gridControl').getItemIndex(item)
          };
          this.create(this.get('defaultUrl') + 'observations/examples', null, params).then(function(){
            this.get('specimenexaminationreportService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
            this._getExamListItemsSource();
          }.bind(this)).catch(function(error){
            this._catchError(error);
          }.bind(this));
        }else{
          const params={
            observationExampleId: item.id,
            valueTypeCode: item.valueTypeCode,
            value: item.value,
            functionTypeCode: item.functionTypeCode,
            functionApplyCode: item.functionKey,
            // displaySequence: item.displaySequence,
            displaySequence: this.get('gridControl').getItemIndex(item),
            isValidDataRow: true,
          };
          params.value.quantity.value= parseInt(item.quantityValue);
          set(params, 'value.valueString', item.dataAbsentReason);
          this.update(this.get('defaultUrl') + 'observations/examples', null, false, params).then(function(){
            this.get('specimenexaminationreportService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
            this._getExamListItemsSource();
          }.bind(this)).catch(function(error){
            this._catchError(error);
          }.bind(this));
        }
      },

      onDelClick(item){
        if(isEmpty(item.id)){
          const examListItemsSource= this.get('examListItemsSource');
          examListItemsSource.removeObject(item);
        }else{
          const options = {
            'caption': '',
            'messageBoxButton': 'YesNoCancel',
            'messageBoxImage': 'question',
            'messageBoxText': this.getLanguageResource('11669', 'S','삭제하시겠습니까?'),
            'messageBoxFocus': 'Yes'
          };
          return messageBox.show(this, options).then(function (result) {
            if(result==='Yes'){
              const params={
                observationExampleId: item.id,
                valueTypeCode: item.valueTypeCode,
                value: item.value,
                functionTypeCode: item.functionTypeCode,
                functionApplyCode: item.functionKey,
                displaySequence: item.displaySequence,
                isValidDataRow: false,
              };
              params.value.quantity.value= parseInt(item.quantityValue);
              set(params, 'value.valueString', item.dataAbsentReason);
              this.update(this.get('defaultUrl') + 'observations/examples', null, false, params).then(function(){
                this.get('specimenexaminationreportService').onShowToast('delete', this.getLanguageResource('8944', 'F', 'Deleted'), '');
                this._getExamListItemsSource();
              }.bind(this)).catch(function(error){
                this._catchError(error);
              }.bind(this));
            }
          }.bind(this));

        }
      },

      onBeforeFocusIn(e) {
        this.set('gridControl', e.source);
        if(e.type.includes('body')) {
          if(e.type.includes('cell')) {
            this.set('previousItem', this.get('currentItem'));
            this.set('currentItem', e.source.getOriginalSource(e.originalEvent).item);
            this.set('_currentCell', e.source.getCurrentCell());
            e.cancel = true;
          }
        }
        if(e.type.includes('body')) {
          if(e.type.includes('ghead')) {
            if(e.type.includes('expander')) {
              e.source.deselectAll();
            }
          }
        }
      },

      onCellClick(e){
        if(e.column.bodyTemplateName=='resultComments'){
          this.set('isResultCommentPopupOpen', true);
          this.set('commentPopupTitleResource', this.getLanguageResource('906', 'S','결과비고'));
          this.set('commentPopupPlacementTarget', `#${e.originalSource.elementId}`);
        }
      },
      returnDataAbsentReason(resultComments){
        if(isEmpty(resultComments)){
          return;
        }
        const currentItem= this.get('currentItem');

        set(currentItem , 'dataAbsentReason', resultComments);
      },

      onSelectionChange(e){
        const returnResultCommentsCB = this.get('returnResultCommentsCB');
        // const data= e.data;
        if(!isEmpty(returnResultCommentsCB)) {
          if(!isEmpty(e.source.value)){
            //아이템 선택
            returnResultCommentsCB(e.source.value, true);
            return false;
          }
        }
      },

      onRowDragStart(e){
        this.set('dragItemIndex', this.get('gridControl').getItemIndex(e.dragItems[0]));
        this.set('dragItem', e.dragItems.get('firstObject'));
      },

      onRowDrop(e){
        this.set('dropItem', e.dropItem);
        if(isEmpty(this.get('dragItem.id')) || isEmpty(e.dropItem.id)){
          return;
        }
        this.set('isGridShow', true);
        this.set('loaderType', 'progress');
        this.get('specimenexaminationreportService').changeSequence(
          'observations/examples/change-display-sequence',
          this.get('examListItemsSource'),
          this.get('dragItemIndex'),
          e.dropItem
        ).then(function(){
          if(!isEmpty(this.get('dragItem.id')) && !isEmpty(e.dropIte.id)){
            this.get('specimenexaminationreportService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
            this._getExamListItemsSource();
          }
        }).catch(function(error){
          this._catchError(error);
        }.bind(this));
      },

    },
    onAudit(){
      const item = this.get('examListSelectedItem');
      if(!isEmpty(item.id)){
        this.set('aggregateKey', item.id);
        this.set('isOpenAuditTrail', true);
      }
    },
    // 5. Private methods Area
    _init(){
      this.set('isGridShow', true);
      this.set('loaderType', 'spinner');
      this.set('isCodeSeachOpen', false);
      this._getDiffEntryRemarkClassification();
      this._getFunctionCodes();
    },

    _returnValueType(item){
      const resultTypeCode= item.property.resultTypeCode;
      if(isEmpty(resultTypeCode)){
        return null;
      }else if(resultTypeCode == 'Numeric'){
        return 'Quantity';
      }else if(resultTypeCode == 'Character'){
        return 'CodeableConcept';
      }else {
        return 'Quantity';
      }
    },

    _setExamList(){
      const list= this.get('examListItemsSource');
      list.forEach(e => {
        set(e, 'functionKey', isEmpty(e.functionApply)? null: e.functionApply.code);
        set(e, 'dataAbsentReason', e.get('value.valueString'));
        set(e, 'functionTypeCode', isEmpty(e.functionType)? null: e.functionType.code);
        set(e, 'quantityValue', e.get('value.quantity.value'));
      });
    },

    async _getExamListItemsSource() {
      try {
        this.set('loaderType', 'spinner');
        this.set('isGridShow', true);
        this.set('examListItemsSource', emberA());
        const result = await this.getList(this.get('defaultUrl') + 'observations/examples', {exampleTypeCode: 'DiffEntry'}, null, true);
        this.set('examListItemsSource', result.response);
        this.set('isGridShow', false);
        this._setExamList();
        next(this,function(){
          isEmpty(this.get('dragItem'))?
            this.set('examListSelectedItem', result.response.get('firstObject'))
            :this.get('gridControl').selectRow(this.get('dropItem.displaySequence')-1);
        }.bind(this));
      } catch(e) {
        this._showError(e);

      }
    },

    async _getDiffEntryRemarkClassification() {
      try {
        this.set('classificationId', null);
        const result = await this.getList(this.get('defaultUrl') + 'business-codes/search', {classificationCode: 'DiffEntryRemarkClassification'}, null);
        if(!isEmpty(result)) {
          this.set('classificationId', result[0].code);
          this._getResultRemarkExample();
        }
      } catch(e) {
        this._showError(e);
      }
    },
    async _getResultRemarkExample() {
      try {
        this.set('resultCommentsItemsSource', emberA());
        const params = {
          exampleTypeCode: 'ResultRemark',
          examinationId: null,
          classificationId: this.get('classificationId')
        };
        const result = await this.getList(this.get('defaultUrl') + 'observations/examples', params, null);
        if(!isEmpty(result)) {
          this.set('resultCommentsItemsSource', result);
        }
      } catch(e) {
        this._showError(e);
      }
    },

    async _getFunctionCodes() {
      try {
        const param = {classificationCodes: ['FunctionApplyCode','FunctionTypeCode']};
        const result = await this.getList(this.get('defaultUrl') + 'business-codes/search', null, param, false);
        const functionApplyCodeList = [];
        const functionTypeCodeList = [];
        if(!isEmpty(result)) {
          result.forEach(d =>{
            if(d.classificationCode == 'FunctionApplyCode'){
              functionApplyCodeList.addObject(d);
            }else if(d.classificationCode == 'FunctionTypeCode'){
              functionTypeCodeList.addObject(d);
            }
          });
        }
        this.set('functionApplyCodeList', functionApplyCodeList);
        this.set('functionTypeCodeList', functionTypeCodeList);
        this._getExamListItemsSource();
      } catch(e) {
        this._showError(e);
      }
    },
    // _getExamListItemsSource(){
    //   this.set('isGridShow', true);
    //   this.set('examListItemsSource', emberA());
    //   this.getList(this.get('defaultUrl') + 'observations/examples', {exampleTypeCode: 'DiffEntry'}, null, true).then(function(res){
    //     this.set('examListItemsSource', res.response);
    //     this._setExamList();
    //     next(this,function(){
    //       isEmpty(this.get('dragItem'))?
    //         this.set('examListSelectedItem', res.response.get('firstObject'))
    //         :this.get('gridControl').selectRow(this.get('dropItem.displaySequence')-1);
    //     }.bind(this));
    //   }.bind(this)).catch(function(error){
    //     this._catchError(error);
    //   }.bind(this));
    // },

    // _getResultRemarkExample() {
    //   const defaultUrl = this.get('defaultUrl');
    //   hash({
    //     // dataAbsentReasonList: this.getList(defaultUrl + 'observations/examples', {exampleTypeCode: 'ResultRemark', examinationId: null}, null),
    //     resultCommentsItemsSource: this.getList(defaultUrl + 'observations/examples', {
    //       exampleTypeCode: 'ResultRemark', examinationId: null, classificationId: this.get('classificationId')}, null),
    //     businessCodes: this.getList(defaultUrl + 'business-codes/search', null,{
    //       classificationCodes: [
    //         'FunctionApplyCode','FunctionTypeCode'
    //       ]
    //     }, false),
    //   }).then(function(result) {
    //     const functionApplyCodeList= [];
    //     const functionTypeCodeList= [];
    //     result.businessCodes.forEach(e=>{
    //       if(e.classificationCode == 'FunctionApplyCode'){
    //         functionApplyCodeList.addObject(e);
    //       }else if(e.classificationCode == 'FunctionTypeCode'){
    //         functionTypeCodeList.addObject(e);
    //       }
    //     });
    //     this.set('functionApplyCodeList', functionApplyCodeList);
    //     this.set('functionTypeCodeList', functionTypeCodeList);
    //     // this.set('dataAbsentReasonList', result.dataAbsentReasonList);
    //     this.set('resultCommentsItemsSource', result.resultCommentsItemsSource);
    //     this._getExamListItemsSource();
    //   }.bind(this)).catch(function(error){
    //     this._catchError(error);
    //   }.bind(this));
    // },

    _catchError(e){
      this.set('isGridShow',false);
      this.set('loaderType', 'spinner');
      this.showResponseMessage(e);
    }

  });