/* eslint-disable max-lines */
/* eslint-disable chis/require-template-forced-expression */
// import $ from 'jquery';
import { A } from '@ember/array';
import { set } from '@ember/object';
import { copy } from '@ember/object/internals';
import { next } from '@ember/runloop';
import { isEmpty, isPresent } from '@ember/utils';
import { hash } from 'rsvp';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'specimenexaminationreport-module/app-config';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MessageMixin,
  {
    specimenCheckInService: service('specimen-check-in-service'),
    specimenexaminationreportService: service('specimen-examination-report-service'),
    layout,
    // 2. Property Area
    isInit: null,
    defaultUrl: null,
    searchCondition: null,
    worklistConfigurations: null,
    conditionItemsSource: null,
    total: null,
    specimenNumberListColumns: null,
    specimenNumberListItemsSource: null,
    specimenNumber: null,
    equipFlagSelectedItem: null,
    tatSearchTypecodeItemsSource: null,
    tatSearchTimeMinuteItemsSource: null,
    patientTypeItemsSource: null,
    issuedDepartmentItemsSource: null,
    isSubSearchVisible: false,
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-work-list');

      //Set Stateful properties
      this.setStateProperties([
        'examDate',
        'defaultUrl',
        'searchCondition',
        'worklistConfigurations',
        'total',
        'specimenNumberListColumns',
        'specimenNumberListItemsSource',
        'specimenNumberListSelectedItem',
        'specimenNumber',
        'equipFlagSelectedItem',
        'tatSearchTypecodeItemsSource',
        'tatSearchTimeMinuteItemsSource',
        'issuedDepartmentItemsSource',
        'hpcSelectedValue',
      ]);
      if (this.hasState() === false) {
        //Initialize Stateful properties
        this.set('isLoaderShow', true);
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')
        + `specimen-examination-report/${config.version}/`);
        this.set('checkinUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimencheckin')+'specimen-checkin/v0/');
        this.set('currentUser', this.get('co_CurrentUserService.user'));
        this.set('examDate', this.get('co_CommonService').getNow());
        // this.set('detailSearchOpen', 'none');
        // this.set('isDetailClosed', '');
        this.set('specimenNumberListColumns', [
          { field: 'specimenNumber', title: this.getLanguageResource('859', 'S','Specimen No.'), align: 'center', bodyTemplateName: 'specimenInfo', width: 146},
          // { field: 'progressStatusCode', title: 'Status', align: 'center', width: 27},
        ]);
        this.set('sortByItemsSource', [
          {selected: true, value: 'basic', text: this.getLanguageResource('1514', 'S','', '기본')},
          {selected: false, value: 'tatCode', text: this.getLanguageResource('15513', 'S','', 'TAT경과기준')},
          {selected: false, value: 'patientName', text: this.getLanguageResource('4184', 'S','', '환자명')}]
        );
        this.set('equipFlagSelectedItem', this.get('equipFlagItemsSource.firstObject'));
        // this.set('relativeSource', this);
        this.set('isInit', true);
        //2021.01.13 정렬조건 추가 (TAT)
        this.set('selectedSortByValue', 'basic');
        //2018-12-10 검색조건 조각UI 추가
        this.set('findSettingPopupInfo', {});
        this.set('findSettingPopupInfo.isOpen', false);
      }
      this.set('calcPixcel', 250);
      //Initialize Stateless properties
    },


    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      if (this.hasState() === false) {
        const defaultUrl = this.get('defaultUrl');
        hash({
          // worklistConfigurations: this.getList(defaultUrl + 'worklist-configurations/search', {staffId:this.get('currentUser.employeeId')}, null),
          examinationTagNameItemsSource: this.getList(this.get('defaultUrl') + 'worklist-configurations/search',
            {staffId: this.get('co_CurrentUserService.user.employeeId')}, null),
          businessCodes: this.getList(defaultUrl + 'business-codes/search', null,{
            classificationCodes: [
              'WorkListSearchCode','TatSearchCode','EquipmentRemarkSelectType', 'TatTimeMinute'
            ],
          }, false),
          tatPercentCodes: this.getList(this.get('checkinUrl') + 'business-codes/search', {classificationCode: 'TatPercentSearchCode'}, null)
        }).then(function(result) {
          const conditionItemsSource=[];
          const tatSearchTypecodeItemsSource= [];
          const equipFlagItemsSource= [];
          const tatSearchTimeMinuteItemsSource= [];
          result.businessCodes.forEach(e=>{
            if(e.classificationCode == 'WorkListSearchCode'){
              conditionItemsSource.addObject(e);
            }else if(e.classificationCode == 'TatSearchCode'){
              tatSearchTypecodeItemsSource.addObject(e);
            }else if(e.classificationCode == 'EquipmentRemarkSelectType'){
              equipFlagItemsSource.addObject(e);
            }else if(e.classificationCode == 'TatTimeMinute'){
              tatSearchTimeMinuteItemsSource.addObject(e);
            }
          });
          this.set('tatPercentCodes', result.tatPercentCodes);
          this.get('tatPercentCodes').unshiftObject({code: 'A', name: this.getLanguageResource('6700', 'F', '', '전체')});
          this.set('conditionItemsSource', conditionItemsSource);
          this.set('tatSearchTypecodeItemsSource', tatSearchTypecodeItemsSource);
          this.set('equipFlagItemsSource', equipFlagItemsSource);
          this.set('equipFlagSelectedItem', equipFlagItemsSource.get('firstObject'));
          this.set('tatSearchTimeMinuteItemsSource', tatSearchTimeMinuteItemsSource);
          //검색조건 조각UI 추가
          this.set('examinationTagNameItemsSource', result.examinationTagNameItemsSource);
          if(!isEmpty(result.examinationTagNameItemsSource)){
            const filterdExaminationTagList=[];
            result.examinationTagNameItemsSource.forEach(e=>{
            //검사분류, 작업단위, 검사항목별로 나눠서 저장해둠
              filterdExaminationTagList.addObject(this._filterExaminationTagList(
                e.workListFindConfigurationId,
                e.property.classifications,
                e.property.unitWorks,
                e.property.observationExaminations));
            });
            this.set('filterdExaminationTagList', filterdExaminationTagList);
          }
          const today= this.get('co_CommonService').getNow();
          const searchCondition= {
            queryOption: null,
            checkInFromDate: today,
            checkInToDate: today,
            specimenNumber: null,
            checkInStartNumber: null,
            checkInEndNumber: null,
            encounterTypeCode: null,
            tatSearchTypecode: tatSearchTypecodeItemsSource.get('firstObject.code'),
            tatSearchTimeMinute: tatSearchTimeMinuteItemsSource.get('firstObject.code'),
            tatPercentSearchTypeCode: this.get('tatPercentCodes.firstObject.code')
          };
          this.get('co_PersonalizationService').getSettingInfo(`specimen-examination-report-work-list`).then((settingInfo) => {
            if(isEmpty(settingInfo.settingValue)){
              searchCondition.queryOption= conditionItemsSource.get('firstObject.code');
              searchCondition.classificationIds= null;
              searchCondition.unitWorkIds= null;
              searchCondition.examinationIds= null;
              searchCondition.isStat= false;
              searchCondition.isToday= false;
              this.set('hpcSelectedValue', 'HPCExclude');
            }else{
              const data = JSON.parse(settingInfo.settingValue).conditionData.get('firstObject');
              searchCondition.queryOption= data.queryOption;
              searchCondition.classificationIds= data.classificationIds;
              searchCondition.examinationIds= data.examinationIds;
              searchCondition.unitWorkIds= data.unitWorkIds;
              searchCondition.isStat= data.isStat;
              searchCondition.isToday= data.isToday;
              //검사set 콤보박스세팅
              if(!isEmpty(JSON.parse(settingInfo.settingValue).conditionData[1])){
                if(!isEmpty(this.get('examinationTagNameItemsSource')) && !isEmpty(JSON.parse(settingInfo.settingValue).conditionData[1].workListFindConfigurationId)){
                  this.set('examinationTagNameSelectedItem', this.get('examinationTagNameItemsSource').findBy('workListFindConfigurationId', JSON.parse(settingInfo.settingValue).conditionData[1].workListFindConfigurationId));
                }
              }else{
                this.set('examinationTagNameSelectedItem', JSON.parse(settingInfo.settingValue).conditionData[1]);
              }
              // this.set('examinationTagNameSelectedItem', JSON.parse(settingInfo.settingValue).conditionData[1] );
              // this.set('hpcSelectedValue', isEmpty(data.hpcSearchTypeCode)? 'HPCExclude' :data.hpcSearchTypeCode);
              this.set('hpcSelectedValue', JSON.parse(settingInfo.settingValue).hpcSearchTypeCode);
            }
            this.set('searchCondition',searchCondition);
            this._getSpecimenList().then(()=>{
              this.set('isLoaderShow', false);
            });
          });
        }.bind(this)).catch(function(e){
          this._catchError(e);
        }.bind(this));
      }
    },

    didInsertElement() {
      this._super(...arguments);
      this.$('#specimen-examination-report-work-list_specimenNumber').focus();

      // scheduleOnce('afterRender', () => {
      //   this.$('.scrollbar-macosx').scrollbar();
      // });
      this.get('co_ContentMessageService').subscribeMessage('updateMessage', this.get('currentMenuId'), this, this.updateMessage);
      this.get('co_ContentMessageService').subscribeMessage('EXAMINATION_SETTING_CALLBACK_BRIEF', this.get('viewId'), this, this._getExaminationSettings);
    },

    willDestroyElement() {
      this._super(...arguments);
      this.get('co_ContentMessageService').unsubscribeMessage('updateMessage', this.get('currentMenuId'), this, this.updateMessage);
      this.get('co_ContentMessageService').unsubscribeMessage('EXAMINATION_SETTING_CALLBACK_BRIEF', this.get('viewId'), this, this._getExaminationSettings);
    },
    _getExaminationSettings(sResult) {
      if(sResult.isSelectionConfirmCB) {
        return;
      }
      let tagList = null;
      let currentCongifId = null;
      const selectedSetItem = this.get('examinationTagNameSelectedItem');
      if(!isEmpty(selectedSetItem)) {
        currentCongifId = selectedSetItem.workListFindConfigurationId;
      }
      if(sResult.workListFindConfigurationId === currentCongifId) {
        if(sResult.tagList === null && !isEmpty(this.get('examinationTagList'))) {
          tagList = this.get('examinationTagList');
        } else {
          tagList = sResult.tagList;
        }
        this._setExaminationTagList(tagList);
        // this.set('examinationTagNameSelectedItem', null);
        this.set('examinationCategoryTagItems', sResult.examinationCategoryTagItems);
        this.set('examinationUnitTagItems', sResult.examinationUnitTagItems);
        this.set('examinationTagItems', sResult.examinationTagItems);
        if(!isEmpty(sResult.workListFindConfigurationId)){
          //저장된 세트를 선택한 경우
          this._setExaminationComboBox(sResult.workListFindConfigurationId);
        }else{
          this.set('examinationTagNameSelectedItem', null);
          this.set('examinationTagList', tagList);
        }
        if(tagList !== null) {
          if(this.get('examSetRefresh')){
            this._setExaminationComboBox(sResult.workListFindConfigurationId);
          }
          this._selectedSearchCondition(tagList);
        }
        this._getSpecimenList();
      } else {
        this._setExaminationComboBox(currentCongifId);
      }
    },
    updateMessage(){
      this._getSpecimenList();
    },
    // 4. Actions Area
    actions: {
      onSortByHidden(){
        // if(!this.get('originalListItemsSource')){
        //   return;
        // }
        // if(this.get('originalListItemsSource').length < 2 ){
        //   return;
        // }
        // if(this.get('selectedSortByValue') === 'basic'){
        //   this.set('specimenNumberListItemsSource', this.get('originalListItemsSource'));
        // }else if (this.get('selectedSortByValue') === 'tatCode'){
        //   const sortList = this._groupBySort(this.get('originalListItemsSource'), 'tatPercentSearchTypeCode', 'desc');
        //   this.set('specimenNumberListItemsSource', sortList);
        // }else if (this.get('selectedSortByValue') === 'patientName'){
        //   const sortList = this._groupBySort(this.get('originalListItemsSource'), 'patientName', 'asc');
        //   this.set('specimenNumberListItemsSource', sortList);
        //   // this.get('specimenNumberListItemsSource').sortBy('patientName');
        // }
      },
      onSortItemChanged(e) {
        if(isEmpty(e.item)) {
          return;
        }
        const selectedValue = e.item.value;
        if(!this.get('originalListItemsSource')){
          return;
        }
        if(this.get('originalListItemsSource').length < 2 ){
          return;
        }
        if(selectedValue === 'basic'){
          this.set('specimenNumberListItemsSource', this.get('originalListItemsSource'));
        }else if (selectedValue === 'tatCode'){
          const sortList = this._groupBySort(this.get('originalListItemsSource'), 'tatPercentSearchTypeCode', 'desc');
          this.set('specimenNumberListItemsSource', sortList);
        }else if (selectedValue === 'patientName'){
          const sortList = this._groupBySort(this.get('originalListItemsSource'), 'patientName', 'asc');
          this.set('specimenNumberListItemsSource', sortList);
        }

      },
      onFoldClick() {
        this.set('isSubSearchVisible', !this.get('isSubSearchVisible'));
        if(this.get('isSubSearchVisible')) {
          this.set('calcPixcel', 298);
        } else {
          this.set('calcPixcel', 250);
        }
        // this._setPersonalSettingInfo(this.get('searchCondition'));
      },
      onTatPercentCodeChanged() {
        //
      },
      onHpcChanged(e){
        this.set('hpcSelectedValue',e.value);
        this._getSpecimenList();
      },

      onSearchBtnClick(){
        if(this.get('isInit')==false){
          return;
        }
        this._getSpecimenList();
      },

      onSpecimenNumberCommit(){
        this._specimenNumberCommit();
      },

      onCellDoubleClick(item){
        if(isEmpty(item)){
          return;
        }
        this.get('specimenNumberListItemsSource').forEach(e=>{
          set(e, 'onOff', "");
        });
        set(item, 'onOff', "on");
        this.set('specimenNumberListSelectedItem', item);
        if(isEmpty(item)){
          this._specimenNumberCommit();
        }else{
          this._openMenu(item);
        }

        next(this, function () {
          this.$('#specimen-examination-report-work-list_specimenNumber').select();
        }.bind(this));
      },

      // onGridLoad(e){
      //   // this.set('_gridControl', e.source);
      // },

      onSearchPopupOnClick(e){
        this.set('findSettingPopupInfo.isOpen', !this.get('findSettingPopupInfo.isOpen'));
        this.set('findSettingPopupInfo.targetId', e.originalEvent.currentTarget);
      },
      //팝업 콜백 이벤트
      onFindSettingCallBack(sResult){
        let currentCongifId = null;
        const selectedSetItem = this.get('examinationTagNameSelectedItem');
        if(!isEmpty(selectedSetItem)) {
          currentCongifId = selectedSetItem.workListFindConfigurationId;
        }
        if(sResult.workListFindConfigurationId !== currentCongifId && !sResult.isSelectionConfirmCB) {
          this._setExaminationComboBox(currentCongifId);
        } else {
          let tagList = null;
          if(sResult.tagList === null && !isEmpty(this.get('examinationTagList'))) {
            tagList = this.get('examinationTagList');
          } else {
            tagList = sResult.tagList;
          }
          this._setExaminationTagList(tagList);
          // this.set('examinationTagNameSelectedItem', null);
          this.set('examinationCategoryTagItems', sResult.examinationCategoryTagItems);
          this.set('examinationUnitTagItems', sResult.examinationUnitTagItems);
          this.set('examinationTagItems', sResult.examinationTagItems);
          if(!isEmpty(sResult.workListFindConfigurationId)){
            //저장된 세트를 선택한 경우
            this._setExaminationComboBox(sResult.workListFindConfigurationId);
          }else{
            this.set('examinationTagNameSelectedItem', null);
            this.set('examinationTagList', tagList);
          }
          if(tagList !== null) {
            if(this.get('examSetRefresh')){
              this._setExaminationComboBox(sResult.workListFindConfigurationId);
            }
            this._selectedSearchCondition(tagList);
          }
          this._getSpecimenList();
        }
        this.get('co_ContentMessageService').sendMessage('EXAMINATION_SETTING_CALLBACK_OVERVIEW', sResult);
        this.get('co_ContentMessageService').sendMessage('EXAMINATION_SETTING_CALLBACK_LIST', sResult);
      },

      onExamSetChanged(e){
        if(!isEmpty(e)){
          this.set('examinationTagNameSelectedItem',e.selectedItems.get('firstObject'));
        }
        const searchCondition= copy(this.get('searchCondition'));
        this.set('searchCondition', searchCondition);
        set(searchCondition, 'classificationIds', []);
        set(searchCondition, 'unitWorkIds', []);
        set(searchCondition, 'examinationIds', []);
        this._getSpecimenList();
      },

      onExamSetSelectionChanged(e) {
        if(isEmpty(e.selectedItems)) {
          this.set('worklistItemsSource', null);
          this._setExaminationComboBox();
        }
      },
      onGetPatient(item) {
        this.set('searchPatientInfo', item);
        this._getSpecimenList();
      },
      onClearedSearch() {
        this.set('searchPatientId', null);
        this.set('searchPatientInfo', null);
        this._getSpecimenList();

      },
      onCommitSearch(result) {
        if (!isEmpty(result.selectedItem)) {
          this.set('searchPatientId', result.selectedItem.patientId);
        }
      },
    },

    // 5. Private methods Area
    _selectedSearchCondition(returnedTagList){
      // const examinationTagList= this.get('examinationTagList');
      const searchCondition= this.get('searchCondition');
      set(searchCondition, 'classificationIds', null);
      set(searchCondition, 'unitWorkIds', null);
      set(searchCondition, 'examinationIds', null);
      returnedTagList.forEach(e=>{
        if(e.type=='category' && !isEmpty(e.items)){
          set(searchCondition, 'classificationIds', e.items.map(function(item){
            return item.id;
          }));
        }else if(e.type=='unit' && !isEmpty(e.items)){
          set(searchCondition, 'unitWorkIds', e.items.map(function(item){
            return item.id;
          }));
        }else if(e.type=='exam' && !isEmpty(e.items)){
          set(searchCondition, 'examinationIds', e.items.map(function(item){
            return item.id;
          }));
        }
      });
    },
    _init(){
      const worklistConfigurations= this.get('worklistConfigurations');
      const examTypeItemsSource= this.get('examTypeItemsSource');

      examTypeItemsSource.forEach(e=>{
        if(worklistConfigurations.classificationIds.includes(e.classificationId)){
          set(e, 'selected', true);
        }
      });
      this._setComboboxData( examTypeItemsSource,'classificationIds');
      // this._getProcessCategory();
    },
    _setExaminationTagList(getTagList){
      // const newTagList = [];
      const examinationTagNameSelectedItem = this.get('examinationTagNameSelectedItem');

      //Tag Setting을 파라미터(getTagList)로 받아오면 그걸로 셋팅해주고 아니면 콤보박스에 지정된 Tag를 셋팅.
      if (getTagList !== null){
        this.set('examinationTagList', getTagList);
      //C-ComboBox 변경으로 인하여 selectedItems가 null로 바꿀때도 호출이 되고 있음. - null check 추가.
      } else if (examinationTagNameSelectedItem !== null){
        let examinationCategoryTagItems = [];
        if(!isEmpty(examinationTagNameSelectedItem.property.classifications)) {
          examinationCategoryTagItems = examinationTagNameSelectedItem.property.classifications;
        }
        let examinationUnitTagItems = [];
        if(!isEmpty(examinationTagNameSelectedItem.property.unitWorks)) {
          examinationUnitTagItems = examinationTagNameSelectedItem.property.unitWorks;
        }
        let examinationTagItems = [];
        if(!isEmpty(examinationTagNameSelectedItem.property.observationExaminations)) {
          examinationTagItems = examinationTagNameSelectedItem.property.observationExaminations;
        }
        const searchCondition= this.get('searchCondition');
        set(searchCondition, 'classificationIds', examinationCategoryTagItems.map(function(item){
          return item.id;
        }));
        set(searchCondition, 'unitWorkIds', examinationUnitTagItems.map(function(item){
          return item.id;
        }));
        set(searchCondition, 'examinationIds', examinationTagItems.map(function(item){
          return item.id;
        }));
      }

      //WorkList에서 조각UI로 열릴시에 변경값 탭으로 전달하는 콜백 이벤트
      // this._callBackViewSettingCB('1');
    },
    _setExaminationComboBox(workListFindConfigurationId){
      this.getList(this.get('defaultUrl') + 'worklist-configurations/search',
        {staffId: this.get('co_CurrentUserService.user.employeeId')}, null).then(function(res){
        this.set('examinationTagNameItemsSource', res);
        if(!isEmpty(res)){
          const filterdExaminationTagList=[];
          res.forEach(e=>{
            if(e.workListFindConfigurationId===workListFindConfigurationId){
              this.set('examinationTagNameSelectedItem', e);
            }
            //검사분류, 작업단위, 검사항목별로 나눠서 저장해둠
            filterdExaminationTagList.addObject(this._filterExaminationTagList(
              e.workListFindConfigurationId,
              e.property.classifications, e.property.unitWorks, e.property.observationExaminations));
          });
          this.set('filterdExaminationTagList', filterdExaminationTagList);
        }
      }.bind(this)).catch(function(e){
        this._catchError(e);
      }.bind(this));
    },

    _filterExaminationTagList(workListFindConfigurationId, examinationCategoryTagItems,examinationUnitTagItems,examinationTagItems){
      const filterdExaminationTagList= [];
      filterdExaminationTagList.workListFindConfigurationId=workListFindConfigurationId;
      if(!isEmpty(examinationCategoryTagItems)){
        examinationCategoryTagItems.forEach(element => {
          filterdExaminationTagList.push({
            id: element.id,
            name: element.name,
            abbreviation: element.abbreviation,
            type: 'category'
          });
        });
      }
      if(!isEmpty(examinationUnitTagItems)){
        examinationUnitTagItems.forEach(element => {
          filterdExaminationTagList.push({
            id: element.id,
            name: element.name,
            abbreviation: element.name,
            type: 'unit'
          });
        });
      }
      if(!isEmpty(examinationTagItems)){
        examinationTagItems.forEach(element => {
          filterdExaminationTagList.push({
            id: element.id,
            name: element.name,
            abbreviation: element.abbreviation,
            type: 'unit'
          });
        });
      }
      return filterdExaminationTagList;
    },

    _openMenu(selectedItem){
      this.get('specimenCheckInService').getDisplayView(selectedItem.specimenNumber, null).then(function(res){
        if(isEmpty(res)){
          // this.get('specimencheckinService')._showMessage('No Display View', 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        const globalItem = {
          patientChoicePath: 'Encounter',
          patientId: selectedItem.subjectId,
          encounterId: selectedItem.specimenOrders.get('firstObject.encounterId'),
          examination:{
            state: selectedItem.progressStatusCode,
            specimenId: selectedItem.specimenId,
          },
          patientSelectionSource: {
            viewId: 'specimen-examination-report-work-list'
          }
        };
        const m = A();
        const parameters ={};
        // let promise= null;
        res.forEach( e => {
          m.addObject({
            displayCode: e.viewId,
            stateType: null,
            parameters: {
              specimenNumber:selectedItem.specimenNumber,
              examinationCode: isEmpty(selectedItem.observation)? null : selectedItem.observation.get('firstObject.examinationCode')}
          });
        });

        if(isEmpty(selectedItem.observation)){
          this.getList(this.get('defaultUrl') + 'observations/results', {
            checkInId:null,
            specimenNumber: selectedItem.specimenNumber
          }, null, false).then(function(result){
            parameters.examinationCode= result.get('firstObject.examination.displayCode');
            this.getList(this.get('defaultUrl') + 'result-worklists/requests/current-encounter', {procedureRequestId: selectedItem.specimenOrders.get('firstObject.basedOn.id')}, null, false).then(function(response) {
              this.set('specimenNumber', null);
              if(!isEmpty(response) && !isEmpty(response.encounterId)){
                globalItem.encounterId = response.encounterId;
              }
              this.get('co_PatientManagerService').selectPatient(globalItem, m);
            }.bind(this)).catch(function(e) {
              this._catchError(e);
              this.get('co_PatientManagerService').selectPatient(globalItem, m);
            }.bind(this));
          }.bind(this)).catch(function(e){
            this._catchError(e);
          }.bind(this));
        }else{
          this.getList(this.get('defaultUrl') + 'result-worklists/requests/current-encounter', {procedureRequestId: selectedItem.specimenOrders.get('firstObject.basedOn.id')}, null, false).then(function(result) {
            this.set('specimenNumber', null);
            if(!isEmpty(result.encounterId)){
              globalItem.encounterId = result.encounterId;
            }
            this.get('co_PatientManagerService').selectPatient(globalItem, m);
          }.bind(this)).catch(function() {
            this.get('co_PatientManagerService').selectPatient(globalItem, m);
          }.bind(this));
        }
      }.bind(this)).catch(function(e){
        this._catchError(e);
      }.bind(this));
    },

    _getSpecimenList(){
      // scheduleOnce('afterRender', () => {
      //   this.$('.scrollbar-macosx').scrollbar();
      // });
      const searchCondition= copy(this.get('searchCondition'));
      if(isEmpty(searchCondition)){
        return;
      }
      const examinationTagNameSelectedItem= this.get('examinationTagNameSelectedItem');
      const examinationCategoryTagItems = isEmpty(examinationTagNameSelectedItem) ? this.get('examinationCategoryTagItems') : examinationTagNameSelectedItem.property.classifications;
      const examinationUnitTagItems = isEmpty(examinationTagNameSelectedItem) ? this.get('examinationUnitTagItems') : examinationTagNameSelectedItem.property.unitWorks;
      const examinationTagItems = isEmpty(examinationTagNameSelectedItem) ? this.get('examinationTagItems') : examinationTagNameSelectedItem.property.observationExaminations;
      if(!isEmpty(examinationCategoryTagItems)){
        set(searchCondition, 'classificationIds', examinationCategoryTagItems.map(function(item){
          return item.id;
        }));
      }
      if(!isEmpty(examinationUnitTagItems)){
        set(searchCondition, 'unitWorkIds', examinationUnitTagItems.map(function(item){
          return item.id;
        }));
      }
      if(!isEmpty(examinationTagItems)){
        set(searchCondition, 'examinationIds', examinationTagItems.map(function(item){
          return item.id;
        }));
      }
      searchCondition.checkInFromDate= new Date(searchCondition.checkInFromDate.getFullYear(), searchCondition.checkInFromDate.getMonth(), searchCondition.checkInFromDate.getDate(), 0, 0, 0);
      searchCondition.checkInToDate= new Date(searchCondition.checkInToDate.getFullYear(), searchCondition.checkInToDate.getMonth(), searchCondition.checkInToDate.getDate(), 0, 0, 0);
      if(searchCondition.tatSearchTypecode==="0"){
        searchCondition.tatSearchTimeMinute=null;
      }
      if(isEmpty(searchCondition.classificationIds)){
        searchCondition.classificationIds= [];
      }
      if(searchCondition.unitWorkIds==""){
        searchCondition.unitWorkIds=null;
      }
      searchCondition.subjectNumber = this.get('searchPatientInfo.displayId');
      searchCondition.subjectTypeCode = 'Patient';
      searchCondition.hpcSearchTypeCode= this.get('hpcSelectedValue')=='All'? null: this.get('hpcSelectedValue');
      this.set('isInit', false);
      this.set('isLoaderShow', true);
      return this.getList(this.get('defaultUrl') + 'result-worklists/search', null, searchCondition, false).then(res => {
        this.get('co_PersonalizationService').setSettingInfo(`specimen-examination-report-work-list`, JSON.stringify({
          conditionData:[searchCondition, this.get('examinationTagNameSelectedItem')],
          hpcSearchTypeCode: this.get('hpcSelectedValue')
        }), '진단검사 Brif View 설정 저장');
        if(!isEmpty(res)){
          res.forEach(e=>{
            // const specimenOrder= e.get('specimenOrders.firstObject');
            let isNeedConsent = false;
            let isNeedRequest = false;
            e.get('specimenOrders').forEach(order=>{
              if(order.isNeedConsent){
                isNeedConsent= true;
              }
              if(order.isNeedRequest){
                isNeedRequest= true;
              }
            });
            set(e, 'tooltip', e.subject.name + '(' + e.subject.number + '/' + e.subject.gender + '/'+e.subject.age +')');
            set(e, 'iconDisplay', this._setIconDisplay(e.progressType.code, isNeedConsent, isNeedRequest, e.subject.isInfection, e.prescriptionTypeCode));
            set(e, 'pointTooltip', this._setIconDisplayTooltip(e.progressType.code, isNeedConsent, isNeedRequest, e.subject.isInfection, e.prescriptionTypeCode));
            if(e.subject.isPrivacyProtection || e.subject.isProtectionHealthInfo) {
              set(e, 'isShowIconProtect', true);
            }
            let patientName = null;
            if(isPresent(e.subject)) {
              patientName = e.subject.name;
            }
            set(e, 'patientName', patientName);
          });
        }
        // this.set('selectedSortByValue', 'basic');
        // this.set('specimenNumberListItemsSource', res);
        this.set('originalListItemsSource', res);
        const selectedValue = this.get('selectedSortByValue');
        if(selectedValue === 'basic'){
          this.set('specimenNumberListItemsSource', this.get('originalListItemsSource'));
        }else if (selectedValue === 'tatCode'){
          const sortList = this._groupBySort(this.get('originalListItemsSource'), 'tatPercentSearchTypeCode', 'desc');
          this.set('specimenNumberListItemsSource', sortList);
        }else if (selectedValue === 'patientName'){
          const sortList = this._groupBySort(this.get('originalListItemsSource'), 'patientName', 'asc');
          this.set('specimenNumberListItemsSource', sortList);
        }
        this.set('isInit', true);
        this.set('isLoaderShow', false);
      }).catch(function(e){
        this._catchError(e);
        this.set('isInit', true);
      }.bind(this));
    },
    _setIconDisplay(progressTypeCode,isNeedConsent, isNeedRequest, isInfection, prescriptionTypeCode){
      //아이콘 표기 우선순위: progressTypeCode"D","F" > isInfection > isAllergy > isNeedConsent > isNeedRequest
      let res = null;
      if(isInfection){
        res = 'isInfection';
      }else if(progressTypeCode === "F"){
        res = 'F';
      }else if(progressTypeCode === "D"){
        res = 'D';
      }else if(isNeedConsent){
        res = 'isNeedConsent';
      }else if(isNeedRequest){
        res = 'isNeedRequest';
      }else if(prescriptionTypeCode == '6'){
        res = 'isDischarge';
      }
      return res;
    },

    _setIconDisplayTooltip(progressTypeCode,isNeedConsent, isNeedRequest, isInfection, prescriptionTypeCode){
      let res=[];
      if(isInfection){
        res.addObject(this.getLanguageResource('581', 'S', 'Infection Precaution') + '<br>');
      }
      if( progressTypeCode === "F"){
        res.addObject(this.getLanguageResource('5725', 'F', '응급')+ '<br>');
      }
      if(progressTypeCode === "D" ){
        res.addObject(this.getLanguageResource('1880', 'F', '당일')+ '<br>');
      }
      // if(isAllergy){
      //   res.addObject(this.getLanguageResource('4682', 'F', 'Allergy') + '<br>');
      // }
      if(isNeedConsent){
        res.addObject(this.getLanguageResource('11740', 'S', '동의서 필요') + '<br>');
      }
      if(isNeedRequest){
        res.addObject(this.getLanguageResource('17066', 'S', '의뢰서 필요') + '<br>');
      }
      if(prescriptionTypeCode == '6'){
        res.addObject(this.getLanguageResource('11988', 'S', '퇴원오더') + '<br>');
      }

      if(res.length > 1){
        res=res.join('').toString();
      }else{
        res=[];
      }
      return res;
    },
    _specimenNumberCommit(){
      // this.get('_gridControl').deselectAll();
      let selectedItem= this.get('specimenNumberListSelectedItem');

      const params={
        queryOption : "1",
        specimenNumber : isEmpty(this.get('specimenNumber'))? null: this.get('specimenNumber').trim(),
      };

      this.getList(this.get('defaultUrl') + 'result-worklists/search', null, params, false).then(res=>{
        if(isEmpty(res)){
          this.get('specimenexaminationreportService').onShowToast('error', this.getLanguageResource('9264', 'F', '조회된 정보가 없습니다'), '');
          return;
        }
        this.get('co_PersonalizationService').setSettingInfo(`specimen-examination-report-work-list`, JSON.stringify({
          conditionData:[params, this.get('examinationTagNameSelectedItem')],
          hpcSearchTypeCode: this.get('hpcSelectedValue')
        }), '진단검사 Brif View  설정 저장');
        selectedItem= res;

        this._openMenu(selectedItem.get('firstObject'));
      }).catch(function(e){
        this._catchError(e);
      }.bind(this));

      next(this, function () {
        // this.set('specimenNumber', null);
        this.$('#specimen-examination-report-work-list_specimenNumber').select();
      }.bind(this));
    },
    groupBy(list, keyGetter) {
      const map = new Map();
      list.forEach((item) => {
        const key = keyGetter(item);
        const collection = map.get(key);
        if (!collection) {
          map.set(key, [item]);
        } else {
          collection.push(item);
        }
      });
      return map;
    },
    _groupBySort(list, prop, type) {
      const grouped = this.groupBy(list, item => item[prop]);
      const uniqList = list.uniqBy(prop);
      const groupKeyList = [];
      const sortList = [];
      uniqList.forEach((item) => {
        const groupItems = grouped.get(item[prop]);
        groupKeyList.push({key: groupItems[0][prop], value: groupItems});
      });
      if(type === 'desc') {
        groupKeyList.sort(function(a, b) {
          if (a.key > b.key) {
            return -1;
          }
          if (a.key < b.key) {
            return 1;
          }
          return 0;
        });
      } else if(type === 'asc') {
        groupKeyList.sort(function(a, b) {
          if (a.key > b.key) {
            return 1;
          }
          if (a.key < b.key) {
            return -1;
          }
          return 0;
        });

      }
      groupKeyList.forEach(group => {
        group.value.map(item => {
          sortList.push(item);
        });
      });
      return sortList;
    },
    _catchError(e){
      this.set('isLoaderShow',false);
      this.showResponseMessage(e);
    }


  });