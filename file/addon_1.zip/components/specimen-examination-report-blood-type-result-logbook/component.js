import { A } from '@ember/array';
import { Promise } from 'rsvp';
import EmberObject, { set } from '@ember/object';
import { isEmpty } from '@ember/utils';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'specimenexaminationreport-module/app-config';
import specimenExaminationREportPrintMixin from 'specimenexaminationreport-module/mixins/specimen-examination-report-print-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  specimenExaminationREportPrintMixin,
  /* Only For Server-Call Component
  CHIS.FR.CrossCutting.ServerCallMixin,
  */
  {
  /* 1. Service define Area
  testService:Ember.inject.service(),
  */
    specimenexaminationreportService: service('specimen-examination-report-service'),
    layout,
    // 2. Property Area
    defaultUrl: null,
    searchCondition: null,
    bloodTypeGridColumns: null,
    bloodTypeGridItemsSource: null,
    printPopup:null,
    printConfig:null,
    printContent:null,
    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      //this.set('menuClass', 'w1000');
      this.set('viewId','specimen-examination-report-blood-type-result-logbook');
      //Set Stateful properties
      this.setStateProperties([
        'defaultUrl',
        'searchCondition',
        'bloodTypeGridColumns',
        'bloodTypeGridItemsSource',
        'selectedItem'
      ]);
      if (this.hasState() === false) {
      //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')
      +`specimen-examination-report/${config.version}/`);
        // const today= this.get('co_CommonService').getNow();
        this.set('searchCondition',{
          // checkInFromDate:today,
          // checkInStartNumber: null,
          // checkInEndNumber: null,
        });
        this.set('selectedDate', this.get('co_CommonService').getNow());
        this.set('bloodTypeGridColumns', [
          { title: this.getLanguageResource('6767', 'S','Check-in No.'), field: 'checkInNumber', width: 80, readOnly: true,align: 'center'},
          { title: this.getLanguageResource('859', 'S','Specimen No.'), field: 'specimenNumber', width: 90, readOnly: true,align: 'center' },
          { title: this.getLanguageResource('16881', 'S','Pt Name'), field: 'subject.name', bodyTemplateName: 'boldTooltip',align: 'center', width: 90, readOnly: true},
          { title: this.getLanguageResource('8451', 'S','MRN'), field: 'subject.number', bodyTemplateName: 'bold',align: 'center',width: 65, readOnly: true},
          { title: this.getLanguageResource('3680', 'S','Sex'), field: 'subject.gender',align: 'center', width: 35, readOnly: true },
          { title: this.getLanguageResource('1662', 'S','Age'), field: 'subject.age', align: 'center', width: 45, readOnly: true },
          { title: this.getLanguageResource('11947', 'S','1차결과'), field: 'displayResult',align: 'center', bodyTemplateName: 'detailview', readOnly: true},
          { title: this.getLanguageResource('11948', 'S','2차결과'), field: 'finaldisplayResult',align: 'center', bodyTemplateName: 'finalDetailview', readOnly: true},
          { title: this.getLanguageResource('11949', 'S', '1차 입력자'), field: 'issuedStaff.name', bodyTemplateName: 'tooltip',align: 'center',width: 95, readOnly: true},
          { title: this.getLanguageResource('11950', 'S', '2차 입력자'), field: 'finalIssuedStaff.name', bodyTemplateName: 'tooltip',align: 'center',width: 100, readOnly: true},
          { title: this.getLanguageResource('3452', 'S','Status'), field: 'progressStatus.name', align: 'center',width: 90, bodyTemplateName: 'tooltip', readOnly: true},
          { title: this.getLanguageResource('8827', 'S', '발행처'), field: 'issuedDepartment.name', width: 90, bodyTemplateName: 'tooltip',readOnly: true,align: 'center'},
          { title: this.getLanguageResource('14751', 'S', '현위치'), field: 'occupyingBed', width: 110, bodyTemplateName: 'occupyingBedTooltip',readOnly: true,align: 'center'},
          { title: this.getLanguageResource('1113', 'S','진료과'), field: 'department.name', width: 90, bodyTemplateName: 'tooltip',readOnly: true,align: 'center'},
        ]);
        this._getbloodTypeGridItemsSource();
      }
    //Initialize Stateless properties
    },

    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1360');
    },
    // 4. Actions Area
    actions: {
      onGridLoad(e){
        this.set('_gridControl', e.source);
      },

      onSearchAction(){
        this._getbloodTypeGridItemsSource().then(function(res){
          if(!isEmpty(res)){
            res.forEach(e=>{
              set(e, 'aboDisplayResult', isEmpty(e.aboDisplayResult)? '': e.aboDisplayResult);
              set(e, 'displayResult', isEmpty(e.rhDisplayResult)? e.aboDisplayResult : e.aboDisplayResult + e.rhDisplayResult);
              set(e, 'finalAboDisplayResult', isEmpty(e.finalAboDisplayResult)? '' : e.finalAboDisplayResult);
              set(e, 'finaldisplayResult', isEmpty(e.finalRhDisplayResult)? e.finalAboDisplayResult : e.finalAboDisplayResult+ e.finalRhDisplayResult);
            });
          }
          this.set('bloodTypeGridItemsSource', res);
        }.bind(this));
      },
      onPrintClick(){
        const selectedItems= this.get('_gridControl.selectedItems');
        if(isEmpty(selectedItems)){
          this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9260', 'F', 'Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        const bloodTypeResultLookbook = [];
        selectedItems.forEach(e=>{
          bloodTypeResultLookbook.addObject({
            "checkInNumber" : e.checkInNumber,
            "subjectNumber" : e.get('subject.number'),
            "subjectName" : e.get('subject.name'),
            "subjectGender" : e.get('subject.gender'),
            "displayResult" : e.displayResult,
            "issuedStaff" : e.get('issuedStaff.name'),
            "finaldisplayResult" : e.finaldisplayResult,
            "finalIssuedStaff" : e.get('finalIssuedStaff.name'),
            "specimenNumber" : e.specimenNumber,
            "issuedDepartmentName" : e.get('issuedDepartment.name'),
            "departmentName" : e.get('department.name'),
            "isFinal" : e.get('progressStatus.code') =='Final' ? 'Y':'N',
          });
        });

        this.set('printPopup',true);
        const printConfig=
        {
          'printType': 2,
          'printName': 'BloodTypeResultLookbook',
        };
        this.set('printConfig',printConfig);
        this.set('printContent',{
          dataField :{
            "bloodTypeResultLookbook": bloodTypeResultLookbook,
          },
          parameterField :{
            "checkInDate" : this.get('searchCondition').checkInFromDate.toFormatString(true, false),
          }
        });
      },
      onDetailClick(item, col, e){
        this.set('detailPopupTarget', e.currentTarget);
        if(!isEmpty(item)){
          if(col.field=='displayResult'){
            if(item.aboRecordNoteId !== null){
              set(item, 'isDetailOpen', false);
              this.set('isSpecimenExamDetailOpen', true);
              this.set('detailView', EmberObject.create({
                // title: item.examination.abbreviation,
                title: this.getLanguageResource('890', 'S', '결과'),
                recordNoteId: item.aboRecordNoteId,
              }));
            }
          }
          if(col.field=='finaldisplayResult'){
            if(item.finalAboRecordNoteId !== null){
              set(item, 'isPrevDetailOpen', false);
              this.set('isSpecimenExamDetailOpen', true);
              this.set('detailView', EmberObject.create({
                title: this.getLanguageResource('13258', 'F','', '확인 결과'),
                recordNoteId: item.finalAboRecordNoteId,
              }));
            }
          }
        }
      },
      onDetailViewClosed(){
        set(this.get('detailView'), 'title', null);
        set(this.get('detailView'), 'recordNoteId', null);
      },
      onExcelPrintAction() {
        const columns = this.get('bloodTypeGridColumns');
        const itemsSource = this.get('bloodTypeGridItemsSource');
        if(isEmpty(itemsSource)){
          this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9264', 'F', '조회된 정보가 없습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        const gridSource=this.get('_gridControl');
        const reason = 'Excel export blood type lookbook';
        const headers=[];
        const fields=[];

        columns.forEach(function(item, index){
          headers.addObject({ left: index, top: 0, right: index, bottom: 0, value: item.title });
          item.type == 'date'? fields.addObject({ width: 140, value: item.field }) : fields.addObject({ width: item.width, value: item.field });
        });
        gridSource.exportToExcel('blood_type_lookbook.xlsx', headers, fields, this, 'onExcelPrintAction', reason , itemsSource);
      },
    },
    // 5. Private methods Area
    _getbloodTypeGridItemsSource(){
      this.set('isGridShow', true);
      const searchCondition= this.get('searchCondition');
      const selectedDate= this.get('selectedDate');
      const checkInFromDate=new Date(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate(), 0, 0, 0);
      set(searchCondition, 'checkInFromDate', checkInFromDate);
      set(searchCondition, 'checkInToDate', checkInFromDate);
      return this.getList(this.get('defaultUrl')+'observations/results/blood-types/search', searchCondition, null, true).then(function(res){
        this.set('isGridShow', false);
        if(res){
          const promise = new Promise((resolve)=>{
            if(res.response.length ){
              resolve(A(res.response));
              res.response.forEach(e=>{
                if(!isEmpty(e.ward)){
                  let occupyingBed= isEmpty(e.ward.displayCode)? '' : e.ward.displayCode;
                  occupyingBed= isEmpty(e.room.roomCode)? occupyingBed : occupyingBed + '/' + e.room.roomCode;
                  occupyingBed= isEmpty(e.bed.displayCode)? occupyingBed : occupyingBed + '/' + e.bed.displayCode;
                  set(e, 'occupyingBed', occupyingBed);
                  let occupyingBedTooltip= isEmpty(e.ward.name)? '' : e.ward.name;
                  occupyingBedTooltip= isEmpty(e.room.roomName)? occupyingBedTooltip : occupyingBedTooltip + '/' + e.room.roomName;
                  occupyingBedTooltip= isEmpty(e.bed.name)? occupyingBedTooltip : occupyingBedTooltip + '/' + e.bed.name;
                  set(e, 'occupyingBedTooltip', occupyingBedTooltip);
                }else{
                  set(e, 'occupyingBed', '');
                  set(e, 'occupyingBedTooltip', '');
                }
              });
            } else{
              resolve(A([]));
            }
          });
          return promise;
        }
      }.bind(this)).catch(function() {
        this.set('isGridShow', false);
      }.bind(this));
    }
  });