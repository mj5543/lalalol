import { isEmpty } from '@ember/utils';
import EmberObject, { set } from '@ember/object';
import $ from 'jquery';
// import { hash } from 'rsvp';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from '../../../app-config';

import MessageMixin from '../../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MessageMixin,
  /* Only For Server-Call Component
  CHIS.FR.CrossCutting.ServerCallMixin,
  */
  {
  /* 1. Service define Area
  testService:Ember.inject.service(),
  */
    layout,
    specimenexaminationreportService: service('specimen-examination-report-service'),

    // 2. Property Area
    defaultUrl: null,
    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      //this.set('menuClass', 'w1000');
      this.set('viewId','specimen-examination-report-result-entry-negative');
      //Set Stateful properties
      this.setStateProperties([
        'defaultUrl',
      ]);
      if (this.hasState() === false) {
      //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')
      + `specimen-examination-report/${config.version}/`);

      }
    //Initialize Stateless properties
    },

    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      // if (this.hasState() === false) {
      // }
    },
    // 4. Actions Area
    actions: {
      onOpenedAction(){
        this.set('showLoader', true);
        this.get('specimenexaminationreportService').getNegativeCodeableConcept(this.get('classificationCode')).then(res=>{
          this._init();
          this.set('radiobuttonlistItemsSource', res);
          $('#commentsValue').on('input', this._commentTextChanged.bind(this));
          this.set('showLoader', false);
        }).catch(function(error){
          this._catchError(error);
        }.bind(this));
      },

      onCommentKeyDown(e) {
        const type = this.get('specimenexaminationreportService').getKeyBoardEventType(e.originalEvent);
        // const type = this._getKeyBoardEventType(e.originalEvent);

        if(type === 'esc') {
          this.set('isNegativeEntryOpen', false);
        }
      },
      onTextCleared(){
        const currentItem= this.get('currentItem');
        const fullTextValue=this._getSelectedItemName();
        this.set('fullTextValue', fullTextValue);
        set(currentItem, 'fullTextValue', fullTextValue);
        // set(currentItem, 'isValueChanged', true);
      },
      onRadiobuttonlistChanged(e){
        if(isEmpty(e.item)){
          //선택 해제한 경우
          this.set('fullTextValue', this.get('commentsValue'));
          return;
        }
        this._commentTextChanged(e);
      },
      onDoubleClickAction(){
        // this._returnCB();
        // this.set('isNegativeEntryOpen', false);
      },
      onConfirmedAction(){
        this._returnCB();
        this.set('isNegativeEntryOpen', false);
      },
      onClearClick(){
        this.set('commentsValue', null);
        this.set('selectedExample', null);
        this.set('fullTextValue', null);
      },
    },
    // 5. Private methods Area
    _init(){
      this.set('commentsValue', null);
      this.set('selectedExample', null);
      this.set('fullTextValue', null);
    },
    _commentTextChanged(e){
      // this._commentsValueChanged(e);
      const commentsValue= isEmpty(this.get('commentsValue'))? '' : this.get('commentsValue');
      let fullTextValue = this.get('fullTextValue');
      const selectedExampleName= isEmpty(this.get('selectedExample'))? '' : this.get('selectedExample').name;
      fullTextValue= isEmpty(e.target)? commentsValue : e.target.value ;
      fullTextValue= selectedExampleName +' '+ fullTextValue;
      this.set('fullTextValue', fullTextValue);
    },

    _returnCB(){
      //Negative 처리 입력값 리턴
      const returnNegativeCB = this.get('returnNegativeCB');
      if(!isEmpty(returnNegativeCB)) {
        const obj= {
          valueValueString: this.get('fullTextValue'),
          value: {
            quantity: {"value":null},
            codeableConcept: {
              coding: [
                {
                  system: null,version: null,
                  code: this.get('selectedExample.code'),
                  displayName: this.get('selectedExample.name')
                }
              ],
              displayContent: this.get('selectedExample.name')
            },
            valueDecimal: 0,
            valueString: this.get('commentsValue'),
            valueBool: true,
          },
        };
        returnNegativeCB($.extend(true, EmberObject.create(), obj));
        $('#commentsValue').off('input', this._commentTextChanged.bind(this));
        this._init();
      }
    },
    _commentsValueChangedList(e){
      const currentItem= this.get('currentItem');
      set(currentItem, 'isCleared', false);
      let commentsValue= this.get('commentsValue');
      let fullTextValue = this.get('fullTextValue');
      if(isEmpty(commentsValue)){
        commentsValue='';
      }
      let selectedExampleTemp= currentItem.selectedExamples;
      if(e.checked==false && isEmpty(selectedExampleTemp)){
        // if(Ember.isEmpty(selectedExampleTemp)){
        //선택항목 없음
        fullTextValue = !isEmpty(e.target) ? e.target.value : commentsValue;
        this.set('fullTextValue', fullTextValue);
        set(currentItem, 'fullTextValue', fullTextValue);
        // }
        return;
      }
      // const displayName= currentItem.get('value.codeableConcept.coding.firstObject.displayName');
      const displayName= this._getSelectedItemName();
      if(!isEmpty(selectedExampleTemp)){
        //새로 선택한 라디오버튼 선택값(e.item)
        selectedExampleTemp=currentItem.selectedExamples.map(function(i){
          return i.displayName;
        });
        selectedExampleTemp=selectedExampleTemp.join(', ');
        fullTextValue= !isEmpty(e.target)? e.target.value: commentsValue;
        fullTextValue= selectedExampleTemp +' '+ fullTextValue;
        this.set('fullTextValue', fullTextValue);
        set(currentItem, 'fullTextValue', fullTextValue);
        return;
      }else if(!isEmpty(displayName)
        && isEmpty(selectedExampleTemp) && this.get('updatedComment')!=true){
        //기존 저장값만 있는 경우
        selectedExampleTemp=displayName;
        this.set('updatedComment', true);
        fullTextValue= !isEmpty(e.target)? e.target.value: commentsValue;
        fullTextValue= selectedExampleTemp +' '+ fullTextValue;
        this.set('fullTextValue', fullTextValue);
        set(currentItem, 'fullTextValue', fullTextValue);
        return;
      }else if(currentItem.selectedExample ===null){
        //clear된상태
        selectedExampleTemp='';
      }else if(isEmpty(displayName)){
        //comment만 있는 경우
        selectedExampleTemp='';
      }else if(!isEmpty(displayName)){
        // selectedExampleTemp=currentItem.value.codeableConcept.displayContent;
        selectedExampleTemp=displayName;
      }

      fullTextValue= isEmpty(selectedExampleTemp)? e.target.value : selectedExampleTemp+ ' ' + e.target.value ;
      this.set('fullTextValue', fullTextValue);
      set(currentItem, 'fullTextValue', fullTextValue);
    },
    _getSelectedItemName(){
      const currentItem= this.get('currentItem');
      let displayName='';
      // let displayName = currentItem.get('value.codeableConcept.coding.firstObject.displayName');
      const tmp=[];
      const arr=[];
      if(this.get('isMultiCodeableConcept') ){
        this.get('codeableConceptItems').forEach(function(i){
          if(i.selected==true){
            arr.addObject(i);
            tmp.addObject(i.displayName);
          }
        });
        set(currentItem, 'selectedExamples', arr);
        displayName=tmp.join(', ');
      }else if(!this.get('isMultiCodeableConcept')){
        // displayName= displayName;
        displayName=this.get('selectedExample.displayName');
        set(currentItem, 'selectedExample', this.get('selectedExample'));
      }else{
        displayName='';
      }

      return displayName;
    },

    _catchError(e){
      this.set('showLoader',false);
      this.showResponseMessage(e);
    }
  });