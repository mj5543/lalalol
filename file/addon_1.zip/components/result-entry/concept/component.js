/* eslint-disable max-lines */
/* eslint-disable complexity */
import { copy } from '@ember/object/internals';
import { next } from '@ember/runloop';
import $ from 'jquery';
import { isEmpty, isPresent } from '@ember/utils';
import EmberObject, { get, set } from '@ember/object';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from '../../../app-config';
import MessageMixin from '../../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MessageMixin,
  {
    layout,
    specimenexaminationreportService: service('specimen-examination-report-service'),
    // 2. Property Area
    defaultUrl: null,
    selectedExample: null,
    fullTextValue: null,
    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-result-entry-concept');
      //Set Stateful properties
      this.setStateProperties([
        'menuClass',
      ]);
      if (this.hasState() === false) {
        //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')
        + `specimen-examination-report/${config.version}/`);
        this.set('fullTextValue', null);
        this.set('updatedComment', false);
      }
      // $(function() {
      //   $('#coderableConceptEntrypopUp').focus();
      // });
      //Initialize Stateless properties
    },

    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1000');
    },

    // keyDown(e){
    //   console.log('keyDown     ' + e);

    //   this.onPopUpKeyDown();
    // },
    // 4. Actions Area
    actions: {
      onOpenedAction(e){
        this._init();
        this.set('popup', e.source);
        this.set('functionApplyCode', null);
        const currentItem= EmberObject.create(this.get('currentItem'));
        const defaultUrl= this.get('defaultUrl');
        set(currentItem, 'selectedExamples',[]);
        set(currentItem, 'selectedExample', null);
        set(currentItem, 'fullTextValue', null);
        if(!isEmpty(currentItem.value.codeableConcept)){
          this.set('initialDisplayName', currentItem.value.codeableConcept.displayContent);
        }
        const selectedExamplesTemp= [];
        this.set('isCodeableConceptShow',true);
        this.getList(defaultUrl + 'observations/examples', {exampleTypeCode: 'ExampleValue', examinationId: this.get('currentItem.examinationId')}, null).then(exampleValue=>{
          this.set('isCodeableConceptShow', false);
          if(isEmpty(exampleValue)){
            //등록한 예문 없는 경우
            this.set('isMultiCodeableConcept', false);
            this.set('hasExamples', false);
            this.getList(defaultUrl + 'business-codes/search', {classificationCode: 'CodeableConcept'}, null).then(function(res){
              this.set('codeableConceptItems', this._setCodeableConceptItemsDefault(res, currentItem, selectedExamplesTemp));
            }.bind(this)).catch(function(error){
              this._catchError(error);
            }.bind(this));
          }else{
            //등록한 예문 존재
            this.set('hasExamples', true);
            this.set('codeableConceptItems', this._setCodeableConceptItems(exampleValue, currentItem, selectedExamplesTemp));
            this.set('selectedExamplesTemp', selectedExamplesTemp);
          }
          set(currentItem, 'fullTextValue', currentItem.get('valueValueString'));
          if(this.get('subMode') === 'results-by-item') {
            this.set('fullTextValue', currentItem.get('valueValueString'));
            this.set('commentsValue', currentItem.get('value.valueString'));
          } else {
            this.set('commentsValue', null);
          }
          $('#commentsValue').on('input', this._commentTextChanged.bind(this));

          $('#coderableConceptEntrypopUp').on('keydown', this._onPopUpKeyDown.bind(this));
          next(this, function(){
            set(currentItem, 'selectedExamples',selectedExamplesTemp);
            if(this.get('subMode') === 'results-by-item') {
              this.set('selectedExample', selectedExamplesTemp.get('firstObject'));
            } else {
              this.set('selectedExample', null);
            }
            this.set('isCodeableConceptShow', false);
            const target = $('div[data-id=' + this.get('popup').elementId + ']').find('[name=coderableConceptEntrypopUp]');
            target.focus();
          }.bind(this));
        }).catch(function(error){
          this._catchError(error);
        }.bind(this));
      },

      onClosedAction(){
        // this.set('isConceptEntryOpen', false);
        // this.set('isClosed', true);
        // const currentItem= this.get('currentItem');
        // const previousItem= this.get('previousItem');
        // if(isEmpty(previousItem)){
        //   if(isEmpty(currentItem)){
        //     return;
        //   }else{
        //     this.set('previousItem', copy(currentItem));
        //   }
        // }
        // set(previousItem, 'selectedExample', this.get('isMultiCodeableConcept')?
        //   previousItem.selectedExamples : previousItem.selectedExample);
        // set(previousItem, 'commentsValue', this.get('commentsValue'));
        // this._calculate("Rule");
        // this.set('fullTextValue', null);
        // this.set('selectedExamplesTemp', null);
        $('#commentsValue').off('input', this._commentTextChanged.bind(this));
        $('#coderableConceptEntrypopUp').off('keydown');
        next(this, function(){
          this.set('commentsValue', null);
          this.set('codeableConceptItems', null);
        }.bind(this));
      },

      onConfirmedAction(){
        const currentItem= this.get('currentItem');
        // this.set('currentItem', this.get('currentItem'));
        this.set('isConceptEntryOpen', false);
        this.set('isClosed', true);
        set(currentItem, 'selectedExample', this.get('isMultiCodeableConcept')?
          currentItem.selectedExamples : currentItem.selectedExample);
        set(currentItem, 'commentsValue', this.get('commentsValue'));
        this.set('previousItem', this.get('currentItem'));
        this._calculate("Rule");
        this.set('fullTextValue', null);
        this.set('selectedExamplesTemp', null);
        next(this, function(){
          this.set('commentsValue', null);
          this.set('codeableConceptItems', null);
        }.bind(this));
      },
      onValueStringCommitAction(){
        // this._return();
        this.set('isConceptEntryOpen', false);

        this.set('isClosed', true);
        this.set('previousItem', this.get('currentItem'));
        this._calculate("Rule");
        const returnKeyDownValueCB = this.get('returnKeyDownValueCB');
        if(!isEmpty(returnKeyDownValueCB)) {
          returnKeyDownValueCB(null,null,null);
        }
      },

      onLoadClick(){
        const resultValue= copy(this.get('resultValue'));
        const comparator= this.get('quantityComparatorSelectedItem.displayCode');
        const deviceValue= this.get('currentItem.deviceValue.quantity.value');

        // this.set('valueString', comparator + resultValue + '(' + deviceValue + ')');
        if(isPresent(deviceValue)){
          // if(Ember.isPresent(deviceValue)){
          this.set('valueString', comparator + resultValue + '(' + deviceValue + ')');
          // }
        }else{
          this.set('valueString', comparator + resultValue + '( )');
        }
      },

      onCheckboxlistChanged(e){
        const currentItem= this.get('currentItem');
        this.set('previousItem', currentItem);
        if(e.checked== false){
          //선택 해제한 경우
          const selectedExamples= this.get('selectedExamplesTemp').removeObject(e.item);
          set(currentItem, 'selectedExamples', selectedExamples);
          this._commentsValueChangedList(e);
          set(currentItem, 'fullTextValue',this.get('fullTextValue'));
          // set(currentItem, 'isValueChanged', true);
          return;
        }

        const selectedExamples= this.get('selectedExamplesTemp').addObject(e.item);
        set(currentItem, 'selectedExamples', selectedExamples);
        this._commentsValueChangedList(e);
        set(currentItem, 'fullTextValue',this.get('fullTextValue'));
        // set(currentItem, 'isValueChanged', true);
      },

      onRadiobuttonlistChanged(e){
        if(isEmpty(e.item)){
          //선택 해제
          this.set('fullTextValue', this.get('commentsValue'));
          return;
        }
        const currentItem= this.get('currentItem');
        this.set('previousItem', currentItem);
        set(currentItem, 'selectedExample',e.item);
        this._commentsValueChanged(e);
        set(currentItem, 'fullTextValue',this.get('fullTextValue'));
        // set(currentItem, 'isValueChanged', true);
        set(currentItem, 'selectedExample',e.item);
        this.set('currentItem', currentItem);
      },

      onKeyDown(e) {
        const type = this.get('specimenexaminationreportService').getKeyBoardEventType(e.originalEvent);
        this.set('previousItem', this.get('currentItem'));
        if(type === 'esc') {
          this.set('isConceptEntryOpen', false);
        }
      },

      onDoubleClickAction(){
        this.set('isConceptEntryOpen', false);
      },

      onClearClick(){
        const currentItem= this.get('currentItem');
        // const currentItem= $.extend(true, EmberObject.create(), this.get('currentItem'));
        this.set('previousItem', currentItem);
        set(currentItem, 'isCleared', true);
        // set(currentItem, 'isValueChanged', true);
        this.set('commentsValue', null);
        set(currentItem, 'selectedExample', null);
        if(!isEmpty(currentItem.value)){
          set(currentItem, 'value.codeableConcept', { coding: null, displayContent: null});
          set(currentItem, 'value', { codeableConcept :{ coding: null, displayContent: null}, valueString: null });
        }
        this.set('fullTextValue', null);
        if(!isEmpty(this.get('codeableConceptItems'))){
          this.get('codeableConceptItems').forEach(e=>{
            set(e,'selected' , false);
          });
        }
        this.set('selectedExample', null);
        this.set('selectedExamplesTemp', []);
      },

      onTextCleared(){
        const currentItem= this.get('currentItem');
        const fullTextValue=this._getSelectedItemName();
        this.set('fullTextValue', fullTextValue);
        set(currentItem, 'fullTextValue', fullTextValue);
        // set(currentItem, 'isValueChanged', true);
        this.set('previousItem', currentItem);
      },

      // onPopUpKeyDown(e){
      //   if(isEmpty(e.key)){
      //     return;
      //   }
      //   if(e.key === 'Alt'){
      //     this.set('isAlt', true);
      //     return;
      //   }

      //   if(this.get('isAlt')){
      //     this.set('isAlt', false);
      //     this.get('codeableConceptItems').forEach(item=>{
      //       if(!isEmpty(item.get('functionApply.code'))){
      //         if(item.get('functionApply.code').slice(6) == e.key){
      //           console('isAlt  functionApplyCode  ' + e.key);
      //         }
      //       }
      //     });
      //   }
      // },

    },
    _onPopUpKeyDown(e){
      if(isEmpty(e.key)){
        return;
      }
      if(e.key === 'Alt'){
        this.set('isAlt', true);
        return;
      }

      if(this.get('isAlt')){
        this.set('isAlt', false);
        this.get('codeableConceptItems').forEach(item=>{
          if(!isEmpty(item.get('functionApply.code'))){
            if(item.get('functionApply.code').slice(6) == e.key){
              // console('isAlt  functionApplyCode  ' + e.key);

              this.set('commentsValue', e.value.valueString);
              this.set('fullTextValue', e.value.valueString);
              this.set('isConceptEntryOpen', false);
            }

          }
        });
      }
    },
    // 5. Private methods Area
    _init(){
      this.set('isClosed', false);
      this.set('selectedExample', null);
      this.set('commentsValue', null);
      this.set('fullTextValue', null);
      this.set('updatedComment', false);
    },

    _setCodeableConceptItemsDefault(exampleValue, currentItem, selectedExamplesTemp){
      exampleValue.forEach(element => {
        set(element,'displayName' , element.name);
        set(element,'selected' , false);
        if(isEmpty(currentItem.value)){
          return;
        }
        if(isEmpty(currentItem.value.codeableConcept.coding)){
          // return;
        }else if(currentItem.value.codeableConcept.coding.length>1){
        // 멀티타입인경우

        }else if(element.get('code')== currentItem.value.codeableConcept.coding.get('firstObject.code')
          && this.get('subMode') === 'results-by-item'){
          set(element,'selected' , true);
          this.set('selectedExample', element);
          set(element,'selectedExample' , element);
          selectedExamplesTemp.addObject(element);
          // selectedExampleTemp=element;
        }else {
          set(element,'selected' , false);
        }
      });
      return exampleValue;
    },

    _setCodeableConceptItems(exampleValue, currentItem, selectedExamplesTemp){
      if(exampleValue.get('firstObject').isMultiCodeableConcept){
        this.set('isMultiCodeableConcept', true);
      }else{
        this.set('isMultiCodeableConcept', false);
      }
      exampleValue.forEach(element => {
        const elementCoding= element.get('value.codeableConcept.coding');
        //예문리스트에서 displayContent 없을 경우 displayName
        set(element,'displayName', isPresent(element.get('value.codeableConcept.displayContent'))?
          element.get('value.codeableConcept.displayContent')
          : elementCoding.get('firstObject.displayName'));
        if(isEmpty(currentItem.value)){
          return;
        }
        if(isEmpty(currentItem.get('value.codeableConcept.coding.firstObject.code'))){
          return;
        }
        //calculate 후 or 특정 값으로 select 해야하는 경우
        if(currentItem.value.codeableConcept.coding.length>1){
          currentItem.value.codeableConcept.coding.forEach(e=>{
            if(elementCoding.get('firstObject.code')== e.code && this.get('subMode') === 'results-by-item'){
              set(element,'selected' , true);
              selectedExamplesTemp.addObject(element);
              this.set('selectedExample', element);
              set(element,'selectedExample' , element);
            }
          });
        }else if(element.get('value.codeableConcept.coding.firstObject.code')== currentItem.value.codeableConcept.coding.get('firstObject.code')
          && this.get('subMode') === 'results-by-item'){
          set(element,'selected' , true);
          this.set('selectedExample', element);
          set(element,'selectedExample' , element);
          selectedExamplesTemp.addObject(element);
        }else {
          set(element,'selected' , false);
        }
      });
      return exampleValue;
    },
    _getSelectedItemName(){
      const currentItem= this.get('currentItem');
      let displayName='';
      // let displayName = currentItem.get('value.codeableConcept.coding.firstObject.displayName');
      const tmp=[];
      const arr=[];
      if(this.get('isMultiCodeableConcept') ){
        this.get('codeableConceptItems').forEach(function(i){
          if(i.selected==true){
            arr.addObject(i);
            tmp.addObject(i.displayName);
          }
        });
        set(currentItem, 'selectedExamples', arr);
        displayName=tmp.join(', ');
      }else if(!this.get('isMultiCodeableConcept')){
        // displayName= displayName;
        displayName=this.get('selectedExample.displayName');
        set(currentItem, 'selectedExample', this.get('selectedExample'));
      }else{
        displayName='';
      }
      return displayName;
    },

    _commentTextChanged(e){
      if(this.get('isMultiCodeableConcept')){
        this._commentsValueChangedList(e);
      }else{
        this._commentsValueChanged(e);
      }
      // set(this.get('currentItem'), 'isValueChanged', true);
    },

    _commentsValueChangedList(e){
      const currentItem= this.get('currentItem');
      set(currentItem, 'isCleared', false);
      let commentsValue= this.get('commentsValue');
      let fullTextValue = this.get('fullTextValue');
      if(isEmpty(commentsValue)){
        commentsValue='';
      }
      let selectedExampleTemp= currentItem.selectedExamples;
      if(e.checked==false && isEmpty(selectedExampleTemp)){
        //선택항목 없음
        fullTextValue = !isEmpty(e.target) ? e.target.value : commentsValue;
        this.set('fullTextValue', fullTextValue);
        set(currentItem, 'fullTextValue', fullTextValue);
        return;
      }
      const displayName= this._getSelectedItemName();
      if(!isEmpty(selectedExampleTemp)){
        //새로 선택한 라디오버튼 선택값(e.item)
        selectedExampleTemp=currentItem.selectedExamples.map(function(i){
          return i.displayName;
        });
        selectedExampleTemp=selectedExampleTemp.join(', ');
        fullTextValue= !isEmpty(e.target)? e.target.value: commentsValue;
        fullTextValue= selectedExampleTemp +' '+ fullTextValue;
        this.set('fullTextValue', fullTextValue);
        set(currentItem, 'fullTextValue', fullTextValue);
        return;
      }else if(!isEmpty(displayName) && isEmpty(selectedExampleTemp) && this.get('updatedComment')!=true){
        //기존 저장값만 있는 경우
        selectedExampleTemp=displayName;
        this.set('updatedComment', true);
        fullTextValue= !isEmpty(e.target)? e.target.value: commentsValue;
        fullTextValue= selectedExampleTemp +' '+ fullTextValue;
        this.set('fullTextValue', fullTextValue);
        set(currentItem, 'fullTextValue', fullTextValue);
        return;
      }else if(currentItem.selectedExample ===null){
        //clear된상태
        selectedExampleTemp='';
      }else if(isEmpty(displayName)){
        //comment만 있는 경우
        selectedExampleTemp='';
      }else if(!isEmpty(displayName)){
        selectedExampleTemp=displayName;
      }
      fullTextValue= isEmpty(selectedExampleTemp)? e.target.value : selectedExampleTemp+ ' ' + e.target.value ;
      this.set('fullTextValue', fullTextValue);
      set(currentItem, 'fullTextValue', fullTextValue);
    },

    _commentsValueChanged(e){
      const currentItem= this.get('currentItem');
      set(currentItem, 'isCleared', false);
      let commentsValue= this.get('commentsValue');
      let fullTextValue = this.get('fullTextValue');
      if(isEmpty(commentsValue)){
        //사용자 입력한 comment값
        commentsValue='';
      }
      let selectedExampleTemp= currentItem.selectedExample;
      // let selectedExampleTemp= this.get('selectedExample');
      if(e.checked != true && isEmpty(selectedExampleTemp) && isEmpty(this.get('selectedExample'))){
        //선택항목 없음 최초 comment 입력
        fullTextValue = !isEmpty(e.target) ? e.target.value : commentsValue;
        this.set('fullTextValue', fullTextValue);
        set(currentItem, 'fullTextValue', fullTextValue);
        return;
      }

      if(!isEmpty(selectedExampleTemp)){
        //새로 선택한 라디오버튼 선택값(e.item)
        selectedExampleTemp= currentItem.selectedExample.displayName;
        fullTextValue= !isEmpty(e.target)? e.target.value: commentsValue;
        fullTextValue= selectedExampleTemp +' '+ fullTextValue;
        this.set('fullTextValue', fullTextValue);
        set(currentItem, 'fullTextValue', fullTextValue);
        return;
      }else if(!isEmpty(fullTextValue) && isEmpty(selectedExampleTemp) && this.get('updatedComment')!=true){
        //기존 저장값유지, comment 수정
        // selectedExampleTemp=fullTextValue;
        if(isEmpty(currentItem.value)){
          selectedExampleTemp='';
        }else if(isEmpty(currentItem.value.codeableConcept)){
          selectedExampleTemp='';
        }else{
          selectedExampleTemp= isEmpty(currentItem.value.codeableConcept.displayContent)? '': currentItem.value.codeableConcept.displayContent;
        }
        this.set('updatedComment', true);
      }else if(currentItem.selectedExample ===null){
        //clear된상태
        selectedExampleTemp='';
      }else if(isEmpty(currentItem.value)){
        selectedExampleTemp='';
      }else if(!isEmpty(currentItem.value.codeableConcept.displayContent)){
        selectedExampleTemp=currentItem.value.codeableConcept.displayContent;
      }
      fullTextValue= selectedExampleTemp + ' ' + e.target.value ;
      this.set('fullTextValue', fullTextValue);
      set(currentItem, 'fullTextValue', fullTextValue);
    },

    _calculate(inputModeType){
      const currentItem= isEmpty(this.get('previousItem'))? this.get('currentItem'): this.get('previousItem');
      if(!this._calculateValidationCheck(currentItem, currentItem.selectedExample)){
        return;
      }
      let resultListItemsSource=[];
      var selectedItemsTemp = this.get('selectedItems');
      if (this.get('mode')=='results-by-item') {
        //항목별검사결과관리 에서는 선택항목만 calculate
        selectedItemsTemp.forEach(function (e) {
          resultListItemsSource.addObject(EmberObject.create(e));
        });
      }else{
        //일반검사결과관리-리스트 전체 calculate
        resultListItemsSource= this.get('resultListItemsSource');
        // this.get('specimenexaminationreportService')._showMessage('선택된 검사가 없습니다.', 'warning', 'Ok', 'Ok', '', 2000);
        // return;
      }
      const observationResults= [];
      let value={};
      if(isEmpty(resultListItemsSource)){
        return;
      }
      const now = this.get('co_CommonService').getNow();
      const subMode = this.get('subMode');
      resultListItemsSource.forEach((element, index)=>{
        const e=element;
        if(currentItem.examinationId==e.examinationId && currentItem.specimenId==e.specimenId && e.value != currentItem.value
           && e.valueValueString != e.fullTextValue){
          set(e, 'isValueChanged', true);
        }else if(currentItem.examinationId==e.examinationId && currentItem.fullTextValue != this.get('initialDisplayName')){
          set(e, 'isValueChanged', true);
        }
        //2021-05-25 염색결과입력, 배양결과입력 코드형 일괄입력 기능 추가
        if(subMode === 'results-by-item-micro') {
          if(e.valueTypeCode ==='CodeableConcept' && index !== 0) {
            set(e, 'value', resultListItemsSource[0].value);
          }
          set(e, 'isValueChanged', true);
        }
        if(e.isCleared==true){
          value={
            quantity: {value: null, comparatorCode: null, unitCode: null, unitName: null},
            codeableConcept:  value={ coding: null, displayContent: null}, valueString: null};
        }else if((this.get('mode')=='results-by-item' && e.isValueChanged == true) || (this.get('mode')=='general') ){
          //항목별검사결과: 수정한 항목만 calculate 일반검사결과: 리스트중에 하나라도 수정했으면 전부 calculate
          value= e.valueTypeCode ==='CodeableConcept'? this._setCodeableValueParam(e, now) : e.get('value');
        }else{
          return;
        }

        if(e.isValueChanged != true){
          // calculate 대상 아닌 것 제거
          const tmp={
            isChange: false,
            examinationId: e.examinationId,
            observationResultId: e.observationResultId,
            valueTypeCode: e.valueTypeCode,
            recentObservationResultId: isEmpty(e.recentObservationResult)? null : e.recentObservationResult.observationResultId,
            value:value,
          };
          observationResults.addObject(tmp);
          return;
        }

        const tmp={
          isChange: true,
          examinationId: e.examinationId,
          observationResultId: e.observationResultId,
          valueTypeCode: e.valueTypeCode,
          value:value,
          recentObservationResultId: isEmpty(e.recentObservationResult)? null : e.recentObservationResult.observationResultId
        };
        if(!isEmpty(tmp.value)){
          if(!isEmpty(tmp.value.displayContent)){
            tmp.value.displayContent= tmp.value.displayContent.trim();
          }
          value.valueString= isEmpty(value.valueString)? null: value.valueString;
        }
        observationResults.addObject(tmp);
      });
      if(isEmpty(observationResults)){
        return;
      }
      const params={
        inputModeType: inputModeType,
        isPossibleInputItemId: true,
        subjectId: currentItem.subjectId,
        subjectTypeCode : 'Patient',
        specimenNumber: currentItem.specimenNumber,
        observationResults: observationResults
      };
      this.set('gridDisabled', true);
      this.create(this.get('defaultUrl') + 'observations/results/calculate', null, params).then(res=>{
        this.set('gridDisabled', false);
        if(isEmpty(resultListItemsSource) || isEmpty(res)){
          return;
        }
        const returnCalculatedValueCB = this.get('returnCalculatedValueCB');
        if (this.get('mode') == 'results-by-item') {
          //항목별검사관리- 한개의 항목만 binding
          let item= res.get('firstObject');
          //2021-05-25 염색결과입력, 배양결과입력 코드형 일괄입력 기능 추가
          if(this.get('subMode') === 'results-by-item-micro') {
            item = res;
          } else {
            const valueValueString= this._setValueValueString(item);
            set(item, 'valueValueString', valueValueString);
            set(item, 'numericCellInputValue', valueValueString);
            set(item, 'value', res.get('firstObject').value);
          }
          if(!isEmpty(returnCalculatedValueCB)) {
            returnCalculatedValueCB(item, currentItem);
          }
        }else{
          //일반검사관리
          if(!isEmpty(returnCalculatedValueCB)) {
            returnCalculatedValueCB(null);
          }
          this.get('resultListItemsSource').forEach(function(gridItem, gridItemIndex){
            let item=null;
            const changedItem=res.findBy('examinationId', gridItem.examinationId);
            if (this.get('mode')=='general' && !isEmpty(changedItem)){
              item= changedItem;
              set(gridItem, 'isUpdated', true );
            }else if(this.get('mode')=='results-by-item'){
              item=res[gridItemIndex];
            }else{
              return;
            }
            const valueValueString= this.get('specimenexaminationreportService')._setValueString(item);
            if(item.valueTypeCode=='Quantity'){
              if(isPresent(item.value)){
                set(gridItem, 'valueValueString', valueValueString);
                set(gridItem, 'numericCellInputValue', valueValueString);
                set(gridItem, 'value', item.value);
              }
              if(gridItem.examinationId == currentItem.examinationId){
                set(currentItem, 'a', true);
                set(currentItem, 'isUpdated', true);
              }

              if((gridItem.statusCode =='final' || gridItem.statusCode =='corrected') && (valueValueString == gridItem.valueValueString)){
                //검증상태이고 value가 같으면 isUpdated 업데이트 안함
                //gridItem: calculate 전 -> item, valueValueString: calculate 후
                set(currentItem, 'isUpdated', false);
              }
            }else if(item.valueTypeCode=='CodeableConcept'){
              if(isPresent(item.value)){
                set(gridItem, 'valueValueString', valueValueString);
                set(gridItem, 'numericCellInputValue', valueValueString);
                set(gridItem, 'value', item.value);
              }
            }
            set(gridItem, 'check.isCritical', item.check.isCritical);
            set(gridItem, 'check.isDelta', item.check.isDelta);
            set(gridItem, 'check.isPanic', item.check.isPanic);
            set(gridItem, 'check.isRecentCritical', item.check.isRecentCritical);
            // if(gridItem.statusCode == "waiting"){
            if(gridItem.check.isNotAnalyticalMeasurementRange != item.check.isNotAnalyticalMeasurementRange){
              //calculate 후 달라졌을 경우만 업데이트
              set(gridItem, 'check.isNotAnalyticalMeasurementRange', item.check.isNotAnalyticalMeasurementRange);
            }
            set(gridItem, 'interpretation', item.interpretation);
            if(!isEmpty(item.interpretation)){
              set(gridItem, 'interpretation.code', item.interpretation.coding.get('firstObject.code'));
            }
            set(gridItem, 'valueTypeCode', item.valueTypeCode);
            set(gridItem, 'numberValue', null);
          }.bind(this));
        }
        //save 작업 위한
        set(currentItem, 'isUpdated', true);
        set(currentItem, 'isValueChanged', false);
        set(currentItem, 'isCleared', false);
        this.set('closedByKeyDown', false);
      }).catch(function(error){
        this._catchError(error);
        set(currentItem, 'isValueChanged', false);
        this.set('currentItem', null);
      }.bind(this));
    },

    _setValueValueString(item){
      let example= item.get('value.codeableConcept.displayContent');
      let valueString= item.get('value.valueString');
      if(isEmpty(example)){
        example= '';
      }
      if(isEmpty(valueString)){
        valueString= null;
      }
      return isEmpty(valueString)? example: example + ' '+ valueString;
    },

    _calculateValidationCheck(currentItem,selectedExample){
      let res= true;
      if(isEmpty(selectedExample) && !currentItem.isValueChanged && isEmpty(this.get('fullTextValue'))){
        if(currentItem.isCleared != true){
          res= false;
        }
      }
      return res;
    },

    _setCodeableValueParam(e, now){
      const commentsValue= this.get('commentsValue')==''? null: this.get('commentsValue');
      let value= {
        quantity: {"value":null},
        codeableConcept: isEmpty(get(e, 'value.codeableConcept'))? {} : e.value.codeableConcept,
        valueString: e.isValueChanged? commentsValue: e.get('value.valueString'),
        valueDecimal: isEmpty(e.value)? 0 : e.value.valueDecimal
      };
      if(!isEmpty(e.selectedExamples)){
        value= this._setValueByselectedExamples(e, value, now);
      }else if(!isEmpty(e.selectedExample)){
        //싱글선택
        value= this._setValueByselectedExample(e,value, now);
      }else if(e.isValueChanged && isEmpty(e.selectedExamples) && isEmpty(e.selectedExample)
      && isEmpty(e.fullTextValue) && !isEmpty(e.valueValueString)){
        //Negative 처리 //fullTextValue 수정//있던 정보 초기화할경우//최초입력이 없었던 경우
        value= e.value;
      }else if(isEmpty(e.selectedExamples) && isEmpty(e.selectedExample)
      && isEmpty(e.valueValueString)){
        if( isEmpty(e.fullTextValue)){
          //최초입력이 없었던 경우
          value={
            quantity: { value: null, comparatorCode: null, unitCode: null, unitName: null},
            codeableConcept:  null, valueString:null
          };
        }
        //valueValueString는 기존 저장되있던 값
        value.codeableConcept= {
          coding: e.get('value.codeableConcept.coding'),
          displayContent: isEmpty(e.get('value.codeableConcept.displayContent'))? null : e.get('value.codeableConcept.displayContent')
        };
      }else if(isEmpty(value.codeableConcept.coding) && !isEmpty(value.valueString)){
        //coding 값 선택 없이 valueSting으로 저장할경우
        // value={
        //   quantity: { value: null, comparatorCode: null, unitCode: null, unitName: null},
        //   codeableConcept: null,
        //   valueString:value.valueString
        // };
      }else{
        //저장되있던 coding값 그대로 넘길경우(comments만 수정)
        value.codeableConcept= {
          coding: e.get('value.codeableConcept.coding'),
          displayContent: isEmpty(e.get('value.codeableConcept.displayContent'))? null :e.get('value.codeableConcept.displayContent'),
          // valueString:value.valueString
        };
      }
      return value;
    },
    _setValueByselectedExamples(e, value, now){
      //multi입력일경우
      const coding= [];
      // if(Ember.isEmpty(e.selectedExamples)){
      //   //아무것도 선택하지 않은 경우
      //   value.codeableConcept.displayContent= Ember.isEmpty(e.fullTextValue)?
      //     e.get('value.codeableConcept.displayContent') : e.fullTextValue;
      //   return;
      // }
      let displayContent=null;
      // const now= this.get('co_CommonService').getNow();
      e.selectedExamples.forEach(i=>{
        coding.pushObject({
          system: null,
          version: null,
          code: i.get('value.codeableConcept.coding.firstObject.code'),
          displayName: i.get('value.codeableConcept.coding.firstObject.displayName'),
          dataFirstRegisteredDateTimeUtc: now,
          dataLastModifiedDateTimeUtc: now,
        });
        displayContent= displayContent===null? i.get('value.codeableConcept.coding.firstObject.displayName'): displayContent+', '+i.get('value.codeableConcept.coding.firstObject.displayName');
      });
      value.codeableConcept.coding=coding;
      value.codeableConcept.displayContent= displayContent;
      value.codeableConcept.dataFirstRegisteredDateTimeUtc= now;
      value.codeableConcept.dataLastModifiedDateTimeUtc= now;
      // value.codeableConcept.displayContent= Ember.isEmpty(e.fullTextValue)?
      //   e.get('value.codeableConcept.displayContent') : e.fullTextValue.trim();

      return value;
      //그리드 전체를 calculate 해야하므로this.get('fullTextValue') 사용 못함
      // value.codeableConcept.displayContent= Ember.isEmpty(this.get('fullTextValue'))?
      //   e.value.codeableConcept.displayContent : this.get('fullTextValue').trim();
    },
    _setValueByselectedExample(e, value, now){
      let code= null;
      let displayName= null;
      let displayContent= null;
      // const now= this.get('co_CommonService').getNow();
      if(this.get('hasExamples')&& e.isValueChanged && isEmpty(e.get('selectedExample.value.codeableConcept.coding.firstObject'))){
        //저장된 예문일경우 -기존 저장된 코드에서 comment만 수정한경우
        code= e.get('value.codeableConcept.coding.firstObject.code');
        displayName=e.get('value.codeableConcept.coding.firstObject.displayName');
        displayContent=e.isValueChanged? e.selectedExample.value.codeableConcept.displayContent
          : e.get('value.codeableConcept.displayContent');
      }else if(this.get('hasExamples')&& !isEmpty(e.get('selectedExample.value.codeableConcept.coding.firstObject'))){
        //저장된 예문일경우 -코드 바꾼경우
        code= e.get('selectedExample.value.codeableConcept.coding.firstObject.code');
        displayName= e.get('selectedExample.value.codeableConcept.displayContent');
        displayContent=e.isValueChanged? e.selectedExample.value.codeableConcept.displayContent
          : e.get('value.codeableConcept.displayContent');
      }else if(!this.get('hasExamples') && e.isValueChanged && isEmpty(e.get('selectedExample.code'))){
        //저장안된 예문 -기존 저장된 코드에서 comment만 수정한경우
        code= e.get('value.codeableConcept.coding.firstObject.code');
        displayName=e.get('value.codeableConcept.coding.firstObject.displayName');
        displayContent=e.selectedExample.displayName;
      }else{
        //코드값을 새로 선택한경우
        code= e.get('selectedExample.code');
        displayName=e.get('selectedExample.name');
        displayContent=e.selectedExample.displayName;
      }
      value.codeableConcept= {
        coding: [{
          system: null,
          version: null,
          code: code,
          displayName: displayName,
          dataFirstRegisteredDateTimeUtc: now,
          dataLastModifiedDateTimeUtc: now,
        }],
        displayContent: displayContent,
        dataFirstRegisteredDateTimeUtc: now,
        dataLastModifiedDateTimeUtc: now,
      };
      return value;
    },

    _catchError(e){
      this.set('isCodeableConceptShow',false);
      this.set('gridDisabled', false);
      this.showResponseMessage(e);
    }
  });