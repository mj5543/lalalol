/* eslint-disable max-lines */
import { copy } from '@ember/object/internals';
import $ from 'jquery';
import { next } from '@ember/runloop';
import { isEmpty, isPresent } from '@ember/utils';
import EmberObject, { set } from '@ember/object';
import { hash } from 'rsvp';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import MessageMixin from '../../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MessageMixin,
  {
    specimenexaminationreportService: service('specimen-examination-report-service'),
    layout,
    // 2. Property Area
    defaultUrl: null,
    quantityComparatorSelectedItem: null,
    numberValue: null,
    valueString: null,
    comments: null,
    editItem: null,
    fullTextValue: null,
    closedByKeyDown: null,
    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-result-entry-quantity');
      //Set Stateful properties
      this.setStateProperties([
        'quantityComparatorSelectedItem',
        'numberValue',
        'isQuantityEntryOpen',
        'valueString',
        'menuClass',
        'fullTextValue'
      ]);
      if (this.hasState() === false) {
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')
        + `specimen-examination-report/v0/`);
        this.set('numberValue', this.get('currentItem.value.quantity.value'));
        this.set('isQuantityEntryOpen', false);
        this.set('closedByKeyDown', false);
        this.set('fullTextValue', null);
        this.set('commentsValue', null);
        this.set('numericOptions',"decimal",{});
      }
      //Initialize Stateless properties
    },

    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1000');
      if (this.hasState() === false) {
        const defaultUrl = this.get('defaultUrl');
        hash({
          quantityComparator: this.getList(defaultUrl + 'business-codes/search', {classificationCode: 'QuantityComparator'}, null),
        }).then(function(result) {
          this.set('quantityComparator', result.quantityComparator);
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      }
    },

    // 4. Actions Area
    actions: {
      onOpenedAction(e){
        this.set('popup', e.source);
        this.set('isClosed', false);
        this.set('closedByConfirmedBtn', false);
        const currentItemCopy= EmberObject.create(this.get('currentItem'));
        if(isEmpty(currentItemCopy)){
          return;
        }
        this.set('isPopupShow', true);
        this.set('editItem', currentItemCopy.examinationId );
        this.set('fullTextValue', null);
        this.set('numberValue', null);
        this.set('commentsValue', null);
        next(this, function () {
          this.set('quantityComparatorSelectedItem', this.get('quantityComparator.firstObject'));
          $('#specimen-examination-report_quantitNnumberValueId').on('input', this._numberValueChanged.bind(this));
          $('#commentsValueId').on('input', this._commentsValueChanged.bind(this));
          if(isEmpty(currentItemCopy.value.quantity.value)){
            if(isEmpty(currentItemCopy.numberValue)){
              //최초입력
              if(currentItemCopy.isKeydown===true){
                // this.set('numberValue', currentItemCopy.key);
                // this.set('numberValue', this.get('currentItem').numericCellInputValue);
                // this._numberValueChanged({});
              }else{
                this.set('numberValue', null);
              }
              this.set('valueString', null);
            }else{
              //저장전
              this.set('quantityComparatorSelectedItem', currentItemCopy.comparatorSelectedItem);
              this.set('numberValue', currentItemCopy.numberValue);
              this.set('valueString', currentItemCopy.value.valueString);
            }
          }else if(isPresent(currentItemCopy.numberValue)){
            //수정후
            this._setPopUpData();
          }else{
            //저장후
            this._setPopUpData();
          }
          const target = $('div[data-id=' + this.get('popup').elementId + ']').find('[name=quantityNumberValue]');
          target.find('input:first').parent().find('input').focus();
          next('this', function() {
            if(!isEmpty(currentItemCopy.value.quantity.value)){
              target.parent().find('input').select();
            }else if(!isEmpty(this.get('currentItem').numericCellInputValue)){
              //최초입력일 경우/조회후 최초연경우 select 안함
              this.set('numberValue', this.get('currentItem').numericCellInputValue);
              this._numberValueChanged({});
            }
            this.set('isPopupShow', false);
          }.bind(this));
        }.bind(this));
      },

      onClosedAction(){
        // this.set('isPopupShow', true);
        // const previousItem= this.get('previousItem');
        // const currentItem= this.get('currentItem');
        // this.set('isClosed', true);
        // // console.log('onClosedAction     ' + this.get('previousItem').examination.name + ' / ' +
        // // previousItem.isKeydown +'   /   ' + this.get('currentItem').examination.name + ' /' + currentItem.isKeydown);
        // if(this.get('closedByConfirmedBtn')){
        //   this.set('previousItem', null);
        //   set(currentItem, 'comparatorSelectedItem', this.get('quantityComparatorSelectedItem.code'));
        //   set(currentItem, 'valueString', this.get('commentsValue'));
        //   this._calculate("Rule");
        // }else if(this.get('closedByKeyDown')==false){
        //   if(isEmpty(previousItem)){
        //     if(isEmpty(currentItem)){
        //       this.set('isPopupShow', false);
        //       return;
        //     }
        //   }
        //   if(isEmpty(previousItem) && isEmpty(currentItem)){
        //     this.set('previousItem', copy(currentItem));
        //   }
        //   set(previousItem, 'comparatorSelectedItem', this.get('quantityComparatorSelectedItem.code'));
        //   set(previousItem, 'numberValue', this.get('numberValue'));
        //   set(currentItem, 'comparatorSelectedItem', this.get('quantityComparatorSelectedItem.code'));
        //   set(currentItem, 'valueString', this.get('commentsValue'));
        //   this._calculate("Rule");
        // }else{
        //   set(currentItem, 'comparatorSelectedItem', this.get('quantityComparatorSelectedItem.code'));
        //   set(currentItem, 'numberValue', this.get('numberValue'));
        //   set(currentItem, 'valueString', this.get('commentsValue'));
        //   this.set('previousItem', currentItem);
        //   this._calculate("Rule");
        // }
        $('#specimen-examination-report_quantitNnumberValueId').off('input', this._numberValueChanged);
        $('#commentsValueId').off('input', this._commentsValueChanged);
      },

      onNumberValueCommit(){
        this._load();
        const target = $('[tabindex=3]');
        if(!isEmpty(target.get(0))){
          target.get(0).focus();
        }
        this.set('closedByKeyDown', true);
        this.set('isQuantityEntryOpen', false);
        const currentItem= this.get('currentItem');
        this.set('isClosed', true);
        this.set('previousItem', this.get('currentItem'));
        set(currentItem, 'comparatorSelectedItem', this.get('quantityComparatorSelectedItem.code'));
        set(currentItem, 'valueString', this.get('commentsValue'));
        // set(currentItem, 'isValueChanged', true);
        this._calculate("Rule");
        const returnKeyDownValueCB = this.get('returnKeyDownValueCB');
        if(!isEmpty(returnKeyDownValueCB)) {
          returnKeyDownValueCB(null,null,null);
        }
      },

      onCommentsCommitAction(){
        this.set('closedByKeyDown', true);
        this.set('isQuantityEntryOpen', false);
        const currentItem= this.get('currentItem');
        this.set('isClosed', true);
        this.set('previousItem', this.get('currentItem'));
        set(currentItem, 'comparatorSelectedItem', this.get('quantityComparatorSelectedItem.code'));
        set(currentItem, 'valueString', this.get('commentsValue'));
        // set(currentItem, 'isValueChanged', true);
        this._calculate("Rule");
        // set(this.get('currentItem'), 'isValueChanged', true);

        const returnKeyDownValueCB = this.get('returnKeyDownValueCB');
        if(!isEmpty(returnKeyDownValueCB)) {
          returnKeyDownValueCB(null,null,null);
        }
      },

      onLoadClick(){
        this._load();
      },

      onKeyDown(e) {
        const type =this.get('specimenexaminationreportService').getKeyBoardEventType(e.originalEvent);
        if(type === 'esc') {
          this.set('isQuantityEntryOpen', false);
        }else{
          // set(this.get('currentItem'), 'isValueChanged', true);
        }
      },

      onComparatorChanged(e){
        if(!isEmpty(e.item)){
          this.set('quantityComparatorSelectedItem', e.item);
        }
        this._numberValueChanged(e);
        // set(this.get('currentItem'), 'isValueChanged', true);
        set(this.get('currentItem'), 'comparatorSelectedItem', this.get('quantityComparatorSelectedItem.code'));
      },

      onClearClick() {
        const currentItem= this.get('currentItem');
        this.set('quantityComparatorSelectedItem', this.get('quantityComparator.firstObject'));
        this.set('numberValue', null);
        this.set('commentsValue', null);
        this.set('fullTextValue', null);
        set(currentItem, 'isCleared', true);
        set(currentItem, 'key', null);
        // set(currentItem, 'isValueChanged', true);
      },

      onTextCleared(){
        this._commentsValueChanged(null);
      },

      onConfirmedAction(){
        this.set('closedByConfirmedBtn', true);
        this.set('isQuantityEntryOpen', false);
        this.set('isPopupShow', true);
        // const previousItem= this.get('previousItem');
        const currentItem= this.get('currentItem');
        this.set('isClosed', true);
        this.set('previousItem', this.get('currentItem'));
        set(currentItem, 'comparatorSelectedItem', this.get('quantityComparatorSelectedItem.code'));
        set(currentItem, 'valueString', this.get('commentsValue'));
        set(currentItem, 'isNotProgress', false);
        // set(currentItem, 'isValueChanged', true);
        this._calculate("Rule");
        // // console.log('onClosedAction     ' + this.get('previousItem').examination.name + ' / ' +
        // // previousItem.isKeydown +'   /   ' + this.get('currentItem').examination.name + ' /' + currentItem.isKeydown);
        // if(this.get('closedByConfirmedBtn')){
        //   this.set('previousItem', null);
        //   set(currentItem, 'comparatorSelectedItem', this.get('quantityComparatorSelectedItem.code'));
        //   set(currentItem, 'valueString', this.get('commentsValue'));
        //   this._calculate("Rule");
        // }else if(this.get('closedByKeyDown')==false){
        //   if(isEmpty(previousItem)){
        //     if(isEmpty(currentItem)){
        //       this.set('isPopupShow', false);
        //       return;
        //     }
        //   }
        //   if(isEmpty(previousItem) && isEmpty(currentItem)){
        //     this.set('previousItem', copy(currentItem));
        //   }
        //   set(previousItem, 'comparatorSelectedItem', this.get('quantityComparatorSelectedItem.code'));
        //   set(previousItem, 'numberValue', this.get('numberValue'));
        //   set(currentItem, 'comparatorSelectedItem', this.get('quantityComparatorSelectedItem.code'));
        //   set(currentItem, 'valueString', this.get('commentsValue'));
        //   this._calculate("Rule");
        // }else{
        //   set(currentItem, 'comparatorSelectedItem', this.get('quantityComparatorSelectedItem.code'));
        //   set(currentItem, 'numberValue', this.get('numberValue'));
        //   set(currentItem, 'valueString', this.get('commentsValue'));
        //   this.set('previousItem', currentItem);
        //   this._calculate("Rule");
        // }
      },
    },

    // 5. Private methods Area
    _load(){
      const numberValue= copy(this.get('numberValue'));
      // const numberValue= this.get('numberValue');
      const comparator= this.get('quantityComparatorSelectedItem.displayCode');
      const deviceValue= this.get('currentItem.deviceValue.quantity.value');
      // const examinationUnit = Ember.isEmpty(this.get('currentItem.examinationUnit.firstObject.name'))
      //   ? '' : this.get('currentItem.examinationUnit.firstObject.name');

      //To-do deviceValue
      // this.set('valueString', comparator + numberValue + '(' + deviceValue + ')');
      if(isPresent(deviceValue)){
        // if(Ember.isPresent(deviceValue)){
        this.set('valueString', comparator + numberValue +'(' + deviceValue + ')');
        // }
      }else{
        this.set('valueString', comparator + numberValue );
      }
    },

    _setCurrentCellSelectedItem() {
      const cell = this.get('_currentCell');
      const value = cell.value.toString();
      let item;

      if(cell.editType.code === '5') {
        item = cell.editType.items.findBy('id', value);
        if(!isEmpty(item)) {
          set(item, 'selected', true);
        }
      } else if (cell.editType.code === '6') {
        for(let i=0; i < cell.editType.items.length; i++) {
          set(cell.editType.items[i], 'selected', false);
        }

        const arr = value.split(',');

        for(let i=0; i < arr.length; i++) {
          item = cell.editType.items.findBy('id', arr[i]);
          if(!isEmpty(item)) {
            set(item, 'selected', true);
          }
        }
      }

    },

    _numberValueChanged(e) {
      if(e==='false'){
        e.target=null;
      }
      const currentItem= this.get('currentItem');
      set(currentItem, 'isCleared', false);
      // let comparator= this.get('quantityComparatorSelectedItem.displayCode');
      //quantityComparator onChanged()일때와 numberValue changed 일때 구분
      let comparator= isEmpty(e.item)? this.get('quantityComparatorSelectedItem.displayCode'): e.item.displayCode;
      let numberValue= this.get('numberValue');
      let commentsValue= this.get('commentsValue');
      comparator= isEmpty(comparator)? '': comparator;
      if(comparator =='-' || isEmpty(comparator)){
        comparator= '';
      }
      numberValue= isEmpty(this.get('numberValue'))? '': numberValue;
      commentsValue= isEmpty(this.get('commentsValue'))? '': commentsValue;
      let fullTextValue = this.get('fullTextValue');
      fullTextValue= comparator;
      if(isEmpty(numberValue) && isEmpty(e.target)){
        // this.set('fullTextValue', comparator + commentsValue);
        return;
      }
      if(isEmpty(e.target)){
        fullTextValue= fullTextValue + ' '+ numberValue + ' '+ commentsValue;
      }else{
        fullTextValue= fullTextValue + ' '+ e.target.value + ' ' + commentsValue;
      }
      this.set('fullTextValue', fullTextValue);

    },

    _commentsValueChanged(e){
      const currentItem= this.get('currentItem');
      const comparator= this.get('quantityComparatorSelectedItem.displayCode')===null? '': this.get('quantityComparatorSelectedItem.displayCode');
      const numberValue= isEmpty(this.get('numberValue'))? '' : this.get('numberValue');
      const comments= isEmpty(e)? '': e.target.value;
      this.set('fullTextValue', comparator + ' '+ numberValue + ' ' + comments);
      this.set('previousItem', this.get('currentItem'));
      // set(currentItem, 'isValueChanged', true);
      set(currentItem, 'valueString', comments);
      // Ember.set(currentItem, 'valueString', this.get('fullTextValue'));
    },

    _setPopUpData(){
      const currentItemCopy= this.get('currentItem');
      const numberValue= currentItemCopy.value.quantity.value;
      let commentsValue= currentItemCopy.value.valueString;
      let comparator= copy(currentItemCopy.value.quantity.comparatorCode);
      if(!isEmpty(this.get('quantityComparator'))){
        this.set('quantityComparatorSelectedItem', this.get('quantityComparator').find(function(i){
          //재확인 i.code
          return i.code==comparator;
        }));
      }
      if(comparator =='-' || isEmpty(comparator)){
        comparator= '';
        this.set('quantityComparatorSelectedItem',this.get('quantityComparator.firstObject'));
      }
      if(isEmpty(commentsValue)){
        commentsValue= '';
      }
      this.set('numberValue', numberValue);
      this.set('commentsValue', currentItemCopy.value.valueString);
      if(!isEmpty(currentItemCopy.numericCellInputValue) && !currentItemCopy.isNotProgress){
        //cellclick
        // this.set('fullTextValue', numberValue);
        this.set('fullTextValue', currentItemCopy.numericCellInputValue);
      }else{
        this.set('fullTextValue', comparator + ' ' + numberValue + ' ' + commentsValue);
      }
    },

    _calculate(inputModeType){
      // console.log(this.get('previousItem.examination.name') + '   /   ' + this.get('currentItem.examination.name'));
      const currentItem= isEmpty(this.get('previousItem'))? this.get('currentItem'): this.get('previousItem');
      const numberValue= this.get('numberValue');
      // const commentsValue= this.get('commentsValue');
      if(isEmpty('currentItem')){
        return;
      }
      let resultListItemsSource=[];
      const calculateArr=[];
      var selectedItemsTemp = this.get('selectedItems');
      if (this.get('mode')=='general') {
        //일반검사결과관리
        resultListItemsSource= this.get('resultListItemsSource');
      }else{
        //항목별검사결과관리 에서는 선택항목만 계산
        if(selectedItemsTemp.length==1 && !isEmpty(this.get('currentItem'))){
          //keydown으로 cell이동시 그리드 선택값과 focused cell이 다른 문제
          if(this.get('previousItem') != this.get('currentItem')){
            selectedItemsTemp=[];
            selectedItemsTemp.addObject(this.get('currentItem'));
            this.set('currentItem', currentItem);
          }
        }else if(selectedItemsTemp.length >1 || selectedItemsTemp.length == 0){
          selectedItemsTemp=[];
          selectedItemsTemp.addObject(this.get('currentItem'));
        }
        this.set('currentItem', currentItem);
        selectedItemsTemp.forEach(function (e) {
          resultListItemsSource.addObject(EmberObject.create(e));
        });
      }
      const observationResults= [];
      let value={};

      if(isEmpty(numberValue) || isEmpty(this.get('fullTextValue'))){
        if(currentItem.isCleared != true){
          // this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('8945', 'F', '필수값을 입력하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
      }
      resultListItemsSource.forEach(element=>{
        const e=EmberObject.create(element);
        if(currentItem.examinationId==e.examinationId && currentItem.specimenId==e.specimenId){
          set(e, 'isValueChanged', true);
          calculateArr.addObject(e);
        }else if(this.get('mode')=='results-by-item'){
          calculateArr.addObject(e);
        }
        if(e.isCleared==true){
          value={
            quantity: {value: null, comparatorCode: null, unitCode: null, unitName: null},
            codeableConcept:  value={coding: null, displayContent: null},
            valueString: null
          };
        }else{
          value=this._setCalculateValue(e);
        }
        if(e.isValueChanged != true){
          //calculate 대상 아닌 경우
          observationResults.addObject(this._addObservationResult(e, value, false));
          return;
        }
        observationResults.addObject(this._addObservationResult(e, value, true));
      });
      const params={
        inputModeType: inputModeType,
        isPossibleInputItemId: true,
        subjectId: currentItem.subjectId,
        subjectTypeCode : 'Patient',
        specimenNumber: currentItem.specimenNumber,
        observationResults: observationResults
      };
      if(calculateArr.length==0){
        return;
      }
      this.set('isPopupShow', true);
      this.set('gridDisabled', true);
      return this.ajaxSyncCall(this.get('defaultUrl') + 'observations/results/calculate', null,'POST',params,false).done(function(res){
        this.set('gridDisabled', false);
        this.set('isPopupShow', false);
        this.set('closedByConfirmedBtn', false);
        this.set('fullTextValue', null);
        this.set('numberValue', null);
        this.set('commentsValue', null);
        if(isEmpty(res)){
          return;
        }
        const returnCalculatedValueCB = this.get('returnCalculatedValueCB');
        if (this.get('mode')=='results-by-item') {
          //항목별검사관리- 선택항목만 binding
          const item= res.get('firstObject');
          set(item, 'valueValueString', this._setValueString(item));
          set(item, 'numericCellInputValue', this._setValueString(item));
          if(!isEmpty(returnCalculatedValueCB)) {
            returnCalculatedValueCB(item, this.get('currentItem'));
          }
        }else{
          //일반검사관리
          if(!isEmpty(returnCalculatedValueCB)) {
            returnCalculatedValueCB(null);
          }
          this.get('resultListItemsSource').forEach(function(gridItem, gridItemIndex){
            let item=null;
            const changedItem=res.findBy('examinationId', gridItem.examinationId);
            if (this.get('mode')=='general' && !isEmpty(changedItem)){
              item= changedItem;
            }else if(this.get('mode')=='results-by-item'){
              item=res[gridItemIndex];
            }else{
              return;
            }

            if(item.valueTypeCode=='Quantity'){
              const valueValueString = this.get('specimenexaminationreportService')._setValueString(item);
              if(isPresent(item.value)){
                set(gridItem, 'valueValueString', valueValueString);
                set(gridItem, 'numericCellInputValue',valueValueString );
                set(gridItem, 'value', item.value);
              }
              if(gridItem.examinationId ==currentItem.examinationId){
                set(currentItem, 'a', true);
                set(currentItem, 'isUpdated', true);
              }

              if((gridItem.statusCode =='final' || gridItem.statusCode =='corrected') && (valueValueString == gridItem.valueValueString)){
                //검증상태이고 value가 같으면 isUpdated 업데이트 안함
                //gridItem: calculate 전 -> item, valueValueString: calculate 후
                set(currentItem, 'isUpdated', false);
              }
            }else if(item.valueTypeCode=='CodeableConcept'){
              if(isPresent(item.value)){
                set(gridItem, 'valueValueString', this.get('specimenexaminationreportService')._setValueString(item));
                set(gridItem, 'value', item.value);
              }
            }
            set(gridItem, 'check.isCritical', item.check.isCritical);
            set(gridItem, 'check.isDelta', item.check.isDelta);
            set(gridItem, 'check.isPanic', item.check.isPanic);
            set(gridItem, 'check.isRecentCritical', item.check.isRecentCritical);
            // if(gridItem.statusCode == "waiting"){
            if(gridItem.check.isNotAnalyticalMeasurementRange != item.check.isNotAnalyticalMeasurementRange){
              //calculate 후 달라졌을 경우만 업데이트
              set(gridItem, 'check.isNotAnalyticalMeasurementRange', item.check.isNotAnalyticalMeasurementRange);
            }
            set(gridItem, 'interpretation', item.interpretation);
            if(!isEmpty(item.interpretation)){
              set(gridItem, 'interpretation.code', item.interpretation.coding.get('firstObject.code'));
            }
            set(gridItem, 'numberValue', null);
          }.bind(this));
        }
        //save 작업 위한
        set(currentItem, 'isUpdated', true);
        set(currentItem, 'isValueChanged', false);
        set(currentItem, 'isCleared', false);
        if(this.get('closedByKeyDown')==true){
          // this._moveFocus('down', false);
          this.set('closedByKeyDown', false);
        }
      }.bind(this)).catch(function(error){
        set(currentItem, 'isValueChanged', false);
        this.set('currentItem', null);
        this._catchError(error);
      }.bind(this));
    },
    _setCalculateValue(e){
      let value={};
      switch(e.valueTypeCode){
        case 'Quantity':
          value={
            quantity: {
              // value: numberValue 다 같은 값으로 업데이트됨
              value: e.isValueChanged? this.get('numberValue'): e.value.quantity.value,
              //value에 저장된값있는지 확인//diff일 경우 '-'
              comparatorCode: e.isValueChanged? e.comparatorSelectedItem: e.value.quantity.comparatorCode,
              unitCode: isEmpty(e.examinationUnit)? null: e.examinationUnit.code,
              unitName: isEmpty(e.examinationUnit)? null: e.examinationUnit.name
            },
            codeableConcept: null,
            valueString: e.isValueChanged? e.valueString : e.value.valueString
          };
          break;
        case 'CodeableConcept':
          value= e.value;
          break;
        default:
          break;
      }
      value.valueString= isEmpty(value.valueString)? null: value.valueString;
      return value;
    },

    _addObservationResult(e, value, isChange){
      return {
        isChange: isChange,
        examinationId: e.examinationId,
        observationResultId: e.observationResultId,
        valueTypeCode: e.valueTypeCode,
        // check: e.check,
        recentObservationResultId: isEmpty(e.recentObservationResult)? null: e.recentObservationResult.observationResultId,
        value: {
          quantity: value.quantity,
          codeableConcept: value.codeableConcept,
          valueDecimal: isEmpty(e.value.valueDecimal)? 0 : e.value.valueDecimal,
          valueString: value.valueString,
          valueBool: true,
        },
      };
    },
    _setQuantityValueString(item){
      let quantityValue= item.value.quantity.value;
      let comparator=item.value.quantity.comparatorCode;
      let valueString= item.value.valueString;
      if(isEmpty(quantityValue)){
        quantityValue= '';
      }
      if(comparator =='-' || isEmpty(comparator)){
        comparator= '';
      }
      if(isEmpty(valueString)){
        valueString= '';
      }
      return comparator+ ' ' + quantityValue + ' ' + valueString;
    },

    _setValueString(item){
      let valueValueString='';
      if(item.value.quantity.comparatorCode !='-' && !isEmpty(item.value.quantity.comparatorCode)){
        valueValueString= item.value.quantity.comparatorCode + item.value.quantity.value;
      }else{
        valueValueString= item.value.quantity.value;
      }
      return isEmpty(item.value.valueString)? valueValueString: valueValueString+item.value.valueString;
    },

    _moveFocus(moveType) {
      const grid = this.get('_gridControl');
      const rowIndex = this.get('_currentCell.rowIndex');
      const cellIndex = this.get('_currentCell.cellIndex');
      // const cellIndex = this.get('mode')=='general'? 1 : 13;
      let moveRow = 0;
      let moveColumn = 0;

      if(moveType === 'down') {
        moveRow = 1;
      } else if(moveType === 'self') {
        moveRow = 0;
        moveColumn = 0;
      }
      // else if(moveType === 'up') {
      //   moveRow = -1;
      // } else if(moveType === 'left') {
      //   moveColumn = -1;
      // } else if(moveType === 'right') {
      //   moveColumn = 1;
      // }
      next(this, function() {
        if(moveRow != 0) {
          grid.selectCell(rowIndex + moveRow, cellIndex);
          grid.focusCell(rowIndex + moveRow, cellIndex);
        } else if(moveColumn != 0) {
          grid.selectCell(rowIndex, cellIndex + moveColumn);
          grid.focusCell(rowIndex, cellIndex + moveColumn);
        } else if ( moveRow === 0 && moveColumn === 0) {
          grid.selectCell(rowIndex, cellIndex);
          grid.focusCell(rowIndex, cellIndex);
        }
      });
    },

    _catchError(e){
      this.set('isPopupShow',false);
      this.set('gridDisabled', false);
      this.showResponseMessage(e);
    }

  });