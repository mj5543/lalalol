import $ from 'jquery';
import { next } from '@ember/runloop';
import { copy } from '@ember/object/internals';
import EmberObject, { set } from '@ember/object';
import { inject as service } from '@ember/service';
import { isEmpty, isPresent } from '@ember/utils';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from '../../../app-config';
import MessageMixin from '../../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MessageMixin,
  /* Only For Server-Call Component
  CHIS.FR.CrossCutting.ServerCallMixin,
  */
  {
  /* 1. Service define Area
  testService:Ember.inject.service(),
  */
    layout,
    // 2. Property Area
    defaultUrl: null,
    specimenexaminationreportService: service('specimen-examination-report-service'),
    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      //this.set('menuClass', 'w1000');
      this.set('viewId','specimen-examination-report-result-entry-string');
      //Set Stateful properties
      this.setStateProperties([
        'defaultUrl',
      ]);
      if (this.hasState() === false) {
      //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')
      +`specimen-examination-report/${config.version}/`);

      }
    //Initialize Stateless properties
    },

    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
    // if (this.hasState() === false) {
    // }
    },
    // 4. Actions Area
    actions: {
      onChanged(){
        // const currentItem= this.get('currentItem');
        // if(this.get('valueString') == currentItem.valueString){
        //   //onTextCommit -> calculate 후
        //   return;
        // }
        // if(isEmpty(currentItem.preValueString)){
        //   set(currentItem, 'preValueString', copy(currentItem.get('value.valueString')));
        // }
        // if(isEmpty(currentItem.get('value'))){
        //   set(currentItem, 'value',{} );
        // }
        // set(currentItem, 'value.valueString', e.value);
      },
      onOpenedAction(e){
        this.set('isClosed', false);
        this.set('popup', e.source);
        const currentItemCopy= EmberObject.create(this.get('currentItem'));

        this.set('initialValueString', this.get('currentItem').value.valueString);
        if(isEmpty(currentItemCopy)){
          return;
        }
        this.set('valueString', null);

        next(this, function () {
          if(isEmpty(currentItemCopy.get('value.valueString'))){
            //최초입력
            if(currentItemCopy.isKeydown===true){
              this.set('valueString', currentItemCopy.key);
            }
          }else{
            //저장전
            this.set('valueString', currentItemCopy.value.valueString);
          }
          const selector = 'div[data-id=' + this.get('popup').elementId + ']';
          const popupDom = $(selector);
          let target = popupDom.find('[name=valueString]');
          target = target.find('input:first');
          target.parent().find('input').focus();
          next('this', function() {
            if(!isEmpty(currentItemCopy.get('value.valueString'))){
              //최초입력일 경우 select 안함
              target.parent().find('input').select();
            }
          });
        }.bind(this));
      },
      onPopupClosed(){
        //
      },

      onValueStringCommitAction(){
        this.set('isStringEntryOpen',false);
        const currentItem= this.get('currentItem');
        if(isEmpty(currentItem.preValueString)){
          set(currentItem, 'preValueString', copy(currentItem.get('value.valueString')));
        }
        if(isEmpty(currentItem.get('value'))){
          set(currentItem, 'value',{} );
        }
        set(currentItem, 'value.valueString', this.get('valueString'));
        set(currentItem, 'valueString', this.get('valueString'));
        this.set('isClosed', true);
        this.set('previousItem', this.get('currentItem'));
        this._calculate("Rule");
        const returnKeyDownValueCB = this.get('returnKeyDownValueCB');
        if(!isEmpty(returnKeyDownValueCB)) {
          returnKeyDownValueCB(null,null,null);
        }

      },

      onTextCleared(){
        const currentItem= this.get('currentItem');
        this.set('valueString', null);
        set(currentItem, 'isCleared', true);
        // set(currentItem, 'isValueChanged', true);
      },

      onConfirmedAction(){
        this.set('isStringEntryOpen',false);
        const previousItem= this.get('previousItem');
        const currentItem= this.get('currentItem');

        this.set('isClosed', true);
        this.set('previousItem', this.get('currentItem'));
        if(this.get('closedByKeyDown')==false){
          if(isEmpty(previousItem) && isEmpty(currentItem)){
            this.set('previousItem', copy(currentItem));
          }
          set(previousItem, 'valueString', this.get('valueString'));
          this._calculate("Rule");
        }else{
          set(currentItem, 'valueString', this.get('valueString'));
          this.set('previousItem', null);
          this._calculate("Rule");
        }
      },
    },
    // 5. Private methods Area
    _calculate(inputModeType){
      const currentItem= isEmpty(this.get('previousItem'))? this.get('currentItem'): this.get('previousItem');
      let valueString= this.get('valueString');

      if(isEmpty('currentItem')){
        return;
      }

      let resultListItemsSource=[];
      var selectedItemsTemp = this.get('selectedItems');
      if (isEmpty(selectedItemsTemp)) {
        //일반검사결과관리
        resultListItemsSource= this.get('resultListItemsSource');
      }else{
        //항목별검사결과관리 에서는 선택항목만 계산
        if(selectedItemsTemp.length==1 && !isEmpty(this.get('currentItem'))){
          //keydown으로 cell이동시 그리드 선택값과 focused cell이 다른 문제
          // if(Ember.isEmpty(this.get('previousItem')){
          // }else{
          if(this.get('previousItem') != this.get('currentItem')){
            selectedItemsTemp=[];
            selectedItemsTemp.addObject(this.get('currentItem'));
            this.set('currentItem', currentItem);
          }
        }else if(selectedItemsTemp.length>1){
          selectedItemsTemp=[];
          selectedItemsTemp.addObject(this.get('currentItem'));
        }
        this.set('currentItem', currentItem);
        // this.get('_gridControl').deselectRow(this.get('currentItem'));
        selectedItemsTemp.forEach(function (e) {
          resultListItemsSource.addObject(EmberObject.create(e));
        });
      }
      const observationResults= [];
      let value={};

      if(isEmpty(valueString)){
        // if(currentItem.isCleared != true){
        //   return;
        // }
      }
      // const valueString= this.get('valueString');
      const calculateArr=[];
      resultListItemsSource.forEach(element=>{
        const e=EmberObject.create(element);
        // if(e.isValueChanged && currentItem.examinationId==e.examinationId && currentItem.specimenId==e.specimenId){
        if(e.preValueString !== e.valueString){
          set(e, 'isValueChanged', true);
          calculateArr.addObject(e);
        }

        if(e.isCleared==true){
          value={
            quantity: {
              value: null,
              comparatorCode: null,
              unitCode: null,
              unitName: null,
            },
            codeableConcept:  value={
              coding: null,
              displayContent: null
            },
            valueString:null
          };
        }else{
          value= e.value;
        }
        if(currentItem.examinationId==e.examinationId && currentItem.specimenId==e.specimenId && e.value != currentItem.value
          && e.valueValueString != e.fullTextValue){
          set(e, 'isValueChanged', true);
        }else if(currentItem.examinationId==e.examinationId && currentItem.valueString != this.get('initialValueString')){
          set(e, 'isValueChanged', true);
        }else{
          set(e, 'isValueChanged', false);
        }
        if(e.isValueChanged != true){
          //calculate 대상 아닌 경우
          const tmp={
            isChange: false,
            examinationId: e.examinationId,
            observationResultId: e.observationResultId,
            valueTypeCode: e.valueTypeCode,
            recentObservationResultId: isEmpty(e.recentObservationResult)? null: e.recentObservationResult.observationId,
            value: {
              quantity: null,
              codeableConcept: null,
              valueDecimal: isEmpty(e.get('value.valueDecimal'))? 0 : e.value.valueDecimal,
              valueString: value.valueString,
              valueBool: true,
            },
          };
          observationResults.addObject(tmp);

          return;
        }
        const tmp={
          isChange: true,
          examinationId: e.examinationId,
          observationResultId: e.observationResultId,
          valueTypeCode: e.valueTypeCode,
          value: {
            quantity: null,
            codeableConcept: null,
            valueDecimal: isEmpty(e.get('value.valueDecimal'))? 0 : e.value.valueDecimal,
            valueString: valueString,
            valueBool: true,
          },
          recentObservationResultId: isEmpty(e.recentObservationResult)? null : e.recentObservationResult.observationId
        };

        observationResults.addObject(tmp);
      });
      const params={
        inputModeType: inputModeType,
        isPossibleInputItemId: true,
        subjectId: currentItem.subjectId,
        subjectTypeCode :  'Patient',
        specimenNumber: currentItem.specimenNumber,
        observationResults: observationResults
      };
      if(calculateArr.length==0){
        return;
      }
      this.set('gridDisabled', true);
      return this.ajaxSyncCall(this.get('defaultUrl') + 'observations/results/calculate', null,'POST',params,false).done(function(res){
        this.set('gridDisabled', false);
        if(isEmpty(res)){
          return;
        }
        const returnCalculatedValueCB = this.get('returnCalculatedValueCB');
        if (this.get('mode')=='results-by-item') {
          //항목별검사관리- 선택항목만 binding
          if(!isEmpty(returnCalculatedValueCB)) {
            returnCalculatedValueCB(res.get('firstObject'), currentItem);
          }
        }else{
          //일반검사관리
          if(!isEmpty(returnCalculatedValueCB)) {
            returnCalculatedValueCB(null);
          }
          this.get('resultListItemsSource').forEach(function(gridItem,gridItemIndex){
            let item=null;
            const changedItem=res.findBy('examinationId', gridItem.examinationId);
            if (this.get('mode')=='general' && !isEmpty(changedItem)){
              item= changedItem;
            }else if(this.get('mode')=='results-by-item'){
              item=res[gridItemIndex];
            }else{
              return;
            }
            const valueValueString= this.get('specimenexaminationreportService')._setValueString(item);
            if(item.valueTypeCode=='Quantity'){
              if(isPresent(item.value)){
                set(gridItem, 'valueValueString', valueValueString);
                set(gridItem, 'numericCellInputValue', valueValueString);
                set(gridItem, 'value', item.value);
              }
              if(gridItem.examinationId ==currentItem.examinationId){
                set(currentItem, 'a', true);
                set(currentItem, 'isUpdated', true);
              }

              if((gridItem.statusCode =='final' || gridItem.statusCode =='corrected') && (valueValueString == gridItem.valueValueString)){
                //검증상태이고 value가 같으면 isUpdated 업데이트 안함
                //gridItem: calculate 전 -> item, valueValueString: calculate 후
                set(currentItem, 'isUpdated', false);
              }
            }else if(item.valueTypeCode=='CodeableConcept'){
              this._setCodeableConceptValue(item, gridItem, valueValueString, currentItem);
            }else if(item.valueTypeCode=='ValueString' || item.valueTypeCode=='ValueTextString'){
              if(isPresent(item.value)){
                valueString= item.value.valueString;
                if(isEmpty(valueString)){
                  valueString= '';
                }
                set(gridItem, 'valueValueString', valueString);
                set(gridItem, 'numericCellInputValue', valueString);
                set(gridItem, 'value', item.value);
              }
              if(gridItem.examinationId ==currentItem.examinationId){
                set(currentItem, 'isUpdated', true);
                set(currentItem, 'preValueString', null);
              }
            }
            set(gridItem, 'check.isCritical', item.check.isCritical);
            set(gridItem, 'check.isDelta', item.check.isDelta);
            set(gridItem, 'check.isPanic', item.check.isPanic);
            set(gridItem, 'check.isRecentCritical', item.check.isRecentCritical);
            // if(gridItem.statusCode == "waiting"){
            if(gridItem.check.isNotAnalyticalMeasurementRange != item.check.isNotAnalyticalMeasurementRange){
              //calculate 후 달라졌을 경우만 업데이트
              set(gridItem, 'check.isNotAnalyticalMeasurementRange', item.check.isNotAnalyticalMeasurementRange);
            }
            set(gridItem, 'interpretation', item.interpretation);
            if(!isEmpty(item.interpretation)){
              set(gridItem, 'interpretation.code', item.interpretation.coding.get('firstObject.code'));
            }
            //save 작업 위한
          }.bind(this));
        }
        set(currentItem, 'isUpdated', true);
        set(currentItem, 'isValueChanged', false);
        set(currentItem, 'isCleared', false);

        if(this.get('closedByKeyDown')==true){
          // this._moveFocus('down', false);
          this.set('closedByKeyDown', false);
        }
      }.bind(this)).catch(function(error){
        set(currentItem, 'isValueChanged', false);
        this._catchError(error);
        this.set('currentItem', null);
      }.bind(this));
    },

    _setCodeableConceptValue(item, gridItem, valueValueString, currentItem){
      if(isPresent(item.value)){
        set(gridItem, 'valueValueString', valueValueString);
        set(gridItem, 'numericCellInputValue', valueValueString);
        set(gridItem, 'value', item.value);
      }
      if(gridItem.examinationId ==currentItem.examinationId){
        set(currentItem, 'isUpdated', true);
      }
    },

    _setQuantityValue(item){
      let quantityValue= item.value.quantity.value;
      let comparator=item.value.quantity.comparatorCode;
      let valueString= item.value.valueString;
      if(isEmpty(quantityValue)){
        quantityValue= '';
      }
      if(comparator =='-' || isEmpty(comparator)){
        comparator= '';
      }
      if(isEmpty(valueString)){
        valueString= '';
      }
      return comparator+ ' ' + quantityValue + ' ' + valueString;
    },

    // _setCodeableConceptValue(item){
    //   let example= null;
    //   if(isPresent(item.value.codeableConcept)){
    //     example= item.value.codeableConcept.displayContent;
    //   }
    //   let valueStringTmp= item.value.valueString;
    //   if(isEmpty(example)){
    //     example= '';
    //   }
    //   if(isEmpty(valueStringTmp)){
    //     valueStringTmp= '';
    //   }
    //   return example + ' '+ valueStringTmp;
    // },
    _moveFocus(moveType) {
      const grid = this.get('_gridControl');
      const rowIndex = this.get('_currentCell.rowIndex');
      const cellIndex = this.get('_currentCell.cellIndex');
      // const cellIndex = this.get('mode')=='general'? 1 : 13;
      let moveRow = 0;
      let moveColumn = 0;

      if(moveType === 'down') {
        moveRow = 1;
      } else if(moveType === 'self') {
        moveRow = 0;
        moveColumn = 0;
      }

      next(this, function() {
        if(moveRow != 0) {
          grid.selectCell(rowIndex + moveRow, cellIndex);
          grid.focusCell(rowIndex + moveRow, cellIndex);
        } else if(moveColumn != 0) {
          grid.selectCell(rowIndex, cellIndex + moveColumn);
          grid.focusCell(rowIndex, cellIndex + moveColumn);
        } else if ( moveRow === 0 && moveColumn === 0) {
          grid.selectCell(rowIndex, cellIndex);
          grid.focusCell(rowIndex, cellIndex);
        }
      });
    },

    _catchError(e){
      this.set('isCodeableConceptShow',false);
      this.set('gridDisabled', false);
      this.showResponseMessage(e);
    }
  });