import $ from 'jquery';
import { next, later } from '@ember/runloop';
import { isEmpty } from '@ember/utils';
import { set } from '@ember/object';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import MessageMixin from '../../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MessageMixin,
  {
    /* 1. Service define Area
     testService:Ember.inject.service(),
    */
    specimenexaminationreportService: service('specimen-examination-report-service'),
    layout,
    defaultUrl: null,
    diffEntryColumns: null,
    // diffEntryItemsSource: null,
    // isDiffEntryOpen: Ember.computed('resultListItemsSource', function() {

    // }),
    // diffEntryItemsSource: computed('isDiffEntryOpen', function() {
    //   if(this.get('isDiffEntryOpen') ==false){
    //     return;
    //   }
    //   this._diffEntryItemsSourceChanged();

    //   // this.set('selectedItem', this.get('diffEntryItemsSource.firstObject'));

    // }),
    totalKeyCount: null,
    isEntryBtnDisabled: null,
    diffFGrid: null,
    // diffEntryTarget: Ember.computed('')
    // 2. Property Area

    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-diff-entry');
      //Set Stateful properties
      this.setStateProperties([
        'diffEntryColumns',
        // 'diffEntryItemsSource',
        'menuClass',
        'totalKeyCount',
        'isEntryBtnDisabled',
        'diffFGrid'
      ]);
      if (this.hasState() === false) {
        //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')
        + `specimen-examination-report/v0/`);
        this.set('diffEntryColumns', [
          { title: this.getLanguageResource('16920', 'S','Exam Name'), field: 'examination.name',readOnly: true, width: 260},
          { title: this.getLanguageResource('890', 'F', 'Result'), field: 'count', type: 'number',
            enableGotFocusAutoSelect:true, min:0, max:100 },
        ]);
        this.send('onOpenedAction');
      }
      //Initialize Stateless properties
    },

    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1000');
      if (this.hasState() === false) {
        // this.$('#diffGrid').focus();
      }
    },


    // 4. Actions Area
    actions: {
      onkeydown(e){
        if(this.get('isEditMode')){
          return;
        }
        const key= e.key.toUpperCase();
        let totalKeyCount= this.get('totalKeyCount');
        const diffEntryItemsSource= this.get('diffEntryItemsSource');
        // let tmp=0;
        if(isEmpty(diffEntryItemsSource)){
          return;
        }

        if(totalKeyCount < 100){
          diffEntryItemsSource.forEach(element=>{
            if(isEmpty(element.functionType) || isEmpty(element.functionApply)){
              return;
            }
            if(element.functionType.code== 'None'){
              //functionType=None Value 에 상관없이 total Count, count 모두 증가안함
              return;
            }
            if(element.functionApply.valueString === key){
              //sum 타입인데 value가 없으면 totalKeyCount 증가 안함
              set(element,'count', isEmpty(element.count)? parseInt(element.functionType.valueString) : parseInt(element.count) + parseInt(element.functionType.valueString));

              this.set('totalKeyCount', totalKeyCount +=1);
              if(totalKeyCount ==100 ){
                this.set('isEntryBtnDisabled', false);
                next(this, function () {
                  const target = $('[tabindex=2]');

                  later(this, function() {
                    target.get(0).focus();
                    this.set('totalKeyCount', 100);
                  }, 50);
                }.bind(this));
              }
            }
          });
        }else{
          this.set('isEntryBtnDisabled', false);
          next(this, function () {
            const target = $('[tabindex=2]');

            later(this, function() {
              target.get(0).focus();
              this.set('totalKeyCount', 100);
            }, 50);
          }.bind(this));
        }
      },

      onEditStart(e){
        this.set('isEditMode', true);
        this.set('preValue', isEmpty(e.item.count)? 0: parseInt(e.item.count));
      },
      onEditEnd(e){
        this.set('isEditMode', false);
        const preValue= this.get('preValue');
        const totalKeyCount= this.get('totalKeyCount');

        if(preValue==e.item.count){
          return;
        }else if(e.item.count > 100 || (e.item.count + totalKeyCount > 100)){
          if(preValue > e.item.count || e.item.count - preValue + totalKeyCount <= 100){
            // 입력값 감소한경우
            const currentValue= parseInt(e.item.count);
            this._count(currentValue, e.item.count-preValue);
            return;
          }
          //입력 이전 값 으로 되돌림
          set(e, 'item.count', preValue);
          this.set('totalKeyCount', totalKeyCount + e.item.count-preValue);
          this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9237', 'S', '값 범위를 확인하세요.'), 'warning', 'Ok', 'Ok', '', 2000);

          return;
        }
        const currentValue= parseInt(e.item.count);
        this._count(currentValue, e.item.count-preValue);
      },

      onOpenedAction(){
        this.set('isDiffGridShow', true);
        this.set('diffEntryItemsSource', null);
        this.set('totalKeyCount',0);
        this.set('isEntryBtnDisabled', true);
        const resultListItemsSource= this.get('resultListItemsSource');

        if(isEmpty(resultListItemsSource)){
          this.set('isDiffGridShow', false);
          return;
        }
        const examinations = resultListItemsSource.map(function(item){
          return $.extend(true, {}, {examinationId: item.examinationId, exampleTypeCode: 'DiffEntry'});
        });
        const params ={examinations};
        this.create(this.get('defaultUrl') + 'observations/examples/search', null, params).then(res=>{
          this.set('isDiffGridShow', false);
          res.forEach(element =>{
            set(element, 'count', null);
          });
          this.set('diffEntryItemsSource', res);
          this.get('diffEntryItemsSource').sortBy('displaySequence');
          // this.$('#diffGrid').focus();
          let gridEl = document.getElementById(this.get('gridSource.elementId'));
          gridEl.focus();
          gridEl = null;
        }).catch(function(error){
          this._catchError(error);
        }.bind(this));
        this.set('selectedItem', this.get('diffEntryItemsSource.firstObject'));
      },
      onGridLoaded(e) {
        this.set('gridSource', e.source);
      },
      onClosedAction(){
        // this.set('isDiffEntryOpen', false);
        // this.set('diffEntryItemsSource', null);
        // this.set('preValue', null);
      },

      onEntryClick(){
        this._return();
      },
    },

    // 5. Private methods Area
    _count(input, num){
      const totalKeyCount= this.get('totalKeyCount');
      const preValue= this.get('preValue');
      if(totalKeyCount - preValue + input >= 100 && num > 0){
        this.set('isEntryBtnDisabled', false);
        next(this, function () {
          const target = $('[tabindex=2]');
          later(this, function() {
            target.get(0).focus();
            this.set('totalKeyCount', 100);
          }, 50);
        }.bind(this));
      }else{
        //최초 100입력시
        // this.set('isEntryBtnDisabled', true);
        this.set('totalKeyCount', totalKeyCount + num);
      }
    },
    _return(){
      this.set('isDiffEntryOpen', false);
      const returnResultValueCB = this.get('returnResultValueCB');
      // const resultListItemsSource= this.get('resultListItemsSource');

      if(!isEmpty(returnResultValueCB)) {
        const array = this.get('diffEntryItemsSource').map(function(e){
          return $.extend(true, {}, e);
        });
        returnResultValueCB($.extend(true, [], array));
        this.set('diffEntryItemsSource', null);
      }
    },

    _catchError(e){
      this.set('isResultGridShow',false);
      this.showResponseMessage(e);
    }

  });