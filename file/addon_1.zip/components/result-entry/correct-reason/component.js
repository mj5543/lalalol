/* eslint-disable prefer-named-capture-group */
import { copy } from '@ember/object/internals';
import $ from 'jquery';
import { isEmpty } from '@ember/utils';
import { next } from '@ember/runloop';
import { hash } from 'rsvp';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'specimenexaminationreport-module/app-config';
import MessageMixin from '../../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MessageMixin,
  {
    layout,
    // 2. Property Area
    defaultUrl: null,
    isCorrectReasonEntryOpened: false,
    onPropertyInit(){
      this._super(...arguments);
      //this.set('menuClass', 'w1000');
      this.set('viewId','result-entry-correct-reason');
      //Set Stateful properties
      this.setStateProperties([
        'defaultUrl',
      ]);
      if (this.hasState() === false) {
      //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')
        + `specimen-examination-report/${config.version}/`);
      }
    //Initialize Stateless properties
    },

    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w800');
      if (this.hasState() === false) {
        const defaultUrl = this.get('defaultUrl');
        hash({
          editReasionItemsSource: this.getList(defaultUrl + 'business-codes/search', {classificationCode: 'ObservationResultChangeReason'}, null),
          // editReasionItemsSource: ,

        }).then(function(result) {
          this.set('editReasionItemsSource', result.editReasionItemsSource);
          next(this, function(){
            if(this.isDestroyed || this.isDestroying) {
              return;
            }
            this.set('editReasonSelectedItem', result.editReasionItemsSource.get('firstObject'));

          }.bind(this));
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      }
    },
    // 4. Actions Area
    actions: {
      // onOpenCenterAction() {
      //   this.set('isCenterOpen', true);
      // },
      onPopupOpenedAction() {
        this.set('addRemark', false);
        this.set('remark', this.get('currentItem.remark') );
        this.set('editReasonSelectedItem', this.get('editReasionItemsSource.firstObject'));
        if(!isEmpty( this.get('resultListItemsSource'))){
          this.set('gridItemsSource', $.extend(true, [], this.get('resultListItemsSource').map(function(e){
            return $.extend(true, {}, e);
          })));

        }
      },

      onPopupClosedAction(){
        // this.set('isResultGridShow', false);
      },

      onReasonSelectionChanged(){
        if(this.get('editReasonSelectedItem.code') == 'ReasonETC'){
          this.set('reasonsInputDisabled', false);
        }else{
          this.set('reasonsInputDisabled', true);
          this.set('textareaValue', null);
        }
      },

      onConfirmClick(){
        this.set('isCorrectReasonEntryOpened', false);
        let tmp='';
        if(this.get('addRemark')){
          //결과비고에 추가
          this.ajaxSyncCall(this.get('defaultUrl') + 'business-codes/search', {classificationCode: 'ObservationResultChangeReasonResultDefaultComment'},'GET',null,false).done(function(res){
            tmp=isEmpty(this.get('currentItem.remark'))? tmp : this.get('currentItem.remark')+'<br/>';
            tmp=isEmpty(res.get('firstObject.name'))? tmp: tmp + res.get('firstObject.name') +'<br/>';
            tmp=isEmpty(this.get('textareaValue'))? tmp: tmp+ this.get('textareaValue').replace(/\n|\r\n/giu, '<br>');
            this.set('remark', tmp);
          }.bind(this));
        }
        const editReasonSelectedItem= this.get('editReasonSelectedItem');
        const returnChangesReasonCB = this.get('returnChangesReasonCB');
        if(!isEmpty(returnChangesReasonCB)) {
          const res={
            code: editReasonSelectedItem.code,
            name:isEmpty(this.get('textareaValue'))? editReasonSelectedItem.name
              : copy(this.get('textareaValue').replace(/(\n|\r\n)/gu, '<br>'))
          };
          returnChangesReasonCB(res, tmp, this.get('gridItemsSource'));
        }
      },
      onCancelClick() {
        if(!isEmpty(this.get('reasonEntryCancel'))) {
          this.get('reasonEntryCancel')();
        }
      }
    },

    _catchError(e){
      this.showResponseMessage(e);
    }
    // 5. Private methods Area
  });