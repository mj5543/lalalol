/* eslint-disable prefer-named-capture-group */
/* eslint-disable no-console */
import $ from 'jquery';
import { isEmpty } from '@ember/utils';
import { A as emberA } from '@ember/array';
// import { set } from '@ember/object';
// import { next } from '@ember/runloop';
import layout from './template';
import CHIS from 'framework/chis-framework';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';
import PrintMixin from 'specimenexaminationreport-module/mixins/specimen-examination-report-print-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  PrintMixin,
  MessageMixin,
  {
    layout,
    isShowLoader: false,
    isIdentificationOpen: false,
    identificationTarget: null,
    loaderType: 'spinner',
    loaderDimed: null,
    isMonitringDisabled: true,
    isSwitchChecked: false,
    isSwitchDisabled: true,
    isRecordOpen: false,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-microbe-incubation-positive-patient-search');

      this.setStateProperties([
        'defaultColumns',
        'gridColumns',
        'gridItems',
        'gridSource',
        'searchPatientInfo',
        'searchPatientId',
        'urlPrefix',
        'examinationItems',
        'departmentItems',
        'wardItems',
        'bacterialItems'
      ]);
      if (!this.hasState()) {
        this.set('model', {
          gridSelectedItem: null,
          selectedExaminationCode: null,
          selectedExamination: null,
          selectedBacterialCode: null,
          selectedBacterialName: null,
          selectedBacterialAbbreviation: null,
          selectedDepartmentCode: null,
          selectedWardCode: null,
          isArriveAfter: false,
          selectedWardItem: null,
          selectedDepartmentItem: null,
          isArriveWithin: false,
        });
        const defaultUrl = this.get('fr_HostConfigService')
          .getEnvConfig('ServerCallConfig', 'specimenexaminationreport') +
          `specimen-examination-report/v0`;
        this.set('urlPrefix', defaultUrl);
        const displayDate = new Date(this.get('co_CommonService').getNow());
        this.set('defaultColumns', [
          { field: 'patient.displayNumber', title: this.getLanguageResource('8451', 'S', '', '환자번호'), width: 70, align: 'center', locked:true, bodyTemplateName:'boldText'},
          { field: 'patient.name', title: this.getLanguageResource('16881', 'S', '', '환자명'), width: 70, align: 'center',locked:true, bodyTemplateName:'boldText'},
          { field: 'patient.gender', title: this.getLanguageResource('3680', 'S', null, '성별'), width: 35, align: 'center'},
          { field: 'patient.age', title: this.getLanguageResource('1662', 'S', null, '나이'), width: 35, align: 'center'},
          { field: 'patient.birthdate', title: this.getLanguageResource('3480', 'S', '', '생년월일'), width: 80, align: 'center', type: 'date', dataFormat: 'd',},
          { field: 'encounterType.name', title:  this.getLanguageResource('16963', 'S','구분'), width: 50, align: 'center', bodyTemplateName: 'textTooltip'},
          { field: 'issuedDepartment.name', title:  this.getLanguageResource('8827', 'S','발행처'), width: 70, align: 'center', bodyTemplateName: 'textTooltip'},
          { field: 'department.name', title: this.getLanguageResource('1113', 'S','진료과'), width: 70, align: 'center', bodyTemplateName: 'cellTooltip'},
          { field: 'ward.displayCode', title:  this.getLanguageResource('2749', 'S','병동'), width: 50, align:'center', bodyTemplateName: 'textTooltip'},
          { field: 'room.roomCode', title:  this.getLanguageResource('2825', 'S','병실'), width: 50, align:'center', bodyTemplateName: 'textTooltip'},
          { field: 'icuCheckOutDatetime', title: this.getLanguageResource('17435', 'S', '', 'ICU퇴실(2일 이내)'), width: 105, align: 'center', type: 'date', dataFormat: 'd',},
          { field: 'orderName', title: this.getLanguageResource('5218', 'S', '', '오더명'), width: 120, bodyTemplateName:'cellTooltip'},
          { field: 'specimenNumber', title: this.getLanguageResource('859', 'S', '', '검체번호'), width: 80, align:'center', bodyTemplateName: 'textTooltip'},
          { field: 'specimenType.name', title: this.getLanguageResource('840', 'S', '', '검체'), width: 60, bodyTemplateName: 'cellTooltip'},
          { field: 'samplingDate', title: this.getLanguageResource('798', 'S', '', '채혈일'), width: 80, align: 'center', type: 'date', dataFormat: 'd',},
          { field: 'checkInDate', title: this.getLanguageResource('6777', 'S', '', '접수일'), width: 80, align: 'center', type: 'date', dataFormat: 'd',},
          { field: 'checkInNumber', title: this.getLanguageResource('6767', 'S', '', '접수번호'), width: 70, align:'center'},
          { field: 'interpretatedDate', title: this.getLanguageResource('7954', 'S', '', '판독일'), width: 80, align: 'center', type: 'date', dataFormat: 'd',},
          { field: 'visitStartDate', title: this.getLanguageResource('6366', 'S', '', '입원일'), width: 80, align: 'center', type: 'date', dataFormat: 'd',},
          { field: 'visitEndDate', title: this.getLanguageResource('7821', 'S', '', '퇴원일'), width: 80, align: 'center', type: 'date', dataFormat: 'd',},
          { field: 'identificationName', title: this.getLanguageResource('2052', 'S', '', '동정결과'), width: 130, bodyTemplateName: 'identificationTooltip'},
          { field: 'specifiedResultTextString', title: this.getLanguageResource('17110', 'S', '', '검사결과'), width: '120', bodyTemplateName: 'specifiedResultTooltip', hidden: false, },
          { field: 'mediaName', title: this.getLanguageResource('11040', 'S', '', '배지종류'), width: 80},
          { field: 'interpretationContent', title: this.getLanguageResource('11043', 'S', '', '집락'), width: 70},
          { field: 'colonySequence', title: this.getLanguageResource('2698', 'S', '', '번호'), align: 'center', width: 50},
          { field: 'characterizationContent', title: this.getLanguageResource('9906', 'S', '', '성상결과'), width: 100, bodyTemplateName: 'textTooltip'},
          { field: 'colonyContent', title: this.getLanguageResource('11042', 'S', '', '정도'), width: 70, bodyTemplateName: 'textTooltip'},
          { field: 'identificationCode', title: this.getLanguageResource('11041', 'S', '', '동정코드'), width: 70, align:'center', bodyTemplateName: 'textTooltip'},
        ]);
        this._dataReset();
        this.set('selectedFromDate', displayDate);
        this.set('selectedToDate', displayDate);
      }

    },

    onLoaded() {
      this._super(...arguments);

      this.set('menuClass', 'w1360');
      this._getBusinessCodeList();
      this._getConditionsList();
      // this.getDataList();
    },
    actions: {
      onGridCellDoubleClick(e) {
        if(isEmpty(e.item.recordNoteId)) {
          this.set('isRecordOpen', false);
          return;
        }
        this.set('recordId', e.item.recordNoteId);
        this.set('recordTitle', e.item.orderName);
        this.set('isRecordOpen', true);
      },
      onGetPatient(item) {
        console.log('onGetPatient--', item);
        this.set('searchPatientInfo', item);
        this.set('patientInfoTooltip',`${item.primaryFullName} ( ${item.displayId} )`);
        const content = `${item.primaryFullName} (${item.displayId}/${item.genderCodeName}/${item.medicalAge}${this.getLanguageResource('3703', 'F', '', '세')})`;
        this.getGridItemList(content);
        // this.getDatas();
      },
      onCleareSearch() {
        this.set('searchPatientInfo', null);
        this.set('patientInfoTooltip', null);
      },
      onSearchAction() {
        // this.getDataList();
        this.getGridItemList();
      },
      onGridLoaded(e) {
        this.set('gridSource', e.source);
      },
      onGridSelectionChanged(e) {
        if(!isEmpty(e.selectedItems)) {
          this.set('isMonitringDisabled', false);
        } else {
          this.set('isMonitringDisabled', true);
        }
      },
      // onPopupsIdentificationGridSelectedAction(e) {
      //   if(!isEmpty(e.selectedItems)) {
      //     const selectedItem = e.selectedItems[0];
      //     this._setPopupSusceptibilitysGrid(selectedItem.bacterialIdentificationRelated.targetObservationId);
      //   }

      // },
      onFromToUpdated(e) {
        const fromDate = this.get('fr_I18nService').formatDate(e.selectedFromDate, 'd');
        const toDate = this.get('fr_I18nService').formatDate(e.selectedToDate, 'd');
        // const fromDate = `${e.fromYear}-${e.fromMonth}-${e.fromDate}`;
        // const toDate = `${e.toYear}-${e.toMonth}-${e.toDate}`;
        this.getGridItemList(`${fromDate} ~ ${toDate}`);
      },
      onFindBacterial(e) {
        this.set('isIdentificationOpen', true);
        this.set('identificationTarget', e.originalEvent.currentTarget);
      },
      onBacterialTextCleared() {
        this.set('model.selectedBacterialCode', null);
        this.set('model.selectedBacterialName', null);
      },
      onSwitchChanged() {
        this.set('model.selectedBacterialCode', null);
        this.set('model.selectedBacterialName', null);
      },
      onReturnIdentification(returnItems) {
        // console.log('onReturnIdentification', returnItems);
        if (!isEmpty(returnItems)) {
          this.set('model.selectedBacterialCode', returnItems.displayCode);
          this.set('model.selectedBacterialName', returnItems.name);
          this.getGridItemList(`${returnItems.name}`);
          this.set('isIdentificationOpen', false);
        }
      },
      onMonitoringClick() {
        this._saveMonitorings();
      },
      onExportExcel() {
        this._getExportExcel();
      },
      onBacterialChanged(e) {
        let itemName = null;
        if(!isEmpty(e.item)) {
          this.set('model.selectedBacterialCode', e.item.code);
          itemName = e.item.abbreviation;
          this.set('model.selectedBacterialAbbreviation', itemName);
          this.getGridItemList(`${this.getLanguageResource('9528', 'S', '', '균동정')} : ${itemName}`);
        } else {
          this.set('model.selectedBacterialAbbreviation', null);
          this.set('model.selectedBacterialCode', null);
          this.getGridItemList();
        }
      },
      onBeforeChagned(e) {
        if(e.checked) {
          this.set('model.isArriveAfter', false);
        }
      },
      onAfterChagned(e) {
        if(e.checked) {
          this.set('model.isArriveWithin', false);
        }
      },
    },

    _dataReset() {
      this._gridReset();
      this.set('formReset', !this.get('formReset'));
      this.set('searchPatientInfo', null);
      this.set('searchPatientId', null);
      this.set('patientInfoTooltip', null);
    },

    _gridReset() {
      this.set('gridItems', emberA());
      this.set('gridColumns', $.extend(true, [], this.get('defaultColumns')));
    },

    getDataList() {
      this._dataReset();
      this.getGridItemList();
    },

    async getGridItemList(refreshContent) {
      try {
        this.set('loaderDimed', false);
        this.set('loaderType', 'spinner');
        this.set('isShowLoader', true);
        this._gridReset();
        const selectedBacterialCode = this.get('model.selectedBacterialCode');
        const fromDate = this._getDateFormat(this.get('selectedFromDate'));
        const toDate = this._getDateFormat(this.get('selectedToDate'));
        const params = {
          fromDate: fromDate,
          toDate: toDate,
          isBacterialCodeSearch: this.get('isSwitchChecked'),
          departmentId: this.get('model.selectedDepartmentCode') === 'All' ? null : this.get('model.selectedDepartmentCode'),
          wardId: this.get('model.selectedWardCode') === 'All' ? null : this.get('model.selectedWardCode'),
          examinationType: this.get('model.selectedExamination.code') === 'All' ? null : this.get('model.selectedExamination.code'),
          bacterialValue: selectedBacterialCode === 'All' ? null : selectedBacterialCode,
          patientId: this.get('searchPatientInfo.patientId'),
          isArriveAfter: this.get('model.isArriveAfter'),
          isArriveWithin: this.get('model.isArriveWithin'),
        };
        const result = await this.getList(`${this.get('urlPrefix')}/infection-management/microbe-incubation/positive-patient`, null, params, false);
        if(!isEmpty(refreshContent)) {
          this.showToastRefresh(refreshContent);
        }
        if (!isEmpty(result)) {
          result.map(item => {
            let interpretationContent = '';
            if(!isEmpty(item.interpretation)) {
              interpretationContent = item.interpretation.displayContent;
            }
            let mediaName = '';
            if(!isEmpty(item.mediaCode)) {
              mediaName = item.mediaCode.name;
            }
            let identificationNameText = '';
            let specifiedResultText = '';
            if(!isEmpty(item.identificationName)) {
              identificationNameText = item.identificationName.replace(/(\n|\r\n)/gu, '<br>');
            }
            if(!isEmpty(item.specifiedResultTextString)) {
              specifiedResultText = item.specifiedResultTextString.replace(/(\n|\r\n)/gu, '<br>');
            }
            item.identificationNameTooltip = identificationNameText;
            item.specifiedResultTooltip = specifiedResultText;
            item.interpretationContent = interpretationContent;
            item.mediaName = mediaName;
            if(!isEmpty(item.susceptibilityResult)) {
              const uniqItems = item.susceptibilityResult.uniqBy('antibioticExaminatoin.abbreviation');
              uniqItems.forEach(d => {
                item[d.antibioticExaminatoin.abbreviation] = d.result.coding[0].code;
              });
            }
          });
          this.set('dataResult', result);
          this._setGridColumns();
          this.set('gridItems', result);
        }
        this.set('isShowLoader', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowLoader', false);
        }
        this._showError(e);
        console.log('getGridItemList Error :::::', e);
      }

    },
    async _getBusinessCodeList() {
      try{
        this.set('isShowLoader', true);
        const examinationResult = await this.getBusinessCodes('MicrobeIncubationExamination');
        const examinationConditions = examinationResult.uniqBy('abbreviation');
        const examinationComboitesm = [
          {abbreviation: this.getLanguageResource('6700', 'F', '', '전체'), code: 'All'},
          ...examinationConditions
        ];
        this.set('examinationItems', examinationComboitesm);
        this.set('model.selectedExaminationCode', 'All');
        this.set('model.selectedExamination', examinationComboitesm[0]);
        const antibioticResult = await this.getBusinessCodes('MicrobeIncubationAntibiotic');
        this.set('antibioticList', antibioticResult);
        this.getGridItemList();
      }catch(e) {
        console.log('_getBusinessCodeList Error::', e);
        this._showError(e);
      }
    },
    async _getConditionsList() {
      try {
        this._getBacterialItems();
        const department = await this._getDepartmentsSearch({businessGroupCode: 'OPD'});
        const departmentItems = [
          {name: this.getLanguageResource('6700', 'F', '', '전체'), id: 'All'},
          ...department
        ];
        this.set('departmentItems', departmentItems);
        this.set('model.selectedDepartmentCode', 'All');
        const ward = await this._getDepartmentsSearch({businessGroupCode: 'WARD'});
        const wardItems = [
          {name: this.getLanguageResource('6700', 'F', '', '전체'), id: 'All'},
          ...ward
        ];
        this.set('wardItems', wardItems);
        this.set('model.selectedWardCode', 'All');
      } catch(e) {
        this._showError(e);
      }
    },
    _getDepartmentsSearch(param) {
      return this.getList(`${this.get('urlPrefix')}/departments/search`, param, null);
    },

    async _getBacterialItems() {
      try {
        const result = await this.getList(`${this.get('urlPrefix')}/infection-management/microbe-incubation/identification-result-key-code`, null, null);
        if(!isEmpty(result)) {
          const items = [
            {abbreviation: this.getLanguageResource('6700', 'F', '', '전체'), code: 'ALL'},
            ...result
          ];
          this.set('model.selectedBacterialAbbreviation', this.getLanguageResource('6700', 'F', '', '전체'));
          this.set('model.selectedBacterialCode', 'ALL');
          this.set('bacterialItems', items);
          this.set('isSwitchDisabled', false);
        }
      } catch(e) {
        this.showToastApiError();
      }
    },
    async _getBacterialIdentifications() {
      try {
        const result = await this.getList(`${this.get('urlPrefix')}/bacterial-identifications`, null, null);
        const bacterialItems = [
          {displayCode: 'All', name: this.getLanguageResource('6700', 'F', '', '전체')},
          ...result
        ];
        this.set('bacterialItems', bacterialItems);
        this.set('model.selectedBacterialCode', 'All');
      } catch(e) {
        console.log('_getBacterialIdentifications Error :::::', e);
      }
    },
    async _saveMonitorings() {
      try {
        this.set('loaderDimed', true);
        this.set('loaderType', 'progress');
        this.set('isShowLoader', true);
        this.set('isMonitringDisabled', true);
        const params = {
          monitorings: this._getSaveParams()
        };
        await this.create(`${this.get('urlPrefix')}/infection-management/microbe-incubation/monitorings`, null, params, false);
        this.get('gridSource').deselectAll();
        this.showToastSaved();
        this.set('isShowLoader', false);
      } catch(e) {
        this._showSaveError(e);
        this.set('isShowLoader', false);
        console.log('_saveMonitorings Error:::', e);
      }
    },
    _getSaveParams() {
      const targetItems = this.get('gridSource').selectedItems;
      const returnArr = [];
      targetItems.forEach(item => {
        let tempObj = {};
        tempObj = {
          patientId: item.patient.patientId,
          encounterId: item.encounterId,
          sourceCode: null,
          departmentId: item.department.id,
          wardId: isEmpty(item.ward) ? null : item.ward.id,
          roomId: isEmpty(item.room) ? null : item.room.id
        };
        returnArr.push(tempObj);
      });
      return returnArr;
    },
    getBusinessCodes(code) {
      const param = {classificationCode: code};
      return this.getList(`${this.get('urlPrefix')}/business-codes/search`, param, null);
    },
    _setGridColumns() {
      const defaultColumns = $.extend(true, [], this.get('defaultColumns'));
      const customColumns = [];
      // const susceptibilityResult = this.get('dataResult.susceptibilityResult');

      const antibiotics = this.get('antibioticList');
      const tempArr = [];
      antibiotics.forEach(item => {
        const findItem = this.get('dataResult').find(d=> d[item.abbreviation]);
        if(!isEmpty(findItem)) {
          tempArr.push(item);
        }
      });
      const uniqitems = tempArr.uniqBy('abbreviation');
      uniqitems.forEach(item => {
        customColumns.push({ field: item.abbreviation, title: item.abbreviation, width: 40, align: 'center'});
      });
      defaultColumns.push(...customColumns);
      this.set('gridColumns', defaultColumns);

    },
    _getDateFormat(date) {
      return new Date(date.getFullYear(), date.getMonth(), date.getDate()).toFormatString();
    },
    _getExportExcel() {
      const gridItemsSource = this.get('gridItems');
      const firstRow = [];
      const colInfo = [];
      const columns = this.get('gridColumns');
      columns.forEach(column => {
        if(!isEmpty(column.field)) {
          firstRow.push(column.title);
          colInfo.push({wpx: column.width});
        }
      });
      const initArr = [firstRow];
      const resultArr = [];
      gridItemsSource.forEach(datas => {
        const tempArr = [];
        columns.forEach(col => {
          if(!isEmpty(col.field)) {
            const fields = col.field.split('.');
            let fieldsData = datas[col.field];
            if(fields.length > 1) {
              if(isEmpty(datas[fields[0]])) {
                fieldsData = '';
              } else {
                fieldsData = datas[fields[0]][fields[1]];
              }
            }
            tempArr.push(fieldsData);
          }
        });
        resultArr.push(tempArr);
      });
      this.getExportByArrayTypeExcel(initArr, resultArr);
    },

  });