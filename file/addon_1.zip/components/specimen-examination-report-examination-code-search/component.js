import { isEmpty } from '@ember/utils';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'specimenexaminationreport-module/app-config';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MessageMixin,
  /* Only For Server-Call Component
  CHIS.FR.CrossCutting.ServerCallMixin,
  */
  {
    // specimenexaminationreportService: service('specimen-examination-report-service'),

    layout,
    // 2. Property Area
    searchKey: null,
    examListItemsSource: null,
    examListSelectedItem: null,
    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-examination-code-search');
      //Set Stateful properties
      this.setStateProperties([
        'searchKey',
        'examListItemsSource',
        'examListSelectedItem'
      ]);
      if (this.hasState() === false) {
      //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')
        + `specimen-examination-report/${config.version}/`);
        this.set('examListColumns', [
          { field: 'displayCode', title: this.getLanguageResource('16919', 'S','Exam Code'), bodyTemplateName: 'tooltip', width:90},
          { field: 'name', title: this.getLanguageResource('16920', 'S','Exam Name'), bodyTemplateName: 'tooltip', width:250 },
        ]);
        this._init();

        this._search(this.get('selectedOption'));
      }
    },

    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w680');
    },
    // 4. Actions Area
    actions: {
      onSearchClick(){
        this._search(this.get('selectedOption'));
      },

      onSearchKeyCommit(){
        this._search(this.get('selectedOption'));
      },

      onSelectClick(){
        if(isEmpty(this.get('examListSelectedItem'))){
          return;
        }
        this._returnValue();
      }
    },

    // 5. Private methods Area
    _init(){
      this.set('searchKey', null);
    },

    _search(selectedOption){
      this.set('isLoaderShow', true);
      const params={
        selectedOption: isEmpty(selectedOption)? null : selectedOption,
        classificationId: null,
        parameterId: null,
        searchKey: this.get('searchKey')
      };
      this.getList(this.get('defaultUrl') + 'specimen-examinations/search',params , null).then(function(res){

        this.set('isLoaderShow', false);
        if(isEmpty(res)){
          this.set('examListItemsSource', null);
          this.set('examListSelectedItem', null);
          // this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9264', 'F', '조회된 정보가 없습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        this.set('examListItemsSource', res);
      }.bind(this)).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    _returnValue(){
      const returnCodeValueCB = this.get('returnCodeValueCB');

      if(!isEmpty(returnCodeValueCB)) {
        returnCodeValueCB(this.get('examListSelectedItem'));
        // this.set('isCodeSeachOpen', false);
      }
    },

    _catchError(e){
      this.set('isLoaderShow',false);
      this.showResponseMessage(e);
    }
  });