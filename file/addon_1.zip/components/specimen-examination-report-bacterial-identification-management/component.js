import { copy } from '@ember/object/internals';
import { next } from '@ember/runloop';
import { isEmpty } from '@ember/utils';
import { hash } from 'rsvp';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MessageMixin,
  /* Only For Server-Call Component
  CHIS.FR.CrossCutting.ServerCallMixin,
  */
  {
  /* 1. Service define Area
  testService:Ember.inject.service(),
  */
    specimenexaminationreportService: service('specimen-examination-report-service'),
    layout,
    // 2. Property Area
    defaultUrl: null,
    returnedItem: null,
    item: null,
    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-germ-management');
      //Set Stateful properties
      this.setStateProperties([
        'defaultUrl',
        'typeItemsSource',
        'subtypeItemsSource',
        'item'
      ]);
      if (this.hasState() === false) {
        //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')+ `specimen-examination-report/v0/`);
        this._initItem();
      }
    },

    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1000');
      if (this.hasState() === false) {
        const defaultUrl = this.get('defaultUrl');
        hash({
          sampleItemsSource: this.getList(defaultUrl + 'susceptibilitys/search', null, {
            "displayCode": null,
            "name": null
          },false),
          businessCodes: this.getList(defaultUrl + 'business-codes/search', null,{
            classificationCodes: [
              'BacterialTypeCode','BacterialSubTypeCode'
            ]
          }, false),
        }).then(function(result) {
          const typeItemsSource= [];
          const subtypeItemsSource= [];
          result.businessCodes.forEach(e=>{
            if(e.classificationCode == 'BacterialTypeCode'){
              typeItemsSource.addObject(e);
            }else if(e.classificationCode == 'BacterialSubTypeCode'){
              subtypeItemsSource.addObject(e);
            }
          });
          this.set('typeItemsSource', typeItemsSource);
          this.set('subtypeItemsSource', subtypeItemsSource);
          this.set('sampleItemsSource', result.sampleItemsSource);
          this.set('item', this.get('returnedItem'));
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      }
    },
    // 4. Actions Area
    actions: {
      returnIdentification(e){
        if(!isEmpty(e)){
          this.set('returnedItem', e);
          this.get('gridControl').selectRow(e);
        }else{
          next(this, function () {
            this._initItem();
          }.bind(this));
        }
      },
      onCodeInputLoaded(e) {
        let inputdEl = document.getElementById(e.source.elementId).getElementsByTagName('input')[0];
        this.set('codeInputElement', inputdEl);
        inputdEl = null;
      },

      onNewClick(){
        this.get('gridControl').deselectRow(this.get('gridSelectedItem'));
        this._initItem();
        this.get('codeInputElement').focus();
      },

      onSaveClick(){
        const item= this.get('item');
        let promise;
        if(isEmpty(item.displayCode) || isEmpty(item.name)
        || isEmpty(item.bacterialType)){
          this.get('specimenexaminationreportService').onShowToast('error', this.getLanguageResource('8945', 'F', '필수값을 입력하세요.'), '');
          return;
        }
        let bacterialTypeCode= item.bacterialType.code;
        let bacterialSubTypeCode= item.bacterialSubType.code;
        if(isEmpty(bacterialTypeCode)){
          //To-do displaycode으로 selectedItem 바인딩 못한경우
          bacterialTypeCode= this.get('typeItemsSource').findBy('displayCode', item.bacterialType.displayCode).code;
        }
        if(isEmpty(bacterialSubTypeCode)){
          bacterialSubTypeCode= this.get('subtypeItemsSource').findBy('displayCode', item.bacterialSubType.displayCode).code;
        }
        const params={
          displayCode: item.displayCode,
          name: item.name,
          bacterialTypeCode: bacterialTypeCode,
          bacterialSubTypeCode: bacterialSubTypeCode,
          displaySequence: isEmpty(item.displaySequence)? 1 : item.displaySequence,
          susceptibilityId: isEmpty(item.susceptibility)? null : item.susceptibility.id,
          codeableConcept: null
        };
        if(isEmpty(item.id)){
          //등록
          promise= this.create(this.get('defaultUrl') + 'bacterial-identifications', null, params);
        }else{
          //수정
          const tmp= copy(params);
          tmp.id= item.id;
          promise= this.update(this.get('defaultUrl') + 'bacterial-identifications', null, false, tmp);
        }
        promise.then(()=>{
          this.get('specimenexaminationreportService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
          this.set('updatedSelectedItem', item);
        }).catch(function(error){
          this._catchError(error);
        }.bind(this));
      },

      onDeleteClick(){
        if(isEmpty(this.get('item.id'))){
          return;
        }
        this.delete(this.get('defaultUrl') + 'bacterial-identifications', null, {id: this.get('item.id')}, true).then(function(){
          this.set('updatedSelectedItem', null);
          this.showToastDeleted();
          this._initItem();
          this.set('updatedSelectedItem', this.get('item'));
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      },

    },
    onAudit(){
      const item = this.get('item');
      if(!isEmpty(item.id)){
        this.set('aggregateKey', item.id);
        this.set('isOpenAuditTrail', true);
      }
    },
    // 5. Private methods Area
    _initItem(){
      this.set('item', {
        displayCode: null,
        name: null,
        bacterialType: {displayCode: null, name: null, code:null},
        bacterialSubType: {displayCode: null, name: null, code:null},
        susceptibility: {},
        displaySequence: 1,
      });
    },

    _catchError(e){
      this.showResponseMessage(e);
    }
  });