/* eslint-disable prefer-named-capture-group */
/* eslint-disable no-console */
import { isEmpty } from '@ember/utils';
import $ from 'jquery';
import { A as emberA } from '@ember/array';
import layout from './template';
import CHIS from 'framework/chis-framework';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  MessageMixin,
  {
    layout,
    isShowLoader: false,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-microbe-incubation-result-search');

      this.setStateProperties([
        'gridColumns',
        'gridItems',
        'searchPatientInfo',
        'searchPatientId',
        'urlPrefix',
        'boxClass'
      ]);
      if (!this.hasState()) {
        this.set('model', {
          gridSelectedItem: null,
          loaderSize: 'lg'
        });
        const defaultUrl = this.get('fr_HostConfigService')
          .getEnvConfig('ServerCallConfig', 'specimenexaminationreport') +
          `specimen-examination-report/v0`;
        this.set('urlPrefix', defaultUrl);
        this.set('gridColumns', [
          { field: 'checkInDate', title: this.getLanguageResource('6777', 'F', '', '접수일'), width: 60, align: 'center', type: 'date', dataFormat: 'd',},
          { field: 'specimenType.name', title: this.getLanguageResource('840', 'F', '', '검체'), width: 70, align: 'center', bodyTemplateName: 'textTooltip'},
          { field: 'identificationName', title: this.getLanguageResource('2052', 'F', '', '동정결과'), width: 160, bodyTemplateName: 'identificationTooltip'},
          { field: 'specifiedResultTextString', title: this.getLanguageResource('17110', 'F', '', '검사결과'), width: 160, bodyTemplateName: 'specifiedResultTooltip',},
          { field: 'susceptibility.name', title: this.getLanguageResource('13266', 'F', '', '항생제내성구분'), width: 80, bodyTemplateName: 'textTooltip'},
        ]);
        this._dataReset();
        // this.set('searchParamters', {
        //   patientId: 'ea58a886-7e3c-449a-a52e-4e5d73fd68d3',
        //   fromDate: '2019-07-25T00:00:00',
        //   toDate: '2019-10-25T00:00:00'
        // });
        this.set('boxClass', 'boxsp-type01');
      }

    },
    onLoaded() {
      this._super(...arguments);

      this.set('menuClass', 'w680');
      if(!isEmpty(this.get('searchParamters'))) {
        this.set('model.loaderSize', 'md');
        this.set('searchPatientId', this.get('searchParamters.patientId'));
        this.set('selectedFromDate', this.get('searchParamters.fromDate'));
        this.set('selectedToDate', this.get('searchParamters.toDate'));
        $(this.element).addClass('hp100');
        this.set('boxClass', 'boxsp-type07');
      } else {
        const displayDate = new Date(this.get('co_CommonService').getNow());
        this.set('selectedFromDate', displayDate);
        this.set('selectedToDate', displayDate);
        this.getDataList();
      }
    },
    actions: {
      onGetPatient(item) {
        this.set('searchPatientInfo', item);
        const content = `${item.primaryFullName} (${item.displayId}/${item.genderCodeName}/${item.medicalAge}${this.getLanguageResource('3703', 'F', '', '세')})`;
        this.getGridItemList(content);
      },
      onCleareSearch() {
        this.set('searchPatientInfo', null);
      },
      onSearchAction() {
        this.getGridItemList();
      },
      onFromToUpdated(e) {
        const fromDate = this.get('fr_I18nService').formatDate(e.selectedFromDate, 'd');
        const toDate = this.get('fr_I18nService').formatDate(e.selectedToDate, 'd');
        this.getGridItemList(`${fromDate} ~ ${toDate}`);
      },
      onGridCellDoubleClick(e) {
        if(!isEmpty(this.get('incubationResultCB'))) {
          this.get('incubationResultCB')(e.item);
        }
      },
    },

    _dataReset() {
      this._gridReset();
      this.set('formReset', !this.get('formReset'));
      this.set('searchPatientInfo', null);
      this.set('searchPatientId', null);
    },

    _gridReset() {
      this.set('gridItems', emberA());
    },

    getDataList() {
      this._dataReset();
      this.getGridItemList();
    },
    async getGridItemList(refreshContent) {
      try {
        this.set('isShowLoader', true);
        this._gridReset();
        const selectedFromDate = new Date(this.get('selectedFromDate'));
        const selectedToDate = new Date(this.get('selectedToDate'));
        const fromDate = new Date(selectedFromDate.getFullYear(), selectedFromDate.getMonth(), selectedFromDate.getDate()).toFormatString();
        const toDate = new Date(selectedToDate.getFullYear(), selectedToDate.getMonth(), selectedToDate.getDate()).toFormatString();
        const params = {
          fromDate: fromDate,
          toDate: toDate,
          patientId: this.get('searchPatientInfo.patientId'),
        };
        const result = await this.getList(`${this.get('urlPrefix')}/infection-management/microbe-incubation/result`, params, null);
        if(!isEmpty(refreshContent)) {
          this.showToastRefresh(refreshContent);
        }
        if (!isEmpty(result)) {
          result.map(item => {
            let identificationNameText = '';
            let specifiedResultText = '';
            if(!isEmpty(item.identificationName)) {
              identificationNameText = item.identificationName.replace(/(\n|\r\n)/gu, '<br>');
            }
            if(!isEmpty(item.specifiedResultTextString)) {
              specifiedResultText = item.specifiedResultTextString.replace(/(\n|\r\n)/gu, '<br>');
            }
            item.identificationNameTooltip = identificationNameText;
            item.specifiedResultTooltip = specifiedResultText;
          });
          this.set('gridItems', result);
        }
        this.set('isShowLoader', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowLoader', false);
          this._showError(e);
        }
        console.log('getGridItemList Error :::::', e);
      }

    },
  });