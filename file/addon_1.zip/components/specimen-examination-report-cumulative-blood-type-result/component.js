/* eslint-disable max-lines */
/* eslint-disable no-console */
import { isEmpty } from '@ember/utils';
import { A as emberA } from '@ember/array';
import $ from 'jquery';
import { next } from '@ember/runloop';
// import { set } from '@ember/object';
// import { inject } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import SpecimenExaminationReportMixin from '../../mixins/specimen-examination-report-mixin';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(
  SpecimenExaminationReportMixin,
  MessageMixin,
  {
    layout,
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-cumulative-blood-type-result');
      this.setStateProperties([
        'model',
        'globalPatient'
      ]);
      if (this.hasState() === false) {
        this.set('model', {
        });
        this.set('gridColumns', [
          { field: 'checkInDateTime', title: this.getLanguageResource('6776', 'S', '접수일'), width: 80, align:'center', bodyTemplateName:'checkInDate' },
          // { field: 'checkInNumber', title: this.getLanguageResource('6767', 'F', '', '접수번호'), width: 60, align:'center'},
          // { field: 'reportedDateTime', title: this.getLanguageResource('2872', 'F', '', '보고일'), width: 100, align: 'center', type: 'date', dataFormat: 'd',},
          { field: 'reportedDateTime', title: this.getLanguageResource('2872', 'F', '', '보고일'), width: 80, align: 'center', bodyTemplateName: 'reportedDate',},
          { field: 'examination.name', title: this.getLanguageResource('16920', 'F', '', '검사명'), width: 100, bodyTemplateName:'textTooltip'},
          { field: 'specimenType.name', title: this.getLanguageResource('16921', 'F', '', '검체명'), width: 80, align: 'center', bodyTemplateName:'textTooltip'},
          { field: 'displayResult', title: this.getLanguageResource('890', 'S', '결과'), align: 'center', width:100, bodyTemplateName: 'boldText'},
        ]);
        const displayDate = new Date(this.get('co_CommonService').getNow());
        this.set('selectedFromDate', displayDate.addYears(-1));
        this.set('selectedToDate', displayDate);
      }
    },

    onLoaded(){
      this._super(...arguments);
      this._getGridData();
    },
    actions: {
      onRefreshClick() {
        this._getGridData();
      },
      onGridLoaded(e) {
        this.set('gridSource', e.source);
      },
      onSearchAction() {
        this._getGridData();
      },
      onGridCellClick(e) {
        const expandedDetailRowItem = e.source.expandedDetailRowItems[0];
        if(!isEmpty(e.item)){
          const gridComp = e.source;
          if(!isEmpty(e.item.recoredNoteId)) {
            gridComp.collapseAllDetailRow();
            const targetIndex = gridComp.getItemIndex(e.item);
            if(!isEmpty(expandedDetailRowItem) && expandedDetailRowItem.recoredNoteId !== e.item.recoredNoteId) {
              gridComp.expandDetailRow(targetIndex);
            } else if(isEmpty(expandedDetailRowItem)) {
              gridComp.expandDetailRow(targetIndex);
            }
          } else {
            gridComp.collapseAllDetailRow();
          }
        }
      }
    },
    async _getGridData() {
      try {
        // await this._getSpecimenCheckInDisplayView();
        const selectedFromDate = this.get('selectedFromDate');
        const selectedToDate = this.get('selectedToDate');
        const fromDate = new Date(selectedFromDate.getFullYear(), selectedFromDate.getMonth(), selectedFromDate.getDate(), 0, 0, 0).toFormatString();
        const toDate = new Date(selectedToDate.getFullYear(), selectedToDate.getMonth(), selectedToDate.getDate(), 0, 0, 0).toFormatString();
        this.set('isShowLoader', true);
        this.set('gridData', emberA());
        const queryParam = {
          subjectTypeCode: "Patient",
          subjectId: this.get('patientId'),
          periodTypeCode: 'CheckIn',
          fromDate: fromDate,
          toDate: toDate,
          departmentId: null,
          orderedStaffId: null,
          isViewUnReportExamination: false,
          isTextResult: null,
          isAbnormalResult: null,
          isExcludePointOfCare: null,
          classificationIds: null,
          examinationIds: this.get('examinationIds'),
          requestRange: null,
        };
        const result = await this.get('btService').getSpecimenReportsSearch(queryParam);
        if(!isEmpty(result)) {
          // const tempArr = [];
          // result.forEach(data => {
          //   if(!data.isTextRecordNoteResult) {
          //     tempArr.push(data);
          //   }
          // });
          // this.set('gridData', tempArr);
          this.set('gridData', result);
          next(() => {
            const tableRows = $(`#${this.get('gridSource.elementId')}`).find('.c-gtr');
            const rowslength = tableRows.length;
            for(let i = 0; i < rowslength; i++) {
              if(i % 2 !== 0 && rowslength !== i+1) {
                $(tableRows[i]).css({'border-bottom': '1px dotted #a6a4a4'});
              }
            }
          });
          //border-bottom: 1px dotted #a6a4a4;
        }
        this.set('isShowLoader', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this._showError(e);
          this.set('isShowLoader', false);
        }
        console.log('getDatas Error::: ', e);
      }
    },
  });