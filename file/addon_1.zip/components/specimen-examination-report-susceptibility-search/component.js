import { next } from '@ember/runloop';
import $ from 'jquery';
import { copy } from '@ember/object/internals';
import { isEmpty } from '@ember/utils';
import { computed, get, set } from '@ember/object';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from '../../app-config';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MessageMixin,
  /* Only For Server-Call Component
  CHIS.FR.CrossCutting.ServerCallMixin,
  */
  {
  /* 1. Service define Area
  testService:Ember.inject.service(),
  */
    layout,
    specimenexaminationreportService: service('specimen-examination-report-service'),
    // 2. Property Area
    defaultUrl: null,
    itemChanged: computed('updatedSelectedItem', function() {
      if(this.get('updatedSelectedItem') == 'refresh'){
        this._getGridList(this.get('searchKey'), null);
      }else if(!isEmpty(this.get('updatedSelectedItem'))){
        this._getGridList(this.get('searchKey'), this.get('updatedSelectedItem'));
      }
    }),
    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      this.set('menuClass', 'w500');
      this.set('viewId','specimen-examination-report-susceptibility-search');
      //Set Stateful properties
      this.setStateProperties([
        'defaultUrl',
        'gridColumns',
        'gridItemsSource',
        'susceptibilityItem',
        'detailTemplateChildColumns',
        'antibiotics',
        'antibioticsSelectedItem',
        'isSelectBtnVisibie',
        'searchKey',
        'filterCondition',
        'filteritemsSource'
      ]);
      if (this.hasState() === false) {
      //Initialize Stateful properties
        this.set('searchKey', '');
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')+ `specimen-examination-report/${config.version}/`);
        this._setGridColumns();
        this.set('filterCondition', this.get('filteritemsSource.firstObject.code'));
        this._getGridList();
        this.set('detailRowExpandMode', 'single');
      }
    //Initialize Stateless properties
    },

    _setGridColumns(){
      this.set('gridColumns',[
        { title: this.getLanguageResource('7674', 'F', 'Code'), field: 'displayCode', width: 160 },
        { title: this.getLanguageResource('5930', 'F', 'name'), field: 'name' },
      ]);
      this.set('detailTemplateChildColumns',[
        { title: this.getLanguageResource('7674', 'F', 'Code'), field: 'examination.displayCode', width: 70,
          onBodyCellRender: function (context) {
            if (get(context.item, 'highlightCode')) {
              context.cellComponent.$().css('color', 'red');
            }
          }
        },
        { title: this.getLanguageResource('5930', 'F', 'name'), field: 'examination.name', width: 170,
          onBodyCellRender: function (context) {
            if (get(context.item, 'highlightName')) {
              context.cellComponent.$().css('color', 'red');
            }
          } },
        { title: this.getLanguageResource('9763', 'S', 'R'), field: 'displayRanges.resistant',align: 'center' },
        { title: this.getLanguageResource('9765', 'S', 'Min I'), field: 'displayRanges.lowIntermediate',align: 'center' },
        { title: this.getLanguageResource('9766', 'S', 'Max I'), field: 'displayRanges.highIntermediate',align: 'center' },
        { title: this.getLanguageResource('9764', 'S', 'S'), field: 'displayRanges.susceptible',align: 'center' },
      ]);
      this.set('filteritemsSource',[
        { name : this.getLanguageResource('9761', 'S', '감수성'), code : 'susceptibility'},
        { name : this.getLanguageResource('7674', 'F', 'Code'), code : 'antibiotic'},
      ]);
    },
    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
    },

    didInsertElement() {
      this._super(...arguments);
      this.$('[name*="specimen-examination-report-susceptibility-search_searchKey"] input').focus();
    },

    // 4. Actions Area
    actions: {
      onGridLoad(e) {
        this.set('gridControl', e.source);
      },
      onAntibioticGridLoad(e) {
        this.set('antibioticGridControl', e.source);
      },
      onTextCommit(e){
        this._filteringGrid(e);
      },
      onSearchClick() {
        this._getGridList(this.get('searchKey'), null);
      },

      onFilterConditionChanged(){
        this.set('gridItemsSource', this._filtering(this.get('searchKey')));
      },

      onAntibioticSelectionChanged(e){
        //디테일 그리드 선택
        if(this.get('detailRowExpandMode')=='single'){
          this.set('susceptibilityItem', this.get('gridControl.expandedDetailRowItems.firstObject'));
        }else if(this.get('detailRowExpandMode')=='multiple'){
          if(!isEmpty(e.selectedItems.get('firstObject'))){
            this.set('tmpAntibiotics', copy(e.selectedItems.get('firstObject')));
            this.set('tmpSusceptibility', e.source.parentView.item);
            this.set('antibioticsSelectedItem', null);
          }
        }
      },

      onSusceptibilitySelectionChanged(e){
        //감수성 그리드 선택
        if(this.get('detailRowExpandMode')=='single'){
          if(e.selectedItems[0] != this.get('gridControl.expandedDetailRowItems.firstObject')){
            // this.set('antibioticsSelectedItem', null);
            // this.set('singleTmpAntibiotics', e.selectedItems.get('firstObject.antibiotics'));
            this.get('gridControl').collapseDetailRow(this.get('gridControl.expandedDetailRowItems.firstObject'));
          }
        }
      },
      onDetailRowItemsChanged(e){
        this.set('susceptibilityItem', e.expandedDetailRowItems.get('firstObject'));
        this.set('antibioticsSelectedItem', null);
      },
      onSelectClick(){
        if(isEmpty(this.get('returnSusceptibilityCB'))){
          return;
        }
        const susceptibilityItem= this.get('susceptibilityItem');

        let res=null;
        if(this.get('detailRowExpandMode')=='single'){
          if(!isEmpty(this.get('gridControl.expandedDetailRowItems.firstObject'))){
            const susceptibility= this.get('gridControl.expandedDetailRowItems.firstObject');
            res={
              antibiotics: isEmpty(this.get('antibioticsSelectedItem'))? susceptibility.antibiotics : this.get('antibioticsSelectedItem'),
              displayCode: susceptibility.displayCode,
              id: susceptibility.id,
              name: susceptibility.name,
            };
          }else{
            res=susceptibilityItem;
          }
        }else if(this.get('detailRowExpandMode')=='multiple'){
          if(!isEmpty(this.get('tmpSusceptibility'))){
            const susceptibility= this.get('tmpSusceptibility');
            res={
              antibiotics: this.get('tmpAntibiotics'),
              displayCode: susceptibility.displayCode,
              id: susceptibility.id,
              name: susceptibility.name,
            };
          }else{
            res=susceptibilityItem;
          }
        }

        if(isEmpty(res)){
          this.get('specimenexaminationreportService')._showMessage( this.get('specimenexaminationreportService')._showMessage('선택된 검사가 없습니다.', 'warning', 'Ok', 'Ok', '', 2000));
        }
        this.get('returnSusceptibilityCB')(res);
        this.set('tmpAntibiotics', null);
        this.set('tmpSusceptibility', null);
        this.set('singleTmpAntibiotics', null);
      },
      // onsearchKeyTextCleared
    },
    // 5. Private methods Area
    async _getGridList(searchKey, selectedItem){
      this.set('isGridShow', true);
      await this.getList(this.get('defaultUrl') + 'susceptibilitys/search', null,{
        "displayCode": null,
        "name": null
      },false).then(res=>{
        this.set('isGridShow', false);
        res.forEach(element => {
          if(isEmpty(element.antibiotics)){
            return;
          }
          element.antibiotics.forEach(antibiotic => {
            if(isEmpty(antibiotic.referenceRanges)){
              set(antibiotic, 'displayRanges', {});
            }else if(antibiotic.referenceRanges.length !=3){
              set(antibiotic, 'displayRanges', {});
              return;
            }
            set(antibiotic, 'orderNameTooltip', antibiotic.examination.displayCode + ', ' + antibiotic.examination.name);
            set(antibiotic, 'displayRanges', {resistant: null, intermediate: null, susceptible: null});
            antibiotic.referenceRanges.forEach(item=>{
              if(item.typeCode ==="anti-resistant"){
                set(antibiotic, 'displayRanges.resistant', item.low.value);
              }else if(item.typeCode ==="anti-intermediate"){
                set(antibiotic, 'displayRanges.lowIntermediate', item.low.value);
                set(antibiotic, 'displayRanges.highIntermediate', item.high.value);
              }else if(item.typeCode ==="anti-susceptible"){
                set(antibiotic, 'displayRanges.susceptible', item.high.value);
              }
            });
          });

        });
        this.set('gridItemsSource', res);
        this.set('sortedGridItemsSource', res);
        this.set('initialGridItemsSource', res);
        next(this, function(){
          if(!isEmpty(searchKey)){
            // searchKey 검색조건으로 다시 검색
            this._filteringGrid(searchKey, selectedItem);
          }else if(!isEmpty(selectedItem)){
            //이전 선택값 다시 선택
            this.set('susceptibilityItem', res.findBy('displayCode', selectedItem.displayCode));
          }else{
            this.set('susceptibilityItem', res.get('firstObject'));
          }
        }.bind(this));
      }).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    _filteringGrid(e, selectedItem){
      let sortedGridItemsSource=null;
      if(isEmpty(e.source) && isEmpty(e)){
        sortedGridItemsSource=this.get('initialGridItemsSource');
      }else{
        sortedGridItemsSource= isEmpty(e.source)? this._filtering(e) : this._filtering(e.source.value);
      }
      this.set('gridItemsSource', sortedGridItemsSource);
      next(this, function(){
        if(!isEmpty(selectedItem)){
          this.set('susceptibilityItem', this.get('updatedSelectedItem'));
        }
      }.bind(this));
      // this.$('[name*="specimen-examination-report-susceptibility-search_searchKey"] input').focus();
    },
    _filtering(text){
      const initialGridItemsSource= $.extend(true, [], this.get('initialGridItemsSource').map(function(e){
        return $.extend(true, {}, e);
      }));
      if(isEmpty(text)){
        return this.get('initialGridItemsSource');
      }
      this.set('isGridShow', true);
      const tmp=[];
      if(this.get('filterCondition')== 'susceptibility'){
        initialGridItemsSource.forEach(element => {
          if(isEmpty(element.name) ||isEmpty(element.displayCode)){
            return;
          }
          if(element.name.toLocaleLowerCase().includes(text.toLocaleLowerCase())|| element.displayCode.toLocaleLowerCase().includes(text.toLocaleLowerCase())){
            tmp.addObject(element);
          }
        });
        this.set('detailRowExpandMode','single');
        next(this, function(){
          this.get('gridControl').collapseDetailRow();
        }.bind(this));
      }else if(this.get('filterCondition')== 'antibiotic'){
        initialGridItemsSource.forEach(element => {
          element.antibiotics.forEach(e=>{
            if(isEmpty(e.examination)){
              return;
            }
            if(e.examination.displayCode.toLocaleLowerCase().includes(text.toLocaleLowerCase())){
              tmp.addObject(element);
              set(e, 'highlightCode', true);
            }
            if(e.examination.name.toLocaleLowerCase().includes(text.toLocaleLowerCase())){
              tmp.addObject(element);
              set(e, 'highlightName', true);
            }
          });
        });
        this.set('detailRowExpandMode','multiple');
        tmp.uniqBy('displayCode');
        // next(this, function(){
        //   this.get('gridControl').expandAllDetailRow();
        // }.bind(this));
      }
      next(this, function(){
        this.set('isGridShow', false);
        this.$('[name*="specimen-examination-report-susceptibility-search_searchKey"] input').focus();
      }.bind(this));
      return tmp;
    },

    _catchError(e){
      this.set('isGridShow',false);
      this.showResponseMessage(e);
    }
  });