/* eslint-disable no-console */
// import { copy } from '@ember/object/internals';
import EmberObject, { set } from '@ember/object';
import { isEmpty, isPresent } from '@ember/utils';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'specimenexaminationreport-module/app-config';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';
import CalculattionMixin from '../../mixins/specimen-examination-report-calculation-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  MessageMixin,
  CalculattionMixin,
  /* Only For Server-Call Component
  CHIS.FR.CrossCutting.ServerCallMixin,
  */
  {
  /* 1. Service define Area
  testService:Ember.inject.service(),
  */
    layout,
    // 2. Property Area
    defaultUrl: null,
    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      //this.set('menuClass', 'w1000');
      this.set('viewId','specimen-examination-report-observations-result-log');
      //Set Stateful properties
      this.setStateProperties([
        'defaultUrl',
      ]);
      if (this.hasState() === false) {
      //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')
        + `specimen-examination-report/${config.version}/`);
        this.set('changesGridColumns', [
          { title: this.getLanguageResource('9946', 'S','', '검사일시'), field: 'changeDatetime', width: 110, type: 'date', dataFormat: 'g',align: 'center' },
          { title: this.getLanguageResource('890', 'F','Result'), field: 'valueValueString',align: 'center',bodyTemplateName: 'detailview'},
          { title: this.getLanguageResource('16887', 'S','검사자'), field: 'changeStaff.name', bodyTemplateName: 'tooltip', width: 80,align: 'center'},
          { title: this.getLanguageResource('3452', 'F','Status'), field: 'status.name',align: 'center', width: 80, readOnly: true},
          { title: this.getLanguageResource('6533', 'S', '', '재검여부'), field: 'check.isRecheck', bodyTemplateName: 'dataYN', width: 60,align: 'center'},
        ]);
      }
      this.set('popupTitle', null);

    //Initialize Stateless properties
    },

    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w800');
      if (this.hasState() === false) {
        // const defaultUrl = this.get('defaultUrl');
        // Ember.RSVP.hash({
        //   // editReasionItemsSource: this.getList(defaultUrl + 'business-codes/search', {classificationCode: 'ObservationResultChangeReasonResultDefaultComment'}, null),

        // }).then(function(result) {
        //   // this.set('editReasionItemsSource', result.editReasionItemsSource);
        // }.bind(this));
      }
    },
    _setCalculateItem(item) {
      set(item, 'examinationId', this.get('item.examinationId'));
      set(item, 'specimenId', this.get('item.specimenId'));
      set(item, 'subjectId', this.get('item.subjectId'));
      set(item, 'specimenNumber', this.get('item.specimenNumber'));
      this._getCalculate(item);
    },
    // 4. Actions Area
    actions: {
      onPopupOpenedAction() {
        let popupTitle = this.getLanguageResource('14394', 'S','', '검사이력');
        if(isPresent(this.get('item'))) {
          popupTitle = ` ${popupTitle} - ${this.get('item.examination.name')}`;
        }
        this.set('popupTitle', popupTitle);
        this.set('changesGridItemsSource', null);
        this._searhChangesLog();
      },
      onGridCellDoubleClick(e) {
        this._setCalculateItem(e.item);
        // if(isPresent(this.get('resultChangedItemCB'))) {
        //   this.get('resultChangedItemCB')(e.item);
        //   this.set('isChangesLogOpened', false);
        // }
      },
      onSelectClick() {
        const selectedChangesGridItem = this.get('selectedChangesGridItem');
        if(isEmpty(selectedChangesGridItem)) {
          return;
        }
        this._setCalculateItem(selectedChangesGridItem);
      },
      onDetailClick(item, col){
        if(isPresent(item)){
          if(col === 'Result'){
            if(item.recordNoteId !== null){
              set(item, 'isDetailOpen', false);
              this.set('isSpecimenExamDetailOpen', true);
              this.set('detailView', EmberObject.create({
                title: null,
                recordNoteId: item.recordNoteId,
                recordDate: item.changeDatetime
              }));
            }
          }
          // if(col === 'Prev. Result'){
          //   if(item.recentRecoredNoteId !== null){
          //     Ember.set(item, 'isPrevDetailOpen', false);
          //     this.set('isSpecimenExamDetailOpen', true);
          //     this.set('detailView', Ember.Object.create({
          //       title: item.examination.abbreviation + " [Prev. Result]",
          //       recordNoteId: item.recentRecoredNoteId,
          //     }));
          //   }
          // }
        }
      },
      onDetailViewClosed(){
        set(this.get('detailView'), 'title', null);
        set(this.get('detailView'), 'recordNoteId', null);
      },
    },
    // 5. Private methods Area
    _searhChangesLog(){
      if(isEmpty(this.get('item.observationId'))){
        return;
      }
      this.getList(this.get('defaultUrl') + 'observations/changes/log', {observationId: this.get('item.observationId')}, null, false).then(res=>{

        if(isEmpty(res)){
          this.set('changesGridItemsSource', null);
        }else{
          res.map(d=> {
            d.valueValueString = this.get('specimenexaminationreportService')._setValueString(d);
          });
          this.set('changesGridItemsSource', res);
        }

      }).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    _catchError(e){
      this.showResponseMessage(e);
    }
  });