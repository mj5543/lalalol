/* eslint-disable max-lines */
/* eslint-disable chis/require-template-convention */
/* eslint-disable no-console */
/* eslint-disable max-lines-per-function */
import { isEmpty, isPresent } from '@ember/utils';
import { next } from '@ember/runloop';
import { set } from '@ember/object';
import { copy } from '@ember/object/internals';
import layout from './template';
import CHIS from 'framework/chis-framework';
import SpecimenExaminationReportMixin from '../../mixins/specimen-examination-report-mixin';
import CultureResultManagementMixin from '../../mixins/culture-result-management/specimen-examination-report-culture-result-management-mixin';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';
import CultureResultSusceptibilityMixin from '../../mixins/culture-result-management/susceptibilitys-mixin';
// import $ from 'jquery';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  SpecimenExaminationReportMixin,
  CultureResultManagementMixin,
  CultureResultSusceptibilityMixin,
  MessageMixin,
  {
    layout,
    globalPatientInfo: null,
    identificationGrid: null,
    identificationResultItemsSource: null,
    identificationResultColumns: null,
    resultExampleColumns: null,
    susceptibilityResultColumns: null,
    selectedDate: null,
    specimenNumber:null,
    resultWorkData: null,
    observationCulturesData: null,
    dianosticReportStain: null,
    isIdentificationLoader: false,
    bacterialMethodItems: null,
    mediaItems: null,
    interpretationItems: null,
    colonyContentItems: null,
    resultExampleList: null,
    isShowInputbox: false,
    isIdentificationOpen: false,
    identificationTarget: null,
    isRemarkDetailPopupOpen: false,
    remarkDetailTarget: null,
    resultRemarkList: null,
    identificationRemoveIds: null,
    resultExampleTarget: null,
    isResultExampleOpen: false,
    isShowReportResultSearchButton: false,
    isRecordExportOpen: false,
    exampleGrid: null,
    isEditingIdentificationItems: false,
    isEditingSusceptibilityItems: false,
    initializeTimeVolume: null,
    isCumulativePopupOpen: false,
    isCorrectReasonEntryOpened: false,
    loaderDimed: false,
    contentLoaderType: 'spinner',
    isGridContainerLoader: false,
    specimenExaminationId: null,
    calcHeight: null,
    isNewAddedRow: false,
    isShowUnitItem: false,
    isButtonDisabled: true,

    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-culture-result-management');
      this.setStateProperties([
        'model',
        'identificationResultItemsSource',
        'susceptibilityResultItemsSource',
        'selectedDate',
        'specimenNumber',
        'resultWorkData',
        'observationCulturesData',
        'dianosticReportStain',
      ]);
      if (this.hasState() === false) {
        this.set('model', {
          identificationSelectedItem: null,
          identificationCheckedItems: null,
          examinationStatus: {
            registered: null,
            preliminary: null,
            final: null
          },
          identificationInputFieldItem: {
            characterization: null,
            additionalExamiation: null,
            customMethod: null,
          },
          unitMarkItem: null,
          selectedBacterialMethodId: null,
          selectedMediaId: null,
          selectedInterpretationId: null,
          selectedItemIndex: null,
          exampleSelectedItems: null,
          exampleSelectedItemsText: null,
          resultExamplesInputText: null,
          selectedCellOriginValue: null,
          customMethodContent: null,
          resultReason: {
            reasonCode: null,
            reasonContent: null,
          },
        });
        this.set('identificationResultColumns', [
          { field: 'reportableYN', title: this.getLanguageResource('2859', 'F', '', '보고'), width: 20, bodyTemplateName: 'reportableIcon', align:'center'},
          { field: 'media.name', title: this.getLanguageResource('11040', 'S', '', '배지종류'), width: 90, bodyTemplateName: 'mediaCombobox'},
          { field: 'interpretationCoding.name', title: this.getLanguageResource('11043', 'S', '', '집락'), width: 70, bodyTemplateName: 'interpretationCombobox'},
          { field: 'colonySequence', title: 'No', width: 20, align:'center', readOnly: true},
          { field: 'colonyContent', title: this.getLanguageResource('11042', 'F', '', '정도'), width: 100, bodyTemplateName:'colonyCombobox'},
          // { field: 'interpretationCoding.code', title: this.getLanguageResource('tempkey', 'F', '', '장비번호'), width: 50, align:'center'},
          { field: 'codeableConceptCoding.code', title: this.getLanguageResource('11041', 'F', '', '동정코드'), width: 50, readOnly: true},
          { field: 'codeableConceptCoding.displayName', title: this.getLanguageResource('2052', 'F', '', '동정결과'), width: 160, bodyTemplateName: 'codeableConceptName'},
          { field: 'remark', title: this.getLanguageResource('906', 'S', '', '결과비고'), width: 40, readOnly: true, align:'center', bodyTemplateName: 'resultRemark'},
        ]);
        this.set('resultExampleColumns', [
          { field: 'name', title: this.getLanguageResource('890', 'F', '', '결과')},
        ]);
        this.set('susceptibilityResultColumns', [
          { field: 'antibioticReportableYN', title: this.getLanguageResource('2859', 'F', '', '보고'), width: 30, bodyTemplateName: 'reportableIcon', align:'center'},
          { field: 'examination.name', title: this.getLanguageResource('8098', 'F', '', '항목'), width: 110, bodyTemplateName: 'examinationName', readOnly: true},
          { field: 'displayResultText', title: this.getLanguageResource('7068', 'F', '', '지름'), width: 60, align:'center', readOnly: true, enableGotFocusAutoSelect: true, allowDecimal:true, type: 'number'},
          { field: 'interpretation.displayContent', title: this.getLanguageResource('890', 'F', '', '결과'), width: 70,
            readOnly: true, enableGotFocusAutoSelect: true},
          { field: 'displayRange', title: this.getLanguageResource('14749', 'F', '', '참고'), width: 100, align:'center', readOnly: true},
        ]);
        const displayDate = new Date(this.get('co_CommonService').getNow());
        this.set('selectedDate', displayDate);
        this.set('model.exampleSelectedItemsText', []);
        this.set('model.identificationCheckedItems', []);
        this._setDatasReset();
        this.set('cvrReasonItemList', []);
        this.set('bacterialMethodItems', []);
        this.set('mediaItems', []);
        this.set('interpretationItems', []);
        this.set('colonyContentItems', []);
        this.set('resultExampleList', []);
        this.set('calcHeight', 'height:calc(48% - 138px);');
      }
    },

    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1360');
      if(!isEmpty(this.get('co_PatientManagerService.selectedPatient'))){
        this.set('globalPatientInfo', this.get('co_PatientManagerService.selectedPatient'));
      }
      this.getBusinessCodeList();
      const contentSource= this.getOpenMenuParams();
      const examinationSpecimenId = this.get('co_PatientManagerService.selectedPatient.examination.specimenId');
      if(!isEmpty(contentSource)){
        this.set('specimenNumber', contentSource.specimenNumber);
        this.set('examinationCode', contentSource.examinationCode);
        this._init();
      } else if(!isEmpty(examinationSpecimenId)) {
        this.set('specimenId', examinationSpecimenId);
        this._init();
      }

    },
    // didInsertElement(){
    //   this._super(...arguments);
    //   this.get('co_ContentMessageService').subscribeMessage('sendMessage', this.get('currentMenuId'), this, this.sendMessage);
    // },
    // willDestroyElement() {
    //   this._super(...arguments);
    //   this.get('co_ContentMessageService').unsubscribeMessage('sendMessage', this.get('currentMenuId'), this, this.sendMessage);
    // },
    // sendMessage(e){
    //   if(!isEmpty(e)){
    //     this.set('specimenNumber', e.specimenNumber);
    //     this.set('examinationCode', e.examinationCode);
    //     this._init();
    //   }
    // },

    actions: {
      onGetSendResult(e) {
        console.log('onGetSendResult--', e);
      },
      onCommentBtnClick(e){
        this.toggleProperty('initializeTimeVolume');
        this.set('isCommentOpen', true);
        this.set('commentPopupTarget', e.originalEvent.currentTarget);
      },
      /**
       * grid action
       */
      onIdentificationGridLoaded(e) {
        this.set('identificationGrid', e.source);
      },
      onIdentificationGridSelectedAction(e) {
        // console.log('onIdentificationGridSelectedAction---', e);
        const selectedItem = e.selectedItems[0];
        this.set('isShowReportResultSearchButton', false);
        this.set('model.exampleSelectedItemsText', null);
        // this.set('model.resultExamplesInputText', null);
        this.set('model.identificationInputFieldItem.characterization', null);
        this.set('model.identificationInputFieldItem.additionalExamiation', null);
        this.set('model.identificationInputFieldItem.customMethod', null);
        this.set('isShowInputbox', false);
        if(this.get('isRecordExportOpen')) {
          this.set('calcHeight', 'height:calc(48% - 138px);');
        } else {
          // this.set('calcHeight', 'height:calc(100% - 138px);');
        }
        this.set('model.selectedBacterialMethodId', null);
        this._setSusceptibilitysDataReset();
        const gridComponent = e.source;
        this.set('model.identificationCheckedItems', e.selectedItems);

        if (!isEmpty(selectedItem) && e.selectedItems.length === 1) {
          if(!isEmpty(selectedItem.observationId)) {
            this.set('isSusceptibilityDisabled', false);
            this._setSusceptibilitysGrid(selectedItem.observationId);
          }
          const itemIndex = gridComponent.getItemIndex(selectedItem);
          this.set('model.selectedItemIndex', itemIndex);
          // this.set('model.resultExamplesInputText', selectedItem.resultContent);
          if (!isEmpty(selectedItem.value) && !isEmpty(selectedItem.value.recordNoteId)) {
            this.set('isShowReportResultSearchButton', true);
          }
          this.set('model.identificationInputFieldItem.characterization', selectedItem.characterizationContent);
          this.set('model.identificationInputFieldItem.additionalExamiation', selectedItem.additionalExaminationContent);
          this.set('model.identificationInputFieldItem.customMethod', selectedItem.methodCoding);
          if (!isEmpty(selectedItem.methodCoding.code)) {
            this.set('model.selectedBacterialMethodId', selectedItem.methodCoding.code);
            if(this.hasCustomMethodCode(selectedItem.methodCoding)) {
              this.set('isShowInputbox', true);
              // this.set('calcHeight', 'height:calc(100% - 162px);');
              this.set('calcHeight', 'height:calc(48% - 162px);');
            }
          }
          this.set('isIdentificationsFieldsDisabled', false);
        } else {
          this.set('model.selectedItemIndex', null);
          this.set('isIdentificationsFieldsDisabled', true);
        }
      },
      onIdentificationCellClick(e) {
        const currentValue = this.getCellsCurrentValue(e);
        const itemIndex = e.source.getItemIndex(e.item);
        this.set('model.selectedItemIndex', itemIndex);
        this.set('model.selectedCellOriginValue', copy(currentValue));

        if (e.column.field === 'remark') {
          this.set('isRemarkDetailPopupOpen', true);
          // this._getResultRemarks(e.item);
          this.set('remarkDetailTarget', `#${e.originalSource.elementId}`);
        } else if(e.column.field === 'codeableConceptCoding.displayName' || e.column.field === 'codeableConceptCoding.code') {
          this.set('identificationTarget', `#${e.originalSource.elementId}`);
          this.set('isIdentificationOpen', true);
        } else if (e.column.field === 'reportableYN') {
          const changeReportable = !e.item.isReportable;
          const changeSymbol = changeReportable ? 'Y' : 'N';
          this._identificationGridItemChange(changeReportable, 'isReportable');
          this._identificationGridItemChange(changeSymbol, 'reportableYN');
        }
      },
      onIdentificationEditEnd(e) {
        if (this.cellChagnedCheck(e)) {
          this.set('isEditingIdentificationItems', true);
        }
      },
      onExampleGridLoad(e) {
        this.set('ExampleGrid', e.source);
      },
      onResultExampleSelectedAction(e) {
        const exampleSelectedItemsText = [];

        e.selectedItems.forEach(item => {
          exampleSelectedItemsText.push(item.name);
        });
        // this.set('model.exampleSelectedItemsText', exampleSelectedItemsText.join('\r\n'));
        this.set('model.exampleSelectedItemsText', exampleSelectedItemsText.join(', '));
        this.set('exampleSelectedItemsTextTooltip', exampleSelectedItemsText.join('<br>'));
        this.set('exampleSelectedItemsString', exampleSelectedItemsText.join(', '));
      },
      /**
       * combobox action
       */
      onMediaChanged(e) {
        this._identificationGridItemChange(e.selectedItems[0].name, 'media.name');
        this._identificationGridItemChange(e.selectedItems[0].code, 'media.code');
      },
      onInterpretationChanged(e){
        this._identificationGridItemChange(e.selectedItems[0].name, 'interpretationCoding.name');
        this._identificationGridItemChange(e.selectedItems[0].code, 'interpretationCoding.code');
      },
      onColonyChanged(e){
        this._identificationGridItemChange(e.selectedItems[0].name, 'colonyContent');
      },
      onBacterialMethodChanged(e) {
        // console.log('onBacterialMethodChanged---', e);
        if (!isEmpty(e.selectedItems)) {
          const selectedItem = e.selectedItems[0];
          if (this.hasCustomMethodCode(selectedItem)) {
            this.set('isShowInputbox', true);
            if(this.get('isRecordExportOpen')) {
              this.set('calcHeight', 'height:calc(48% - 162px);');
            } else {
              // this.set('calcHeight', 'height:calc(100% - 162px);');
            }
            // this.set('model.identificationInputFieldItem.customMethod.name', null);
          } else {
            this.set('isShowInputbox', false);
            if(this.get('isRecordExportOpen')) {
              this.set('calcHeight', 'height:calc(48% - 138px);');
            } else {
              // this.set('calcHeight', 'height:calc(100% - 138px);');
            }
          }
          this._identificationGridItemChange(selectedItem.code, 'methodCoding.code');
        }
      },
      onBacterialMethodKeyUp() {
        if (isEmpty(this.get('identificationResultItemsSource'))) {
          return this.showWarningMessage(this.getLanguageResource('9260', 'F', '항목을 추가해주세요.'), 2000);
        } else if(isEmpty(this.get('model.identificationSelectedItem'))) {
          return this.showWarningMessage(this.getLanguageResource('9260', 'F', '항목을 선택하세요.'), 2000);
        }
        if(this.get('identificationGrid').selectedItems.length > 1) {
          return this.showWarningMessage(this.getLanguageResource('11038', 'F', '', '한 개의 항목만 선택하세요.'), 2000);
        }
      },
      /**
       * button action
       * */
      //결과 돋보기 버튼
      onFindResultExampleClick(e) {
        this.set('isResultExampleOpen', true);
        this.set('resultExampleTarget', e.originalEvent.currentTarget);
      },
      //보고결과조회버튼
      onReportResultSearchClick() {
        if(this.get('isShowInputbox')) {
          this.set('calcHeight', 'height:calc(48% - 162px);');
        } else {
          this.set('calcHeight', 'height:calc(48% - 138px);');
        }
        this.set('isRecordExportOpen', true);
        next(() => {
          this.$('.scrollbar-macosx').scrollbar();
        });
      },
      onRemarkClick() {
        //비고버튼
      },
      //동정결과 Row 추가
      onBacterialIdentificationAddRow() {
        if (this.get('isEditingSusceptibilityItems')) {
          const checkedItems = this.get('model.identificationCheckedItems');
          if (checkedItems.length === 1) {
            const message = this.getLanguageResource('11039', 'F', null, '감수성 결과가 저장되지 않았습니다. 항목을 변경하시겠습니까?');
            this.showConfirmMessage(message).then(result => {
              if (result === 'Yes') {
                this.set('isEditingSusceptibilityItems', false);
                this._addIdentificationsRow();
              }
            });
          }
        } else {
          this._addIdentificationsRow();
        }

      },
      onRemoveIdentificationItem() {
        // if((!isEmpty(this.get('susceptibilityResultItemsSource')) && !this.get('isSusceptibilityTempItemsSource')) || this.get('model.identificationCheckedItems').length > 1) {
        //   this.showWarningMessage(this.getLanguageResource('9235', 'F', '', '삭제할 수 없습니다.'), 2000);
        //   return;
        // }
        // if(isEmpty(this.get('susceptibilityResultItemsSource')) && this.get('isEditingSusceptibilityItems')) {
        //   this.showWarningMessage(this.getLanguageResource('10277', 'F', '', '감수성결과를 저장하지 않았습니다.'), 2000);
        //   return;
        // }
        if(isEmpty(this.get('model.identificationSelectedItem'))) {
          this.showWarningMessage(this.getLanguageResource('9260', 'F', '항목을 선택하세요.'), 2000);
        } else {
          this._setRemoveIdentificationItems();
        }

      },
      onIntermediateReportingClick() {
        //중간보고 버튼
      },
      //동정결과 저장버튼
      onIdentificationSaveClick() {
        if(!this.checkGPatientId(this.get('resultWorkData.subjectId'), true)) {
          return;
        }
        this._saveBacterialIdentifications();
      },
      //감수성결과 저장버튼
      onSusceptibilitySaveClick() {
        if(!this.checkGPatientId(this.get('resultWorkData.subjectId'), true)) {
          return;
        }
        this._saveIdentificationsSusceptibility();
      },
      //비고팝업 내용 적용버튼 클릭
      onRemarkApplyClick() {
        this._setRemarkCellsItemChange();
      },
      onNewRemarkClick(){
        this.set('isRegisterRemarkPopupOpen', true);
      },
      onRemarkChangedCB(){
        const resultWorksInfo = this.get('resultWorkData');
        const resultCulturesParams = {
          specimenNumber: resultWorksInfo.specimenNumber,
          checkInId: resultWorksInfo.checkInId
        };
        this.set('isRemarkPopupLoader', true);
        this._getResultRemarks(resultCulturesParams);
      },
      //임시저장버튼
      onPreliminarySaveClick() {
        if(!this.checkGPatientId(this.get('resultWorkData.subjectId'), true)) {
          return;
        }

        // if (!this.getHasEditItems()) {
        //   console.log('not editing!!!', this.getHasEditItems());
        //   return;
        // }
        this.getRegisterCultureResult('preliminary');
      },
      //최하단 저장버튼
      onFinalSaveClick() {
        if(!this.checkGPatientId(this.get('resultWorkData.subjectId'), true)) {
          return;
        }
        // if(!this._checkEditingItem()) {
        //   this.showWarningMessage(this.getLanguageResource('9231', 'F', '', '저장 되지 않은 데이터가 있습니다.'), 2000);
        //   return;
        // }
        // if (!this.getHasEditItems()) {
        //   console.log('not editing!!!', this.getHasEditItems());
        //   return;
        // }
        if (this.get('observationCulturesData.statusCode') === 'final' || this.get('observationCulturesData.statusCode') === 'corrected') {
          this.set('isCorrectReasonEntryOpened', true);
        } else {
          this.getRegisterCultureResult('final');
        }
      },
      onExampleResetClick() {
        this.set('model.exampleSelectedItems', []);
        this.set('model.exampleSelectedItemsText', []);
        this.set('exampleSelectedItemsTextTooltip', null);
        this.set('exampleSelectedItemsString', null);
        this.get('ExampleGrid').deselectAll();
      },
      onExampleApply() {
        const changedTextValue = this.get('model.exampleSelectedItemsText');
        if(isEmpty(changedTextValue)) {
          return;
        }
        this.set('model.resultExamplesInputText', changedTextValue.split(', ').join('\r\n'));
        this.set('exampleSelectedItemsTextTooltip', changedTextValue.split(', ').join('<br>'));
        this.set('isResultExampleOpen', false);
        this._identificationGridItemChange(changedTextValue, 'resultContent');
      },
      onResuletExampleOpend() {
        const exampleValue = this.get('model.resultExamplesInputText');
        if(isPresent(exampleValue)) {
          this.set('model.exampleSelectedItemsText', exampleValue.replace(/\n|\r\n/giu, ', '));
        }
      },
      onExampleCloseClick() {
        this.set('isResultExampleOpen', false);
      },
      onCultureCumulativeSearchBtnClick() {
        this.set('isCumulativePopupOpen', true);
      },

      /*
       * input Field change
       */
      onInputFieldItemChanged(e) {
        // console.log('onInputFieldItemChangede--', e);
        this._identificationGridItemChange(e.value, e.source.id);
        this.set('isEditingIdentificationItems', true);
      },

      /**
       * other component callback
       */
      onReturnIdentification(returnItems) {
        // console.log('onReturnIdentification', returnItems);
        if (!isEmpty(returnItems)) {
          // const identificationGridItems = this.get('identificationResultItemsSource');
          // const findedSameObj = identificationGridItems.find(item => item.codeableConceptCoding.code === returnItems.displayCode);
          // if (findedSameObj) {
          //   this.showWarningMessage(this.getLanguageResource('9226', 'F', '이미 추가되어있습니다.'), 2000);
          // } else {
          //   this.set('model.identificationSelectedItem.codeableConceptCoding.code', returnItems.displayCode);
          //   this.set('model.identificationSelectedItem.codeableConceptCoding.displayName', returnItems.name);
          //   // this.get('identificationResultItemsSource').addObject(tempObj);
          //   this.set('isIdentificationOpen', false);
          //   this.set('isEditingIdentificationItems', true);
          // }
          this.set('model.identificationSelectedItem.codeableConceptCoding.code', returnItems.displayCode);
          this.set('model.identificationSelectedItem.codeableConceptCoding.displayName', returnItems.name);
          // if (isEmpty(this.get('model.identificationSelectedItem.observationId'))) {
          //   this._identificationsBySusceptibilitys(returnItems.displayCode);
          // }
          // this.get('identificationResultItemsSource').addObject(tempObj);
          this.set('isIdentificationOpen', false);
          this.set('isEditingIdentificationItems', true);
        }
      },
      onReturnChangesReason(returnObj) {
        // console.log('returnObj---', returnObj);
        this.set('model.resultReason.reasonCode', returnObj.code);
        this.set('model.resultReason.reasonContent', returnObj.name);
        this.getRegisterCultureResult('final');
      },
      onReasonEntryCancel() {
        this.set('isCorrectReasonEntryOpened', false);
        this.set('isIdentificationLoader', false);
        this.set('isGridContainerLoader', false);
        this.set('isSusceptibilityDisabled', false);
        this.set('isButtonDisabled', false);
      },
      onRefreshClick() {
        this.set('model.resultExamplesInputText', null);
        this.set('exampleSelectedItemsTextTooltip', null);
        this.set('exampleSelectedItemsString', null);
        this.set('isEditingIdentificationItems', false);
        this.set('isEditingSusceptibilityItems', false);
        this.set('identificationResultItemsSource', []);
        this.set('isRecordExportOpen', false);
        this.getDataList();
      },
    },
    onBeforePatientChange() {
      this._super(...arguments);
      if(this.get('isEditingIdentificationItems') === true || this.get('isEditingSusceptibilityItems') === true) {
        return false;
      } else {
        // this.set('specimenNumber', null);
        // this.set('examinationCode', null);
        return true;
      }

    },
    onPatientChange(canchange) {
      this._super(...arguments);
      if (canchange === false) {
        const options = {
          'caption': this.getLanguageResource('10251', 'F', '', '환자 선택 변경 진행중'),
          'messageBoxButton': 'YesNoCancel',
          'messageBoxImage': 'question',
          'messageBoxText': `[ ${this.get('menuTitle')} ]<br>${this.getLanguageResource('9231', 'F', null, '저장하지 않은 데이터가 있습니다.')}.<br>${this.getLanguageResource('8939', 'F', null, '저장하시겠습니까?')}`,
          'messageBoxFocus': 'Yes'
        };
        return messageBox.show(this, options).then(function (result) {
          if(result==='Yes'){
            if (this.get('isEditingIdentificationItems')) {
              this._saveBacterialIdentifications();
            } else if (this.get('isEditingSusceptibilityItems')) {
              this._saveIdentificationsSusceptibility();
            }
            this.continuePatientChanging();
          } else if (result==='No'){
            this.continuePatientChanging();
          } else if (result==='Cancel'){
            this.cancelPatientChanaging();
          }
        }.bind(this));
      }

    },
    onOpenMenuParamsChanged(e) {
      this._super(...arguments);
      console.log('onOpenMenuParamsChanged---', e);
      if(isEmpty(e)){
        return;
      }
      this.set('specimenNumber', e.specimenNumber);
      this.set('examinationCode', e.examinationCode);
      this._init();

    },
    onPatientChanged(Patient){
      this._super(...arguments);
      this.set('globalPatient', Patient);
      this.set('isEditingIdentificationItems', false);
      this.set('isEditingSusceptibilityItems', false);
      if(isEmpty(Patient)){
        return;
      }
      if(this.checkPatientDataClear() === true) {
        this._setDatasReset();
        return;
      }
      // this._init();
      if(!isEmpty(this.get('observationCulturesData')) && (this.get('observationCulturesData.subject.displayNumber') !== Patient.patientDisplayId)) {
        // this.get('co_MenuManagerService').closeMenu(this.get('viewId'));
        this._setDatasReset();
        return;
      }
      const examinationSpecimenId = this.get('co_PatientManagerService.selectedPatient.examination.specimenId');
      if(isEmpty(examinationSpecimenId)) {
        this._setDatasReset();
        return;
      }
      this.set('specimenNumber', null);
      this.set('specimenId', examinationSpecimenId);
      this._init();
    // if(isEmpty(this.get('specimenNumber'))) {
      //   this._setDatasReset();
      // }
    },

    _init() {
      this._setDatasReset();
      this.getDataList();
    },

    _setDatasReset() {
      this.set('identificationResultItemsSource', []);
      this.set('resultWorkData', null);
      this.set('observationCulturesData', null);
      this.set('dianosticReportStain', null);
      // this.set('bacterialMethodItems', []);
      // this.set('mediaItems', []);
      // this.set('interpretationItems', []);
      this.set('identificationRemoveIds', []);
      // this.set('colonyContentItems', []);
      // this.set('resultExampleList', []);
      this.set('isEditingIdentificationItems', false);
      this.set('isButtonDisabled', true);
      this.set('isPreSaveDisabled', true);
      this.set('isShowUnitItem', false);
      this.set('currentLocation', null);
      this.set('locationTooltip', null);
      this.set('model.resultExamplesInputText', null);
      this.set('exampleSelectedItemsTextTooltip', null);
      this.set('exampleSelectedItemsString', null);
      this._setSusceptibilitysDataReset();

    },

    async getBusinessCodeList() {
      try {
        // this.set('cvrReasonItemList', []);
        // this.set('bacterialMethodItems', []);
        // this.set('interpretationItems', []);
        // this.set('mediaItems', []);
        // this.set('colonyContentItems', []);
        // this.set('resultExampleList', []);
        const searchCodes = [
          'CVRReason',
          'BacterialIdentificationMethod',
          'MediaCode',
          'BacterialIdentificationInterpretation',
          'ColonyContent',
          'CultureResultExample'
        ];
        const resultList = await this.get('cultureResultService').getBusinessCodeList({classificationCodes: searchCodes});
        resultList.forEach(item => {
          this._setPartialBusicessCodes(item);
        });
        this.getQuantityComparator();
      } catch(e) {
        console.log('specimen-examination-report-culture-result-management getBusinessCodeList Error::', e);
      }
    },
    async _getDepartmentComments(){
      try {
        this.set('comments', {
          isCommentsExpanded: false,
          deptCommentsCount: 0
        });
        if(isEmpty(this.get('resultWorkData'))){
          return;
        }
        const res = await this.get('specimenexaminationreportService').getDepartmentComments(this.get('resultWorkData'));
        if(!isEmpty(res)){
          this.set('comments', res);
        }
      } catch(e) {
        console.error(e);
      }
    },
    async _getDelayReason() {
      if(isEmpty(this.get('resultWorkData'))){
        return;
      }
      const params = {
        specimenId: this.get('resultWorkData.specimenId'),
        checkinId: this.get('resultWorkData.checkInId'),
      };
      try {
        const result = await this.getList(this.get('checkinUrl') + 'specimen-checkins/observation-delay-specimens', params, null);
        if(isPresent(result)) {
          set(this.get('comments'), 'isCommentsExpanded', true);
        }
      }catch(e) {
        console.error(e);
      }
    },
    _initProps() {
      this.set('contentLoaderType', 'spinner');
      this.set('loaderDimed', false);
      this.set('isIdentificationLoader', true);
      this.set('isPreSaveDisabled', true);
      this.set('isRecordExportOpen', false);
      this.set('resultCultures', null);
      this.set('isShowDisplayResult', false);
    },
    async getDataList() {
      try {
        this._initProps();
        const resultWorksInfo = await this._getResultWorkData();
        if(isEmpty(resultWorksInfo)) {
          this.set('isIdentificationLoader', false);
          return;
        }
        if(!this.checkGPatientId(resultWorksInfo.subjectId, false)) {
          // this.get('co_MenuManagerService').closeMenu(this.get('viewId'));
          this.set('isIdentificationLoader', false);
          return;
        }
        if(!isEmpty(resultWorksInfo.ward)) {
          this.set('currentLocation', `${resultWorksInfo.ward.displayCode} / ${resultWorksInfo.room.roomCode} / ${resultWorksInfo.bed.displayCode}`);
          this.set('locationTooltip', `${resultWorksInfo.ward.name} / ${resultWorksInfo.room.roomName} / ${resultWorksInfo.bed.name}`);
        }
        const remarkResult = await this.get('cultureResultService').getObservationsResultRemarks(resultWorksInfo, 'tlanumber');
        this.set('specimenNumber', resultWorksInfo.specimenNumber);
        resultWorksInfo.TLANumber = remarkResult;
        this.set('resultWorkData', resultWorksInfo);
        const resultCulturesParams = {
          specimenNumber: resultWorksInfo.specimenNumber,
          checkInId: resultWorksInfo.checkInId
        };
        // const specimensOverview = await this.get('cultureResultService').getSpecimenCheckInOverview({specimenNumber: resultWorksInfo.specimenNumber});
        this._getSpecimenInformation(resultWorksInfo.specimenNumber);
        this._getResultRemarks(resultCulturesParams);
        const observationsResultCultures = await this._getResultCultures(resultCulturesParams);
        if(isEmpty(observationsResultCultures)) {
          this._setDatasReset();
          this.set('isIdentificationLoader', false);
          return;
        }
        if((observationsResultCultures.valueTypeCode === 'CodeableConcept' || observationsResultCultures.valueTypeCode === 'ValueString')
        && isPresent(observationsResultCultures.value)) {
          this.set('isShowDisplayResult', true);
        }
        this.set('resultCultures', observationsResultCultures);
        if(this.get('observationCulturesData.statusCode') === 'final' || this.get('observationCulturesData.statusCode') === 'corrected') {
          this.set('isPreSaveDisabled', true);
        } else {
          this.set('isPreSaveDisabled', false);
        }
        if(isPresent(this.get('observationCulturesData.value')) && isPresent(this.get('observationCulturesData.value.recordNoteId'))) {
          this.set('calcHeight', 'height:calc(48% - 138px);');
          this.set('isRecordExportOpen', true);
        }
        this.toggleProperty('initializeTimeVolume');
        const searchStainParams = {
          subjectTypeCode: 'Patient',
          subjectId: resultWorksInfo.subjectId,
          specimenId: resultWorksInfo.specimenId
        };
        this._getSearchStainSearchStain(searchStainParams);
        const bacterialIdentifications = await this.getBacterialIdentifications(observationsResultCultures.observationId);
        if (!isEmpty(bacterialIdentifications)) {
          this.set('identificationResultItemsSource', bacterialIdentifications);
          // const result = $.extend(true, [], bacterialIdentifications.map(function(e){
          //   return $.extend(false, {}, e);
          // }));
          // this.set('identificationResultItemsOriginal', result);
          this.set('model.identificationSelectedItem', bacterialIdentifications[0]);
        } else {
          this.set('isIdentificationsFieldsDisabled', true);
        }
        this.set('isButtonDisabled', false);
        this.set('isIdentificationsDisabled', false);
        this.set('isIdentificationLoader', false);
        this._getDepartmentComments();
        this._getDelayReason();
        this.$('.scrollbar-macosx').scrollbar();
      } catch (e) {
        if(!this.get('isDestroyed')) {
          this.set('isIdentificationLoader', false);
        }
        this._showError(e);
      }
    },

    async _getSearchStainSearchStain(params) {
      try {
        this.set('dianosticReportStain', null);
        const result = await this.get('cultureResultService').getDianosticReportSearchStain(params);
        if(isPresent(result)) {
          this.set('dianosticReportStain', result[0]);
        }
      }catch(e) {
        console.log(e);
      }
    },

    async _getResultCultures(params) {
      try {
        const observationsResultCultures = await this.get('cultureResultService').getObservationsResultsCultures(params);
        if(!isEmpty(observationsResultCultures)) {
          // if(observationsResultCultures[0].subject.displayNumber !== this.get('globalPatientInfo.patientDisplayId')) {
          //   this.get('co_MenuManagerService').closeMenu(this.get('viewId'));
          //   return;
          // }
          const unitItem = this.getUnitItem(observationsResultCultures[0]);
          this.set('model.unitMarkItem', unitItem);
          if(observationsResultCultures[0].statusCode !== 'waiting') {
            this.set('isShowUnitItem', true);
          }
          this.set('observationCulturesData', observationsResultCultures[0]);
          this.set('cvrInfo', observationsResultCultures[0]);
          return observationsResultCultures[0];
        }
      } catch(e) {
        console.log('_getResultCultures Error::', e);
      }
    },

    async _getResultRemarks(params) {
      try {
        const specimenExaminations = await this.get('cultureResultService').getCulturesBacterialIdentificationsSpecimenExaminations(params);
        this.set('isRemarkPopupLoader', false);
        if(isEmpty(specimenExaminations)) {
          return;
        }
        this.set('resultRemarkList', null);
        this.set('specimenExaminationId', specimenExaminations.specimenExaminationId);
        const exampleParams = {exampleTypeCode: 'ResultRemark', examinationId: specimenExaminations.specimenExaminationId};
        const resultRemarks = await this.get('cultureResultService').getObservationsExamples(exampleParams);
        const exampleValueParams = {exampleTypeCode: 'ExampleValue', examinationId: specimenExaminations.specimenExaminationId};
        const exampleValueResult = await this.get('cultureResultService').getObservationsExamples(exampleValueParams);
        console.log('exampleValueResult---', exampleValueResult);
        resultRemarks.map(d => {
          d.isChecked = false;
        });
        this.set('resultRemarkList', resultRemarks);
        return resultRemarks;
      } catch(e) {
        this.set('isRemarkPopupLoader', false);
        // this._showError(e);
        console.log('_getResultRemarks Error::', e);

      }
    },

    _identificationGridItemChange(item, column) {
      const selectedIndex = this.get('model.selectedItemIndex');
      if (!isEmpty(selectedIndex)) {
        const gridList = this.get('identificationResultItemsSource');
        set(gridList[selectedIndex], column, item);
      }
    },

    _setRemarkCellsItemChange() {
      const remarkList = this.get('resultRemarkList');
      const selectedIndex = this.get('model.selectedItemIndex');
      const gridList = this.get('identificationResultItemsSource');

      const checkedRemarks = [];
      remarkList.forEach(item => {
        if(item.isChecked) {
          checkedRemarks.push(item.value.valueString);
        }
      });
      const remarksText = checkedRemarks.join('<br>');
      set(gridList[selectedIndex], 'remark', remarksText);
      this.set('isRemarkDetailPopupOpen', false);
    },

    _setRemoveIdentificationItems() {
      const removeList = this.get('identificationRemoveIds');
      const selectedItem = this.get('model.identificationSelectedItem');
      if (!isEmpty(selectedItem.observationId)) {
        removeList.push(selectedItem.observationId);
      }
      this.get('identificationResultItemsSource').removeObject(selectedItem);
      if(isEmpty(this.get('identificationResultItemsSource'))) {
        this.set('isIdentificationsFieldsDisabled', true);
      }
      this.get('identificationGrid').selectRow(this.get('identificationResultItemsSource').length - 1);
      this.set('isEditingIdentificationItems', true);
    },


    async _saveBacterialIdentifications() {
      try {
        this.set('contentLoaderType', 'progress');
        this.set('loaderDimed', true);
        this.set('isIdentificationLoader', true);
        const changedList = this._getChangedResultData(this.get('identificationResultItemsSource'));
        if(!isEmpty(changedList)) {
          const saveParams = {
            cultureObservationId: this.get('observationCulturesData.observationId'),
            issuedStaffId: this.get('globalCurrentUser.employeeId'),
            bacterialIdentificationResult: changedList
          };
          await this.get('cultureResultService').createCulturesBacterialIdentifications(saveParams);
        }
        const deleteParams = {
          cultureObservationId: this.get('observationCulturesData.observationId'),
          bacterialIdentificationObservationId: this.get('identificationRemoveIds'),
        };
        if (!isEmpty(this.get('identificationRemoveIds'))) {
          await this.get('cultureResultService').deleteCulturesBacterialIdentifications(deleteParams);
        }
        this.showToastSaved();
        const bacterialIdentifications = await this.getBacterialIdentifications(this.get('observationCulturesData.observationId'));
        this.set('identificationResultItemsSource', bacterialIdentifications);
        const targetSelectRowIndex = this.get('model.selectedItemIndex');
        if(!isEmpty(targetSelectRowIndex)) {
          this.set('model.identificationSelectedItem', bacterialIdentifications[targetSelectRowIndex]);
        } else {
          this.set('isIdentificationsFieldsDisabled', true);
        }

        this.set('identificationRemoveIds', []);
        this.set('isEditingIdentificationItems', false);
        this.set('isNewAddedRow', false);
        this.set('isIdentificationLoader', false);
      } catch(e) {
        this.set('isIdentificationLoader', false);
        this._showSaveError(e);
        console.log('createCulturesBacterialIdentifications Error::::', e);
      }
    },

    async getRegisterCultureResult(status) {
      // if (!this.getHasEditItems()) {
      //   console.log('not editing!!!', this.getHasEditItems());
      //   return;
      // }
      try {
        const params = this.getRegisterCultureParams(status);
        if(isEmpty(params)) {
          return;
        }
        this.set('isButtonDisabled', true);
        this.set('contentLoaderType', 'progress');
        this.set('loaderDimed', true);
        this.set('isGridContainerLoader', true);
        await this.get('cultureResultService').createObservationsResultsCultures(params);
        this.showToastSaved();
        this.set('model.resultReason.reasonCode', null);
        this.set('model.resultReason.reasonContent', null);
        this.set('identificationResultItemsSource', []);
        this.set('model.resultExamplesInputText', null);
        this.set('exampleSelectedItemsTextTooltip', null);
        this.set('exampleSelectedItemsString', null);
        this.set('contentLoaderType', 'spinner');
        this.set('loaderDimed', false);
        this.get('co_ContentMessageService').sendMessage('updateMessage', 'D');
        if(status === 'final' || status === 'corrected') {
          this.get('co_ContentMessageService').sendMessage('test_result_viewer_refresh_specimen');
        }
        this.set('isGridContainerLoader', false);
        this.set('isButtonDisabled', false);
        await this.getDataList();
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isGridContainerLoader', false);
          this.set('isButtonDisabled', false);
        }
        this._showSaveError(e);
        console.log('getRegisterCultureResult Error::::', e);
      }
    },
    _addIdentificationsRow() {
      let tempObj = {};
      tempObj = this._getIdentificationDefaultObject();
      const identificationGridItems = this.get('identificationResultItemsSource');
      let lastSequence = 1;
      if (!isEmpty(identificationGridItems)) {
        const targetIndex = identificationGridItems.length - 1;
        lastSequence = identificationGridItems[targetIndex].colonySequence + 1;
      }
      tempObj.colonySequence = lastSequence;
      this.get('identificationResultItemsSource').addObject(tempObj);
      this.get('identificationGrid').deselectAll();
      this.get('identificationGrid').selectRow(tempObj);
      this.set('isIdentificationsFieldsDisabled', false);
      this.set('isEditingIdentificationItems', true);
      this.set('isNewAddedRow', true);
    },


  });