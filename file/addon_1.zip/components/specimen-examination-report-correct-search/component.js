import EmberObject, { set } from '@ember/object';
import { isEmpty } from '@ember/utils';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from '../../app-config';
import { inject as service } from '@ember/service';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MessageMixin,
  /* Only For Server-Call Component
  CHIS.FR.CrossCutting.ServerCallMixin,
  */
  {
    /* 1. Service define Area
   testService:Ember.inject.service(),
   */
    layout,
    specimenexaminationreportService: service('specimen-examination-report-service'),
    // 2. Property Area
    defaultUrl: null,
    isChangesLogOpened: null,
    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      //this.set('menuClass', 'w1000');
      this.set('viewId','specimen-examination-report-correct-search');
      //Set Stateful properties
      this.setStateProperties([
        'defaultUrl',
        'periodRadioBtnitemsSource'
      ]);
      if (this.hasState() === false) {
      //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')
        +`specimen-examination-report/${config.version}/`);
        this.set('periodRadioBtnitemsSource', [
          { text : this.getLanguageResource('16991', 'S','Check-in Date'), value : 'CheckIn'},
          { text : this.getLanguageResource('16992', 'S','Edited Date'), value : 'ObservationResultChange'},
        ]);
        this.set('changesGridColumns', [
          { title: this.getLanguageResource('789', 'S','Check-in Date'), field: 'checkInDatetime', width: 90, type: 'date', dataFormat: 'd',align: 'center'},
          { title: this.getLanguageResource('16993', 'S','Edited Time'), field: 'changeDatetime', width: 125, type: 'date', dataFormat: 'u',align: 'center' },
          { title: this.getLanguageResource('16881', 'F','Pt Name'), field: 'subject.name', bodyTemplateName: 'boldTooltip',align: 'center', width: 90},
          { title: this.getLanguageResource('8451', 'S','MRN'), field: 'subject.number', bodyTemplateName: 'bold',align: 'center',width: 65},
          { title: this.getLanguageResource('3680', 'F','Sex'), field: 'subject.gender',align: 'center', width: 35 },
          { title: this.getLanguageResource('1662', 'F','Age'), field: 'subject.age', align: 'center', width: 45 },
          { title: this.getLanguageResource('16921', 'S','Specimen Name'), field: 'specimenType.name',bodyTemplateName: 'tooltip', width: 105 },
          { title: this.getLanguageResource('859', 'S','Specimen No.'), field: 'specimenNumber', width: 90 ,align: 'center'},
          { title: this.getLanguageResource('16892', 'S','Exam.Type'), field: 'classification.name', width: 120, bodyTemplateName: 'tooltip'},
          { title: this.getLanguageResource('16920', 'S','Exam Name'), field: 'examination.name',bodyTemplateName: 'tooltip', width: 190},
          { title: this.getLanguageResource('890', 'F', '결과'), field: 'displayResult', bodyTemplateName: 'detailview', width: 90},
          { title: this.getLanguageResource('16994', 'S','Edited Result'), field: 'displayChangeResult', bodyTemplateName: 'detailview', width: 90},
          { title: this.getLanguageResource('16995', 'S','Edited Reason'), field: 'reasonContent',bodyTemplateName: 'reasonContent'},
          { title: this.getLanguageResource('16996', 'S','Edited by'), field: 'changeStaff.name',align: 'center',bodyTemplateName: 'tooltip', width: 75},
        ]);
        this.set('contextMenuSource', [
          { action : this._openChangesLog.bind(this), text : this.getLanguageResource('4155', 'F','Edit History'), disabled : false, display : true},
        ]);
        const today= this.get('co_CommonService').getNow();
        this.set('searchCondition',{
          periodTypeCode: 'CheckIn',
          fromDate: today,
          toDate: today,
        });
        this._searhChanges();
      }
    //Initialize Stateless properties
    },
    _openChangesLog(e){
      if(isEmpty(e.dataItem.item)){
        return;
      }
      // this.set('selectedChangesGridItem', e.dataItem.item);
      this.set('isChangesLogOpened', true);
      this.set('item', e.dataItem.item);
    },
    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1360');
      // if (this.hasState() === false) {
      // }
    },

    // 4. Actions Area
    actions: {

      onGridLoad(e){
        this.set('correctSerachGrid', e.source);
      },

      onTextCommit(e){
        this.set('changesLogGridItemsSource', e.source.value? this._filtering(e.source.value) : this.get('changesLogGridItemsSourceCopy'));
      },

      onTextCleared(){
        this.set('changesLogGridItemsSource', this.get('changesLogGridItemsSourceCopy'));
      },
      onSearchClick(){
        this._searhChanges();
      },

      onDetailClick(item, col){
        if(!isEmpty(item)){
          if(col.title==this.getLanguageResource('890', 'F', '결과')){
            if(item.recordNoteId !== null){
              set(item, 'isDetailOpen', false);
              this.set('isSpecimenExamDetailOpen', true);
              this.set('detailView', EmberObject.create({
                title: item.examination.abbreviation,
                recordNoteId: item.recordNoteId,
              }));
            }else{
              this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('8948', 'F', '해당정보가 없습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
            }
          }
          if(col.title==this.getLanguageResource('4148', 'S', '수정결과')){
            if(item.changeRecordNoteId !== null){
              set(item, 'isPrevDetailOpen', false);
              this.set('isSpecimenExamDetailOpen', true);
              this.set('detailView', EmberObject.create({
                title: item.examination.abbreviation + " "+this.getLanguageResource('4148', 'S','Edited Result'),
                recordNoteId: item.changeRecordNoteId,
              }));
            }else{
              this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('8948', 'F', '해당정보가 없습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
            }
          }
        }
      },
      onDetailViewClosed(){
        set(this.get('detailView'), 'title', null);
        set(this.get('detailView'), 'recordNoteId', null);
      },

      onExcelPrintAction() {
        const itemsSource = this.get('changesLogGridItemsSource');
        const columns = this.get('changesGridColumns');
        if(isEmpty(itemsSource)){
          this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9264', 'F', '조회된 정보가 없습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }

        const gridSource=this.get('correctSerachGrid');
        const reason = 'Excel export_specimen examination correct search';
        const headers=[];
        const fields=[];
        columns.forEach(function(item, index){
          headers.addObject({ left: index, top: 0, right: index, bottom: 0, value: item.title});
          item.type == 'date'? fields.addObject({ width: 140, value: item.field }) : fields.addObject({ width: item.width, value: item.field });
        });
        gridSource.exportToExcel('specimen_examination_correct_search.xlsx', headers, fields, this, 'onExcelPrintAction', reason , itemsSource);
      },

      onContextMenuOpen(e){
        this.set('selectedChangesGridItem', e.dataItem.item);
      }
    },
    // 5. Private methods Area

    _searhChanges(){
      const searchCondition= this.get('searchCondition');
      if(searchCondition.fromDate.getHours() !=0){
        searchCondition.fromDate= new Date(searchCondition.fromDate.getFullYear(), searchCondition.fromDate.getMonth(), searchCondition.fromDate.getDate(), 0, 0, 0) ;
        searchCondition.toDate= new Date(searchCondition.toDate.getFullYear(), searchCondition.toDate.getMonth(), searchCondition.toDate.getDate(), 0, 0, 0) ;
      }
      searchCondition.observationId=null;
      searchCondition.examinationId=this.get('searchKey.specimenExaminationId');
      this.set('isGridShow', true);
      this.getList(this.get('defaultUrl') + 'observations/changes/search', null, searchCondition, false).then(res=>{
        this.set('isGridShow', false);
        if(isEmpty(res)){
          this.set('changesLogGridItemsSource', null);
        }else{
          res.forEach(element => {
            set(element, 'reasonContent', isEmpty(element.reasonContent)? null: element.reasonContent.replace(/<br>|<br\/>|<br \/>/giu, '\r\n'));
            set(element, 'reasonContentTooltip', isEmpty(element.reasonContent)? null: element.reasonContent);
          });
          this.set('changesLogGridItemsSource', res);
          this.set('changesLogGridItemsSourceCopy', res);
        }
      }).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    _filtering(text){
      if(isEmpty(text)){
        return;
      }
      this.set('isGridShow', true);
      const tmp=[];
      if(!isEmpty(this.get('changesLogGridItemsSourceCopy'))){
        this.get('changesLogGridItemsSourceCopy').forEach(element => {
          if(element.examination.name.toLocaleLowerCase().includes(text.toLocaleLowerCase())
          || element.examination.displayCode.toLocaleLowerCase().includes(text.toLocaleLowerCase())){
            tmp.addObject(element);
          }
        });

      }
      this.set('isGridShow', false);
      return tmp;

    },

    _catchError(e){
      this.set('isGridShow',false);
      this.showResponseMessage(e);
    }
  });