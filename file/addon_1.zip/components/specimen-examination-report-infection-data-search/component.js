/* eslint-disable prefer-named-capture-group */
/* eslint-disable no-console */
// import $ from 'jquery';
import { isEmpty } from '@ember/utils';
import { A as emberA } from '@ember/array';
import layout from './template';
import CHIS from 'framework/chis-framework';
import BasicMixin from '../../mixins/specimen-examination-report-basic-mixin';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';
import PrintMixin from 'specimenexaminationreport-module/mixins/specimen-examination-report-print-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  BasicMixin,
  MessageMixin,
  PrintMixin,
  {
    layout,
    isShowLoader: false,
    isFirstLoading: true,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-infection-data-search');

      this.setStateProperties([
        'gridColumns',
        'gridItems',
        'classificationList'
      ]);
      if (!this.hasState()) {
        this.set('model', {
          gridSelectedItem: null,
          categoryCode: null,

        });
        this.set('gridColumns', [
          { field: 'checkInDate', title: this.getLanguageResource('6777', 'F', '', '접수일'), width: 100, align: 'center', type: 'date', dataFormat: 'd',},
          { field: 'checkInNumber', title: this.getLanguageResource('6767', 'F', '', '접수번호'), width: 80, align:'center'},
          { field: 'patient.displayNumber', title: this.getLanguageResource('8451', 'F', '', '환자번호'), width: 80, align: 'center',},
          { field: 'patient.name', title: this.getLanguageResource('16881', 'F', '', '환자명'), width: 70, align: 'center',},
          { field: 'department.name', title:  this.getLanguageResource('17109', 'S','', '의뢰처'), width: 80,},
          { field: 'specimenType.name', title: this.getLanguageResource('840', 'F', '', '검체'), width: 100, bodyTemplateName:'textTooltip'},
          { field: 'identificationResult.displayContent', title: this.getLanguageResource('2052', 'F', '', '동정결과'), width: 160, bodyTemplateName: 'identificationTooltip'},
          { field: 'susceptibilityResult', title: this.getLanguageResource('13263', 'F', '', '항생제 감수성결과'), width: 640, bodyTemplateName:'resultTooltip'},
        ]);
        this.set('classificationList', emberA());
      }

    },
    onLoaded() {
      this._super(...arguments);

      this.set('menuClass', 'w1360');
      this._getSearchConditionList();
    },
    actions: {
      onFromToUpdated(e) {
        const fromDate = this.get('fr_I18nService').formatDate(e.selectedFromDate, 'd');
        const toDate = this.get('fr_I18nService').formatDate(e.selectedToDate, 'd');
        this.getGridItemList(`${fromDate} ~ ${toDate}`);
      },
      onSearchAction() {
        this.getDataList();
      },
      onExcelClick() {
        this._getExcelData();
      },
      onClassificationChanged(e) {
        if(!isEmpty(e.item)) {
          this.set('model.categoryCode', e.item.categoryCode);
          this.getGridItemList(e.item.value);
        }
      }
    },
    getDataList() {
      this.getGridItemList();
    },
    async _getSearchConditionList() {
      const result = await this.getList(`${this.get('urlPrefix')}/infection-management/infection-data/classification-list`, null, null);
      this.set('classificationList', result);
      if(!isEmpty(result)) {
        this.set('model.categoryCode', result[0].categoryCode);
        this.getDataList();
      }

    },
    async getGridItemList(refreshContent) {
      try {
        this.set('gridItems', emberA());
        this.set('isShowLoader', true);
        const {fromDate, toDate} = this._getSearchFromTo();
        const params = {
          fromDate: fromDate,
          toDate: toDate,
          categoryCode: this.get('model.categoryCode'),
        };
        const result = await this.getList(`${this.get('urlPrefix')}/infection-management/infection-data/patient-list`, params, null);
        if (!isEmpty(result)) {
          if(!isEmpty(refreshContent)) {
            this.showToastRefresh(refreshContent);
          }
          result.map(item => {
            let identificationResultText = '';
            if(!isEmpty(item.identificationResult.displayContent)) {
              identificationResultText = item.identificationResult.displayContent.replace(/(\n|\r\n)/gu, '<br>');
            }
            item.identificationResultTooltip = identificationResultText;
          });
          this.set('gridItems', result);
        }
        if(isEmpty(result) && !this.get('isFirstLoading')) {
          this.showToastNoData();
        }
        this.set('isFirstLoading', false);
        this.set('isShowLoader', false);
      } catch(e) {
        this._showError(e);
        this.set('isShowLoader', false);
        console.log('getGridItemList Error :::::', e);
      }

    },
    _getExcelData() {
      const gridItemsSource = this.get('gridItems');
      const firstRow = [];
      const colInfo = [];
      const columns = this.get('gridColumns');
      columns.forEach(column => {
        if(!isEmpty(column.field)) {
          firstRow.push(column.title);
          colInfo.push({wpx: column.width});
        }
      });
      const initArr = [firstRow];
      const resultArr = [];
      gridItemsSource.forEach(datas => {
        const tempArr = [];
        columns.forEach(col => {
          if(!isEmpty(col.field)) {
            const fields = col.field.split('.');
            let fieldsData = datas[col.field];
            if(fields.length > 1) {
              fieldsData = datas[fields[0]][fields[1]];
            }
            tempArr.push(fieldsData);
          }
        });
        resultArr.push(tempArr);
      });
      this.getExportByArrayTypeExcel(initArr, resultArr, colInfo);
    },

  });