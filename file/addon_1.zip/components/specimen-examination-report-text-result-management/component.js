/* eslint-disable max-lines */
/* eslint-disable chis/require-template-convention */
/* eslint-disable no-console */
import $ from 'jquery';
import { A } from '@ember/array';
import moment from 'moment';
// import { next } from '@ember/runloop';
import { set, get } from '@ember/object';
import { isEmpty, isPresent } from '@ember/utils';
import { hash } from 'rsvp';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from '../../app-config';
import KmiSgin from 'co-security/mixins/kmi-sign-mixin';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';
export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, KmiSgin, MessageMixin,
  {
    layout,
    specimenexaminationreportService: service('specimen-examination-report-service'),
    // 2. Property Area
    defaultUrl: null,
    specimenNumber:null,
    examinationCode:null,
    currentUser:null,
    selectedValue:null,
    selectedDetailInfo:null,
    generalRecodeType:null,
    copyRecode:null,
    isTextResultManagementShow: null,
    comments: null,
    cvrSendInformation: null,
    isContentEditing: false,
    isShowDimmed: false,
    isEditDisplay: true,
    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId', 'specimen-examination-report-text-result-management');

      //Set Stateful properties
      this.setStateProperties([
        'defaultUrl',
        'currentUser',
        'specimenNumber',
        'examinationCode',
        'selectedValue',
        'selectedDetailInfo',
        'generalRecodeType',
        'copyRecode',
        'comments',
        'cvrSendInformation',
        'isPreliminaryChecked'
      ]);
      if (this.hasState() === false) {
      //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport') +`specimen-examination-report/${config.version}/`);
        this.set('checkinUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimencheckin')+'specimen-checkin/v0/');
        this.set('currentUser', this.get('co_CurrentUserService.user'));
        //기록지타입 'E037'도 나중에 Back-End쪽에서 관리되게 해야함.
        this.set('generalRecodeType', 'E037');
        this.set('selectedDetailInfo', {});
        this.set('copyRecode', {isPasteDisable: true, recordTypeCode: null, recordNoteId: null});
        this.set('comments', {
          isCommentsExpanded: false,
          deptCommentsCount: 0,
          notification:false ,
        });
        // this.set('isTextResultManagementShow', true);
      }
    //Initialize Stateless properties
    },

    onOpenMenuParamsChanged(params){
      this._super(...arguments);
      console.log('-----onOpenMenuParamsChanged ---------recordNoteId-----');
      console.log(this.get('selectedDetailInfo.recordNoteId'));
      this.set('generalRecodeType', 'E037');
      this.set('selectedDetailInfo', {});
      console.log(this.get('selectedDetailInfo.recordNoteId'));
      this.set('specimenNumber', params.specimenNumber);
      this.set('examinationCode', params.examinationCode);
      console.log(this.get('selectedDetailInfo'));
      this._initialize();
    },
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w680');

      if (this.hasState() === false) {
        const defaultUrl = this.get('defaultUrl');
        hash({
          cvrReasonItemList: this.getList(defaultUrl + 'business-codes/search', {classificationCode: 'CVRReason'}, null),
        }).then(function(result) {
          if(!isEmpty(result.cvrReasonItemList)){
            result.cvrReasonItemList.map(item =>{
              set(item, 'businessCode', item.code);
              return item;
            });
          }
          this.set('cvrReasonItemList', result.cvrReasonItemList);
          const contentSource= this.getOpenMenuParams();

          //받아오는 Params은 2개만 받아오면됨. - 검체번호, 검사코드
          if(!isEmpty(contentSource)){
            this.set('specimenNumber', contentSource.specimenNumber);
            this.set('examinationCode', contentSource.examinationCode);
          }
          this._initialize();

          this._setWorkListParams('specimenId', this.get('co_PatientManagerService.selectedPatient.examination.specimenId'));
        }.bind(this)).catch(function(error) {
          this._catchError(error);
        }.bind(this));
      }
      let componentEl = document.getElementById(this.elementId);
      if (componentEl) {
        componentEl.addEventListener('keydown', this._keydownEvent);
      }
      componentEl = null;
    },
    willDestroyElement() {
      this._super(...arguments);
      let componentEl = document.getElementById(this.elementId);
      componentEl.removeEventListener('keydown', this._keydownEvent);
      componentEl = null;
    },

    _keydownEvent() {
      const kc = event.keyCode;
      console.log('_keydownEvent---', event);
      if( (kc>=48 && kc<=57) || (kc>=65 && kc<=90) || (kc>=96 && kc<=105) || (kc === 229)) {
        this.set('isContentEditing', true);
      }
    },
    didRender() {
      this._super(...arguments);
      let tagetEl = $(this.element).find('.btn-primary');
      if(!isEmpty(tagetEl)) {
        $(tagetEl).text(this.getLanguageResource('14852', 'F', 'Save'));
      }
      tagetEl = null;
      this._setSaveButtonDisabled(this.get('isPreliminaryChecked'));
    },

    onBeforePatientChange(){
      this._super(...arguments);
      // this._initialize();
      // this.set('selectedDetailInfo', {});
      this.set('comments', {
        isCommentsExpanded: false,
        deptCommentsCount: 0,
        notification:false ,
      });
      if(!isEmpty(this.get('selectedDetailInfo'))){
        if(this.get('selectedDetailInfo.isEditor') && this.get('isContentEditing')){
        //편집모드였을 경우
          return false;
        }else{
          return true;
        }
      }else{
        return true;
      }
    },

    onPatientChange(changeable) {
      this._super(...arguments);
      if(changeable===false && !isEmpty(this.get('selectedDetailInfo'))){
        const options = {
          'caption': this.getLanguageResource('10251', 'F', '환자 선택 변경 진행중'),
          'messageBoxButton': 'YesNoCancel',
          'messageBoxImage': 'question',
          'messageBoxText': `[ ${this.get('menuTitle')} ]<br>` + this.getLanguageResource('9231', 'F', '저장되지 않은 데이터가 있습니다.')
           + `<br>`+ this.getLanguageResource('8939', 'F', '저장하시겠습니까?'),
          'messageBoxFocus': 'Yes',
        };
        return messageBox.show(this, options).then(function (result){
          if(result == 'Yes'){
            //save
            this.get('co_ContentMessageService').sendMessage('GENERAL_RECORD_SAVE', this.get('currentMenuId'));
            this.continuePatientChanging();
          }else if(result ==='No'){
            this.continuePatientChanging();
          }else if(result ==='Cancel'){
            this.cancelPatientChanging();
          }
        }.bind(this)).catch(function(error) {
          this._catchError(error);
        }.bind(this));
      }
    },
    onPatientChanged(Patient){
      this._super(...arguments);
      if(this.checkPatientDataClear() === true) {
        this.set('selectedDetailInfo', {});
        this.set('isContentEditing', false);
        this.set('specimenNumber', null);
        return;
      }
      if(!isEmpty(this.get('selectedDetailInfo')) && (this.get('selectedDetailInfo.subject.number') !== Patient.patientDisplayId)) {
        this.set('selectedDetailInfo', {});
        this.set('isContentEditing', false);
        return;
      }
      this._initialize();
    },
    _setSaveButtonDisabled(checked) {
      let tagetEl = $(this.element).find('.btn-primary');
      if(isEmpty(tagetEl)) {
        this.set('isEditDisplay', true);
        return;
      }
      // $(tagetEl).text(this.getLanguageResource('14852', 'F', 'Save'));
      if(checked) {
        $(tagetEl).addClass('disabled');
      } else {
        $(tagetEl).removeClass('disabled');
      }
      this.set('isEditDisplay', true);
      tagetEl = null;
    },
    // 4. Actions Area
    actions: {
      onCheckChanged(e) {
        this._setSaveButtonDisabled(e.checked);
      },
      onCopyMode(){
        if(!isEmpty(this.get('selectedDetailInfo.recordNoteId'))){
          this.set('copyRecode', {
            isPasteDisable: false,
            recordTypeCode: this.get('selectedDetailInfo.recordTypeCode'),
            recordNoteId: this.get('selectedDetailInfo.recordNoteId'),
          });
          this.set('copyRecode.isPasteOpen', true);
        }
      },
      onPasteMode(){
        const selectedDetailInfo = this.get('selectedDetailInfo');
        const copyRecode = this.get('copyRecode');

        if(selectedDetailInfo.recordTypeCode === copyRecode.recordTypeCode){
          this.set('selectedDetailInfo.isEditor', true);
          this.set('selectedDetailInfo.copyRecord', true);
          this.set('selectedDetailInfo.recordNoteId', copyRecode.recordNoteId);
        }
      },
      onEditMode(){
        if(isEmpty(this.get('selectedDetailInfo'))){
          return;
        }
        this.set('selectedDetailInfo.isEditor', true);
        const isPreliminaryChecked = this.get('isPreliminaryChecked');
        if(isPreliminaryChecked) {
          this.set('isEditDisplay', false);
        }
        setTimeout(() => {
          this._setSaveButtonDisabled(isPreliminaryChecked);
        }, 350);
      },

      //기록지 조각UI에서 저장버튼을 누르고서 이후에 Return 오는 CallBack 메소드.
      onTextResultRecordSave(recordNoteId, recordStatusCode, signStatusCode){
        this.set('recordNoteId', recordNoteId);
        this.set('signStatusCode', signStatusCode);
        this.set('isShowDimmed', true);
        if(isEmpty(recordNoteId) || recordNoteId.code =='ALL_EMPTY'){
          // this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9209', 'F', '저장할 내용이 없습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        if(signStatusCode === 'S'){
          //전자서명 필요없음  'S'면 서명 'N'이면 서명안함 'U'이면 unneeded
          this.saveSignData(this._setPlaintext(this.get('recordNoteId')));
        }else{
          this._saveResult(this.get('recordNoteId'));
        }
      },

      onSendInputBox(){
        const cvrInfo = this.get('cvrInfo');
        // if(Ember.isEmpty(this.get('cvrInfo.encounterId')) || Ember.isEmpty(this.get('cvrInfo.basedOnId'))
        if(isEmpty(this.get('cvrInfo.encounterId')) || isEmpty(this.get('cvrInfo.subjectId'))){
          return;
        }
        this.set('isCvrOpen', true);
        this.set('cvrSendInformation', A({
          patient : { id: cvrInfo.subjectId,
            displayCode: cvrInfo.subject.displayNumber,
            name: cvrInfo.subject.name},
          examination: {basedOnTypeCode: "Specimen",
            id:cvrInfo.examination.id,
            basedOnId: cvrInfo.specimenId,
            name: cvrInfo.examination.name,
            performDate: cvrInfo.get('performers.firstObject.performDatetime')},
          encounter:{ id:cvrInfo.encounterId},
          smsContent: null,
          staffs: [{actorTypeName: this.getLanguageResource('9686', 'S','처방의'),
            actorId:cvrInfo.orderedStaff.id,
            actorName: cvrInfo.orderedStaff.name}],
          result: null
        }));
        console.log(this.get('cvrSendInformation'));

      },
      onCommentBtnClick(e){
        this.toggleProperty('initializeTimeVolume');
        this.set('isCommentOpen', true);
        this.set('commentPopupTarget', e.originalEvent.currentTarget);
      },

      onReturnChangesReason(item, remark){
        if(!isEmpty(item)){
          // this.set('isCorrectReasonEntered', true);
          if(!isEmpty(remark)){
            //결과비고에 저장
            set(this.get('selectedValue') , 'remark', remark.replace(/<br>|<br\/>|<br \/>/giu, '\r\n'));
            // this.get('resultListItemsSource').forEach(e=>
            // });
          }
          this.set('editReasonSelectedItem', item);
          this._saveResult(this.get('recordNoteId'));
        } else {
          this.set('isShowDimmed', false);
        }

      },
      onReasonEntryCancel() {
        this.set('isCorrectReasonEntryOpened', false);
        this.set('isShowDimmed', false);
        this.set('isEditDisplay', true);
      },
      onRefreshClick(){
        this.set('isEditDisplay', true);
        this.set('generalRecodeType', 'E037');
        this.set('selectedDetailInfo', {});
        // this.set('specimenNumber', this.g.specimenNumber);
        // this.set('examinationCode', params.examinationCode);
        this._initialize();
      },

      onLinkedInboxClick(){
        if(isEmpty(this.get('cvrInfo')) || isEmpty(this.get('selectedDetailInfo.specimenNumber'))){
          return;
        }
        // if(isEmpty(this.get('cvrInfo.orderedStaff'))){
        //   return;
        // }
        // const items = this.get('specimenexaminationreportService').getInboxParams(
        //   this.get('cvrInfo.specimenOrder'), this.get('cvrInfo'), this.getLanguageResource('9686', 'S', '처방의'),
        //   this.getLanguageResource('13255', 'F', '','결과보고알림'), '');
        // params = ;
        const cvrInfo = this.get('cvrInfo');
        const specimenOrder = this.get('cvrInfo.specimenOrder');
        this.set('sendInformation', A({
          patient: {
            id: cvrInfo.subjectId,
            displayCode: cvrInfo.get('subject.displayNumber'),
            name: cvrInfo.get('subject.name')},
          examination: {
            name: cvrInfo.get('examination.name'),
            issuedDate: this.get('fr_I18nService').formatDate(specimenOrder.orderDate, 'd'),
            checkInDateTime: moment(new Date(cvrInfo.get('checkInDateTime'))).format('YYYY-MM-DD HH:mm'),
          },
          // performDate: isEmpty(resultListSelectedItem.get('performers'))? '': this.get('fr_I18nService').formatDate(resultListSelectedItem.get('performers.firstObject.performDatetime'), 'd')},
          encounter:{ id: specimenOrder.encounterId},
          staffs: [{
            actorTypeName: this.getLanguageResource('9686', 'S', '처방의'),
            actorId:specimenOrder.orderedStaff.id,
            actorName: specimenOrder.orderedStaff.name
          }],
          purpose: this.getLanguageResource('13255', 'F', '','결과보고알림'),
          defaultMessage: cvrInfo.get('examination.name') + " 검사결과가 보고되었습니다. 검사결과를 확인하시기 바랍니다."
        }));
        console.log(this.get('sendInformation'));
        this.set('isInboxOpen', true);
      },
    },
    onCertificateSignSucess(signData){
      //전자서명 성공 call back function
      this.set('signId', signData.signKey);
      this.get('kmiService').kmiAliveHealthChecker().then(function(){
        this._saveSignData(signData, this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'kmiServiceUrl') + 'sign/v1/signs');
      }.bind(this), function(){
        this._saveSignData(signData, this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'aliveHealthChecker') + 'sign/v1/signs');
      }.bind(this)).catch(function(error) {
        this._catchError(error);
      }.bind(this));
    },

    // 5. Private methods Area
    async _saveSignData(signdata, certificateUrl){
      // const signKey = v4();
      const selectedValue = this.get('selectedValue');
      const currentUser= this.get('co_CurrentUserService.user');
      const dataToSend = [{
        "signerEmail": currentUser.email,
        "tenantId": currentUser.get('tenant.tenantId'),
        "hospitalId": currentUser.get('hospital.hospitalId'),
        "signKey": selectedValue.observationId,
        "signDocument": signdata,
        "patientId": selectedValue.subjectId,
        "patientDisplayId": selectedValue.subjectTypeCode,
        "encounterId": selectedValue.encounterId,
        // "signerStaffId": currentUser.employeeId,
        "signerId": currentUser.employeeId,
        "signerDisplayId": currentUser.employeeDisplayId,
        "signerName": currentUser.employeeName,
        "signedDate": new Date(),
        "ipAddress": this.get('fr_GlobalSystemService.localIPAddress'),
        "domain": 'specimenexaminationreport',
        "serviceCode": 'specimenexaminationreport/save-sign-data',
        "aggregateId": this.get('recordNoteId')
      }];
      await this.getItem(certificateUrl, null, dataToSend, false).then(result => {
        if(!isEmpty(result)){
          if(result.signSaveResult === 'Y'){
            this._saveResult(this.get('recordNoteId'));
          }
        }
      }).catch(function(error) {
        this._catchError(error);
      }.bind(this));
    },
    _saveResult(recordNoteId){
      const selectedValue = this.get('selectedValue');
      let isCorrected= false;
      this.set('isShowDimmed', true);
      if(selectedValue.statusCode === 'final' || selectedValue.statusCode ==='corrected') {
        isCorrected=true;
      }
      const params = this._setPlaintext(recordNoteId);
      if(isCorrected && isEmpty(this.get('editReasonSelectedItem'))){
        this.set('isCorrectReasonEntryOpened', true);
      }else{
        this.get('specimenexaminationreportService').resultSave(params.inputType, isCorrected, selectedValue.statusCode, params.observationResults,this.get('editReasonSelectedItem')).then(function(){
          this.set('editReasonSelectedItem', null);
          this.get('specimenexaminationreportService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
          //미니워크리스트 재조회
          this.get('co_ContentMessageService').sendMessage('returnTextResultToResultByItem', recordNoteId);
          this.get('co_ContentMessageService').sendMessage('returnTextResultToGeneralResult', recordNoteId);
          this._initialize();
        }.bind(this)).catch(function(error) {
          this._catchError(error);
        }.bind(this));
      }
    },

    _setPlaintext(recordNoteId){
      const selectedValue = this.get('selectedValue');
      let isCorrected= false;
      let inputType = this.get('selectedValue.inputType');
      if(isEmpty(selectedValue.value)){
        selectedValue.value = {};
      }
      selectedValue.value.recordNoteId = recordNoteId;
      if(selectedValue.statusCode === 'final' || selectedValue.statusCode ==='corrected') {
        isCorrected=true;
      }
      if(selectedValue.valueTypeCode === 'ValueTextString'){
        inputType = 'textresult';
      }
      const observationResults= this.get('selectedValue');
      observationResults.performer= {
        typeCode: "Practitioner",
        id: this.get('co_CurrentUserService.user').id,
        displaySequence: 0, performDatetime: this.get('co_CommonService').getNow()
      };

      observationResults.relatedTypeCode =selectedValue.relatedTypeCode === this.undefined ? '' : selectedValue.relatedTypeCode;
      observationResults.targetObservationResultId= selectedValue.targetObservationResultId === this.undefined ? '' : selectedValue.targetObservationResultId;
      observationResults.inputSubType = selectedValue.inputSubType === this.undefined? '' : selectedValue.inputSubType;
      observationResults.isSigned= true;
      observationResults.signId= this.get('signId');
      observationResults.statusCode= isCorrected? 'corrected': selectedValue.statusCode;

      if(this.get('isPreliminaryChecked')){
        observationResults.isReport = true;
      }
      return{
        inputStatus: isCorrected? 'corrected': selectedValue.statusCode,
        inputType: inputType,
        issuedStaffId: this.get('currentUser.employeeId'),
        observationResults: [observationResults]
      };
    },

    _initialize(){
      this.set('signId', null);
      this.set('isShowDimmed', false);
      this.set('isPreliminaryChecked', false);
      let tagetEl = $(this.element).find('.btn-primary');
      if(!isEmpty(tagetEl)) {
        $(tagetEl).removeClass('disabled');
      }
      tagetEl = null;
      this.set('comments', {
        isCommentsExpanded: false,
        deptCommentsCount: 0,
        notification:false ,
      });

      const path = this.get('defaultUrl') + 'observations/results';
      let params= null;
      if(!isEmpty(this.get('specimenNumber'))){
        params = {
          checkInId:null,
          specimenNumber:this.get('specimenNumber')
        };
        this.set('specimenId', null);
      }else if(!isEmpty(this.get('co_PatientManagerService.selectedPatient.examination.specimenId'))){
        //전역정보의 specimenId로 조회
        params = {
          checkInId:null,
          specimenId: this.get('co_PatientManagerService.selectedPatient.examination.specimenId')
        };
        this.set('specimenId', this.get('co_PatientManagerService.selectedPatient.examination.specimenId'));
        // return;
      }
      if(isEmpty(params)){
        return;
      }
      return this.getList(path, params, null, false).then(function(result){
        if(isEmpty(result)){
          return;
        }
        if(!isEmpty(this.get('specimenId'))){
          //전역정보로 조회한 경우
          let valueTextStringCount = 0;
          let tmp= null;
          result.forEach(element => {
            if(element.valueTypeCode =='ValueTextString'){
              valueTextStringCount ++;
              tmp= element;
            }
          });
          if(valueTextStringCount > 1){
            //text입력이 하나만 있는경우만 셋팅,한개이상 있는경우는 초기화
            return;
          }
          this.set('cvrInfo', tmp);
          // const cvrInfo=this.get('cvrInfo');
          // set(cvrInfo, 'orderDate', tmp.get('specimenOrders.firstObject.orderDate'));
          // set(cvrInfo, 'encounterId', tmp.get('specimenOrders.firstObject.encounterId'));
          // set(cvrInfo, 'orderedStaff', tmp.get('specimenOrders.firstObject.orderedStaff'));
          // set(cvrInfo, 'physicianStaff', tmp.get('specimenOrders.firstObject.physicianStaff'));
          // set(cvrInfo, 'specimenOrder', tmp.get('specimenOrders.firstObject'));
          // console.log('cvrInfo');
          // console.log(tmp);
          this.set('selectedValue', tmp);
          this._getDetailViewInfo(tmp);
          this._getReportViewInfo(tmp).then(function(){
            this.get('co_ContentMessageService').sendMessage('__main_patient_information_refresh', 'refresh');
            this.get('co_ContentMessageService').sendMessage('updateMessage', 'D');
          }.bind(this)).catch(function(error) {
            this._catchError(error);
          }.bind(this));
        }else{
          //검체번호로 일치하는 검사코드를 찾아서 저장param으로 가지고 있게하기
          let element = null;
          if(this.get('examinationCode') === null && result.length == 1){
            //examinationCode 안넘긴경우
            element= result.get('firstObject');
          }else if(result.length > 1){
            result.forEach(e => {
              if(e.get('examination.displayCode') === this.get('examinationCode')){
                element = e;
              }
            });
          }else if(result.length == 1){
            element= result.get('firstObject');
          }else{
            return;
          }

          this.set('cvrInfo', element);
          this.set('selectedValue', element);
          this._getDetailViewInfo(element);
          this._getReportViewInfo(element).then(function(){
            this.get('co_ContentMessageService').sendMessage('__main_patient_information_refresh', 'refresh');
            this.get('co_ContentMessageService').sendMessage('updateMessage', 'D');
          }.bind(this)).catch(function(error) {
            this._catchError(error);
          }.bind(this));
        }

      }.bind(this)).catch(function(error) {
        this._catchError(error);
      }.bind(this));
    },

    _getDetailViewInfo(selectedValue){
      //검체번호로 상세조회
      const path = this.get('defaultUrl') + 'result-worklists/search';
      const now = this.get('co_CommonService').getNow();
      const params = {
        checkInFromDate: now,
        checkInToDate: now,
        specimenNumber: selectedValue.specimenNumber,
        tatSearchTimeMinute: 0,
      };
      if(isEmpty(params)){
        return;
      }
      this.getList(path, null, params, false).then(function(res) {
        if(isEmpty(res)){
          return;
        }
        const element = res.get('firstObject');
        let orderComment = '';
        if(!isEmpty(element.specimenOrders)){
          element.specimenOrders.forEach(e=>{
            if(!isEmpty(e.orderComment)){
              orderComment= orderComment + ' ' + e.orderComment;
            }
          });
        }
        this.set('selectedDetailInfo.collectionComment' , element.collectionComment);
        this.set('selectedDetailInfo.orderComment' , orderComment);
        this.set('comments', {
          isCommentsExpanded: false,
          deptCommentsCount: 0,
          notification:false ,
        });

        const cvrInfo=this.get('cvrInfo');
        set(cvrInfo, 'encounterId', element.get('specimenOrders.firstObject.encounterId'));
        set(cvrInfo, 'orderedStaff', element.get('specimenOrders.firstObject.orderedStaff'));
        set(cvrInfo, 'physicianStaff', element.get('specimenOrders.firstObject.physicianStaff'));
        set(cvrInfo, 'specimenOrder', element.get('specimenOrders.firstObject'));
        set(cvrInfo, 'checkInDateTime', element.get('checkInDateTime'));
        console.log('cvrInfo');
        console.log(this.get('cvrInfo'));
        this.set('selectedDetailInfo.checkInId', element.checkInId);
        this.set('selectedDetailInfo.examinationId', selectedValue.examinationId);
        this.set('selectedDetailInfo.specimenNumber', selectedValue.specimenNumber);
        this.set('selectedDetailInfo.subjectId', selectedValue.subjectId);
        this.set('selectedDetailInfo.subject', selectedValue.subject);
        this.set('selectedDetailInfo.specimenId', selectedValue.specimenId);
        this.set('selectedDetailInfo.examDisplayCode', selectedValue.examination.displayCode);
        this.set('selectedDetailInfo.examAbbreviation', selectedValue.examination.abbreviation);
        this.set('selectedDetailInfo.referredFrom', element.specimenOrders.get('firstObject.issuedDepartment.name') + ' / '
          + element.specimenOrders.get('firstObject.department.name') + ' / '
          + element.specimenOrders.get('firstObject.orderedStaff.name'));
        this.set('selectedDetailInfo.isReport', selectedValue.isReport && selectedValue.statusCode != "final" && selectedValue.statusCode != "amended" && selectedValue.statusCode != "corrected");
        this.get('specimenexaminationreportService').getDepartmentComments(element).then(comments=>{
          if(isPresent(comments)){
            this.set('comments', comments);
          }
          this._getDelayReason();
        }).catch(function(error) {
          this._catchError(error);
        }.bind(this));
        if(!isEmpty(element.ward)){
          let occupyingBed= isEmpty(get(element,'ward.displayCode'))? '' :get(element,'ward.displayCode');
          occupyingBed= isEmpty(get(element, 'room.roomCode'))? occupyingBed : occupyingBed + ' / ' + get(element, 'room.roomCode');
          occupyingBed= isEmpty(get(element, 'bed.displayCode'))? occupyingBed : occupyingBed + ' / ' + get(element, 'bed.displayCode');
          this.set('selectedDetailInfo.occupyingBed', occupyingBed);
          let occupyingBedTooltip= isEmpty(get(element,'ward.name'))? '' : get(element,'ward.name');
          occupyingBedTooltip= isEmpty(get(element, 'room.roomName'))? occupyingBedTooltip : occupyingBedTooltip + ' / ' + get(element, 'room.roomName');
          occupyingBedTooltip= isEmpty(get(element, 'bed.name'))? occupyingBedTooltip : occupyingBedTooltip + ' / ' + get(element, 'bed.name');
          this.set('selectedDetailInfo.occupyingBedTooltip', occupyingBedTooltip);

        }else{
          this.set('selectedDetailInfo.occupyingBed', '');
          this.set('selectedDetailInfo.occupyingBedTooltip', '');
        }
      }.bind(this)).catch(function(error) {
        this._catchError(error);
      }.bind(this));
    },
    async _getDelayReason() {
      if(isEmpty(this.get('selectedDetailInfo'))){
        return;
      }
      const params = {
        specimenId: this.get('selectedDetailInfo.specimenId'),
        checkinId: this.get('selectedDetailInfo.checkInId'),
      };
      try {
        const result = await this.getList(this.get('checkinUrl') + 'specimen-checkins/observation-delay-specimens', params, null);
        if(!isEmpty(result)) {
          set(this.get('comments'), 'isCommentsExpanded', true);
        }
      }catch(e) {
        console.error(e);
      }
    },

    _getReportViewInfo(selectedValue){
      const path = this.get('defaultUrl') + 'specimen-examinations';
      const params = {
        id: null,
        displayCode: selectedValue.examination.displayCode,
      };
      this.set('isTextResultManagementShow', true);
      //검사코드로 상세조회 - 하단 General-Record Setting
      if(isEmpty(params)){
        return;
      }
      return this.getList(path, params, null, false).then(function(res) {
        let sRecordTypeCode = null;

        //받아온 결과의 상태가 'final', 'corrected'면 Viewer모드로 Default설정.
        this.set('selectedDetailInfo.isEditor', true);
        if (selectedValue.statusCode === 'final' || selectedValue.statusCode ==='corrected'){
          this.set('selectedDetailInfo.isEditor', false);

          //하지만 Text결과입력이 처음이면 다시 Edit모드로.. (기록지ID가 없을경우)
          if (selectedValue.value.recordNoteId === '' || selectedValue.value.recordNoteId === null){
            this.set('selectedDetailInfo.isEditor', true);
          }
        }

        //Record-Type Text인지 확인조건 : 총 3개의 조건이 부합되면 그걸로 Return.
        //조건1) property.resultTypeCode : TEXT
        if(res.property.resultTypeCode === 'TEXT'){

          //조건2) mappingInformation.specimenExaminationMapping.displayCode : RecordType
          res.mappingInformation.forEach(element => {
            if(element.specimenExaminationMapping.displayCode === 'RecordType'){

              //조건3) mappingInformation.mappingAttribute.property.isMappingCode : true
              if(element.mappingAttribute.property.isMappingCode){
                sRecordTypeCode = element.value;
              }
            }
          });
        }
        //위에 조건을통해 TextType이 아니면 기본Type을 가져오게함.
        if(isEmpty(this.get('selectedDetailInfo.recordTypeCode'))){
          this.set('selectedDetailInfo.recordTypeCode', isEmpty(sRecordTypeCode) ? this.get('generalRecodeType') : sRecordTypeCode);
        }
        if(isEmpty(this.get('selectedDetailInfo.recordNoteId'))){
          this.set('selectedDetailInfo.recordNoteId', isEmpty(selectedValue.value) ? '' : selectedValue.value.recordNoteId);
        }
        this.set('selectedDetailInfo.copyRecord', false);
        this.set('isTextResultManagementShow', false);

        //위탁검사여부 체크(위탁검사인경우 Footer null로 셋팅)
        this._setCustomFooter(res.mappingInformation);
      }.bind(this)).catch(function(error) {
        this._catchError(error);
      }.bind(this));
    },

    _catchError(e){
      this.set('isShowDimmed', false);
      this.set('isTextResultManagementShow',false);
      this.showResponseMessage(e);
    },

    _setCustomFooter(mappingInformations){
      this.set('selectedDetailInfo.isCustomFooter', false);
      this.set('selectedDetailInfo.customFooterTemplates', null);

      if(isEmpty(mappingInformations) || !A(mappingInformations)){
        return;
      }

      //Mapping InforMation 체크로직
      //1. ConsignedAgency - 위탁검사 매핑정보가 있어야함.
      //2. linkKeyCode - IsUse '사용여부' true로 되어있어야함.
      mappingInformations.forEach(element => {
        if(element.specimenExaminationMapping.displayCode === 'ConsignedAgency' &&
           element.mappingAttribute.linkKeyCode === 'IsUse' &&
           element.value === 'true'){
          //체크사항 모두 해당되면 Footer Null Setting.. - Interface 결과로 들어오는경우..
          this.set('selectedDetailInfo.isCustomFooter', true);
          this.set('selectedDetailInfo.customFooterTemplates', [{
            recordStatusCode:'RS01', isWriterSignImage:false, imagePath:null, writerName:'', writerId:'', departmentName:'', isRecordDate:'',
          }, {
            recordStatusCode:'RS02', isWriterSignImage:false, imagePath:null, writerName:'', writerId:'', departmentName:'', isRecordDate:'',
          }]);
        }
      });
    },
  });