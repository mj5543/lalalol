/* eslint-disable max-lines */
/* eslint-disable max-lines-per-function */
/* eslint-disable chis/require-template-forced-expression */
/* eslint-disable no-console */
import $ from 'jquery';
import { isEmpty } from '@ember/utils';
import { get, set } from '@ember/object';
import { A as emberA } from '@ember/array';
import layout from './template';
import CHIS from 'framework/chis-framework';
import VerificationMixin from '../../mixins/specimen-examination-report-verification-mixin';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';
import KmiSginMixin from 'co-security/mixins/kmi-sign-mixin';
import PrintMixin from '../../mixins/specimen-examination-report-print-mixin';
// import v4 from 'uuid';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  VerificationMixin,
  MessageMixin,
  KmiSginMixin,
  PrintMixin,
  {
    layout,
    specimenNumber: null,
    examinationCode: null,
    isShowLoader: false,
    loaderDimed: null,
    isOtherTextDisabled: true,
    resultSet: null,
    isSaveDisabled: false,
    isNotInterpretated: true,
    isInterpretated: true,
    isPreDisabled: true,
    isEditing: false,
    actionStatusCode: null,
    isExamplePopupOpen: false,
    popupOpenType: null,
    exampleTitle: null,
    isAmendedDisabled: true,
    isCancelDisabled: true,
    isFinalDisabled: true,
    isWaiting: false,
    loaderType: null,
    saveCallback: null,
    isRefreshDisabled: true,
    isDisabled: true,
    isPkickerDisabled: false,
    isEmptyResultStatus: false,

    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId', 'specimen-examination-report-verification-report-interpretation');
      this.setStateProperties([
        'model',
        'globalPatient',
        'examinationGrid',
        'basicGridItems',
        'examinationGridColumns',
        'verifyGrid',
        'verifyGridItems',
        'verifyGridColumns',
        'checkboxlistComp',
        'searchParameters',
        'isNotInterpretated',
        'opinionItems',
        'commentItems',
        'amendedItems',
        'isDisabled',
        'exampleGrid',
        'exampleColumns',
        'exampleItemsSource',
        'signId'
      ]);
      if (this.hasState() === false) {
        //
      }
      this.set('model', {
        selectedComment: null,
        selectedRecommend: null,
        selectedAdditional: null,
        textComment: null,
        textRecommend: null,
        textAdditional: null,
        orderExaminationsNames: null,
        orderExaminationsNamesText: null,
        check: {
          isCalibration: true,
          isQualityControl: true,
          isDelta: true,
          isPanic: true,
          isRecheck: true,
          isOthers: true,
          othersComment: null,
        },
        exampleSelectedItemsText: null,
      });
      this.set('opinionItems', emberA());
      this.set('commentItems', emberA());
      this.set('amendedItems', emberA());
      const gridColumns = [
        // { field: 'checkInDatetime', title: this.getLanguageResource('6777', 'F', '', '접수일'), width: 120, align: 'center', type: 'date', dataFormat: 'd',},
        { field: 'checkInId', title: this.getLanguageResource('6776', 'S', '접수일'), width: 120, merge: true, bodyTemplateName:'regDate' },
        { field: 'reportedDate', title: this.getLanguageResource('2872', 'S', '', '보고일'), width: 100, align: 'center', type: 'date', dataFormat: 'd',},
        { field: 'examination.name', title: this.getLanguageResource('16920', 'F', '', '검사항목명'), width: 130, bodyTemplateName:'textTooltip'},
        { field: 'specimenType.name', title: this.getLanguageResource('16921', 'S', '', '검체명'), width: 100, bodyTemplateName:'textTooltip'},
        // { field: 'resultQuantity.value', title: this.getLanguageResource('890', 'F', '', '결과'), width: 60, align: 'center', bodyTemplateName:'flagColorResult'},
        { field: 'displayResult', title: this.getLanguageResource('890', 'F', '', '결과'), width: 60, align: 'center', bodyTemplateName:'flagColorResult'},
        { field: 'flag.displayCode', title: this.getLanguageResource('14749', 'F', '', '참고'), align: 'center', width:50, bodyTemplateName:'flagCode'},
        { field: 'examinationUnit.name', title: this.getLanguageResource('1819', 'F', '', '단위'), align: 'center', width:90, bodyTemplateName:'textTooltip' },
      ];
      this.set('verifyGridColumns', $.extend(true, emberA(), gridColumns));
      const verifyColumns = $.extend(true, emberA(), gridColumns);
      verifyColumns.push({ field: 'subjectReferenceRange', title: this.getLanguageResource('10745', 'F', '', '참고치'), align: 'center', width: 120, bodyTemplateName:'subjectReferenceRange'});
      this.set('examinationGridColumns', verifyColumns);
      this.set('exampleColumns', [
        { field: 'name', title: this.getLanguageResource('890', 'F', '', '결과')},
      ]);
      this.set('model.orderExaminationsNames', []);
      this._datasReset();
    },

    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1360');
      this.get('co_ContentMessageService').subscribeMessage('verification_selectedData', this.get('currentMenuId'), this, this.sendSelectedDataMessage);
      this.set('recordViewerUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'generalrecord') + `record-viewer/v0/`);
      //전역정보 x 테스트
      // this.set('specimenNumber', '19080700003');
      // this._init();
      this._getSettingInfo();
      this.getBusinessCodeList();
      const contentSource = this.getOpenMenuParams();
      console.log('contentSource----', contentSource);
      if(isEmpty(contentSource)){
        this.get('co_ContentMessageService').sendMessage('verification_worklist_selectedData');
        return;
      }
      if(!isEmpty(this.get('globalPatient')) && (this.get('globalPatient.patientDisplayId') === contentSource.patient.displayNumber)) {
        this.set('searchParameters', contentSource);
        this.set('isRefreshDisabled', false);
        this._init();
      }
    },
    didInsertElement(){
      this._super(...arguments);
      // this.get('co_ContentMessageService').subscribeMessage('verification_selectedData', this.get('currentMenuId'), this, this.sendSelectedDataMessage);
    },
    willDestroyElement() {
      this._super(...arguments);
      this.get('co_ContentMessageService').unsubscribeMessage('verification_selectedData', this.get('currentMenuId'), this, this.sendSelectedDataMessage);
    },
    sendSelectedDataMessage(e){
      console.log('menuOpenedPatient---', e);
      if(!isEmpty(e)){
        this.set('isRefreshDisabled', false);
        this.set('searchParameters', e);
        this._init();
      }
    },
    onBeforePatientChange() {
      this._super(...arguments);
      if(!this.get('isEditing')) {
        return true;
      } else {
        return false;
      }

    },
    onPatientChange(canchange) {
      this._super(...arguments);
      if (canchange === false) {

        const options = {
          'caption': this.getLanguageResource('10251', 'F', '', '환자 선택 변경 진행중'),
          'messageBoxButton': 'YesNoCancel',
          'messageBoxImage': 'question',
          'messageBoxText': `[ ${this.get('menuTitle')} ]<br>${this.getLanguageResource('9231', 'F', null, '저장하지 않은 데이터가 있습니다.')}.<br>${this.getLanguageResource('8939', 'F', null, '저장하시겠습니까?')}`,
          'messageBoxFocus': 'Yes'
        };
        return messageBox.show(this, options).then(function (result) {
          if(result==='Yes'){
            let statusCode = 'preliminary';
            if(!this.get('isAmendedDisabled')) {
              statusCode = 'amended';
            }
            this.set('actionStatusCode', statusCode);
            this._verificationReportSave();
            this.continuePatientChanging();
          } else if (result==='No'){
            this.continuePatientChanging();
          } else if (result==='Cancel'){
            this.cancelPatientChanaging();
          }
        }.bind(this));
      }

    },
    onOpenMenuParamsChanged(e) {
      this._super(...arguments);
      console.log('onOpenMenuParamsChanged----', e);
      if(!isEmpty(e)){
        this.set('isRefreshDisabled', false);
        this.set('searchParameters', e);
        this._init();
      }

    },
    onPatientChanged(Patient){
      this._super(...arguments);
      this.set('globalPatient', Patient);
      if(isEmpty(Patient)){
        return;
      }
      if(isEmpty(this.get('searchParameters')) || (this.get('searchParameters.patient.displayNumber') !== Patient.patientDisplayId)) {
        // this.get('co_MenuManagerService').closeMenu(this.get('viewId'));
        this.set('searchParameters', null);
        this._datasReset();
      }
      if(this.checkPatientDataClear() === true) {
        this._datasReset();
      }
    },
    actions: {
      onUpdateUserSelectDate(e) {
        if(this.get('isEmptyResultStatus') || this.get('isWaiting')) {
          this.set('selectedDate', e.source.selectedDate);
        }
      },
      onRefreshClick() {
        this._init();
      },
      onExaminationGridLoaded(e) {
        this.set('examinationGrid', e.source);
      },
      onVerifyGridLoaded(e) {
        this.set('verifyGrid', e.source);

      },
      onAddVerificationItems() {
        this._setVerifyGrid();
        this.set('isEditing', true);
      },
      onRemoveVerificationItems() {
        const selectedItems = this.get('verifyGrid').selectedItems;
        if(isEmpty(selectedItems)) {
          return;
        }
        const verifyGridItems = $.extend(true, [], this.get('verifyGridItems'));
        // const removeTargetNames = [];
        // const orderExaminationsNames = [];
        selectedItems.forEach(item => {
          verifyGridItems.removeObject(item);
        });
        const tempArr = [];
        // const orderExaminationsNames = $.extend(true, [], this.get('model.orderExaminationsNames'));
        verifyGridItems.forEach(item => {
          const sameItem = selectedItems.find(d => d.checkInId === item.checkInId && d.examination.id === item.examination.id);
          if(isEmpty(sameItem)) {
            // const sameOrderExamanation = orderExaminationsNames.find(d => d === item.orderExamination.name);
            // if(isEmpty(sameOrderExamanation)) {
            //   orderExaminationsNames.push(item.orderExamination.name);
            // }
            tempArr.push(item);
          }
        });
        // this.set('model.orderExaminationsNamesText', orderExaminationsNames.join(', '));
        this.set('verifyGridItems', tempArr);
        this.set('isEditing', true);
        // this.set('model.orderExaminationsNames', orderExaminationsNames);
      },
      onCheckboxlistLoaded(e) {
        this.set('checkboxlistComp', e.source);
      },
      onCheckboxlistChanged(e) {
        if(!this.get('isEditing')) {
          this.set('isEditing', true);
        }
        if(e.item === 'other' && e.checked) {
          this.set('isOtherTextDisabled', false);
        }
      },
      onOtherCommentChanged(e) {
        console.log('onOtherCommentChanged--', e);
      },
      onTextFieldsReset() {
        this.dataFieldsReset();
        this.set('verifyGridItems', emberA());
      },
      onExaminationSave(status) {
        // if(isEmpty(this.get('verifyGridItems'))) {
        //   return;
        // }
        this.set('actionStatusCode', status);
        this.set('saveCallback', this._verificationReportSave);
        this.set('loaderDimed', true);
        this.set('loaderType', 'progress');
        this.set('isShowLoader', true);
        // this._temporarySave();
        this.saveSignData(this.get('viewId'));
        // this._verificationReportSave();
      },
      onExaminationCancel() {
        this.set('saveCallback', this._getReportCancellation);
        this._showConfirmMessage('cancel');
        // this.saveSignData(this.get('viewId'));
        // this._temporarySave();
        // this._getReportCancellation();
      },
      onAdditionalReport(status) {
        // if(isEmpty(this.get('verifyGridItems'))) {
        //   return;
        // }
        this.set('actionStatusCode', status);
        // this._getAdditionalVerificationReport();
        this.set('saveCallback', this._getAdditionalVerificationReport);
        this._showConfirmMessage(status);
        // this.saveSignData(this.get('viewId'));
        // this._temporarySave();
      },
      onGridSelectionChanged(e) {
        const lastSelectedItem = e.source.selectedItem;
        const interpretatedResults = this.get('resultSet.interpretatedResults');
        if(!isEmpty(interpretatedResults) && !isEmpty(lastSelectedItem)) {
          const arladyItem = interpretatedResults.find(d => d.checkInId === lastSelectedItem.checkInId && d.examination.id === lastSelectedItem.examination.id);
          if(!isEmpty(arladyItem)) {
            this.showToastCustomMessage('error', this.getLanguageResource('9194', 'F', '', '이미 동일한 데이터가 있습니다.'));
            e.source.deselectRow(lastSelectedItem);
          }
        }
      },
      onExampleGridLoad(e) {
        this.set('exampleGrid', e.source);
      },
      onResultExampleSelectedAction(e) {
        const text = this.get('model.exampleSelectedItemsText');
        let addText = '';
        e.selectedItems.forEach(item => {
          if(!isEmpty(text)) {
            addText = `${text}  \r\n${item.name} `;
          } else {
            addText = item.name;
          }
        });
        this.set('model.exampleSelectedItemsText', addText);

      },
      onExampleResetClick() {
        // this.set('model.exampleSelectedItems', []);
        // this.set('model.exampleSelectedItemsText', []);
        this.get('exampleGrid').deselectAll();
      },
      onCheckboxChanged(e) {
        console.log('onCheckboxChanged--', e);
        if(!this.get('isEditing')) {
          this.set('isEditing', true);
        }
        if(e.source.content === 'Others') {
          this.set('isOtherTextDisabled', !e.checked);
          if(!e.checked) {
            this.set('model.othersComment', null);
          }
        }
      },
      onExampleApply() {
        const type = this.get('popupOpenType');
        const exampleText = this.get('model.exampleSelectedItemsText');
        if(type === 'Comment') {
          this.set('model.textComment', exampleText);
        } else if(type === 'Recommend') {
          this.set('model.textRecommend', exampleText);
        } else if(type === 'Additional') {
          this.set('model.textAdditional', exampleText);
        }
        this.set('isExamplePopupOpen', false);
        this.set('isEditing', true);
      },
      onFindExampleClick(type, e) {
        this.set('exampleItemsSource', emberA());
        this.set('model.exampleSelectedItemsText', null);
        let exampleTitle = '';
        if(type === 'Comment') {
          exampleTitle = `${this.getLanguageResource('9046', 'F', '', '검증')}/${this.getLanguageResource('7948', 'F', '', '판독소견')}`;
          this.set('exampleItemsSource', this.get('opinionItems'));
        } else if(type === 'Recommend') {
          exampleTitle = this.getLanguageResource('7532', 'F', '', '추천');
          this.set('exampleItemsSource', this.get('commentItems'));
        } else if(type === 'Additional') {
          exampleTitle = this.getLanguageResource('13283', 'F', '', '추가보고');
          this.set('exampleItemsSource', this.get('amendedItems'));
        }
        this.set('exampleTitle', exampleTitle);
        this.set('popupOpenType', type);
        this.set('isExamplePopupOpen', true);
        this.set('resultExampleTarget', e.originalEvent.currentTarget);
      },

    },
    onCertificateSignSucess(signData){
      //전자서명 성공 call back function
      this.set('signId', signData.signKey);
      this.get('kmiService').kmiAliveHealthChecker().then(function(){
        this._saveSignData(signData, this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'kmiServiceUrl') + 'sign/v1/signs');
      }.bind(this), function(){
        this._saveSignData(signData, this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'aliveHealthChecker') + 'sign/v1/signs');
      }.bind(this));
    },

    // 5. Private methods Area
    async _saveSignData(signdata, url){
      // const signKey = v4();
      const selectedValue = this.get('resultSet');
      const currentUser= this.get('co_CurrentUserService.user');
      const searchParams = this.get('searchParameters');
      const dataToSend = [{
        'signerEmail': currentUser.email,
        'tenantId': currentUser.get('tenant.tenantId'),
        'hospitalId': currentUser.get('hospital.hospitalId'),
        // 'signKey': selectedValue.observationId,
        'signDocument': signdata,
        'patientId': selectedValue.subjectId,
        'patientDisplayId': searchParams.patient.displayNumber,
        'encounterId': selectedValue.encounterId,
        // 'signerStaffId': currentUser.employeeId,
        'signerId': currentUser.employeeId,
        'signerDisplayId': currentUser.employeeDisplayId,
        'signerName': currentUser.employeeName,
        'signedDate': new Date(),
        'ipAddress': this.get('fr_GlobalSystemService.localIPAddress'),
        'domain': 'specimenexaminationreport',
        'serviceCode': 'specimenexaminationreport/save-sign-data',
        // 'aggregateId': this.get('recordNoteId')
      }];
      const result = await this.getItem(url, null, dataToSend, false);
      if(!isEmpty(result)){
        if(result.signSaveResult === 'Y'){
          // if(this.get('isInterpretated')) {
          //   this._verificationReportSave();
          // } else {
          //   this._getAdditionalVerificationReport();
          // }
          this.get('saveCallback')();
        } else {
          this.set('isShowLoader', false);
        }
      } else {
        this.set('isShowLoader', false);
      }
    },
    _temporarySave() {
      this.get('saveCallback')();
    },
    async _showConfirmMessage(status) {
      let message = '';
      if(status === 'amended') {
        message = this.getLanguageResource('13244', 'F', null, '추가보고 하시겠습니까?');
      } else if(status === 'cancel') {
        message = this.getLanguageResource('8941', 'F', null, '취소 하시겠습니까?');
      }
      const result = await this.showConfirmMessage(message, '');
      if(result === 'Yes') {
        this.set('loaderDimed', true);
        this.set('loaderType', 'progress');
        this.set('isShowLoader', true);
        this.saveSignData(this.get('viewId'));
      }
    },
    _init() {
      this._datasReset();
      this.getDatas();
    },
    async getBusinessCodeList() {
      try {
        const searchCodes = [
          'VerificationInterpretativeReportOpinion',
          'VerificationInterpretativeReportComment',
          'VerificationInterpretativeReportAmended',
        ];
        const resultList = await this.get('apiService').getBusinessCodeList({classificationCodes: searchCodes});
        const codeItems = function(code) {
          return resultList.filter(item => item.classificationCode === code);
        };
        this.set('amendedItems', codeItems('VerificationInterpretativeReportAmended'));
        this.set('commentItems', codeItems('VerificationInterpretativeReportComment'));
        this.set('opinionItems', codeItems('VerificationInterpretativeReportOpinion'));
      } catch(e) {
        console.error(e);
      }
    },

    async getDatas() {
      try {
        if(isEmpty(this.get('searchParameters'))) {
          return;
        }
        this.set('loaderDimed', false);
        this.set('loaderType', 'spinner');
        this.set('isShowLoader', true);
        this.set('isPkickerDisabled', true);
        const searchParams = this.get('searchParameters');
        this.set('model.selectedPatientGridItem', searchParams);
        this.set('printPatientInfo', {
          'birthDay' : searchParams.patient.birthdate,
          'patientDisplayId' : searchParams.patient.displayNumber,
          'patientName' : searchParams.patient.name,
          'gender' : searchParams.patient.gender
        });
        const params = {
          subjectId: searchParams.subjectId,
          encounterId: searchParams.encounterId,
          specimens: searchParams.specimens
        };
        const result = await this.get('apiService').getVerificationReport(params);
        if(!isEmpty(result)) {
          this.set('reportInfo', result);
          this._eachItemsSetting(result);
          if(!isEmpty(this.get('globalPatient'))) {
            if(!isEmpty(result.interpretatedResults)) {
              this.set('isNotInterpretated', false);
            } else {
              this.set('isInterpretated', false);
            }
            let statusCode = null;
            if (isEmpty(result.statusCode)) {
              this.set('isEmptyResultStatus', true);
              statusCode = this.get('searchParameters.statusCode.code');
            } else {
              statusCode = result.statusCode.code;
            }
            if(statusCode === 'preliminary') {
              this.set('isFinalDisabled', false);
              this.set('isCancelDisabled', false);
              this.set('isDisabled', false);
            } else if(statusCode === 'final') {
              this.set('isAmendedDisabled', false);
              this.set('isCancelDisabled', false);
            } else if(statusCode === 'waiting') {
              this.set('isWaiting', true);
              this.set('isFinalDisabled', false);
              this.set('isDisabled', false);
            } else if(statusCode === 'amended') {
              this.set('isAmendedDisabled', false);
            }
            if(statusCode !== 'final' && statusCode !== 'amended'){
              this.set('isPreDisabled', false);
            }
            if(statusCode === 'preliminary' || statusCode === 'waiting') {
              this.set('selectedDate', this.get('userSelectedDate'));
            } else {
              this.set('selectedDate', result.verificationDate);
            }
          }
          result.verificationWorklist.map(item => {
            item.regInfo = this._setRegInfo(item);
            if(!isEmpty(item.subjectReferenceRange) && (item.subjectReferenceRange.indexOf('\n') > -1)) {
              item.subjectReferenceRangeTooltip = item.subjectReferenceRange.replace(/\n|\r\n/giu, '<br>');
              item.isReplaceSubjectReferenceRange = true;
            }
          });
          if(result.check.isOthers) {
            this.set('isOtherTextDisabled', false);
          }
          this.set('isPkickerDisabled', false);
          this.set('resultSet', result);
          this.set('basicGridItems', result.verificationWorklist);
          this.set('isShowLoader', false);
        }
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowLoader', false);
          this._showError(e);
        }
      }
    },

    _datasReset() {
      this.set('signId', null);
      this.set('isNotInterpretated', true);
      this.set('isInterpretated', true);
      this.set('isPreDisabled', true);
      this.set('isAmendedDisabled', true);
      this.set('isCancelDisabled', true);
      this.set('isFinalDisabled', true);
      this.set('isWaiting', false);
      this.set('isDisabled', true);
      this.set('resultSet', null);
      this.set('basicGridItems', emberA());
      this.set('verifyGridItems', emberA());
      this.set('isEditing', false);
      this.set('isOtherTextDisabled', true);
      this.set('isEmptyResultStatus', false);
      this.set('isRecordDisabled', true);
      this.dataFieldsReset();
    },

    async _createVerificationReport() {
      try {
        this.set('loaderDimed', true);
        this.set('loaderType', 'progress');
        this.set('isShowLoader', true);
        const params = {
          subjectId: this.get('resultSet.subjectId'),
          encounterId: this.get('resultSet.encounterId'),
          activationDate: this.get('searchParameters.activationDate'),
          verificationDate: this.get('selectedDate'),
          attendingDepartmentId: this.get('searchParameters.attendingDepartmentId'),
          verificationItemRemark: this.get('model.orderExaminationsNamesText'),
          signId: this.get('signId'),
          inputStatus: this.get('actionStatusCode'),
          check: {
            isCalibration: this.get('model.check.isCalibration'),
            isQualityControl: this.get('model.check.isQualityControl'),
            isDelta: this.get('model.check.isDelta'),
            isPanic: this.get('model.check.isPanic'),
            isRecheck: this.get('model.check.isRecheck'),
            isOthers: this.get('model.check.isOthers'),
            othersComment: this.get('model.check.othersComment'),
          },
          interpretationComment: this.get('model.textComment'),
          recommentation: this.get('model.textRecommend'),
          // additionalReport: this.get('model.textAdditional'),
          verificationResults: this.get('verifyGridItems'),
          // verificationResultsTableString: this._getCopyContent()
        };
        await this.get('apiService').createInterpretedReport(params);
        this._init();
        this.get('co_ContentMessageService').sendMessage('verification_worklist_resfresh');
        this.get('co_ContentMessageService').sendMessage('test_result_viewer_refresh_specimen');
        this.showToastSaved();
        this.set('isShowLoader', false);
      } catch(e) {
        this._showSaveError(e);
        this.set('isShowLoader', false);
        console.error(e);
      }

    },
    async _getAdditionalVerificationReport() {
      try {
        this.set('loaderDimed', true);
        this.set('loaderType', 'progress');
        this.set('isShowLoader', true);
        const params = {
          verificationInterpretativeReportId: this.get('resultSet.id'),
          verificationDate: this.get('selectedDate'),
          subjectId: this.get('resultSet.subjectId'),
          check: this.get('model.check'),
          verificationItemRemark: this.get('model.orderExaminationsNamesText'),
          interpretationComment: this.get('model.textComment'),
          recommentation: this.get('model.textRecommend'),
          additionalReport: this.get('model.textAdditional'),
          signId: this.get('signId'),
          recordNoteId: null,
          // valueTextString: null,
          inputStatus: this.get('actionStatusCode'),
          verificationResults: this.get('verifyGridItems'),
          // verificationResultsTableString: this._getCopyContent()
        };
        await this.get('apiService').updateInterpretedReport(params);
        this.get('co_ContentMessageService').sendMessage('verification_worklist_resfresh');
        this.get('co_ContentMessageService').sendMessage('test_result_viewer_refresh_specimen');
        this._init();
        this.showToastSaved();
        this.set('isShowLoader', false);
      } catch(e) {
        this._showSaveError(e);
        this.set('isShowLoader', false);
        console.error(e);
      }

    },
    async _getReportCancellation() {
      try {
        this.set('loaderDimed', true);
        this.set('loaderType', 'progress');
        this.set('isShowLoader', true);
        const params = {
          subjectId: this.get('resultSet.subjectId'),
          verificationInterpretativeReportId: this.get('resultSet.id')
        };
        await this.get('apiService').deleteCancellation(params);
        this.get('co_ContentMessageService').sendMessage('verification_worklist_resfresh');
        this.get('co_ContentMessageService').sendMessage('test_result_viewer_refresh_specimen');
        const statusCode = this.get('searchParameters.statusCode');
        set(statusCode, 'code', 'waiting');
        this._init();
        this.showToastCanceled();
        this.set('isShowLoader', false);
      } catch(e) {
        this._showSaveError(e);
        this.set('isShowLoader', false);
        console.log('_getAdditionalVerificationReport Error::', e);
      }

    },
    _verificationReportSave() {
      if(!this.get('isWaiting')) {
        this._getAdditionalVerificationReport();
      } else {
        this._createVerificationReport();
      }
    },
    _getVerificationResults() {
      const verifyItems = this.get('verifyGridItems');
      const tempResult = [];
      verifyItems.forEach(item => {
        const obj = {
          observationResultId: item.observationResultId,
          // subjectId: string,
          // checkInDatetime: 2019-08-27T00:55:14.403Z,
          // reportedDate: 2019-08-27T00:55:14.403Z,
          // specimenId: string,
          // specimenNumber: string,
          // classification: {
          //   id: string,
          //   displayCode: string,
          //   name: string,
          //   abbreviation: string
          // },
          // specimenType: {
          //   id: string,
          //   displayCode: string,
          //   name: string,
          //   abbreviation: string
          // },
          // orderExamination: {
          //   id: string,
          //   displayCode: string,
          //   name: string,
          //   abbreviation: string,
          //   displaySequence: 0
          // },
          // examination: {
          //   id: string,
          //   displayCode: string,
          //   name: string,
          //   abbreviation: string,
          //   displaySequence: 0
          // },
          // resultQuantity: {
          //   value: 0,
          //   comparatorCode: string,
          //   unitCode: string,
          //   unitName: string
          // },
          // flag: {
          //   code: string,
          //   displayCode: string,
          //   name: string,
          //   abbreviation: string
          // },
          // subjectReferenceRange: string,
          // checkInId: string,
          // issuedDepartmentId: string,
          // examinationUnit: {
          //   code: string,
          //   name: string
          // }
        };
        tempResult.push(obj);
      });
      return tempResult;
    },
    _getCopyContent() {
      const dataList = this.get('verifyGridItems');
      let content = '';
      let allContent = '';
      let columnsTag = '';
      let headerContent = '';
      const _bindingColumns = this.get('verifyGridColumns');
      dataList.forEach(item => {
        columnsTag = '';
        _bindingColumns.forEach( (column) => {
          if(column.field !== 'checkInId') {
            let columnEmpty = '\t\t';
            if(column.field === 'specimenType.name') {
              // columnEmpty = '&#8195;&#8195;&#8195;&#8195;';
              columnEmpty = '\t      \t';
            } else if(column.field === 'resultQuantity.value') {
              columnEmpty = '\t\t';
              // columnEmpty = '&#8195;&#8195;&#8195;';
            } else if(column.field === 'examination.abbreviation') {
              columnEmpty = '\t      ';
            } else if(column.field === 'flag.displayCode') {
              columnEmpty = '\t\t';
            }
            columnsTag += `${column.title}${columnEmpty}`;
            let cellContent = get(item, column.field);
            let contentEmpty = '\t';
            if(column.field === 'examination.abbreviation') {
              const tempTextArr = item.examination.abbreviation.split('.');
              if((item.examination.abbreviation.indexOf('.') < 0 && item.examination.abbreviation.length > 8)
              || (tempTextArr.length > 2 && item.examination.abbreviation.length >= 10)
              || (tempTextArr.length === 2 && item.examination.abbreviation.length > 8)) {
                contentEmpty = '\t';
              } else {
                contentEmpty = '\t            ';
              }
              // contentEmpty = '\t\t\t';
            } else if(column.field === 'flag.displayCode') {
              contentEmpty = '\t\t';
              // if(isEmpty(cellContent)) {
              //   contentEmpty = '\t\t\t';
              // }
            } else if(column.field === 'resultQuantity.value') {
              contentEmpty = '\t\t';
            } else if(column.field === 'specimenType.name') {
              contentEmpty = '\t\t';
            }
            cellContent = isEmpty(cellContent) ? '' : cellContent;
            if(column.field == 'reportedDate') {
              cellContent = this.get('fr_I18nService').formatDate(item.checkInDatetime, 'd');
              // cellContent.trimStart();
            }
            content += `${cellContent}${contentEmpty}`;
          }
        });
        content += '\r\n';
      });
      headerContent += columnsTag;
      allContent = `${headerContent}\r\n${content}`;
      // allContent +=` ${content}`;
      console.log('allContent---', allContent);
      return allContent;

    },

    _getCopyTableContent() {
      const dataList = this.get('verifyGridItems');
      const tableStyle = 'width: 100%;border: 1px solid #444444;border-collapse: collapse;';
      const borderStyle = 'border: 1px solid #444444;';
      let content = '';
      let allContent = '';
      let columnsTag = '';
      const groupList = this.groupBy(dataList, data => data.checkInId);
      let headerContent = `<table style='${tableStyle}'><thead><tr style='background:#f0f1f3;text-ailgn:center;'>`;
      const _bindingColumns = this.get('verifyGridColumns');
      dataList.forEach(item => {
        columnsTag = '';
        const groups = groupList.get(item.checkInId);
        _bindingColumns.forEach( (column) => {
          let textAlign = column.align;
          if(isEmpty(textAlign)) {
            textAlign = 'left';
          }
          columnsTag += `<th style='width:${column.width}px;${borderStyle}'>${column.title}</th>`;
          let cellContent = get(item, column.field);
          let checkInHtml = '';
          if(column.field === 'checkInId' && (groups[0].examination.id === item.examination.id)) {
            const regContent = `${this.get('fr_I18nService').formatDate(item.checkInDatetime, 'g')}<br>[${item.classification.abbreviation}] [${item.orderExamination.abbreviation}]`;
            checkInHtml = `<td style='${borderStyle}text-align:${textAlign};' rowspan='${groups.length}'>${regContent}</td>`;
          }
          cellContent = isEmpty(cellContent) ? '' : cellContent;
          if(column.field == 'reportedDate') {
            cellContent = this.get('fr_I18nService').formatDate(item.checkInDatetime, 'd');
          }
          if(column.field === 'checkInId') {
            content += '<tr>';
            content += checkInHtml;
          } else {
            content += `<td style='${borderStyle}text-align:${textAlign};'>${cellContent}</td>`;
          }
        });
        content += '</tr>';
      });
      headerContent += columnsTag;
      headerContent += '</tr></thead>';
      allContent = `${headerContent}`;
      allContent +=` <tbody>${content}</tbody></table>`;
      console.log('allContent---', allContent);
      return allContent;

    },


  });