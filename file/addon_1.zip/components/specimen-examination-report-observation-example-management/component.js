/* eslint-disable max-statements */
/* eslint-disable max-lines-per-function */
// import { copy } from '@ember/object/internals';
import $ from 'jquery';
import { later } from '@ember/runloop';
import { hash } from 'rsvp';
import { isEmpty, isPresent } from '@ember/utils';
import EmberObject, { computed, set } from '@ember/object';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'specimenexaminationreport-module/app-config';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MessageMixin,
  {
    layout,
    specimenexaminationreportService: service('specimen-examination-report-service'),
    // quantityComparatorItemsSource: null,
    // codeableConceptSelectedItem: null,
    exampleListColumns: null,
    exampleListItemsSource: null,
    textValue: null,
    isExamItemSelectedItemChanged: computed('examItemSelectedItem', function() {
      const examItemSelectedItem= this.get('examItemSelectedItem');
      if(isEmpty(examItemSelectedItem)){
        return;
      }
      this._examItemSelectedItemChanged();
      // this._getDefaultResultValue();
      this._getExampleValue();
    }),
    exampleListSelectedItem: null,
    quantityValue: null,
    // isDefaultSaveChecked: null,
    defaultValueString: null,
    defualtValue: null,
    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-observation-example-management');
      //Set Stateful properties
      this.setStateProperties([
        'menuClass',
        'functionTypeCodeItemsSource',
        'codeableConceptSelectedItem',
        'codeableConceptItemsSource',
        'exampleListColumns',
        'exampleListItemsSource',
        'exampleListSelectedItem',
        'quantityValue',
      ]);
      if (this.hasState() === false) {
        //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')+ `specimen-examination-report/${config.version}/`);
        this.set('exampleListColumns', [
          { title: this.getLanguageResource('1527', 'S','기본값'), field: 'isDefaultValue', bodyTemplateName:'default', width: 45, align: 'center', readOnly: true},
          { title: this.getLanguageResource('5043', 'S','예문내용'), field: 'displayName', readOnly: true},
          { title: this.getLanguageResource('1830', 'S','단축키'), field: 'displayName', bodyTemplateName:'functionApplyCode',width: 145, align: 'center'},
        ]);
        this.set('delteteItems', []);
        // this.set('isDefaultSaveChecked', false);
      }
    },

    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'wp680');
      if (this.hasState() === false) {
        const defaultUrl = this.get('defaultUrl');
        hash({
          businessCodes: this.getList(defaultUrl + 'business-codes/search', null,{
            classificationCodes: ['CodeableConcept','examplefunctionApplyCode', 'examplefunctionTypeCode']}, false)
        }).then(function(result) {
          const functionApplyCodeItemsSource= [];
          const codeableConceptItemsSource= [];
          result.businessCodes.forEach(e=>{
            if(e.classificationCode == 'ExampleFunctionApplyCode'){
              functionApplyCodeItemsSource.addObject(e);
            }else if(e.classificationCode == 'ExampleFunctionTypeCode'){
              this.set('exampleFunctionTypeCode', e.code);
            }else if(e.classificationCode == 'CodeableConcept'){
              codeableConceptItemsSource.addObject(e);
            }
          });
          this.set('functionApplyCodeItemsSource', functionApplyCodeItemsSource);
          this.set('codeableConceptItemsSource', codeableConceptItemsSource);
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      }
    },

    // 4. Actions Area
    actions: {
      onGridLoaded(e){
        this.set('gridControl', e.source);
      },

      onDeleteClick(e){
        if(!isEmpty(this.get('exampleListItemsSource')) && !isEmpty(e)){
          this.get('delteteItems').addObject(e);
          this.get('exampleListItemsSource').removeObject(e);
        }
      },

      onAddClick(){
        //grid row추가
        if(!isEmpty(this.get('exampleListItemsSource'))){
          if(!isEmpty(this.get('exampleListItemsSource').findBy('displayName', this.get('codeableConceptSelectedItem')))){
            this.get('specimenexaminationreportService').onShowToast('error', this.getLanguageResource('9842', 'F', '중복데이터가 있습니다'), '');
            return;
          }
        }

        const codeableConceptSelectedItem= this.get('codeableConceptSelectedItem');
        let code = codeableConceptSelectedItem;
        let name = codeableConceptSelectedItem;
        const selectedItem = this.get('codeableConceptItemsSource').findBy('name', codeableConceptSelectedItem);
        if(!isEmpty(selectedItem)){
          code = selectedItem.code;
          name = selectedItem.name;
        }
        if(isEmpty(code) || isEmpty(name)){
          this.get('specimenexaminationreportService')._showMessage( this.getLanguageResource('9207', 'F','입력된 내용이 없습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        const tmp={
          exampleTypeCode: "ExampleValue",
          examinationId: this.get('examItemSelectedItem.specimenExaminationId'),
          valueTypeCode: 'CodeableConcept',
          displayName : name,
          value:{
            quantity: { "value":null },
            codeableConcept: {
              coding: [{system: null, version: null, code: code, displayName: name}],
              displayContent: name,
            },
            valueString: null
          },
          functionTypeCode: null,
          functionApplyCode: null,
          displaySequence: 0,
          isDefaultValue: false
        };
        let exampleListItemsSource= this.get('exampleListItemsSource');
        if(isEmpty(exampleListItemsSource)){
          exampleListItemsSource=[tmp];
        }else{
          exampleListItemsSource.addObject(tmp);
        }
        this.set('exampleListItemsSource', exampleListItemsSource);
        this.get('gridControl').selectRow(tmp);
        later(() => {
          let tableRows = document.getElementById(this.get('gridControl.elementId')).getElementsByClassName('c-gtr');
          let targetElement = null;
          if(isPresent(tableRows)) {
            targetElement = tableRows[tableRows.length-1];
            if(isPresent(targetElement)) {
              targetElement.scrollIntoView({block: "end"});
            }
          }
          tableRows = null;
        });
      },

      onExampleGridCellClick(e){
        //기본값 아이콘 클릭
        if (e.column.field != 'isDefaultValue' || isEmpty(e.item)) {
          return;
        }
        const exampleListItemsSource= this.get('exampleListItemsSource');
        exampleListItemsSource.forEach(item=>{
          if(e.item==item){
            set(item, 'isDefaultValue', !e.item.isDefaultValue);
          }else{
            set(item, 'isDefaultValue', false);
          }
        });
      },

      onExampleSaveClick(){
        const examItemSelectedItem= this.get('examItemSelectedItem');
        const exampleListItemsSource= this.get('exampleListItemsSource');
        if(!this._duplicationCheck($.extend(true, [], exampleListItemsSource))){
          this.set('isExampleGridShow',false);
          return ;
        }
        this.set('isExampleGridShow', true);
        const defaultResultValueObj= this.get('defaultResultValueObj');
        const createExampleList= [];
        const updateExampleList= [];
        let promise = null;
        if(!isEmpty(this.get('delteteItems'))){
          this.get('delteteItems').forEach(function(e){
            if(!isEmpty(e.id)){
              const tmp= {
                observationExampleId: e.id,
                exampleTypeCode: "ExampleValue",
                valueTypeCode: e.valueTypeCode,
                value: e.value,
                functionTypeCode: this.get('exampleFunctionTypeCode'),
                functionApplyCode: isEmpty(e.functionApply)? null : e.functionApply.code,
                displaySequence: e.displaySequence,
                isValidDataRow: false,
                isDefaultValue: false
              };
              if(!isEmpty(defaultResultValueObj)){
                if(e.get('value.codeableConcept.coding.firstObject.displayName') == defaultResultValueObj.get('value.codeableConcept.coding.firstObject.displayName')){
                  //default값, ExampleValue 둘다 삭제
                  updateExampleList.addObject(tmp);
                  const defaultFalseTmp= $.extend(true, EmberObject.create(), tmp);
                  defaultFalseTmp.exampleTypeCode= 'DefaultResultValue';
                  defaultFalseTmp.isDefaultValue= false;
                  updateExampleList.addObject(defaultFalseTmp);
                }else{
                  //ExampleValue 삭제
                  updateExampleList.addObject(tmp);
                }
              }else{
                updateExampleList.addObject(tmp);
              }
            }

          }.bind(this));
        }

        if(!isEmpty(exampleListItemsSource)){
          exampleListItemsSource.forEach(function(e, index){
            const tmp={
              observationExampleId: null,
              exampleTypeCode: e.exampleTypeCode,
              valueTypeCode: e.valueTypeCode,
              value: {
                quantity: {"value":null},
                codeableConcept: {
                  coding: [
                    {
                      system: null, version: null,
                      code: e.value.codeableConcept.coding.get('firstObject').code,
                      displayName: e.displayName
                    }
                  ], displayContent: e.displayName
                },
              },
              functionTypeCode: this.get('exampleFunctionTypeCode'),
              functionApplyCode: isEmpty(e.functionApply)? null: e.functionApply.code,
              displaySequence: index,
              isValidDataRow: true,
              isDefaultValue: e.isDefaultValue
            };

            if(isEmpty(e.id)){
              //ExampleValue 신규 등록
              const tmp2= $.extend(true, EmberObject.create(), tmp);
              tmp2.exampleTypeCode = 'ExampleValue';
              tmp2.isDefaultValue = e.isDefaultValue? true : false;
              createExampleList.addObject(tmp2);
            }else{
              //N 그냥 수정
              const defaultTmp= $.extend(true, EmberObject.create(), tmp);
              defaultTmp.observationExampleId= e.id;
              defaultTmp.exampleTypeCode = 'ExampleValue';
              defaultTmp.isDefaultValue = e.isDefaultValue? true : false;
              updateExampleList.addObject(defaultTmp);
            }
          }.bind(this));

        }
        if(!isEmpty(createExampleList)){
          const params={
            examinationId: examItemSelectedItem.specimenExaminationId,
            exampleValues: createExampleList
          };
          promise = this.create(this.get('defaultUrl') + 'observations/examples-list', null, params, true);
        }
        if(!isEmpty(updateExampleList)){
          const params= {
            exampleValues : updateExampleList};
          promise= this.update(this.get('defaultUrl') + 'observations/examples-list', null, false, params, true);
        }

        if(isEmpty(promise)){
          this.set('isExampleGridShow',false);
          return;
        }
        promise.then(res=>{
          if(res.response==false){
            return;
          }
          this.set('delteteItems', []);
          this.get('specimenexaminationreportService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
          this._getExampleValue();
          const observationPopupCB= this.get('observationPopupCB');
          if(!isEmpty(observationPopupCB)) {
            observationPopupCB();
          }
        }).catch(function(error){
          this._catchError(error);
        }.bind(this));
      },
      onExampleRetrieveClick(){
        //검사코드조회 파ㅂ업 오픈
        this.set('isCodeSeachOpen', true);
      },

      onExampleRowDragStart(e){
        this.set('dragItemIndex', e.downIndex);
      },

      onExampleRowDrop(){
        // this.set('dropItem', e.dropItem);
      },

      onReturnExamCodeValueCB(item){
        this.set('isCodeSeachOpen', false);
        this.set('isExampleGridShow',true);
        this.getList(this.get('defaultUrl') + 'observations/examples-merge', {
          examinationId: this.get('examItemSelectedItem.specimenExaminationId'),
          mergeExaminationId: item.specimenExaminationId,
          // valueTypeCode: 'CodeableConcept'
          valueTypeCode: item.property.resultTypeCode
        } , null, false).then(res=>{
          this.set('isExampleGridShow',false);
          if(isEmpty(res)){
            this.get('specimenexaminationreportService').onShowToast('error', this.getLanguageResource('9264', 'F', '조회된 정보가 없습니다.'), '');
            return;
          }
          let exampleListItemsSource= this.get('exampleListItemsSource');
          let isDuplicated = false;
          if(isEmpty(exampleListItemsSource)){
            exampleListItemsSource=[];
          }
          res.forEach(e=>{
            e.displayName = e.get('value.codeableConcept.coding.firstObject.displayName');
            if(!isEmpty(exampleListItemsSource.findBy('displayName', e.displayName))){
              isDuplicated= true;
              return;
            }
            exampleListItemsSource.addObject(e);
          });
          if(isDuplicated){
            this.get('specimenexaminationreportService').onShowToast('error', this.getLanguageResource('9842', 'F', '중복데이터가 있습니다'), '');
          }
          this.set('exampleListItemsSource', exampleListItemsSource);
        }).catch(function(error){
          this._catchError(error);
        }.bind(this));
      },
    },

    // 5. Private methods Area
    _duplicationCheck(exampleListItemsSourceTmp){
      const exampleListItemsSource = [];
      let res = true;
      exampleListItemsSourceTmp.forEach(e=>{
        if(!isEmpty(e.functionApply) && !isEmpty(e.displayName)){
          exampleListItemsSource.addObject(e);
          // return;
        }else{
          // exampleListItemsSource.addObject(e);
        }

      });
      // if(isEmpty(exampleListItemsSource) && isEmpty(this.get('delteteItems'))){
      //   res= false;
      // }
      // if(!isEmpty(exampleListItemsSource)){
      if(exampleListItemsSource.uniqBy('functionApply').length != exampleListItemsSource.length){
        this.get('specimenexaminationreportService').onShowToast('error', this.getLanguageResource('9842', 'F', '중복데이터가 있습니다'), '');
        res= false;
      }else{
        res= true;
      }
      return res;
      // }
    },

    _examItemSelectedItemChanged(){
      this.set('exampleListItemsSource', null);
    },

    _getExampleValue(){
      const examItemSelectedItem= this.get('examItemSelectedItem');
      // const valueTypeCode= examItemSelectedItem.property.resultTypeCode;
      if(isEmpty(examItemSelectedItem.specimenExaminationId)){
        return;
      }
      this.set('isExampleGridShow', true);
      this.getList(this.get('defaultUrl') + 'observations/examples',
        {exampleTypeCode: 'ExampleValue', examinationId: examItemSelectedItem.specimenExaminationId}, null, false).then(res=>{
        // {examinationId: examItemSelectedItem.specimenExaminationId}, null, false).then(res=>{
        if(isEmpty(res)){
          this.set('isExampleGridShow', false);
          this.set('defaultResultValueObj', null);
          return;
        }

        // let defaultItemDisplayName= null;
        // this.getList(this.get('defaultUrl') + 'observations/examples',
        //   {exampleTypeCode: 'DefaultResultValue', examinationId: this.get('examItemSelectedItem').specimenExaminationId}, null, false).then(defaultRes=>{
        // if(isEmpty(defaultRes)){
        //   this.set('isExampleGridShow', false);
        //   this.set('defaultResultValueObj', null);
        // }else{
        //   this.set('defaultResultValueObj', defaultRes[0]);
        //   defaultItemDisplayName = defaultRes[0].get('value.codeableConcept.coding.firstObject.displayName');
        // }
        // if(!isEmpty(defaultItemDisplayName)){
        res.forEach(element => {
          const displayName = element.get('value.codeableConcept.coding.firstObject.displayName');
          if(element.exampleTypeCode=='DefaultResultValue'){
            set(element, 'isDefaultValue', true);
            this.set('defaultResultValueObj', element);
            // defaultItemDisplayName = element.get('value.codeableConcept.coding.firstObject.displayName');
          }
          set(element, 'displayName', displayName);
        });
        // }else{
        //   res.forEach(element => {
        //     set(element, 'displayName', element.get('value.codeableConcept.coding.firstObject.displayName'));
        //   });
        // }
        // this.set('exampleListItemsSource', res.filterBy('exampleTypeCode', "ExampleValue"));
        this.set('exampleListItemsSource', res);
        this.set('isExampleGridShow', false);
        // }).catch(function(error){
        //   this._catchError(error);
        // }.bind(this));
        // switch(valueTypeCode){
        //   // case 'Numeric':
        //   //   res.forEach(function(element, index) {
        //   //     set(element, 'displayName', element.get('value.quantity.value'));
        //   //     set(element, 'displaySequence', index);
        //   //   });
        //   //   this.set('exampleListItemsSource', res);
        //   //   break;
        //   case 'Character':

        //     break;
        //   // case 'Text':
        //   //   this.set('textValue', res.response);
        //   //   break;
        //   // case 'Extra Report':
        //   //   this.set('textValue', res.response);
        //   //   break;
        //   default:
        //     break;
        // }
      }).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    _setParams(item, index, isValidDataRow){
      const params={
        observationExampleId: item.id,
        valueTypeCode: item.valueTypeCode,
        value: item.value,
        functionTypeCode: null,
        functionApplyCode: null,
        displaySequence: item.displaySequence,
        isValidDataRow: isValidDataRow
      };
      if(!isEmpty(index)){
        params.displaySequence= index;
      }
      return params;
    },

    _catchError(e){
      this.set('isExampleGridShow',false);
      this.showResponseMessage(e);
    }
  });