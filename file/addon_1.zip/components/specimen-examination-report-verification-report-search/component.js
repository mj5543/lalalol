/* eslint-disable no-console */
import moment from 'moment';
import { isEmpty, isPresent } from '@ember/utils';
import { next } from '@ember/runloop';
import { set } from '@ember/object';
import { A as emberA } from '@ember/array';
import layout from './template';
import CHIS from 'framework/chis-framework';
import VerificationMixin from '../../mixins/specimen-examination-report-verification-mixin';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';
import PrintMixin from '../../mixins/specimen-examination-report-print-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  VerificationMixin,
  MessageMixin,
  PrintMixin,
  {
    layout,
    specimenNumber: null,
    examinationCode: null,
    isShowLoader: false,
    isShowCalendarLoader: false,
    isShowLoaderByPatient: false,
    isReadOnly: true,
    verifyGridItems: null,
    profileImageFile: null,

    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-verification-report-search');
      this.setStateProperties([
        'model',
        'globalPatient',
        'patientGridItems',
        'patientGridIColumns',
        'verifyGridColumns',
        'calendarSelectedDate',
        'calendarItemsSource',
        'calendarDisplayDate',
        'isDisabled',
        'isSearchDisabled',
      ]);
      if (this.hasState() === false) {
        this.set('model', {
          selectedPatientGridItem: null,
          check: {
            isCalibration: false,
            isQualityControl: false,
            isDelta: false,
            isPanic: false,
            isRecheck: false,
            isOthers: false,
            othersComment: null,
          },
          orderExaminationsNamesText: null,
          originId: null,
        });
        this.set('patientGridIColumns', [
          { field: 'verificationDate', title: this.getLanguageResource('7954', 'F', '', '판독일'), width: 130, align: 'center', type: 'date', dataFormat: 'd',},
          { field: 'patient.displayNumber', title: this.getLanguageResource('8451', 'F', '', '환자번호'), width: 130, align: 'center', bodyTemplateName:'textTooltip'},
          { field: 'patient.name', title: this.getLanguageResource('16881', 'F', '', '환자명'), width: 110, align: 'center', bodyTemplateName:'textTooltip'},
        ]);
        this.set('patientGridItems', emberA());
        this.set('verifyGridColumns', [
          { field: 'checkInId', title: this.getLanguageResource('6776', 'S', '접수일'), width: 140, merge: true, bodyTemplateName:'regDate' },
          { field: 'reportedDate', title: this.getLanguageResource('2872', 'F', '', '보고일'), width: 100, align: 'center', type: 'date', dataFormat: 'd',},
          { field: 'examination.name', title: this.getLanguageResource('16920', 'F', '', '검사항목명'), width: 130},
          { field: 'specimenType.name', title: this.getLanguageResource('16921', 'F', '', '검체명'), width: 110},
          { field: 'displayResult', title: this.getLanguageResource('890', 'F', '', '결과'), width: 60, align: 'center', bodyTemplateName:'flagColorResult'},
          { field: 'flag.displayCode', title: this.getLanguageResource('14749', 'F', '', '참고'), align: 'center', width:50, bodyTemplateName:'flagCode'},
          { field: 'examinationUnit.name', title: this.getLanguageResource('1819', 'F', '', '단위'), align: 'center', width:90 },
          { field: 'subjectReferenceRange', title: this.getLanguageResource('10745', 'F', '', '참고치'), align: 'center', width: 120, bodyTemplateName: 'subjectReferenceRange'}
        ]);
        this.set('settingColumns', [
          { title: this.getLanguageResource('4404', 'S','', '시작일'), field: 'fromDate', width: 80, align: 'center', type: 'date', pickerType:'date', bodyTemplateName: 'dateInput'},
          { title: this.getLanguageResource('6967', 'S','', '종료일'), field: 'toDate', width: 80, align: 'center', bodyTemplateName: 'dateInput'},
          { title: this.getLanguageResource('13288', 'S','', '인증번호'), field: 'certificationNumber', align: 'center', width: 60, enableGotFocusAutoSelect: true},
          { title: this.getLanguageResource('5949', 'S','', '이미지명'), field: 'fileName', width: 230, align: 'center', bodyTemplateName: 'upload', enableGotFocusAutoSelect: true},
        ]);
        this.set('verifyGridItems', emberA());
      }
    },
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1180');
      if(!isEmpty(this.get('co_CurrentUserService.user'))){
        this.set('globalCurrentUser', this.get('co_CurrentUserService.user'));
      }
      this.set('generalRecordUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'generalrecord') + `general-record/v0/`);
      this.set('recordViewerUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'generalrecord') + `record-viewer/v0/`);
      this._getCalenderList();
      this._init();
    },
    // onPatientChanged(Patient){
    //   this._super(...arguments);
    //   this.set('globalPatient', Patient);
    //   if(isEmpty(Patient)){
    //     return;
    //   }
    //   if(isEmpty(this.get('specimenNumber'))) {
    //     this._dataReset();
    //   }
    // },
    _uploadFileToGrid(attachfile){
      // const attachfiles = this.get('settingItemsSource');
      // const attachfilesIdx = attachfiles.length;
      if(!isEmpty(attachfile)){
        for(const file of attachfile){
          // const refinedAttachfile = {
          //   fromDate: this.get('co_CommonService').getNow(),
          //   toDate: null,
          //   fileName: file.fileName,
          //   filePath: file.id,
          //   imageUrl: this.get('fileuploadUrl') + `file/v4/${this.get('tenantId')}/${this.get('hospitalId')}/view/${file.id}`,
          //   certificationNumber: null,
          //   subSequence: 1
          // };
          // attachfiles.insertAt(attachfilesIdx, refinedAttachfile);
          set(this.get('selectedGridItem'), 'fileName', file.fileName);
          set(this.get('selectedGridItem'), 'filePath', file.id);
          set(this.get('selectedGridItem'), 'imageUrl', `${this.get('fileUrl')}/${file.id}`);
        }
      }
      // this.set('vmodel.saveShowloader', false);
      this.set('profileImageFile', []);
    },
    actions: {
      onChangedProfileImage(){
        const _files = this.get('profileImageFile');
        if(_files.length > 0){
          var rst = this.get('fr_UploadHelperService').putFileObject(this.get('viewId'), _files , false, true, false, true);
          rst.then((data)=>{
            console.log('data--', data);
            if(isPresent(data)) {
              if(data[0].contentType.indexOf('image') > -1) {
                this._uploadFileToGrid(data);
              } else {
                this.showToast('error', '', this.getLanguageResource('17311', 'F', '', '이미지 파일을 등록해주세요.'));
                this.set('profileImageFile', []);
              }
            }
          });
          this.set('profileImageFileUrl', URL.createObjectURL(_files[0]));
        }
      },
      onGridLoad(e) {
        this.set('_gridControl', e.source);
      },
      onGridCellClick(e) {
        const rowIndex = this.get('_gridControl').getItemIndex(e.item);
        this.set('selectedRowIndex', rowIndex);
      },
      onGridDateUpdated() {
        const isInvalid = this._checkDate();
        const selectedGridItem = this.get('selectedGridItem');
        const fromDate = moment(new Date(selectedGridItem.fromDate)).format('YYYYMMDD');
        const toDate = moment(new Date(selectedGridItem.toDate)).format('YYYYMMDD');
        if(isInvalid) {
          set(this.get('selectedGridItem'), 'fromDate', null);
          set(this.get('selectedGridItem'), 'toDate', null);
          this.showToast('error', '', this.getLanguageResource('17312', 'F', '', '중복기간이 있습니다.'));
        } else if(isPresent(selectedGridItem.fromDate) && isPresent(selectedGridItem.toDate) && fromDate > toDate) {
          this.showToast('error', '', this.getLanguageResource('17313', 'F', '', '시작일이 종료일보다 큽니다.'));
        }
      },
      onDelClick() {
        if(isEmpty(this.get('selectedGridItem'))) {
          return;
        }
        this.get('settingItemsSource').removeObject(this.get('selectedGridItem'));
      },
      onNewClick(){
        const gridControl = this.get('_gridControl');
        if(!isEmpty(gridControl.itemsSource)){
          const emptyIdItem = gridControl.itemsSource.filter(d => d.id === null);
          if(!isEmpty(emptyIdItem)){
            return;
          }
        }
        let settingItemsSource = this.get('settingItemsSource');
        if(isEmpty(settingItemsSource)){
          settingItemsSource = [];
        }
        settingItemsSource.unshiftObject({
          // fromDate: this.get('co_CommonService').getNow(),
          fromDate: null,
          toDate: null,
          fileName: null,
          filePath: null,
          imageUrl: null,
          certificationNumber: null,
          isRowEditing: true,
          subSequence: 1
        });
        this.set('settingItemsSource', settingItemsSource);
        setTimeout(() => {
          gridControl.selectRow(0);
          gridControl.focusCell(0, 0);
        });
      },
      onEditEnd(e){
        set(e, 'item.isUpdated', true);
      },
      onCalendarSelecteChanged(e) {
        this.set('calendarDisplayDate', e.selectedDate);
        this._getPatientList();
      },
      onCalendarRangeChanged(e) {
        if (!isEmpty(e.displayDate)) {
          this.set('calendarDisplayDate', e.displayDate);
        }
        this._getCalenderList();

      },
      onPatientGridSelectionChanged() {
        // if(!isEmpty(e.selectedItems)) {
        //   this.set('isSearchDisabled', false);
        // }
        // this._getInterpretedReport();
        this.set('isRecordDisabled', true);
        this.set('isSearchDisabled', true);
        this.set('reportInfo', null);
        this.set('verifyGridItems', emberA());
        this.dataFieldsReset();
      },
      onGridCellDoubleClick(e) {
        const patient = e.item.patient;
        this.set('printPatientInfo', {
          'birthDay' : patient.birthdate,
          'patientDisplayId' : patient.displayNumber,
          'patientName' : patient.name,
          'gender' : patient.gender
        });
        this._getInterpretedReport();

      },
      onSearchClick() {
        this.dataFieldsReset();
        this._getInterpretedReport();
      },
      onCalendarRefresh() {
        this._getCalenderList();
        this._getPatientList();
      },
    },
    _init() {
      this._getSettingInfo();
      this._dataReset();
      this.getDatas();
    },

    _dataReset() {
      //TODO: some..
    },
    getDatas() {
      try {
        this.set('isShowLoader', true);
      } catch(e) {
        console.log('getDatas Error::: ', e);

      }
      next(this, function(){
        this.set('isShowLoader', false);
      });

    },

    async _getCalenderList() {
      try {
        this.set('isShowCalendarLoader', true);
        this.set('calendarItemsSource', emberA());
        if(isEmpty(this.get('calendarDisplayDate'))) {
          return;
        }
        const param = {searchDate: this.getParamsDate(this.get('calendarDisplayDate'))};
        const result = await this.get('apiService').getVerificationReportCalendarList(param);
        if(!isEmpty(result)) {
          result.forEach(d => {
            const tempObj = {
              date: d.calendarDate,
              content: d.interpretedCount,
              tooltip: `${this.get('fr_I18nService').formatDate(new Date(d.calendarDate), 'd')}  ${this.getLanguageResource('7941', 'F', '판독건수')}[${d.interpretedCount}]`
            };
            this.get('calendarItemsSource').addObject(tempObj);
          });
        }
        this.set('isShowCalendarLoader', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowCalendarLoader', false);
        }
        this._showError(e);
        console.log('_getCalenderList Error::: ', e);
      }
    },

    async _getPatientList() {
      try {
        this.set('patientGridItems', emberA());
        this.set('verifyGridItems', emberA());
        this.set('reportInfo', null);
        this.set('isRecordDisabled', true);
        this.set('isSearchDisabled', true);
        this.set('isShowLoaderByPatient', true);
        const param = {searchDate: this.getSearchParamsCalendarDate()};
        const result = await this.get('apiService').getVerificationReportPatientList(param);
        this.set('patientGridItems', result);
        this.set('isShowLoaderByPatient', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowLoaderByPatient', false);
        }
        this._showError(e);
        console.log('_getPatientList Error::: ', e);
      }
    },

    async _getInterpretedReport() {
      try {
        this.set('verifyGridItems', emberA());
        this.set('reportInfo', null);
        this.set('model.originId', null);
        if(isEmpty(this.get('model.selectedPatientGridItem'))) {
          this.dataFieldsReset();
          return;
        }
        this.set('isShowLoader', true);
        const params = {
          subjectId: this.get('model.selectedPatientGridItem.patient.patientId'),
          searchDate: this.getSearchParamsCalendarDate(),
        };
        const result = await this.get('apiService').getVerificationInterpretedReport(params);
        if(!isEmpty(result)) {
          this.set('reportInfo', result);
          this._eachItemsSetting(result);
        }
        this.set('isSearchDisabled', false);
        this.set('isShowLoader', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowLoader', false);
        }
        this._showError(e);
        console.log('_getInterpretedReport Error::: ', e);
      }
    },

  });