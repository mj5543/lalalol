/* eslint-disable require-unicode-regexp */
/* eslint-disable prefer-named-capture-group */
/* eslint-disable no-console */
// import { next } from '@ember/runloop';
import { computed, set } from '@ember/object';
import { isEmpty, isNone } from '@ember/utils';
// import { inject as service } from '@ember/service';
import { A as emberA } from '@ember/array';
import layout from './template';
import CHIS from 'framework/chis-framework';
import SpecimenExaminationReportMixin from '../../mixins/specimen-examination-report-mixin';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';
// import iconv from 'iconv-lite';

export default CHIS.FR.Core.ComponentBase.extend(
  SpecimenExaminationReportMixin,
  MessageMixin,
  {
    layout,
    consignmentGrid: null,
    cosignmentColumns: null,
    cosignmentItemsSource: null,
    agencyItemsSource: null,
    resultWorksInfoList: null,
    consignAgencyInfoList: null,
    consignmentList: null,
    specimenNumbers: null,
    completeDatas: null,
    isShowLoader: false,
    loaderDimed: false,
    contentLoaderType: 'spinner',
    // consignmentService: service('specimen-examination-report-consignment-service'),
    // //첨부파일
    // uploadService: inject('upload-helper-service'),
    multipleCommonFilesInformation: computed('multipleCommonFiles', function () {
      const multipleCommonFilesInformation = emberA([]), frUtility = this.get('fr_Utility'), multipleFiles = this.get('multipleCommonFiles');

      if (!isNone(multipleFiles)) {
        for (let i = 0; i < multipleFiles.length; i++) {
          multipleCommonFilesInformation.pushObject({
            name: multipleFiles[i].name,
            size: frUtility.toFileSize(multipleFiles[i].size),
            type: multipleFiles[i].type,
          });
        }
      }
      return multipleCommonFilesInformation;
    }),

    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-consignment-examination-result-upload');
      this.setStateProperties([
        'model',
        'isDisabled',
        'successCount'
      ]);
      if (this.hasState() === false) {
        this.set('model', {
          selectedAgencyId: null,
          selectCheckedList: null,
        });
      }
      this.set('cosignmentColumns', [
        { field: 'testDate', title: this.getLanguageResource('16890', 'S', '', '검사일자'), width: '80', align: 'center'},
        { field: 'patientNumber', title: this.getLanguageResource('8457', 'S', '', '환자번호'), width: '80', align: 'center',},
        { field: 'patientName', title: this.getLanguageResource('16881', 'S', '', '환자명'), width: '70', align: 'center',},
        { field: 'specimenNumber', title: this.getLanguageResource('859', 'S', '', '검체번호'), width: '80', align: 'center'},
        { field: 'displayCode', title: this.getLanguageResource('16919', 'S', '', '검사코드'), width: '80', align: 'center'},
        { field: 'examinationName', title: this.getLanguageResource('10011', 'S', '', '검사명'), width: '100'},
        { field: 'testCd', title: this.getLanguageResource('13259', 'S', '', '위탁기관 검사코드'), width: '110', align: 'center'},
        { field: 'resultContent', title: this.getLanguageResource('17110', 'S', '', '검사결과'), width: '110'},
        { field: 'resultStatus.name', title: this.getLanguageResource('732', 'S', '', '검사상태'), width: '70', align: 'center'},
        { field: 'process', title: this.getLanguageResource('7223', 'S', '', '처리'), width: '30', align: 'center'},

      ]);
      this.set('resultWorksInfoList', emberA([]));
      this.set('consignAgencyInfoList', emberA([]));
      this.set('specimenNumbers', emberA([]));
    },

    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1000');
      this._init();

    },


    actions: {
      onGridLoaded(e) {
        this.set('consignmentGrid', e.source);
      },
      //첨부파일 버튼
      onFileContentReset(filesPropertyName) {
        this.set(filesPropertyName, null);
        this.set('cosignmentItemsSource', emberA([]));
      },
      submitCommonFiles() {
        var rst = this.get('fr_UploadHelperService').putCommonFileObject(this.get('viewId'), this.get('multipleCommonFiles') , 'test');
        rst.then((data)=>{
          console.log('upladed S');
          console.log(data);
          console.log('upladed E');
        });
      },
      onAgencyChanged() {
        this._getSearchConsignedAgency();
      },
      onCosignmentSelectChanged(e) {
        console.log('onCosignmentSelectChanged---', e);
        this.set('model.selectCheckedList', e.selectedItems);
        //
      },
      onChangedFile() {
        this._getFileContent();
      },

      onConsignmentSave() {
        this._setSaveParameters();
      },

    },
    _getFileContent() {
      if(this.get('multipleCommonFiles')[0].type.indexOf('text') < 0) {
        return;
      }
      this.set('contentLoaderType', 'spinner');
      this.set('loaderDimed', false);
      this.set('isShowLoader', true);
      this.set('cosignmentItemsSource', emberA());
      const fr = new FileReader();
      // fr.readAsBinaryString(this.get('multipleCommonFiles')[0]);
      fr.readAsText(this.get('multipleCommonFiles')[0], 'euc-kr');
      fr.onload = (evt) => {
        // 파일 인코딩 euc-kr -> utf-8
        // iconv.skipDecodeWarning = true;
        let str = '';
        // str = iconv.decode(evt.target.result, 'euc-kr');
        str = evt.target.result;
        str = str.replace('<BODY><PRE>', '');
        str = str.replace(/<!--[^>](.*?)-->/g, '');
        str = str.replace('<HTML><HEAD>', '');
        str = str.replace('</HEAD>', '');
        str = str.replace('<META[^>]*>(.*?)>', '');
        str = str.replace('</PRE></BODY></HTML>', '');
        str = str.replace('<!DOCTYPE[^>]*>(.*?)>', '');
        str = str.replace(/<[^<|>]*>/g, '');
        str = str.replace(/&lt;/g, '<');
        str = str.replace(/&gt;/g, '>');
        str = str.split(/\r?\n/);
        const tempArr = [];
        str.forEach( data => {
          if(!isEmpty(data)) {
            const parseText = this._parseFileText(data);
            if (!isEmpty(parseText)) {
              tempArr.push(parseText);
            }
          }
        });
        setTimeout(() => {
          this._getGridData(tempArr);
        }, 1000);
      };
    },

    async _getGridData(datas) {
      try {
        this.set('isShowLoader', true);
        const items = datas.map(async data => {
          const resultInfo = await this._getResultWorksInfo(data.specimenNumber, data);
          return resultInfo;
        });
        const resolve = await Promise.all(items);
        this.set('cosignmentItemsSource', resolve);
        this.set('isShowLoader', false);
      } catch(e) {
        console.error(e);
      }
    },

    _parseFileText(data) {
      let strPtNm = '', strTestCd, strResult;
      const strTestDate = this.fnSubString(data, 0, 8);
      const strPatientNo = this.fnSubString(data, 8, 15);
      const strSpecimenNo = this.fnSubString(data, 23, 15);
      // const lngTempData = this.getByteLength(data);
      const lngTempData = this.fnStrlen(data);
      if (lngTempData <= 231) {
        strPtNm = this.fnSubString(data, 38, 10);
        strTestCd = this.fnSubString(data, 48, 4);
        strResult = this.fnSubString(data, 54, this.fnStrlen(data)-54);
      } else {
        let lngTemp = lngTempData - 231 - 3;
        if (lngTemp < 0 ) {
          lngTemp = 0;
        }
        strPtNm = this.fnSubString(data, 38, 10 + lngTemp);
        strTestCd = this.fnSubString(data, 48 + lngTemp, 4);
        strResult = this.fnSubString(data, 54 + lngTemp, this.fnStrlen(data)-53 + (lngTempData - 232 - 3));
      }
      const y = strTestDate.substr(0, 4);
      const m = strTestDate.substr(4, 2);
      const d = strTestDate.substr(6, 2);
      strTestCd = this._getTextTrim(strTestCd);
      const cosignedAgentList = this.get('consignAgencyInfoList');
      const findedObj = cosignedAgentList.find(agency => agency.agencyExaminationCode === strTestCd);
      let obj = {};
      if (!isEmpty(findedObj)) {
        obj = {
          testDate: `${y}-${m}-${d}`,
          patientNumber: this._getTextTrim(strPatientNo),
          patientName: this._getTextTrim(strPtNm),
          specimenNumber: this._getTextTrim(strSpecimenNo),
          displayCode: findedObj.displayCode,
          examinationId: findedObj.specimenExaminationId,
          examinationName: findedObj.name,
          testCd: strTestCd,
          // series: this.cutByteLength(data, 52, 2),
          resultContent: this._getTextTrim(strResult),
          resultStatus: {
            code: null,
            name: null,
          },
          subjectId: null,
          process: null,
        };
        return obj;
      }
    },

    async _getResultWorksInfo(specimenNo, data) {
      try {
        this.set('isShowLoader', true);
        const param = {specimenNumber: specimenNo};
        const result = await this.get('consignmentService').getResultWorkListSearch(param);
        let tempObj = {};
        tempObj = data;
        if(!isEmpty(result)) {
          tempObj.resultStatus.name = result[0].progressStatus.name;
          tempObj.resultStatus.code = result[0].progressStatus.code;
          tempObj.subjectId = result[0].subjectId;
          this.get('resultWorksInfoList').addObject(result[0]);
        } else {
          tempObj.resultStatus.name = this.getLanguageResource('4883', 'F', 'Error');
          tempObj.subjectId = null;
        }
        return tempObj;
      } catch(e) {
        console.error(e);
      }
    },

    _getTextTrim(str) {
      return isEmpty(str) ? null : str.trim();
    },

    _getTextArray(strData) {
      const textArr = [];
      strData.forEach(data => {
        if (!isEmpty(data)) {
          textArr.push(data);
        }
      });
      return textArr;
    },

    async _getSpecimenCheckInConsignment() {
      const params = {
        queryOption:"1",
        specimenNumber:null,
        checkInFromDate:"2019-04-03 00:00:00",
        checkInToDate:"2019-04-29 00:00:00",
        consignedAgencyCode:this.get('model.selectedAgencyId'),
        examinationIds:null
      };
      const coginedList = await this.get('consignmentService').getSpecimenCheckInConsignment(params);
      this.set('consignmentList', coginedList);
    },

    async _init() {
      this.set('agencyItemsSource', emberA());
      const agencyList = await this.get('consignmentService').getConsignedAgency();
      if(!isEmpty(agencyList)) {
        this.set('agencyItemsSource', agencyList);
        this.set('model.selectedAgencyId', agencyList[0].code);
      }
    },

    async _getSearchConsignedAgency() {
      try {
        const param = {consignedAgencyCode: this.get('model.selectedAgencyId')};
        const result = await this.get('consignmentService').getSearchConsignedAgency(param);
        this.set('consignAgencyInfoList', result);
      } catch(e) {
        console.error(e);
      }
    },

    async _setSaveParameters() {
      try {
        const checkedList = this.get('model.selectCheckedList');
        if (isEmpty(checkedList)){
          this.showToastWarning(this.getLanguageResource('9260', 'F', null, '항목을 선택하세요.'), 2000);
          return;
        }
        const invalidStatusObj = checkedList.find(d => d.resultStatus.code === 'Final');
        if (!isEmpty(invalidStatusObj)) {
          this.showToastWarning(this.getLanguageResource('9288', 'F', null, '검사상태를 확인해주세요.'), 2000);
          return;
        }
        checkedList.forEach(item => {
          set(item, 'process', null);
        });
        this.set('contentLoaderType', 'progress');
        this.set('loaderDimed', true);
        this.set('isShowLoader', true);
        await Promise.all(
          checkedList.map(async d => {
            const params = {
              specimenNumber: d.specimenNumber,
              examinationId: d.examinationId,
              subjectTypeCode: 'Patient',
              subjectId: d.subjectId,
              resultContent: d.resultContent,
              issuedStaffId: this.get('globalCurrentUser.employeeId')
            };
            await this._saveConsignment(params, d);
          })
        );
        // const gridItemsSource = this.get('cosignmentItemsSource');
        // gridItemsSource.forEach(item => {
        //   if (isEmpty(item.process)) {
        //     const gridComponent = this.get('consignmentGrid');
        //     const targetIndex = gridComponent.getItemIndex(item);
        //     set(gridItemsSource[targetIndex], 'process', null);
        //   }
        // });
        this.showToast('save', this.getLanguageResource('10841', 'F', null, '완료되었습니다.'), '');
        this.set('isShowLoader', false);
      } catch(e) {
        console.error(e);
      }
    },

    async _saveConsignment(params, item) {
      const gridComponent = this.get('consignmentGrid');
      const targetIndex = gridComponent.getItemIndex(item);
      const gridItemsSource = this.get('cosignmentItemsSource');
      try {
        await this.get('consignmentService').createObservationsResultsConsignments(params);
        set(gridItemsSource[targetIndex], 'process', this.getLanguageResource('3670', 'F', null, '성공'));
      } catch(e) {
        set(gridItemsSource[targetIndex], 'process', this.getLanguageResource('4585', 'F', null, '실패'));
        console.log('_saveConsignment Error::::', e);
      }
    }

  });