/* eslint-disable no-console */
import { isEmpty } from '@ember/utils';
import { A as emberA } from '@ember/array';
import layout from './template';
import CHIS from 'framework/chis-framework';
import CultureResultManagementMixin from '../../mixins/culture-result-management/specimen-examination-report-culture-result-management-mixin';
import CultureResultSusceptibilityMixin from '../../mixins/culture-result-management/susceptibilitys-mixin';

export default CHIS.FR.Core.ComponentBase.extend(
  CultureResultManagementMixin,
  CultureResultSusceptibilityMixin,
  {
    layout,
    cultureObservationId: null,
    subjectTypeCode: null,
    subjectId: null,
    selectedFromDate: null,
    selectedToDate: null,
    cumulativeCultureColumns: null,
    cumulativeCultureItemsSource: null,
    identificationPopupColumns: null,
    identificationPopupItemsSource: null,
    susceptibilityPopupColumns: null,
    susceptibilityPopupItemsSource: null,
    cumulativeLoader: false,
    isIdentificationPopupLoader: false,
    isSusceptibilityPopupLoader: false,
    isReportResultOpen: false,
    resultReportPopupTarget: null,
    // cultureResultService: Ember.inject.service('specimen-examination-report-culture-result-management-service'),

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-cumulative-culture-result-search');

      this.setStateProperties([
        'cultureObservationId',
        'subjectTypeCode',
        'subjectId',
      ]);
      if (!this.hasState()) {
        this.set('model', {
          identificationPopupSelectedItem: null,
          cumulativeCultureSelectedItem: null,

        });
        const displayDate = new Date(this.get('co_CommonService').getNow());
        this.set('cumulativeCultureColumns', [
          { field: 'checkInDateTime', title: this.getLanguageResource('16890', 'F', '', '검사일'), type: 'date', dataFormat: 'd', width: 70, align: 'center'},
          { field: 'checkInNumber', title: this.getLanguageResource('6767', 'F', '', '접수번호'), width: 40, align:'center'},
          { field: 'specimenType.name', title: this.getLanguageResource('840', 'F', '', '검체'), width: 50, align:'center'},
          { field: 'specimenNumber', title: this.getLanguageResource('859', 'F', '', '검체번호'), width: 80, align:'center'},
          { field: 'displayResult', title: this.getLanguageResource('890', 'F', '', '검사결과'), width: 80, align:'center', bodyTemplateName: 'recodeExport'},
        ]);
        this.set('identificationPopupColumns', [
          { field: 'interpretationCoding.code', title: this.getLanguageResource('11043', 'F', '', '집락'), width: 40, align:'center'},
          { field: 'colonySequence', title: 'No', width: 20, align:'center', readOnly: true},
          { field: 'codeableConceptCoding.code', title: this.getLanguageResource('11041', 'F', '', '동정코드'), width: 60},
          { field: 'codeableConceptCoding.displayName', title: this.getLanguageResource('2052', 'F', '', '동정결과'), width: 120, bodyTemplateName:'codeableName'},
          { field: 'remark', title: this.getLanguageResource('906', 'F', '', '결과비고'), width: 50, readOnly: true, align:'center', bodyTemplateName: 'resultRemark'},
          { field: 'reportableYN', title: this.getLanguageResource('2859', 'F', '', '보고'), width: 20, bodyTemplateName: 'reportableIcon', align:'center'},
        ]);
        this.set('susceptibilityPopupColumns', [
          { field: 'examination.name', title: this.getLanguageResource('8098', 'F', '', '항목'), width: 90, bodyTemplateName: 'examinationName'},
          { field: 'displayResultText', title: this.getLanguageResource('7068', 'F', '', '지름'), width: 60, align:'center'},
          { field: 'interpretationCoding.code', title: this.getLanguageResource('890', 'F', '', '결과'), width: 50, align:'center'},
          { field: 'displayRange', title: this.getLanguageResource('14749', 'F', '', '참고'), width: 90, align:'center'},
          { field: 'antibioticReportableYN', title: this.getLanguageResource('2859', 'F', '', '보고'), width: 50, bodyTemplateName: 'reportableIcon', align:'center'},
        ]);

        this._dataReset();
        this.set('selectedFromDate', displayDate.addYears(-1));
        this.set('selectedToDate', displayDate);
      }

    },
    onLoaded() {
      this._super(...arguments);

      this.set('menuClass', 'w1450');
      this.getDataList();
    },
    actions: {
      onSearchAction() {
        this.getDataList();
      },
      onPopupsIdentificationGridSelectedAction(e) {
        this.set('susceptibilityPopupItemsSource', emberA());
        if(!isEmpty(e.selectedItems)) {
          const selectedItem = e.selectedItems[0];
          this._setPopupSusceptibilitysGrid(selectedItem.bacterialIdentificationRelated.targetObservationId);
        }

      },
      onPopupsSusceptibilityGridSelectedAction() {
        //
      },
      onReportResultOpenClick() {
        this.set('isReportResultOpen', true);
      },
      onCumulativeSelectedChanged() {
        this.getIdentificationsData();
      },

    },

    _dataReset() {
      this.set('cumulativeCultureItemsSource', emberA());
      this.set('identificationPopupItemsSource', emberA());
      this.set('susceptibilityPopupItemsSource', emberA());
    },

    getDataList() {
      this._dataReset();
      this.getCumulativeCultureList();
    },
    async getCumulativeCultureList() {
      try {
        this.set('cumulativeLoader', true);
        const searchCultureParams = {
          subjectTypeCode: this.get('subjectTypeCode'),
          subjectId: this.get('subjectId'),
          fromDate: this.get('selectedFromDate'),
          toDate: this.get('selectedToDate')
        };
        const searchCultureData = await this.get('cultureResultService').getDiagnosticReportSearchCulture(searchCultureParams);
        if (!isEmpty(searchCultureData)) {
          this.set('cumulativeCultureItemsSource', searchCultureData);
          this.set('model.cumulativeCultureSelectedItem', searchCultureData[0]);
        }
        this.set('cumulativeLoader', false);
      } catch(e) {
        this.set('cumulativeLoader', false);
        this._showError(e);
      }

    },
    async getIdentificationsData() {
      try {
        this.set('isIdentificationPopupLoader', true);
        const identificationsData = await this.getBacterialIdentifications(this.get('model.cumulativeCultureSelectedItem.observationId'));
        if (!isEmpty(identificationsData)) {
          this.set('identificationPopupItemsSource', identificationsData);
          this.set('model.identificationPopupSelectedItem', identificationsData[0]);
        }
        this.set('isIdentificationPopupLoader', false);
      } catch(e) {
        this.set('isIdentificationPopupLoader', false);
        this._showError(e);
      }

    },
    async _setPopupSusceptibilitysGrid(observationId) {
      try {
        this.set('isSusceptibilityPopupLoader', true);
        const susceptibilitys = await this.getSusceptibilitysList(observationId);
        this.set('susceptibilityPopupItemsSource', susceptibilitys);
        this.set('isSusceptibilityPopupLoader', false);
      } catch(e) {
        this.set('isSusceptibilityPopupLoader', false);
        this._showError(e);
      }
    },


  });