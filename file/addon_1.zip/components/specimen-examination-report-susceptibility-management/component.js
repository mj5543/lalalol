import { set } from '@ember/object';
import { isEmpty } from '@ember/utils';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from '../../app-config';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MessageMixin,
  /* Only For Server-Call Component
  CHIS.FR.CrossCutting.ServerCallMixin,
  */
  {
  /* 1. Service define Area
  testService:Ember.inject.service(),
  */
    specimenexaminationreportService: service('specimen-examination-report-service'),
    layout,
    // 2. Property Area
    defaultUrl: null,
    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      this.set('menuClass', 'w1360');
      this.set('viewId','specimen-examination-report-susceptibility-management');
      //Set Stateful properties
      this.setStateProperties([
        'defaultUrl',
        'gridItemsSource',
        'antibioticsGridColumns',
        'susceptibilityItem',
        'antibioticsSelectedItem',
        'newSusceptibilityCode',
        'newSusceptibilityName',
      ]);
      if (this.hasState() === false) {
      //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')
          + `specimen-examination-report/${config.version}/`);
        this.set('antibioticsGridColumns',[
          { title: this.getLanguageResource('5930', 'F', 'name'), field: 'examination.name',bodyTemplateName: 'orderNameTooltip', width: 140},
          { title: this.getLanguageResource('9763', 'S','R'), field: 'displayRanges.resistant',align: 'center' },
          { title: this.getLanguageResource('9765', 'S','Min I'), field: 'displayRanges.lowIntermediate',align: 'center' },
          { title: this.getLanguageResource('9766', 'S','Max I'), field: 'displayRanges.highIntermediate',align: 'center'},
          { title: this.getLanguageResource('9764', 'S','S'), field: 'displayRanges.susceptible',align: 'center' },
          { title: this.getLanguageResource('9520', 'S', 'Reportable Result'), field: 'isReportable', type: 'boolean', width: 55, align: 'center' },
        ]);
      }
    },

    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1000');

    },
    // 4. Actions Area
    actions: {
      onAntibioticsGridLoaded(e){
        this.set('antibioticsGridControl', e.source);
      },

      onSusceptibilityNewClick(){
        this.set('isSusceptibilityEntryOpen', true);
      },

      onSusceptibilityPopupClosedAction(){
        this.set('newSusceptibilityCode', null);
        this.set('newSusceptibilityName', null);
      },

      onSusceptibilityAddClick(){
        if(isEmpty(this.get('newSusceptibilityCode')) || isEmpty(this.get('newSusceptibilityName'))){
          this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('8945', 'F', '필수값을 입력하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        this.set('susceptibilityItem', {
          displayCode: this.get('newSusceptibilityCode'),
          name: this.get('newSusceptibilityName')
        });
        this.set('isSusceptibilityEntryOpen', false);
      },

      onAntibioticsAddClick(){
        if(isEmpty(this.get('susceptibilityItem'))){
          return;
        }
        this.set('isCodeSeachOpen', true);
      },

      returnCodeValue(returnItem){
        const susceptibilityItem= this.get('susceptibilityItem');
        if(isEmpty(returnItem) || isEmpty(susceptibilityItem)){
          this.set('isCodeSeachOpen', false);
          return;
        }
        const obj= {
          displayCode: returnItem.displayCode,
          displaySequence: returnItem.displaySequence,
          displayRanges:{resistant: null, lowIntermediate: null, highIntermediate: null, susceptible: null},
          examination: returnItem,
          isReportable: returnItem.property.isReportable
        };
        if(isEmpty(susceptibilityItem.antibiotics)){
          set(susceptibilityItem, 'antibiotics', [obj]);
        }else{
          if(!isEmpty(susceptibilityItem.antibiotics.find(function(e){
            return e.examinationId== returnItem.specimenExaminationId;
          }))){
            this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9226', 'F', '이미 추가되어있습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
            return;
          }
          susceptibilityItem.antibiotics.addObject(obj);
        }
        this.set('isCodeSeachOpen', false);
      },

      onAntibioticsDelClick(){
        const grid= this.get('susceptibilityItem.antibiotics');
        if(isEmpty(grid) || isEmpty(this.get('antibioticsSelectedItem'))){
          this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9260', 'F', 'Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        grid.removeObject(this.get('antibioticsSelectedItem'));
      },

      onSusceptibilityDelClick(){
        const grid= this.get('susceptibilityItem.antibiotics');
        const susceptibilityItem= this.get('susceptibilityItem');
        if(isEmpty(grid) || isEmpty(susceptibilityItem)){
          this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9260', 'F', 'Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        this.set('updatedSelectedItem', null);
        this.delete(this.get('defaultUrl') + 'susceptibilitys', null, {id: susceptibilityItem.id}, true).then(function(){
          this.get('specimenexaminationreportService').onShowToast('delete', '삭제되었습니다', '');
          this.set('updatedSelectedItem', 'refresh');
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      },

      onSaveClick(){
        const susceptibilityItem= this.get('susceptibilityItem');
        let params=null;
        if(isEmpty(susceptibilityItem)){
          return;
        }
        params= {
          displayCode: susceptibilityItem.displayCode,
          name: susceptibilityItem.name,
          antibiotics: [],
        };
        const arr= this.get('susceptibilityItem.antibiotics');
        if(isEmpty(arr)){
          if(isEmpty(susceptibilityItem.id)){
            this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9209', 'F', '저장할 내용이 없습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
          }else{
            this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9209', 'F', '저장할 내용이 없습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
            // this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('8945', 'F', '필수값을 입력하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
          }
          return;
        }else{
          this.get('susceptibilityItem.antibiotics').forEach(element => {
            params.antibiotics.addObject(this._setCreateParams(element));
          });
        }
        if(isEmpty(susceptibilityItem.id)){
          //등록
          this.create(this.get('defaultUrl') + 'susceptibilitys', null, params).then(()=>{
            this.get('specimenexaminationreportService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
            this.set('updatedSelectedItem', this.get('susceptibilityItem'));
          }).catch(function(error){
            this._catchError(error);
          }.bind(this));
        }else{
          //수정
          params.id= susceptibilityItem.id;
          this.update(this.get('defaultUrl') + 'susceptibilitys', null, false, params).then(()=>{
            this.get('specimenexaminationreportService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
            this.set('updatedSelectedItem', this.get('susceptibilityItem'));
          }).catch(function(error){
            this._catchError(error);
          }.bind(this));
        }
      },
    },
    onAudit(){
      const susceptibilityItem = this.get('susceptibilityItem');
      if(!isEmpty(susceptibilityItem.id)){
        this.set('aggregateKey', susceptibilityItem.id);
        this.set('isOpenAuditTrail', true);
      }
    },
    // 5. Private methods Area

    _setCreateParams(element){
      const examinationId= isEmpty(element.examination.id)? element.examination.specimenExaminationId : element.examination.id;
      const res={
        examinationId: examinationId,
        displaySequence: element.displaySequence,
        isReportable: element.isReportable,
        referenceRanges: [
          {
            examinationId: examinationId,
            low: {value: isEmpty(element.displayRanges)? null: element.displayRanges.resistant,
              comparatorCode: null, unitCode: null,unitName: null},
            high: {value: null, comparatorCode: null, unitCode: null, unitName: null},
            typeCode: "anti-resistant",
            appliesTo: [{coding: [{system: null, version: null, code: null, displayName: null}],displayContent: null}],
            ageRangeLow: {value: null, comparatorCode: null, unitCode: null, unitName: null},
            ageRangeHigh: {value: null, comparatorCode: null, unitCode: null, unitName: null},
            referenceDescription: null
          },
          {
            examinationId: examinationId,
            low: {value: isEmpty(element.displayRanges)? null: element.displayRanges.lowIntermediate,
              comparatorCode: null, unitCode: null, unitName: null},
            high: {value: isEmpty(element.displayRanges)? null: element.displayRanges.highIntermediate,
              comparatorCode: null, unitCode: null, unitName: null},
            typeCode: "anti-intermediate",
            appliesTo: [{coding: [{system: null, version: null, code: null, displayName: null}], displayContent: null}],
            ageRangeLow: {value: null, comparatorCode: null, unitCode: null, unitName: null},
            ageRangeHigh: {value: null, comparatorCode: null, unitCode: null, unitName: null},
            referenceDescription: null
          },
          {
            examinationId: examinationId,
            low: {value: null, comparatorCode: null, unitCode: null, unitName: null},
            high: {value: isEmpty(element.displayRanges)? null: element.displayRanges.susceptible,
              comparatorCode: null, unitCode: null, unitName: null},
            typeCode: "anti-susceptible",
            appliesTo: [{coding: [{system: null, version: null, code: null, displayName: null}], displayContent: null}],
            ageRangeLow: {value: null, comparatorCode: null, unitCode: null, unitName: null},
            ageRangeHigh: {value: null, comparatorCode: null, unitCode: null, unitName: null},
            referenceDescription: null
          },
        ],
      };
      return res;
    },

    _catchError(e){
      this.showResponseMessage(e);
    }
  });