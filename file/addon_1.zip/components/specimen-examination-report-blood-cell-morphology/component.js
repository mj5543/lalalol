/* eslint-disable max-lines */
/* eslint-disable chis/require-template-forced-expression */
/* eslint-disable no-console */
import $ from 'jquery';
import { isEmpty, isPresent } from '@ember/utils';
import { A as emberA } from '@ember/array';
import { inject as service } from '@ember/service';
import { later } from '@ember/runloop';
import {set} from '@ember/object';
import layout from './template';
import CHIS from 'framework/chis-framework';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  MessageMixin,
  {
    layout,
    globalPatient: null,
    specimenNumber: null,
    examinationCode: null,
    resultData: null,
    isShowLoader: false,
    loaderDimed: null,
    searchPatientId: null,
    searchPatientInfo: null,
    isDisabled: true,
    isCbcDisabled: true,
    isRetiDisabled: true,
    worklistValues: null,
    cbcValues: null,
    retiValues: null,
    isEditing: false,
    isGridDisabled: true,
    isRbcTopDisabled: true,
    isRbcMiddleDisabled: true,
    isRbcBottomDisabled: true,
    isRbcBottomCombo1Disabled: true,
    isRbcBottomCombo2Disabled: true,
    isRbcBottomCombo3Disabled: true,
    isRbcBottomCombo4Disabled: true,
    isRbcBottomCombo5Disabled: true,
    isRbcBottomCombo6Disabled: true,
    isRbcBottomCombo7Disabled: true,
    isHiperInputDisabled: true,
    isPseudoInputDisabled: true,
    isPltInputDisabled: true,
    isGiantPltInputDisabled: true,
    isSaveDisabled: true,
    isHotkeyActive: false,
    isWBCPropsReadOnly: false,
    loaderType: 'spinner',
    apiService: service('specimen-examination-report-blood-cell-morphology-service'),

    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-blood-cell-morphology');
      this.setStateProperties([
        'model',
        'globalPatient',
        'cbcGridItems',
        'retiGridItems',
        'gridColumns',
        'gridColumns2',
        'schistocytesList',
        'spherocytesList',
        'acanthocytesList',
        'teardropcellsList',
        'targetcellsList',
        'elliptocytesList',
        'burrcellsList',
        'rbcDefaultModel',
        'wbcDefaultModel',
        'plateletDefaultModel',
        'numericOptions',
        'commentItems',
        'commentGrid',
        'commnetColumns'
      ]);
      if (this.hasState() === false) {
        this.set('model', {
          selectedCbcItem: null,
          selectedRetiItem: null,
          rbcAttr: null,
          rbcByRetiAttr: null,
          wbcAttr: null,
          plateletAttr: null,
          opinion: null,
          wbcNumberGroupValue: null,
          plateletNumberGroupValue: null,
          rbcTopGroupValue: null,
          rbcMiddleGroupdValue: null,
          rbcBottomGroupValue: null,
          wbcTotalResult: null,
        });
        if(!isEmpty(this.get('co_PatientManagerService.selectedPatient'))){
          this.set('globalPatient', this.get('co_PatientManagerService.selectedPatient'));
        }
        this.set('numericOptions', {
          alias: 'numeric',
          autoUnmask: true,
          unmaskAsNumber: true,
        });
        this.set('gridColumns', [
          { field: 'checkInNumber', title: this.getLanguageResource('6767', 'S', '', '접수번호'), width: 40, align: 'center', bodyTemplateName:'textTooltip'},
          { field: 'checkInDatetime', title: this.getLanguageResource('9919', 'F', '', '접수일시'), width: 90, align: 'center', type: 'date', dataFormat: 'g',},
          { field: 'specimenNumber', title: this.getLanguageResource('859', 'S', '', '검체번호'), width: 80, align: 'center', bodyTemplateName:'textTooltip'},
        ]);
        this.set('retiGridColumns', $.extend(true, emberA(), this.get('gridColumns')));
        this.set('commentColumns', [
          { field: 'name', title: this.getLanguageResource('906', 'F', '', '결과비고'), bodyTemplateName:'textTooltip'},
        ]);
        this.set('rbcDefaultModel', {
          anemiaCheck: false,
          normalCheck: false,
          increasedCheck: false,
          normocyticCheck: false,
          microcyticCheck: false,
          macrocyticCheck: false,
          normochromicCheck: false,
          hypochromicCheck: false,
          hyperchromicCheck: false,
          anisocytosisCheck: false,
          rdwTextValue: null,
          rdwQuantityValue: 0,
          polychromasiaCheck: false,
          reticulocyteTextValue: null,
          reticulocyteQuantityValue: 0,
          immatureRetiValue: 0,
          poikilocytosisCheck: false,
          poikilocytosisValue: null,
          schistocytesCheck: false,
          schistocytesValueCode: null,
          spherocytesCheck: false,
          spherocytesValueCode: null,
          acanthocytesCheck: false,
          acanthocytesValueCode: null,
          tearDropCellsCheck: false,
          tearDropCellsValueCode: null,
          targetCellsCheck: false,
          targetCellsValueCode: null,
          elliptocytesCheck: false,
          elliptocytesValueCode: null,
          burrCellsCheck: false,
          burrCellsValueCode: null
        });
        this.set('wbcDefaultModel', {
          normalCheck: false,
          decreasedCheck: false,
          increasedCheck: false,
          segValue: 0,
          lymphoValue: 0,
          eosinValue: 0,
          promyeloValue: 0,
          metamyeloValue: 0,
          blastValue: 0,
          plasmaCellValue: 0,
          bandValue: 0,
          monoValue: 0,
          basoValue: 0,
          myeloValue: 0,
          prolymphocyteValue: 0,
          atypicalLymphoValue: 0,
          nrbcsPer100WbcsValue: 0,
          otherValue: 0,
          wbcTotalResult: 0,
          hypersegmentationCheck: false,
          hypersegmentationValue: null,
          pseudoPelgerHuetCheck: false,
          pseudoPelgerHuetValue: null
        });
        this.set('plateletDefaultModel', {
          normalCheck: false,
          decreasedCheck: false,
          increasedCheck: false,
          pltClumpingCheck: false,
          pltClumpingValue: null,
          giantPltCheck: false,
          giantPltValue: null,
        });
      }
    },

    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w680');
      const globalPatient = this.get('globalPatient');
      // if(isEmpty(globalPatient)) {
      //   this.get('co_MenuManagerService').closeMenu(this.get('viewId'));
      //   return;
      // }
      const contentSource= this.getOpenMenuParams();
      //contentSource 가 존재하면 워크리스트에서 선택하지 않고 메뉴로 들어와도 조회 될 수 있도록 데이터 조회
      if(!isEmpty(contentSource)){
        this.set('specimenNumber', contentSource.specimenNumber);
        this.set('examinationCode', contentSource.examinationCode);
        this._init(true);
      } else if(!isEmpty(globalPatient) && !isEmpty(globalPatient.examination) &&!isEmpty(globalPatient.examination.specimenId)) {
        this.set('specimenId', globalPatient.examination.specimenId);
        this._init(false);
      }
    },
    didRender() {
      this._super(...arguments);
      const rbcAttr = this.get('model.rbcAttr');
      if(!isEmpty(rbcAttr) && rbcAttr.poikilocytosisCheck === true) {
        this.set('isRbcBottomDisabled', false);
      } else {
        this.set('isRbcBottomDisabled', true);
      }

    },
    willDestroyElement() {
      this._super(...arguments);
      this.removeEvent();
    },
    onOpenMenuParamsChanged(params){
      this._super(...arguments);
      this.set('specimenNumber', params.specimenNumber);
      this.set('examinationCode', params.examinationCode);
      this._init(true);
    },

    onBeforePatientChange() {
      this._super(...arguments);
      if(this.get('isEditing') === true) {
        return false;
      } else {
        // this.set('specimenNumber', null);
        // this.set('examinationCode', null);
        return true;
      }

    },
    onPatientChange(canchange) {
      this._super(...arguments);
      if (canchange === false) {

        const options = {
          'caption': this.getLanguageResource('10251', 'F', '', '환자 선택 변경 진행중'),
          'messageBoxButton': 'YesNoCancel',
          'messageBoxImage': 'question',
          'messageBoxText': `[ ${this.get('menuTitle')} ]<br>${this.getLanguageResource('9231', 'F', null, '저장하지 않은 데이터가 있습니다.')}.<br>${this.getLanguageResource('8939', 'F', null, '저장하시겠습니까?')}`,
          'messageBoxFocus': 'Yes'
        };
        return messageBox.show(this, options).then(function (result) {
          if(result==='Yes'){
            this._saveResult();
            this.continuePatientChanging();
          } else if (result==='No'){
            this.continuePatientChanging();
          } else if (result==='Cancel'){
            this.cancelPatientChanaging();
          }
        }.bind(this));
      }

    },
    onPatientChanged(Patient){
      this._super(...arguments);

      this.set('globalPatient', Patient);
      this._allResetting();
      if(this.checkPatientDataClear() === true) {
        return;
      }
      if(this.get('globalPatient.patientDisplayId') !== Patient.patientDisplayId) {
        return;
      }
      const examinationSpecimenId = this.get('co_PatientManagerService.selectedPatient.examination.specimenId');
      if(isEmpty(examinationSpecimenId)) {
        return;
      }
      // this.set('specimenNumber', null);
      this.set('specimenId', examinationSpecimenId);
      // this._init(false);
      // if(isEmpty(Patient)){
      //   return;
      // }
      this._init();
      // if(isEmpty(this.get('specimenNumber'))) {
      //   this.get('co_MenuManagerService').closeMenu(this.get('viewId'));
      // }
    },

    _allResetting() {
      this.set('isEditing', false);
      this.set('isRbcTopDisabled', true);
      this.set('isRbcMiddleDisabled', true);
      this._setComboboxAllInactive();
      this._gridReset();
      this._setRbcAttrReset();
      this._attributesReset();
    },
    setAddEvent () {
      document.addEventListener('keydown', this._keydownEvent);
    },

    removeEvent() {
      document.removeEventListener('keydown', this._keydownEvent);
    },

    _setEvent() {
      if(this.get('isHotkeyActive')) {
        this.set('isWBCPropsReadOnly', true);
        this.setAddEvent();
        this.showMessagebox(this.getLanguageResource('13237', 'F', null, '단축키 입력 설정'), this.getLanguageResource('13239', 'F', null, '키보드 단축키 입력이 설정되었습니다.'), 'information', 2000);
      } else {
        this.set('isWBCPropsReadOnly', false);
        this.removeEvent();
        this.showMessagebox(this.getLanguageResource('13238', 'F', null, '단축키 입력 해제'), this.getLanguageResource('13240', 'F', null, '키보드 단축키 입력이 해제되었습니다.'), 'information', 2000);
      }
    },

    _keydownEvent() {
      this._setValueIncrease(event.keyCode);
    },

    _setValueIncrease(code) {
      let property = null;
      switch(code) {
        case 74:
          property = 'segValue';
          break;
        case 72:
          property = 'bandValue';
          break;
        case 75:
          property = 'lymphoValue';
          break;
        case 76:
          property = 'monoValue';
          break;
        case 71:
          property = 'eosinValue';
          break;
        case 70:
          property = 'basoValue';
          break;
        case 89:
          property = 'promyeloValue';
          break;
        case 85:
          property = 'myeloValue';
          break;
        case 73:
          property = 'metamyeloValue';
          break;
        case 77:
          property = 'prolymphocyteValue';
          break;
        case 78:
          property = 'blastValue';
          break;
        case 79:
          property = 'atypicalLymphoValue';
          break;
        case 82:
          property = 'plasmaCellValue';
          break;
        case 80:
          property = 'nrbcsPer100WbcsValue';
          break;
        default:
          break;
      }
      if(!isEmpty(property)) {
        const targetProp = `model.wbcAttr.${property}`;
        this.set(targetProp, parseInt(this.get(targetProp))+1);
        this._getWbcTotalResult();
      }
    },

    actions: {
      onSearchClick() {
        this.getDatas();
      },
      onPickerChanged() {
        this.getDatas();
      },
      onHotkeyClick() {
        this.set('isEditing', true);
        this.toggleProperty('isHotkeyActive');
        event.preventDefault();
        this._setEvent();
      },
      onGridCellDoubleClick(e) {
        this._getWorkListValues(e.item);
      },
      onInputLoaded(section, e) {
        this.set(`inputSource${section}Id`, e.source.elementId);
      },
      onComboboxLoaded(no, e) {
        this.set(`comboboxSource${no}`, e.source);
      },
      onWbcInputChanged() {
        this.set('isEditing', true);
        if(!isEmpty(this.get('model.wbcAttr.wbcTotalResult'))) {
          set(this.get('model.wbcAttr'), 'wbcTotalResult', null);
        }
      },
      onCheckboxChanged(section, type, e) {
        this.set('isEditing', true);
        if(type === 'Area') {
          if(section === 'Top') {
            this.set('isRbcTopDisabled', !e.checked);
            if(!e.checked) {
              set(this.get('model.rbcAttr'), 'rdwTextValue', null);
              set(this.get('model.rbcAttr'), 'rdwQuantityValue', null);
            }
          } else if(section === 'Middle') {
            this.set('isRbcMiddleDisabled', !e.checked);
            if(!e.checked) {
              set(this.get('retiValues'), 'reticulocyteTextValue', null);
              set(this.get('retiValues'), 'reticulocyteQuantityValue', null);
              set(this.get('retiValues'), 'immatureRetiValue', null);
            }
          } else if(section === 'Bottom') {
            this.set('isRbcBottomDisabled', !e.checked);
            if(!e.checked) {
              this._setRbcAttrReset();
            }
          }
        }
        if(type === 'ComboboxList') {
          this._setComboboxOpenClose();
          this.set(`isRbcBottomCombo${section}Disabled`, !e.checked);
          if(e.checked) {
            set(this.get(`comboboxSource${section}`), 'isOpen', true);
          } else {
            set(this.get(`comboboxSource${section}`), 'selectedValue', null);
          }
        }
        if(type === 'Input') {
          this.set(`is${section}Disabled`, !e.checked);
          if(!e.checked) {
            if(section === 'HiperInput') {
              set(this.get('model.wbcAttr'), 'hypersegmentationValue', null);
            } else if(section === 'PseudoInput') {
              set(this.get('model.wbcAttr'), 'pseudoPelgerHuetValue', null);
            } else if(section === 'PltInput') {
              set(this.get('model.plateletAttr'), 'pltClumpingValue', null);
            } else if(section === 'GiantPltInput') {
              set(this.get('model.plateletAttr'), 'giantPltValue', null);
            }
          }
        }
        if(type !== 'ComboboxList' && e.checked) {
          const elementId = this.get(`inputSource${section}Id`);
          let inputEl = document.getElementById(elementId).getElementsByTagName('input')[0];
          later(() => {
            inputEl.focus();
            inputEl = null;
          });
        }
      },
      onRadiobuttonLoaded(group, e) {
        this.set(`${e.source.value}${group}Radio`, e.source);
      },
      onRadioButtonCheanged(group) {
        this.set('isEditing', true);
        this._setRadioValuesAttr(group);

      },
      onCommentGridLoaded(e) {
        this.set('commentGrid', e.source);
      },
      onTotalButtonClick() {
        this._getWbcTotalResult();
      },
      onSaveClick() {
        this._saveResult();
      },
      onReferralPrintClick() {
        if(isEmpty(this.get('resultData.referralRecordNoteId'))){
          this.showWarningMessage(this.getLanguageResource('9848', 'F', '출력할 정보가 없습니다.'), 2000);
          return;
        }
        this.set('printReferralOpen', true);
      },
    },
    _setRbcAttrReset() {
      if(isEmpty(this.get('model.rbcAttr'))) {
        return;
      }
      set(this.get('model.rbcAttr'), 'acanthocytesValueCode', null);
      set(this.get('model.rbcAttr'), 'schistocytesValueCode', null);
      set(this.get('model.rbcAttr'), 'spherocytesValueCode', null);
      set(this.get('model.rbcAttr'), 'tearDropCellsValueCode', null);
      set(this.get('model.rbcAttr'), 'targetCellsValueCode', null);
      set(this.get('model.rbcAttr'), 'elliptocytesValueCode', null);
      set(this.get('model.rbcAttr'), 'burrCellsValueCode', null);
      set(this.get('model.rbcAttr'), 'schistocytesCheck', false);
      set(this.get('model.rbcAttr'), 'spherocytesCheck', false);
      set(this.get('model.rbcAttr'), 'acanthocytesCheck', false);
      set(this.get('model.rbcAttr'), 'tearDropCellsCheck', false);
      set(this.get('model.rbcAttr'), 'targetCellsCheck', false);
      set(this.get('model.rbcAttr'), 'elliptocytesCheck', false);
      set(this.get('model.rbcAttr'), 'burrCellsCheck', false);
      this._setComboboxAllInactive();
    },

    _setComboboxAllInactive() {
      this.set('isRbcBottomCombo1Disabled', true);
      this.set('isRbcBottomCombo2Disabled', true);
      this.set('isRbcBottomCombo3Disabled', true);
      this.set('isRbcBottomCombo4Disabled', true);
      this.set('isRbcBottomCombo5Disabled', true);
      this.set('isRbcBottomCombo6Disabled', true);
      this.set('isRbcBottomCombo7Disabled', true);
      this._setComboboxOpenClose();
    },

    _setComboboxOpenClose() {
      set(this.get(`comboboxSource1`), 'isOpen', false);
      set(this.get(`comboboxSource2`), 'isOpen', false);
      set(this.get(`comboboxSource3`), 'isOpen', false);
      set(this.get(`comboboxSource4`), 'isOpen', false);
      set(this.get(`comboboxSource5`), 'isOpen', false);
      set(this.get(`comboboxSource6`), 'isOpen', false);
      set(this.get(`comboboxSource7`), 'isOpen', false);
    },
    _getOpenMenu() {
      const parameters = {
        specimenNumber: this.get('specimenNumber'),
        examinationCode: this.get('examinationCode'),
      };
      this.get('co_MenuManagerService').openMenu('specimen-examination-report-text-result-management', parameters);
      this.get('co_ContentMessageService').sendMessage('sendTextResult', parameters);
    },
    _init(isOpenMenuParam) {
      this._gridReset();
      this.set('isOpenMenuParam', isOpenMenuParam);
      this.getDatas();
    },

    _gridReset() {
      this.set('cbcGridItems', emberA());
      this.set('retiGridItems', emberA());
    },
    _attributesReset() {
      this.set('commentItems', emberA());
      this.set('isSaveDisabled', true);
      this.set('worklistValues', null);
      this.set('cbcValues', null);
      this.set('resultData', null);
      this.set('isDisabled', true);
      this.set('model.rbcAttr', $.extend(true, {}, this.get('rbcDefaultModel')));
      this.set('retiValues', $.extend(true, {}, this.get('rbcDefaultModel')));
      this.set('model.wbcAttr', $.extend(true, {}, this.get('wbcDefaultModel')));
      this.set('model.plateletAttr', $.extend(true, {}, this.get('plateletDefaultModel')));
      this.set('model.opinion', null);
    },

    getDatas() {
      this._getBusinessCodes();
      this._attributesReset();
      this._getResult();
      this._getWorkList();
    },
    async _getResult() {
      try {
        this.set('loaderType', 'spinner');
        this.set('isShowLoader', true);
        let params = {
          specimenId: this.get('globalPatient.examination.specimenId')
        };
        if(this.get('isOpenMenuParam')) {
          params = {
            specimenNumber: this.get('specimenNumber')
          };
        }
        const result = await this.get('apiService').getBloodCellMorphologyResult(params);
        if(!isEmpty(result)) {
          if(isEmpty(result.observationId)) {
            this.set('isShowLoader', false);
            return;
          }
          this.set('isDisabled', false);
          this.set('isSaveDisabled', false);
          this.set('resultData', result);
          this.set('cbcValues', result);
          this.set('resultComments', result.resultComments);
          this._getCommentGrid();
          if(!isEmpty(result.rbcAttribute)) {
            this.set('model.rbcAttr', result.rbcAttribute);
            this.set('retiValues', result.rbcAttribute);
            this._setRbcArea(result.rbcAttribute);
          }
          if(!isEmpty(result.wbcAttribute)) {
            this.set('model.wbcAttr', result.wbcAttribute);
            this._setWbcArea(result.wbcAttribute);
          }
          if(!isEmpty(result.plateletAttribute)) {
            this.set('model.plateletAttr', result.plateletAttribute);
            this._setPlateleArea(result.plateletAttribute);
          }
          this.set('model.opinion', result.opinion);
          this._settingItems();
        }
        if(!this.get('isGridDisabled')) {
          this.set('isShowLoader', false);
        }
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowLoader', false);
        }
        this._showError(e);
        console.log('_getResult Error::: ', e);
      }
    },
    async _getWorkList() {
      try {
        this.set('loaderDimed', false);
        this.set('loaderType', 'spinner');
        this.set('isShowLoader', true);
        let params = {
          specimenId: this.get('globalPatient.examination.specimenId')
        };
        if(this.get('isOpenMenuParam')) {
          params = {
            specimenNumber: this.get('specimenNumber')
          };
        }
        const result = await this.get('apiService').getBloodCellMorphologyWorklist(params);
        console.log('_getWorkList----', result);
        if(!isEmpty(result)) {
          this.set('isGridDisabled', false);
          this.set('cbcGridItems', result.cbcWorkList);
          this.set('retiGridItems', result.retiWorkList);
        }
        this.set('isShowLoader', false);
      } catch(e) {
        console.log('_getWorkList Error::: ', e);
        this.set('isShowLoader', false);
      }

    },

    async _getWorkListValues(item) {
      try {
        // this.set('isShowLoader', true);
        // this._attributesReset(item.type);
        const params = {
          checkInId: item.checkInId,
          specimenId: item.specimenId,
          checkInDatetime: item.checkInDatetime,
          type: item.type
        };
        const result = await this.get('apiService').getBloodCellMorphologyWorklistValues(params);
        if(!isEmpty(result)) {
          this.set('isEditing', true);
          if(item.type === 'CBC') {
            this.set('cbcValues', null);
            this.set('isCbcDisabled', false);
            this.set('cbcValues', result);
            set(this.get('model.rbcAttr'), 'rdwQuantityValue', result.rdwQuantityValue);
            set(this.get('model.rbcAttr'), 'rdwTextValue', result.rdwTextValue);
          } else {
            this.set('retiValues', null);
            this.set('isRetiDisabled', false);
            this.set('retiValues', result);
          }
        }
        // this.set('isShowLoader', false);
      } catch(e) {
        console.log('_getWorkListValues Error::: ', e);
      }
    },
    async _getBusinessCodes() {
      const result = await this.get('apiService').getBusinessCodes('BloodCellMorphologyRangeResult');
      if(!isEmpty(result)) {
        const groupList = this.groupBy(result, item => item.abbreviation);
        groupList.forEach(group => {
          const groupKey = group[0].abbreviation.replace(/ /giu, '');
          this._setComboboxItems(groupKey, group);
        });
      }
    },

    async _getCommentGrid() {
      try{
        const result = await this.get('apiService').getBusinessCodes('BloodCellMorphologyComment');
        const commentList = result.map(res => {
          const obj = {code: res.code, name: res.name};
          return obj;
        });
        this.set('commentItems', commentList);
        const resultComments = this.get('resultComments');
        if(isPresent(resultComments)) {
          later(() => {
            commentList.forEach((item, index) => {
              const findItem = resultComments.find(d => d.code === item.code);
              if(!isEmpty(findItem)) {
                this.get('commentGrid').selectRow(index);
              }
            });
          });
        }
      } catch(e) {
        console.log('_getCommentGrid Error::: ', e);
      }
    },
    async _createResult() {
      try {
        this.set('isSaveDisabled', true);
        let params = {};
        params = this._getSaveParameters();
        params.specimenId = this.get('globalPatient.examination.specimenId');
        params.observationId = this.get('resultData.observationId');
        await this.get('apiService').createBloodCellMorphologyResult(params);
        this._getOpenMenu();
        this.set('isEditing', false);
        this.set('isShowLoader', false);
        this.showToastSaved();
        this.getDatas();
        this.get('co_ContentMessageService').sendMessage('test_result_viewer_refresh_specimen');
        this.set('isSaveDisabled', false);
      } catch(e) {
        this.set('isShowLoader', false);
        this.set('isSaveDisabled', false);
        this._showSaveError(e);
        console.log('_saveResult Error:::', e);
      }
    },

    async _modifyResult() {
      try {
        this.set('isSaveDisabled', true);
        let params = {};
        params = this._getSaveParameters();
        params.bloodCellMorphologyId = this.get('resultData.bloodCellMorphologyId');
        await this.get('apiService').getModifyResult(params);
        this.set('isEditing', false);
        this._getOpenMenu();
        this.get('co_ContentMessageService').sendMessage('test_result_viewer_refresh_specimen');
        this.showToastSaved();
        this.set('isShowLoader', false);
        this.getDatas();
        this.set('isSaveDisabled', false);
      } catch(e) {
        this.set('isShowLoader', false);
        this.set('isSaveDisabled', false);
        this._showSaveError(e);
        console.log('_modifyResult Error:::', e);
      }
    },
    async _removeResult() {
      try {
        const param = {
          bloodCellMorphologyId: null
        };
        await this.get('apiService').getRemoveResult(param);
      } catch(e) {
        console.log('_removeResult Error:::', e);
      }
    },
    _setWbcArea(attr) {
      if(attr.hypersegmentationCheck === true) {
        this.set('isHiperInputDisabled', false);
      }
      if(attr.pseudoPelgerHuetCheck === true) {
        this.set('isPseudoInputDisabled', false);
      }

    },
    _setPlateleArea(attr) {
      if(attr.pltClumpingCheck === true) {
        this.set('isPltInputDisabled', false);
      }
      if(attr.giantPltCheck) {
        this.set('isGiantPltInputDisabled', false);
      }
    },
    _setRbcArea(attr) {
      if(attr.anisocytosisCheck === true) {
        this.set('isRbcTopDisabled', false);
      }
      if(attr.polychromasiaCheck === true) {
        this.set('isRbcMiddleDisabled', false);
      }
      if(attr.schistocytesCheck === true) {
        this.set('isRbcBottomCombo1Disabled', false);
      }
      if(attr.spherocytesCheck === true) {
        this.set('isRbcBottomCombo2Disabled', false);
      }
      if(attr.acanthocytesCheck === true) {
        this.set('isRbcBottomCombo3Disabled', false);
      }
      if(attr.tearDropCellsCheck === true) {
        this.set('isRbcBottomCombo4Disabled', false);
      }
      if(attr.targetCellsCheck === true) {
        this.set('isRbcBottomCombo5Disabled', false);
      }
      if(attr.elliptocytesCheck === true) {
        this.set('isRbcBottomCombo6Disabled', false);
      }
      if(attr.burrCellsCheck === true) {
        this.set('isRbcBottomCombo7Disabled', false);
      }
    },
    _settingItems() {
      this._getRbcRadioGroupValue();
      const wbcAttr = this.get('model.wbcAttr');
      const plateletAttr = this.get('model.plateletAttr');
      this.set('model.wbcNumberGroupValue', this._getNumberGroupValue(wbcAttr));
      this.set('model.plateletNumberGroupValue', this._getNumberGroupValue(plateletAttr));

    },
    _getNumberGroupValue(attr) {
      let returnValue = null;
      if(!isEmpty(attr)) {
        if(attr.normalCheck === true) {
          returnValue = 'normal';
        } else if(attr.decreasedCheck === true) {
          returnValue = 'decreased';
        } else if(attr.increasedCheck === true) {
          returnValue = 'increased';
        }
      }
      return returnValue;
    },

    _getRbcRadioGroupValue() {
      const attr = this.get('model.rbcAttr');
      let topValue = null;
      let middleValue = null;
      let bottomValue = null;
      if(!isEmpty(attr)) {
        if(attr.anemiaCheck === true) {
          topValue = 'anemia';
        } else if(attr.normalCheck === true) {
          topValue = 'normal';
        } else if(attr.increasedCheck === true) {
          topValue = 'increased';
        }
        if(attr.normocyticCheck === true) {
          middleValue = 'normocytic';
        } else if (attr.microcyticCheck === true) {
          middleValue = 'microcytic';
        } else if(attr.macrocyticCheck === true) {
          middleValue = 'macrocytic';
        }
        if(attr.normochromicCheck === true) {
          bottomValue = 'normochromic';
        } else if(attr.hypochromicCheck === true) {
          bottomValue = 'hypochromic';
        } else if (attr.hyperchromicCheck === true) {
          bottomValue = 'hyperchromic';
        }
      }
      this.set('model.rbcTopGroupValue', topValue);
      this.set('model.rbcMiddleGroupValue', middleValue);
      this.set('model.rbcBottomGroupValue', bottomValue);
    },
    _setRadioValuesAttr(group) {
      let attr = null;
      if(group === 'RBC') {
        attr = this.get('model.rbcAttr');
        set(attr, 'anemiaCheck', this.get('anemiaRBCRadio.checked'));
        set(attr, 'normalCheck', this.get('normalRBCRadio.checked'));
        set(attr, 'increasedCheck', this.get('increasedRBCRadio.checked'));
        set(attr, 'normocyticCheck', this.get('normocyticRBCRadio.checked'));
        set(attr, 'microcyticCheck', this.get('microcyticRBCRadio.checked'));
        set(attr, 'macrocyticCheck', this.get('macrocyticRBCRadio.checked'));
        set(attr, 'normochromicCheck', this.get('normochromicRBCRadio.checked'));
        set(attr, 'hypochromicCheck', this.get('hypochromicRBCRadio.checked'));
        set(attr, 'hyperchromicCheck', this.get('hyperchromicRBCRadio.checked'));
      } else if(group === 'WBC') {
        attr = this.get('model.wbcAttr');
        set(attr, 'normalCheck', this.get('normalWBCRadio.checked'));
        set(attr, 'decreasedCheck', this.get('decreasedWBCRadio.checked'));
        set(attr, 'increasedCheck', this.get('increasedWBCRadio.checked'));
      } else if(group === 'Platelet') {
        attr = this.get('model.plateletAttr');
        set(attr, 'normalCheck', this.get('normalPlateletRadio.checked'));
        set(attr, 'decreasedCheck', this.get('decreasedPlateletRadio.checked'));
        set(attr, 'increasedCheck', this.get('increasedPlateletRadio.checked'));
      }
    },
    _saveResult() {
      this.set('loaderDimed', true);
      this.set('loaderType', 'progress');
      this.set('isShowLoader', true);
      if(isEmpty(this.get('resultData.bloodCellMorphologyId'))) {
        this._createResult();
      } else {
        this._modifyResult();
      }
    },
    _getSaveParameters() {
      let rbcAttr = {};
      rbcAttr = this.get('model.rbcAttr');
      if (!isEmpty(this.get('retiValues'))) {
        set(rbcAttr, 'reticulocyteTextValue', this.get('retiValues.reticulocyteTextValue'));
        set(rbcAttr, 'reticulocyteQuantityValue', this.get('retiValues.reticulocyteQuantityValue'));
        set(rbcAttr, 'immatureRetiValue', this.get('retiValues.immatureRetiValue'));
      }
      const params = {
        wbcValue: this.get('cbcValues.wbcValue'),
        hbValue: this.get('cbcValues.hbValue'),
        hctValue: this.get('cbcValues.hctValue'),
        pltValue: this.get('cbcValues.pltValue'),
        mcvValue: this.get('cbcValues.mcvValue'),
        mchValue: this.get('cbcValues.mchValue'),
        mchcValue: this.get('cbcValues.mchcValue'),
        opinion: this.get('model.opinion'),
        resultComments: this.get('commentGrid').selectedItems,
        rbcAttribute: rbcAttr,
        wbcAttribute: this.get('model.wbcAttr'),
        plateletAttribute: this.get('model.plateletAttr'),
      };
      return params;
    },
    _setComboboxItems(key, group) {
      switch(key) {
        case 'schistocytes':
          this.set('schistocytesList', group);
          break;
        case 'spherocytes':
          this.set('spherocytesList', group);
          break;
        case 'acanthocytes':
          this.set('acanthocytesList', group);
          break;
        case 'teardropcells':
          this.set('teardropcellsList', group);
          break;
        case 'targetcells':
          this.set('targetcellsList', group);
          break;
        case 'elliptocytes':
          this.set('elliptocytesList', group);
          break;
        case 'burrcells':
          this.set('burrcellsList', group);
          break;
        default:
          break;
      }
    },
    _getWbcTotalResult() {
      const attr = this.get('model.wbcAttr');
      const attrKeys = Object.keys(attr);
      let sum = 0;
      attrKeys.forEach(k => {
        const notAddKeys = ['hypersegmentationValue', 'pseudoPelgerHuetValue', 'wbcTotalResult', 'nrbcsPer100WbcsValue', 'otherValue'];
        if(k.indexOf('Check') < 0 && !notAddKeys.includes(k)) {
          const numberValue = Number(attr[k]);
          sum += numberValue;
        }
      });
      set(this.get('model.wbcAttr'),'wbcTotalResult', sum);
    },

    groupBy(list, keyGetter) {
      const map = new Map();
      list.forEach((item) => {
        const key = keyGetter(item);
        const collection = map.get(key);
        if (!collection) {
          map.set(key, [item]);
        } else {
          collection.push(item);
        }
      });
      return map;
    },

  });