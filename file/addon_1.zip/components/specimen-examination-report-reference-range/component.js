/* eslint-disable max-lines */
/* eslint-disable complexity */
/* eslint-disable no-console */
import { Promise } from 'rsvp';
import $ from 'jquery';
import EmberObject, { get, set } from '@ember/object';
import { next } from '@ember/runloop';
import { isEmpty } from '@ember/utils';
import { A } from '@ember/array';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'specimenexaminationreport-module/app-config';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MessageMixin,
  {
    specimenexaminationreportService: service('specimen-examination-report-service'),
    layout,
    item: null,
    typeItemsSource: null,
    // referenceRangeTypeSelectedItem: null,
    appliesToItemsSource: null,
    // appliesToSelectedItem: null,
    quantityComparator: null,
    ageUnitItemSource: null,
    startDate: null,
    endDate: null,
    // newItem: null,
    selectedTabName: null,
    examItemSelectedItem: null,
    isReferTabShow: true,
    isGridShow: false,
    heightErrorMessage: null,
    lowErrorMessage: null,
    isRangeCheck: false,
    heightShowClear: true,
    lowShowClear: true,
    isPopupSaveDisabled: false,

    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-reference-range');
      //Set Stateful properties
      this.setStateProperties([
        'referenceRangeType',
        'referenceRangeColumns',
        'referenceRangeItemsSource',
        'item',
        'appliesToItemsSource',
        'appliesToSelectedItem',
        'quantityComparator',
        'appliesToNames',
        'typeItemsSource',
        'quantityComparator',
        'appliesToItemsSource',
        'ageUnitItemSource',
        'cutoff',
        'selectedTypeValue',
        '_gridControl',
        'itemCopy'
      ]);
      if (this.hasState() === false) {
      //Initialize Stateful properties
        console.log('onPropertyInit---');
        this.set('isReferTabShow', true);
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')
        + `specimen-examination-report/${config.version}/`);
        this.set('itemCopy', {});
        this._setGridColumns();
        this.set('numericOptions',"decimal",{
          // unmaskAsNumber: true
        });
      }
    },

    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'wp100');
      console.log('onLoaded---');
      this.set('isReferTabShow', true);
      this._getBusinessCodeList();
    },
    didInsertElement(){
      this._super(...arguments);
      this.set('isReferTabShow', true);
      // this.$('.scrollbar-macosx').scrollbar();
    },
    didUpdateAttrs() {
      this._super(...arguments);
      console.log('didUpdateAttrs---');
      this.set('initialReferenceRangeItemsSource', A());
      this._examItemSelectedItemChanged();
    },
    _setInputDefualt(item) {
      this.set(`${item}ErrorMessage`, null);
      this.set(`${item}ShowClear`, true);
      this.set('isPopupSaveDisabled', false);
    },
    // 4. Actions Area
    actions: {
      onAgeUnitChanged(item, e) {
        let rangeVal = '';
        if(item === 'low') {
          rangeVal = this.get('itemCopy.ageRangeLow.value');
        } else {
          rangeVal = this.get('itemCopy.ageRangeHigh.value');
        }
        if(e.item.name === 'year' && !isEmpty(rangeVal)) {
          rangeVal = parseInt(rangeVal);
          if(rangeVal > 999) {
            this.set(`${item}ErrorMessage`, '999 이상 입력 할 수 없습니다');
            this.set(`${item}ShowClear`, false);
            this.set('isPopupSaveDisabled', true);
          } else {
            this._setInputDefualt(item);
          }
        } else {
          this._setInputDefualt(item);
        }
      },
      onRangeChanged(item, e) {
        let isChheckUnitRange = false;
        let rangeUnit = null;
        if(item === 'low') {
          rangeUnit = this.get('itemCopy.ageRangeLow.unit');
        } else {
          rangeUnit = this.get('itemCopy.ageRangeHigh.unit');
        }
        if(!isEmpty(rangeUnit) && rangeUnit.name === 'year') {
          isChheckUnitRange = true;
        }
        if(!isEmpty(e.value) && isChheckUnitRange) {
          const inpuVal = parseInt(e.value);
          if(inpuVal > 999) {
            this.set(`${item}ErrorMessage`, '999 이상 입력 할 수 없습니다');
            this.set(`${item}ShowClear`, false);
            this.set('isPopupSaveDisabled', true);
          } else {
            this._setInputDefualt(item);
          }
        } else {
          this._setInputDefualt(item);
        }
      },

      onGridLoad(e){
        this.set('_gridControl', e.source);
      },
      onTypeSelectionChanged(e){
        if(isEmpty(e.selectedItems.get('firstObject'))){
          return;
        }
        if(isEmpty(this.get('initialReferenceRangeItemsSource'))){
          return;
        }
        next(this, function () {
          const arr= this.get('initialReferenceRangeItemsSource').filterBy('typeCode', e.selectedItems.get('firstObject.code'));
          this.set('referenceRangeItemsSource',arr);
          this.set('selectedTypeValue', isEmpty(this.get('selectedTypeValue.code'))? this.get('typeItemsSource')[0]
            : this.get('selectedTypeValue'));
        }.bind(this));
      },

      onAppliesComboboxLoaded(e){
        this.set('applyCombobox', e.source);
        next(this, function () {
          const item= this.get('itemCopy');
          if(!isEmpty(item.appliesTo) ){
            item.appliesTo.forEach(function(element){
              e.source.selectItem(this.get('appliesToItemsSource').find(function(tmp){
                return tmp.name===element.displayContent;
              }));
            }.bind(this));
          }
        }.bind(this));
      },

      onAddClick(e){
        this._init();
        this.set('isEntryPopupOpen', true);
        this.set('targetTypeIndex', null);
        this.set('entryPopuptarget', e.originalEvent.currentTarget);
        next(this, function () {
          if(!isEmpty(this.get('applyCombobox'))){
            this.get('applyCombobox').deselectAll();
          }
        }.bind(this));
      },

      onEntryPopupOpenedAction(){
        this.set('itemCopy.typeCode', this.get('selectedTypeValue.code'));
        if(this.get('selectedTypeValue.code') =='amr'){
          this.set('cutoff', true);
          this.get('applyCombobox').deselectAll();
          this.set('ageUnitItemSource',this.get('amrAgeUnitItemSource'));
          this.set('ageUnitLowRequired', false);
          this.set('ageUnitHighRequired', false);
        }else{
          this.set('ageUnitItemSource', this.get('filteredAgeUnitItemSource'));
          this.set('cutoff', false);
          this.set('ageUnitLowRequired', true);
          this.set('ageUnitHighRequired', true);
        }
        const itemCopy= this.get('itemCopy');
        if(isEmpty(get(itemCopy, 'high.value')) && isEmpty(get(itemCopy, 'low.value')) && isEmpty(get(itemCopy, 'referenceDescription'))){
          this.set('isLowHighRequired', true);
        }else{
          this.set('isLowHighRequired', false);
        }
        // if(!isEmpty(itemCopy.ageRangeLow.unitCode) && !isEmpty(get(itemCopy,'ageRangeLow.unit.classificationCode')) ){
        //ageUnitItemSource 셋팅에 따른
        next(this, function () {
          set(itemCopy, 'ageRangeLow.unit', this.get('ageUnitItemSource').findBy('code', itemCopy.ageRangeLow.unitCode));
          set(itemCopy, 'ageRangeHigh.unit', this.get('ageUnitItemSource').findBy('code', itemCopy.ageRangeHigh.unitCode));
        });
        // }
      },

      onCellDoubleClick(e){
        const itemCopy= $.extend(true, EmberObject.create(), this.get('item'));
        if(isEmpty(itemCopy)){
          this.get('specimenexaminationreportService')._showMessage( this.getLanguageResource('9260', 'F','Select an item.'),
            'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        this.set('isSaveAsBtnDisabled', false);
        this.set('isEntryPopupOpen', true);
        this.set('entryPopuptarget', `#${e.originalSource.elementId}`);
        this.set('itemCopy', {
          typeCode: itemCopy.typeCode,
          low:itemCopy.low,
          high:itemCopy.high,
          appliesTo: itemCopy.appliesTo,
          ageRangeLow: itemCopy.ageRangeLow,
          ageRangeHigh: itemCopy.ageRangeHigh,
          referenceDescription: itemCopy.referenceDescription,
          validStartDate: itemCopy.validStartDate,
          validEndDate: itemCopy.validEndDate,
          id: itemCopy.id
        });
      },

      onDelClick(){
        if(isEmpty(this.get('item.id'))){
          this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9260', 'F','Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        this.delete(this.get('defaultUrl') + 'observation-referenceranges', null, {referenceRangeId:this.get('item.id')}).then(function(){
          this.get('specimenexaminationreportService').onShowToast('delete', this.getLanguageResource('8944', 'F', 'Deleted'), '');
          this._getReferenceRange();
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      },

      onEntryPopupClosedAction(){
        this.set('isSaveAsBtnDisabled', true);
        this.set('applyCombobox', null);
      },

      onLowHighChanged(e){
        const itemCopy= this.get('itemCopy');
        if(!isEmpty(e.value)){
          //값 입력
          this.set('isLowHighRequired', false);
        }else if(isEmpty(itemCopy.high.value) && isEmpty(itemCopy.low.value)){
          this.set('isLowHighRequired', true);
        }else{
          this.set('isLowHighRequired', false);
        }
      },

      onLowTextCleared(){
        const itemCopy= this.get('itemCopy');
        set(itemCopy, 'low.value', null);
        if(isEmpty(this.get('itemCopy.high.value'))){
          this.set('isLowHighRequired', true);
        }
      },
      onHighTextCleared(){
        const itemCopy= this.get('itemCopy');
        set(itemCopy, 'high.value', null);
        if(isEmpty(this.get('itemCopy.low.value'))){
          this.set('isLowHighRequired', true);
        }
      },

      onDescriptionChanged(e){
        if(!isEmpty(e.value)){
          this.set('isLowHighRequired', false);
        }else if(isEmpty(this.get('itemCopy.low.value')) && isEmpty(this.get('itemCopy.high.value'))){
          this.set('isLowHighRequired', true);
        }else{
          this.set('isLowHighRequired', false);
        }
      },

      onDescriptionTextCleared(){
        const low = this.get('itemCopy.low.value');
        const high = this.get('itemCopy.high.value');
        if(isEmpty(low) && isEmpty(high)){
          this.set('isLowHighRequired', true);
        }else{
          this.set('isLowHighRequired', false);
        }
      },

      onDescriptionKeyDown(e){
        const low = this.get('itemCopy.low.value');
        const high = this.get('itemCopy.high.value');
        if(!isEmpty(e.source.value)){
          this.set('isLowHighRequired', false);
          return;
        }
        if(isEmpty(low) && isEmpty(high)){
          this.set('isLowHighRequired', true);
        }else{
          this.set('isLowHighRequired', false);
        }

      },

      onPopUpSaveClick(e){
        const item= this.get('itemCopy');
        if((item.high.comparatorCode != '-' && isEmpty(item.high.value)) || (item.low.comparatorCode != '-' && isEmpty(item.low.value)) ){
          this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9237', 'S', '','수치값 범위를 확인하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        if(isEmpty(item.typeCode)
        || (isEmpty(item.low.value) && isEmpty(item.high.value) && isEmpty(item.referenceDescription))
        || (isEmpty(item.ageRangeHigh.value) && !this.get('cutoff')) || (isEmpty(item.ageRangeLow.value)&& !this.get('cutoff'))
        || (isEmpty(get(item, 'ageRangeHigh.unit.code')) && !this.get('cutoff')) || (isEmpty(get(item,'ageRangeLow.unit.code')) && !this.get('cutoff'))
        || (isEmpty(this.get('applyCombobox.selectedItems')) && !this.get('cutoff'))){
          this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('8945', 'F', 'Enter mandatory fields.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        this.set('isEntryPopupOpen', false);
        const appliesToTemp=[];
        this.get('applyCombobox.selectedItems').forEach(element=>{
          appliesToTemp.addObject({ coding:[{ system: null, version: null, code: element.code, displayName: element.displayCode }], displayContent: element.name});
        });
        const params= {
          examinationId: this.get('examItemSelectedItem.specimenExaminationId'),
          low: item.low,
          high: item.high ,
          typeCode: item.typeCode,
          appliesTo: appliesToTemp ,
          ageRangeLow: {
            value: get(item, 'ageRangeLow.value') , comparatorCode: get(item, 'ageRangeLow.comparatorCode') ,
            unitCode: get(item, 'ageRangeLow.unit.code'), unitName: get(item, 'ageRangeLow.unit.name'),
          },
          ageRangeHigh: {
            value: get(item, 'ageRangeHigh.value'), comparatorCode: get(item, 'ageRangeHigh.comparatorCode') ,
            unitCode: get(item, 'ageRangeHigh.unit.code'), unitName: get(item, 'ageRangeHigh.unit.name'),
          } ,
          referenceDescription: item.referenceDescription,
          validStartDate: new Date(item.validStartDate.getFullYear(), item.validStartDate.getMonth(), item.validStartDate.getDate(), 0, 0, 0),
          validEndDate: isEmpty(item.validEndDate)? new Date('9999','11', '31')
            : new Date(item.validEndDate.getFullYear(), item.validEndDate.getMonth(), item.validEndDate.getDate(), 0, 0, 0),
        };
        if(e.source.name==='saveAsBtn'){
          set(item, 'id', null);
        }
        if(isEmpty(item.id)){
          //다른 이름으로 등록
          this.create(this.get('defaultUrl') + 'observation-referenceranges', null, params).then(function(){
            this._getReferenceRange();
            this.get('specimenexaminationreportService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
          }.bind(this)).catch(function(error){
            this._catchError(error);
          }.bind(this));
        }else {
          //수정
          params.referenceRangeId= item.id;
          this.update(this.get('defaultUrl') + 'observation-referenceranges', null, false, params).then(function(){
            this._getReferenceRange().then(function(){
              this.get('specimenexaminationreportService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
            }.bind(this)).catch(function(error){
              this._catchError(error);
            }.bind(this));
          }.bind(this)).catch(function(error){
            this._catchError(error);
          }.bind(this));
        }
      },

      onTypeChanged(e){
        if(e.item.code =='amr'){
          this.set('cutoff', true);
          this.get('applyCombobox').deselectAll();
        }else{
          this.set('cutoff', false);
        }
      },

      onComparatorChanged(e){
        if(e.item.code == '-'){
          const low = this.get('itemCopy.low.value');
          const high = this.get('itemCopy.high.value');
          if(!isEmpty(this.get('itemCopy.referenceDescription'))){
            this.set('isLowHighRequired', false);
            return;
          }
          if(isEmpty(low) && isEmpty(high)){
            this.set('isLowHighRequired', true);
          }else{
            this.set('isLowHighRequired', false);
          }
        }
      },

      // onAgeValueTextCleared(e){
      //   const itemCopy= this.get('itemCopy');
      //   if(e =='Low'){
      //     set(itemCopy, 'ageRangeLow.unit', null);
      //   }else if(e =='High'){
      //     set(itemCopy, 'ageRangeHigh.unit', null);
      //   }

      // },

      // onAgeValueChanged(option, e){
      //   if (!isEmpty(e.value)){
      //     const itemCopy= this.get('itemCopy');
      //     if(option =='Low'){
      //       if(isEmpty(get(itemCopy, 'ageRangeLow.unit.value'))){
      //         this.set('ageUnitLowRequired', true);
      //         set(itemCopy, 'ageRangeLow.unit', null);
      //       }
      //     }else if(option =='High'){
      //       if(isEmpty(get(itemCopy, 'ageRangeLow.unit.value'))){
      //         // this.set('ageUnitHighRequired', true);
      //         set(itemCopy, 'ageRangeHigh.unit', null);
      //       }
      //     }
      //   }
      // },
    },
    // 5. Private methods Area
    _examItemSelectedItemChanged(){
      const specimenExaminationId= this.get('examItemSelectedItem.specimenExaminationId');
      if(isEmpty(specimenExaminationId)){
        return null;
      }
      if(this.get('selectedTabName')!= 'reference'){
        return;
      }
      if(isEmpty(this.get('typeItemsSource'))){
        //onLoaded() 이전인 경우
        return;
      }
      this._getReferenceRange();

    },

    _setGridColumns() {
      this.set('typeColumns',[
        { title: this.getLanguageResource('1258', 'F','Type'), field: 'name', width:150, bodyTemplateName:'strong'},
      ]);
      this.set('referenceRangeColumns',[
        { title: this.getLanguageResource('4404', 'F', 'Start Date'), field: 'validStartDate', width: 80,type: 'date', dataFormat: 'd', align: 'center'},
        { title: this.getLanguageResource('6967', 'F', 'End Date'), field: 'validEndDate', width: 80,type: 'date', dataFormat: 'd', align: 'center'},
        { title: this.getLanguageResource('9522', 'S', '하한값'), field: 'lowValue', width: 70, align: 'center'},
        { title: this.getLanguageResource('9523', 'S', '상한값'), field: 'highValue', width: 70, align: 'center'},
        { title: this.getLanguageResource('9885', 'S', '연령하한'), field: 'ageRangeLowValue', width: 100, align: 'center'},
        { title: this.getLanguageResource('9886', 'S', '연령상한'), field: 'ageRangeHighValue', width: 100, align: 'center'},
        { title: this.getLanguageResource('9524', 'F', 'Applies To'), field: 'displayContent', width: 40, align: 'center'},
      ]);

    },

    async _getBusinessCodeList() {
      this.set('isReferTabShow', true);
      const defaultUrl = this.get('defaultUrl');
      const businessCodes= await this.getList(defaultUrl + 'business-codes/search', null,{
        classificationCodes: [
          'ObservationReferenceRangeMeaningCodes','QuantityComparator', 'AppliesTo', 'AgeUnit'
        ]
      }, false);
      const typeItemsSource=[];
      const appliesToItemsSource= [];
      const quantityComparator= [];
      const ageUnitItemSource= [];
      businessCodes.forEach(e=>{
        if(e.classificationCode == 'ObservationReferenceRangeMeaningCodes'){
          typeItemsSource.addObject(e);
        }else if(e.classificationCode == 'QuantityComparator'){
          quantityComparator.addObject(e);
        }else if(e.classificationCode == 'AppliesTo'){
          appliesToItemsSource.addObject(e);
        }else if(e.classificationCode == 'AgeUnit'){
          ageUnitItemSource.addObject(e);
        }
      });
      this.set('isGridShow', true);
      this.set('typeItemsSource', typeItemsSource);
      this.set('appliesToItemsSource', appliesToItemsSource);
      this.set('quantityComparator', quantityComparator);
      this.set('selectedTypeValue', typeItemsSource[0]);
      this.set('amrAgeUnitItemSource', ageUnitItemSource);
      const tmp= $.extend(true, [], ageUnitItemSource.map(function(e){
        return $.extend(true, {}, e);
      }));
      tmp.removeObject(tmp[0]);
      this.set('filteredAgeUnitItemSource', tmp);
      await this._getReferenceRange();
    },

    _init(){
      this.set('currentDate', this.get('co_CommonService').getNow());
      if(isEmpty(this.get('filteredAgeUnitItemSource'))){
        return;
      }
      const item= {
        typeCode: this.get('typeItemsSource.firstObject.code'),
        low:{
          comparatorCode: this.get('quantityComparator.firstObject.code'), value: null, unitCode: null, unitName: null,
        },
        high:{
          comparatorCode: this.get('quantityComparator.firstObject.code'), value: null, unitCode: null, unitName: null,
        },
        appliesTo: null,
        ageRangeLow: {
          comparatorCode: this.get('quantityComparator.firstObject.code'),
          value: null,
          // unitCode: this.get('ageUnitItemSource.firstObject.displayCode'),
          // unit: this.get('ageUnitItemSource.firstObject')
          unitName: null,
          unitCode: null,
          unit: {code:null, name:null}
        },
        ageRangeHigh: {
          comparatorCode: this.get('quantityComparator.firstObject.code'),
          value: null,
          // unitCode: this.get('ageUnitItemSource.firstObject.displayCode'),
          // unit: this.get('ageUnitItemSource.firstObject'),
          unitName: null,
          unitCode: null,
          unit: {code:null, name:null}
        },
        referenceDescription: null,
        validStartDate: this.get('currentDate'),
        // validEndDate: new Date('2999','11', '31'),
        validEndDate: null,
      };
      this.set('itemCopy', item);
    },

    _getReferenceRange(){
      const specimenExaminationId= this.get('examItemSelectedItem.specimenExaminationId');
      if(isEmpty(specimenExaminationId)){
        return;
      }
      this.set('isReferTabShow', true);
      const typeItemsSource= this.get('typeItemsSource');
      typeItemsSource.forEach(function(r){
        set(r, 'style', '');
      });
      this.set('targetTypeIndex',this.get('selectedTypeValue'));
      return this.getList(this.get('defaultUrl') + 'observation-referenceranges/'+ specimenExaminationId, null, null,true).then(function(res){
        this.set('isReferTabShow', false);
        if(res){
          const promise = new Promise((resolve)=>{
            const selectRowsTmp=[];
            if(res.response.length){
              resolve(A(res.response));
              const appliesToItemsSource= this.get('appliesToItemsSource');
              if(isEmpty(appliesToItemsSource)){
                return;
              }
              res.response.forEach(element => {
                typeItemsSource.forEach(function(r, index){
                  if(r.code == element.typeCode){
                    set(r, 'style', 'font-weight: bold');
                    selectRowsTmp.addObject(index);
                  }
                });
                this._setData(element);
              });
              res.response.map(data => {
                data.lowValue = data.lowValue === 'null' ? null : data.lowValue;
                data.highValue = data.highValue === 'null' ? null : data.highValue;
              });
              this.set('initialReferenceRangeItemsSource', res.response);
              this.set('typeItemsSource', typeItemsSource);
              this.get('_gridControl').selectRow(this.get('targetTypeIndex'));
              const arr= this.get('initialReferenceRangeItemsSource').filterBy('typeCode', this.get('selectedTypeValue.code'));
              this.set('referenceRangeItemsSource',arr);
            } else{
              resolve(A(res.response));
              this.set('referenceRangeItemsSource', null);
              this._init();
              typeItemsSource.forEach(function(r){
                set(r, 'style', '');
              });
              this.set('typeItemsSource', typeItemsSource);
              this.set('selectedTypeValue', null);
            }
          });
          return promise;
        }
      }.bind(this)).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    _setData(element){
      let first='';
      element.get('appliesTo').forEach(e=> {
        if(!isEmpty(e.displayContent)){
          first= isEmpty(first)? e.displayContent : first + ', ' + e.displayContent;
        }
        set(element, 'displayContent', first);
      });
      set(element, 'validEndDate', element.validEndDate.toString() > "9999-12-30"? null : element.validEndDate);
      set(element, 'ageRangeLow.unit', {code: element.ageRangeLow.unitCode, name: element.ageRangeLow.unitName});
      set(element, 'ageRangeHigh.unit', {code: element.ageRangeHigh.unitCode, name: element.ageRangeHigh.unitName});
      set(element, 'ageRangeLow.value', isEmpty(element.ageRangeLow.value)? '' :element.ageRangeLow.value);
      set(element, 'ageRangeHigh.value', isEmpty(element.ageRangeHigh.value)? '' :element.ageRangeHigh.value);
      set(element, 'lowValue', element.low.comparatorCode=='-'? element.low.value : element.low.comparatorCode + element.low.value);
      set(element, 'highValue', element.high.comparatorCode =='-'? element.high.value: element.high.comparatorCode + element.high.value);
      let ageRangeLowValue = element.ageRangeLow.comparatorCode =='-'? element.ageRangeLow.value : element.ageRangeLow.comparatorCode + element.ageRangeLow.value;
      ageRangeLowValue = ageRangeLowValue === 'null' ? null : ageRangeLowValue;
      if(!isEmpty(element.ageRangeLow.unitName)) {
        ageRangeLowValue = `${ageRangeLowValue} ${element.ageRangeLow.unitName}`;
      }
      set(element, 'ageRangeLowValue', ageRangeLowValue);
      let ageRangeHighValue = element.ageRangeHigh.comparatorCode =='-'? element.ageRangeHigh.value : element.ageRangeHigh.comparatorCode + element.ageRangeHigh.value;
      ageRangeHighValue = ageRangeHighValue === 'null' ? null : ageRangeHighValue;
      if(!isEmpty(element.ageRangeHigh.unitName)) {
        ageRangeHighValue = `${ageRangeHighValue} ${element.ageRangeHigh.unitName}`;
      }
      set(element, 'ageRangeHighValue',ageRangeHighValue );
    },

    _catchError(e){
      this.set('isReferTabShow',false);
      this.showResponseMessage(e);
    }
  });