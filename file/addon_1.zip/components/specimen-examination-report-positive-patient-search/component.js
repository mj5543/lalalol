/* eslint-disable prefer-named-capture-group */
/* eslint-disable no-console */
import { isEmpty, isPresent } from '@ember/utils';
import { set } from '@ember/object';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from '../../app-config';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';
import PrintMixin from '../../mixins/specimen-examination-report-print-mixin';
import ValueSettingMixin from '../../mixins/specimen-examination-resport-result-value-setting-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  PrintMixin,
  MessageMixin,
  ValueSettingMixin,
  {
    layout,
    defaultUrl: null,
    searchPatientId: null,
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-positive-patient-search');
      //Set Stateful properties
      this.setStateProperties([
        'defaultUrl',
        'searchCondition',
        'gridColumns',
        'gridItemsSource',
      ]);
      this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')
      +`specimen-examination-report/${config.version}/`);
      this.set('codebuilderUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationcodebuilder')+'specimen-examination-code-builder/v0/');
      this.set('gridColumns',[
        { field: 'encounterType.name', title: this.getLanguageResource('16963', 'S', '구분'),align: 'center', width: 60},
        { title: this.getLanguageResource('16881', 'F','Pt Name'), field: 'patient.name', bodyTemplateName: 'bold',align: 'center', width: 90 },
        { title: this.getLanguageResource('8451', 'S','MRN'), field: 'patient.displayNumber', align: 'center', width: 65, bodyTemplateName: 'bold' },
        { title: this.getLanguageResource('3680', 'F','Sex'), field: 'patient.gender',align: 'center', width: 35 },
        { title: this.getLanguageResource('1662', 'F','Age'), field: 'patient.age',align: 'center', width: 35 },
        { title: this.getLanguageResource('6366', 'S', '입원일'), field: 'visitStartDate', width: 90, type: 'date', dataFormat: 'd', align: 'center' },
        { title: this.getLanguageResource('7821', 'S', '퇴원일'), field: 'visitEndDate', width: 90, type: 'date', dataFormat: 'd', align: 'center' },
        { title: this.getLanguageResource('6777', 'S', '접수일'), field: 'checkInDate', width: 90, type: 'date', dataFormat: 'd', align: 'center', bodyTemplateName: 'dateTime' },
        { title: this.getLanguageResource('2872', 'S', '보고일'), field: 'reportedDatetime', width: 90, type: 'date', dataFormat: 'd', align: 'center' },
        { title: this.getLanguageResource('1113', 'S','진료과'), field: 'department.name', width: 100, align: 'center', bodyTemplateName: 'tooltip' },
        { title: this.getLanguageResource('8827', 'S','발행처'), field: 'issuedDepartment.name', width: 100, align: 'center', bodyTemplateName: 'tooltip' },
        { title: this.getLanguageResource('16919', 'S', '검사코드'), field: 'examination.displayCode', width: 100, bodyTemplateName:'tooltip'},
        { title: this.getLanguageResource('17062', 'S', '검사명'), field: 'examination.name', width: 150, bodyTemplateName:'tooltip'},
        { title: this.getLanguageResource('17110', 'F','검사결과'), field: 'displayValue', width: 100, align: 'center', bodyTemplateName: 'resultTooltip'},
        { title: this.getLanguageResource('16921', 'S','검체명'), field: 'specimenType.name', bodyTemplateName: 'tooltip', width: 100, },
        { title: this.getLanguageResource('16402', 'F','재원여부'), field: 'isInHospital', width: 70, align: 'center'},
        { field: 'currentLocation', title: this.getLanguageResource('14751', 'S','현위치'),align: 'center', width: 100, bodyTemplateName: 'locationTooltip'},
      ]);
      const today= this.get('co_CommonService').getNow();
      const searchCondition = {
        queryOption: null,
        fromDate: today,
        toDate: today,
        subjectNumber: null,
        specimenNumber: null,
        classificationIds: null,
        classificationId: null,
        separationGroupCode: null,
        encounterTypeCode: null,
        admissionStatus: null,
        specifiedExaminationTypeCode: null,
        wardCode: null,
        patientId: null,
      };
      this.set('model', {
        selectedWardItem: null,
      });
      this.set('allCount', 0);
      this.set('positiveCount', 0);
      this.set('negativeCount', 0);
      this.set('notReportedCount', 0);
      this.set('searchCondition', searchCondition);
    },
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1360');
      if (this.hasState() === false) {
        this.set('admissionStatusItems', [
          {name: this.getLanguageResource('6700', 'F', '', '전체'), code: 'All'},
          {name: 'Y', code: true},
          {name: 'N', code: false},
        ]);
        this.set('searchCondition.admissionStatus', 'All');
        this._getCodeGroupList();
        this._geWardItems();
        this._getBusinessCodes();
      }
    },
    actions: {
      onLoadDepCombobox(e){
        this.set('issuedDepartmentCombobox', e.source);
      },
      onLoadGrid(e){
        this.set('gridSource', e.source);
      },
      onResultDetailClick(item) {
        if(isEmpty(item.value.recordNoteId)) {
          return;
        }
        this.set('searchRecordNoteId', item.value.recordNoteId);
        this.set('recordExaminationId', item.examination.id);
        this.set('recordExaminationName', item.examination.name);
        this.set('isReportResultOpen', true);
      },
      onRecordPopupClosed() {
        this.set('searchRecordNoteId', null);
        this.set('recordExaminationId', null);
        this.set('recordExaminationName', null);
      },
      onFromToUpdated(e) {
        const fromDate = this.get('fr_I18nService').formatDate(e.selectedFromDate, 'd');
        const toDate = this.get('fr_I18nService').formatDate(e.selectedToDate, 'd');
        this._getGridData(`${fromDate} ~ ${toDate}`);
      },
      onSeparationGroupCodeChanged(title, e) {
        this.set('searchCondition.separationGroupCode', e.item.displayCode);
        this._getGridData(`${title} :  ${e.item.name}`);
      },
      onTypeCodeChanged(title, e) {
        this.set('searchCondition.specifiedExaminationTypeCode', e.item.code);
        this._setGridItemsSource(`${title} : ${e.item.name}`);
      },
      onWardChanged(title, e) {
        this.set('searchCondition.wardCode', e.item.id);
        this._getGridData(`${title} :  ${e.item.name}`);
      },
      onSearchClick(){
        this._getGridData();
      },
      onEncounterTypeCodeChanged(e){
        this.set('searchCondition.encounterTypeCode', e.item.code);
        this._getDepartments();
      },
      onGetPatient(item) {
        console.log('onGetPatient--', item);
        this.set('searchPatientInfo', item);
        this.set('searchCondition.patientId', item.patientId);
        this.set('patientInfoTooltip',`${item.primaryFullName} ( ${item.displayId} )`);
        const content = `${item.primaryFullName} (${item.displayId}/${item.genderCodeName}/${item.medicalAge}${this.getLanguageResource('3703', 'F', '', '세')})`;
        this._getGridData(content);
      },
      onCleareSearch() {
        this.set('searchPatientInfo', null);
        this.set('patientInfoTooltip', null);
      },
      onExcelPrintAction() {
        const gridSource = this.get('gridSource');
        const reason = 'Excel export specimen-examination-report-positive-patient list.';
        const headers = [];
        const fields = [];
        this.get('gridColumns').forEach(function(item, index){
          headers.addObject({ left: index, top: 0, right: index, bottom: 0, value: item.title});
          item.type == 'date'? fields.addObject({ width: 140, value: item.field }) : fields.addObject({ width: item.width, value: item.field });
        });
        gridSource.exportToExcel('specimen-examination-report-positive-patient-search.xlsx', headers, fields, this, 'onExcelPrintAction',reason , this.get('gridItemsSource'));
      },
    },
    async _getGridData(refreshContent){
      try {
        const searchCondition= this.get('searchCondition');
        if(isEmpty(searchCondition)){
          return;
        }
        set(this.get('searchCondition'), 'issuedDepartmentIds', this.get('issuedDepartmentCombobox.selectedItems').map(function(item){
          return item.id;
        }));
        this.set('isGridShow', true);
        this.set('gridItemsSource', null);
        const params={
          checkInFromDate: new Date(searchCondition.fromDate.getFullYear(), searchCondition.fromDate.getMonth(), searchCondition.fromDate.getDate(), 0, 0, 0).toFormatString(),
          checkInToDate: new Date(searchCondition.toDate.getFullYear(), searchCondition.toDate.getMonth(), searchCondition.toDate.getDate(), 0, 0, 0).toFormatString(),
          separationGroupCode: searchCondition.separationGroupCode,
          specifiedExaminationTypeCode: searchCondition.specifiedExaminationTypeCode,
          encounterTypeCode: searchCondition.encounterTypeCode,
          wardId: searchCondition.wardCode,
          isInHospital: searchCondition.admissionStatus === 'All' ? null : searchCondition.admissionStatus,
          patientId: isEmpty(searchCondition.patientId)? null : searchCondition.patientId.trim(),
          issuedDepartmentIds: isEmpty(searchCondition.issuedDepartmentIds)? null : searchCondition.issuedDepartmentIds
        };
        const res = await this.getList(this.get('defaultUrl') + 'observations/results/separation-condition', null, params, false);
        if(!isEmpty(refreshContent)) {
          this.showToastRefresh(refreshContent);
        }
        if(isPresent(res)) {
          res.map(d => {
            let resultTooltip = d.displayValue;
            if(d.valueTypeCode === 'ValueTextString' && isPresent(resultTooltip)) {
              resultTooltip = d.displayValue.replace(/(\n|\r\n)/gu, '<br>');
            }
            d.resultTooltip = resultTooltip;
            // d.displayValue = this._setValueString(d, 'value');
            // d.orderNameTooltip = d.examination.displayCode + ', '+ d.examination.name;
            let location = d.issuedDepartment.name;
            let locationTooltip = d.issuedDepartment.name;
            if(!isEmpty(d.ward)) {
              location = `${d.ward.displayCode} / ${d.room.roomCode} / ${d.bed.displayCode}`;
              locationTooltip = `${d.ward.name} / ${d.room.roomName} / ${d.bed.name}`;
            }
            d.currentLocation = location;
            d.locationTooltip = locationTooltip;
          });
        }
        this.set('listResult', res);
        // this.set('gridItemsSource', res);
        this._setGridItemsSource();
        this.set('allCount', res.length);
        this.set('positiveCount', res.filter(d => d.specifiedExaminationType === 'Positive').length);
        this.set('negativeCount', res.filter(d => d.specifiedExaminationType === 'Negative').length);
        this.set('notReportedCount', res.filter(d => d.specifiedExaminationType === 'NotReported').length);
        this.set('isGridShow', false);
      } catch(e) {
        this.set('isGridShow', false);
        this.set('allCount', 0);
        this.set('positiveCount', 0);
        this.set('negativeCount', 0);
        this.set('notReportedCount', 0);
        this._showError(e);
      }
    },
    _setGridItemsSource(refreshContent) {
      try {
        const specifiedExaminationTypeCode = this.get('searchCondition.specifiedExaminationTypeCode');
        const listResult = this.get('listResult');
        if(specifiedExaminationTypeCode === 'A') {
          this.set('gridItemsSource', listResult);
        } else {
          this.set('gridItemsSource', listResult.filter(d => d.specifiedExaminationType === specifiedExaminationTypeCode));
        }
        if(!isEmpty(refreshContent)) {
          this.showToastRefresh(refreshContent);
        }
      } catch(e) {
        this._showError(e);
      }
    },
    async _getBusinessCodes() {
      try {
        const results = await this.getList(this.get('defaultUrl') + 'business-codes/search', null, {classificationCodes: ['WorkListSearchCode', 'EncounterTypeCode', 'SpecifiedExaminationTypeCode']}, false);
        if(isPresent(results)) {
          const patientTypes = results.filter(d => d.classificationCode === 'EncounterTypeCode');
          const specifiedExaminationTypes = results.filter(d => d.classificationCode === 'SpecifiedExaminationTypeCode');
          this.set('searhConditionStatusItems', results.filter(d => d.classificationCode === 'WorkListSearchCode'));
          this.set('patientTypeItems', patientTypes);
          specifiedExaminationTypes.unshiftObject({name: this.getLanguageResource('6700', 'F', '', '전체'), code: 'A'});
          this.set('specifiedExaminationTypes', specifiedExaminationTypes);
          this.set('searchCondition.encounterTypeCode', patientTypes[0].code);
          this._getDepartments();
          this.set('searchCondition.specifiedExaminationTypeCode', specifiedExaminationTypes[0].code);
        }
      }catch(e) {
        //
      }
    },
    async _getCodeGroupList() {
      try {
        const res = await this.getList(this.get('codebuilderUrl') + 'separation-group', {groupTypeCode: 'PossitivePatient'}, null);
        res.unshiftObject({name: this.getLanguageResource('6700', 'F', '', '전체'), displayCode: 'A'});
        this.set('separationGroups', res);
        this.set('searchCondition.separationGroupCode', 'A');
      } catch(e) {
        this._showError(e);
      }
    },

    async _getDepartments(){
      try {
        const encounterTypeCode = this.get('searchCondition.encounterTypeCode');
        // const encounterTypeCode = 'I';
        if(!isEmpty(encounterTypeCode)) {
          const res = await this._getDepartmentsSearch({encounterTypeCode: encounterTypeCode});
          this.set('deptItemsSource', res);
        }
      } catch(e) {
        this._showError(e);
      }
    },
    async _geWardItems() {
      try {
        const ward = await this._getDepartmentsSearch({businessGroupCode: 'WARD'});
        const wardItems = [
          {name: this.getLanguageResource('6700', 'F', '', '전체'), id: 'A'},
          ...ward
        ];
        this.set('wardItems', wardItems);
        this.set('searchCondition.wardCode', 'A');
      } catch(e) {
        this._showError(e);
      }
    },
    _getDepartmentsSearch(param) {
      return this.getList(`${this.get('defaultUrl')}departments/search`, param, null);
    },
  });