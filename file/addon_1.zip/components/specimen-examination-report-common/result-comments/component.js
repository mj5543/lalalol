import $ from 'jquery';
import { next } from '@ember/runloop';
import { isEmpty } from '@ember/utils';
// import { hash } from 'rsvp';
import { copy } from '@ember/object/internals';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from '../../../app-config';
import MessageMixin from '../../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MessageMixin,
  /* Only For Server-Call Component
  CHIS.FR.CrossCutting.ServerCallMixin,
  */
  {
    /* 1. Service define Area
     testService:Ember.inject.service(),
    */
    specimenexaminationreportService: service('specimen-examination-report-service'),
    layout,
    // 2. Property Area
    isPopupOpen: null,
    titleResource: null,
    remark:null,
    allResultCommentsItemsSource: null,

    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId', 'specimen-examination-report-common/result-comments');

      this.setStateProperties([
        // 'isPopupOpen',
        'titleResource',
        'remark',
        'allResultCommentsItemsSource',
        'resultCommentsItemsSource'
      ]);

      if (!this.hasState()) {
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')+`specimen-examination-report/${config.version}/`);
        this.set('isPopupOpen', false);
        this.set('itemsSource', copy(this.get('resultCommentsList')));
        this._getResultCommentsItemsSource();
      }
    },

    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w680');
      // if (this.hasState() === false) {
      //   const defaultUrl = this.get('defaultUrl');
      //   hash({
      //     allResultCommentsItemsSource: this.getList(defaultUrl + 'observations/examples', {exampleTypeCode: 'ResultRemark', examinationId: null}, null),
      //   }).then(function(result) {
      //     this.set('allResultCommentsItemsSource', result.allResultCommentsItemsSource);
      //   }.bind(this)).catch(function(error){
      //     this._catchError(error);
      //   }.bind(this));
      // }
    },

    // 4. Actions Area
    actions: {
      onOpenedAction(e){
        this.set('popup', e.source);
        if(!isEmpty(this.get('_currentCell'))){
          this.set('remark', this.get('_currentCell').item.remark);
        }
        this._filtering();
        next(this, function () {
          const selector = 'div[data-id=' + this.get('popup').elementId + ']';
          const popupDom = $(selector);
          let target = popupDom.find('[name=result-comments_remark]');
          target = target.find('input:first');
          target.parent().find('input').focus();
        }.bind(this));

      },
      onConfirmClick(){
        this._returnRemark();
      },

      onPopupClosed(){
        this.set('remark', null);
      },

      onSelectionChange(e){
        const returnResultCommentsCB = this.get('returnResultCommentsCB');
        if(!isEmpty(returnResultCommentsCB)) {
          // if(!isEmpty(e.source.value)){
          //아이템 선택
          returnResultCommentsCB(e.source.value, true);
          return false;
          // }
        }
      },
      onKeyDown(e){
        const type = this.get('specimenexaminationreportService').getKeyBoardEventType(e.originalEvent);
        if(type== 'enter'){
          this.set('remark', e.source.value);
          this._returnRemark();
        }
      },

      onNewRemarkClick(){
        this.set('isRegisterRemarkPopupOpen', true);

      },

      onRemarkChangedCB(){
        this._getResultCommentsItemsSource();
      }
    },

    _filtering(){
      const resultCommentsItemsSource= [];
      if(!isEmpty(this.get('allResultCommentsItemsSource'))){
        this.get('allResultCommentsItemsSource').forEach(i=>{
          if(isEmpty(i.examinationId) || i.examinationId == this.get('_currentCell.item.examinationId')){
            resultCommentsItemsSource.addObject(i);
          }
        });
      }
      this.set('resultCommentsItemsSource', resultCommentsItemsSource);
    },

    _getResultCommentsItemsSource(){
      const params = {
        exampleTypeCode: 'ResultRemark',
        examinationId: null,
        classificationId: this.get('classificationId')
      };
      this.getList(this.get('defaultUrl') + 'observations/examples', params, null).then(function(result) {
        this.set('allResultCommentsItemsSource', result);
        this._filtering();
      }.bind(this)).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    _returnRemark(){
      this.get('onCommentCB')(this.get('remark'));
      this.set('isPopupOpen', false);
    },

    _catchError(e){
      // this.set('isResultGridShow',false);
      this.showResponseMessage(e);
    }
  });

