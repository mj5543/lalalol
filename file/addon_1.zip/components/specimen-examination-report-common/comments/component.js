import { isEmpty } from '@ember/utils';
import {set} from '@ember/object';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import MessageMixin from '../../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MessageMixin,
  /* Only For Server-Call Component
  CHIS.FR.CrossCutting.ServerCallMixin,
  */
  {
    specimenexaminationreportService: service('specimen-examination-report-service'),
    specimenSamplingService: service('specimen-sampling-service'),
    layout,
    // 2. Property Area
    defaultUrl: null,
    isReasonSaveClick: false,

    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      //this.set('menuClass', 'w1000');
      this.set('viewId','specimen-examination-report-common/comments');
      //Set Stateful properties
      this.setStateProperties([
        'defaultUrl',
        'currentUser',
      ]);
      if (this.hasState() === false) {
      //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')
      + `specimen-examination-report/v0/`);
        // this.set('currentUser', this.get('co_CurrentUserService.user'));
      }
    //Initialize Stateless properties
    },

    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
    // if (this.hasState() === false) {
    // }
    },
    // 4. Actions Area
    actions: {
      // onDeptCommentsMouseEnter(e){
      //   this.set('deptHistoryTarget', this.$(e.target).get(0));
      //   this.set('isDeptCommentsHistoryOpen', !this.get('isDeptCommentsHistoryOpen'));
      // },
      onDeptCommentSaveClick(){
        if(isEmpty(this.get('resultListSelectedItem'))){
          return;
        }
        if(isEmpty(this.get('resultListSelectedItem'))&& isEmpty(this.get('comments'))){
          return;
        }
        this.get('specimenexaminationreportService').departmentCommentSave(this.get('resultListSelectedItem'), this.get('comments'), true).then(function(){
          this.set('comments.notification', true);
          this.get('specimenexaminationreportService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
          this.get('specimenexaminationreportService').getDepartmentComments(this.get('resultListSelectedItem')).then(res=>{
            if(!isEmpty(res)){
              this.set('comments', res);
            }
          }).catch(function(error){
            this._catchError(error);
          }.bind(this));
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      },

      onDeptCommentDelClick(item){
        if(isEmpty(this.get('resultListSelectedItem'))){
          return;
        }
        try {
          this.get('specimenexaminationreportService').departmentCommentSave(null, item, false).then(function(){
            // this.set('comments.notification', true);
            this.get('specimenexaminationreportService').getDepartmentComments(this.get('resultListSelectedItem')).then(res=>{
              if(!isEmpty(res)){
                this.set('comments', res);
              }
            }).catch(function(error){
              this._catchError(error);
            }.bind(this));
            this.get('specimenexaminationreportService').onShowToast('delete', this.getLanguageResource('8944', 'F', 'Deleted'), '');
          }.bind(this)).catch(function(error){
            this._catchError(error);
          }.bind(this));
          // this.update(this.get('defaultUrl') + 'observations/results/remarks', null, false, {
          //   observationRemarkId: item.observationRemarkId,
          //   remark: "string",
          //   isValidDataRow: false
          // }).then(function(){
          //   this.get('specimenexaminationreportService').onShowToast('delete', this.getLanguageResource('8944', 'F', 'Deleted'), '');
          //   //재조회
          // }.bind(this));
        }catch(e) {
          this.showResponseMessage(e);
        }
      },
      onReasonSaveClick() {
        if(isEmpty(this.get('resultListSelectedItem'))) {
          return;
        }
        this.set('isReasonSaveClick', true);
      },
      onReasonSaveSuccessCB() {
        this.set('isReasonSaveClick', false);
        set(this.get('comments'), 'isCommentsExpanded', true);
        this.showToastSaved();
      },
      onReaseonSelectedItemCB() {
        set(this.get('comments'), 'isCommentsExpanded', true);
      },
      onPopupClosed() {
        this.set('isReasonSaveClick', false);
      },
    },
    // 5. Private methods Area
    _catchError(e){
      this.set('isReasonSaveClick', false);
      this.showResponseMessage(e);
    }
  });