/* eslint-disable no-console */
/* eslint-disable max-lines-per-function */
/* eslint-disable no-undef */
import { isEmpty, isPresent } from '@ember/utils';
import { A as emberA } from '@ember/array';
import { set } from '@ember/object';
import layout from './template';
import CHIS from 'framework/chis-framework';
import SpecimenExaminationReportMixin from '../../mixins/specimen-examination-report-mixin';
import PrintMixin from '../../mixins/specimen-examination-report-print-mixin';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(
  CHIS.FR.CrossCutting.ServerCallMixin,
  SpecimenExaminationReportMixin,
  PrintMixin,
  MessageMixin,
  {
    layout,
    selectedTabName: null,
    isDisabled: true,
    searchPatientInfo: null,
    isShowContainerLoader: false,
    workConfigurationList: null,
    remarkInfo: null,
    remarkInputValue: null,
    orderRemarkInputValue: null,
    isShowContentLoader: false,
    departmentCombobox: null,
    isReportResultOpen: false,
    isShowObservationsLoader: false,
    tagCallbackItems: null,
    isRecordViewerOpen: false,
    isRecordDisabled: true,
    isConditionDisabled: false,
    isPrintDisabled: true,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'specimen-examination-report-examination-result-search');
      this.setStateProperties([
        'model',
        'selectedFromDate',
        'selectedToDate',
        'isDisabled',
        'worksResultItemsSource',
        'worksResultColumns',
        'observationsResultItemsSource',
        'observationsResultColumns',
        'departmentList',
        'encounterList',
        'workConfigurationList',
        'examinationCategoryTagItems',
        'examinationUnitTagItems',
        'examinationTagItems',
        'examinationTagList',
      ]);

      if (!this.hasState()) {
        this.set('isDisabled', false);
        this.set('model', {
          selectedEncountTypeCode: null,
          workConfigSelectedItem: null,
          workConfigSelectedValue: null,
          departmentSelectedItems: null,
          resultWorksSelectedItem: null,
          observationsResultSelectedItem: null,
          searchRecordNoteId: null,
          recordExaminationId: null,
          originId: null,
        });
        const displayDate = new Date(this.get('co_CommonService').getNow());
        this.set('selectedFromDate', displayDate);
        this.set('selectedToDate', displayDate);
        this.set('findSettingPopupInfo', {});
        this.set('findSettingPopupInfo.isOpen', false);
      }
      this.set('worksResultItemsSource', []);
      this.set('observationsResultItemsSource', []);
      this.set('workConfigurationList', []);
      this.set('departmentList', []);
      this.set('encounterList', []);
      this.set('worksResultColumns', [
        { field: 'orderInfo.classification.name', title: this.getLanguageResource('16892', 'S', '', '검사분류'), width:70},
        { field: 'checkInDateTime', title: this.getLanguageResource('9919', 'S', '', '접수일시'), align: 'center', width:90, type: 'date', dataFormat: 'g' },
        { field: 'checkInNumber', title: this.getLanguageResource('6767', 'S', '', '접수번호'), width: 60, align: 'center'},
        { field: 'reportedDateTime', title: this.getLanguageResource('2873', 'S', '', '보고일시'), align: 'center', width:90, type: 'date', dataFormat: 'g'},
        { field: 'specimenNumber', title: this.getLanguageResource('859', 'S', '', '검체번호'), align: 'center', width:80 },
        { field: 'specimenType.name', title: this.getLanguageResource('16921', 'S','Specimen Name'), width:80 },
      ]);
      this.set('observationsResultColumns', [
        { field: 'examination.name', title: this.getLanguageResource('16920', 'S', '검사항목'), width:100, bodyTemplateName:'examinationName'},
        { field: 'displayResult', title: this.getLanguageResource('890', 'S', '결과'), align: 'center', width:50, bodyTemplateName:'detailview' },
        { field: 'comment', title: this.getLanguageResource('906', 'S', '', '결과비고'), width: 40, align: 'center', bodyTemplateName: 'commentIcon'},
        { field: 'statusName', title: this.getLanguageResource('3452', 'S', '', '상태'), align: 'center', width:40, bodyTemplateName: 'status'},
        { field: 'subject.referenceRange.rangeContent', title: this.getLanguageResource('10745', 'F', '', '참고치'), align: 'center', width:90, bodyTemplateName:'cellTooltip' },
        { field: 'examinationUnit.name', title: this.getLanguageResource('1819', 'S', '', '단위'), align: 'center', width:50 },
        { field: 'issuedDatetime', title: this.getLanguageResource('2873', 'S', '', '보고일시'), align: 'center', width:90, type: 'date', dataFormat: 'g' },
        { field: 'issuedStaff.name', title: this.getLanguageResource('784', 'S', '', '검사자'), align: 'center', width:50 },
      ]);
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1360');
      this.set('fileuploadUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'technicalServiceUrl'));
      const userInfoSets = this.get('globalCurrentUser');
      let hospitalId = null;
      let tenantId=null;
      if(!isEmpty(userInfoSets)){
        hospitalId = userInfoSets.hospital.hospitalId;
        tenantId = userInfoSets.tenant.tenantId;
      }
      this.set('fileUrl', this.get('fileuploadUrl')+'file/v4/'+tenantId+'/'+hospitalId+'/view');
      this.set('roiUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'roi') + `roi/v0/`);
      this.set('generalRecordUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'generalrecord') + `general-record/v0/`);
      // this._getEmployeeSignature();
      // const imagePath = isEmpty(this.get('employeeSignature'))? null : this.get('employeeSignature').imagePath;
      // const filePath = isEmpty(imagePath)? null : this.get('technicalServiceUrl')+'file/v4/'+tenantId+'/'+hospitalId+'/view/'+imagePath;
      this._init();
    },
    async _getEmployeeSignature() {
      const result = await this.getList(this.get('roiUrl') + `codes/employee-signatures/${this.get('globalCurrentUser.employeeId')}/summary-views`);
      console.log('result----', result);
    },
    actions: {
      onSettingClick() {
        //
      },
      onSelectionChangedAction() {
        //
      },
      onLoadedDepartmentCombobox(e) {
        this.set('departmentCombobox', e.source);
      },
      onSearchClick() {
        this._getResultWorks();
      },
      onResultDetailClick(item) {
        if(isEmpty(item.value.recordNoteId)) {
          return;
        }
        this.set('model.searchRecordNoteId', item.value.recordNoteId);
        this.set('model.recordExaminationId', item.examination.id);
        this.set('isReportResultOpen', true);
      },
      onRecordPopupClosed() {
        this.set('model.searchRecordNoteId', null);
        this.set('model.recordExaminationId', null);

      },
      onRecordViewerOpen() {
        this.set('isRecordViewerOpen', true);
      },
      onRecordViewerClosed() {
        this.set('model.originId', null);
      },
      onGetPatient(item) {
        this.set('searchPatientInfo', item);
        this._getResultWorks();
      },
      onClearedSearch() {
        this.set('searchPatientId', null);
        this.set('searchPatientInfo', null);
        this._getResultWorks();

      },
      onCommitSearch(result) {
        if (!isEmpty(result.selectedItem)) {
          this.set('searchPatientId', result.selectedItem.patientId);
        }
      },

      onCofigSelectionChanged(e) {
        const selectedItem = e.selectedItems[0];
        if (!isEmpty(selectedItem)) {
          this.set('model.workConfigSelectedItem', selectedItem);
        } else {
          this.set('model.workConfigSelectedItem', null);
        }
        this._getResultWorks();

      },
      onEncounterTypeCodeChanged() {
        this._getDepartmentSearch();
      },
      onDeapartmentSelectionChanged(e) {
        if (isEmpty(e.selectedItems)) {
          this._getResultWorks();
        }
      },
      onSearchPopupOnClick(e){
        this.set('findSettingPopupInfo.isOpen', !this.get('findSettingPopupInfo.isOpen'));
        this.set('findSettingPopupInfo.targetId', `#${e.originalEvent.currentTarget.id}`);
      },
      //팝업 콜백 이벤트
      onFindSettingCallBack(sResult){
        this.set('model.workConfigSelectedItem', null);
        this.set('examinationTagList', sResult.tagList);
        this._setConfigProperty(sResult);
      },
      onResultWorksSelectionChanged(e) {
        this.set('isRecordViewerOpen', false);
        this.set('isReportResultOpen', false);
        this.set('orderRemarkInputValue', null);
        this.set('observationsResultItemsSource', emberA());
        const selectedItem = e.selectedItems[0];
        this.set('isRecordDisabled', true);
        this.set('model.originId', null);
        if (!isEmpty(selectedItem)) {
          this.set('orderRemarkInputValue', selectedItem.orderComment);
          if(selectedItem.progressStatusCode === 'Final') {
            this.set('isRecordDisabled', false);
            this.set('model.originId', selectedItem.specimenId);
          }
        }
        this.set('remarkInputValue', null);
        this.set('isPrintDisabled', false);
        this._getObservationsResults();
      },
      onObservationsResultSelectionChanged(e) {
        this.set('model.searchRecordNoteId', null);
        this.set('isReportResultOpen', false);
        const selectedItem = e.selectedItems;
        if(!isEmpty(selectedItem) && !isEmpty(selectedItem[0].value) && !isEmpty(selectedItem[0].value.recordNoteId)) {
          this.set('model.searchRecordNoteId', selectedItem[0].value.recordNoteId);
          // this._getFileNotes();
        }
      },
      onExportExcel() {
        this._getExportExcel();
      },
    },

    onPatientChanged(Patient){
      this._super(...arguments);
      if(isEmpty(Patient)){
        return;
      }
      this.set('globalPatient', Patient);
      // this._getResultWorks();
      if(this.checkPatientDataClear() === true) {
        this.set('globalPatient', null);
        this._dataReset();
      } else {
        this.set('globalPatient', Patient);
        this._getResultWorks();
      }
    },

    async _init() {
      this.getBusinessCode();
      await this._getDatas();
    },

    async getBusinessCode() {
      try {
        const result = await this.get('cultureResultService').getBusinessCodesSearch({classificationCode: 'LaboratoryDefaultRepoter'});
        if(!isEmpty(result)) {
          this.set('reporterName', result[0].name);
        }
      } catch(e) {
        console.error(e);
      }
    },

    async _getEncounterList() {
      const encounterList = await this.get('cultureResultService').getBusinessCodesSearch({classificationCode: 'EncounterTypeCode'});
      this.set('model.selectedEncountTypeCode', encounterList[0].code);
      this.set('encounterList', encounterList);
    },

    async _getDepartmentSearch() {
      const departmentList = await this.get('cultureResultService').getDepartmentsSearch({encounterTypeCode: this.get('model.selectedEncountTypeCode')});
      this.set('departmentList', departmentList);
    },

    async _getDatas() {
      try{
        await this._getEncounterList();
        await this._getWorkCofigurations();
        this.set('isDisabled', false);
        await this._getResultWorks();
      } catch(e) {
        console.log('_init getDatas Error::::', e);
      }

    },

    async _getWorkCofigurations() {
      const param = {staffId: this.get('globalCurrentUser.employeeId')};
      const configResult = await this.get('cultureResultService').getSpecimenCheckInConfigurations(param);
      this.set('workConfigurationList', configResult);
      // this.set('model.workConfigSelectedValue', configResult[0].workListFindConfigurationId);
      // this.set('model.workConfigSelectedItem', configResult[0]);
    },

    async _getResultWorks() {
      this._dataReset();
      const globalPatient = this.get('globalPatient');
      if (isEmpty(globalPatient)) {
        return;
      }
      this.set('printPatientInfo', {
        'birthDay' : globalPatient.patientInformation.birthDay,
        'patientDisplayId' : globalPatient.patientDisplayId,
        'patientName' : globalPatient.patientName,
        'gender' : globalPatient.patientInformation.gender
      });
      this.set('isShowContentLoader', true);
      // this.set('isConditionDisabled', true);
      try {
        const params = this._getResultWorksParam();
        const resultWorks = await this.get('cultureResultService').getResultWorkListsSearch(params);
        if (!isEmpty(resultWorks)) {
          resultWorks.map(d => {
            if (!isEmpty(d.specimenOrders)) {
              d.orderInfo = d.specimenOrders[0];
              d.orderCommnets = this._getComments(d.specimenOrders, 'orderComment');
            }
          });
          this.set('worksResultItemsSource', resultWorks);
          this.set('model.resultWorksSelectedItem', resultWorks[0]);
        }
        this.set('isShowContentLoader', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowContentLoader', false);
          this._showError(e);
          console.log(e);
        }
      }

    },

    _getExportExcel() {
      const exportItemsWS = XLSX.utils.json_to_sheet(this.get('worksResultItemsSource'), {cellDates: true, dateNF: 'YYYY-MM-DD HH:mm:ss'});
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, exportItemsWS, 'sheet1');
      XLSX.writeFile(wb, 'export_sample.xlsx');
    },

    _dataReset() {
      this.set('orderRemarkInputValue', null);
      this.set('remarkInputValue', null);
      this.set('worksResultItemsSource', emberA());
      this.set('observationsResultItemsSource', emberA());
    },

    _getComments(lists, prop) {
      const comments = [];
      let splitCommnet = '';
      lists.forEach(datas => {
        if (!isEmpty(datas[prop])) {
          comments.push(datas[prop]);
        }
      });
      if (!isEmpty(comments)) {
        splitCommnet = comments.join(', ');
      }
      return splitCommnet;
    },

    _setConfigProperty(items) {
      const setObj = this._getTagProperties(items);
      this.set('tagCallbackItems', setObj);
      this.set('model.workConfigSelectedValue', items.workListFindConfigurationId);
      // this.set('model.workConfigSelectedItem', setObj);
      if (isEmpty(items.workListFindConfigurationId)) {
        this._getResultWorks();
      }
    },

    _getResultWorksParam() {
      let configProperties = this.get('model.workConfigSelectedItem.property');
      if (isEmpty(configProperties)) {
        configProperties = this.get('tagCallbackItems.property');
      }
      const {fromDate, toDate} = this._getSearchFromTo();
      const returnParam = {
        queryOption: '1',
        checkInFromDate: fromDate,
        checkInToDate: toDate,
        isStat: null,
        isToday: null,
        specimenNumber: null,
        subjectTypeCode: "Patient",
        // subjectNumber: this.get('searchPatientInfo.displayId'),
        subjectNumber: this.get('globalPatient.patientDisplayId'),
        checkInStartNumber: null,
        checkInEndNumber: null,
        encounterTypeCode: this.get('model.selectedEncountTypeCode'),
        tatSearchTypeCode: null,
        tatSearchTimeMinute: 0,
      };
      if (!isEmpty(this.get('departmentCombobox.selectedItems'))) {
        const departmentIds = this.get('departmentCombobox.selectedItems').map(d => d.id);
        returnParam.issuedDepartmentIds = departmentIds;
      }
      const typeByIds = (prop) => {
        const configs = configProperties[prop];
        if(!isEmpty(configs)) {
          const ids = configs
            .map(config => config.id);
          if(!isEmpty(ids)) {
            return ids;
          }
        }
      };
      if(!isEmpty(configProperties)){
        returnParam.classificationIds = typeByIds('classifications');
        returnParam.unitWorkIds = typeByIds('unitWorks');
        returnParam.examinationIds = typeByIds('observationExaminations');
      }
      return returnParam;
    },

    async _getObservationsResults() {
      try {
        this.set('isShowObservationsLoader', true);
        this.set('isPrintDisabled', true);
        const resultWorksItem = this.get('model.resultWorksSelectedItem');
        if (!isEmpty(resultWorksItem)) {
          const remarkResult = await this.get('cultureResultService').getObservationsResultRemarks(resultWorksItem, 'remark');
          if (!isEmpty(remarkResult)) {
            this.set('remarkInputValue', this._getComments(remarkResult, 'remark'));
          }
          // this.set('remarkInfo', remarkResult);
          const params = {
            checkInId: this.get('model.resultWorksSelectedItem.checkInId'),
            specimenNumber: this.get('model.resultWorksSelectedItem.specimenNumber'),
            proxyCallType: this.get('viewId')
          };
          const result = await this.get('cultureResultService').getObservationsResults(params);
          const fileUrl = this.get('fileUrl');
          let itemsSource = result;
          const verifiedItems = result.filter(d => d.isReport && d.isReportable);
          if(!isEmpty(result)) {
            if(!isEmpty(verifiedItems)) {
              const res = result.map(async d => {
                let pathResult = null;
                let writerInfo = null;
                if(!isEmpty(d.value) && !isEmpty(d.value.recordNoteId)) {
                  pathResult = await this._getFileNotes(d.value.recordNoteId);
                  writerInfo = await this._getRecordSummaryViews(d.value.recordNoteId);
                  if(isPresent(writerInfo) && isPresent(writerInfo.isWriterSignImage)) {
                    set(writerInfo, 'signImageUrl', `${fileUrl}/${writerInfo.imagePath}`);
                  }
                }
                d.filePaths = pathResult;
                d.writerInfo = writerInfo;
                return d;
              });
              const resolve = await Promise.all(res);
              itemsSource = resolve;
              this.set('isPrintDisabled', false);
            }
            this.set('observationsResultItemsSource', itemsSource);
            this.set('model.observationsResultSelectedItem', result[0]);
          }
        }
        this.set('isConditionDisabled', false);
        this.set('isShowObservationsLoader', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isConditionDisabled', false);
          this.set('isShowObservationsLoader', false);
          console.error('error@', e);
          this._showError(e);
        }

      }
    },
    async _getFileNotes(recordId) {
      try {
        const param = {
          recordNoteId: recordId
        };
        const result = await this.get('cultureResultService').getObservationsFileNotes(param);
        const pathList = [];
        const fileUrl = this.get('fileUrl');
        if(!isEmpty(result)) {
          result.contents.forEach(d => {
            pathList.push(`${fileUrl}/${d.filePath}`);
          });
        }
        return pathList;
      } catch(e) {
        console.error(e);
      }
    },

    async _getRecordSummaryViews(recordId) {
      try {
        const result = await this.getList(this.get('generalRecordUrl') + `record-notes/${recordId}/summary-views`);
        let returnResult = null;
        if(!isEmpty(result) && !isEmpty(result.footers)){
          returnResult = result.footers[0];
        }
        return returnResult;
      } catch(e) {
        console.log(e);
      }
    },
    _getSearchFromTo() {
      const fromDate = new Date(this.get('selectedFromDate').getFullYear(), this.get('selectedFromDate').getMonth(), this.get('selectedFromDate').getDate()).toFormatString();
      const toDate = new Date(this.get('selectedToDate').getFullYear(), this.get('selectedToDate').getMonth(), this.get('selectedToDate').getDate()).toFormatString();
      return {fromDate, toDate};
    },
  });
