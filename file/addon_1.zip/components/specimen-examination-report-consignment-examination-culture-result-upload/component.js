/* eslint-disable max-lines */
/* eslint-disable complexity */
/* eslint-disable no-undef */
/* eslint-disable require-unicode-regexp */
/* eslint-disable prefer-named-capture-group */
/* eslint-disable no-console */
// import { next } from '@ember/runloop';
import { computed, set } from '@ember/object';
import { isEmpty, isNone } from '@ember/utils';
// import { inject as service } from '@ember/service';
import { A as emberA } from '@ember/array';
import layout from './template';
import CHIS from 'framework/chis-framework';
import SpecimenExaminationReportMixin from '../../mixins/specimen-examination-report-mixin';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(
  SpecimenExaminationReportMixin,
  MessageMixin,
  {
    layout,
    consignmentGrid: null,
    cosignmentColumns: null,
    cosignmentItemsSource: null,
    agencyItemsSource: null,
    resultWorksInfoList: null,
    consignAgencyInfoList: null,
    consignmentList: null,
    specimenNumbers: null,
    completeDatas: null,
    isShowLoader: false,
    loaderDimed: false,
    contentLoaderType: 'spinner',
    isCulture: true,
    // consignmentService: service('specimen-examination-report-consignment-service'),
    // //첨부파일
    // uploadService: inject('upload-helper-service'),
    multipleCommonFilesInformation: computed('multipleCommonFiles', function () {
      const multipleCommonFilesInformation = emberA([]), frUtility = this.get('fr_Utility'), multipleFiles = this.get('multipleCommonFiles');

      if (!isNone(multipleFiles)) {
        for (let i = 0; i < multipleFiles.length; i++) {
          multipleCommonFilesInformation.pushObject({
            name: multipleFiles[i].name,
            size: frUtility.toFileSize(multipleFiles[i].size),
            type: multipleFiles[i].type,
          });
        }
      }
      return multipleCommonFilesInformation;
    }),

    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-consignment-examination-culture-result-upload');
      this.setStateProperties([
        'model',
        'isDisabled',
        'successCount'
      ]);
      if (this.hasState() === false) {
        this.set('model', {
          selectedAgencyId: null,
          selectCheckedList: null,
          selectedUploadType: null,
          selectedStatusCode: null,
          selectedAgencyItem: null,
          selectedUploadTypeItem: null,
        });
      }
      // this.set('specimenColumns', [
      //   { field: 'specimenNumber', title: this.getLanguageResource('tempkey', 'F', '', '검체번호'), width: '80'},
      //   // { field: 'patientName', title: this.getLanguageResource('tempkey', 'F', '', '환자명'), width: '70', align: 'center',},
      //   { field: 'subjectNumber', title: this.getLanguageResource('tempkey', 'F', '', '등록번호'), width: '70', align: 'center',},
      //   // { field: 'gender', title: this.getLanguageResource('tempkey', 'F', '', '성별'), width: '40', align: 'center',},
      //   // { field: 'age', title: this.getLanguageResource('tempkey', 'F', '', '나이'), width: '40', align: 'center',},
      //   { field: 'examinationCode', title: this.getLanguageResource('tempkey', 'F', '', '검사코드'), width: '80'},
      //   // { field: 'examinationName', title: this.getLanguageResource('tempkey', 'F', '', '검사명'), width: '100'},
      //   { field: 'resultContent', title: this.getLanguageResource('tempkey', 'F', '', '검사결과'), width: '100'},
      //   { field: 'unitCode', title: this.getLanguageResource('tempkey', 'F', '', '단위'), width: '80', align: 'center'},
      //   { field: 'referenceRangeContents', title: this.getLanguageResource('tempkey', 'F', '', '참고치'), width: '100'},
      //   { field: 'isDelta', title: this.getLanguageResource('tempkey', 'F', '', 'IsDelta'), width: '40', align: 'center',},
      //   { field: 'isPanic', title: this.getLanguageResource('tempkey', 'F', '', 'IsPanic'), width: '40', align: 'center',},
      //   { field: 'referenceCode', title: this.getLanguageResource('tempkey', 'F', '', 'H/'), width: '40', align: 'center',},
      //   { field: 'remark', title: this.getLanguageResource('tempkey', 'F', '', '비고'), width: '30', align: 'center', bodyTemplateName: 'remark'},
      //   { field: 'performedStaffName', title: this.getLanguageResource('tempkey', 'F', '', '검사자'), width: '70', align: 'center'},
      //   { field: 'confirmStaffName', title: this.getLanguageResource('tempkey', 'F', '', '확인자'), width: '90', align: 'center'},
      //   { field: 'statusCode', title: this.getLanguageResource('tempkey', 'F', '', '검사상태'), width: '90', align: 'center', hidden: !this.get('isCulture')},
      //   { field: 'process', title: this.getLanguageResource('7223', 'F', '', '처리'), width: '30', align: 'center'},
      // ]);
      this.set('pathologyColumns', [
        { field: 'orderDate', title: this.getLanguageResource('5246', 'F', '', '오더일'), width: '55', align: 'center'},
        { field: 'checkinDate', title: this.getLanguageResource('6776', 'F', '', '접수일'), width: '55', align: 'center',},
        { field: 'pathologyNumber', title: this.getLanguageResource('2796', 'F', '', '병리번호'), width: '80', align: 'center'},
        { field: 'patientName', title: this.getLanguageResource('16881', 'F', '', '환자명'), width: '50', align: 'center', bodyTemplateName: 'textTooltip'},
        { field: 'patientCode', title: this.getLanguageResource('8451', 'F', '', '등록번호'), width: '60', align: 'center',},
        { field: 'gender', title: this.getLanguageResource('3680', 'F', '', '성별'), width: '30', align: 'center',},
        { field: 'age', title: this.getLanguageResource('1662', 'F', '', '나이'), width: '30', align: 'center',},
        { field: 'specimenName', title: this.getLanguageResource('840', 'F', '', '검체'), align: 'center', width: '40', bodyTemplateName: 'textTooltip'},
        { field: 'displayCode', title: this.getLanguageResource('16919', 'F', '', '검사코드'), width: '60', align: 'center'},
        { field: 'examinationName', title: this.getLanguageResource('10011', 'F', '', '검사명'), width: '150', bodyTemplateName: 'textTooltip'},
        { field: 'pathologyResultValue', title: this.getLanguageResource('10518', 'F', '', '병리검사결과'), width: '160', bodyTemplateName: 'textTooltip'},
        { field: 'reportDate', title: this.getLanguageResource('2872', 'F', '', '보고일'), width: '55', align: 'center'},
        { field: 'performedStaffName', title: this.getLanguageResource('784', 'F', '', '검사자'), width: '90', align: 'center', bodyTemplateName: 'textTooltip'},
        { field: 'confirmStaffName', title: this.getLanguageResource('8387', 'F', '', '확인자'), width: '90', align: 'center', bodyTemplateName: 'textTooltip'},
        { field: 'process', title: this.getLanguageResource('7223', 'F', '', '처리'), width: '30', align: 'center', bodyTemplateName: 'processTooltip'},
        { field: 'failMessage', title: '', width: '30', align: 'center', hidden: true},
      ]);
      this.set('resultWorksInfoList', emberA());
      this.set('consignAgencyInfoList', emberA());
      this.set('specimenNumbers', emberA());
      this.set('uploadTypeItems', [
        {code: 'culture', name: this.getLanguageResource('2402', 'F', '', '미생물')},
        {code: 'pathology', name: this.getLanguageResource('2785', 'F', '', '병리')},
        {code: 'normal', name: this.getLanguageResource('16891', 'F', '', '일반')}
      ]);
      this.set('model.selectedUploadType', 'culture');
      this.set('statusItems', [
        {code: 'preliminary', name: 'preliminary'},
        {code: 'final', name: 'final'},
      ]);
    },

    onLoaded(){
      this._super(...arguments);
      // this.set('menuClass', 'w1180');
      this.set('menuClass', 'w1360');
      this._init();
    },

    actions: {
      onGridLoaded(e) {
        this.set('consignmentGrid', e.source);
      },
      //첨부파일 버튼
      onFileContentReset(filesPropertyName) {
        this.set(filesPropertyName, null);
        this.set('cosignmentItemsSource', emberA());
      },
      onAgencyChanged() {
        // this._getSearchConsignedAgency();
      },
      onCosignmentSelectChanged(e) {
        this.set('model.selectCheckedList', e.selectedItems);
      },
      onChangedFile() {
        this._getFileContent();
      },

      onConsignmentSave() {
        this._uploadedFileSave();
      },
      onUploadTypeChanged(e) {
        this.set('multipleCommonFiles', null);
        this.set('cosignmentItemsSource', emberA());
        this.set('model.selectedStatusCode', null);
        this.set('isCulture', false);
        this.set('model.selectedUploadTypeItem', e.item);
        if(e.item.code === 'culture') {
          this.set('isCulture', true);
        }
        this._setGridColumns();
      },
      onStatusChanged(e) {
        const checkedList = this.get('model.selectCheckedList');
        if (isEmpty(checkedList)){
          return;
        }
        checkedList.forEach(d => {
          set(d, 'statusCode', e.item.code);
        });
      },
      onComboboxClick(e) {
        if(isEmpty(e.source.selectedValue)) {
          const checkedList = this.get('model.selectCheckedList');
          if (isEmpty(checkedList)){
            return;
          }
          checkedList.forEach(d => {
            set(d, 'statusCode', null);
          });
        }
      },
    },

    _setGridColumns() {
      console.log('model.selectedUploadType--', this.get('model.selectedUploadType'));
      if(this.get('model.selectedUploadType') === 'pathology') {
        this.set('cosignmentColumns', this.get('pathologyColumns'));
      } else {
        const specimeColumns = [
          { field: 'specimenNumber', title: this.getLanguageResource('859', 'S', '', '검체번호'), width: '60', align: 'center'},
          // { field: 'patientName', title: this.getLanguageResource('tempkey', 'F', '', '환자명'), width: '70', align: 'center',},
          { field: 'subjectNumber', title: this.getLanguageResource('8451', 'S', '', '등록번호'), width: '60', align: 'center',},
          // { field: 'gender', title: this.getLanguageResource('tempkey', 'F', '', '성별'), width: '40', align: 'center',},
          // { field: 'age', title: this.getLanguageResource('tempkey', 'F', '', '나이'), width: '40', align: 'center',},
          { field: 'examinationCode', title: this.getLanguageResource('16919', 'S', '', '검사코드'), width: '60', align: 'center'},
          // { field: 'examinationName', title: this.getLanguageResource('tempkey', 'F', '', '검사명'), width: '100'},
          { field: 'resultContent', title: this.getLanguageResource('17110', 'S', '', '검사결과'), width: '120', bodyTemplateName: 'textTooltip'},
          { field: 'unitCode', title: this.getLanguageResource('1819', 'S', '', '단위'), width: '60', align: 'center'},
          { field: 'referenceRangeContents', title: this.getLanguageResource('10745', 'F', '', '참고치'), width: '100', bodyTemplateName: 'textTooltip'},
          { field: 'isDelta', title: this.getLanguageResource('17307', 'F', '', 'IsDelta'), width: '40', align: 'center',},
          { field: 'isPanic', title: this.getLanguageResource('17308', 'F', '', 'IsPanic'), width: '40', align: 'center',},
          { field: 'referenceCode', title: this.getLanguageResource('14749', 'F', '', '참고'), width: '40', align: 'center',},
          { field: 'remark', title: this.getLanguageResource('3173', 'S', '', '비고'), width: '30', align: 'center', bodyTemplateName: 'remark'},
          { field: 'performedStaffName', title: this.getLanguageResource('784', 'S', '', '검사자'), width: '80', align: 'center', bodyTemplateName: 'textTooltip'},
          { field: 'confirmStaffName', title: this.getLanguageResource('8387', 'S', '', '확인자'), width: '80', align: 'center', bodyTemplateName: 'textTooltip'},
          { field: 'statusCode', title: this.getLanguageResource('732', 'S', '', '검사상태'), width: '60', align: 'center', hidden: !this.get('isCulture')},
          { field: 'process', title: this.getLanguageResource('7223', 'S', '', '처리'), width: '30', align: 'center', bodyTemplateName: 'processTooltip'},
          { field: 'failMessage', title: '', width: '30', align: 'center', hidden: true},
        ];
        this.set('cosignmentColumns', specimeColumns);
      }
    },

    async _uploadedFileSave() {
      const selectedGridItems = this.get('consignmentGrid.selectedItems');
      const selectedUploadType = this.get('uploadTypeItems').find(item => item.code === this.get('model.selectedUploadType'));
      if(isEmpty(this.get('multipleCommonFiles'))) {
        this.showToastWarning(this.getLanguageResource('10585', 'F', null, '파일을 선택하세요.'), 2000);
        return;
      }
      if (isEmpty(selectedGridItems)){
        this.showToastWarning(this.getLanguageResource('9260', 'F', null, '항목을 선택하세요.'), 2000);
        return;
      }
      if(this.get('model.selectedUploadType') === 'culture' && isEmpty(this.get('model.selectedStatusCode'))) {
        return;
      }
      // const fileName = `${this.getLanguageResource('7934', 'F', null, '파일명')} : ${this.get('multipleCommonFiles')[0].name}`;
      const message = `<b>${this.getLanguageResource('9880', 'F', null, '위탁기관')} : ${this.get('model.selectedAgencyItem.name')}
      &nbsp; (${selectedUploadType.name} ${selectedGridItems.length} 건)</b>`;
      const result = await this.showConfirmMessage(this.getLanguageResource('8939', 'F', null, '저장하시겠습니까?'), message);
      if(result === 'Yes') {
        this._setSaveParameters();
      }
    },
    _getFileContent() {
      if(this.get('multipleCommonFiles')[0].type.indexOf('excel') < 0) {
        return;
      }
      this.set('contentLoaderType', 'spinner');
      this.set('loaderDimed', false);
      this.set('isShowLoader', true);
      this.set('cosignmentItemsSource', emberA());
      const fr = new FileReader();
      fr.readAsBinaryString(this.get('multipleCommonFiles')[0]);
      fr.onload = () => {
        const fileData = fr.result;
        const wb = XLSX.read(fileData, {type : 'binary'});
        wb.SheetNames.forEach(sheetName => {
          const rowObj = XLSX.utils.sheet_to_json(wb.Sheets[sheetName]);
          // console.log(JSON.stringify(rowObj));
          if(this.get('model.selectedUploadType') === 'pathology') {
            this._setPathologyItems(rowObj);
          } else {
            this._setSpecimenItems(rowObj);
          }
        });
      };
    },

    _setPathologyItems(list) {
      const tempArr = [];
      list.forEach(d => {
        const values = Object.values(d);
        let tempObj = {};
        values.forEach((val, index) => {
          const key = this._getPathologyObjectKey(index);
          let value = val;
          if(!isEmpty(key)) {
            if(key === 'reportDate' && val.indexOf('-') < 0) {
              const y = val.substr(0, 4);
              const m = val.substr(4, 2);
              const day = val.substr(6, 2);
              value = `${y}-${m}-${day}`;
            }
            const newObj = {[key]: value};
            tempObj = Object.assign(tempObj, newObj);
          }
        });
        tempArr.push(tempObj);
      });
      this.set('cosignmentItemsSource', tempArr);
      this.set('isShowLoader', false);
    },

    _setSpecimenItems(list) {
      const tempArr = [];
      list.forEach(d => {
        const values = Object.values(d);
        let tempObj = {};
        tempObj.statusCode = this.get('model.selectedStatusCode');
        values.forEach((val, index) => {
          const key = this._getSpecimenObjectKey(index);
          if(!isEmpty(key)) {
            const newObj = {[key]: val};
            tempObj = Object.assign(tempObj, newObj);
          }
        });
        tempArr.push(tempObj);
      });
      this.set('cosignmentItemsSource', tempArr);
      this.set('isShowLoader', false);
    },
    _getSpecimenObjectKey(index) {
      let propName = '';
      switch(index) {
        case 0:
          propName = 'orderDate';
          break;
        case 1:
          propName = 'checkinDate';
          break;
        case 2:
          propName = 'specimenNumber';
          break;
        case 3:
          propName = 'subjectNumber';
          break;
        case 4:
          propName = 'patientName';
          break;
        case 5:
          propName = 'gender';
          break;
        case 6:
          propName = 'age';
          break;
        case 7:
          propName = 'specimenName';
          break;
        case 8:
          //항목코드(검사코드)
          propName = 'examinationCode';
          break;
        case 9:
          propName = 'examinationName';
          break;
        case 10:
          propName = 'remark';
          break;
        case 11:
          if(this.get('model.selectedUploadType') === 'normal') {
            propName = 'resultContent';
          }
          break;
        case 12:
          if(this.get('model.selectedUploadType') === 'culture') {
            propName = 'resultContent';
          }
          break;
        case 13:
          propName = 'unitCode';
          break;
        case 14:
          propName = 'referenceRangeContents';
          break;
        case 15:
          propName = 'reportDate';
          break;
        case 16:
          propName = 'isDelta';
          break;
        case 17:
          propName = 'isPanic';
          break;
        case 18:
          propName = 'referenceCode';
          break;
        case 19:
          propName = 'performedStaffName';
          break;
        case 20:
          propName = 'confirmStaffName';
          break;
        default:
          break;
      }
      return propName;
    },

    _getPathologyObjectKey(index) {
      let propName = '';
      switch(index) {
        case 0:
          propName = 'orderDate';
          break;
        case 1:
          propName = 'checkinDate';
          break;
        case 2:
          propName = 'pathologyNumber';
          break;
        case 3:
          propName = 'patientCode';
          break;
        case 4:
          propName = 'patientName';
          break;
        case 5:
          propName = 'gender';
          break;
        case 6:
          propName = 'age';
          break;
        case 7:
          propName = 'specimenName';
          break;
        case 8:
          //항목코드(검사코드)
          propName = 'displayCode';
          break;
        case 9:
          propName = 'examinationName';
          break;
        case 12:
          propName = 'pathologyResultValue';
          break;
        case 15:
          propName = 'reportDate';
          break;
        case 16:
          propName = 'performedStaffName';
          break;
        case 17:
          propName = 'confirmStaffName';
          break;
        default:
          break;
      }
      return propName;
    },

    async _init() {
      this._setGridColumns();
      this.set('agencyItemsSource', emberA());
      const agencyList = await this.get('consignmentService').getConsignedAgency();
      if(!isEmpty(agencyList)) {
        this.set('agencyItemsSource', agencyList);
        this.set('model.selectedAgencyId', agencyList[0].code);
      }
    },

    async _getSearchConsignedAgency() {
      try {
        const param = {consignedAgencyCode: this.get('model.selectedAgencyId')};
        const result = await this.get('consignmentService').getSearchConsignedAgency(param);
        this.set('consignAgencyInfoList', result);
      } catch(e) {
        console.error(e);
      }
    },

    async _setSaveParameters() {
      try {
        const checkedList = this.get('model.selectCheckedList');
        if (isEmpty(checkedList)){
          this.showToastWarning(this.getLanguageResource('9260', 'F', null, '항목을 선택하세요.'), 2000);
          return;
        }
        // const gridItemsSource = this.get('cosignmentItemsSource');
        // gridItemsSource.forEach(item => {
        //   set(item, 'process', null);
        //   set(item, 'failMessage', null);
        // });
        checkedList.forEach(item => {
          set(item, 'process', null);
          set(item, 'failMessage', null);
        });
        this.set('contentLoaderType', 'progress');
        this.set('loaderDimed', true);
        this.set('isShowLoader', true);
        const now = new Date(this.get('co_CommonService').getNow());
        const uploadType = this.get('model.selectedUploadType');
        await Promise.all(
          checkedList.map(async d => {
            const params = this._setItemsParameters(d, uploadType, now);
            await this._saveConsignment(params, d);
          })
        );
        this.set('isShowLoader', false);
        this.showToast('save', this.getLanguageResource('10841', 'F', null, '완료되었습니다.'), '');
      } catch(e) {
        console.error(e);
      }
    },

    _bodyCellRender() {
      return (context) => {
        const cellItem = context.item;
        console.log('-cellItem--', cellItem);
        if (!isEmpty(cellItem.failMessage)){
          set(context.cellComponent, 'description', cellItem.failMessage);
        }
      };
    },

    _setItemsParameters(d, type, now) {
      let params = {};
      if(type === 'pathology') {
        params = {
          consignedAgencyCode: this.get('model.selectedAgencyId'),
          pathologyNumber: d.pathologyNumber,
          registrationDatetime: now,
          registrationStaffId: this.get('globalCurrentUser.employeeId'),
          pathologyResultValue: d.pathologyResultValue,
          reportDate: d.reportDate,
          confirmStaffName: d.confirmStaffName
        };
      } else {
        params = {
          specimenNumber: d.specimenNumber,
          subjectNumber: d.subjectNumber,
          examinationCode: d.examinationCode,
          resultContent: d.resultContent,
          isDelta: d.isDelta,
          isPanic: d.isPanic,
          unitCode: d.unitCode,
          referenceCode: d.referenceCode,
          referenceRangeContents: d.referenceRangeContents,
          performedStaffName: d.performedStaffName,
          confirmStaffName: d.confirmStaffName,
          statusCode: d.statusCode,
        };
      }
      return params;
    },

    async _saveConsignment(params, item) {
      const gridComponent = this.get('consignmentGrid');
      const targetIndex = gridComponent.getItemIndex(item);
      const gridItemsSource = this.get('cosignmentItemsSource');
      // const gridItemsSource = $.extend(true, [], this.get('cosignmentItemsSource'));
      try {
        let promise = null;
        if(this.get('model.selectedUploadType') === 'pathology') {
          promise = this.get('consignmentService').createPathologyConsignments(params);
        } else {
          promise = this.get('consignmentService').createObservationsConsignments(params);
        }
        await promise;
        set(gridItemsSource[targetIndex], 'process', this.getLanguageResource('3670', 'F', null, '성공'));
        set(gridItemsSource[targetIndex], 'failMessage', null);
        // this.set('cosignmentItemsSource', gridItemsSource);
      } catch(e) {
        if(e.status === 400 && !isEmpty(e.responseJSON)) {
          set(gridItemsSource[targetIndex], 'failMessage', e.responseJSON.messages[0]);
        } else if(e.status === 500) {
          set(gridItemsSource[targetIndex], 'failMessage', this.getLanguageResource('10867', 'F', '', 'api에러'));
        }
        set(gridItemsSource[targetIndex], 'process', this.getLanguageResource('4585', 'F', null, '실패'));
        // this.set('cosignmentItemsSource', gridItemsSource);
        console.log('_saveConsignment Error::::', e);
      }
    }

  });