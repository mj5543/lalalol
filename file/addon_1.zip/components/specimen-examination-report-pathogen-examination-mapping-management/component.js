/* eslint-disable prefer-named-capture-group */
/* eslint-disable no-console */
// import $ from 'jquery';
import { isEmpty } from '@ember/utils';
import { A as emberA } from '@ember/array';
import { set } from '@ember/object';
import layout from './template';
import CHIS from 'framework/chis-framework';
import InfectionMixin from '../../mixins/specimen-examination-report-infection-mixin';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';
import PrintMixin from 'specimenexaminationreport-module/mixins/specimen-examination-report-print-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  InfectionMixin,
  MessageMixin,
  PrintMixin,
  {
    layout,
    isShowLoader: false,
    loaderType: null,
    isFirstLoading: true,
    isIdentificationOpen: false,
    identificationTarget: null,
    isSusceptibilityOpen: false,
    susceptibilityTarget: null,
    isEditingSusceptibilityItems: false,
    isResultAreaDisabled: true,
    isSusceptibilityDesabled: true,
    isEditingResultGridItems: false,
    isShowMappingsLoader: false,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-pathogen-examination-mapping-management');

      this.setStateProperties([
        'gridColumns',
        'gridItems',
        'classificationList'
      ]);
      if (!this.hasState()) {
        this.set('model', {
          gridSelectedItem: null,
          selectedClassificationId: null,
          organization: {
            number: null,
            name: null
          },
          selectedExaminationtItem: null,
          selectedResultGridItem: null,
          selectedResultMappingItem: null,

        });
        this.set('examinationColumns', [
          { field: 'displayCode', title: this.getLanguageResource('16919', 'F', '', '검사코드'), width: 60, align: 'center',},
          { field: 'name', title: this.getLanguageResource('10011', 'F', '', '검사명'), width: 170, bodyTemplateName: 'tooltip'},

        ]);
        this.set('resultGridColumns', [
          { field: 'methodCode', title: this.getLanguageResource('13267', 'F', '', '검사방법코드'), width: 90, align: 'center', enableGotFocusAutoSelect: true},
          { field: 'pathogenCode_1', title: this.getLanguageResource('13268', 'F', '', '병원체코드'), width: 80, align:'center', enableGotFocusAutoSelect: true},
          { field: 'pathogenCode_2', title: this.getLanguageResource('13269', 'F', '', '법정병원체코드'), width: 100, align: 'center', enableGotFocusAutoSelect: true},
          { field: 'resultType', title: this.getLanguageResource('13270', 'F', '', '결과타입'), width: 80, align: 'center', bodyTemplateName: 'resultType'},
          { field: 'specimenKindType', title:  this.getLanguageResource('13271', 'S','', '검체종류코드'), width: 80, bodyTemplateName: 'specimenKind'},
          { field: 'suscelptibilityCheck', title: this.getLanguageResource('13272', 'F', '', '감수성체크'), width: 70, align: 'center', bodyTemplateName:'textYN'},
          { field: 'isUse', title: this.getLanguageResource('3287', 'F', '', '사용'), width: 50, align: 'center', bodyTemplateName: 'textUseYN'},
        ]);
        this.set('resultMappingColumns', [
          { field: 'name', title: this.getLanguageResource('7684', 'F', '', '이름'), width: '240', bodyTemplateName: 'titleTooltip'},
          { field: 'isUse', title: this.getLanguageResource('3287', 'F', '', '사용'), width: '60', align: 'center', bodyTemplateName: 'textUseYN'},

        ]);
        this.set('specimenMappingColumns', [
          { field: 'code', title: this.getLanguageResource('10372', 'F', '', '코드'), width: 80, align: 'center',},
          { field: 'name', title: this.getLanguageResource('7684', 'F', '', '이름'), width: 160, bodyTemplateName: 'titleTooltip'},
          { field: 'isUse', title: this.getLanguageResource('3287', 'F', '', '사용'), width: 60, align: 'center', bodyTemplateName: 'textUseYN'},
        ]);
        this.set('susceptibilityMappingColumns', [
          { field: 'code', title: this.getLanguageResource('10372', 'F', '', '코드'), width: '80', align: 'center',},
          { field: 'name', title: this.getLanguageResource('7684', 'F', '', '이름'), width: '160', bodyTemplateName: 'titleTooltip'},
          { field: 'isUse', title: this.getLanguageResource('3287', 'F', '', '사용'), width: '60', align: 'center', bodyTemplateName: 'textUseYN'},
        ]);
        this.set('classificationList', emberA());
        this.set('resultGridItems', emberA());
        this.set('specimenKindTypeItems', emberA());
        this._resetMappingGrids();
      }

    },
    onLoaded() {
      this._super(...arguments);

      this.set('menuClass', 'w1180');
      this._init();
    },
    actions: {
      // onSearchAction() {
      //   this.getDataList();
      // },
      onClassificationChanged(e) {
        if(!isEmpty(e.item)) {
          this.set('model.selectedClassificationId', e.item.id);
          // this.getGridItemList(e.item.value);
          this._getExaminationGridItems();
        }
      },
      onResultGridLoaded(e) {
        this.set('resultGrid', e.source);
      },
      onGridSelectionChanged() {
        // if(isEmpty(e.selectedItems)) {
        //   return;
        // }
        this._getResultGridItems();
      },
      onResultSelectionChanged(e) {
        this.set('isResultAreaDisabled', true);
        this.set('isSusceptibilityDesabled', true);
        this._resetMappingGrids();
        if(!isEmpty(e.selectedItems) && !isEmpty(e.selectedItems[0].displayCode)) {
          this._getValueList();
          const item = e.selectedItems[0];
          if(item.suscelptibilityCheck) {
            this.set('isSusceptibilityDesabled', false);
          }
          if(isEmpty(item.displayCode)) {
            this.set('isResultAreaDisabled', false);
          }
        }

      },
      onResultGridCellClick(e) {
        console.log('onResultGridCellClick--', e);
        const field = e.column.field;
        if(field === 'suscelptibilityCheck') {
          set(e.item, field, !e.item[field]);
          this.set('isSusceptibilityDesabled', !e.item[field]);
        } else if(field === 'isUse') {
          set(e.item, field, !e.item[field]);
        }
      },
      onMappingGridCellClick(e) {
        console.log('onMappingGridCellClick--', e);
        const field = e.column.field;
        if(field === 'isUse') {
          set(e.item, field, !e.item[field]);
        }
      },
      onResultGridAddRow() {
        this._addResultGridRow();
      },
      onResultGridDeleteRow() {
        // const selectedItem = this.get('model.selectedResultGridItem');
        // this.get('resultGridItems').removeObject(selectedItem);
        this._setRemoveResultGridItems();

      },
      onSearchIdentification(e) {
        this.set('identificationTarget', e.originalEvent.currentTarget);
        this.set('isIdentificationOpen', true);
      },
      onDeleteResultMappingRow() {
        const selectedItem = this.get('model.selectedResultMappingItem');
        this.get('resultMappingItems').removeObject(selectedItem);
      },
      //감수성결과코드조회
      onSearchSusceptibility(e) {
        if (isEmpty(this.get('model.selectedResultGridItem.categoryCode'))) {
          this.showWarningMessage(this.getLanguageResource('9231', 'F', '', '결과가 저장되지 않았습니다.'), 2000);
          return;
        }
        this.set('isSusceptibilityOpen', true);
        this.set('susceptibilityTarget', e.originalEvent.currentTarget);
      },
      onReturnIdentification(returnItems) {
        console.log('onReturnIdentification', returnItems);
        if (!isEmpty(returnItems)) {
          this._addIdentificationRow(returnItems);
          // this.set('model.identificationSelectedItem.codeableConceptCoding.code', returnItems.displayCode);
          // this.set('model.identificationSelectedItem.codeableConceptCoding.displayName', returnItems.name);
          // this.set('isIdentificationOpen', false);
          // this.set('isEditingIdentificationItems', true);
        }
      },
      onReturnSusceptibility(returnItem) {
        console.log('returnItem----', returnItem);
        // const valueTypeCode = this.get('model.identificationSelectedItem').get('valueTypeCode');
        // const valueTypeCode = "CodeableConcept";
        let antibiotics = null;
        if (Array.isArray(returnItem.antibiotics)) {
          antibiotics = returnItem.antibiotics;
        } else {
          antibiotics = [returnItem.antibiotics];
        }
        this._susceptibilitysItemsSetting(antibiotics, returnItem.id);
        this.set('isSusceptibilityOpen', false);
      },
    },
    _init() {
      this._getPathogenOrganization();
      this._getPathogenClassification();
    },
    async _getPathogenOrganization() {
      try {
        const result = await this.get('apiService').getPathogenMappingOrganization();
        this.set('model.organization.number', result.organizationNumber);
        this.set('model.organization.name', result.organizationName);
      } catch(e) {
        console.log('_getPathogenClassification', e);
      }
    },
    async _getPathogenClassification() {
      try {
        const result = await this.get('apiService').getPathogenClassification();
        const comboboxItems = [
          {name: this.getLanguageResource('6700', 'F', '', '전체'), id: 'All'},
          ...result
        ];
        this.set('classificationItems', comboboxItems);
        this.set('model.selectedClassificationId', 'All');
        this._getExaminationGridItems();
      } catch(e) {
        console.log('_getPathogenClassification', e);
      }
    },
    async _getExaminationGridItems() {
      try {
        this.set('examinationGridItems', emberA());
        this.set('isShowLoader', true);
        const classificationId = this.get('model.selectedClassificationId');
        const params = {
          classificationId: classificationId === 'All' ? null : classificationId
        };
        const result = await this.get('apiService').getPathogenMappingExaminationList(params);
        if (!isEmpty(result)) {
          this.set('examinationGridItems', result);
        }
        this.set('isShowLoader', false);
      } catch(e) {
        this._showError(e);
        this.set('isShowLoader', false);
        console.log('_getExaminationGridItems Error :::::', e);
      }

    },
    async _getResultGridItems() {
      try {
        this.set('resultGridItems', emberA());
        if(isEmpty(this.get('model.selectedExaminationtItem'))) {
          return;
        }
        this.set('loaderType', 'spinner');
        this.set('isShowLoader', true);
        const params = {
          examinationId: this.get('model.selectedExaminationtItem.id'),
          categoryCode: null,
        };
        const result = await this.get('apiService').getPathogenMappingResultList(params);
        if (!isEmpty(result)) {
          result.map(d => {
            d.resultTypeDisabled = true;
          });
          this.set('resultGridItems', result);
        }
        this.set('isShowLoader', false);
      } catch(e) {
        this._showError(e);
        this.set('isShowLoader', false);
        console.log('_getResultGridItems Error :::::', e);
      }

    },
    async _getValueList() {
      try {
        this.set('isShowMappingsLoader', true);
        this.set('loaderType', 'spinner');
        const params = {
          examinationCode: this.get('model.selectedResultGridItem.examinationId'),
          categoryCode: this.get('model.selectedResultGridItem.categoryCode'),
        };
        const mappings = await this.get('apiService').getPathogenMappingValueList(params);
        if (!isEmpty(mappings)) {
          this.set('resultMappingItems', mappings.resultMappingValue);
          this.set('specimenMappingItems', mappings.specimenMappingValue);
          this.set('susceptibilityMappingItems', mappings.susceptibilityMappingValue);
        }
        this.set('isShowMappingsLoader', false);
      } catch(e) {
        this._showError(e);
        this.set('isShowMappingsLoader', false);
        console.log('_getResultGridItems Error :::::', e);
      }

    },
    _resetMappingGrids() {
      this.set('resultMappingItems', emberA());
      this.set('specimenMappingItems', emberA());
      this.set('susceptibilityMappingItems', emberA());
    },
    _addResultGridRow() {
      const tempObj = {
        categoryCode: null,
        examinationId: this.get('model.selectedExaminationtItem.id'),
        methodCode: null,
        'pathogenCode_1': null,
        'pathogenCode_2': null,
        resultType: null,
        specimenKindType: null,
        suscelptibilityCheck: true,
        isUse: true,
        resultTypeDisabled: false,
      };
      this.get('resultGridItems').addObject(tempObj);
      this.set('isEditingResultGridItems', true);
      this.get('resultGrid').deselectAll();
      this.get('resultGrid').selectRow(tempObj);
    },
    _addIdentificationRow(item) {
      if(!isEmpty(this.get('resultMappingItems'))) {
        const findName = this.get('resultMappingItems').findBy('name', item.name);
        console.log('findName--', findName);
      }
      const tempObj = {
        mappingCode: this.get('model.selectedResultGridItem.resultType'),
        name: item.name,
        isUse: true,
      };
      this.get('resultMappingItems').addObject(tempObj);
      this.set('isIdentificationOpen', false);
    },
    _susceptibilitysItemsSetting(antibiotics){
      antibiotics.forEach(item => {
        const susceptibilityMappingItems = this.get('susceptibilityMappingItems');
        let findedSameObj = null;
        const hasExaminationId = !isEmpty(item.examination);
        if (!isEmpty(susceptibilityMappingItems) && hasExaminationId) {
          findedSameObj = susceptibilityMappingItems.find(d => d.id === item.examination.id);
        }
        if (isEmpty(findedSameObj) && hasExaminationId) {
          let tempObj = {};
          tempObj = item.examination;
          tempObj.code = item.examination.displayCode;
          tempObj.mappingCode = 'Susceptibility';
          tempObj.isUse = true;
          this.get('susceptibilityMappingItems').addObject(tempObj);
          this.set('isSusceptibilityOpen', false);
          this.set('isEditingSusceptibilityItems', true);
        }
      });
    },
    _setRemoveResultGridItems() {
      // const removeList = this.get('identificationRemoveIds');
      const selectedItem = this.get('model.selectedResultGridItem');
      // if (!isEmpty(selectedItem.observationId)) {
      //   removeList.push(selectedItem.observationId);
      // }
      this.get('resultGridItems').removeObject(selectedItem);
      this.get('resultGrid').selectRow(this.get('resultGridItems.lastObject'));
      this.set('isEditingResultGridItems', true);
    },
  });