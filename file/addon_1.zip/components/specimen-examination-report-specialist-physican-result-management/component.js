/* eslint-disable max-lines */
/* eslint-disable max-lines-per-function */
/* eslint-disable prefer-named-capture-group */
/* eslint-disable no-console */
import { isEmpty } from '@ember/utils';
import { set } from '@ember/object';
import { A as emberA } from '@ember/array';
import { next } from '@ember/runloop';
import layout from './template';
import CHIS from 'framework/chis-framework';
import SpecimenExaminationReportMixin from '../../mixins/specimen-examination-report-mixin';
import specimenExaminationREportPrintMixin from 'specimenexaminationreport-module/mixins/specimen-examination-report-print-mixin';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';
import KmiSgin from 'co-security/mixins/kmi-sign-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  SpecimenExaminationReportMixin,
  specimenExaminationREportPrintMixin,
  MessageMixin,
  KmiSgin,
  {
    layout,
    selectedTabName: null,
    isDisabled: true,
    isShowContainerLoader: false,
    workConfigurationList: null,
    remarkInfo: null,
    isShowContentLoader: false,
    departmentCombobox: null,
    isReportResultOpen: false,
    isShowObservationsLoader: false,
    tagCallbackItems: null,
    entryPopupTarget: null,
    isPhysicianEntryPopupOnpen: false,
    isSaveDisabled: true,
    isModifyDisabled: true,
    signId: null,
    loaderType: null,
    loaderDimed: false,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId', 'specimen-examination-report-specialist-physican-result-management');
      this.setStateProperties([
        'model',
        'gridSource',
        'selectedFromDate',
        'selectedToDate',
        'isDisabled',
        'gridItemsSource',
        'gridColumns',
        'workConfigurationList',
        'examinationCategoryTagItems',
        'examinationUnitTagItems',
        'examinationTagItems',
        'examinationTagList',
        'workListSearchCodeItems',
        'workSearchCodeItems',
        'specialistPhysicianItems',
        'specialistPhysicianOpinionItems',
        'deleteItems'
      ]);

      if (!this.hasState()) {
        this.set('isDisabled', false);
        this.set('model', {
          selectedEncountTypeCode: null,
          workConfigSelectedItem: null,
          workConfigSelectedValue: null,
          departmentSelectedItems: null,
          selectedGridItem: null,
          observationsResultSelectedItem: null,
          selectedWorkListSearchCode: null,
          selectedPhysicianValue: null,
          selectedPhysicianOpinionValue: null,
          selectedWorkSearchCode: null,
        });
        const displayDate = new Date(this.get('co_CommonService').getNow());
        this.set('selectedFromDate', displayDate);
        this.set('selectedToDate', displayDate);
        this.set('findSettingPopupInfo', {});
        this.set('findSettingPopupInfo.isOpen', false);
      }
      this.set('gridItemsSource', []);
      this.set('workConfigurationList', []);
      this.set('gridColumns', [
        { field: 'checkInDate', title: this.getLanguageResource('6777', 'F', '', '접수일'), width: 90, align: 'center', type: 'date', dataFormat: 'd',},
        { field: 'issuedDatetime', title: this.getLanguageResource('7954', 'F', '', '판독일'), width: 90, align: 'center', type: 'date', dataFormat: 'd',},
        { field: 'checkInNumber', title: this.getLanguageResource('6767', 'S', '', '접수번호'), width: 80, align: 'center'},
        { field: 'subject.name', title: this.getLanguageResource('16881', 'F', '', '환자명'), width: 110, align: 'center', bodyTemplateName: 'boldText'},
        { field: 'subject.displayNumber', title: this.getLanguageResource('8451', 'S', null, '등록번호'), width: 70, align: 'center', bodyTemplateName: 'boldText'},
        { field: 'subject.gender', title: this.getLanguageResource('3680', 'F', null, '성별'), width: 35, align: 'center'},
        { field: 'subject.age', title: this.getLanguageResource('1662', 'F', null, '나이'), width: 35, align: 'center'},
        { field: 'examination.name', title: this.getLanguageResource('16920', 'S','검사항목'), headerTemplateName: 'tooltip',bodyTemplateName: 'tooltip', width: 130, readOnly: true},
        { title: this.getLanguageResource('890', 'F','결과'), field: 'displayResult', headerTemplateName: 'tooltip', bodyTemplateName: 'resultEntry', width: 90},
        { title: this.getLanguageResource('7387', 'F','Recent Result'), field: 'recentObservationResult.displayResult', bodyTemplateName: 'recentResultComments', width: 90, readOnly: true},
        { title: 'D', field: 'check.isDelta',align: 'center', bodyTemplateName:'delta', width: 40, readOnly: true},
        { title: 'P', field: 'check.isPanic',align: 'center', bodyTemplateName:'panic', width: 40, readOnly: true},
        { title: 'C', field: 'check.isCritical',align: 'center', bodyTemplateName:'critical', width: 40, readOnly: true},
        { field: 'specimenNumber', title: this.getLanguageResource('859', 'S', '', '검체번호'), align: 'center', width: 90 },
        { title: this.getLanguageResource('906', 'S','결과비고'), field: 'remark', headerTemplateName: 'tooltip',bodyTemplateName: 'resultComments', width: 90, align: 'center'},
        { field: 'opinionContent', title: this.getLanguageResource('13280', 'F', '', '판독 및 검증'), width:100, bodyTemplateName: 'opinionContentText', align: 'center'},
      ]);

      this.set('workListSearchCodeItems', emberA());
      this.set('specialistPhysicianItems', emberA());
      this.set('specialistPhysicianOpinionItems', emberA());
      this.set('deleteItems', emberA());
      this.set('workSearchCodeItems', [
        {code: '3', name: this.getLanguageResource('2457', 'F', '', '미완료')},
        {code: '4', name: this.getLanguageResource('9699', 'F', '', '완료')},
      ]);
    },

    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1360');
      this._init();
    },
    actions: {
      onGridLoaded(e) {
        this.set('gridSource', e.source);
      },
      onDeleteButtonClick() {
        this._setDeleteItems();
      },
      onEntryButtonClick(e) {
        this.set('entryPopupTarget', `#${e.source.elementId}`);
        this.set('isPhysicianEntryPopupOnpen', true);
      },
      onGridSelectionChanged(e) {
        const selectedItem = e.selectedItems;
        if (!isEmpty(selectedItem)) {
          this.set('isModifyDisabled', false);
        } else {
          this.set('isModifyDisabled', true);
        }
      },
      onPopupOpenedAction() {
        //
      },
      onPopupClosedAction() {
        this.set('model.selectedPhysicianValue', null);
        this.set('model.selectedPhysicianOpinionValue', null);
      },
      onQueryOptionCodeChanged(e) {
        const selectedItem = e.selectedItems[0];
        let content = this.getLanguageResource('6700', 'F', '', '전체');
        if (!isEmpty(selectedItem)) {
          content = selectedItem.name;
        }
        this._getSpeciallistPhysicans(true, content);
      },
      onSearchClick() {
        this._getSpeciallistPhysicans(true, '');
      },
      onFromToUpdated(e) {
        const fromDate = this.get('fr_I18nService').formatDate(e.selectedFromDate, 'd');
        const toDate = this.get('fr_I18nService').formatDate(e.selectedToDate, 'd');
        this._getSpeciallistPhysicans(true, `${fromDate} ~ ${toDate}`);
      },
      onSaveClick() {
        if(isEmpty(this.get('gridSource').selectedItems)) {
          this.showToastWarning(this.getLanguageResource('9260', 'F', null, '항목을 선택하세요.'), 2000);
          return;
        }
        // this._saveSpeciallistPhysicans();
        this.set('isShowContentLoader', true);
        this.saveSignData(this.get('viewId'));
      },
      onPopupConfirm() {
        this._setGridItemsOpinionContent();
      },
      onResultDetailClick() {
        this.set('isReportResultOpen', true);
      },

      onWorkConfigSelectionChanged(e) {
        const selectedItem = e.selectedItems[0];
        if (!isEmpty(selectedItem)) {
          this.set('model.workConfigSelectedItem', selectedItem);
          this._getSpeciallistPhysicans(true, selectedItem.displayName);
        } else {
          this.set('model.workConfigSelectedItem', null);
        }

      },
      onSearchPopupOnClick(e){
        this.set('findSettingPopupInfo.isOpen', !this.get('findSettingPopupInfo.isOpen'));
        this.set('findSettingPopupInfo.targetId', `#${e.originalEvent.currentTarget.id}`);
      },
      //팝업 콜백 이벤트
      onFindSettingCallBack(sResult){
        this.set('model.workConfigSelectedItem', null);
        this.set('examinationTagList', sResult.tagList);
        this._setConfigProperty(sResult);
      },
      onResultWorksSelectionChanged(e) {
        const selectedItem = e.selectedItems[0];
        if (!isEmpty(selectedItem)) {
          //TODO: some
        }
      },
      onObservationsResultSelectionChanged() {
        //
      },
      onExportExcel() {
        this._getExportExcel();
      },
    },
    onCertificateSignSucess(signData){
      console.log('signData---', signData);
      this.set('signId', signData.signKey);
      //전자서명 성공 call back function
      this.get('kmiService').kmiAliveHealthChecker().then(function(){
        this._saveSignData(signData, this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'kmiServiceUrl') + 'sign/v1/signs');
      }.bind(this), function(){
        this._saveSignData(signData, this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'aliveHealthChecker') + 'sign/v1/signs');
      }.bind(this));
    },

    // 5. Private methods Area
    async _saveSignData(signdata, url){
      const certificateUrl = url;
      // const signKey = v4();
      const selectedValue = this.get('model.selectedGridItem');
      const currentUser= this.get('co_CurrentUserService.user');
      const dataToSend = [{
        "signerEmail": currentUser.email,
        "tenantId": currentUser.get('tenant.tenantId'),
        "hospitalId": currentUser.get('hospital.hospitalId'),
        // "signKey": selectedValue.observationId,
        "signDocument": signdata,
        "patientId": selectedValue.subjectId,
        "patientDisplayId": selectedValue.subjectTypeCode,
        "encounterId": selectedValue.encounterId,
        // "signerStaffId": currentUser.employeeId,
        "signerId": currentUser.employeeId,
        "signerDisplayId": currentUser.employeeDisplayId,
        "signerName": currentUser.employeeName,
        "signedDate": new Date(),
        "ipAddress": this.get('fr_GlobalSystemService.localIPAddress'),
        "domain": 'specimenexaminationreport',
        "serviceCode": 'specimenexaminationreport/save-sign-data',
        // "aggregateId": this.get('recordNoteId')
      }];
      const result = await this.getItem(certificateUrl, null, dataToSend, false);
      console.log('result---', result);
      if(!isEmpty(result)){
        if(result.signSaveResult === 'Y'){
          this._saveSpeciallistPhysicans();
        } else {
          this.set('isShowContentLoader', false);
        }
      } else {
        this.set('isShowContentLoader', false);
      }
    },

    _getExportExcel() {
      const gridItemsSource = this.get('gridItemsSource');
      const firstRow = [];
      const colInfo = [];
      const columns = this.get('gridColumns');
      columns.forEach(column => {
        firstRow.push(column.title);
        colInfo.push({wpx: column.width-30});
      });
      const initArr = [firstRow];
      const resultArr = [];
      gridItemsSource.forEach(datas => {
        const recentResult = isEmpty(datas.recentObservationResult) ? '' : datas.recentObservationResult.displayResult;
        resultArr.push([
          datas.checkInDate,
          datas.issuedDatetime,
          datas.checkInNumber,
          datas.subject.name,
          datas.subject.displayNumber,
          datas.subject.gender,
          datas.subject.age,
          datas.examination.name,
          datas.displayResult,
          recentResult,
          datas.check.isDelta,
          datas.check.isPanic,
          datas.check.isCritical,
          datas.specimenNumber,
          datas.remark,
          datas.opinionContent,
        ]);
      });
      this.getExportByArrayTypeExcel(initArr, resultArr);
    },

    _dataReset() {
      this.set('signId', null);
      this.set('deleteItems', emberA());
      this.set('gridItemsSource',emberA());
    },

    async _init() {
      await this.getBusinessCodeList();
      await this._getDatas();
    },

    async getBusinessCodeList() {
      try {
        const searchCodes = [
          'WorkListSearchCode',
          'SpecialistPhysician',
          'SpecialistPhysicianOpinion',
        ];
        const resultList = await this.get('cultureResultService').getBusinessCodeList({classificationCodes: searchCodes});
        resultList.forEach(item => {
          this._setPartialBusicessCodes(item);
        });
        this.set('model.selectedWorkListSearchCode', this.get('workListSearchCodeItems.firstObject').get('code'));
      } catch(e) {
        console.log('getBusinessCodeList Error::', e);
      }
    },

    async _getDatas() {
      try{
        await this._getWorkConfigurations();
        this.set('isDisabled', false);
        await this._getSpeciallistPhysicans(false, '');
      } catch(e) {
        console.log('_init getDatas Error::::', e);
      }

    },

    async _getWorkConfigurations() {
      try {
        const param = {staffId: this.get('globalCurrentUser.employeeId')};
        const configResult = await this.get('cultureResultService').getSpecimenCheckInConfigurations(param);
        if(!isEmpty(configResult)) {
          this.set('workConfigurationList', configResult);
          this.set('model.workConfigSelectedValue', configResult[0].workListFindConfigurationId);
          this.set('model.workConfigSelectedItem', configResult[0]);
        }
      } catch(e) {
        console.log('_getWorkConfigurations Error::::', e);
      }
    },

    async _getSpeciallistPhysicans(isShowToast, content) {
      this._dataReset();
      this.set('loaderDimed', false);
      this.set('loaderType', 'spinner');
      this.set('isShowContentLoader', true);
      try {
        const params = this._getSpeciallistPhysicansParam();
        const result = await this.get('cultureResultService').getSpeciallistPhysicans(params);
        if(isShowToast) {
          this.showToastRefresh(content);
        }
        if (!isEmpty(result)) {
          result.map(d => {
            if (!isEmpty(d.specialistPhysician.opinionContent)) {
              d.opinionContent = d.specialistPhysician.opinionContent.replace(/(\n|\r\n)/gu, '<br>');
            }
          });
          this.set('gridItemsSource', result);
        }
        this.set('isShowContentLoader', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowContentLoader', false);
          this._showError(e);
        }
        console.log('_getSpeciallistPhysicans Error::::', e);
      }

    },

    _setGridItemsOpinionContent() {
      this._getSaveResultsData('Modify');
      next(this, function(){
        if(this.isDestroyed || this.isDestroying) {
          return;
        }
        this.set('isPhysicianEntryPopupOnpen', false);
      });
    },

    _setPopupsSelectedItemsText() {
      const physicianOpinionText = this.get('model.selectedPhysicianValue');
      const physicianText = this.get('model.selectedPhysicianOpinionValue');
      let tempStr = null;
      if(!isEmpty(physicianText) && !isEmpty(physicianOpinionText)) {
        tempStr = `${physicianText}<br>${physicianOpinionText}`;
      } else if(!isEmpty(physicianText) && isEmpty(physicianOpinionText)) {
        tempStr = `${physicianText}`;
      } else if(isEmpty(physicianText) && !isEmpty(physicianOpinionText)) {
        tempStr = `${physicianOpinionText}`;
      }
      return tempStr;
    },

    _getComments(lists, prop) {
      const comments = [];
      let commentString = '';
      lists.forEach(datas => {
        if (!isEmpty(datas[prop])) {
          comments.push(datas[prop]);
        }
      });
      if (!isEmpty(comments)) {
        commentString = comments.join(', ');
      }

      return commentString;
    },

    _setConfigProperty(items) {
      const setObj = this._getTagProperties(items);
      this.set('tagCallbackItems', setObj);
      this.set('model.workConfigSelectedValue', items.workListFindConfigurationId);
      // this.set('model.workConfigSelectedItem', setObj);
      if (isEmpty(items.workListFindConfigurationId)) {
        this._getSpeciallistPhysicans(false, '');
      }
    },

    _getSpeciallistPhysicansParam() {
      let configProperties = this.get('model.workConfigSelectedItem.property');
      if (isEmpty(configProperties)) {
        configProperties = this.get('tagCallbackItems.property');
      }
      const {fromDate, toDate} = this._getSearchFromTo();
      const queryOption = this.get('model.selectedWorkSearchCode');
      const returnParam = {
        queryOption: isEmpty(queryOption) ? 1 : queryOption,
        checkInFromDate: fromDate,
        checkInToDate: toDate,
        // classificationIds:["GUID_L70"],
        isStat: null,
        isToday: null,
        specimenNumber: null,
        subjectTypeCode: "Patient",
        // subjectNumber: this.get('globalPatient.patientDisplayId'),
        checkInStartNumber: null,
        checkInEndNumber: null,
        // encounterTypeCode: this.get('model.selectedEncountTypeCode'),
        encounterTypeCode: null,
        issuedDepartmentIds: null,
        tatSearchTypeCode: null,
        tatSearchTimeMinute: 0,
      };
      const typeByIds = (prop) => {
        const configs = configProperties[prop];
        if(!isEmpty(configs)) {
          const ids = configs
            .map(config => config.id);
          if(!isEmpty(ids)) {
            return ids;
          }
        }
      };
      if(!isEmpty(configProperties)){
        returnParam.classificationIds = typeByIds('classifications');
        returnParam.unitWorkIds = typeByIds('unitWorks');
        returnParam.examinationIds = typeByIds('observationExaminations');
      }
      return returnParam;
    },

    _saveSpeciallistPhysicans() {
      try {
        this.set('loaderDimed', true);
        this.set('loaderType', 'progress');
        this.set('isShowContentLoader', true);
        this._createSpeciallistPhysicans();
        // this._deleteSpeciallistPhysicans();
        // next(this, function(){
        //   this.showToastSaved();
        //   this.set('isShowContentLoader', false);
        //   // this._getSpeciallistPhysicans(false, '');
        // });
      } catch(e) {
        this.set('isShowContentLoader', false);
      }
    },

    async _createSpeciallistPhysicans() {
      try {
        const saveResults = this._getSaveResultsData('Save');
        if(!isEmpty(saveResults)) {
          const saveParams = {
            issuedStaffId: this.get('globalCurrentUser.employeeId'),
            specialistPhysicianResults: saveResults
          };
          await this.get('cultureResultService').createSpeciallistPhysicans(saveParams);
        }
        this.showToastSaved();
        this.set('isShowContentLoader', false);
      } catch(e) {
        this._showSaveError(e);
        console.log('_createSpeciallistPhysicans Error:::', e);
      }
    },

    async _deleteSpeciallistPhysicans() {
      try {
        this._getSaveResultsData('Delete');
        const deleteResults = this.get('deleteItems');
        if(!isEmpty(deleteResults)) {
          this.set('loaderDimed', true);
          this.set('loaderType', 'progress');
          this.set('isShowContentLoader', true);
          const deleteParams = {
            specialistPhysicianResults: deleteResults
          };
          await this.get('cultureResultService').deleteSpeciallistPhysicans(deleteParams);
          this.showToastDeleted();
          this.set('isShowContentLoader', false);
        }
      } catch(e) {
        this.set('isShowContentLoader', false);
        this.showToastDeleteFail();
        console.log('_deleteSpeciallistPhysicans Error:::', e);
      }
    },

    _getSaveResultsData(type) {
      const selectedGridItems = this.get('gridSource').selectedItems;
      const targetResults = [];
      if(!isEmpty(selectedGridItems)) {
        const popupsContents = this._setPopupsSelectedItemsText();
        selectedGridItems.forEach(data => {
          if (type === 'Delete') {
            this.get('deleteItems').addObject({
              specimenId: data.specimenId,
              observationId: data.observationId
            });
            // this.get('gridItemsSource').removeObject(data);
            set(data, 'opinionContent', null);
            this.set('isSaveDisabled', false);
          } else if(type === 'Save') {
            let contentText = null;
            if(!isEmpty(data.opinionContent)) {
              contentText = data.opinionContent.replace(/(<br>|<br\/>|<br \/>)/gu, '\r\n');
              targetResults.push({
                specimenId: data.specimenId,
                observationId: data.observationId,
                isSignded: true,
                signId: this.get('signId'),
                opinionContent: contentText
              });
            }
          } else if(type === 'Modify') {
            set(data, 'opinionContent', popupsContents);
            this.set('isSaveDisabled', false);
            // data.opinionContent = popupsContents;
          }
        });
      }
      return targetResults;
    },

    _setDeleteItems() {
      this.showConfirmDelete().then(result => {
        if(result === 'Yes') {
          this._deleteSpeciallistPhysicans();
        }
      });
    },

    _getSearchFromTo() {
      const fromDate = new Date(this.get('selectedFromDate').getFullYear(), this.get('selectedFromDate').getMonth(), this.get('selectedFromDate').getDate()).toFormatString();
      const toDate = new Date(this.get('selectedToDate').getFullYear(), this.get('selectedToDate').getMonth(), this.get('selectedToDate').getDate()).toFormatString();
      return {fromDate, toDate};
    },
  });
