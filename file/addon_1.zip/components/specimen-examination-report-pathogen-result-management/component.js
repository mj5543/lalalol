/* eslint-disable prefer-named-capture-group */
/* eslint-disable no-console */
import { isEmpty } from '@ember/utils';
// import $ from 'jquery';
import { A as emberA } from '@ember/array';
import layout from './template';
import CHIS from 'framework/chis-framework';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';
import PrintMixin from '../../mixins/specimen-examination-report-print-mixin';
import InfectionMixin from '../../mixins/specimen-examination-report-infection-mixin';

export default CHIS.FR.Core.ComponentBase.extend(
  MessageMixin,
  PrintMixin,
  InfectionMixin,
  {
    layout,
    isShowLoader: false,
    loaderDimed: false,
    loaderType: null,

    onPropertyInit() {
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-pathogen-result-management');

      this.setStateProperties([
        'examinationItems',
        'gridColumns',
        'gridItems',
        'gridSource',
        'searchPatientInfo',
        'searchPatientId',
      ]);
      if (!this.hasState()) {
        this.set('model', {
          gridSelectedItem: null,
          selectedClassificationId: null,
          selectedClassification: null,
        });
        const othersLang = `(${this.getLanguageResource('9697', 'F', '', '기타')})`;
        this.set('gridColumns', [
          {title: this.getLanguageResource('5835', 'F', '', '의뢰기관'),
            columns: [
              { field: 'referOrganizationCode', title: this.getLanguageResource('1465', 'F', '', '의뢰기관코드'), width: 100, align: 'center',bodyTemplateName: 'textTooltip', readOnly: true},
              { field: 'referOrganizationName', title: this.getLanguageResource('1466', 'F', '', '의뢰기관명'), width: 100, align: 'center', bodyTemplateName: 'textTooltip', readOnly: true},
              { field: 'orderedStaff.name', title: this.getLanguageResource('1854', 'F', '', '담당자'), width: 70, align: 'center', bodyTemplateName: 'textTooltip', readOnly: true},
            ]},
          {title: this.getLanguageResource('867', 'F', '', '검체정보'),
            columns: [
              { field: 'patient.displayNumber', title: this.getLanguageResource('8451', 'F', null, '등록번호'), width: 80, align: 'center', bodyTemplateName: 'textTooltip', readOnly: true},
              { field: 'patient.name', title: this.getLanguageResource('16881', 'F', '', '환자명'), width: 70, align: 'center', bodyTemplateName: 'textTooltip', readOnly: true},
              { field: 'patient.gender', title: this.getLanguageResource('3680', 'F', null, '성별'), width: 40, align: 'center', readOnly: true},
              { field: 'patient.birthdate', title: this.getLanguageResource('3480', 'F', '', '생년월일'), width: 80, align: 'center', type: 'date', dataFormat: 'd', readOnly: true},
              { field: 'department.name', title: this.getLanguageResource('1113', 'S','진료과'), width: 80, align: 'center', bodyTemplateName: 'textTooltip', readOnly: true},
              { field: 'ward.displayCode', title:  this.getLanguageResource('2749', 'S','병동'), width: 50, align:'center', bodyTemplateName: 'textTooltip', readOnly: true},
              { field: 'specimenKindCode', title: this.getLanguageResource('868', 'F', '', '검체종류'), width: 60, align:'center', readOnly: true},
              { field: 'declareInformation.specimenKindEtc', title: this.getLanguageResource('868', 'F', '', '검체종류')+othersLang, width: 90, bodyTemplateName:'editKindEtc'},
              { field: 'examinationMethodCode', title: this.getLanguageResource('721', 'F', '', '검사방법'), width: 60, align:'center', readOnly: true},
              { field: 'declareInformation.examinationMethodEtc', title: this.getLanguageResource('721', 'F', '', '검사방법')+othersLang, width: 90, bodyTemplateName:'editMethodEtc'},
            ]},
          {title: this.getLanguageResource('2856', 'F', '', '병원체'),
            columns: [
              { field: 'pathogenCode', title: this.getLanguageResource('13268', 'F', '', '병원체코드'), width: 80, align: 'center', readOnly: true},
            ]},
          {title: this.getLanguageResource('13276', 'F', '', '발생정보'),
            columns: [
              { field: 'checkInDate', title: this.getLanguageResource('6777', 'F', '', '접수일'), width: 80, align: 'center', type: 'date', dataFormat: 'd', readOnly: true},
              { field: 'issuedDate', title: this.getLanguageResource('2872', 'F', '', '보고일'), width: 80, align: 'center', type: 'date', dataFormat: 'd', readOnly: true},
            ]},
          {title: this.getLanguageResource('14506', 'F', '', '검사기관'),
            columns: [
              { field: 'organizationCode', title: this.getLanguageResource('13273', 'F', '', '기관번호'), width: 80, align: 'center', readOnly: true},
              { field: 'chargedStaff.name', title: this.getLanguageResource('13277', 'F', '', '진단의'), width: 70, align: 'center', readOnly: true},
            ]},
          {title: this.getLanguageResource('13278', 'F', '', '병원체검사신고'),
            columns: [
              { field: 'declareInformation.isReportSend', title: this.getLanguageResource('13279', 'F', '', '전송여부'), width: 60, align: 'center', bodyTemplateName: 'reportSendYN', readOnly: true},
              { field: 'declareInformation.sendResultDatetime', title: this.getLanguageResource('10071', 'F', '', '전송일시'), width: 120, align: 'center', type: 'date', dataFormat: 'g', readOnly: true},
              { field: 'declareInformation.sendResultStaffId.name', title: this.getLanguageResource('6678', 'F', '', '전송자'), width: 70, align: 'center', readOnly: true},
            ]},
        ]);
        const displayDate = new Date(this.get('co_CommonService').getNow());
        this.set('selectedFromDate', displayDate);
        this.set('selectedToDate', displayDate);
      }

    },
    onLoaded() {
      this._super(...arguments);
      this.set('menuClass', 'w1360');
      this._init();
    },
    actions: {
      onGridLoaded(e) {
        this.set('gridSource', e.source);
      },
      onSearchAction() {
        this.getGridItemList();
      },
      onFromToUpdated(e) {
        const fromDate = this.get('fr_I18nService').formatDate(e.selectedFromDate, 'd');
        const toDate = this.get('fr_I18nService').formatDate(e.selectedToDate, 'd');
        this.getGridItemList(`${fromDate} ~ ${toDate}`);
      },
      onComboboxChanged(e) {
        this.getGridItemList(`${this.getLanguageResource('9009', 'F', '', '분류')}:  ${e.item.name}`);
      },
      onExcelClick() {
        this._getExcelData();
      },
      onDeclareClick() {
        this._getSaveConfirm();
      }
    },

    _init() {
      this._getPathogenClassification();
      this.getGridItemList();
    },
    async _getPathogenClassification() {
      try {
        const result = await this.get('apiService').getPathogenClassification();
        const comboboxItems = [
          {name: this.getLanguageResource('6700', 'F', '', '전체'), id: 'All'},
          ...result
        ];
        this.set('classificationItems', comboboxItems);
        this.set('model.selectedClassificationId', 'All');
      } catch(e) {
        console.log('_getPathogenClassification', e);
      }
    },
    async getGridItemList(refreshContent) {
      try {
        this.set('gridItems', emberA());
        this.set('loaderDimed', false);
        this.set('loaderType', 'spinner');
        this.set('isShowLoader', true);
        const {fromDate, toDate} = this._getSearchFromTo();
        const classificationId = this.get('model.selectedClassificationId');
        const params = {
          fromDate: fromDate,
          toDate: toDate,
          classificationId: classificationId === 'All' ? null : classificationId,
        };
        const result = await this.get('apiService').getPathogenExaminationResult(params);
        result.map(d => {
          const defaultDeclare = {
            pathogenDeclareId: null,
            isReportSend: false,
            specimenKindEtc: null,
            examinationMethodEtc: null,
            sendResultDatetime: null,
            sendResultStaffId: null
          };
          if(isEmpty(d.declareInformation)) {
            d.declareInformation = defaultDeclare;
          }
        });
        if(!isEmpty(refreshContent)) {
          this.showToastRefresh(refreshContent);
        }
        if (!isEmpty(result)) {
          this.set('gridItems', result);
        }
        this.set('isShowLoader', false);
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isShowLoader', false);
          this._showError(e);
        }
        console.log('getGridItemList Error :::::', e);
      }
    },
    async _getSaveConfirm() {
      if(isEmpty(this.get('gridSource.selectedItems'))) {
        this.showToastCustomMessage('error', this.getLanguageResource('11918', 'F', '', '선택한 항목이 없습니다.'));
        return;
      }
      const result = await this.showConfirmSave();
      if(result === 'Yes') {
        this._savePathogenDeclare();
      }
    },
    async _savePathogenDeclare() {
      try {
        this.set('loaderDimed', true);
        this.set('loaderType', 'progress');
        this.set('isShowLoader', true);
        // const params = {
        //   basedOnTypeCode: null,
        //   basedOnId: null,
        //   dataTypeCode: null,
        //   mappingTypeCode: null,
        //   mappingValue: null,
        //   isAttribute: true,
        //   isSubCategory: true,
        //   attributeId: null
        // };
        // await this.get('apiService').createPathogenExaminationMapping(params);
        const params = {
          pathogenDeclaration: this._getSaveParameters()
        };
        await this.get('apiService').createPathogenDeclare(params);
        this.showToastSaved();
        this.set('isShowLoader', false);
        this.getGridItemList();
      } catch(e) {
        this.showToastSaveFail();
        this.set('isShowLoader', false);
        console.log('_savePathogenExamination Error:::', e);
      }
    },

    _getSaveParameters() {
      const seletedItems = this.get('gridSource.selectedItems');
      const retunrArr = [];
      seletedItems.forEach(item => {
        const param = {
          specimenId: item.specimenId,
          examinationId: item.examinationId,
          observationId: item.observationId,
          specimenKindCode: item.specimenKindCode,
          examinationMethodCode: item.examinationMethodCode,
          specimenKindEtc: item.declareInformation.specimenKindEtc,
          examinationMethodEtc: item.declareInformation.examinationMethodEtc,
          declarePathogenCode: item.declarePathogenCode
        };
        retunrArr.push(param);
      });
      return retunrArr;
    },
    _getExcelData() {
      const gridItemsSource = this.get('gridItems');
      const firstRow = [];
      const secondRow = [];
      const colInfo = [];
      const columns = this.get('gridColumns');
      columns.forEach(column => {
        column.columns.forEach((child, index) => {
          if (index === 0) {
            firstRow.push(column.title);
          } else {
            firstRow.push('');
          }
          secondRow.push(child.title);
        });
      });
      const initArr = [firstRow, secondRow];
      const resultArr = [];
      gridItemsSource.forEach(datas => {
        const tempArr = [];
        columns.forEach(col => {
          col.columns.forEach((child) => {
            if(!isEmpty(child.field)) {
              const fields = child.field.split('.');
              let fieldsData = '';
              if(fields.length > 1 && !isEmpty(datas[fields[0]])) {
                fieldsData = datas[fields[0]][fields[1]];
                if(fields[1] === 'isReportSend') {
                  fieldsData = fieldsData ? 'Y' : 'N';
                }
              } else if(!isEmpty(datas[child.field])){
                fieldsData = datas[child.field];
              }
              tempArr.push(fieldsData);
            }
          });
        });
        resultArr.push(tempArr);
      });
      this.getExportByArrayTypeExcel(initArr, resultArr, colInfo, 'A3');
    },
  });