import { isEmpty, isPresent } from '@ember/utils';
// import { hash } from 'rsvp';
import { A as emberA } from '@ember/array';
import { set } from '@ember/object';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from '../../app-config';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MessageMixin,
  {
    /* 1. Service define Area
     testService:Ember.inject.service(),
    */
    specimenexaminationreportService: service('specimen-examination-report-service'),
    layout,
    isClassificationCheck: true,
    isComboDisabled: false,
    selectedClassificationId: null,
    needCallList: true,
    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-result-comments');
      //Set Stateful properties
      this.setStateProperties([
        'resultCommentsColumns',
        'resultCommentsItemsSource',
        'gridSelectedItem',
        'menuClass',
      ]);
      if (this.hasState() === false) {
        //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')
        +`specimen-examination-report/${config.version}/`);
        this.set('resultCommentsColumns', [
          // { title: this.getLanguageResource('5043', 'S','예문내용'), field: 'value.valueString',bodyTemplateName: 'tooltip', width: 100},
          { title: this.getLanguageResource('5043', 'S','예문내용'), field: 'value.valueString', width: 100, enableGotFocusAutoSelect: true, bodyTemplateName:'editCell'},
        ]);
        this.set('isPopupOpen', false);
        this.set('deleteItems', []);
        this.set('resultCommentsItemsSource', this.get('resultCommentsList'));
      }
    },

    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w680');
      this._getClassifications();
      if (this.hasState() === false) {
        // const defaultUrl = this.get('defaultUrl');

        // hash({
        //   allResultCommentsItemsSource: this.getList(defaultUrl + 'observations/examples', {exampleTypeCode: 'ResultRemark', examinationId: null}, null),
        // }).then(function(result) {
        //   this.set('allResultCommentsItemsSource', result.allResultCommentsItemsSource);
        // }.bind(this)).catch(function(error){
        //   this._catchError(error);
        // }.bind(this));
      }
    },

    // 4. Actions Area
    actions: {
      onGridLoad(e) {
        this.set('_gridControl', e.source);
      },
      onCheckChagned(e) {
        this.set('isComboDisabled', !e.checked);
        if(e.checked) {
          this._getGridItemsSource(this.get('selectedClassificationId'));
        } else {
          this._getGridItemsSource(null);
        }
      },
      onRefreshClick() {
        if(this.get('isClassificationCheck')) {
          let classificationId = this.get('selectedClassificationId');
          if(this.get('isMicrobacterial')) {
            classificationId = 'GUID_MICROBAC';
          }
          this._getGridItemsSource(classificationId);
        } else {
          this._getGridItemsSource(null);
        }
      },
      onClassificationChanged(e) {
        this._getGridItemsSource(e.item.classificationId);
      },
      onOpenedAction(e){
        this.set('itemSourceChanged', false);
        const classificationId = this.get('classificationId');
        this.set('gridSelectedItem', null);
        this.set('popup', e.source);
        if(!isEmpty(this.get('_currentCell'))){
          this.set('remark', this.get('_currentCell').item.remark);
        }
        if(this.get('needCallList')) {
          this._getGridItemsSource(classificationId);
        }
        // this._setGridItemsSource();
      },

      onPopupClosed(){
        const classificationId = this.get('classificationId');
        if(!this.get('isClassificationCheck') || this.get('selectedClassificationId') !== classificationId) {
          this.set('resultCommentsItemsSource', emberA());
          this.set('needCallList', true);
          this.set('isClassificationCheck', true);
          this.set('isComboDisabled', false);
          this.set('selectedClassificationId', classificationId);
        } else {
          this.set('needCallList', false);
        }
        if(this.get('itemSourceChanged')){
          const onRemarkChangedCB = this.get('onRemarkChangedCB');
          if(!isEmpty(onRemarkChangedCB)) {
            onRemarkChangedCB();
          }
        }
      },

      onNewClick(){
        const gridControl = this.get('_gridControl');
        if(!isEmpty(gridControl.itemsSource)){
          const emptyIdItem = gridControl.itemsSource.filter(d => d.id === null);
          if(!isEmpty(emptyIdItem)){
            return;
          }
        }
        let classificationId = null;
        if(this.get('isClassificationCheck')) {
          classificationId = this.get('selectedClassificationId');
        }
        if(this.get('isMicrobacterial')) {
          classificationId = 'GUID_MICROBAC';
        }
        let item = {};
        if(!isEmpty(this.get('_currentCell'))){
          item = this.get('_currentCell').item;
        }
        let resultCommentsItemsSource = this.get('resultCommentsItemsSource');
        if(isEmpty(resultCommentsItemsSource)){
          resultCommentsItemsSource = [];
        }
        resultCommentsItemsSource.unshiftObject({
          id: null,
          exampleTypeCode: "ResultRemark",
          examinationId: isEmpty(item.examinationId)? null: item.examinationId,
          // valueTypeCode: isEmpty(item.valueTypeCode)? this._returnValueType(item): item.valueTypeCode,
          valueTypeCode: isEmpty(item.valueTypeCode)? null : item.valueTypeCode,
          value: {
            quantity: {
              value: null,
              comparatorCode: null,
              unitCode: null,
              unitName: null
            },
            codeableConcept: null,
            valueDecimal: null,
            valueString: item.dataAbsentReason,
            valueBool: true,
          },
          functionTypeCode: null,
          functionApplyCode: null,
          displaySequence: 0,
          classificationId: classificationId
        });
        this.set('resultCommentsItemsSource', resultCommentsItemsSource);
        setTimeout(() => {
          gridControl.selectRow(0);
          gridControl.focusCell(0, 0);
          gridControl.editCell(0, 0);
        });
      },

      onSaveClick(){
        let examinationId = isEmpty(this.get('_currentCell'))? null : this.get('_currentCell.item.examinationId');
        this.set('isGridShow', true);
        if(this.get('isMicrobacterial')) {
          examinationId = this.get('specimenExaminationId');
        }
        let promise = null;
        let createParams = null;
        const updateParams = [];
        const deleteItems = this.get('deleteItems');
        const gridItems = this.get('resultCommentsItemsSource');
        const gridControl = this.get('_gridControl');
        if(isEmpty(gridItems) && isEmpty(deleteItems)){
          this.set('isGridShow', false);
          return;
        }
        if(!isEmpty(deleteItems)){
          deleteItems.forEach(e => {
            updateParams.addObject({
              observationExampleId: e.id,
              exampleTypeCode : e.exampleTypeCode,
              valueTypeCode: e.valueTypeCode,
              value: e.value,
              functionTypeCode: null,
              functionApplyCode: null,
              displaySequence: e.displaySequence,
              isValidDataRow: false,
              classificationId: e.classificationId
            });
          });
        }
        let validationCheck= true;
        if(!isEmpty(gridItems)) {
          //2020.06.23 refactroring
          // gridItems.forEach((e, index)=>{
          //   if(e.displaySequence !== index) {
          //     set(e, 'displaySequence', index);
          //     set(e, 'isUpdated', true);
          //   }
          //   if(isEmpty(e.value.valueString)){
          //     validationCheck= false;
          //     this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('8945', 'F', '필수값을 입력하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
          //     return;
          //   }
          //   if(e.isUpdated){
          //     if(isEmpty(e.id)){
          //       createParams= {
          //         exampleTypeCode: "ResultRemark",
          //         examinationId: examinationId,
          //         // examinationId: null,
          //         // valueTypeCode: e.valueTypeCode,
          //         valueTypeCode: "ValueString",
          //         value: e.value,
          //         functionTypeCode: null,
          //         functionApplyCode: null,
          //         // displaySequence: 1,
          //         displaySequence: e.displaySequence,
          //         classificationId: e.classificationId
          //         // isDefaultValue: false
          //       };
          //     }else{
          //       //수정
          //       const updateParam = {
          //         observationExampleId: e.id,
          //         exampleTypeCode : e.exampleTypeCode,
          //         valueTypeCode: e.valueTypeCode,
          //         value: e.value,
          //         functionTypeCode: null,
          //         functionApplyCode: null,
          //         displaySequence: e.displaySequence,
          //         isValidDataRow: true,
          //         classificationId: e.classificationId
          //       };
          //       updateParams.addObject(updateParam);
          //     }
          //   }
          // });
          const itemSize = gridItems.length;
          for(let i = 0; itemSize > i; i++) {
            const e = gridItems[i];
            if(e.displaySequence !== i) {
              set(e, 'displaySequence', i);
              set(e, 'isUpdated', true);
            }
            if(isEmpty(e.value.valueString)){
              validationCheck = false;
              gridControl.selectRow(i);
              this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('8945', 'F', '필수값을 입력하세요.'), 'warning', 'Ok', 'Ok', '', 1000);
              setTimeout(() => {
                gridControl.focusCell(i, 0);
                gridControl.editCell(i, 0);
              });
              break;
            }
            if(e.isUpdated){
              if(isEmpty(e.id)){
                createParams= {
                  exampleTypeCode: "ResultRemark",
                  examinationId: examinationId,
                  // examinationId: null,
                  // valueTypeCode: e.valueTypeCode,
                  valueTypeCode: "ValueString",
                  value: e.value,
                  functionTypeCode: null,
                  functionApplyCode: null,
                  // displaySequence: 1,
                  displaySequence: e.displaySequence,
                  classificationId: e.classificationId
                  // isDefaultValue: false
                };
              }else{
                //수정
                const updateParam = {
                  observationExampleId: e.id,
                  exampleTypeCode : e.exampleTypeCode,
                  valueTypeCode: e.valueTypeCode,
                  value: e.value,
                  functionTypeCode: null,
                  functionApplyCode: null,
                  displaySequence: e.displaySequence,
                  isValidDataRow: true,
                  classificationId: e.classificationId
                };
                updateParams.addObject(updateParam);
              }
            }
          }
        }
        if(!validationCheck){
          this.set('isGridShow', false);
          return;
        }
        if(!isEmpty(createParams)){
          promise= this.create(this.get('defaultUrl') + 'observations/examples', null, createParams);
        }
        if(!isEmpty(updateParams)){
          promise = this.update(this.get('defaultUrl') + 'observations/examples-list', null, false, {
            exampleValues : updateParams});
        }
        if(!isEmpty(promise)){
          promise.then(function(){
            // let classificationId = this.get('classificationId');
            let classificationId = null;
            if(this.get('isClassificationCheck')) {
              classificationId = this.get('selectedClassificationId');
            }
            if(this.get('isMicrobacterial')) {
              classificationId = 'GUID_MICROBAC';
            }
            this.set('isGridShow', false);
            this.get('specimenexaminationreportService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
            if(this.get('classificationId') === classificationId) {
              this.set('itemSourceChanged', true);
            }
            this._getGridItemsSource(classificationId);
          }.bind(this)).catch(function(error){
            this._catchError(error);
          }.bind(this));
        } else {
          this.set('isGridShow', false);
        }
      },

      onDelClick(){
        const selectedItem = this.get('selectedItem');
        const gridControl = this.get('_gridControl');
        const resultCommentsItemsSource = this.get('resultCommentsItemsSource');
        if(isEmpty(selectedItem)){
          this.get('specimenexaminationreportService')._showMessage( this.getLanguageResource('9260', 'F','Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        const itemIndex = gridControl.getItemIndex(selectedItem);
        if(!isEmpty(selectedItem.id)) {
          this.get('deleteItems').addObject(selectedItem);
        }
        resultCommentsItemsSource.removeObject(selectedItem);
        if(!isEmpty(itemIndex) && itemIndex !== resultCommentsItemsSource.length) {
          gridControl.selectRow(itemIndex);
        } else if(!isEmpty(resultCommentsItemsSource)) {
          gridControl.selectRow(resultCommentsItemsSource.length-1);
        }
      },

      // onEditStart(e){

      // },

      onEditEnd(e){
        set(e, 'item.isUpdated', true);
      },
      // onCellDoubleClick(e){
      //   if(isEmpty(e.item.value.valueString)){
      //     this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('8945', 'F', '필수값을 입력하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
      //     return;
      //   }
      //   this._returnValue(e.item.value.valueString);
      // },
    },
    // _getGridItemsSource(classificationId){
    //   this.set('isGridShow', true);
    //   const params = {
    //     exampleTypeCode: 'ResultRemark',
    //     examinationId: null,
    //     classificationId: classificationId
    //   };
    //   // this.getList(this.get('defaultUrl') + 'observations/examples', params, null).then(res=> {
    //   this.getList(this.get('defaultUrl') + 'observations/result-remarks', params, null).then(res=> {
    //     if(isEmpty(res)){
    //       return;
    //     }
    //     res.forEach(e=>{
    //       set(e, 'isUpdated', false);
    //     });
    //     this.set('resultCommentsItemsSource', res);

    //     this._setGridItemsSource();
    //   }).catch(function(error){
    //     this._catchError(error);
    //   }.bind(this));
    // },

    async _getGridItemsSource(classificationId) {
      try {
        this.set('deleteItems', emberA());
        this.set('isGridShow', true);
        this.set('resultCommentsItemsSource', emberA());
        // let parameterId = classificationId;
        // if(this.get('isMicrobacterial')) {
        //   parameterId = 'GUID_MICROBAC';
        // }
        const params = {
          exampleTypeCode: 'ResultRemark',
          classificationId: classificationId
        };
        const res = await this.getList(this.get('defaultUrl') + 'observations/result-remarks', params, null);
        if(isPresent(res)) {
          res.map(d => {
            d.isUpdated = false;
          });
          this.set('resultCommentsItemsSource', res);
        }
        this.set('isGridShow', false);
        if(!this.get('isMicrobacterial')) {
          this._setGridItemsSource();
        }
      } catch(e) {
        this._showError(e);
      }
    },

    _setGridItemsSource(){
      this.set('isGridShow', true);
      const resultCommentsItemsSource = [];
      const gridItems = this.get('resultCommentsItemsSource');
      const _currentCell = this.get('_currentCell');

      if(isEmpty(gridItems)){
        this.set('isGridShow', false);
        return;
      }
      gridItems.forEach(i=>{
        if(isEmpty(i.examinationId) || (isPresent(_currentCell) && i.examinationId === _currentCell.item.examinationId)){
          resultCommentsItemsSource.addObject(i);
        }
      });
      this.set('resultCommentsItemsSource', resultCommentsItemsSource);
      this.set('isGridShow', false);
    },
    // _returnValueType(item){
    //   const resultTypeCode= item.property.resultTypeCode;
    //   if(isEmpty(resultTypeCode)){
    //     return null;
    //   }else if(resultTypeCode == 'Numeric'){
    //     return 'Quantity';
    //   }else if(resultTypeCode == 'Character'){
    //     return 'CodeableConcept';
    //   }else {
    //     return 'Quantity';
    //   }
    // },
    // _returnValue(valueString){
    //   const onReturnResultCommentsCB = this.get('onReturnResultCommentsCB');

    //   if(!isEmpty(onReturnResultCommentsCB)) {
    //     onReturnResultCommentsCB(valueString);
    //     // this.set('isCodeSeachOpen', false);
    //   }
    // },
    async _getClassifications() {
      if(this.get('isMicrobacterial')) {
        return;
      }
      this.set('selectedClassificationId', null);
      const result = await this.getList(this.get('defaultUrl') + 'classifications', {selectedOption: 'EnconterTypeCode', classificationType: 1}, null);
      if(!isEmpty(result)) {
        this.set('comboboxItems', result);
        this.set('selectedClassificationId', this.get('classificationId'));
      }
    },

    _catchError(e){
      this.set('isGridShow',false);
      this.showResponseMessage(e);
    },
    // 5. Private methods Area

  });