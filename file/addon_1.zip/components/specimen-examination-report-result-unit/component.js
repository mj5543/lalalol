import { A } from '@ember/array';
import $ from 'jquery';
import { isEmpty } from '@ember/utils';
import { next } from '@ember/runloop';
import { hash, Promise } from 'rsvp';
import EmberObject, { computed, get, set } from '@ember/object';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'specimenexaminationreport-module/app-config';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MessageMixin,
  /* Only For Server-Call Component
  CHIS.FR.CrossCutting.ServerCallMixin,
  */
  {
    /* 1. Service define Area
     testService:Ember.inject.service(),
    */
    specimenexaminationreportService: service('specimen-examination-report-service'),
    layout,
    // 2. Property Area
    defaultUrl: null,
    resultUnitManagementColumns: null,
    unitCodeItemsSource: null,
    // unitCodeSelectedItem: null,
    unitCodeItemsSourceCopy: null,
    _gridControl: null,
    isResultUnitOpen: computed('examItemSelectedItem', function() {
      this._init();

      return this.get('isResultUnitOpen');
    }),
    // item: Ember.computed('selectedUnit', function() {
    //   this._init();

    //   return this.get('isResultUnitOpen');
    // }),
    item: null,
    // selectedUnitName: null,
    changedUnit: null,
    searchItemsSource: null,
    showDropDownLoader: null,
    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-result-unit');
      //Set Stateful properties
      this.setStateProperties([
        'defaultUrl',
        'menuClass',
        'resultUnitManagementColumns',
        'unitCodeItemsSource',
        // 'unitCodeSelectedItem',
        '_gridControl'
      ]);
      if (this.hasState() === false) {
        //Initialize Stateful properties
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')
        + `specimen-examination-report/${config.version}/`);
        this.set('resultUnitManagementColumns',[
          { title: this.getLanguageResource('4404', 'F', 'Start Date'), field: 'validStartDate', width: 110,type: 'date', dataFormat: 'd',},
          { title: this.getLanguageResource('6967', 'F', 'End Date'), field: 'validEndDate', width: 110,type: 'date', dataFormat: 'd',},
          { title: this.getLanguageResource('7674', 'F', 'Code'), field: 'code', width: 130,},
          { title: this.getLanguageResource('5930', 'F', 'name'), field: 'name', width: 130,},
        ]);
        this._init();
      }
      //Initialize Stateless properties

    },

    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1360');
      if (this.hasState() === false) {
        const defaultUrl = this.get('defaultUrl');

        hash({
          unitCodeItemsSource: this.getList(defaultUrl + 'business-codes/search', {classificationCode: 'UCUM'}, null),
          // unitManagementItemsSource: this.getList(this.get('defaultUrl') + 'examination-units/'+
          //   this.get('examItemSelectedItem.specimenExaminationId'), null, true)
        }).then(function(result) {
          this.set('unitCodeItemsSource', result.unitCodeItemsSource);
          // this.set('unitManagementItemsSource', result.unitManagementItemsSource);
          // if(Ember.isPresent(result.unitManagementItemsSource)){
          //   // this.set('item', result.unitManagementItemsSource.get('firstObject'));
          // }
          this._getResultUnitList();

        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      }
    },

    // 4. Actions Area
    actions: {
      onFilterChanged(e) {
        let component = e.source, filterValue = e.filterValue;

        this.set('showDropDownLoader', true);
        this.set('searchItemsSource', null);
        next(this, function () {
          let searchItemsSource = null;
          if(isEmpty(this.get('unitCodeItemsSource'))){
            return;
          }
          searchItemsSource = this.get('unitCodeItemsSource').filter(function (item) {
            return RegExp(filterValue, 'giu').test(get(item, 'displayCode'));
          });
          if (filterValue === get(component, 'filterValue')) {
            this.set('searchItemsSource', searchItemsSource);
            this.set('showDropDownLoader', false);
          }
          filterValue = null;
          component = null;
        }.bind(this));
      // if (0 < filterValue.length) {
        //   next(this, function () {
        //     let searchItemsSource = null;
        //     if(isEmpty(this.get('unitCodeItemsSource'))){
        //       return;
        //     }
        //     searchItemsSource = this.get('unitCodeItemsSource').filter(function (item) {
        //       return RegExp(filterValue, 'giu').test(get(item, 'displayCode'));
        //     });
        //     if (filterValue === get(component, 'filterValue')) {
        //       this.set('searchItemsSource', searchItemsSource);
        //       this.set('showDropDownLoader', false);
        //     }
        //     filterValue = null;
        //     component = null;
        //   }.bind(this));
        // } else {
        //   this.set('showDropDownLoader', false);
        // }
      },

      onGridLoad(e) {
        this.set('_gridControl', e.source);
      },

      onGridSelectionChanged(e){
        const item= e.selectedItems.get('firstObject');
        if(isEmpty(item)){
          return;
        }
        this.set('item', item);
        this.set('changedUnit', item);
      },

      onNewClick(){
        const unitManagementItemsSource= this.get('unitManagementItemsSource');
        if(!isEmpty(unitManagementItemsSource)){
          if(!isEmpty(unitManagementItemsSource.get('firstObject').validEndDate)){
            this.get('_gridControl').deselectRow(0);
            this._init();
            // const item= this.get('item');
            // set(item, 'validStartDate',unitManagementItemsSource.get('firstObject').validEndDate.addDays(1));
          }else{
            this.get('_gridControl').deselectRow(0);
            this._init();
            // const item= this.get('item');
            // set(item, 'validStartDate',unitManagementItemsSource.get('firstObject').validEndDate.addDays(1));
            // const item= this.get('item');
            // this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9237', 'S','종료일을 확인하세요.'), 'warning', 'Ok', 'Ok', '', null);
            // return;
          }
        }
        this.set('selectedUnit', this.get('item'));
      },
      onSaveClick(){
        let promise= null;
        const examItemSelectedItem= this.get('examItemSelectedItem');
        const item= this.get('item');
        const selectedUnit= this.get('selectedUnit');
        const latestUnit= this.get('latestUnit');
        if(isEmpty(selectedUnit)){
          this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('8945', 'F', '필수값을 입력하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        if(!isEmpty(item.validEndDate) && item.validStartDate > item.validEndDate){
          // this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9237', 'S','값 범위를 확인하세요.'), 'warning', 'Ok', 'Ok', '', null);
          // return;
        }
        if(isEmpty(item.id)){
          //등록
          promise= this.create(this.get('defaultUrl') + 'examination-units', null, {
            examinationId: examItemSelectedItem.specimenExaminationId,
            code: selectedUnit.code, name: selectedUnit.name,
            validStartDate: new Date(item.validStartDate.getFullYear(), item.validStartDate.getMonth(), item.validStartDate.getDate(), 0, 0, 0),
            validEndDate: isEmpty(item.validEndDate)? new Date('9999','11', '31'): new Date(item.validEndDate.getFullYear(), item.validEndDate.getMonth(), item.validEndDate.getDate(), 0, 0, 0),
          });
        }else{
          //수정
          if(item.validStartDate > item.validEndtDate || item.validStartDate > latestUnit.validStartDate || latestUnit.validEndDate > item.validEndDate){
            // this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9237', 'S','값 범위를 확인하세요.'), 'warning', 'Ok', 'Ok', '', null);
            // return;
          }
          promise= this.update(this.get('defaultUrl') + 'examination-units', null, false, {
            examinationUnitId: item.id,
            code: selectedUnit.code, name: selectedUnit.name,
            validStartDate: new Date(item.validStartDate.getFullYear(), item.validStartDate.getMonth(), item.validStartDate.getDate(), 0, 0, 0),
            validEndDate: isEmpty(item.validEndDate)? new Date('9999','11', '31'): new Date(item.validEndDate.getFullYear(), item.validEndDate.getMonth(), item.validEndDate.getDate(), 0, 0, 0),
          });
        }
        promise.then(function(){
          this.get('specimenexaminationreportService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
          this._getResultUnitList();
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      }
    },

    // 5. Private methods Area
    _init(){
      this.set('selectedUnit', null);
      this.set('item', {
        validStartDate: new Date(this.get('co_CommonService').getNow().setHours(0,0,0,0)),
        validEndDate: null,
        // validEndDate: new Date(),
        name: null,
        code: null,
      });
    },

    _getResultUnitList(){
      this.set('isUnitPopupShow', true);
      return this.getList(this.get('defaultUrl') + 'examination-units/'+
        this.get('examItemSelectedItem.specimenExaminationId'), null, null, true).then(function(res){
        if(res){
          this.set('isUnitPopupShow', false);
          const promise = new Promise((resolve)=>{
            if(res.response.length ){
              resolve(A(res.response));
              res.response.forEach(element => {
                if(element.validEndDate.toString() > "9999-12-30"){
                  set(element, 'validEndDate', null);
                }else{
                  set(element, 'validEndDate', element.validEndDate);
                }
              });
              if(isEmpty(this.get('changedUnit'))){
                this.set('changedUnit',{
                  code: res.response.get('firstObject.code'),
                  displayCode: res.response.get('firstObject.name')
                });
              }
              this.set('unitManagementItemsSource', res.response);
              next(this, function(){
                // this.set('selectedUnit', this.get('changedUnit'));
                this.set('selectedUnit', res.response.get('firstObject'));
                this.set('latestUnit', $.extend(true, EmberObject.create(), res.response.get('firstObject')));
              }.bind(this));
            } else{
              resolve(A([]));
            }
          });
          return promise;
        }

      }.bind(this)).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    _showMessage(caption, messageBoxImage, messageBoxButton, messageBoxFocus, messageBoxText, messageboxInterval){
      const options = {
        'caption': caption,
        'messageBoxImage': messageBoxImage,
        'messageBoxButton': messageBoxButton,
        'messageBoxFocus': messageBoxFocus,
        'messageBoxText': messageBoxText,
        'messageboxInterval': messageboxInterval
      };

      messageBox.show(this, options);
    },

    _catchError(e){
      this.set('isUnitPopupShow',false);
      this.showResponseMessage(e);
    }
  });