/* eslint-disable max-lines */
/* eslint-disable chis/require-template-convention */
/* eslint-disable no-console */
import { isEmpty, isPresent } from '@ember/utils';
import { next } from '@ember/runloop';
import { set } from '@ember/object';
// import { inject } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import SpecimenExaminationReportMixin from '../../mixins/specimen-examination-report-mixin';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin,
  SpecimenExaminationReportMixin,
  MessageMixin,
  {
    layout,
    specimenNumber: null,
    examinationCode: null,
    checkInId: null,
    resultWorkInfo: null,
    statusName: null,
    statusCode: null,
    issuedDate: null,
    recordNoteId: null,
    mappingInfoList: null,
    aboItemsSource: null,
    rhItemsSource: null,
    examplesResultRemarks: null,
    reportRecodeCode: null,
    isBloodTypeEntryShowLoader: false,
    isCorrectReasonEntryOpened: false,
    isCheckboxDisabled: false,
    isDetailEntry: false,
    isDetailEntryChecked: false,
    isShowMainSave: true,
    loaderDimed: false,
    isEditing: false,
    isControlDisabled: true,
    bloodTypeGroupValue: null,
    recordExaminationId: null,
    isDetailCheckDisabled: true,
    isResultContentRequired: false,
    isSaveDisabled: true,
    isRefreshDisabled: true,
    isShowRecordLoader: false,
    isBloodTypeRequired: false,
    isABOChanged: false,
    resultFontSize: 50,
    isCumulativeOpen: false,
    isCumulativeDisabled: true,
    // btService: inject('specimen-examination-report-blood-type-result-service'),

    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-blood-type-result-entry');
      this.setStateProperties([
        'model',
        'globalPatient'
      ]);
      if (this.hasState() === false) {
        this.set('model', {
          selectedRhItem: null,
          selectedAboItem: null,
          resultRemark: null,
          resultReason: {
            reasonCode: null,
            reasonContent: null,
          },
        });
        this.set('mappingInfoList', []);
        this.set('aboItemsSource', []);
        this.set('rhItemsSource', []);
        this.set('examplesResultRemarks', []);
      }
    },

    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w680');
      //전역정보 x 테스트
      // this.set('specimenNumber', '19080700003');
      // this._init();
      const contentSource= this.getOpenMenuParams();
      const examinationSpecimenId = this.get('co_PatientManagerService.selectedPatient.examination.specimenId');
      if(!isEmpty(contentSource)){
        this.set('specimenNumber', contentSource.specimenNumber);
        this.set('examinationCode', contentSource.examinationCode);
        this.set('checkInId', contentSource.checkInId);
        this._init();
      } else if(!isEmpty(examinationSpecimenId)) {
        this.set('specimenId', examinationSpecimenId);
        this._init();
      }
    },
    didInsertElement(){
      this._super(...arguments);
      this.get('co_ContentMessageService').subscribeMessage('sendMessage', this.get('currentMenuId'), this, this.sendMessage);
    },
    willDestroyElement() {
      this._super(...arguments);
      this.get('co_ContentMessageService').unsubscribeMessage('sendMessage', this.get('currentMenuId'), this, this.sendMessage);
    },
    sendMessage(e){
      if(!isEmpty(e)){
        this.set('specimenNumber', e.specimenNumber);
        this.set('examinationCode', e.examinationCode);
        this.set('checkInId', e.checkInId);
        this._init();
      }
    },
    onBeforePatientChange() {
      this._super(...arguments);
      if(this.get('isEditing') === true) {
        return false;
      } else {
        // this.set('specimenNumber', null);
        // this.set('examinationCode', null);
        return true;
      }

    },
    onPatientChange(canchange) {
      this._super(...arguments);
      if (canchange === false) {

        const options = {
          'caption': this.getLanguageResource('10251', 'F', '', '환자 선택 변경 진행중'),
          'messageBoxButton': 'YesNoCancel',
          'messageBoxImage': 'question',
          'messageBoxText': `[ ${this.get('menuTitle')} ]<br>${this.getLanguageResource('9231', 'F', null, '저장하지 않은 데이터가 있습니다.')}.<br>${this.getLanguageResource('8939', 'F', null, '저장하시겠습니까?')}`,
          'messageBoxFocus': 'Yes'
        };
        return messageBox.show(this, options).then(function (result) {
          if(result==='Yes'){
            this._getBloodTypesCompare();
            this.continuePatientChanging();
          } else if (result==='No'){
            this.continuePatientChanging();
          } else if (result==='Cancel'){
            this.cancelPatientChanaging();
          }
        }.bind(this));
      }

    },
    onOpenMenuParamsChanged(e) {
      this._super(...arguments);
      if(!isEmpty(e)){
        this.set('specimenNumber', e.specimenNumber);
        this.set('examinationCode', e.examinationCode);
        this.set('checkInId', e.checkInId);
        this._init();
      }

    },
    onPatientChanged(Patient){
      this._super(...arguments);
      console.log('onPatientChanged----', Patient);
      this.set('isCumulativeOpen', false);
      this.set('globalPatient', Patient);
      if(isEmpty(Patient)){
        return;
      }
      if(this.checkPatientDataClear() === true) {
        this._allResetting();
        return;
      }
      if(!isEmpty(this.get('resultWorkInfo')) && (this.get('resultWorkInfo.subject.number') !== Patient.patientDisplayId)) {
        // this.get('co_MenuManagerService').closeMenu(this.get('viewId'));
        this._allResetting();
        return;
      }
      const examinationSpecimenId = this.get('co_PatientManagerService.selectedPatient.examination.specimenId');
      if(isEmpty(examinationSpecimenId)) {
        this._allResetting();
        // return;
      }
      // this.set('specimenNumber', null);
      // this.set('specimenId', examinationSpecimenId);
      // this._init();
    // if(isEmpty(this.get('specimenNumber'))) {
      //   this.set('resultWorkInfo', null);
      //   this._dataReset();
      // }
    },
    _allResetting() {
      this.set('resultWorkInfo', null);
      this.set('currentLocation', null);
      this.set('locationTooltip', null);
      this._dataReset();
    },
    actions: {
      onRefreshClick() {
        this._dataReset();
        // this._getSpecimenInformation(this.get('specimenNumber'));
        this._getObservationsResultsAboRh(this.get('aboRhParams'));
      },
      onBloodTypeSave() {
        this.set('isSaveDisabled', true);
        this._getBloodTypesCompare();
      },
      onResultContentLoaded(e) {
        this.set('resultInput', e.source);
      },

      onReturnChangesReason(returnObj) {
        this.set('model.resultReason.reasonCode', returnObj.code);
        this.set('model.resultReason.reasonContent', returnObj.name);
        this._saveBloodTypes();
      },
      onReasonEntryCancel() {
        this.set('isSaveDisabled', false);
        this.set('isShowRecordLoader', false);
        this.set('isCorrectReasonEntryOpened', false);
        this.set('isBloodTypeEntryShowLoader', false);

      },
      onCheckedChange(e) {
        if(this.get('isControlDisabled')) {
          return;
        }
        if(isEmpty(this.get('reportRecodeCode'))) {
          this.set('isDetailCheckDisabled', true);
          this.showToastCustomMessage('error', this.getLanguageResource('13241', 'F', '', '결과보고 서식을 지정하세요.'));
          this._removeReportEntryProgress();
          return;
        }
        this.set('isEditing', true);
        if (e.checked) {
          this.set('isShowRecordLoader', true);
          this.set('isSaveDisabled', true);
          this._getBloodTypesCompare();
        } else {
          this.set('isShowMainSave', !e.checked);
          this.set('isDetailEntry', e.checked);
        }
      },
      onTextResultRecordSave(recordNoteId){
        this.set('isEditing', true);
        this.set('recordNoteId', recordNoteId);
        this._saveBeforeAction();
        // this._getBloodTypesCompare();
      },
      onAboItemChanged(e) {
        this.set('aboResultContent', null);
        const isEmptyABO = this._isEmptyABO();
        if(e.item.code === 'directInput' && e.checked) {
          this.set('isSnowDirectInput', true);
          this.set('isResultContentRequired', true);
          this.set('model.selectedRhItem', null);
          this.set('isDetailEntry', false);
          this.set('isDetailEntryChecked', false);
          this.set('isSaveDisabled', false);
          this.set('isShowMainSave', true);
          this.set('isDetailCheckDisabled', true);
        } else {
          this.set('isResultContentRequired', false);
          this.set('isSnowDirectInput', false);
          this.set('isSaveDisabled', isEmptyABO);
          if(!this.get('isCheckboxDisabled')) {
            this.set('isDetailCheckDisabled', isEmptyABO);
          }
          if(this.get('isDetailEntry')) {
            this.set('isABOChanged', true);
            this.set('isShowRecordLoader', true);
            this.set('isSaveDisabled', true);
            this._getBloodTypesCompare();
          }
        }
        this.set('isEditing', true);
      },
      onRhItemChanged(e) {
        if(e.item.name.length > 1) {
          this.set('resultFontSize', 40);
        } else {
          this.set('resultFontSize', 50);
        }
        const isEmptyABO = this._isEmptyABO();
        if(!this.get('isCheckboxDisabled')) {
          this.set('isDetailCheckDisabled', isEmptyABO);
        }
        this.set('isSaveDisabled', isEmptyABO);
        if(this.get('isDetailEntry')) {
          this.set('isABOChanged', true);
          this.set('isShowRecordLoader', true);
          this.set('isSaveDisabled', true);
          this._getBloodTypesCompare();
        }
        this.set('isEditing', true);
      },
      onAboResultContentChanged(e) {
        if(!isEmpty(e.source.value) && this.get('model.selectedAboItem.code') === 'directInput') {
          this.set('isSaveDisabled', false);
          // this.set('isDetailCheckDisabled', this._isEmptyABO());
        } else if(isEmpty(e.source.value) && this.get('model.selectedAboItem.code') === 'directInput') {
          this.set('isSaveDisabled', true);
          // this.set('isDetailCheckDisabled', true);
        }
        this.set('isEditing', true);
      },
      onBloodTypeGroupChanged(e) {
        this.set('isBloodTypeRequired', false);
        if(e.value === 'serum'){
          // if(!isEmpty(this.get('model.selectedRhItem')) && this.get('isDetailEntry') && this.get('model.selectedAboItem.code') !== 'directInput') {
          //   this.set('isDetailEntry', false);
          //   this.set('isDetailEntryChecked', false);
          //   this.set('isShowMainSave', true);
          // }
          if(!isEmpty(this.get('model.selectedAboItem'))) {
            this.set('isDetailCheckDisabled', false);
            this.set('isSaveDisabled', false);
          }
          this.set('model.selectedRhItem', null);
        } else if(e.value !== 'serum' && this._isEmptyABO()){
          this.set('isDetailCheckDisabled', true);
          this.set('isDetailEntry', false);
          this.set('isShowMainSave', true);
          this.set('isSaveDisabled', true);
          this.set('isDetailEntryChecked', false);
        }
        this.set('isEditing', true);
      },
      onCumulativeClick() {
        this.set('isCumulativeOpen', true);
      }

    },
    _init() {
      this.set('resultWorkInfo', null);
      this.set('currentLocation', null);
      this.set('locationTooltip', null);
      this._dataReset();
      if(isPresent(this.get('checkInId'))) {
        const resultParams = {
          specimenNumber: this.get('specimenNumber'),
          checkInId: this.get('checkInId')
        };
        // await this.get('btService').getObservationsResults(resultParams);
        this.set('aboRhParams', resultParams);
        this._getObservationsResultsAboRh(resultParams);
      }
      this.getDatas();
    },

    _dataReset() {
      this.set('isDetailEntry', false);
      this.set('isShowMainSave', true);
      this.set('isDetailEntryChecked', false);
      this.set('model.resultRemark', null);
      this.set('model.selectedAboItem', null);
      this.set('model.selectedRhItem', null);
      this.set('aboResultContent', null);
      this.set('isEditing', false);
      this.set('statusCode', null);
      this.set('statusName', null);
      this.set('issuedDate', null);
      this.set('recordNoteId', null);
      this.set('bloodTypeGroupValue', null);
      this.set('isControlDisabled', false);
      this.set('isSaveDisabled', true);
      this.set('isResultContentRequired', false);
      this.set('isDetailCheckDisabled', true);
      this.set('isShowRecordLoader', false);
      this.set('isBloodTypeRequired', false);
      this.set('sendPatientId', null);
      this.set('sendExaminationIds', []);
      this.set('isCumulativeDisabled', true);
      // this.set('isRefreshDisabled', true);
    },
    async getDatas() {
      try {
        // await this._getSpecimenCheckInDisplayView();
        this.set('contentLoaderType', 'spinner');
        this.set('loaderDimed', true);
        this.set('isBloodTypeEntryShowLoader', true);
        const workData = await this._getResultWorkData();
        if(isEmpty(workData)) {
          this.set('isBloodTypeEntryShowLoader', false);
          return;
        }
        if(workData.subject.number !== this.get('globalPatient.patientDisplayId')) {
          this._dataReset();
          this.set('isBloodTypeEntryShowLoader', false);
          return;
        }
        this.set('isRefreshDisabled', false);
        this.set('resultWorkInfo', workData);
        if(isEmpty(this.get('checkInId'))) {
          const resultParams = {
            specimenNumber: workData.specimenNumber,
            checkInId: workData.checkInId
          };
          // await this.get('btService').getObservationsResults(resultParams);
          this.set('aboRhParams', resultParams);
          const aboResult = await this._getObservationsResultsAboRh(resultParams);
          if(isEmpty(aboResult)) {
            this.set('resultWorkInfo', null);
            this.set('currentLocation', null);
            this.set('locationTooltip', null);
            this._dataReset();
            this.set('isBloodTypeEntryShowLoader', false);
            return;
          }
        }
        this._getSpecimenInformation(workData.specimenNumber);
        if(!isEmpty(workData.ward)) {
          this.set('currentLocation', `${workData.ward.displayCode} / ${workData.room.roomCode} / ${workData.bed.displayCode}`);
          this.set('locationTooltip', `${workData.ward.name} / ${workData.room.roomName} / ${workData.bed.name}`);
        }
        this._setResultRemark();
      } catch(e) {
        if(!this.get('isDestroyed')) {
          this.set('isBloodTypeEntryShowLoader', false);
        }
        console.log('getDatas Error::: ', e);
      }
    },
    async _getDepartmentComments(){
      try {
        this.set('comments', {
          isCommentsExpanded: false,
          deptCommentsCount: 0
        });
        if(isEmpty(this.get('resultWorkInfo'))){
          return;
        }
        const res = await this.get('specimenexaminationreportService').getDepartmentComments(this.get('resultWorkInfo'));
        if(!isEmpty(res)){
          this.set('comments', res);
        }
        this._getDelayReason();
      } catch(e) {
        console.error(e);
      }
    },
    async _getDelayReason() {
      if(isEmpty(this.get('resultWorkInfo'))){
        return;
      }
      const params = {
        specimenId: this.get('resultWorkInfo.specimenId'),
        checkinId: this.get('resultWorkInfo.checkInId'),
      };
      try {
        const result = await this.getList(this.get('checkinUrl') + 'specimen-checkins/observation-delay-specimens', params, null);
        if(isPresent(result)) {
          set(this.get('comments'), 'isCommentsExpanded', true);
        }
      }catch(e) {
        console.error(e);
      }
    },

    // async _getSpecimenCheckInDisplayView() {
    //   const param = {specimenNumber: this.get('specimenNumber')};
    //   const displayView = await this.get('btService').getSpecimenCheckInDisplayView(param);
    //   console.log('displayView---', displayView);
    // },

    async _getObservationsResultsAboRh(params) {
      try {
        this.set('isBloodTypeEntryShowLoader', true);
        this.set('bloodTypesInfo', []);
        const tagetStatusCodes = ['registered', 'preliminary', 'amended', 'final', 'corrected'];
        const result = await this.get('btService').getObservationsResultsAboRh(params);
        const examinationIds = [];
        if(!isEmpty(result)) {
          const examinations = [];
          await Promise.all (
            result.map(async (d, ind) => {
              if (ind === 0 && tagetStatusCodes.includes(d.statusCode)) {
                this.set('statusCode', d.statusCode);
                this.set('recordNoteId', d.value.recordNoteId);
                // this.set('recordExaminationId', d.examinationId);
                if (d.statusCode !== 'registered' || d.statusCode !== 'amended') {
                  this.set('statusName', d.statusName);
                  this.set('issuedDate', d.issuedDatetime);
                }
                if(!isEmpty(d.remark)) {
                  this.set('model.resultRemark', d.remark);
                }
                console.log('d.value.recordNoteId---', d.value.recordNoteId);
              }
              examinationIds.push(d.examinationId);
              examinations.push({examinationId: d.examinationId, exampleTypeCode: 'ExampleValue'});
              this.set('sendPatientId', d.subjectId);
              await this._getMappingInfomation(d.examinationId);
            })
          );
          await this._getObservationsExamplesSearch({examinations: examinations});
          this._getDepartmentComments();
        }
        this.set('sendExaminationIds', examinationIds);
        this.set('isCumulativeDisabled', false);
        return result;
      } catch(e) {
        console.log('_getObservationsResultsAboRh Error::: ', e);
      }
    },

    async _getMappingInfomation(id) {
      try {
        const res = await this.get('btService').getSpecimenExaminations({id: id});
        if(isPresent(res) && isPresent(res.mappingInformation)) {
          const mappingAttr = res.mappingInformation[0].mappingAttribute;
          this.get('bloodTypesInfo').addObject({id: res.mappingInformation[0].basedOnId, name: mappingAttr.linkKeyCode});
          this._getBloodTypeList(res.mappingInformation);
        }
      } catch(e) {
        console.log('_getMappingInfomation Error::: ', e);
      }
    },
    _getBloodTypeList(datas) {
      datas.forEach(d => {
        if (d.value === 'true' && d.specimenExaminationMapping.displayCode === 'IsExamination') {
          // this._getObservationsExamplesSearch(d.basedOnId, d.mappingAttribute.linkKeyCode);
        } else if(d.specimenExaminationMapping.displayCode ==='RecordType' && d.mappingAttribute.linkKeyCode === 'RecordType') {
          if(isEmpty(d.value)) {
            this.set('isCheckboxDisabled', true);
          } else {
            this.set('reportRecodeCode', d.value);
          }
        }
      });
    },
    async _getObservationsExamplesSearch(params) {
      try {
        // const aboComboItems = [];
        // const rhComboItems = [];
        let aboComboItems = null;
        let rhComboItems = null;
        const tempArr = [];
        const res = await this.get('btService').getObservationsExamplesSearch(params);
        res.forEach(item => {
          const content = item.value.codeableConcept.displayContent;
          const checkContents = ['BMT', 'i', 'U'];
          if(!checkContents.includes(content)) {
            const tmpItem = {
              code: item.value.codeableConcept.coding[0].code,
              name: item.value.codeableConcept.displayContent,
              examinationId: item.examinationId
            };
            // if(item.examination.abbreviation === 'ABO') {
            //   aboComboItems.push(tmpItem);
            // } else if(item.examination.abbreviation === 'Rh') {
            //   rhComboItems.push(tmpItem);
            // }
            tempArr.push(tmpItem);
          }
        });
        const aboType = this.get('bloodTypesInfo').find(d => d.name === 'ABO');
        const rhType = this.get('bloodTypesInfo').find(d => d.name === 'RH');
        aboComboItems = tempArr.filter(d => d.examinationId === aboType.id);
        rhComboItems = tempArr.filter(d => d.examinationId === rhType.id);

        this.set('recordExaminationId', aboComboItems[0].examinationId);
        aboComboItems.push({code: 'directInput', name: this.getLanguageResource('10858', 'F', null, '직접입력')});
        this.set('aboItemsSource', aboComboItems);
        this.set('rhItemsSource', rhComboItems);
        this.set('isBloodTypeEntryShowLoader', false);
      } catch(e) {
        console.log('_getObservationsExamplesSearch Error::: ', e);
      }
    },

    // async _getObservationsExamplesSearch(id, type) {
    //   try {
    //     const params = {
    //       examinations: [{
    //         examinationId: id,
    //         exampleTypeCode: 'ExampleValue'
    //       }]
    //     };
    //     const comboItems = [];
    //     const res = await this.get('btService').getObservationsExamplesSearch(params);
    //     res.forEach(item => {
    //       const content = item.value.codeableConcept.displayContent;
    //       const checkContents = ['BMT', 'i', 'U'];
    //       if(!checkContents.includes(content)) {
    //         comboItems.push({
    //           code: item.value.codeableConcept.coding[0].code,
    //           name: item.value.codeableConcept.displayContent
    //         });
    //       }
    //     });
    //     if (type === 'ABO') {
    //       this.set('recordExaminationId', res[0].examinationId);
    //       comboItems.push({code: 'directInput', name: this.getLanguageResource('10858', 'F', null, '직접입력')});
    //       this.set('aboItemsSource', comboItems);
    //     } else if (type === 'RH') {
    //       // comboItems.push({code: 'weekD', name: 'week D'});
    //       this.set('rhItemsSource', comboItems);
    //     }
    //     this.set('isBloodTypeEntryShowLoader', false);
    //   } catch(e) {
    //     console.log('_getObservationsExamplesSearch Error::: ', e);
    //   }
    // },

    _removeReportEntryProgress() {
      next(() => {
        this.set('isDetailEntryChecked', false);
        this.set('isShowRecordLoader', false);
        if(this.get('isResultContentRequired')) {
          let inputEl = document.getElementById(this.get('resultInput.elementId')).getElementsByTagName('input')[0];
          inputEl.focus();
          inputEl = null;
        }
      });
    },

    async _getBloodTypesCompare() {
      try {
        if(!this.checkGPatientId(this.get('resultWorkInfo.subjectId'), true)) {
          return;
        }
        if(this.get('model.selectedAboItem.code') === 'directInput' && isEmpty(this.get('aboResultContent'))) {
          this.showToastCustomMessage('new', this.getLanguageResource('10864', 'F', null, '직접입력이 체크되어있습니다.'));
          this._removeReportEntryProgress();
          this.set('isSaveDisabled', false);
          return;
        }
        if(isEmpty(this.get('bloodTypeGroupValue'))) {
          this.showToastWarning(this.getLanguageResource('9260', 'F', null, '항목을 선택하세요.'), 2000);
          this.set('isBloodTypeRequired', true);
          this._removeReportEntryProgress();
          this.set('isSaveDisabled', false);
          return;
        }
        if(this._isEmptyABO()) {
          this.showToastWarning(this.getLanguageResource('9260', 'F', null, '항목을 선택하세요.'), 2000);
          this._removeReportEntryProgress();
          this.set('isSaveDisabled', false);
          return;
        }
        this.set('isSaveDisabled', true);
        this.set('isDetailCheckDisabled', true);
        const params = {
          specimenId: this.get('resultWorkInfo.specimenId'),
          aboResultCode: this.get('model.selectedAboItem.code') === 'directInput' ? null : this.get('model.selectedAboItem.code'),
          aboResultContent: this.get('aboResultContent'),
          rhResultCode: this.get('model.selectedRhItem.name')
        };
        const compareResult = await this.get('btService').getBloodTypesCompare(params);
        this.set('isShowRecordLoader', false);
        if (!compareResult.isSame) {
          if(this.get('isABOChanged')) {
            this.showWarningMessage(this.getLanguageResource('13242', 'F', '', '이전 입력결과가 다릅니다.'), 2000);
          } else {
            this.showCompareResultWarning();
          }
          this.set('isABOChanged', false);

        } else {
          this._goWarningConfirmNext();
        }
        this.set('isSaveDisabled', false);
        this.set('isDetailCheckDisabled', false);
      } catch(e) {
        this._showError(e);
      }
    },

    async _setResultRemark() {
      try {
        const results = await this.observationExamplesByResultRemark({exampleTypeCode: 'ResultRemark'});
        const emptyExaminationItems = [];
        if(isPresent(results)) {
          results.forEach(datas => {
            if(isEmpty(datas.examinationId)) {
              emptyExaminationItems.push({content: datas.value.valueString});
            }
          });
        } else {
          this.showWarningMessage(this.getLanguageResource('tempkey', 'F', '', '혈액형 검사 결과 예문 등록 여부를 확인하세요.'), 2000);
        }
        this.set('examplesResultRemarks', emptyExaminationItems);
      } catch(e) {
        this.set('isBloodTypeEntryShowLoader', false);
      }
    },

    async showCompareResultWarning() {
      const message = this.getLanguageResource('11050', 'F', null, '이전 입력결과가 다릅니다 저장하시겠습니까?');
      const result = await this.showConfirmMessage(message);
      if (result === 'Yes') {
        // this._saveBeforeAction();
        this._goWarningConfirmNext();
      } else {
        this.set('isDetailEntryChecked', false);
      }
      return result;

    },

    _goWarningConfirmNext() {
      const isChecked = this.get('isDetailEntryChecked');
      if (isChecked) {
        this.set('isDetailEntry', isChecked);
        this.set('isShowMainSave', !isChecked);
      } else {
        this._saveBeforeAction();
      }
    },

    _saveBeforeAction() {
      if (this.get('statusCode') === 'final' || this.get('statusCode') === 'corrected') {
        this.set('isCorrectReasonEntryOpened', true);
      } else {
        this._saveBloodTypes();
      }
    },

    async _saveBloodTypes() {
      this.set('contentLoaderType', 'progress');
      this.set('loaderDimed', true);
      this.set('isBloodTypeEntryShowLoader', true);
      try {
        const selectedAboItem = this.get('model.selectedAboItem');
        let aboResult = {code: null, name: null};
        if(!isEmpty(selectedAboItem) && selectedAboItem.code !== 'directInput') {
          aboResult = selectedAboItem;
        }
        const params = {
          checkInId: this.get('resultWorkInfo.checkInId'),
          specimenId: this.get('resultWorkInfo.specimenId'),
          aboResultCode: aboResult.code,
          aboResultName: aboResult.name,
          aboResultContent: this.get('aboResultContent'),
          aboRecordNoteId: this.get('recordNoteId'),
          isCell: this.get('bloodTypeGroupValue') === 'bloodCell' ? true : false,
          isDirectInput: selectedAboItem.code === 'directInput' ? true : false,
          rhResultCode:  this.get('model.selectedRhItem.code'),
          rhResultName: this.get('model.selectedRhItem.name'),
          remark: this.get('model.resultRemark'),
          issuedStaffId: this.get('globalCurrentUser.employeeId'),
          observationResultChange: {
            reasonCode: this.get('model.resultReason.reasonCode'),
            reasonContent: this.get('model.resultReason.reasonContent')
          }
        };
        await this.get('btService').createBloodTypes(params);
        this.get('co_ContentMessageService').sendMessage('__main_patient_information_refresh', 'refresh');
        this.get('co_ContentMessageService').sendMessage('test_result_viewer_refresh_specimen');
        this.get('co_ContentMessageService').sendMessage('updateMessage', 'D');
        this.showToastSaved();
        this._init();
      } catch(e) {
        this.set('isBloodTypeEntryShowLoader', false);
        this._showSaveError(e);
        console.log('_saveBloodTypes Error::: ', e);
      }
    },
    goResultReasonBySaveAction() {
      this._saveBloodTypes();
    },

    _isEmptyABO() {
      if(isEmpty(this.get('model.selectedAboItem')) ||
      (isEmpty(this.get('model.selectedRhItem')) && this.get('bloodTypeGroupValue') !== 'serum')) {
        return true;
      } else {
        return false;
      }
    },

  });