/* eslint-disable max-lines */
/* eslint-disable chis/require-template-convention */
/* eslint-disable complexity */
/* eslint-disable no-console */
import { A } from '@ember/array';
import moment from 'moment';
import $ from 'jquery';
import { next } from '@ember/runloop';
import EmberObject, { set } from '@ember/object';
import { hash, Promise } from 'rsvp';
import { isEmpty, isPresent } from '@ember/utils';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import { task, waitForProperty } from 'ember-concurrency';
import PrintMixin from 'specimenexaminationreport-module/mixins/specimen-examination-report-print-mixin';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MessageMixin, PrintMixin,
  {
    layout,
    // 2. Property Area
    defaultUrl: null,
    specimenexaminationreportService: service('specimen-examination-report-service'),
    specimenSamplingService: service('specimen-sampling-service'),
    specimenCheckInService: service('specimen-check-in-service'),
    resultListColumns: null,
    resultListItemsSource: null,
    resultListSelectedItem: null,
    returnTextRecordId:null,
    // equipRemark: null,
    isDeptCommentsHistoryOpen: null,
    currentUser: null,
    workListParams: null,
    isQuantityEntryOpen: null,
    isConceptEntryOpen: null,
    quantityComparator: null,
    currentItem: null,
    tat: null,
    tatItemsSource: null,
    tatSelectedValue: null,
    isDiffEntryOpen: null,
    _gridControl: null,
    _currentCell: null,
    commentsListSelectedItem: null,
    remark: null,
    previousItem: null,
    isInappropriateRegistrationModalOpen: null,
    comments: null,
    initializeTimeVolume: null,
    isTimeVolumeShow: null,
    isResultCommentPopupOpen: null,
    editReasonSelectedItem: null,
    showTransfusionHistoryBtn: null,
    printPopup:null,
    printConfig:null,
    printContent:null,
    hasChanged: null,
    isResultReadOnly:null,
    gridEditEnd: true,
    saveClick: false,
    isSaveButtonDisabled: false,
    isNotVerifyClick: false,
    isAllResultCommentPopupOpen: false,
    isAlertLoaderShow: false,
    isAlertOpen: false,
    // 3. Lifecycle hooks Area
    //For State Management
    onPropertyInit(){
      this._super(...arguments);
      this.set('viewId','specimen-examination-report-general-result-management');
      //Set Stateful properties
      this.setStateProperties([
        'defaultUrl', 'menuClass', 'currentUser',
        'specimenNumber',
        'resultListColumns', 'resultListItemsSource', 'resultListSelectedItem',
        'returnTextRecordId',
        'workListParams',
        'quantityComparator',
        'currentItem',
        'tat', 'tatItemsSource',
        '_gridControl', '_currentCell',
        'previousItem',
        'comments',
        'loaderType',
        'initializeTimeVolume', 'isTimeVolumeShow',
        'hasChanged',
        'showTransfusionHistoryBtn',
        'gridEditable',
        'gridDisabled',
        'isSetResultComment',
        // 'isResultReadOnly'
      ]);
      if (this.hasState() === false) {
        //Initialize Stateful properties
        this._initialize();
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport') + `specimen-examination-report/v0/`);
        this.set('checkinUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimencheckin')+'specimen-checkin/v0/');
        this.set('currentUser', this.get('co_CurrentUserService.user'));
        if(!isEmpty(this.getOpenMenuParams())){
          this._setWorkListParams(null, null);
          this.set('specimenId', null);
        }else if(!isEmpty(this.get('co_PatientManagerService.selectedPatient.examination.specimenId'))){
          this.set('specimenId', this.get('co_PatientManagerService.selectedPatient.examination.specimenId'));
          this._setWorkListParams('specimenId', this.get('co_PatientManagerService.selectedPatient.examination.specimenId'));
        }
        this.set('isResultReadOnly', false);
        this._setGridColumns();
        this.set('currentDate', this.get('co_CommonService').getNow());
        this.set('comments', {isCommentsExpanded: false, deptCommentsCount: 0, notification:false});
        this.set('contextMenuSource', [
          { action : this._openChangesLog.bind(this), text : this.getLanguageResource('14394', 'F','Edit History'), display : true},
          { action : this.actions.onNotProgress.bind(this), text : this.getLanguageResource('13260', 'F', '', '검사진행불가'), display : true, alias: 'notProgress'},
          { action : this.actions.onReTest.bind(this), text : this.getLanguageResource('6530', 'F', '', '재검'), display : true, alias: 'reTest'},
        ]);
        this.set('editReasonSelectedItem', null);
        this.set('changeReasonRemark', null);
        this.set('loaderType', 'spinner');
        this.set('hasChanged', false);
        this.set('cvrItem', []);
        this.set('showTransfusionHistoryBtn', false);
        this.set('numericOptions',"decimal",{});
        // this.set('gridEditable', false);
        this.set('impossibleExamination', this.getLanguageResource('13261', 'S', '', '검사불가능'));
        this.set('alertItemsSource', []);
        this.set('alertColumns', [
          { title: this.getLanguageResource('16920', 'S','Exam Name'), field: 'name',bodyTemplateName: 'tooltip', tooltipField: 'displayCode', width: 170},
          { title: this.getLanguageResource('17309', 'S', '', '비교검사항목'), field: 'comparedName',bodyTemplateName: 'tooltip', tooltipField: 'comparedDisplayCode', width: 170,},
          { title: this.getLanguageResource('17310', 'S', '', '경고 메세지'), field: 'content',bodyTemplateName: 'contentTooltip', tooltipField: 'content', width: 450,},
        ]);
      }
      //Initialize Stateless properties
    },
    _setGridColumns(){
      this.set('resultListColumns', [
        // { title: this.getLanguageResource('16919', 'S','Exam Code'), field: 'examination.displayCode',  width: 70, readOnly: true, align: 'center'},
        { title: this.getLanguageResource('13262', 'S', '', '검증제외'), field: 'isNotVerify', type: 'boolean', width: 65, align: 'center', readOnly:false},
        { title: this.getLanguageResource('16920', 'S','Exam Name'), field: 'examination.name',bodyTemplateName: 'orderNameTooltip', width: 170, readOnly: true},
        { title: this.getLanguageResource('890', 'F','Result'), field: 'valueValueString', bodyTemplateName: 'resultEntry', readOnly:this.get('isResultReadOnly'), width: 120, align: 'center'},
        { title: this.getLanguageResource('7387', 'F','Recent Result'), field: 'recentResult', bodyTemplateName: 'recentResultComments', width: 120, readOnly: true, align: 'center'},
        { title: this.getLanguageResource('14749', 'F','', '참고'), field: 'interpretation.code', bodyTemplateName: 'interpretation', width: 40, readOnly: true, align: 'center'},
        { title: 'D', field: 'check.isDelta', bodyTemplateName:'delta', align: 'center', width: 35, readOnly: true},
        { title: 'P', field: 'check.isPanic', bodyTemplateName:'panic', align: 'center', width: 35, readOnly: true},
        { title: 'C', field: 'check.isCritical', bodyTemplateName:'critical', align: 'center', width: 35, readOnly: true},
        { title: 'A', field: 'check.isNotAnalyticalMeasurementRange', bodyTemplateName:'amr', align: 'center', width: 35, readOnly: true},
        { title: this.getLanguageResource('6530', 'F','재검'), field: '', bodyTemplateName: 'reTest', width: 45, align: 'center', readOnly: true},
        { title: this.getLanguageResource('10109', 'S','','참고치'), field: 'referenceRange', bodyTemplateName: 'referenceRange', width: 130, readOnly: true, align: 'center'},
        // { title: '72', field:'check.isRecentCritical', bodyTemplateName:'recentCritical', align: 'center', width: 35, readOnly: true},
        { title: this.getLanguageResource('3452', 'F','Status'), field: 'statusName',align: 'center', width: 90, readOnly: true, bodyTemplateName: 'statusNameColor'},
        { title: this.getLanguageResource('833', 'F','Verified Date'), field: 'issuedDatetime', type: 'date', dataFormat: 'd', width: 90, readOnly: true, align: 'center'},
        { title: this.getLanguageResource('6513', 'S','Equipment'), field: 'deviceCode', width: 90, readOnly: true, align: 'center'},
        { title: this.getLanguageResource('906', 'S','Result Comment'), field: 'remark', bodyTemplateName: 'resultComments', width:100, focusableIndex:1, align: 'center'},
        { title: this.getLanguageResource('7388', 'S', '','최근결과비고'), field: 'recentRemark', bodyTemplateName: 'recentRemarkComments', width:140, align: 'center'},
        { title: this.getLanguageResource('9514', 'S','장비비고'), field: 'deviceRemark', bodyTemplateName: 'tooltip', width:100},
      ]);
    },
    _openChangesLog(e){
      if(isEmpty(e.dataItem.item)){
        return;
      }
      this.set('isChangesLogOpened', true);
      this.set('item', e.dataItem.item);
      this.set('changesLogTarget', e.originalEvent.currentTarget);

    },
    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1360');
      if (this.hasState() === false) {
        const defaultUrl = this.get('defaultUrl');
        hash({
          businessCodes: this.getList(defaultUrl + 'business-codes/search', null,{classificationCodes: ['QuantityComparator','TatSearchCode','CVRReason']}, false),
        }).then(function(result) {
          const quantityComparator= [];
          const tatItemsSource= [];
          const cvrReasonItemList= [];
          result.businessCodes.forEach(e=>{
            if(e.classificationCode == 'QuantityComparator'){
              quantityComparator.addObject(e);
            }else if(e.classificationCode == 'TatSearchCode'){
              tatItemsSource.addObject(e);
            }else if(e.classificationCode == 'CVRReason'){
              cvrReasonItemList.addObject(e);
            }
          });
          this.set('quantityComparator', quantityComparator);
          this.set('tatItemsSource', tatItemsSource);
          if(!isEmpty(cvrReasonItemList)){
            cvrReasonItemList.map(item =>{
              set(item, 'businessCode', item.code);
              return item;
            });
          }
          this.set('cvrReasonItemList', cvrReasonItemList);
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      }
    },
    didInsertElement() {
      this._super(...arguments);
      this.get('co_ContentMessageService').subscribeMessage('returnTextResultToGeneralResult', this.get('currentMenuId'), this, this.returnTextResult);
    },

    willDestroyElement() {
      this._super(...arguments);
      this.get('co_ContentMessageService').unsubscribeMessage('returnTextResultToGeneralResult', this.get('currentMenuId'), this, this.returnTextResult);
    },

    //Text-Result 화면 결과입력 이후 Call-Back Message
    returnTextResult(params){
      this.set('returnTextRecordId', params);
      this._getResultList(null);
    },

    onOpenMenuParamsChanged(e){
      this._super(...arguments);
      this.set('hasChanged', false);
      this.get('menuParamsChangedYield').perform(e);
    },

    menuParamsChangedYield: task(function * (e) {
      //메뉴오픈시
      yield waitForProperty(this, 'hasChanged', false);
      this._initialize();
      this.set('specimenNumber', null);
      this.set('resultListItemsSource', null);
      this._setWorkListParams(e, null);
      yield waitForProperty(this, 'otherTask.isIdle');
    }),

    changeReasonYield: task(function * () {
      //수정사유입력 팝업
      yield waitForProperty(this, 'editReasonSelectedItem.code');
      //editReasonSelectedItem있어야 진행
      this.continuePatientChanging();
      this.set('editReasonSelectedItem', null);
      yield waitForProperty(this, 'otherTask.isIdle');
    }),

    onBeforePatientChange(){
      this._super(...arguments);
      //환자변경 메세지
      if(this.get('hasChanged')){
        return false;
      }else{
        this._initialize();
        this.set('specimenNumber', null);
        this.set('resultListItemsSource', null);
        this.set('hasChanged', false);
        return true;
      }
    },
    onPatientChange(changeable) {
      this._super(...arguments);
      if(changeable===false){
        const options = {
          'caption': this.getLanguageResource('10251', 'F', '환자 선택 변경 진행중'),
          'messageBoxButton': 'YesNoCancel',
          'messageBoxImage': 'question',
          'messageBoxText': `[ ${this.get('menuTitle')} ]<br>` + this.getLanguageResource('9231', 'F', '저장되지 않은 데이터가 있습니다.')
          + `<br>`+ this.getLanguageResource('8939', 'F', '저장하시겠습니까?'),
          'messageBoxFocus': 'Yes',
        };
        return messageBox.show(this, options).then(function (result){
          if(result == 'Yes'){
            //save

            const currentDatetime= this.get('co_CommonService').getNow();
            if(this.get('workListParams.progressStatusCode')=="Checkin"){
              this._setSaveParams('preliminary', null, currentDatetime);
            }else {
              this._setSaveParams('final', null, currentDatetime);
            }
            next(this, function(){
              this.get('changeReasonYield').perform();
            }.bind(this));
          }else if(result ==='No'){
            this.continuePatientChanging();
            this.set('hasChanged', false);
          }else if(result ==='Cancel'){
            this.cancelPatientChanging();
            this.set('hasChanged', false);
          }
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      }
      return changeable;
    },
    onPatientChanged(pateint){
      this._super(...arguments);
      this.set('specimenNumber', null);
      this.set('resultListItemsSource', null);
      this.set('hasChanged', false);
      this._initialize();
      if(this.checkPatientDataClear() === true) {
        return;
      }
      if(isEmpty(pateint)) {
        return;
      }
      if(!isEmpty(pateint.examination) && !isEmpty(pateint.examination.specimenId)){
        this.set('specimenId', pateint.examination.specimenId);
        this._setWorkListParams('specimenId', pateint.examination.specimenId);
      }
    },

    // 4. Actions Area
    actions: {
      returnTimeVolumeShow(isTimeVolumeShow){
        this.set('isTimeVolumeShow', isTimeVolumeShow);
      },
      onOpenPopupAction() {
        this.set('isPopupOpen', true);
      },
      onOpenCenterAction() {
        this.set('isCenterOpen', true);
      },

      onTransfusionhBtnClick(e){
        if(isEmpty(this.get('workListParams.subjectId')) || isEmpty(this.get('resultListItemsSource'))){
          return;
        }
        this.set('patientId', this.get('workListParams.subjectId'));
        this.set('isTransfusionInfoPopupOpen', true);
        this.set('transfusionInfoTarget', e.originalEvent.currentTarget);
      },
      onCommentBtnClick(e){
        this.toggleProperty('initializeTimeVolume');
        this.set('isCommentOpen', true);
        this.set('commentPopupTarget', e.originalEvent.currentTarget);
      },
      onSendCvrClick(){
        const resultListSelectedItem= this.get('resultListSelectedItem');
        if(isEmpty(resultListSelectedItem)){
          this.get('specimenexaminationreportService')._showMessage( this.getLanguageResource('9260', 'F','Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
          return false;
        }else if(resultListSelectedItem.statusCode != 'final' && resultListSelectedItem.statusCode != 'corrected'){
          this.get('specimenexaminationreportService')._showMessage( this.getLanguageResource('13243', 'F', '','결과 검증된 검사만 CVR전송이 가능합니다'), 'warning', 'Ok', 'Ok', '', 2000);
          return false;
        }else if(resultListSelectedItem.isUpdated == true){
          this.get('specimenexaminationreportService')._showMessage( this.getLanguageResource('10277', 'F','저장되지 않은 내역이 있습니다'), 'warning', 'Ok', 'Ok', '', 2000);
          return false;
        }else if(resultListSelectedItem.valueTypeCode == 'ValueTextString'){
          this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('10746', 'F', '', 'CVR대상 검사가 아닙니다. '), 'warning', 'Ok', 'Ok', '', 2000);
          return false;
        }else if(resultListSelectedItem.check.isCritical){
          this._sendCvr();
        }else{
          this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('10746', 'F', '', 'CVR대상 검사가 아닙니다. ')+ '<br>' + this.getLanguageResource('10747', 'F', 'CVR을 전송하시겠습니까?'),
            'question', 'YesNo', 'Yes', '', null).then(function(result){
            if(result === 'Yes'){
              this._sendCvr();
            }
          }.bind(this)).catch(function(error){
            this._catchError(error);
          }.bind(this));
        }
      },

      onSpecimenNumberCommit(){
        this.set('comments', {isCommentsExpanded: false});
        this._initialize();
        this.set('isSaveButtonDisabled', false);
        this.set('resultListItemsSource', null);
        this._setWorkListParams('Commit', null);
      },

      onBeforeMouseDown(e){
        this.set('isResultReadOnly', true);
        if(e.source.getCurrentCell().column=='resultEntry'){
          this.set('isQuantityEntryOpen', false);
          this.set('isConceptEntryOpen', false);
          this.set('isStringEntryOpen', false);
          return;
        }
        if(this.get('previousItem.examination.name') !=this.get('currentItem.examination.name')){
          this.set('isQuantityEntryOpen', false);
          this.set('isConceptEntryOpen', false);
          this.set('isStringEntryOpen', false);
        }
        this.set('isResultCommentPopupOpen', false);
      },

      async onGridKeyDown(e){
        // const resultListSelectedItem = this.get('resultListSelectedItem');
        const resultListSelectedItem = this.get('selectedCellItem');
        if(isEmpty(e.key) || isEmpty(resultListSelectedItem)){
          return;
        }
        if(resultListSelectedItem.valueTypeCode != 'CodeableConcept'){
          return;
        }

        if(e.key =='Alt'){
          this.set('isFunctionKey', true);
          return;
        }
        if(this.get('isFunctionKey')){
          // this.set('isResultGridShow', true);
          await this.getList(this.get('defaultUrl') + 'observations/examples',
            {exampleTypeCode: 'ExampleValue', examinationId: resultListSelectedItem.examinationId}, null).then(res=>{
            // this.set('defaultvalue', res.findBy('exampleTypeCode', 'DefaultResultValue'));
            this.set('defaultvalues', res);
          }).catch(function(error){
            this._catchError(error);
          }.bind(this));

          this.set('isFunctionKey', false);
          const defaultvalues= this.get('defaultvalues');
          if(isEmpty(defaultvalues)){
            return;
          }
          defaultvalues.forEach(v=>{
            if(isEmpty(v.functionApply)){
              return;
            }
            if(isEmpty(v.get('functionApply.displayCode'))){
              return;
            }
            if((v.exampleTypeCode == "ExampleValue")
              && v.get('functionApply.displayCode').slice(v.get('functionApply.displayCode').indexOf('+')+1).toLocaleUpperCase() == e.key.toLocaleUpperCase()){
              //'alt' 제거한 문자로 비교
              set(resultListSelectedItem, 'value', v.value);
              set(resultListSelectedItem, 'valueValueString', this.get('specimenexaminationreportService')._setValueString(v));
              set(resultListSelectedItem, 'numericCellInputValue', this.get('specimenexaminationreportService')._setValueString(v));
              set(resultListSelectedItem , 'isValueChanged', true);
            }
          });
          if(resultListSelectedItem.isValueChanged){
            this._calculate("Rule").then(function(){
              // this.set('resultListSelectedItem', null);
              this._moveFocus('down', false);
            }.bind(this));
          }
        }
      },

      onCellClick(e){
        if(isEmpty(e.item)){
          return;
        }
        console.log('onCellClick--', e);
        this.set('selectedCellItem', e.item);
        // set(e.item, 'isNotVerify', !e.item.isNotVerify);
        const selectedGridItmes = this.get('selectedGridItmes');
        let filterItems = null;
        if(e.column.field === 'isNotVerify') {
          this.set('isNotVerifyClick', true);
          if(!e.item.isNotVerify) {
            e.source.deselectRow(e.item);
            if(!isEmpty(selectedGridItmes)) {
              filterItems = selectedGridItmes.filter(d => d.observationResultId !== e.item.observationResultId);
            }
          } else {
            filterItems = selectedGridItmes;
          }
          if(!isEmpty(filterItems)) {
            if(selectedGridItmes.length === 1 && !selectedGridItmes[0].isNotVerify) {
              // e.source.selectRow(e.item);
            } else {
              e.source.selectRows(filterItems);
            }
          }
        } else {
          this.set('isNotVerifyClick', false);
          e.source.deselectAll();
          e.source.selectRow(e.item);
        }
        this.set('isResultReadOnly', true);
        this.set('currentItem', e.item);
        const bodyTemplateName = e.column.bodyTemplateName;
        const currentItem= this.get('currentItem');
        if(bodyTemplateName ==='resultEntry'){
          switch(currentItem.valueTypeCode){
            case 'Quantity':
              //바로 입력가능하게 수정
              if(isEmpty(currentItem.valueValueString)){
                this.set('gridEditable', true);
                // this.set('disabled', false);
                // this.set('isResultReadOnly', false);
                set(currentItem, 'isCellClick', true);
              }else{
                this.set('gridEditable', false);
                // this.set('disabled', true);
                // this.set('isResultReadOnly', true);
                // this.set('gridDisabled', true);
                // this.set('isQuantityEntryOpen', true);
              }
              break;
            case 'CodeableConcept':
              this.set('isConceptEntryOpen', true);
              break;
            case 'ValueString':
              this.set('isStringEntryOpen', true);
              break;
            case 'ValueTextString':
              //RecordType코드가 없는경우는 단순 String입력 창 오픈
              // if(isEmpty(currentItem.get('value.recordNoteId'))){
              //   this.set('isStringEntryOpen', true);
              // }
              break;
            default:
              break;
          }
        }else if(bodyTemplateName=='resultComments'){
          this.set('isSetResultComment', false);
          this.set('isAllResultCommentPopupOpen', false);
          this.set('isResultCommentPopupOpen', true);
          this.set('commentPopupTitleResource', `${this.getLanguageResource('906', 'S','결과비고')} - ${e.item.examination.name}`);
          this.set('commentPopupPlacementTarget', `#${e.originalSource.elementId}`);
          this.set('remark', e.item.comment);
        }
      },
      onGridContextMenuOpen(e) {
        const item = e.dataItem.item;
        if(isEmpty(item)) {
          set(e, 'cancel', true);
          return;
        }
        // const selectedItems = this.get('_gridControl.selectedItems');
        // let isReCheck = false;
        // if(isPresent(selectedItems)) {
        //   const finalItems = selectedItems.filter(d => d.statusCode === 'final' || d.statusCode === 'corrected');
        //   if(isPresent(finalItems)) {
        //     isReCheck = true;
        //   }
        // } else {
        //   isReCheck = true;
        // }
        // set(this.get('contextMenuSource').findBy('alias', 'reTest'), 'disabled', isReCheck);
        if(e.dataItem.item.statusCode === 'registered' || e.dataItem.item.statusCode === 'preliminary') {
          set(this.get('contextMenuSource').findBy('alias', 'reTest'), 'disabled', false);
        } else {
          set(this.get('contextMenuSource').findBy('alias', 'reTest'), 'disabled', true);
        }
        if(item.valueTypeCode === 'ValueTextString') {
          set(this.get('contextMenuSource').findBy('alias', 'notProgress'), 'disabled', true);
        } else {
          set(this.get('contextMenuSource').findBy('alias', 'notProgress'), 'disabled', false);
        }
      },
      onNotProgress(e) {
        if(isEmpty(e.dataItem.item)) {
          return;
        }
        if(e.dataItem.item.numericCellInputValue === this.get('impossibleExamination')) {
          return;
        }
        this.set('hasChanged', true);
        set(e.dataItem.item, 'isNotProgress', true);
        set(e.dataItem.item, 'isUpdated', true);
        set(e.dataItem.item, 'numericCellInputValue', this.get('impossibleExamination'));
      },
      onReTest() {
        const selectedItems = this.get('_gridControl.selectedItems');
        if(isEmpty(selectedItems)) {
          this.get('specimenexaminationreportService')._showMessage( this.getLanguageResource('9260', 'F','Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        const finalItems = selectedItems.filter(d => d.statusCode !== 'registered' && d.statusCode !== 'preliminary');
        if(isPresent(finalItems)) {
          this.showMessagebox(this.getLanguageResource('9288', 'F', '검사상태를 확인해주시기 바랍니다.'), '', 'warning');
          return;
        }
        if(isPresent(selectedItems)) {
          this._getReobservation();
          // this.get('resultListItemsSource').forEach(d => {
          //   const setItem = selectedItems.find(r => r.observationResultId === d.observationResultId);
          //   if(isPresent(setItem)) {
          //     set(d, 'isReTest', true);
          //   }
          // });
        } else {
          // set(e.dataItem.item, 'isReTest', true);
        }
      },
      onResultChangeCB(item) {
        const resultListItemsSource = this.get('resultListItemsSource');
        resultListItemsSource.forEach(d => {
          if(d.observationResultId === this.get('item.observationResultId')) {
            set(d, 'isValueChanged', true);
            set(d, 'value', item.value);
            set(d, 'valueTypeCode', item.valueTypeCode);
            set(d, 'numericCellInputValue', item.numericCellInputValue);
            set(d, 'valueValueString', item.valueValueString);
            set(d, 'check', item.check);
            set(d, 'numberValue', null);
            set(d, 'interpretation', item.interpretation);
            set(d, 'isUpdated', item.isUpdated);
            set(d, 'isValueChanged', false);
            set(d, 'isCleared', false);
          }
        });
        this.set('closedByKeyDown', false);
      },
      onGridSelectionChanged(e) {
        if(isEmpty(e.source.itemsSource)) {
          return;
        }
        e.source.itemsSource.forEach(item => {
          set(item, 'isNotVerify', false);
        });
        const selectedItems = e.selectedItems;
        this.set('selectedGridItmes', $.extend(true, [], selectedItems));
        if(!isEmpty(selectedItems)) {
          if(selectedItems.length === 1 && !this.get('isNotVerifyClick')) {
            set(selectedItems[0], 'isNotVerify', false);
          } else {
            selectedItems.forEach(item => {
              set(item, 'isNotVerify', true);
            });
          }
        }
      },

      onEditStart(e){
        this.set('_gridControl', e.source);
        this.set('gridEditEnd', false);
        // console.log('onEditStart   ' + this.get('previousItem.examination.name')+ '   /   ' + this.get('currentItem.examination.name'));
        this.set('previousItem', this.get('currentItem'));
      },

      onEditEnd(){
        this._cellEditEnd();
        // const previousItem= this.get('previousItem');
        // if(!isEmpty(previousItem)){
        //   if(previousItem.isCellClick && previousItem.isValueChanged ){
        //     //수치형 바로 입력후 엔터
        //     if(this.get('resultListItemsSource').length ==this.get('_currentCell').rowIndex +1){
        //       //마지막 row일때는 안탐
        //       // return;
        //     }
        //     // set(previousItem, 'value.quantity.value', previousItem.valueValueString);
        //     set(previousItem, 'value.quantity.value', previousItem.numericCellInputValue);
        //     set(previousItem, 'value.quantity.comparator', '-');
        //     set(previousItem , 'isValueChanged', true);
        //     this.set('gridDisabled', true);
        //     this.get('specimenexaminationreportService')._calculate("Rule", true, previousItem, this.get('resultListItemsSource')).then(resultListItemsSource=>{
        //       this.set('gridDisabled', false);
        //       // this.set('gridEditable', true);
        //       if(!isEmpty(resultListItemsSource)){
        //         this.set('resultListItemsSource', resultListItemsSource);
        //       }
        //       this.set('gridEditEnd', true);
        //       if(this.get('saveClick')) {
        //         this._setSaveParams('final', null, this.get('co_CommonService').getNow());
        //       }
        //     }).catch(function(error){
        //       this._catchError(error);
        //       set(previousItem , 'isValueChanged', false);
        //       // this.set('previousItem', null);
        //     }.bind(this));
        //     set(previousItem, 'isCellClick', false);
        //     this.set('isClosed', true);
        //   }else{
        //     //값변경없는 경우
        //     // console.log('값변경없는 경우');

        //     set(previousItem, 'numericCellInputValue', this.get('specimenexaminationreportService')._setValueString(previousItem));
        //     this.set('gridEditEnd', true);
        //     console.log(previousItem.numericCellInputValue);
        //   }

        // }
      },
      onBeforeKeyDown(e) {
        const type = this.get('specimenexaminationreportService').getKeyBoardEventType(e.originalEvent);
        const currentItem= this.get('currentItem');
        this.set('isResultCommentPopupOpen', false);
        if(type === 'edit') {
          if(isEmpty(e.source.getOriginalSource(e.originalEvent).column)){
            return;
          }
          const bodyTemplateName= e.source.getOriginalSource(e.originalEvent).column.bodyTemplateName;
          if(bodyTemplateName=='resultEntry'){
            this._setCurrentCell(e);
            if(currentItem.valueTypeCode=='Quantity'){
              set(currentItem , 'isKeydown', true);
              set(currentItem , 'key', e.originalEvent.key);
              // this.set('isQuantityEntryOpen', true);
            }else if(currentItem.valueTypeCode== 'CodeableConcept'){
              this.set('isConceptEntryOpen', true);
            }else if(currentItem.valueTypeCode== 'ValueString'
            ||(currentItem.valueTypeCode== 'ValueTextString' && isEmpty(currentItem.value.recordNoteId))){
              set(currentItem , 'isKeydown', true);
              set(currentItem , 'key', e.originalEvent.key);
              this.set('isStringEntryOpen', true);
            }
          }
        }else if(type === 'enter'){
          //수치형 바로 입력후 엔터 마지막 row
          if(this.get('resultListItemsSource').length == this.get('_currentCell').rowIndex +1){
            this.get('_gridControl').focusCell(this.get('_currentCell.rowIndex'), this.get('_currentCell.cellIndex')+1);
          }
        }

      },

      onNumericCellValueChanged(resultListSelectedItem){
        if(!isEmpty(resultListSelectedItem)){
          set(resultListSelectedItem, 'isValueChanged', true);
        }
      },

      onNumericCellKeyUp(item, e){
        // if(!isEmpty(this.get('resultListSelectedItem'))){
        //   set(this.get('resultListSelectedItem'), 'isCellClick', true);
        //   if(event.keyCode === 8 || event.keyCode === 46) {
        //     set($(`#${e.source.elementId}`).find('input')[0], 'placeholder', ' ');
        //   }
        //   set(this.get('resultListSelectedItem'), 'numericCellInputValue', e.source.value);
        // }
        if(!isEmpty(item)){
          set(item, 'isCellClick', true);
          if(event.keyCode === 8 || event.keyCode === 46) {
            set($(`#${e.source.elementId}`).find('input')[0], 'placeholder', ' ');
          }
          set(item, 'numericCellInputValue', e.source.value);
        }
      },

      onNumericCellClick(item, e){
        // if(!isEmpty(this.get('resultListSelectedItem'))){
        //   set(this.get('resultListSelectedItem'), 'numericCellInputValue', e.source.value);
        // }
        set(item, 'numericCellInputValue', e.source.value);
        set(item, 'isCellClick', true);
      },
      onCellDoubleClick(e){
        if(e.column.bodyTemplateName =='resultEntry'){
          if(e.item.valueTypeCode === 'Quantity'){
            if(e.item.isNotProgress) {
              set(e , 'item.key', e.item.value.quantity.value);
              set(e, 'item.isCellClick', false);
            } else if(e.item.isCellClick){
              set(e , 'item.key', e.item.numericCellInputValue);
              // set(e , 'item.value.quantity.value', e.source.selectedItem.numericCellInputValue);
              set(e, 'item.isCellClick', false);
            }
            // if(e.item.isCellClick){
            //   set(e , 'item.key', e.source.selectedItem.numericCellInputValue);
            //   // set(e , 'item.value.quantity.value', e.source.selectedItem.numericCellInputValue);
            //   set(e, 'item.isCellClick', false);
            // }
            this.set('isQuantityEntryOpen', true);
          }else if(e.item.valueTypeCode === 'ValueTextString'){
            if(e.column.field ==='valueValueString'){
              this._openTextResultManagement(e);
            }
          }else if(e.column.field ==='examination.name'){
            this._openTextResultManagement(e);
          }
        }
      },

      onGridLoad(e) {
        this.set('_gridControl', e.source);
        this.set('gridSource', e.source);
        // const gridControl = this.$('div[name=specimen-examination-report-general-result-management_grid]').children('.fr-grid');
        // const container = gridControl.children('.fr-grid-body-container');
        const container = $(`#${e.source.elementId}`).children('.c-grid-body-container');
        const scrollTarget = container.children().eq(1);
        this.set('_scrollTarget', scrollTarget);
        scrollTarget.on('scroll', function(evt) {
          evt.preventDefault();
          evt.stopPropagation();
        });
      },
      onGridUnload() {
        this.get('_scrollTarget').off();
      },

      onBeforeFocusIn(e) {
        this.set('isResultReadOnly', true);
        this.set('_gridControl', e.source);
        if(e.type.includes('body')) {
          if(e.type.includes('cell')) {
            // console.log('onBeforeFocusIn   ' + this.get('previousItem.examination.name') + '   /   ' + this.get('currentItem.examination.name'));
            this.set('currentItem', e.source.getOriginalSource(e.originalEvent).item);
            this._setCurrentCell(e);
            e.cancel = true;
          }
        }

        if(e.type.includes('body')) {
          if(e.type.includes('ghead')) {
            if(e.type.includes('expander')) {
              e.source.deselectAll();
            }
          }
        }
      },

      onScroll(){
        this.set('isQuantityEntryOpen', false);
        this.set('isConceptEntryOpen', false);
      },

      // onGridSelectionChanged(e){
      //   const cell = e.selectedCells.get('firstObject');
      //   if(isEmpty(cell)) {
      //     return;
      //   }
      //   this.set('cellIndex', e.source.getColumnIndex(cell.column));
      // },

      returnResultValueCB(){
        this.set('hasChanged', true);
        this._moveFocus('down', false);
        // this.set('gridEditable', true);

      },

      returnCalculatedValueCB(){
        this.set('hasChanged', true);
        // this.set('gridEditable', true);
      },

      onReturnResultCommentsCB(resultComments){
        this.set('hasChanged', true);
        let tmp =resultComments;
        if(isEmpty(resultComments)){
          //초기화 시킬경우
          // this.set('isResultCommentPopupOpen', false);
          // return;
        }
        if(this.get('isSetResultComment')){
          //결과비고 일괄입력
          if(isEmpty(this.get('resultListItemsSource'))){
            return;
          }
          this.get('resultListItemsSource').forEach(currentItem=>{
            if(isEmpty(resultComments)){
              // tmp= isEmpty(currentItem.remark)? resultComments : currentItem.remark;
            }else{
              tmp= isEmpty(currentItem.remark)? resultComments : currentItem.remark + ' / ' + resultComments;
            }
            set(currentItem , 'remark', tmp);
            set(currentItem , 'remarkTooltip', tmp);
            // set(currentItem , 'selectedResultComments', resultComments);
            set(currentItem , 'isUpdated', true);
            const editItem= currentItem;
            set(editItem , 'remark', tmp);
          });
        }else{
          const currentItem= this.get('currentItem');
          // this._setREsultCommentByItem();
          set(currentItem , 'remark', resultComments);
          set(currentItem , 'remarkTooltip', resultComments);
          // set(currentItem , 'selectedResultComments', resultComments);
          set(currentItem , 'isUpdated', true);
          const editItem= currentItem;
          set(editItem , 'remark', resultComments);
        }
        this.set('isAllResultCommentPopupOpen', false);
        // this.set('isResultCommentPopupOpen', false);
      },

      onCalculateClick(param){
        if(param == 'Diff'){
          if(isEmpty(this.get('resultListItemsSource'))){
            return;
          }
          this.set('isDiffEntryOpen', true);
        }else if(param == 'Slide'){
          this._calculate("Slide");
        }else if(param == 'Stick'){
          this._calculate("Stick");
        }else if(param == 'Micro'){
          this._calculate("Micro");
        }
      },

      returnDiffValueCB(diffArr){
        this.set('hasChanged', true);
        const resultListItemsSource= this.get('resultListItemsSource');
        // const updatedItems=[];
        if(isEmpty(diffArr)){
          return;
        }
        diffArr.forEach(function(diffEntryItem){
          const tmp= resultListItemsSource.find(function(e){
            return e.examinationId == diffEntryItem.examinationId;
          });
          set(tmp , 'valueValueString', diffEntryItem.count < 1 ? 0 : diffEntryItem.count );
          set(tmp , 'numericCellInputValue', diffEntryItem.count < 1 ? 0 : diffEntryItem.count );
          set(tmp , 'value.quantity.value', diffEntryItem.count < 1 ? 0 : diffEntryItem.count);
          set(tmp , 'remark', diffEntryItem.value.valueString);
          set(tmp, 'remarkTooltip', isEmpty(diffEntryItem.value.valueString)? '' : diffEntryItem.value.valueString.replace(/\n|\r\n/giu, '<br>'));
          set(tmp , 'isUpdated', true);
          set(tmp , 'isValueChanged', true);
        });
        this.set('diffArr', diffArr);
        this._calculate("Rule");
      },

      returnChangesReasonCB(item, remark){
        if(!isEmpty(item)){
          // this.set('isCorrectReasonEntered', true);
          if(!isEmpty(remark)){
            this.set('changeReasonRemark', isEmpty(remark)? '': remark.replace(/<br>|<br\/>|<br \/>/giu, '\r\n'));
          }
          this.set('editReasonSelectedItem', item);
          this._goSaveResult();
          // this._setSaveParams('final', itemSource, this.get('co_CommonService').getNow());
        }
      },

      onResultsDraftClick(){
        this.set('draftClick', true);
        this.set('isSaveButtonDisabled', true);
        this._setSaveParams('preliminary', null, this.get('co_CommonService').getNow());
      },

      onResultsSaveClick(){
        this.set('saveClick', true);
        this.set('isSaveButtonDisabled', true);
        this._setSaveParams('final', null, this.get('co_CommonService').getNow());
      },
      onInappropriateSpecimenRegistrationClick(){
        if (isEmpty(this.get('specimenNumber'))) {
          this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('10105', 'F', '검체번호를 확인하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
          return false;
        }
        this.set('inappropriateInfo', null);
        this.get('specimenCheckInService').getInappropriateInfo(this.get('workListParams.specimenId')).then(function(inappropriateInfo){
          if(!isEmpty(inappropriateInfo)){
            this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('10106', 'F', '이미 등록된 검체입니다. <br> 취소하고 다시 접수하시겠습니까?'),
              'question', 'YesNo', 'Yes', '', null).then(function(result){
              if(result === 'Yes'){
                this.set('isInappropriateRegistrationModalOpen', true);
                this.set('inappropriateInfo', inappropriateInfo);
              }
            }.bind(this));
          }else{
            this.set('isInappropriateRegistrationModalOpen', true);
          }
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      },

      onPrintBarcodeClick(){
        const workListParams= this.get('workListParams');
        if(isEmpty(workListParams)){
          return;
        }
        this.set('printouts', null);
        this.set('printDataFieldDefault', []);
        this.set('printDataFieldD', []);
        this.set('printDataFieldG', []);
        this.set('printDataFieldF', []);
        this.getPrinterName().then(function(res){
          this.set('printSetting', res);
          this._getSpecimenLabel(workListParams);
          next(this, function(){
            if(this.isDestroyed || this.isDestroying) {
              return;
            }
            this.set('printPopup', false);
            if(isEmpty(this.get('printDataFieldG')) && isEmpty(this.get('printDataFieldD')) && isEmpty(this.get('printDataFieldF'))){
              this.set('printConfig', {'printType': 1, 'printName': 'SpecimenLabel',
              // 'printerName': this.get('printerDefault')
                'printerName': this.get('printSetting').printerDefault
              });
              this.set('printContent', {
                'parameterField': {},
                'dataField': { "specimenInfo" : this.get('printDataFieldDefault')}});
              this.set('printDataFieldDefault' ,null);
              console.log(this.get('printConfig'));
              console.log(this.get('printContent'));
            }else{
              this._print();
            }
            const num= isEmpty(this.get('printouts'))? '': this.get('printouts');
            this.get('specimenexaminationreportService').onShowToast('save', this.getLanguageResource('7554', 'S', '출력매수') + ": \xa0"+ num, '',8000);
          }.bind(this));
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      },

      onCumulativeSearchBtnClick(){
        if(isEmpty(this.get('workListParams.subjectId')) || isEmpty(this.get('resultListItemsSource'))){
          return;
        }
        this.set('isSpecimenExamSummaryOpen', true);
        this.set('patientId', this.get('workListParams.subjectId'));
        this.set('examinationIds', this.get('resultListItemsSource').map(function(i){
          return i.examinationId;
        })
        );
      },

      onExePrintAfterCB(){
        this._print();
      },

      setResultComment(e){
        this.set('isSetResultComment', true);
        if(!isEmpty(this.get('_gridControl'))){
          this.get('_gridControl').deselectAll();
        }
        this.set('remark', null);
        this.set('_currentCell', null);
        this.set('isAllResultCommentPopupOpen', true);
        this.set('isResultCommentPopupOpen', false);
        this.set('commentPopupTitleResource', this.getLanguageResource('906', 'S','결과비고'));
        this.set('commentPopupPlacementTarget', e.originalEvent.currentTarget);
      },

      onLinkedInboxClick(){
        if(isEmpty(this.get('resultListSelectedItem')) || isEmpty(this.get('workListParams'))){

          this.get('specimenexaminationreportService')._showMessage( this.getLanguageResource('9260', 'F','Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        const items = this.getInboxParams(this.get('workListParams.specimenOrders.firstObject'), this.get('resultListSelectedItem'), this.getLanguageResource('9686', 'S', '처방의'));
        const checkInDateTime = moment(new Date(this.get('workListParams.checkInDateTime'))).format('YYYY-MM-DD HH:mm');
        items.examination.checkInDateTime = checkInDateTime;
        this.set('sendInformation', items);
        this.set('isInboxOpen', true);
      },
      onAlertOpened() {
        //
      },
      onAlertClosed() {
        this.set('alertItemsSource', []);
        //
      },
      onAlertConfirm() {
        this.set('alertConfirmed', true);
        this.set('isAlertOpen', false);
        this._goSaveResult();
      },
      onAlertCancel() {
        this.set('isSaveButtonDisabled', false);
        this.set('isAlertOpen', false);
      },
      onReasonEntryCancel() {
        this.set('isCorrectReasonEntryOpened', false);
        this.set('isSaveButtonDisabled', false);
      },
    },

    // 5. Private methods Area
    _print(){
      const printSetting= this.get('printSetting');
      if(!isEmpty(this.get('printDataFieldG'))){
        this.set('printConfig', {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerG });
        this.set('printContent', {
          'parameterField': {},
          'dataField': { "specimenInfo" : this.get('printDataFieldG')}});
        this.set('printDataFieldG' ,null);
        return;
      }
      if(!isEmpty(this.get('printDataFieldD'))){
        this.set('printConfig', {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerD });
        this.set('printContent', {
          'parameterField': {},
          'dataField': { "specimenInfo" : this.get('printDataFieldD')}});
        this.set('printDataFieldD' ,null);
        return;
      }
      if(!isEmpty(this.get('printDataFieldF'))){
        this.set('printConfig', {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerF });
        this.set('printContent', {
          'parameterField': {},
          'dataField': { "specimenInfo" : this.get('printDataFieldF')}});
        this.set('printDataFieldF' ,null);
        return;
      }
      if(!isEmpty(this.get('printDataFieldDefault'))){
        this.set('printConfig', {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerDefault });
        this.set('printContent', {
          'parameterField': {},
          'dataField': { "specimenInfo" : this.get('printDataFieldDefault')}});
        this.set('printDataFieldDefault' ,null);
      }
      console.log(this.get('printConfig'));
      console.log(this.get('printContent'));
    },

    async _cellEditEnd() {
      this.set('gridEditEnd', false);
      const previousItem = this.get('previousItem');
      try {
        if(!isEmpty(previousItem)){
          if(previousItem.isCellClick && previousItem.isValueChanged ){
            //수치형 바로 입력후 엔터
            if(this.get('resultListItemsSource').length ==this.get('_currentCell').rowIndex +1){
              //마지막 row일때는 안탐
              // return;
            }
            // set(previousItem, 'value.quantity.value', previousItem.valueValueString);
            set(previousItem, 'value.quantity.value', isEmpty(previousItem.numericCellInputValue)? null : previousItem.numericCellInputValue);
            set(previousItem, 'value.quantity.comparator', '-');
            set(previousItem , 'isValueChanged', true);
            set(previousItem , 'isNotProgress', false);
            this.set('gridDisabled', true);
            const resultListItemsSource = await this.get('specimenexaminationreportService')._calculate("Rule", true, previousItem, this.get('resultListItemsSource'));
            if(!isEmpty(resultListItemsSource)){
              this.set('resultListItemsSource', resultListItemsSource);
            }
            this.set('gridEditEnd', true);
            if(this.get('saveClick')) {
              this._setSaveParams('final', null, this.get('co_CommonService').getNow());
            }
            if(this.get('draftClick')){
              this._setSaveParams('preliminary', null, this.get('co_CommonService').getNow());
            }
            set(previousItem, 'isCellClick', false);
            this.set('isClosed', true);
            this.set('hasChanged', true);
          }else{
            //값변경없는 경우
            // console.log('값변경없는 경우');
            set(previousItem, 'numericCellInputValue', this.get('specimenexaminationreportService')._setValueString(previousItem));
            this.set('gridEditEnd', true);
            console.log(previousItem.numericCellInputValue);
          }
        }
      } catch(e) {
        this._catchError(e);
        set(previousItem , 'isValueChanged', false);
        set(previousItem, 'isCellClick', false);
        this.set('isClosed', true);
      }

    },
    _getSpecimenLabel(e){
      const printSetting = this.get('printSetting');
      // const printDataField = this.get('printDataField');
      this.get('specimenSamplingService').getSpecimenLabel(null, e.specimenNumber).then(res=>{
        if(!isEmpty(res)){
          this._setProperty(res);
          res.specimenTypes.forEach(function(r, idx) {
            this.set('printouts', this.get('printouts') + r.labelPrintCount);
            let specimenName = res.specimenTypes[idx].abbreviation;
            if(!isEmpty(res.specimenTypes[idx].containerName)){
              specimenName = specimenName + '(' + res.specimenTypes[idx].containerName + ')';
            }
            let u=0;
            while (u < r.labelPrintCount) {
              const resCopy= $.extend(true, EmberObject.create(), res);
              resCopy.specimenName= specimenName;
              if(res.progressTypeCode =="G"&& !isEmpty(printSetting.printerG)){
                if(printSetting.printerG == printSetting.printerDefault){
                  this.get('printDataFieldDefault').pushObject(resCopy);
                }else{
                  this.get('printDataFieldG').pushObject(resCopy);
                }
              }else if(res.progressTypeCode =="D" && !isEmpty(printSetting.printerD)){
                if(printSetting.printerD == printSetting.printerDefault){
                  this.get('printDataFieldDefault').pushObject(resCopy);
                }else{
                  this.get('printDataFieldD').pushObject(resCopy);
                }
              }else if(res.progressTypeCode =="F" && !isEmpty(printSetting.printerF)){
                if(printSetting.printerF == printSetting.printerDefault){
                  this.get('printDataFieldDefault').pushObject(resCopy);
                }else{
                  this.get('printDataFieldF').pushObject(resCopy);
                }
              }else{
                this.get('printDataFieldDefault').pushObject(resCopy);
              }
              u++;
            }
          }.bind(this));
        }
        // this.set('printDataField', printDataField);
      }).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    _sendCvr(e){
      const resultListSelectedItem = isEmpty(e)? this.get('resultListSelectedItem') : e;
      const workListParams = this.get('workListParams.specimenOrders.firstObject');

      if(isEmpty(resultListSelectedItem) || isEmpty(workListParams)){
        return;
      }
      if(isEmpty(workListParams.encounterId) || isEmpty(resultListSelectedItem.subjectId)){
        return;
      }
      this.set('isCvrOpen', true);
      this.set('cvrSendInformation', A({
        patient : { id: resultListSelectedItem.subjectId,
          displayCode: resultListSelectedItem.get('subject.displayNumber'),
          name: resultListSelectedItem.get('subject.name')},
        examination: {
          basedOnTypeCode: "Specimen",
          id:resultListSelectedItem.examination.id,
          basedOnId: resultListSelectedItem.specimenId,
          name: resultListSelectedItem.get('examination.name'),
          performDate: resultListSelectedItem.get('performers.firstObject.performDatetime'),
        },
        encounter:{ id: workListParams.encounterId},
        smsContent: null,
        staffs: [
          {
            actorTypeName: this.getLanguageResource('9686', 'S','처방의'),
            actorId:workListParams.orderedStaff.id,
            actorName: workListParams.orderedStaff.name
          }
        ],
        result: {value: resultListSelectedItem.valueValueString}
      }));
    },
    _initialize(){
      this.set('workListParams', null);
      // this.set('resultListItemsSource', null);
      this.set('resultListSelectedItem', null);
      this.set('equipRemark', null);
      this.set('currentItem', null);
      this.set('isQuantityEntryOpen', false);
      this.set('isConceptEntryOpen', false);
      this.set('isDiffEntryOpen', false);
      this.set('tat', null);
      this.set('specimenName', null );
      // this.set('tatSelectedValue', '3');
      this.set('_gridControl', null);
      this.set('_currentCell', null);
      this.set('isUpdate', false);
      this.set('comments', {
        isCommentsExpanded: false,
        deptCommentsCount: 0
      });
    },

    _openTextResultManagement(e){
      // const selectedItem = this.get('resultListSelectedItem');
      if(isEmpty(e)){
        return;
      }
      const selectedItem = e.item;
      this.get('specimenCheckInService').getDisplayView(selectedItem.specimenNumber, selectedItem.examinationId).then(function(res){
      // this.getList(this.get('defaultUrl') + '/specimen-examination-worklists/results/display-view',{specimenNumber: selectedItem.specimenNumber}, null).then(function(res){
        if(isEmpty(res)){
          this.get('specimenCheckinService')._showMessage('Display View Error', 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        let isPBS= false;
        const _menus = A([]);
        const temp = {
          specimenNumber: selectedItem.specimenNumber,
          examinationCode: selectedItem.examination.displayCode
        };
        res.forEach(element=> {
          // selectedItem.inputType = 'item';
          if(element.viewId == "specimen-examination-report-blood-cell-morphology"){
            isPBS = true;
            _menus.unshiftObject(Object.create({displayCode: element.viewId,parameters: temp}));
          }else{
            _menus.addObject(Object.create({displayCode: element.viewId,parameters: temp}));
          }

        });
        if(isPBS){
          // this.get('co_MenuManagerService').setActiveContent("specimen-examination-report-blood-cell-morphology");
          this.get('co_MenuManagerService').openSpecialMenus(_menus.reverse());
        }else{
          this.get('co_MenuManagerService').openSpecialMenus(_menus);
        }
        this.get('co_ContentMessageService').sendMessage('sendTextResult', temp);
      }.bind(this)).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    _setWorkListParams(params, param2){
      let specimenNumber= null;
      let specimenId= null;
      this.set('isTimeVolumeShow',false);
      if(isEmpty(params) && isEmpty(this.getOpenMenuParams())){
        return;
      }
      if(params == 'Commit'){
        //text commit 경우
        specimenNumber = isEmpty(this.get('specimenNumber'))? null : this.get('specimenNumber').trim();
      }else if(params == 'specimenId' && !isEmpty(param2)){
        specimenId= param2;
      }else{
        specimenNumber= isEmpty(params)? this.getOpenMenuParams().specimenNumber : params.specimenNumber;
      }
      this.set('specimenNumber', specimenNumber );
      this.set('comments', {
        isCommentsExpanded: false,
        deptCommentsCount: 0
      });
      this.getList(this.get('defaultUrl') + 'result-worklists/search', null,
        {
          specimenNumber: specimenNumber,
          specimenId: specimenId
        }, true).then(res=>{
        if(res){
          const promise = new Promise((resolve)=>{
            if(res.response.length){
              resolve(EmberObject.create(res.response));
              const workListParams= res.response.get('firstObject');
              this.set('specimenNumber', workListParams.specimenNumber );
              this.set('specimenName', workListParams.specimenType.name );
              let orderComment = '';
              if(!isEmpty(workListParams.get('specimenOrders'))){
                workListParams.get('specimenOrders').forEach(e=>{
                  if(!isEmpty(e.orderComment)){
                    orderComment = orderComment + ' ' + e.orderComment;
                  }
                });
              }
              set(workListParams, 'referredFrom', workListParams.specimenOrders.get('firstObject.issuedDepartment.name') + '/ '
                + workListParams.specimenOrders.get('firstObject.department.name') + ' / '
                + workListParams.specimenOrders.get('firstObject.orderedStaff.name'));


              if(!isEmpty(workListParams.ward)){
                let occupyingBed= isEmpty(workListParams.ward.displayCode)? '' : workListParams.ward.displayCode;
                occupyingBed= isEmpty(workListParams.room.roomCode)? occupyingBed : occupyingBed + '/' + workListParams.room.roomCode;
                occupyingBed= isEmpty(workListParams.bed.displayCode)? occupyingBed : occupyingBed + '/' + workListParams.bed.displayCode;
                set(workListParams, 'occupyingBed', occupyingBed);
                let occupyingBedTooltip= isEmpty(workListParams.ward.name)? '' : workListParams.ward.name;
                occupyingBedTooltip= isEmpty(workListParams.room.roomName)? occupyingBedTooltip : occupyingBedTooltip + '/' + workListParams.room.roomName;
                occupyingBedTooltip= isEmpty(workListParams.bed.name)? occupyingBedTooltip : occupyingBedTooltip + '/' + workListParams.bed.name;
                set(workListParams, 'occupyingBedTooltip', occupyingBedTooltip);
              }else{
                set(workListParams, 'occupyingBed', '');
                set(workListParams, 'occupyingBedTooltip', '');
              }
              set(workListParams, 'orderInfo',workListParams.specimenOrders.get('firstObject.orderDate').toFormatString(true, false)
                + '<br>' + workListParams.specimenOrders.get('firstObject.orderName'));
              set(workListParams, 'classificationName', workListParams.specimenOrders.get('firstObject.classification.name'));
              // set(workListParams, 'orderComment', workListParams.get('specimenOrders.firstObject.orderComment'));
              set(workListParams, 'orderComment', orderComment);
              set(workListParams, 'collectionComment', workListParams.collectionComment);
              this.set('workListParams', workListParams);
              this._getTransfurionCount(workListParams.subjectId);
              this._getResultList(null);
            } else{
              resolve(null);
              if(params == 'Commit'){
                this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9264', 'F', '조회된 정보가 없습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
              }
              this.set('isResultGridShow',false);
              this.set('gridDisabled', false);
            }
          });
          return promise;
        }
      }).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },
    _getTransfurionCount(subjectId){
      //수혈이력조회
      this.getList(this.get('defaultUrl') + 'result-worklists/transfusions/count', {patientId: subjectId}, null).then(res=>{
        if(isEmpty(res)){
          this.set('showTransfusionHistoryBtn', false);
          return;
        }
        if(res >0){
          this.set('showTransfusionHistoryBtn', true);
        }else{
          this.set('showTransfusionHistoryBtn', false);
        }
      }).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    _getResultListN(inputStatus){
      let workListParams= this.get('workListParams');
      let specimenNumber= this.get('specimenNumber');
      let specimenId= this.get('specimenId');
      // let params= {};
      if(isEmpty(specimenNumber) && isEmpty(specimenId)){
        return;
      }
      if(!isEmpty(specimenNumber)){
        //worklist에서 or 검체번호로 조회
        // params={checkInId: workListParams.checkInId, specimenNumber: workListParams.specimenNumber};
        specimenId=null;
      }else if(!isEmpty(specimenId)){
        //전역정보의 specimenId로 조회
        specimenNumber = null;
      }

      if(isEmpty(workListParams)){
        workListParams={checkInId: null, specimenNumber: specimenNumber, specimenId: specimenId};
      }else{
        this._setTAT(workListParams);
      }
      this.set('isResultGridShow', this.get('isResultGridShow') == true? false : true);
      return this.getList(this.get('defaultUrl') + 'observations/results', {
        checkInId: workListParams.checkInId,
        specimenNumber: workListParams.specimenNumber,
        specimenId: workListParams.specimenId}, null, true).then(res=>{
        this.set('saveClick', false);
        this.set('loaderType', 'spinner');
        if(res){
          const promise = new Promise((resolve)=>{
            if(res.response.length){
              resolve(A(res.response));
              let equipRemark= null;
              this.get('specimenSamplingService').getTimeVolume(specimenNumber).then(function(timeVolumeTmp){
                let timeVolume= null;
                timeVolume= !isEmpty(timeVolumeTmp.get('firstObject'))? timeVolumeTmp.get('firstObject') : timeVolumeTmp;
                this.set('isTimeVolumeShow', !isEmpty(timeVolume.specimenProperty.collectionHour) || !isEmpty(timeVolume.get('firstObject.specimenProperty.collectionHour')));
                this.set('timeVolume',timeVolume.specimenProperty);
                this.toggleProperty('initializeTimeVolume');
              }.bind(this)).catch(function(error){
                this._catchError(error);
              }.bind(this));
              const newCvrItem = [];
              const cvrItem = this.get('cvrItem');
              let returnTextRecordId = false;
              if (!isEmpty(this.get('returnTextRecordId'))){
                returnTextRecordId = true;
              }
              res.response.forEach(element=>{
                // if(element.check.isCritical ===true){
                //   cvrItem.addObject(element);
                // }
                if(cvrItem.includes(element.examinationId)){
                  newCvrItem.addObject(element);
                }
                if(isEmpty(equipRemark)){
                  if(isPresent(element.deviceRemark)){
                    equipRemark= element.deviceRemark;
                  }
                }else if(isPresent(equipRemark) && isPresent(element.deviceRemark)){
                  equipRemark= element.deviceRemark+ ' / ' + element.deviceRemark;
                }
                set(element, 'orderNameTooltip' , element.examination.displayCode + ', '+ element.examination.name);
                set(element, 'equipRemark' ,equipRemark);
                set(element, 'isNotVerify', false);
                this._setValue(element);
                if(returnTextRecordId){
                  this._setRecordNoteId(element);
                }
                if(!isEmpty(element.interpretation)){
                  set(element, 'interpretation.code', element.interpretation.coding.get('firstObject.code'));
                }
              });
              if(!isEmpty(newCvrItem) && inputStatus=='final'){
                this._checkCvr(newCvrItem);
              }
              this.set('equipRemark', equipRemark);
              this.set('resultListItemsSource', res.response);
              this._getDepartmentComments();
            } else{
              resolve(A([]));
              this.set('resultListItemsSource', null);
            }
            this.set('isResultGridShow', false);
          });
          return promise;
        }
      }).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    async _getResultList(inputStatus) {
      try {
        this.set('resultListItemsSource', null);
        this.set('loaderType', 'spinner');
        let workListParams= this.get('workListParams');
        let specimenNumber= this.get('specimenNumber');
        let specimenId= this.get('specimenId');
        // let params= {};
        if(isEmpty(specimenNumber) && isEmpty(specimenId)){
          return;
        }
        if(!isEmpty(specimenNumber)){
          //worklist에서 or 검체번호로 조회
          // params={checkInId: workListParams.checkInId, specimenNumber: workListParams.specimenNumber};
          specimenId=null;
        }else if(!isEmpty(specimenId)){
          //전역정보의 specimenId로 조회
          specimenNumber = null;
        }
        if(isEmpty(workListParams)){
          workListParams={checkInId: null, specimenNumber: specimenNumber, specimenId: specimenId};
        }else{
          this._setTAT(workListParams);
        }
        this._getTimeVolume(specimenNumber);
        this._getDepartmentComments();
        this.set('isResultGridShow', this.get('isResultGridShow') == true? false : true);
        const res = await this.getList(this.get('defaultUrl') + 'observations/results', {
          checkInId: workListParams.checkInId,
          specimenNumber: workListParams.specimenNumber,
          specimenId: workListParams.specimenId}, null, false);
        this.set('saveClick', false);
        this.set('draftClick', false);
        if(isPresent(res)) {
          let equipRemark= null;
          const newCvrItem = [];
          const cvrItem = this.get('cvrItem');
          let returnTextRecordId = false;
          if (!isEmpty(this.get('returnTextRecordId'))){
            returnTextRecordId = true;
          }
          res.forEach(element=>{
            if(cvrItem.includes(element.examinationId)){
              newCvrItem.addObject(element);
            }
            if(isEmpty(equipRemark)){
              if(isPresent(element.deviceRemark)){
                equipRemark= element.deviceRemark;
              }
            }else if(isPresent(equipRemark) && isPresent(element.deviceRemark)){
              equipRemark= element.deviceRemark+ ' / ' + element.deviceRemark;
            }
            set(element, 'orderNameTooltip' , element.examination.displayCode + ', '+ element.examination.name);
            set(element, 'equipRemark' ,equipRemark);
            set(element, 'isNotVerify', false);
            this._setValue(element);
            if(returnTextRecordId){
              this._setRecordNoteId(element);
            }
            if(!isEmpty(element.interpretation)){
              set(element, 'interpretation.code', element.interpretation.coding.get('firstObject.code'));
            }
          });
          if(!isEmpty(newCvrItem) && inputStatus ==='final'){
            this._checkCvr(newCvrItem);
          }
          this.set('equipRemark', equipRemark);
          this.set('resultListItemsSource', res);
        }
        this.set('isResultGridShow', false);
      } catch(e) {
        console.log(e);
        this._catchError(e);
      }

    },

    async _getTimeVolume(specimenNumber) {
      try {
        const result = await this.get('specimenSamplingService').getTimeVolume(specimenNumber);
        let timeVolume= null;
        timeVolume= !isEmpty(result.get('firstObject'))? result.get('firstObject') : result;
        this.set('isTimeVolumeShow', !isEmpty(timeVolume.specimenProperty.collectionHour) || !isEmpty(timeVolume.get('firstObject.specimenProperty.collectionHour')));
        this.set('timeVolume',timeVolume.specimenProperty);
        this.toggleProperty('initializeTimeVolume');
      } catch(e) {
        console.error(e);
      }
    },

    async _getDepartmentComments(){
      try {
        this.set('comments', {
          isCommentsExpanded: false,
          deptCommentsCount: 0
        });
        if(isEmpty(this.get('workListParams'))){
          return;
        }
        const res = await this.get('specimenexaminationreportService').getDepartmentComments(this.get('workListParams'));
        if(!isEmpty(res)){
          this.set('comments', res);
        }
        this._getDelayReason();
      } catch(e) {
        console.error(e);
      }
    },
    async _getDelayReason() {
      const params = {
        specimenId: this.get('workListParams.specimenId'),
        checkinId: this.get('workListParams.checkInId'),
      };
      try {
        const result = await this.getList(this.get('checkinUrl') + 'specimen-checkins/observation-delay-specimens', params, null);
        if(isPresent(result)) {
          set(this.get('comments'), 'isCommentsExpanded', true);
        }
      }catch(e) {
        this._catchError(e);
      }
    },

    _setValue(element){
      //To-do 샘플 확인 후 제거
      if(element.valueTypeCode==="Quantity" && isEmpty(element.get('value.quantity'))){
        set(element, 'value', {quantity: {value: null}});
      }
      set(element, 'check', element.check);
      const valueValueString= this.get('specimenexaminationreportService')._setValueString(element);
      set(element, 'valueValueString', valueValueString);
      set(element, 'numericCellInputValue', valueValueString);
      set(element, 'recentResult', this.get('specimenexaminationreportService')._setRecentValue(element));
      set(element, 'recentResultComments', this._setRecentResultComments(element));
      set(element, 'deviceValueValueString', element.get('deviceValue.valueString'));
      set(element, 'referenceRange', element.get('subject.referenceRange.displayContent'));
      set(element, 'isUpdated', false);
      set(element, 'isNotProgress', false);
      if(!isEmpty(element.remark)){
        set(element, 'remark', isEmpty(element.remark)? '': element.remark.replace(/<br>|<br\/>|<br \/>/giu, '\r\n'));
        set(element, 'remarkTooltip', isEmpty(element.remark)? '': element.remark.replace(/\n|\r\n/giu, '<br>'));
      }
      if(!isEmpty(element.recentRemark)){
        set(element, 'recentRemark', isEmpty(element.recentRemark)? '': element.recentRemark.replace(/<br>|<br\/>|<br \/>/giu, '\r\n'));
        set(element, 'recentRemarkTooltip', isEmpty(element.recentRemark)? '': element.recentRemark.replace(/\n|\r\n/giu, '<br>'));
      }
    },
    _setRecordNoteId(element){
      // if (!isEmpty(this.get('returnTextRecordId'))){
      if (!isEmpty(element.value) && element.value.recordNoteId === this.get('returnTextRecordId')){
        this.set('resultListSelectedItem', element);
        this.set('returnTextRecordId', null);
      }
      // }
    },
    _setRecentResultComments(element){
      const recentValue= isEmpty(element.get('recentObservationResult'))? []: element.get('recentObservationResult');
      let recentResultComments='';
      recentResultComments= isEmpty(recentValue.checkInDatetime)?'' : this.getLanguageResource('6758', 'S', '접수') +': '+ this.get('fr_I18nService').formatDate(new Date(recentValue.checkInDatetime), 'g');
      recentResultComments=isEmpty(recentValue.issuedDatetime)?recentResultComments : recentResultComments +'<br> '+ this.getLanguageResource('9046', 'S', '검증') +': '+ this.get('fr_I18nService').formatDate(new Date(recentValue.issuedDatetime), 'g');
      set(element, 'recentRemark', recentValue.remark);
      return recentResultComments;
    },

    _checkCvr(cvrItem){
      if(cvrItem.length == 1){
        this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('10747', 'F', 'CVR을 전송하시겠습니까?'),
          'question', 'YesNo', 'Yes', '', null).then(function(result){
          if(result === 'Yes'){
            this._sendCvr(cvrItem.get('firstObject'));
          }
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      }else if(cvrItem.length >1){
        this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('10748', 'F', 'CVR 대상검사가 있습니다.'), 'information', 'Ok', 'Ok', '', 20000);
      }
    },

    _setTAT(){
      const workListParams= this.get('workListParams');
      const currentTime= new Date(this.get('co_CommonService').getNow()).getTime();
      let reportedDateTime= null;
      let checkInDateTime=null;
      let receivedDateTime=null;
      let collectionEndDatetime= null;
      let tat= null;

      if(isPresent(workListParams.reportedDateTime)){
        reportedDateTime= workListParams.reportedDateTime.getTime();
      }
      if(isPresent(workListParams.checkInDateTime)){
        checkInDateTime= workListParams.checkInDateTime.getTime();
      }
      if(isPresent(workListParams.receivedDateTime)){
        receivedDateTime= workListParams.receivedDateTime.getTime();
      }else{
        receivedDateTime= reportedDateTime;
      }

      if(isPresent(workListParams.collectionEndDatetime)){
        collectionEndDatetime= workListParams.collectionEndDatetime.getTime();
      }
      if(isEmpty(checkInDateTime)){
        return;
      }

      if(isPresent(reportedDateTime)){
        tat= {
          checkIn: Math.floor((reportedDateTime - checkInDateTime) / 60000),
          received: isEmpty(receivedDateTime)? null: Math.floor((reportedDateTime - receivedDateTime) / 60000),
          sampling: Math.floor((reportedDateTime - collectionEndDatetime) / 60000)
        };
      }else{
        tat= {
          checkIn: Math.floor((currentTime - checkInDateTime) / 60000),
          received: isEmpty(receivedDateTime)? null: Math.floor((currentTime - receivedDateTime) / 60000),
          sampling: Math.floor((currentTime - collectionEndDatetime) / 60000)
        };
      }
      this.set('tat', tat );
    },

    _setCurrentCell(e) {
      const _gridControl= this.get('_gridControl');
      if(isEmpty(this.get('_gridControl'))){
        return;
      }
      const originalSource = _gridControl.getOriginalSource(e.originalEvent);
      const currentDom = $('#' + originalSource.elementId);
      const top = currentDom.height() * -1;
      this.set('_currentCell', {
        item: originalSource.item,
        element: currentDom,
        field: originalSource.column.field,
        rowIndex: originalSource.rowIndex,
        // cellIndex: originalSource.cellIndex,
        cellIndex: _gridControl.getColumnIndex(originalSource.column),
        offset: {top: top + 'px', left: 0 + 'px'}
      });
      // this.set('_currentCell',this.get('specimenexaminationreportService')._setCurrentCell(this, this.get('_gridControl').getOriginalSource(e.originalEvent)));
    },

    async _setSaveParams(inputStatus, itemSource, currentDatetime){
      this.set('tempSaveParams', null);
      if(!this.get('gridEditEnd')) {
        return;
      }
      let observationResults=[];
      // let value={};
      const array = this.get('resultListItemsSource').map(function(e){
        return $.extend(true, {}, e);
      });
      const resultListItemsSource= isEmpty(itemSource)? array: itemSource;
      if(isEmpty(resultListItemsSource)){
        return;
      }
      // this.set('isSaveButtonDisabled', true);
      const performer= this.get('co_CurrentUserService.user');
      if(isEmpty(performer)){
        this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9812', 'F', '사번을 확인하세요'), 'error', 'Ok', 'Ok', 'Invalid user', null);
      }
      let isfinal = false;
      let isCorrected = false;
      const nullItems = [];
      const needCheckExaminationNames = [];
      this.set('cvrItem', []);
      resultListItemsSource.forEach((e, index) => {
        if(e.isNotVerify && inputStatus === 'final'){
          //저장버튼누를 때 검증제외체크된것 검증제외
          return;
        }
        if(!this._validationCheck(inputStatus, e)){
          return;
        }
        if(isEmpty(e.value)){
          set(e, 'value', {quantity:{value: null}, codeableConcept: null});
        }
        if(this._nullCheck(inputStatus, e)){
          nullItems.push(index);
        }
        if(inputStatus ==='preliminary' && e.statusCode ==='final'){
          //최초 save , 이미 저장된항목 Draft 할경우
          isfinal = true;
          needCheckExaminationNames.push(e.examination.name);
          return;
        }

        if(isEmpty(e.numericCellInputValue) && !e.isNullableReport && e.statusCode ==='waiting' && inputStatus ==='final'){
          //null이어도 미검증상태는 저장버튼누를 때 검증제외
          return;
        }
        if(e.valueTypeCode=="ValueTextString" && isEmpty(e.value.recordNoteId)){
          return;
        }
        if(e.statusCode === 'final' || e.statusCode ==='corrected') {
          if(e.valueTypeCode=="ValueTextString" && isEmpty(e.value.recordNoteId)){
            //
          }else{
            set(e,'isCorrected', true);
          }
          isCorrected=true;
          this.set('correctReasonTargetItem', e);
        }
        if(!isEmpty(e.remark)){
          set(e,'replace', isEmpty(e.remark)? '': e.remark.replace(/\n|\r\n/giu, '<br>'));
        }
        if(e.check.isCritical){
          this.get('cvrItem').addObject(e.examinationId);
        }

        if(!isEmpty(e.interpretation)){
          // set(gridItem, 'interpretation.code', item.interpretation.coding.get('firstObject.code'));
          set(e, 'interpretation.dataFirstRegisteredDateTimeUtc', currentDatetime);
          set(e, 'interpretation.dataLastModifiedDateTimeUtc', currentDatetime);
          if(!isEmpty(e.interpretation.coding)){
            e.interpretation.coding.forEach(i=>{
              set(i,'dataFirstRegisteredDateTimeUtc', currentDatetime);
              set(i,'dataLastModifiedDateTimeUtc', currentDatetime);
            });
          }

        }
        observationResults = this._setObservationResults(observationResults, e, e.statusCode === 'final' || e.statusCode ==='corrected', inputStatus,performer,currentDatetime);
      });
      if(isfinal === true){
        const examinationNames = needCheckExaminationNames.join(', ');
        this.showMessagebox(this.getLanguageResource('9288', 'F', '검사상태를 확인해주시기 바랍니다.'), `${this.getLanguageResource('16920', 'S','Exam Name')} : ${examinationNames}`, 'warning');
        // this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9288', 'F', '검사상태를 확인해주시기 바랍니다.'), 'warning', 'Ok', 'Ok', '', 2000);
        this.set('isSaveButtonDisabled', false);
        this.set('hasChanged', false);
        this.set('saveClick', false);
        this.set('draftClick', false);
        return;
      }
      if(!isEmpty(nullItems)){
        this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('8945', 'F', '필수값을 입력하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
        this.set('isSaveButtonDisabled', false);
        this.set('hasChanged', false);
        this.set('saveClick', false);
        this.set('draftClick', false);
        // this.get('gridSource').selectRows(nullItems);
        return;
      }
      if(observationResults.length === 0 ){
        //변경사항이 없는 경우
        this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9209', 'F', '저장할 내용이 없습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
        this.set('isSaveButtonDisabled', false);
        this.set('hasChanged', false);
        this.set('saveClick', false);
        this.set('draftClick', false);
        return;
      }
      this.set('tempSaveParams', {isCorrected, inputStatus, observationResults});
      // const now = this.get('co_CommonService').getNow();
      if(inputStatus === 'final') {
        const compareObservationResults = [];
        resultListItemsSource.forEach(e=>{
          const value = this.get('specimenexaminationreportService')._updatedValue(e, currentDatetime);
          let isUpdated = e.isUpdated;
          if(!e.isReport) {
            isUpdated = true;
          }
          compareObservationResults.push({
            examinationId: e.examinationId,
            observationResultId: e.observationResultId,
            valueTypeCode: e.valueTypeCode,
            isNotVerify: e.isNotVerify,
            isUpdated: isUpdated,
            value:{
              quantity: value.quantity,
              codeableConcept: value.codeableConcept,
              valueDecimal: isEmpty(value.valueDecimal)? 0 : value.valueDecimal,
              valueString: value.valueString,
              valueBool: true,
            },
          });
        });
        const params = {
          specimenNumber: this.get('specimenNumber'),
          observationResults: compareObservationResults
        };
        const compareResult = await this.getList(`${this.get('defaultUrl')}observations/results/compare`, null, params, false);
        if(isPresent(compareResult)) {
          this.set('isAlertOpen', true);
          this.set('alertItemsSource', compareResult);
          return;
        }
      }
      this._goSaveResult();
    },

    _goSaveResult() {
      const {isCorrected, inputStatus, observationResults} = this.get('tempSaveParams');
      if(isCorrected && isEmpty(this.get('editReasonSelectedItem'))){
        //변경사유 입력
        this.set('isCorrectReasonEntryOpened', true);
        this.set('editReasonSelectedItem', null);
      }else{
        this.set('isSaveButtonDisabled', true);
        this._saveResult(isCorrected, inputStatus, observationResults);
      }
      this.set('saveClick', false);
      this.set('draftClick', false);
    },
    // async _beforSaveShowConmfrim(message) {
    //   const result = await this.showConfirmMessage('', message);
    //   if(result === 'Yes') {

    //   }
    // },

    // _goSaveAccess(isNeedReason) {
    //   if(isNeedReason) {
    //     this.set('isCorrectReasonEntryOpened', true);
    //     this.set('editReasonSelectedItem', null);
    //   } else {
    //     this.set('isSaveButtonDisabled', true);
    //     this._saveResult(isCorrected, inputStatus, observationResults);
    //   }
    //   this.set('saveClick', false);
    // },

    _setObservationResults(observationResults, e, crrected, status,performer,currentDatetime){
      let value={};
      let inputStatus = status;
      let isCorrected = crrected;
      switch(e.valueTypeCode){
        case 'Quantity':
          if(e.isNotProgress) {
            set(e, 'valueTypeCode', 'ValueString');
            set(e, 'interpretation', null);
            value={
              quantity: {
                value: null,
                comparatorCode: null,
                unitCode: null,
                unitName:null
              },
              codeableConcept: null,
              valueString: this.get('impossibleExamination')
            };
          } else {
            value={
              quantity: {
                value: isEmpty(e.numberValue)? e.value.quantity.value : parseFloat(e.numberValue) ,
                comparatorCode: isEmpty(e.value.quantity.comparatorCode)? '-': e.value.quantity.comparatorCode,
                unitCode: e.get('examinationUnit.code')? e.get('examinationUnit.code'): null,
                unitName: e.get('examinationUnit.name')? e.get('examinationUnit.name'): null
              },
              codeableConcept: null,
              valueString: e.value.valueString
            };
          }
          observationResults.addObject(this._setObservationResult(e, value, isCorrected,inputStatus,performer,currentDatetime));
          break;
        case 'CodeableConcept':
          //예문 선택안하면 'ValueString' 타입으로 - 저장시에만
          value= e.get('value');
          if(isEmpty(value.codeableConcept)){
            if(e.isUpdated){
              set(value, 'quantity', null);
              set(value, 'codeableConcept', {coding:[]});
              set(value, 'valueString', value.valueString);
              set(e, 'valueTypeCode', 'ValueString');
            }
          }else if(isEmpty(value.codeableConcept.coding)){
            if(e.isUpdated){
              set(value, 'quantity', null);
              set(value, 'codeableConcept', {coding:[]});
              set(value, 'valueString', value.valueString);
              set(e, 'valueTypeCode', 'ValueString');
            }
          }else if(!isEmpty(value.codeableConcept.displayContent)){
            value.codeableConcept.displayContent= value.codeableConcept.displayContent.trim();
          }else if(!isEmpty(value.valueString)){
            if(e.isUpdated){
              set(value, 'quantity', null);
              set(value, 'codeableConcept', {coding:[]});
              set(value, 'valueString', value.valueString);
              set(e, 'valueTypeCode', 'ValueString');
            }
          }
          if(!isEmpty( value.codeableConcept.coding)){
            value.codeableConcept.coding.forEach(i=>{
              set(i,'dataFirstRegisteredDateTimeUtc', currentDatetime);
              set(i,'dataLastModifiedDateTimeUtc', currentDatetime);
            });
            set(e,'value.codeableConcept.dataFirstRegisteredDateTimeUtc', currentDatetime);
            set(e,'value.codeableConcept.dataLastModifiedDateTimeUtc', currentDatetime);
          }
          observationResults.addObject(this._setObservationResult(e, value,isCorrected,inputStatus,performer,currentDatetime));
          break;
        case 'ValueTextString':
          value= e.value;
          if(isEmpty(e.value.recordNoteId)){
            //isValueTextStringInputStatus
            inputStatus= e.statusCode;
            isCorrected= false;
          }
          observationResults.addObject(this._setObservationResult(e, value,isCorrected,inputStatus,performer,currentDatetime));
          break;
        case 'ValueString':
          value= e.get('value');
          if(isEmpty(value.valueString)){
            value.valueString=null;
          }
          observationResults.addObject(this._setObservationResult(e, value, isCorrected, inputStatus, performer, currentDatetime));
          break;
        default:
          break;
      }
      return observationResults;
    },

    _setObservationResult(e, value,isCorrected, inputStatus, performer, currentDatetime){
      let remark =e.remark;
      if(!isEmpty(this.get('changeReasonRemark'))){
        //선택 수정사유 콜백 후
        if(e.valueTypeCode=="ValueTextString" && isEmpty(e.value.recordNoteId)){
          //recordNoteId 없는 ValueTextString 타입
        }else if(isCorrected){
          remark= isEmpty(remark)? this.get('changeReasonRemark') : this.get('changeReasonRemark');
        }
      }

      // if(e.isNotVerify){rhjs
      //   //검증제외
      //   isCorrected=false;
      //   inputStatus= e.statusCode;
      // }

      const tmp={
        checkInId: e.checkInId,
        observationId: e.observationId,
        unitWorkId: e.unitWorkId,
        examinationId: e.examinationId,
        basedOnTypeCode: 'ProcedureRequest',
        subjectTypeCode: 'Patient',
        basedOnId: e.basedOnId,
        subjectId: e.subjectId,
        specimenId: e.specimenId,
        specimenNumber: e.specimenNumber,
        statusCode: isCorrected? 'corrected': inputStatus,
        effectiveDatetime: e.effectiveDatetime,
        effectivePeriod: e.effectivePeriod,
        performer: {
          typeCode: "Practitioner",
          id: performer.id,
          displaySequence: 0,
          performDatetime: currentDatetime
        },
        valueTypeCode: e.valueTypeCode,
        // value: {
        //   quantity: value.quantity,
        //   codeableConcept: value.codeableConcept,
        //   valueDecimal: isEmpty(e.value.valueDecimal)? 0 : e.value.valueDecimal,
        //   valueString: value.valueString,
        // },
        value: value,
        interpretation: e.interpretation,
        remark: remark,
        deviceCode: e.deviceCode,
        displaySequence: e.displaySequence,
        check: e.check,
        relatedTypeCode: null,
        targetObservationResultId: null,
        inputSubType: null,
        isReport: false,
      };
      return tmp;
    },

    // _saveResult(isCorrected, inputStatus, observationResults){
    //   this.set('loaderType', 'progress');
    //   this.set('isResultGridShow', true);
    //   this.get('specimenexaminationreportService').resultSave('general'
    //     , isCorrected, inputStatus, observationResults,this.get('editReasonSelectedItem')).then(function(){
    //     this.set('hasChanged', false);
    //     this.set('editReasonSelectedItem', null);
    //     this.set('changeReasonRemark', null);
    //     switch(inputStatus){
    //       case 'preliminary':
    //         this.get('specimenexaminationreportService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
    //         break;
    //       case 'final':
    //         if(isCorrected){
    //           this.get('specimenexaminationreportService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
    //         }else{
    //           this.get('specimenexaminationreportService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
    //         }
    //         break;
    //       default:
    //     }
    //     //inputStatus = 'final'
    //     this._getResultList(inputStatus, observationResults).then(function(){
    //       this.get('co_ContentMessageService').sendMessage('__main_patient_information_refresh', 'refresh');
    //       this.get('co_ContentMessageService').sendMessage('updateMessage', 'D');
    //       this.set('isResultGridShow', false);
    //       this.set('isSaveButtonDisabled', false);
    //     }.bind(this)).catch(function(error){
    //       this.set('isSaveButtonDisabled', false);
    //       this._catchError(error);
    //     }.bind(this));
    //   }.bind(this)).catch(function(error){
    //     this.set('isSaveButtonDisabled', false);
    //     this._catchError(error);
    //   }.bind(this));
    // },
    async _saveResult(isCorrected, inputStatus, observationResults){
      try {
        this.set('loaderType', 'progress');
        this.set('isResultGridShow', true);
        await this.get('specimenexaminationreportService').resultSave('general', isCorrected, inputStatus, observationResults,this.get('editReasonSelectedItem'));
        this.set('hasChanged', false);
        this.set('editReasonSelectedItem', null);
        this.set('changeReasonRemark', null);
        this.showToastSaved();
        await this._getResultList(inputStatus, observationResults);
        next(() => {
          if(this.isDestroyed || this.isDestroying) {
            return;
          }
          this.get('co_ContentMessageService').sendMessage('updateMessage', 'D');
          // this.get('co_ContentMessageService').sendMessage('__main_patient_information_refresh', 'refresh');
        });
        this.set('isResultGridShow', false);
        this.set('isSaveButtonDisabled', false);
      } catch(e) {
        this.set('isSaveButtonDisabled', false);
        this._catchError(e);
      }
    },

    _validationCheck(inputStatus, e){
      let res= true;
      if(e.statusCode === 'final' && e.isUpdated===false){
        //final 상태에서 변경사항 있는 것만 corrected로 저장
        res=false;
      }
      if(e.statusCode === 'corrected' && e.isUpdated===false){
        //변경사항 없으면 리턴
        res=false;
      }
      // if(inputStatus === 'final' && !e.isUpdated) {
      //   res=false;
      // }
      if(inputStatus==='preliminary' && e.isUpdated===false){
        //preliminary의 경우 변경사항 없어도 draft
        // res=false;
      }
      return res;
    },

    _nullCheck(inputStatus, e){
      //final 저장 시 null값있으면 true리턴
      let res= false;
      if(e.check.isRecheck){
        // isRecheck이면 null체크 안함
        return res;
      }
      const valueValueString= e.valueValueString;
      if(e.valueTypeCode=="ValueTextString" && !isEmpty(e.value.recordNoteId)){
        //recordNoteId있는 ValueTextString타입은 null체크 안함
        // res=true;
      }else if(inputStatus==='final' && isEmpty(valueValueString)){
        // 결과값이 없으면 검증 안되게함.
        // ValueTextString타입 null체크 안함
        if(e.valueTypeCode=="ValueTextString" && isEmpty(e.value.recordNoteId)){
          set(e, 'isValueTextStringInputStatus', true);
        }else if(!e.isNullableReport && !e.isNotProgress){
          //2020.06.10 !e.isNotProgress 조건추가.(검사불가능)
          if(e.statusCode=='waiting' && inputStatus ==='final'){
            // 저장버튼누를 때 미검증상태는 null체크 안하고 검증제외
            res=false;
          }else{
            res=true;
          }
        }else if(e.isNullableReport){
          //null로 저장가능
        }
      }
      return res;
    },

    _calculate(inputModeType){
      //diff, slide, stkck, micro 버튼 클릭시, 팝업onClosed 이벤트 호출 못할때처리
      const workListParams= this.get('workListParams');
      const observationResults= [];
      const observationResultsForSave =[];
      let value={};
      if(isEmpty(this.get('resultListItemsSource'))){
        return;
      }
      const now = this.get('co_CommonService').getNow();
      this.get('resultListItemsSource').forEach(e=>{
        value= isEmpty(e.get('value'))? {} : e.get('value');
        value= this.get('specimenexaminationreportService')._updatedValue(e, now);
        if(inputModeType != 'Rule'){
          observationResults.addObject(this.get('specimenexaminationreportService')._setCalculateObservationResults(e, value, true));
          observationResultsForSave.addObject(e);
        }else if((!e.isUpdated && inputModeType != 'Rule') || e.isValueChanged!=true){
          //calculate 대상 아닌 경우
          observationResults.addObject(this.get('specimenexaminationreportService')._setCalculateObservationResults(e, value, false));
          // return;
        }else{
          observationResults.addObject(this.get('specimenexaminationreportService')._setCalculateObservationResults(e, value, true));
          observationResultsForSave.addObject(e);
        }
      });
      const params={
        inputModeType: inputModeType,
        isPossibleInputItemId: true,
        subjectId: workListParams.subjectId,
        subjectTypeCode : 'Patient',
        specimenNumber: workListParams.specimenNumber,
        observationResults: observationResults
      };
      if(observationResultsForSave.length ==0){
        return;
      }
      // if(!isFunctionKey){
      if(inputModeType != 'Rule' || !isEmpty(this.get('diffArr'))){
        this.set('isResultGridShow', true);
      }
      this.set('gridDisabled', true);
      return this.create(this.get('defaultUrl') + 'observations/results/calculate', null, params).then(function(res){
        this.set('gridDisabled', false);
        if(isEmpty(res)){
          this.set('isResultGridShow', false);
          return;
        }
        this.get('resultListItemsSource').forEach(function(gridItem, gridItemIndex){
          let item=null;
          const changedItem=res.findBy('examinationId', gridItem.examinationId);
          //return 받은 검사항목 찾아서 업데이트
          if (!isEmpty(changedItem)){
            item= changedItem;
            if(inputModeType == "Slide"){
              //slide는 remark가 있는 경우만 업데이트
              this._inputCallBackSetting(inputModeType, gridItem,item);
              set(gridItem, 'isValueChanged', false);
              return;
            }else{
              set(gridItem, 'isUpdated', true);
            }
            if(item.valueTypeCode=='Quantity' && (gridItem.statusCode =='final' || gridItem.statusCode =='corrected')
            && (this.get('specimenexaminationreportService')._setValueString(item) == gridItem.valueValueString)){
            //검증상태이고 value가 같으면 isUpdated 업데이트 안함
              set(gridItem, 'isUpdated', false);
            }
            set(gridItem, 'isValueChanged', false);
            set(gridItem, 'interpretation', item.interpretation);
            if(!isEmpty(item.interpretation)){
              set(gridItem, 'interpretation.code', item.interpretation.coding.get('firstObject.code'));
            }
          }else if(this.get('mode')=='results-by-item'){
            item=res[gridItemIndex];
          }else{
            return;
          }
          if(!isEmpty(item.value)){
            set(gridItem, 'valueValueString', this.get('specimenexaminationreportService')._setValueString(item));
            set(gridItem, 'numericCellInputValue', this.get('specimenexaminationreportService')._setValueString(item));
            set(gridItem, 'value', item.value);
          }
          set(gridItem, 'valueTypeCode', item.valueTypeCode);
          this._inputCallBackSetting(inputModeType, gridItem, item);
          if(!isEmpty(item.remark)){
            set(gridItem, 'remarkTooltip', isEmpty(item.remark)? '': item.remark.replace(/\n|\r\n/giu, '<br>'));
          }
        }.bind(this));
        this.set('diffArr', null);
        this.set('isResultGridShow', false);
      }.bind(this)).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },
    //재검요청
    async _getReobservation() {
      try {
        const selectedItems = this.get('_gridControl.selectedItems');
        if(isEmpty(selectedItems)) {
          return;
        }
        const params = {
          requestDatetime: this.get('co_CommonService').getNow(),
          requestStaffId: this.get('currentUser.employeeId'),
          observationIds: selectedItems.map(d => d.observationId)
        };
        const result = await this.create(this.get('defaultUrl') + 'observations/reobservation', null, params);
        if(isPresent(result)) {
          this.showToastSaved();
          this._getResultList(null);
        }
      }catch(e) {
        this._catchError(e);
      }
    },

    _inputCallBackSetting(inputModeType, gridItem,item ){
      const diffArr= this.get('diffArr');
      if(!isEmpty(diffArr)){
        //diff 클릭 후remark 세팅
        const obj= diffArr.findBy('examinationId', gridItem.examinationId);
        if(!isEmpty(obj)){
          set(gridItem, 'remark', obj.get('value.valueString'));
          set(gridItem, 'isValueChanged', false);
        }
        //check에서 isRecheck 빼고 update
        if(!isEmpty(item.check)){
          set(gridItem, 'check.isCritical', item.check.isCritical);
          set(gridItem, 'check.isDelta', item.check.isDelta);
          set(gridItem, 'check.isPanic', item.check.isPanic);
          // if(gridItem.statusCode == "waiting"){
          if(gridItem.check.isNotAnalyticalMeasurementRange != item.check.isNotAnalyticalMeasurementRange){
            //calculate 후 달라졌을 경우만 업데이트
            set(gridItem, 'check.isNotAnalyticalMeasurementRange', item.check.isNotAnalyticalMeasurementRange);
          }
          set(gridItem, 'check.isRecentCritical', item.check.isRecentCritical);
        }
        set(gridItem, 'interpretation', item.interpretation);
        if(!isEmpty(item.interpretation)){
          set(gridItem, 'interpretation.code', item.interpretation.coding.get('firstObject.code'));
        }
      }else if(inputModeType == "Slide" ){
        //slide는 remark만 업데이트
        if(!isEmpty(item.remark)){
          set(gridItem, 'remark', item.remark);
          set(gridItem, 'remarkTooltip', isEmpty(item.remark)? '': item.remark.replace(/\n|\r\n/giu, '<br>'));
          set(gridItem, 'isUpdated', true);
        }
      }else if(inputModeType == "Stick" || inputModeType == "Rule" || inputModeType == "Micro"){
        // set(gridItem, 'check', item.check);
        if(!isEmpty(item.check)){
          set(gridItem, 'check.isCritical', item.check.isCritical);
          set(gridItem, 'check.isDelta', item.check.isDelta);
          set(gridItem, 'check.isPanic', item.check.isPanic);
          // if(gridItem.statusCode == "waiting"){
          if(gridItem.check.isNotAnalyticalMeasurementRange != item.check.isNotAnalyticalMeasurementRange){
            //calculate 후 달라졌을 경우만 업데이트
            set(gridItem, 'check.isNotAnalyticalMeasurementRange', item.check.isNotAnalyticalMeasurementRange);
          }
          set(gridItem, 'check.isRecentCritical', item.check.isRecentCritical);
        }
        if(isEmpty(item.value)){
          set(gridItem, 'value', {quantity : {value: null},codeableConcept : {coding:null}});
          set(gridItem, 'valueTypeCode', item.valueTypeCode);
        }
      }
    },

    _setQuantityValueValueString(item){
      let quantityValue= item.value.quantity.value;
      let comparator=item.value.quantity.comparatorCode;
      let valueString= item.value.valueString;
      if(isEmpty(quantityValue)){
        quantityValue= '';
      }
      if(comparator =='-' || isEmpty(comparator)){
        comparator= '';
      }
      if(isEmpty(valueString)){
        valueString= '';
      }
      return comparator+ ' ' + quantityValue + ' ' + valueString;
    },

    _setCodeValueValueString(item){
      let displayContent=null;
      if(isPresent(item.value)){
        displayContent= item.value.codeableConcept.displayContent;
      }
      let valueString= item.value.valueString;
      if(isEmpty(displayContent)){
        displayContent= '';
      }
      if(isEmpty(valueString)){
        valueString= '';
      }
      return displayContent + ' '+ valueString;
    },

    _moveFocus(moveType) {
      const grid = this.get('_gridControl');
      const rowIndex = this.get('_currentCell.rowIndex');
      const cellIndex = this.get('_currentCell.cellIndex');
      let moveRow = 0;
      let moveColumn = 0;

      if(moveType === 'down') {
        moveRow = 1;
      } else if(moveType === 'self') {
        moveRow = 0;
        moveColumn = 0;
      }

      next(this, function() {
        if(moveRow != 0) {
          grid.selectRow(rowIndex + moveRow);
          // grid.focusCell(rowIndex + moveRow, cellIndex);
          grid.editCell(rowIndex + moveRow, cellIndex);
          // grid.selectCell(rowIndex + moveRow, cellIndex);
        } else if(moveColumn != 0) {
          // grid.selectCell(rowIndex, cellIndex + moveColumn);
          // grid.focusCell(rowIndex, cellIndex + moveColumn);
        } else if ( moveRow === 0 && moveColumn === 0) {
          // grid.selectCell(rowIndex, cellIndex);
          // grid.focusCell(rowIndex, cellIndex);
        }
      });
    },
    _catchError(e){
      this.set('isResultGridShow',false);
      this.set('gridDisabled', false);
      // this.set('gridEditable', true);
      this.showResponseMessage(e);
    }
  });