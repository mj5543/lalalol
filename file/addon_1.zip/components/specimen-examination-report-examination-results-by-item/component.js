/* eslint-disable max-lines */
/* eslint-disable chis/require-template-convention */
/* eslint-disable max-statements */
/* eslint-disable no-console */
import { A } from '@ember/array';
import $ from 'jquery';
import { copy } from '@ember/object/internals';
import { next, later } from '@ember/runloop';
import EmberObject, { set, get } from '@ember/object';
import { hash } from 'rsvp';
import { isEmpty, compare, isPresent } from '@ember/utils';
import { inject as service } from '@ember/service';
import layout from './template';
import CHIS from 'framework/chis-framework';
import config from 'specimenexaminationreport-module/app-config';
import PrintMixin from 'specimenexaminationreport-module/mixins/specimen-examination-report-print-mixin';
import MessageMixin from '../../mixins/specimen-examination-report-message-mixin';

export default CHIS.FR.Core.ComponentBase.extend(CHIS.FR.CrossCutting.ServerCallMixin, MessageMixin, PrintMixin,
  {
    layout,
    specimenexaminationreportService: service('specimen-examination-report-service'),
    specimenSamplingService: service('specimen-sampling-service'),
    specimenCheckInService: service('specimen-check-in-service'),
    // 2. Property Area
    defaultUrl: null,
    currentUser: null,
    searchCondition: null,
    resultListItemsSource: null,
    resultListSelectedItem: null,
    returnTextRecordId:null,
    selectedItems: null,
    _gridControl: null,
    previousItem: null,
    currentItem: null,
    unitWorkIdsItemsSource: null,
    isQuantityEntryOpen: null,
    isConceptEntryOpen: null,
    comments: null,
    isResultCommentPopupOpen: null,
    isSpecimenExamSummaryOpen: null,
    //print
    printPopup:null,
    printConfig:null,
    printContent:null,
    isMicrobiology: null,
    initializeTimeVolume: null,
    isResultGridShow : null,
    isSaveButtonDisabled: false,
    isCommentDisabled: true,
    isTatInputShow: false,
    isTatDisabled: true,
    filterTATValue: null,
    isValueTextEntryOpen: false,
    isResultExampleOpen: false,
    onPropertyInit(){
      this._super(...arguments);
      if(!isEmpty(this.getOpenMenuParams())){
        if(this.getOpenMenuParams().useTypeCode=="Stain"){
          this.set('viewId','specimen-examination-report-examination-microbiology-results');
          this.set('isMicrobiology', true);
          this.set('useTypeCode', "Stain");
          this._setMicrobiologyGridColumns();
        }else if(this.getOpenMenuParams().useTypeCode=="Microbiology"){
          this.set('viewId','specimen-examination-report-examination-microbiology-results-negative');
          this.set('isMicrobiology', true);
          this.set('useTypeCode', "Microbiology");
          this._setMicrobiologyGridColumns();
        }else if(this.getOpenMenuParams().useTypeCode=="Laboratory"){
          this.set('viewId','specimen-examination-report-examination-results-by-item');
          this.set('isMicrobiology', false);
          this.set('useTypeCode', "Laboratory");
          this._setGridColumns();
        }
      }
      this.set('popupMode', 'results-by-item');
      this.setStateProperties([
        'defaultUrl',
        'currentUser',
        'examinationTagNameItemsSource',
        'examinationTagNameSelectedItem',
        'searchCondition',
        'resultListColumns',
        'resultListItemsSource',
        'resultListSelectedItem',
        'microbiologyResultListColumns',
        'returnTextRecordId',
        '_gridControl',
        'isQuantityEntryOpen',
        'isConceptEntryOpen',
        'previousItem',
        'currentItem',
        'selectedItems',
        'comments',
        'isMicrobiology',
        'examinationCategoryTagItems',
        'examinationUnitTagItems',
        'examinationTagItems',
        'examinationTagList',
        'patientTypeItemsSource',
        'deptItemsSource',
        'tatSearchTypecodeItemsSource',
        'tatSearchTimeMinuteItemsSource',
        'initializeTimeVolume',
        'gridEditable',

      ]);
      if (this.hasState() === false) {
        this.set('defaultUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimenexaminationreport')+ `specimen-examination-report/${config.version}/`);
        this.set('checkinUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimencheckin')+'specimen-checkin/v0/');
        this.set('currentUser', this.get('co_CurrentUserService.user'));
        this.set('isReportSubSearchVisible', false);
        this.set('comments', {isCommentsExpanded: false, deptCommentsCount: 0});
        this.set('findSettingPopupInfo', {});
        this.set('findSettingPopupInfo.isOpen', false);
        this.set('init', true);
        this.set('changeReasonRemark', null);
        this.set('loaderType', 'spinner');
        this.set('isResultGridShow', true);
        this.set('searchCondition', {});
        this.set('numericOptions',"decimal",{});
        this.set('calcPixel', 80);
        this.set('tatListStyle', 'display:none;');
        this.set('recordSize', 300);
        this.set('currentPage', 1);
        this.set('negativeEntryTitle', this.getLanguageResource('12470', 'F','결과 일괄입력'));
        this.set('resultExampleList', []);
        this.set('resultExampleColumns', [
          { field: 'name', title: this.getLanguageResource('890', 'F', '', '결과')},
        ]);
      }
    },
    _setMicrobiologyGridColumns(){
      //염색결과입력
      this.set('microbiologyResultListColumns', [
        // { title: this.getLanguageResource('13262', 'S', '', '검증제외'), field: 'isNotVerify', type: 'boolean', width: 60, align: 'center'},
        { title: this.getLanguageResource('16890', 'S','Exam Date'), field: 'checkInDateTime', type: 'date', dataFormat: 'd',width: 75},
        this._setPointColumns(),
        { title: this.getLanguageResource('6767', 'S','Check-in No.'), field: 'checkInNumber', width: 80,align: 'center'},
        { title: this.getLanguageResource('16892', 'S','Exam.Type'), field: 'classification.name', width: 80, bodyTemplateName: 'tooltip' },
        { title: this.getLanguageResource('16881', 'F','Pt Name'), field: 'subject.name', bodyTemplateName: 'boldTooltip',align: 'center', width: 85},
        { title: this.getLanguageResource('8451', 'S','MRN'), field: 'subject.displayNumber', bodyTemplateName: 'bold',align: 'center',width: 77},
        { title: this.getLanguageResource('3680', 'F','Sex'), field: 'subject.gender',align: 'center', width: 35 },
        { title: this.getLanguageResource('1662', 'S','Age'), field: 'subject.age', width: 35, align: 'center' },
        { field: 'issuedDepartmentCode', title:  this.getLanguageResource('8827', 'S','발행처'), width: 90, bodyTemplateName: 'tooltip',align: 'center'},
        { field: 'occupyingBed', title:  this.getLanguageResource('14751', 'S', '','현위치'), width: 100, bodyTemplateName: 'occupyingBedTooltip',align: 'center'},
        { field: 'departmentCode', title: this.getLanguageResource('1113', 'S','진료과'), width: 90, bodyTemplateName: 'tooltip',align: 'center'},
        { field: 'orderedStaffName', title:  this.getLanguageResource('5250', 'S','발행의'), width: 90, bodyTemplateName: 'tooltip',align: 'center'},
        { title: this.getLanguageResource('16921', 'S','Specimen Name'), field: 'specimenType.name',bodyTemplateName: 'tooltip', width: 100},
        { title: this.getLanguageResource('16920', 'S','Exam Name'), field: 'examination.name', bodyTemplateName: 'orderNameTooltip', width: 120},
        { title: this.getLanguageResource('890', 'F','Result'), field: 'valueValueString', bodyTemplateName: 'resultEntry', width: 110, align: 'center'},
        { title: this.getLanguageResource('7387', 'F','Recent Result'), field: 'recentResult', bodyTemplateName: 'recentResultComments', width: 90, align: 'center'},
        { title: this.getLanguageResource('14749', 'F','', '참고'), field: 'interpretation.code', bodyTemplateName: 'interpretation', align: 'center', width: 65},
        { title: this.getLanguageResource('3452', 'F','Status'), field: 'statusName', align: 'center',bodyTemplateName: 'statusNameColor', width: 60},
        { title: this.getLanguageResource('906', 'S','Result Comment'), field: 'remark', bodyTemplateName: 'resultComments', focusableIndex:2, width: 100,align: 'center'},
        { title: this.getLanguageResource('859', 'S','Specimen No.'), field: 'specimenNumber', width: 100, align: 'center'},
      ]);
    },

    _setGridColumns(){
      //항목별검사결과입력
      this.set('resultListColumns', [
        { title: this.getLanguageResource('16890', 'S','Exam Date'), field: 'checkInDateTime', type: 'date', dataFormat: 'd', width: 75, readOnly: true},
        this._setPointColumns(),
        { title: this.getLanguageResource('6767', 'S','Check-in No.'), field: 'checkInNumber', width: 80, align: 'center', readOnly: true},
        { title: this.getLanguageResource('16892', 'S','Exam.Type'), field: 'classification.name', width: 80, bodyTemplateName: 'tooltip', readOnly: true},
        { title: this.getLanguageResource('16881', 'F','Pt Name'), field: 'subject.name', bodyTemplateName: 'boldTooltip',align: 'center', width: 85, readOnly: true},
        { title: this.getLanguageResource('14851', 'S','MRN'), field: 'subject.displayNumber', bodyTemplateName: 'bold',align: 'center', width: 65, readOnly: true},
        { title: this.getLanguageResource('3680', 'F','Sex'), field: 'subject.gender',align: 'center', width: 35, readOnly: true },
        { title: this.getLanguageResource('1662', 'S','Age'), field: 'subject.age', width: 35, align: 'center', readOnly: true },
        { field: 'issuedDepartmentCode', title:  this.getLanguageResource('8827', 'S', '발행처'), width: 90, bodyTemplateName: 'tooltip',align: 'center', readOnly: true},
        { field: 'occupyingBed', title:  this.getLanguageResource('14751', 'S', '','현위치'), width: 100, bodyTemplateName: 'occupyingBedTooltip',align: 'center'},
        { field: 'departmentCode', title: this.getLanguageResource('7111', 'S','진료과'), width: 90, bodyTemplateName: 'tooltip',align: 'center', readOnly: true},
        { field: 'orderedStaffName', title:  this.getLanguageResource('9686', 'F', '발행의'), width: 90, bodyTemplateName: 'tooltip',align: 'center', readOnly: true},
        { title: this.getLanguageResource('16921', 'S','Specimen Name'), field: 'specimenType.name', bodyTemplateName: 'tooltip', width: 100, readOnly: true},
        { title: this.getLanguageResource('16920', 'S','Exam Name'), field: 'examination.name', bodyTemplateName: 'orderNameTooltip', width: 120, readOnly: true},
        { title: this.getLanguageResource('890', 'F','Result'), field: 'valueValueString', bodyTemplateName: 'resultEntry', width: 70,align: 'center'},
        { title: this.getLanguageResource('7387', 'F','Recent Result'), field: 'recentResult', bodyTemplateName: 'recentResultComments', width: 90, readOnly: true,align: 'center'},
        { title: this.getLanguageResource('14749', 'F','', '참고'), field: 'interpretation.code', bodyTemplateName: 'interpretation', align: 'center', width: 65, readOnly: true},
        { title: 'D', field: 'check.isDelta',align: 'center', bodyTemplateName:'delta', width: 24, readOnly: true},
        { title: 'P', field: 'check.isPanic',align: 'center', bodyTemplateName:'panic', width: 24, readOnly: true},
        { title: 'C', field: 'check.isCritical',align: 'center', bodyTemplateName:'critical', width: 24, readOnly: true},
        { title: 'A', field: 'check.isNotAnalyticalMeasurementRange', bodyTemplateName:'amr', align: 'center', width: 24, readOnly: true},
        // { title: '72', field:'check.isRecentCritical',align: 'center', bodyTemplateName:'recentCritical', width: 35},
        { title: this.getLanguageResource('906', 'S','Result Comment'), field: 'remark', bodyTemplateName: 'resultComments', focusableIndex:2, width: 100,align: 'center', readOnly: true},
        { title: this.getLanguageResource('3452', 'F','Status'), field: 'statusName', align: 'center', bodyTemplateName: 'statusNameColor', width: 60, readOnly: true},
        { title: this.getLanguageResource('6513', 'S','Equipment'), field: 'deviceCode', bodyTemplateName: 'tooltip', width: 70, readOnly: true},
        { title: this.getLanguageResource('859', 'S','Specimen No.'), field: 'specimenNumber', width: 100, readOnly: true,align: 'center'},
      ]);
    },

    _setPointColumns(){
      return {title: this.getLanguageResource('3813', 'S','속성'), field: '', width: 60, bodyTemplateName: 'icon',align: 'center', readOnly: true,
        onBodyCellRender: function (context) {
          if(!isEmpty(context.item.point)){
            set(context.cellComponent, 'description', `${get(context.item, 'point')}`);
            set(context.cellComponent, 'descriptionStyle', 'font-weight: bold; width: 90px;');
          }
        }
      };
    },
    _openChangesLog(e){
      if(isEmpty(e.dataItem.item)){
        return;
      }
      this.set('isChangesLogOpened', true);
      this.set('item', e.dataItem.item);
      this.set('changesLogTarget', e.originalEvent.currentTarget);
    },
    //Only For Server-Call Component
    onLoaded(){
      this._super(...arguments);
      this.set('menuClass', 'w1360');
      if (this.hasState() === false) {
        const defaultUrl = this.get('defaultUrl');
        hash({
          examinationTagNameItemsSource: this.getList(this.get('defaultUrl') + 'worklist-configurations/search', {staffId: this.get('co_CurrentUserService.user.employeeId')}, null),
          businessCodes: this.getList(defaultUrl + 'business-codes/search', null,{classificationCodes: ['WorkListSearchCode','TatSearchCode','EncounterTypeCode', 'TatTimeMinute','CVRReason', 'ItemCodeableConcept', 'CultureResultExample', 'TatPercentSearchCode']}, false),
        }).then(function(result) {
          const searhConditionItemsSource=[];
          const tatSearchTypecodeItemsSource= [];
          const patientTypeItemsSource= [];
          const tatSearchTimeMinuteItemsSource= [];
          const cvrReasonItemList= [];
          const itemCodeableConceptItemsSource= [];
          result.businessCodes.forEach(e=>{
            if(e.classificationCode == 'WorkListSearchCode'){
              searhConditionItemsSource.addObject(e);
            }else if(e.classificationCode == 'TatSearchCode'){
              tatSearchTypecodeItemsSource.addObject(e);
            }else if(e.classificationCode == 'EncounterTypeCode'){
              patientTypeItemsSource.addObject(e);
            }else if(e.classificationCode == 'TatTimeMinute'){
              tatSearchTimeMinuteItemsSource.addObject(e);
            }else if(e.classificationCode == 'CVRReason'){
              cvrReasonItemList.addObject(e);
            }else if(e.classificationCode == 'ItemCodeableConcept'){
              itemCodeableConceptItemsSource.addObject(e);
            }else if(e.classificationCode == 'CultureResultExample'){
              this.get('resultExampleList').addObject(e);
            }
          });
          this.set('searhConditionItemsSource', searhConditionItemsSource);
          this.set('tatSearchTypecodeItemsSource', tatSearchTypecodeItemsSource);
          this.set('patientTypeItemsSource', patientTypeItemsSource);
          this.set('tatSearchTimeMinuteItemsSource', tatSearchTimeMinuteItemsSource);
          this.set('itemCodeableConceptItemsSource', itemCodeableConceptItemsSource);
          this.set('examinationTagNameItemsSource', result.examinationTagNameItemsSource);
          this.set('tatPercentCodes', result.businessCodes.filter(d => d.classificationCode === 'TatPercentSearchCode'));
          this.get('tatPercentCodes').unshiftObject({code: 'A', name: this.getLanguageResource('6700', 'F', '', '전체')});
          this.set('hpcSelectedValue', 'All');
          if(!isEmpty(cvrReasonItemList)){
            cvrReasonItemList.map(item =>{
              set(item, 'businessCode', item.code);
              return item;
            });
          }
          this.set('cvrReasonItemList', cvrReasonItemList);
          if(!isEmpty(result.examinationTagNameItemsSource)){
            this._setFilterdExaminationTagList(result.examinationTagNameItemsSource);
          }
          this._getPersonalizationSetting();
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      }
    },

    _setFilterdExaminationTagList(examinationTagNameItemsSource){
      //검사분류, 작업단위, 검사항목별로 나눠서 저장해둠
      const filterdExaminationTagList=[];
      examinationTagNameItemsSource.forEach(e=>{
        filterdExaminationTagList.addObject(this._filterExaminationTagList(
          e.workListFindConfigurationId, e.property.classifications, e.property.unitWorks, e.property.observationExaminations));
      });
      this.set('filterdExaminationTagList', filterdExaminationTagList);
    },

    _getPersonalizationSetting(){
      let hasTagNameItem = false;
      const today= this.get('co_CommonService').getNow();
      const fromTime = new Date(today.getFullYear(), today.getMonth(), today.getDate(), 0, 0, 0);
      const toTime = new Date(today.getFullYear(), today.getMonth(), today.getDate(), 23, 59, 59);
      this.set('examinationTagNameSelectedItem', this.get('examinationTagNameItemsSource.firstObject'));
      // this.set('searchCondition',searchCondition);
      this.get('co_PersonalizationService').getSettingInfo(`specimen-examination-report-examination-results-by-item`).then((settingInfo) => {
        const searchCondition= {
          checkInFromDate: today,
          checkInToDate: today,
          checkInFromDateTime: fromTime,
          checkInToDateTime: toTime,
          tatSearchTypecode: this.get('tatSearchTypecodeItemsSource.firstObject.code'),
          encounterTypeCode: this.get('patientTypeItemsSource.firstObject.code'),
          tatSearchTimeMinute: this.get('tatSearchTimeMinuteItemsSource.firstObject.code'),
          queryOption : "1",
          tatPercentSearchTypeCode: this.get('tatPercentCodes.firstObject.code')
        };
        this.set('tatDirectInputTimeMinute', searchCondition.tatSearchTimeMinute);
        if(isEmpty(settingInfo.settingValue)){
          searchCondition.queryOption= this.get('searhConditionItemsSource.firstObject.code');
          searchCondition.classificationIds= null;
          searchCondition.unitWorkIds= null;
          searchCondition.examinationIds= null;
          searchCondition.isStat= false;
          searchCondition.isToday= false;
          this.set('examinationTagNameSelectedItem', this.get('examinationTagNameItemsSource.firstObject'));
          // this.set('searchCondition',searchCondition);
        }else{
          const data = JSON.parse(settingInfo.settingValue).conditionData.get('firstObject');
          searchCondition.queryOption= isEmpty(data.queryOption)? '1': data.queryOption;
          searchCondition.isStat= isEmpty(data.isStat)? false: data.isStat;
          searchCondition.isToday= isEmpty(data.isToday)? false: data.isToday;
          this.set('searchCondition',searchCondition);
          this.set('isReportSubSearchVisible', JSON.parse(settingInfo.settingValue).isSubSearchVisible);
          if(isPresent(JSON.parse(settingInfo.settingValue).hpcSearchTypeCode)) {
            this.set('hpcSelectedValue', JSON.parse(settingInfo.settingValue).hpcSearchTypeCode);
          }
          if(this.get('isReportSubSearchVisible')) {
            this.set('calcPixel', 125);
          } else {
            this.set('calcPixel', 80);
          }
          if(!isEmpty(this.get('examinationTagNameItemsSource')) && !isEmpty(JSON.parse(settingInfo.settingValue).conditionData[1].workListFindConfigurationId)){
            hasTagNameItem = true;
            this.set('examinationTagNameSelectedItem', this.get('examinationTagNameItemsSource').findBy('workListFindConfigurationId', JSON.parse(settingInfo.settingValue).conditionData[1].workListFindConfigurationId));
            this._getResultList(this._setSearchConditionProperty(this.get('examinationTagNameSelectedItem')));
            this._getDepartment();
            next(this, function(){
              this.set('searchCondition',searchCondition);
            }.bind(this));
            return;
          }else{
            this.set('examinationTagList', JSON.parse(settingInfo.settingValue).examinationTagList);
            this._getDepartment();
            searchCondition.classificationIds= data.classificationIds;
            searchCondition.examinationIds= data.examinationIds;
            searchCondition.unitWorkIds= data.unitWorkIds;
            this.set('examinationTagNameSelectedItem', JSON.parse(settingInfo.settingValue).conditionData[1]);
            // this.set('searchCondition',searchCondition);
          }
          this.set('searchCondition',searchCondition);
        }
        next(this, function(){
          this.set('searchCondition',searchCondition);
        }.bind(this));
        if(!hasTagNameItem) {
          this._getResultList(searchCondition);
          this._getDepartment();
        }
      }).catch(function(e){
        this.set('searchCondition', {
          checkInFromDate: today,
          checkInToDate: today,
          tatSearchTypecode: this.get('tatSearchTypecodeItemsSource.firstObject.code'),
          encounterTypeCode: this.get('patientTypeItemsSource.firstObject.code'),
          tatSearchTimeMinute: this.get('tatSearchTimeMinuteItemsSource.firstObject.code'),
          queryOption : "1"
        });
        this.set('examinationTagNameSelectedItem', this.get('examinationTagNameItemsSource.firstObject'));
        this._catchError(e);
      }.bind(this));

    },

    didInsertElement() {
      this._super(...arguments);
      this.set('_internalClickEventHandler', function () {
        // event.preventDefault();
        if(this.get('tatListEl')) {
          if (this.get('tatListEl').style.display === 'block' && event.target !== this.get('tatInputEl')) {
            this.get('tatInputEl').blur();
            this.set('tatListStyle', 'display:none;');
          }
          if(event.target === this.get('tatInputEl')) {
            this.get('tatInputEl').select();
          }
        }
      }.bind(this));
      this.element.addEventListener('click', this._internalClickEventHandler, false);
      this.get('co_ContentMessageService').subscribeMessage('returnTextResultToResultByItem', this.get('currentMenuId'), this, this.returnTextResult);
      this.get('inputElement').select();
      // this.$('[name*="specimen-examination-report-examination-microbiology_specimenNumber"] input').select();
    },

    willDestroyElement() {
      this._super(...arguments);
      this.element.removeEventListener('click', this._internalClickEventHandler, false);
      this.get('co_ContentMessageService').unsubscribeMessage('returnTextResultToResultByItem', this.get('currentMenuId'), this, this.returnTextResult);
    },

    //Text-Result 화면 결과입력 이후 Call-Back Message
    returnTextResult(params){
      this.set('returnTextRecordId', params);
      this._getResultList(this.get('searchCondition'));
    },

    // 4. Actions Area
    actions: {
      onCheckInDateUpdated(e) {
        const fromTime = new Date(e.selectedFromDate.getFullYear(), e.selectedFromDate.getMonth(), e.selectedFromDate.getDate(), 0, 0, 0);
        const toTime = new Date(e.selectedToDate.getFullYear(), e.selectedToDate.getMonth(), e.selectedToDate.getDate(), 23, 59, 59);
        set(this.get('searchCondition'), 'checkInFromDateTime', fromTime);
        set(this.get('searchCondition'), 'checkInToDateTime', toTime);
        this.set('tatListStyle', 'display:none;');
        this._getResultList(this._setSearchConditionProperty(this.get('examinationTagNameSelectedItem')));
      },
      onGridScroll(e){
        if(this.get('originalDatas.length') === this.get('resultListItemsSource.length')) {
          return;
        }
        if(e.maxTop !== 0 && Math.round(e.maxTop) <= Math.round(e.top) + 1){
          this.set('currentPage', this.get('currentPage') + 1);
          const pageItems = this.getPageSource(this.get('originalDatas'));
          if(isEmpty(pageItems)) {
            return;
          }
          this.get('resultListItemsSource').addObjects(pageItems);
        }
      },
      //2020.12.23 TAT 직접입력 옵션 추가
      onTatInputLoaded(e) {
        let inputdEl = document.getElementById(e.source.elementId).getElementsByTagName('input')[0];
        this.set('tatInputEl', inputdEl);
        inputdEl = null;
      },
      onTatListboxLoaded(e) {
        let inputdEl = document.getElementById(e.source.elementId);
        this.set('tatListEl', inputdEl);
        inputdEl = null;
      },
      onTATChanged(e) {
        this.set('tatDirectInputTimeMinute', e.item.name);
        this.set('tatListStyle', 'display:none;');
        this._getResultList(this._setSearchConditionProperty(this.get('examinationTagNameSelectedItem')));
        this.set('isTATListClick', false);
      },
      onTATFocusIn() {
        this.set('tatListStyle', 'display:block;');
      },
      onTATInputKeyDown() {
        if(event.keyCode === 27) {
          this.get('tatInputEl').blur();
          this.set('tatListStyle', 'display:none;');
        }
      },
      onTATListClick() {
        this.set('isTATListClick', true);
      },
      onInitializeBtnClick(){
        //그리드, 검체번호 초기화
        this.set('resultListSelectedItem', null);
        this.set('resultListItemsSource', []);
        set(this.get('searchCondition'), 'specimenNumber', null);

      },
      onCommentBtnClick(e){
        if(isEmpty(this.get('resultListSelectedItem'))){
          this.get('specimenexaminationreportService')._showMessage( this.getLanguageResource('9260', 'F','Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        this.toggleProperty('initializeTimeVolume');
        this.set('isCommentOpen', true);
        this.set('commentPopupTarget', e.originalEvent.currentTarget);
      },
      onLoadCombobox(e){
        if (e.source.name =='issuedDepartment'){
          this.set('issuedDepartmentCombobox', e.source);
        }
      },
      onFoldClick() {
        this.set('isReportSubSearchVisible', !this.get('isReportSubSearchVisible'));
        if(this.get('isReportSubSearchVisible')) {
          this.set('calcPixel', 125);
        } else {
          this.set('calcPixel', 80);
        }
        this._setPersonalSettingInfo(this.get('searchCondition'));
      },

      onSendCvrClick(){
        if(isEmpty(this.get('resultListSelectedItem'))){
          this.get('specimenexaminationreportService')._showMessage( this.getLanguageResource('9260', 'F','Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
          return false;
        }else if(this.get('resultListSelectedItem.check.isCritical')){
          this._sendCvr();
        }else{
          this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('10746', 'F', '', 'CVR대상 검사가 아닙니다. ') + this.getLanguageResource('10747', 'F', 'CVR을 전송하시겠습니까?'),
            'question', 'YesNo', 'Yes', '', null).then(function(result){
            if(result === 'Yes'){
              this._sendCvr();
            }
          }.bind(this)).catch(function(e){
            this._catchError(e);
          }.bind(this));
        }
      },

      onSearchAction(e){
        this.set('tatListStyle', 'display:none;');
        if(e ==='specimenNumberCommit' && isEmpty(this.get('searchCondition.specimenNumber'))) {
          return;
        }
        this.set('isSpecimenNumberCommit', e ==='specimenNumberCommit'? true: false );
        this.set('comments', {
          isCommentsExpanded: false,
          deptCommentsCount: 0
        });
        // this.set('isResultGridShow', true);
        this._getResultList(this._setSearchConditionProperty(this.get('examinationTagNameSelectedItem')));
      },

      onGridLoad(e) {
        this.set('_gridControl', e.source);
      },

      onResultListSelectionChange(e){
        this.set('isCommentOpen', false);
        this.set('selectedItems', this.get('_gridControl.selectedItems'));
        if(isEmpty(e.selectedItems) || (e.selectedItems.length > 1)) {
          this.set('comments', {
            isCommentsExpanded: false,
            deptCommentsCount: 0
          });
          this.set('isCommentDisabled', true);
        } else if(e.selectedItems.length === 1) {
          this.set('resultListSelectedItem', e.selectedItems[0]);
          this._getDepartmentComments();
          this.set('isCommentDisabled', false);
        }
      },

      onEditStart(e){
        this.set('_gridControl', e.source);
        this.set('previousItem', this.get('currentItem'));
      },

      onEditEnd(){
        const previousItem= this.get('previousItem');
        if(previousItem.isCellClick && previousItem.isValueChanged){
          set(previousItem, 'value.quantity.value', isEmpty(previousItem.numericCellInputValue)? null : previousItem.numericCellInputValue);
          set(previousItem, 'value.quantity.comparator', '-');
          set(previousItem , 'isValueChanged', true);
          this.set('gridDisabled', true);
          this.get('specimenexaminationreportService')._calculate("Rule", true, previousItem, [previousItem]).then(returedItem=>{
            this.set('gridDisabled', false);
            if(!isEmpty(returedItem)){
              this.set('previousItem', returedItem);
            }

            if(!isEmpty(this.get('_currentCell'))){
              if(!isEmpty(this.get('_gridControl').getItem(this.get('_currentCell.rowIndex')).numericCellInputValue)){
                // this.set('gridEditable', false);
                next(this, function() {
                  this.get('_gridControl').deselectCell(this.get('_currentCell.rowIndex'), this.get('_currentCell.cellIndex'));
                }.bind(this));
              }
            }
            later(() => {
              this.get('_gridControl').deselectAll();
              if(isPresent(this.get('clickInput'))) {
                set(this.get('clickInput.style'), 'textAlign', 'center');
              }
            });
          }).catch(function(error){
            this._catchError(error);
          }.bind(this));

          set(previousItem, 'isCellClick', false);
          this.set('isClosed', true);
        }
      },

      onBeforeFocusIn(e) {
        this.set('_gridControl', e.source);
        if(e.type.includes('body')) {
          if(e.type.includes('cell')) {
            // this.set('previousItem', this.get('currentItem'));
            this.set('currentItem', e.source.getOriginalSource(e.originalEvent).item);
            this._setCurrentCell(e);
            e.cancel = true;
          }
        }
        if(e.type.includes('body')) {
          if(e.type.includes('ghead')) {
            if(e.type.includes('expander')) {
              e.source.deselectAll();
            }
          }
        }
      },
      onBeforeMouseDown(e){
        if(e.source.getCurrentCell().column=='resultEntry'){
          this._closeEntryPopups();
          return;
        }
        if(this.get('previousItem.examination.name') !=this.get('currentItem.examination.name')){
          this._closeEntryPopups();
        }
        this.set('isResultCommentPopupOpen', false);
      },

      onBeforeClick(){
        if(this.get('previousItem.examination.name') !=this.get('currentItem.examination.name')){
          this._closeEntryPopups();
        }
        this.set('isResultCommentPopupOpen', false);
      },

      onCellClick(e){
        if(isEmpty(e.item)){
          return;
        }
        if(isEmpty(this.get('previousItem'))){
          this.set('previousItem', this.get('currentItem'));
        }
        this.set('currentItem', e.item);
        if((this.get('previousItem.examinationId') !=this.get('currentItem.examinationId'))
        && (this.get('previousItem.basedOnId') !=this.get('currentItem.basedOnId'))){
          this._closeEntryPopups();
          //닫힌 previousItem calculate해야함
          this.set('previousItem', this.get('currentItem'));
          return;
        }
        const bodyTemplateName= e.column.bodyTemplateName;

        if(isEmpty(this.get('currentItem.remark'))){
          this.set('commentsListSelectedItem', null);
        }
        const currentItem= this.get('currentItem');
        this.set('resultListSelectedItem', e.item);
        // this._getDepartmentComments();
        if(bodyTemplateName=='resultEntry'){
          if(currentItem.valueTypeCode == 'Quantity'){
            if(isEmpty(currentItem.valueValueString)){
              this.set('gridEditable', true);
              set(currentItem, 'isCellClick', true);
            }else{
              this.set('gridEditable', false);
              this.set('isQuantityEntryOpen', true);
              if(isPresent(this.get('clickInput'))) {
                set(this.get('clickInput.style'), 'textAlign', 'center');
              }
            }
          }else if(currentItem.valueTypeCode == 'CodeableConcept'){
            this.set('popupMode', 'results-by-item');
            this.set('isConceptEntryOpen', true);
          }else if(currentItem.valueTypeCode == 'ValueString'){
            this.set('isStringEntryOpen', true);
          }else if(currentItem.valueTypeCode == 'ValueTextString'){
            // if(isEmpty(currentItem.get('value.recordNoteId'))){
            //   this.set('isStringEntryOpen', true);
            // }
          }
          if(isPresent(this.get('clickInput'))) {
            set(this.get('clickInput.style'), 'textAlign', 'center');
          }
        }else if(bodyTemplateName ==='resultComments'){
          this.set('isResultCommentPopupOpen', true);
          this.set('commentPopupTitleResource', this.getLanguageResource('906', 'S','결과비고'));
          this.set('commentPopupPlacementTarget', `#${e.originalSource.element.id}`);
          this.set('remark', e.item.comment);
        }
        this.set('focusCellItem', null);
        this.set('focusFieldName', null);
        const field = e.column.field;
        if(field === 'specimenNumber' || field === 'subject.displayNumber' || field === 'subject.number') {
          this.set('focusFieldName', field);
          this.set('focusCellItem', e.item);
        }
      },

      onMaskedInputLoaded(e) {
        let inputdEl = document.getElementById(e.source.elementId).getElementsByTagName('input')[0];
        inputdEl.style.textAlign = 'center';
        inputdEl = null;
      },

      onNumericCellValueChanged(resultListSelectedItem){
        set(resultListSelectedItem, 'isValueChanged', true);
      },

      onNumericCellKeyUp(item, e){
        // if(!isEmpty(this.get('resultListSelectedItem'))){
        //   set(this.get('resultListSelectedItem'), 'isCellClick', true);
        //   if(event.keyCode === 8 || event.keyCode === 46) {
        //     set($(`#${e.source.elementId}`).find('input')[0], 'placeholder', ' ');
        //   }
        //   set(this.get('resultListSelectedItem'), 'numericCellInputValue', e.source.value);
        // }
        if(!isEmpty(item)){
          set(item, 'isCellClick', true);
          if(event.keyCode === 8 || event.keyCode === 46) {
            set($(`#${e.source.elementId}`).find('input')[0], 'placeholder', ' ');
          }
          set(item, 'numericCellInputValue', e.source.value);
        }
      },

      onNumericCellClick(item, e){
        // if(!isEmpty(this.get('resultListSelectedItem'))){
        //   set(this.get('resultListSelectedItem'), 'numericCellInputValue', e.source.value);
        // }
        let inputdEl = document.getElementById(e.source.elementId).getElementsByTagName('input')[0];
        this.set('clickInput', inputdEl);
        inputdEl = null;
        set(item, 'numericCellInputValue', e.source.value);
        set(item, 'isCellClick', true);
        if(isPresent(this.get('clickInput'))) {
          set(this.get('clickInput.style'), 'textAlign', 'center');
        }
      },

      onCellDoubleClick(e){
        if(e.column.bodyTemplateName === 'resultEntry'){
          if(e.item.valueTypeCode === 'Quantity'){
            if(e.item.isCellClick){
              set(e , 'item.key', e.source.selectedItem.numericCellInputValue);
              set(e, 'item.isCellClick', false);
            }
            if(isPresent(this.get('clickInput'))) {
              set(this.get('clickInput.style'), 'textAlign', 'center');
            }
            this.set('isQuantityEntryOpen', true);
          }else if(e.item.valueTypeCode === 'ValueTextS1tring'){
            if(e.column.field ==='valueValueString'){
              this._openTextResultManagement(e);
            }
          }else if(e.column.field ==='examination.name'){
            this._openTextResultManagement(e);
          }
        } else {
          let examinationState = null;
          if(isPresent(e.item.statusCode)) {
            examinationState = e.item.statusCode.charAt(0).toUpperCase() + e.item.statusCode.slice(1);
          }
          const globalItem = {
            patientGlobalPathType: 'Encounter',
            patientChoicePath: 'Encounter',
            patientId: e.item.subjectId,
            encounterId: e.item.encounterId,
            examination:{
              name: e.item.examination.name,
              id: e.item.examination.id,
              specimenId: e.item.specimenId,
              state: examinationState,
            },
            patientSelectionSource: {
              viewId: this.get('viewId')
            }
          };
          this.get('co_PatientManagerService').selectPatient(globalItem);
        }
      },
      returnResultValueCB(){
        this.set('hasChanged', true);
        this._moveFocus('down', false);

      },
      onReturnResultValueCB(){
        //결과입력팝업 Callback
        // this.get('_gridControl').focusCell(this.get('_currentCell.rowIndex'),this.get('_currentCell.cellIndex'));
        // this.get('_gridControl').deselectAll();
        this._moveFocus('down', false);
      },

      onReturnCalculatedValueCB(tmp, currentItem){
        //결과입력팝업 Callback
        let resultListSelectedItem= this.get('resultListSelectedItem');
        const previousItem= this.get('previousItem');
        if(!isEmpty(previousItem)){
          if(this.get('previousItem') != this.get('currentItem')){
            resultListSelectedItem= this.get('previousItem');
          }
        }
        if(this.get('popupMode') === 'results-by-item-micro') {
          const selectedItems = this.get('_gridControl.selectedItems');
          this.get('resultListItemsSource').forEach(item => {
            const findItem = selectedItems.find(d => d.checkInId === item.checkInId);
            const findItemIndex = selectedItems.findIndex(d => d.checkInId === item.checkInId);
            const findResultItem = tmp.find((d, ind) => ind === findItemIndex && d.examinationId === selectedItems[findItemIndex].examinationId);
            if(isPresent(findItem) && isPresent(findResultItem) && item.valueTypeCode === 'CodeableConcept') {
              set(item, 'isUpdated', true);
              const res= this.get('specimenexaminationreportService')._setResultValue(findResultItem);
              set(item, 'value', res.value);
              set(item, 'valueValueString', res.valueValueString);
              set(item, 'numericCellInputValue', res.valueValueString);
            }
          });
        } else {
          resultListSelectedItem= currentItem;
          const res= this.get('specimenexaminationreportService')._setResultValue(tmp);
          set(resultListSelectedItem, 'valueValueString', res.valueValueString);
          set(resultListSelectedItem, 'numericCellInputValue', res.valueValueString);
          set(resultListSelectedItem, 'interpretation', res.interpretation);
          if(!isEmpty(res.interpretation)){
            set(resultListSelectedItem, 'interpretation.code', res.interpretation.coding.get('firstObject.code'));
          }
          // isNotAnalyticalMeasurementRange, isRecheck 빼고 update
          // set(resultListSelectedItem, 'check', res.check);
          if(!isEmpty(res.check)){
            set(resultListSelectedItem, 'check.isCritical', res.check.isCritical);
            set(resultListSelectedItem, 'check.isDelta', res.check.isDelta);
            set(resultListSelectedItem, 'check.isPanic', res.check.isPanic);
            set(resultListSelectedItem, 'check.isRecentCritical', res.check.isRecentCritical);
            // if(resultListSelectedItem.statusCode == "waiting"){
            if(resultListSelectedItem.check.isNotAnalyticalMeasurementRange != res.check.isNotAnalyticalMeasurementRange){
              //calculate 후 달라졌을 경우만 업데이트
              set(resultListSelectedItem, 'check.isNotAnalyticalMeasurementRange', res.check.isNotAnalyticalMeasurementRange);
            }
          }
          set(resultListSelectedItem, 'value', res.value);
        }
        next(() => {
          this.get('_gridControl').deselectAll();
          if(isPresent(this.get('clickInput'))) {
            set(this.get('clickInput.style'), 'textAlign', 'center');
          }
        });
      },

      onReturnResultCommentsCB(resultComments){
        const currentItem= this.get('currentItem');
        set(currentItem , 'remark', resultComments);
        set(currentItem , 'remarkTooltip', resultComments);
        set(currentItem , 'selectedResultComments', resultComments);
        set(currentItem , 'isUpdated', true);
        if(isEmpty(this.get('commentsListSelectedItem'))){
          return;
        }
        if(!isEmpty(this.get('commentsListSelectedItem.exampleTypeCode'))){
          set(currentItem , 'remark', this.get('commentsListSelectedItem.value.valueString'));
        }
      },

      onReturnChangesReasonCB(item, remark){
        if(!isEmpty(item)){
          this.set('isResultGridShow', true);
          if(!isEmpty(remark)){
            this.set('changeReasonRemark', isEmpty(remark)?'': remark.replace(/<br>|<br\/>|<br \/>/giu, '\r\n'));
          }
          this.set('editReasonSelectedItem', item);
          this._setSaveParams('final');
        }else{
          this.set('isResultGridShow', false);
        }
      },
      onReasonEntryCancel() {
        this.set('isCorrectReasonEntryOpened', false);
        this.set('isResultGridShow', false);
        this.set('isSaveButtonDisabled' , false);
      },

      onBeforeKeyDown(e) {
        if(isEmpty(this.get('resultListItemsSource'))) {
          return;
        }
        const type = this.get('specimenexaminationreportService').getKeyBoardEventType(e.originalEvent);

        this.set('isResultCommentPopupOpen', false);
        if(type === 'edit') {
          const bodyTemplateName= e.source.getOriginalSource(e.originalEvent).column.bodyTemplateName;
          const currentItem = this.get('currentItem');
          if(bodyTemplateName === 'resultEntry'){
            this._setCurrentCell(e);
            if(this.get('currentItem.valueTypeCode')=='Quantity'){
              set(currentItem , 'isKeydown', true);
              set(currentItem , 'key', e.originalEvent.key);
            }else if(this.get('currentItem.valueTypeCode')== 'CodeableConcept'){
              this.set('popupMode', 'results-by-item');
              this.set('isConceptEntryOpen', true);
            }else if(currentItem.valueTypeCode === 'ValueString'){
              set(currentItem , 'isKeydown', true);
              set(currentItem , 'key', e.originalEvent.key);
              this.set('isStringEntryOpen', true);
            }
            //ValueTextString타입은 TEXT버튼만 보이게
            // || (currentItem.valueTypeCode== 'ValueTextString' && isEmpty(currentItem.value.recordNoteId))){
            // }
          }
        }else if(type === 'enter'){
          //수치형 cellclick바로 입력후 엔터 마지막 row
          if(this.get('resultListItemsSource').length === this.get('_currentCell').rowIndex +1){
            // this._moveFocus('self', false);

            this.get('_gridControl').focusCell(this.get('_currentCell.rowIndex'), this.get('_currentCell.cellIndex')+1);
          }
        }
        if(isPresent(this.get('focusCellItem')) && e.originalEvent.ctrlKey && e.originalEvent.keyCode === 67 ) {
          this.copyToClipboard(this.get(`focusCellItem.${this.get('focusFieldName')}`));
        }
      },

      onResultsDraftClick(){
        const selectedItems = this.get('_gridControl.selectedItems');
        if(isEmpty(selectedItems)) {
          this.get('specimenexaminationreportService')._showMessage( this.getLanguageResource('9260', 'F','Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        if(this.get('useTypeCode') === 'Microbiology' && isPresent(selectedItems.filter(e => e.statusCode === 'final' || e.statusCode ==='corrected'))) {
          this.get('specimenexaminationreportService')._showMessage( this.getLanguageResource('9288', 'F','검사상태를 확인해주시기 바랍니다.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        this._setSaveParams('preliminary');
      },
      onMicroPreliminaryClick() {
        //TODO
        const selectedItems = this.get('_gridControl.selectedItems');
        if(isEmpty(selectedItems)) {
          this.get('specimenexaminationreportService')._showMessage( this.getLanguageResource('9260', 'F','Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        if(this.get('useTypeCode') === 'Microbiology' && isPresent(selectedItems.filter(e => e.statusCode === 'final' || e.statusCode ==='corrected'))) {
          this.get('specimenexaminationreportService')._showMessage( this.getLanguageResource('9288', 'F','검사상태를 확인해주시기 바랍니다.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        this.get('resultListItemsSource').forEach(item => {
          const findItem = selectedItems.find(d => d.checkInId === item.checkInId);
          if(isPresent(findItem)) {
            set(item, 'isUpdated', true);
            set(item, 'isReport', true);
          }
        });
        this._setSaveParams('preliminary');
      },

      onResultsSaveClick(){
        this._setSaveParams('final');
      },

      onInappropriateSpecimenRegistrationClick(){
        this._getInappropriateInfo();
      },

      onCumulativeSearchBtnClick(e){
        if(isEmpty(this.get('selectedItems'))){
          this.get('specimenexaminationreportService')._showMessage( this.getLanguageResource('9260', 'F','Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        const patientId= this.get('selectedItems.firstObject.subjectId');
        let validationCheck = true;
        this.get('selectedItems').forEach(i=>{
          if(i.subjectId !== patientId){
            validationCheck = false;
            this.get('specimenexaminationreportService')._showMessage( this.getLanguageResource('9261', 'F','환자번호를 확인하세요'), 'warning', 'Ok', 'Ok', '', 2000);
          }
        });
        if(!validationCheck){
          return;
        }
        this.set('patientId', patientId);
        this.set('isSpecimenExamSummaryOpen', true);
        this.set('specimenExamSummaryTarget', e.originalEvent.currentTarget);

        this.set('examinationIds', this.get('selectedItems').map(function(i){
          return i.examinationId;
        })
        );
      },

      onPrintBarcodeClick(){
        this.getPrinterName().then(function(res){
          this.set('printSetting', res);
          this._printBarcode();
        }.bind(this)).catch(function(err) {
          this._catchError(err);
        }.bind(this));
      },

      //2018-12-07 검색조건 UI수정
      onSearchPopupOnClick(e){
        this.set('findSettingPopupInfo.isOpen', !this.get('findSettingPopupInfo.isOpen'));
        this.set('findSettingPopupInfo.targetId', e.originalEvent.currentTarget);
      },
      //팝업 콜백 이벤트
      onFindSettingCallBackCB(sResult){
        this.set('examinationTagNameSelectedItem', null);
        this._setExaminationTagList(sResult.tagList);
        this.set('examinationCategoryTagItems', sResult.examinationCategoryTagItems);
        this.set('examinationUnitTagItems', sResult.examinationUnitTagItems);
        this.set('examinationTagItems', sResult.examinationTagItems);
        this.set('comments', {
          isCommentsExpanded: false,
          deptCommentsCount: 0
        });
        let searchCondition = null;
        if(!isEmpty(sResult.workListFindConfigurationId)){
          //저장된 세트를 선택한 경우
          // this._setExaminationComboBox(sResult.workListFindConfigurationId);
          this.getList(this.get('defaultUrl') + 'worklist-configurations/search',
            {staffId: this.get('co_CurrentUserService.user.employeeId')}, null).then(function(res){
            this.set('examinationTagNameItemsSource', res);
            if(!isEmpty(res)){
              const filterdExaminationTagList=[];
              res.forEach(e=>{
                if(e.workListFindConfigurationId === sResult.workListFindConfigurationId){
                  this.set('examinationTagNameSelectedItem', e);
                }
                //검사분류, 작업단위, 검사항목별로 나눠서 저장해둠
                filterdExaminationTagList.addObject(this._filterExaminationTagList(
                  e.workListFindConfigurationId,
                  e.property.classifications, e.property.unitWorks, e.property.observationExaminations));
              });
              this.set('filterdExaminationTagList', filterdExaminationTagList);
            }
            searchCondition = this._setSearchConditionProperty(this.get('examinationTagNameSelectedItem'));
            this._getResultList(searchCondition);
            this._setPersonalSettingInfo(searchCondition);
            // this._getResultList(this._setSearchConditionProperty(this.get('examinationTagNameSelectedItem')));
          }.bind(this)).catch(function(error){
            this._catchError(error);
          }.bind(this));
        }else{
          let tmp = null;
          if(isEmpty(this.get('filterdExaminationTagList'))){
            return;
          }
          this.get('filterdExaminationTagList').forEach(e => {
            if(compare(e.mapBy('id'),sResult.tagList.mapBy('id'))==0){
              tmp=e.workListFindConfigurationId;
            }
          });
          if(tmp === null){
            //저장된 set 이 아닌경우
            this.set('examinationTagNameSelectedItem', null);
            this.set('examinationTagList', sResult.tagList);
          }else{
            this.set('examinationTagNameSelectedItem',this.get('examinationTagNameItemsSource').findBy('workListFindConfigurationId',tmp));
            this.set('examinationTagList', sResult.tagList);
          }
          searchCondition = this._setSearchConditionProperty();
          this._getResultList(searchCondition);
          this._setPersonalSettingInfo(searchCondition);
          // this._getResultList(this._setSearchConditionProperty());
        }
      },
      onExamSetSelectionChanged(e){
        this.set('comments', {
          isCommentsExpanded: false,
          deptCommentsCount: 0
        });
        const searchCondition = copy(this.get('searchCondition'));
        set(searchCondition, 'classificationIds', []);
        set(searchCondition, 'unitWorkIds', []);
        set(searchCondition, 'examinationIds', []);
        this.set('searchCondition', searchCondition);
        this.set('examinationTagNameSelectedItem',e.item);
        const conditions = this._setSearchConditionProperty(e.item);
        this._getResultList(conditions);
        this._setPersonalSettingInfo(conditions);
      },
      onTatPercentCodeChanged(e) {
        const searchCondition = copy(this.get('searchCondition'));
        this.set('searchCondition.tatPercentSearchTypeCode', e.item.code);
        this._getResultList(searchCondition);
        this._setPersonalSettingInfo(searchCondition);
      },
      onHpcChanged(e){
        const searchCondition = copy(this.get('searchCondition'));
        this.set('hpcSelectedValue',e.value);
        this._getResultList(searchCondition);
        this._setPersonalSettingInfo(searchCondition);
      },

      onEncounterTypeCodeChanged(){
        this._getDepartment();
      },

      onEntryBtnOpenAction(mode, e){
        if(isEmpty(this.get('selectedItems'))){
          this.get('specimenexaminationreportService')._showMessage( this.getLanguageResource('9260', 'F','Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        if(!isEmpty(this.get('selectedItems').findBy('valueTypeCode', "Quantity"))){
          this.get('specimenexaminationreportService')._showMessage( this.getLanguageResource('11090', 'F','처리할 수 없습니다'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        const selectedItem = this.get('_gridControl.selectedItems.firstObject');
        this.set('negativeEntryTarget', e.originalEvent.currentTarget);
        if(this.get('isMicrobiology') && selectedItem.valueTypeCode === 'ValueTextString') {
          // if(isPresent(this.get('selectedItems.firstObject.value'))){
          //   this.set('entryValueTextString', this.get('selectedItems.firstObject.value.valueTextString'));
          // }
          this.set('isValueTextEntryOpen', true);
          return;
        }
        if(this.get('isMicrobiology') && selectedItem.valueTypeCode === 'CodeableConcept') {
          this.set('currentItem', selectedItem);
          this.set('_currentCell', {element: e.originalEvent.currentTarget});
          this.set('popupMode', 'results-by-item-micro');
          this.set('isConceptEntryOpen', true);
          return;
        }
        this.set('selectedItems', this.get('selectedItems'));
        if(mode== 'All'){
          this.set('classificationCode', 'ItemCodeableConcept');
          // this.set('negativeEntryTitle', this.getLanguageResource('12470', 'F','결과 일괄입력'));
        }else if (mode== 'Negative'){
          this.set('classificationCode', 'NegativeCodeableConcept');
          // this.set('negativeEntryTitle', this.getLanguageResource('10110', 'F','Negative 처리'));
        }
        this.set('isNegativeEntryOpen', true);
      },
      onValueTextClearClick() {
        this.set('entryValueTextString', null);
        this.set('exampleSelectedItemsText', []);
      },
      onValueTextConfirm() {
        const selectedItems = this.get('_gridControl.selectedItems');
        const entryValueTextString = this.get('entryValueTextString');
        this.get('resultListItemsSource').forEach(item => {
          const findItem = selectedItems.find(d => d.checkInId === item.checkInId);
          if(isPresent(findItem)) {
            set(item, 'isUpdated', true);
            set(item.value, 'valueTextString', entryValueTextString);
          }
        });
        this.set('isValueTextEntryOpen', false);
      },
      onValueTextEntryClosed() {
        this.set('entryValueTextString', null);
        this.set('exampleSelectedItemsText', []);
      },
      onExampleGridLoad(e) {
        this.set('ExampleGrid', e.source);
      },
      onResultExampleSelectedAction(e) {
        const exampleSelectedItemsText = [];

        e.selectedItems.forEach(item => {
          exampleSelectedItemsText.push(item.name);
        });
        this.set('exampleSelectedItemsText', exampleSelectedItemsText.join(', '));
        // this.set('exampleSelectedItemsText', exampleSelectedItemsText.join('\r\n'));

      },
      onFindResultExampleClick(e) {
        this.set('isResultExampleOpen', true);
        this.set('resultExampleTarget', e.originalEvent.currentTarget);
      },
      onExampleApply() {
        const changedTextValue = this.get('exampleSelectedItemsText');
        if(isEmpty(changedTextValue)) {
          return;
        }
        // this.set('entryValueTextString', changedTextValue);
        this.set('entryValueTextString', changedTextValue.split(', ').join('\r\n'));
        this.set('isResultExampleOpen', false);
      },
      onExampleResetClick() {
        this.set('exampleSelectedItemsText', []);
        this.get('ExampleGrid').deselectAll();
      },
      onExampleCloseClick() {
        this.set('isResultExampleOpen', false);
      },
      onResultExxampleClosed() {
        this.set('exampleSelectedItemsText', []);
      },

      onReturnNegativeCB(e){
        if(this.get('classificationCode') == 'ItemCodeableConcept'){
          this.set('negativeCodeableConcept', e);
          this._setSaveParams('negative');
        }else if(this.get('classificationCode') == 'NegativeCodeableConcept'){
          this.set('negativeCodeableConcept', e);
          this._setSaveParams('all');
        }
      },

      onPrintBtnClick(){
        if(isEmpty( this.get('resultListItemsSource'))){
          this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9264', 'F', '조회된 정보가 없습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        const selectedItems= this.get('selectedItems');
        if(isEmpty(selectedItems)){
          this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9260', 'F', 'Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        const searchCondition =this.get('searchCondition');
        const originaDatas = this.get('originalDatas');
        let targetItems = selectedItems;
        if(selectedItems.length === this.get('resultListItemsSource').length) {
          targetItems = originaDatas;
        }
        const worklist = [];
        targetItems.forEach(e=>{
          worklist.addObject({
            "checkInNumber" : e.checkInNumber,
            "checkInDate" : e.checkInDate.toFormatString(true, false),
            "subjectNumber" : e.subject.displayNumber,
            "subjectName" : e.subject.name,
            "issuedDepartmentName" : e.issuedDepartment.name,
            "specimenTypeName" : e.specimenType.name,
            "classificationName" : e.classification.name,
            "examinationName" : e.examination.name,
            "specimenNumber" : e.specimenNumber,
            "orderComment" : e.orderComment,
            "collectionComment": e.collectionComment,
            "result": e.numericCellInputValue,
            "ssn":""
          });
        });
        let unitWorkIds=[];
        let classificationIds=[];
        const examinationTagNameSelectedItem= this.get('examinationTagNameSelectedItem');
        if(isEmpty(examinationTagNameSelectedItem)){
          //검사set 아닌 직접 검사 선택
          this.get('examinationTagList').forEach(e=>{
            if(e.type =='category'){
              e.items.forEach(i=>{
                classificationIds.addObject(i.name);
              });
            }else if(e.type =='unit'){
              e.items.forEach(i=>{
                unitWorkIds.addObject(i.name);
              });
            }
          });
        }else{
          //콤보박스에서 저장된 검사set 선택
          classificationIds= isEmpty(examinationTagNameSelectedItem.property.classifications)? null: examinationTagNameSelectedItem.property.classifications.mapBy('abbreviation');
          unitWorkIds= isEmpty(examinationTagNameSelectedItem.property.unitWorks)? null: examinationTagNameSelectedItem.property.unitWorks.mapBy('name');
        }
        this.set('printPopup',true);
        this.set('printConfig',{'printType': 2, 'commonInformation' : true , 'printName' : "DiagnosisExaminationWorklistResultByItem"});
        // this.set('printConfig',{'printType': 2, 'commonInformation' : true , 'printName' : "DiagnosisExaminationWorklistPortrait"});
        this.set('printContent',{
          dataField : {"worklist": worklist},
          parameterField :{
            "unitWorkIds": isEmpty(unitWorkIds)? null: unitWorkIds.join(', '),
            "classificationIds" : isEmpty(classificationIds)? null: classificationIds.join(', '),
            "checkInFromDate" : searchCondition.checkInFromDate.toFormatString(true, false),
            "checkInToDate" : searchCondition.checkInToDate.toFormatString(true, false),
          }
        });
      },

      onExcelPrintAction() {
        const columns = this.get('isMicrobiology')? this.get('microbiologyResultListColumns'): this.get('resultListColumns');
        const itemsSource = this.get('originalDatas');
        if(isEmpty(itemsSource)){
          this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9264', 'F', '조회된 정보가 없습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        this.getExportExcel(itemsSource, columns);
        // const gridSource=this.get('_gridControl');
        // const reason = 'Excel export: specimen examination results';
        // const headers=[];
        // const fields=[];
        // columns.forEach(function(item, index){
        //   headers.addObject({ left: index, top: 0, right: index, bottom: 0, value: item.title});
        //   if(item.type == 'date'){
        //     fields.addObject({ width: 140, value: item.field });
        //   }else if(item.bodyTemplateName=='delta' || item.bodyTemplateName=='panic' || item.bodyTemplateName=='critical' || item.bodyTemplateName=='amr'){
        //     fields.addObject({ width: 50, value: item.field });
        //   }else{
        //     fields.addObject({ width: item.width, value: item.field });
        //   }
        // });
        // gridSource.exportToExcel('specimen_examination_results.xlsx', headers, fields, this, 'onExcelPrintAction', reason , itemsSource);
      },
      onPrintReferralBtnClick(){
        if(!isEmpty(this.get('resultListSelectedItem.referralRecordNoteId'))){
          this.set('printReferralOpen', true);
        }else{
          this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9848', 'F', '출력할 정보가 없습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
        }
      },
      async onGridKeyDown(e){
        const resultListSelectedItem = this.get('resultListSelectedItem');
        if(isEmpty(e.key) || isEmpty(resultListSelectedItem)){
          return;
        }
        if(resultListSelectedItem.valueTypeCode != 'CodeableConcept'){
          return;
        }

        if(e.key =='Alt'){
          this.set('isFunctionKey', true);
          return;
        }
        if(this.get('isFunctionKey')){
          await this.getList(this.get('defaultUrl') + 'observations/examples',
            {exampleTypeCode: 'ExampleValue', examinationId: this.get('resultListSelectedItem.examinationId')}, null).then(res=>{
            this.set('defaultvalues', res);
          }).catch(function(error){
            this._catchError(error);
          }.bind(this));

          this.set('isFunctionKey', false);
          const defaultvalues= this.get('defaultvalues');
          if(isEmpty(defaultvalues)){
            return;
          }
          defaultvalues.forEach(v=>{
            if(isEmpty(v.functionApply)){
              return;
            }
            if(isEmpty(v.get('functionApply.displayCode'))){
              return;
            }
            if((v.exampleTypeCode == "ExampleValue")
              && v.get('functionApply.displayCode').slice(v.get('functionApply.displayCode').indexOf('+')+1).toLocaleUpperCase() == e.key.toLocaleUpperCase()){
              //'alt' 제거한 문자로 비교
              set(resultListSelectedItem, 'value', v.value);
              set(resultListSelectedItem, 'valueValueString', this.get('specimenexaminationreportService')._setValueString(v));
              set(resultListSelectedItem, 'numericCellInputValue', this.get('specimenexaminationreportService')._setValueString(v));
              set(resultListSelectedItem , 'isValueChanged', true);
            }
          });
          this.set('gridDisabled', true);
          this.get('specimenexaminationreportService')._calculate("Rule", true, resultListSelectedItem, [resultListSelectedItem]).then(resultListItemsSource=>{
            this.set('gridDisabled', false);
            this.get('resultListItemsSource', resultListItemsSource);
            this._moveFocus('down', false);
          });
        }
      },
      onExePrintAfterCB(){
        this._print();
      },
      onInputLoaded(e) {
        let inputdEl = document.getElementById(e.source.elementId).getElementsByTagName('input')[0];
        this.set('inputElement', inputdEl);
        inputdEl = null;
      },
    },

    // 5. Private methods Area
    _printBarcode(){
      const selectedItems= this.get('selectedItems');
      // this.set('printDataField', []);
      this.set('printouts', null);
      this.set('printDataFieldDefault', []);
      this.set('printDataFieldD', []);
      this.set('printDataFieldG', []);
      this.set('printDataFieldF', []);
      if(isEmpty(selectedItems)){
        this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9260', 'F', 'Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
        return;
      }
      selectedItems.forEach(element => {
        set(element, 'index', this.get('_gridControl').getItemIndex(element));
      });
      // let array=[];
      selectedItems.sortBy('index').forEach(element => {
        this._getSpecimenLabel(element);
      });

      next(this, function(){
        this.set('printPopup', false);
        this._print();
        const num= isEmpty(this.get('printouts'))? '': this.get('printouts');
        this.get('specimenexaminationreportService').onShowToast('save', this.getLanguageResource('7554', 'S', '출력매수') + ": \xa0"+ num, '',8000);
      }.bind(this));
    },
    _print(){
      const printDataFieldG= this.get('printDataFieldG');
      const printDataFieldD= this.get('printDataFieldD');
      const printDataFieldF= this.get('printDataFieldF');
      const printDataFieldDefault= this.get('printDataFieldDefault');
      if(!isEmpty(printDataFieldG)){
        const e= this.setPrintParams(this.get('printSetting'), printDataFieldG, null, null, null);
        this.set('printPopup', false);
        this.set('printConfig', e.printConfig);
        this.set('printContent', e.printContent);
        this.set('printDataFieldG', []);
        return;
      }
      if(!isEmpty(printDataFieldD)){
        const e= this.setPrintParams(this.get('printSetting'), null, printDataFieldD, null, null);
        this.set('printPopup', false);
        this.set('printConfig', e.printConfig);
        this.set('printContent', e.printContent);
        this.set('printDataFieldD', []);
        return;
      }
      if(!isEmpty(printDataFieldF)){
        const e= this.setPrintParams(this.get('printSetting'), null, null, printDataFieldF, null);
        this.set('printPopup', false);
        this.set('printConfig', e.printConfig);
        this.set('printContent', e.printContent);
        this.set('printDataFieldF', []);
        return;
      }
      if(!isEmpty(printDataFieldDefault)){
        const e= this.setPrintParams(this.get('printSetting'), null, null, null, printDataFieldDefault);
        this.set('printPopup', false);
        this.set('printConfig', e.printConfig);
        this.set('printContent', e.printContent);
        this.set('printDataFieldDefault', []);
      }
    },
    _inappropriateRegistrationValidationCheck(){
      if(isEmpty(this.get('selectedItems'))){
        this.get('specimenSamplingService')._showMessage(this.getLanguageResource('9260', 'F', 'Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);

        return false;
      }
    },

    _getSpecimenLabel(e){
      const printSetting =this.get('printSetting');
      // const printDataField = this.get('printDataField');
      this.get('specimenSamplingService').getSpecimenLabel(null, e.specimenNumber).then(res=>{
        if(!isEmpty(res)){
          this._setProperty(res);
          res.specimenTypes.forEach(function(r, idx) {
            this.set('printouts', this.get('printouts') + r.labelPrintCount);
            let specimenName = res.specimenTypes[idx].abbreviation;
            if(!isEmpty(res.specimenTypes[idx].containerName)){
              specimenName = specimenName + '(' + res.specimenTypes[idx].containerName + ')';
            }
            let u=0;
            while (u < r.labelPrintCount) {
              const resCopy= $.extend(true, EmberObject.create(), res);
              resCopy.specimenName= specimenName;
              if(res.progressTypeCode =="G"&& !isEmpty(printSetting.printerG)){
                if(printSetting.printerG == printSetting.printerDefault){
                  this.get('printDataFieldDefault').pushObject(resCopy);
                }else{
                  this.get('printDataFieldG').pushObject(resCopy);
                }
              }else if(res.progressTypeCode =="D" && !isEmpty(printSetting.printerD)){
                if(printSetting.printerD == printSetting.printerDefault){
                  this.get('printDataFieldDefault').pushObject(resCopy);
                }else{
                  this.get('printDataFieldD').pushObject(resCopy);
                }
              }else if(res.progressTypeCode =="F" && !isEmpty(printSetting.printerF)){
                if(printSetting.printerF == printSetting.printerDefault){
                  this.get('printDataFieldDefault').pushObject(resCopy);
                }else{
                  this.get('printDataFieldF').pushObject(resCopy);
                }
              }else{
                this.get('printDataFieldDefault').pushObject(resCopy);
              }
              u++;
            }
          }.bind(this));
        }
        // this.set('printDataField', printDataField);
      }).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    _sendCvr(e){
      const resultListSelectedItem = isEmpty(e)? this.get('resultListSelectedItem') : e;
      if(isEmpty(resultListSelectedItem)){
        // this.get('specimenexaminationreportService')._showMessage('선택된 검사가 없습니다.', 'warning', 'Ok', 'Ok', '', 2000);
        return;
      }
      if(isEmpty(resultListSelectedItem.encounterId) || isEmpty(resultListSelectedItem.subjectId)){
        return;
      }
      this.set('isCvrOpen', true);
      this.set('cvrSendInformation', A({
        patient : { id: resultListSelectedItem.subjectId,
          displayCode: resultListSelectedItem.get('subject.displayNumber'),
          name: resultListSelectedItem.get('subject.name')},
        examination: {basedOnTypeCode: "Specimen",
          id:resultListSelectedItem.examination.id,
          basedOnId: resultListSelectedItem.specimenId,
          name: resultListSelectedItem.get('examination.name'),
          performDate: resultListSelectedItem.get('performers.firstObject.performDatetime')},
        encounter:{ id: resultListSelectedItem.encounterId},
        smsContent: null,
        staffs: [{actorTypeName: this.getLanguageResource('9686', 'F','처방의'),
          actorId:resultListSelectedItem.get('orderedStaff.id'),
          actorName: resultListSelectedItem.get('orderedStaff.name')}],
        result: null
      }));
    },
    _specimenCommit(searchCondition){
      this.set('isResultGridShow', true);
      return this.getList(this.get('defaultUrl') + 'result-worklists/observations/search', null,{
        classificationIds: null,
        unitWorkIds:searchCondition.unitWorkIds,
        examinationIds: searchCondition.examinationIds,
        queryOption: "1",
        specimenNumber: searchCondition.specimenNumber,
        subjectTypeCode: "Patient",
      }, false).then(function(res){
        if(!isEmpty(res) && !isEmpty(this.get('resultListItemsSource'))){
          // if(!isEmpty(this.get('resultListItemsSource').find(function(e){
          //   return e.checkInId== res[0].checkInId;
          // }))){
          //   res.reverse().forEach(element=>{
          //     this._setGridDataB(element);
          //     this.get('resultListItemsSource').unshiftObject(element);

          //   });
          // }
          const duplicateItems = [];
          const addItems = [];
          res.forEach(d => {
            const findItem = this.get('resultListItemsSource').find(s => s.observationId === d.observationId);
            if(isPresent(findItem)) {
              duplicateItems.push(d);
            } else {
              addItems.push(d);
            }
          });
          if(isPresent(addItems)) {
            const addObjects = this._setGridData(addItems);
            this.get('resultListItemsSource').unshiftObjects(addObjects);
            later(() => {
              this.get('_gridControl').selectRows(addObjects);
              this.showToast('load', this.getLanguageResource('9861', 'F', '', '조회가 완료되었습니다.'), `${addItems.length} ${this.getLanguageResource('15245', 'F', '건')}`,);
            });
          }
          if(isPresent(duplicateItems)) {
            this.showToastDuplicateData();
            // this.showMessagebox(this.getLanguageResource('tempkey', 'F', null, '중복검사가 있습니다.'), `${this.getLanguageResource('tempkey', 'S',null, '중복검사')} : ${duplicateItems.length} 건`, 'warning', 2000);
          }
        }else{
          this.get('specimenexaminationreportService').onShowToast('error', this.getLanguageResource('9264', 'F', '조회된 정보가 없습니다'), '');
        }
        this.set('isResultGridShow', false);
      }.bind(this)).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },
    _setExaminationTagList(getTagList){
      // const newTagList = [];
      const examinationTagNameSelectedItem = this.get('examinationTagNameSelectedItem');

      //Tag Setting을 파라미터(getTagList)로 받아오면 그걸로 셋팅해주고 아니면 콤보박스에 지정된 Tag를 셋팅.
      if (getTagList !== null){
        this.set('examinationTagList', getTagList);
      //C-ComboBox 변경으로 인하여 selectedItems가 null로 바꿀때도 호출이 되고 있음. - null check 추가.
      } else if (examinationTagNameSelectedItem !== null){
        const examinationCategoryTagItems = examinationTagNameSelectedItem.property.classifications;
        const examinationUnitTagItems = examinationTagNameSelectedItem.property.unitWorks;
        const examinationTagItems = examinationTagNameSelectedItem.property.observationExaminations;
        const searchCondition= this.get('searchCondition');
        set(searchCondition, 'classificationIds', examinationCategoryTagItems.map(function(item){
          return item.id;
        }));
        set(searchCondition, 'unitWorkIds', examinationUnitTagItems.map(function(item){
          return item.id;
        }));
        set(searchCondition, 'examinationIds', examinationTagItems.map(function(item){
          return item.id;
        }));
      }

      //WorkList에서 조각UI로 열릴시에 변경값 탭으로 전달하는 콜백 이벤트
      // this._callBackViewSettingCB('1');
    },

    _filterExaminationTagList(workListFindConfigurationId, examinationCategoryTagItems,examinationUnitTagItems,examinationTagItems){
      const filterdExaminationTagList= [];
      filterdExaminationTagList.workListFindConfigurationId=workListFindConfigurationId;
      if(!isEmpty(examinationCategoryTagItems)){
        examinationCategoryTagItems.forEach(element => {
          filterdExaminationTagList.push({
            id: element.id,
            name: element.name,
            abbreviation: element.abbreviation,
            type: 'category'
          });
        });
      }
      if(!isEmpty(examinationUnitTagItems)){
        examinationUnitTagItems.forEach(element => {
          filterdExaminationTagList.push({
            id: element.id,
            name: element.name,
            abbreviation: element.name,
            type: 'unit'
          });
        });
      }
      if(!isEmpty(examinationTagItems)){
        examinationTagItems.forEach(element => {
          filterdExaminationTagList.push({
            id: element.id,
            name: element.name,
            abbreviation: element.abbreviation,
            type: 'exam'
          });
        });
      }
      return filterdExaminationTagList;
    },
    _openTextResultManagement(e){
      const selectedItem = this.get('currentItem');
      if(isEmpty(e)){
        return;
      }
      //InputType정의
      //general - 검사결과관리
      //textresult - TEXT검사결과입력
      //item - 항목별 검사결과입력
      //culture - 염색,배양결과입력
      //device - 추후 장비인터페이스 사용
      selectedItem.inputType = 'item';
      this.get('specimenCheckInService').getDisplayView(selectedItem.specimenNumber, selectedItem.examinationId).then(function(res){
        if(isEmpty(res)){
          this.get('specimenCheckinService')._showMessage('Display View Error', 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        let isPBS= false;
        const _menus = A([]);
        const temp = {
          specimenNumber: selectedItem.specimenNumber,
          examinationCode: selectedItem.examination.displayCode
        };
        res.forEach(element=> {
          if(element.viewId == "specimen-examination-report-blood-cell-morphology"){
            isPBS = true;
            _menus.unshiftObject(Object.create({displayCode: element.viewId,parameters: temp}));
          }else{
            _menus.addObject(Object.create({displayCode: element.viewId,parameters: temp}));
          }

        });
        if(isPBS){
          this.get('co_MenuManagerService').openSpecialMenus(_menus.reverse());
        }else{
          this.get('co_MenuManagerService').openSpecialMenus(_menus);
        }
        this.get('co_ContentMessageService').sendMessage('sendTextResult', temp);
      }.bind(this)).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    _setSearchConditionProperty(examinationTagNameSelectedItem){
      const searchCondition= this.get('searchCondition');
      const examinationTagList= this.get('examinationTagList');
      set(searchCondition, 'checkInFromDate', new Date(searchCondition.checkInFromDate.getFullYear(), searchCondition.checkInFromDate.getMonth(), searchCondition.checkInFromDate.getDate(), 0, 0, 0));
      set(searchCondition, 'checkInToDate', new Date(searchCondition.checkInToDate.getFullYear(), searchCondition.checkInToDate.getMonth(), searchCondition.checkInToDate.getDate(), 0, 0, 0));
      set(searchCondition, 'subjectTypeCode', 'Patient');
      if(!isEmpty(this.get('issuedDepartmentCombobox.selectedItems'))){
        set(searchCondition, 'issuedDepartmentIds', this.get('issuedDepartmentCombobox.selectedItems').mapBy('id'));
        if(isEmpty(searchCondition.issuedDepartmentIds)){
          searchCondition.issuedDepartmentIds= null;
        }
      }else{
        set(searchCondition, 'issuedDepartmentIds', null);
      }
      //2020.12.23 TAT 직접입력 옵션 추가
      // let tatSearchTimeMinute = this.get('tatSelectedTimeMinute');
      // if(!this.get('isTatDisabled')) {
      //   tatSearchTimeMinute = this.get('tatDirectInputTimeMinute');
      // }
      // set(searchCondition, 'tatSearchTimeMinute', tatSearchTimeMinute);
      // //
      if(!isEmpty(this.get('tatDirectInputTimeMinute'))) {
        set(searchCondition, 'tatSearchTimeMinute', this.get('tatDirectInputTimeMinute'));
      }
      set(searchCondition, 'encounterTypeCode', searchCondition.encounterTypeCode == 'A'? '' : searchCondition.encounterTypeCode);
      let tmp = {property:{}};
      if(!isEmpty(examinationTagNameSelectedItem)){
        set(searchCondition,'classificationIds', null);
        set(searchCondition,'unitWorkIds', null);
        set(searchCondition,'examinationIds', null);
        tmp = examinationTagNameSelectedItem;
        if(!isEmpty(tmp.property.classifications)){
          // set(searchCondition, 'classificationIds', tmp.property.classifications.map(function(item){
          //   return item.id;
          // }));
        }
        if(!isEmpty(tmp.property.unitWorks)){
          set(searchCondition, 'unitWorkIds', tmp.property.unitWorks.mapBy('id'));
        }
        if(!isEmpty(tmp.property.observationExaminations)){
          set(searchCondition, 'examinationIds', tmp.property.observationExaminations.mapBy('id'));
        }
      }else if(isEmpty(examinationTagNameSelectedItem)
        && !isEmpty(searchCondition) && !isEmpty(examinationTagList)){
        //setting팝업 callback값
        set(searchCondition,'classificationIds', null);
        set(searchCondition,'unitWorkIds', null);
        set(searchCondition,'examinationIds', null);
        examinationTagList.forEach(e=>{
          if(e.type === 'category'){
            // set(searchCondition, 'classificationIds', e.items.map(function(item){
            //   return item.id;
            // }));
          }else if(e.type === 'unit'){
            set(searchCondition, 'unitWorkIds', e.items.map(function(item){
              return item.id;
            }));
          }else if(e.type === 'exam'){
            set(searchCondition, 'examinationIds', e.items.map(function(item){
              return item.id;
            }));
          }
        });
      }
      if(!isEmpty(this.get('issuedDepartmentCombobox.selectedItems'))){
        set(searchCondition, 'issuedDepartmentIds', this.get('issuedDepartmentCombobox.selectedItems').map(function(item){
          return item.id;
        }));
        if(isEmpty(searchCondition.issuedDepartmentIds)){
          searchCondition.issuedDepartmentIds = null;
        }
      }
      if(isEmpty(searchCondition.unitWorkIds) || searchCondition.unitWorkIds.includes("")){
        searchCondition.unitWorkIds = null;
      }
      if(isEmpty(searchCondition.examinationIds) || searchCondition.examinationIds.includes("")){
        searchCondition.examinationIds = null;
      }
      // this._setPersonalSettingInfo(searchCondition);
      return searchCondition;
    },

    _getResultListB(searchCondition){
      this.set('isResultGridShow', true);
      if(isEmpty(searchCondition)){
        this.set('isResultGridShow', false);
        return;
      }
      if(this.get('isSpecimenNumberCommit') === true){
        this._specimenCommit(searchCondition);
        this.set('isResultGridShow', false);
        return;
      }
      this.set('comments', {
        isCommentsExpanded: false,
        deptCommentsCount: 0
      });
      this.set('resultListItemsSource', []);
      this.set('resultListSelectedItem', null);
      if(!isEmpty(this.get('issuedDepartmentCombobox.selectedItems'))){
        set(searchCondition, 'issuedDepartmentIds', this.get('issuedDepartmentCombobox.selectedItems').mapBy('id'));
        if(isEmpty(searchCondition.issuedDepartmentIds)){
          searchCondition.issuedDepartmentIds= null;
        }
      }else{
        set(searchCondition, 'issuedDepartmentIds', null);
      }
      if(isEmpty(searchCondition.unitWorkIds) && isEmpty(searchCondition.examinationIds)){
        //최초조회일경우
        if(this.get('init')==true){
          this.set('init', false);
          this.set('isResultGridShow', false);
          return;
        }
        this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9260', 'F', '', '검사항목을 선택하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
        this.set('isResultGridShow', false);
        return;
      }
      this.set('init', false);
      set(searchCondition, 'checkInFromDate', new Date(searchCondition.checkInFromDate.getFullYear(), searchCondition.checkInFromDate.getMonth(), searchCondition.checkInFromDate.getDate(), 0, 0, 0));
      set(searchCondition, 'checkInToDate', new Date(searchCondition.checkInToDate.getFullYear(), searchCondition.checkInToDate.getMonth(), searchCondition.checkInToDate.getDate(), 0, 0, 0));
      set(searchCondition, 'subjectTypeCode', 'Patient');
      if(isEmpty(searchCondition.classificationIds) && isEmpty(searchCondition.unitWorkIds) && isEmpty(searchCondition.examinationIds)){
        this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9192', 'S', '검색 조건을 확인하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
      }
      set(searchCondition, 'encounterTypeCode', searchCondition.encounterTypeCode == 'A'? '' : searchCondition.encounterTypeCode);
      this.set('changeReasonRemark', null);
      return this.getList(this.get('defaultUrl') + 'result-worklists/observations/search', null, searchCondition, true).then(function(res){
        this.set('loaderType', 'spinner');
        this.set('isResultGridShow', false);
        if(res.response){
          this.get('co_PersonalizationService').setSettingInfo(`specimen-examination-report-examination-results-by-item`, JSON.stringify({
            conditionData:[
              searchCondition,
              this.get('examinationTagNameSelectedItem')],
            examinationTagList: this.get('examinationTagList'),
            isSubSearchVisible: this.get('isReportSubSearchVisible')
          }), '항목별검사결과조회 설정 저장');
          const promise = new Promise((resolve)=>{
            if(res.response.length){
              resolve(A(res.response));
              this.set('equipRemark', null);
              res.response.forEach(tmp=>{
                this._setGridData(tmp);
              });
              this.set('resultListItemsSource', res.response);
            } else{
              resolve(A([]));
              this.set('resultListItemsSource', []);
            }
          });
          return promise;
        }else{
          this.set('resultListItemsSource', null);
        }
      }.bind(this)).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },

    async _getResultList(searchCondition) {
      try {
        if(isEmpty(searchCondition)){
          return;
        }
        if(this.get('isSpecimenNumberCommit') === true){
          this._specimenCommit(searchCondition);
          return;
        }
        if(isEmpty(searchCondition.unitWorkIds) && isEmpty(searchCondition.examinationIds)){
          //최초조회일경우
          if(this.get('init') === true){
            this.set('init', false);
            return;
          }
          this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9260', 'F', '', '검사항목을 선택하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
          this.set('isResultGridShow', false);
          return;
        }
        if(isEmpty(searchCondition.classificationIds) && isEmpty(searchCondition.unitWorkIds) && isEmpty(searchCondition.examinationIds)){
          this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9192', 'S', '검색 조건을 확인하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
          return;
        }
        this.set('isResultGridShow', true);
        this.set('init', false);
        this.set('comments', {
          isCommentsExpanded: false,
          deptCommentsCount: 0
        });
        this.set('resultListItemsSource', []);
        this.set('resultListSelectedItem', null);
        this.set('changeReasonRemark', null);
        this.set('entryValueTextString', null);
        const res = await this.getList(this.get('defaultUrl') + 'result-worklists/observations/search', null, searchCondition, false);
        if(isPresent(res)) {
          this.set('equipRemark', null);
          const gridItems = this._setGridData(res);
          this.set('currentPage', 0);
          this.set('originalDatas', gridItems);
          this.set('resultListItemsSource', this.getPageSource(gridItems));
        }
        this.set('isResultGridShow', false);
      } catch(e) {
        this._catchError(e);
      }
    },
    getPageSource(datas) {
      if(isEmpty(datas)) {
        return;
      }
      const startAt = this.get('currentPage') * this.get('recordSize');
      const endAt = startAt + (this.get('recordSize') - 1);
      return datas.filter(item => item.rowNum >= startAt && item.rowNum <= endAt);
    },
    _setPersonalSettingInfo(searchCondition) {
      this.get('co_PersonalizationService').setSettingInfo(`specimen-examination-report-examination-results-by-item`, JSON.stringify({
        conditionData:[
          // this.get('searchCondition'),
          searchCondition,
          this.get('examinationTagNameSelectedItem')],
        examinationTagList: this.get('examinationTagList'),
        isSubSearchVisible: this.get('isReportSubSearchVisible'),
        hpcSearchTypeCode: this.get('hpcSelectedValue'),
      }), '항목별검사결과조회 설정 저장');
    },

    _getDepartmentComments(){
      this.set('comments', {
        isCommentsExpanded: false,
        deptCommentsCount: 0
      });
      this.get('specimenexaminationreportService').getDepartmentComments(this.get('resultListSelectedItem')).then(res=>{
        if(!isEmpty(res)){
          this.set('comments', res);
        }
        this._getDelayReason();
      }).catch(function(error){
        this._catchError(error);
      }.bind(this));
    },
    async _getDelayReason() {
      const params = {
        specimenId: this.get('resultListSelectedItem.specimenId'),
        checkinId: this.get('resultListSelectedItem.checkInId'),
      };
      try {
        const result = await this.getList(this.get('checkinUrl') + 'specimen-checkins/observation-delay-specimens', params, null);
        if(isPresent(result)) {
          set(this.get('comments'), 'isCommentsExpanded', true);
        }
      }catch(e) {
        this._catchError(e);
      }
    },
    _setCurrentCell(e) {
      const _gridControl= this.get('_gridControl');
      if(isEmpty(_gridControl)){
        return;
      }
      const originalSource = _gridControl.getOriginalSource(e.originalEvent);
      const currentDom = this.$('#' + originalSource.element.id);
      const top = currentDom.height() * -1;
      this.set('_currentCell', {
        item: originalSource.item,
        element: currentDom,
        field: originalSource.column.field,
        rowIndex: originalSource.rowIndex,
        // cellIndex: originalSource.cellIndex,
        cellIndex: _gridControl.getColumnIndex(originalSource.column),
        offset: {top: top + 'px', left: 0 + 'px'}
      });
      // this.set('_currentCell',this.get('specimenexaminationreportService')._setCurrentCell(this, this.get('_gridControl').getOriginalSource(e.originalEvent)));
    },

    _setSaveParams(inputStatus){
      let observationResults=[];
      // let value={};
      const resultListItemsSource= [];
      const selectedItemsTemp= this.get('selectedItems');
      const negativeCodeableConcept= this.get('negativeCodeableConcept');
      if(isEmpty(selectedItemsTemp)){
        this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9260', 'S','항목을 선택하세요'), 'warning', 'Ok', 'Ok', '', 2000);
        this.set('isResultGridShow', false);
        return;
      }
      selectedItemsTemp.forEach(e=>{
        resultListItemsSource.addObject(e);
        if((inputStatus==='negative' || inputStatus==='all') && e.valueTypeCode=="CodeableConcept"){
          set(e, 'valueValueString', negativeCodeableConcept.valueValueString);
          set(e, 'numericCellInputValue', negativeCodeableConcept.valueValueString);
        }
      });
      const performer= this.get('co_CurrentUserService.user');
      const currentDatetime= this.get('co_CommonService').getNow();
      let isCorrected= false;
      let isfinal= false;
      let isNull= false;

      if(isEmpty(resultListItemsSource)){
        this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9260', 'S','항목을 선택하세요'), 'warning', 'Ok', 'Ok', '', 2000);
        this.set('isResultGridShow', false);
        return;
      }

      if(isEmpty(performer)){
        this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('8947', 'S','에러가 발생했습니다.'), 'error', 'Ok', 'Ok', 'Invalid user', null);
        this.set('isResultGridShow', false);
      }
      if(inputStatus==='negative' || inputStatus==='all'){
        this._calculateNegative(selectedItemsTemp);
        return;
      }
      let correctCount=0;
      const cvrItem=[];
      const changeReasonRemark= this.get('changeReasonRemark');
      this.set('loaderType', 'progress');
      this.set('isResultGridShow', true);
      resultListItemsSource.forEach(e=>{
        if(inputStatus==='preliminary' && e.statusCode==='final'){
          //최초 save
          isfinal=true;
          return;
        }
        if(this._nullCheck(inputStatus, e)){
          isNull=true;
        }
        if(inputStatus === 'final' && (e.statusCode === 'final' || e.statusCode === 'corrected')){
          //저장 클릭시 선택한 아이템이 모두 corrected바꿀때만 수정사유 입력 팝업 오픈
          correctCount++;
        }
        if(e.isUpdated && (e.statusCode === 'final' || e.statusCode ==='corrected')) {
          //final 상태 이후 수정사유입력 popup 오픈
          isCorrected=true;
          set(e,'isCorrected', true);
          this.set('correctReasonTargetItem', e);
        }else if(!e.isUpdated && (e.statusCode === 'final' || e.statusCode ==='corrected')) {
          //저장할 내용이 없는 경우
          return;
        }

        observationResults= this._addObservationResults(e, observationResults, isCorrected,inputStatus,performer,currentDatetime,changeReasonRemark);

        if(e.check.isCritical ===true){
          cvrItem.addObject(e);
        }
      });
      if(isfinal === true){
        this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9288', 'F', '검사상태를 확인해주시기 바랍니다.'), 'warning', 'Ok', 'Ok', '', 2000);
        this.set('isResultGridShow', false);
        return;
      }
      if(isNull === true){
        this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('8945', 'F', '필수값을 입력하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
        this.set('isResultGridShow', false);
        return;
      }

      if(observationResults.length ===0){
        //변경사항이 없는 경우
        this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9209', 'F', '저장할 내용이 없습니다.'), 'warning', 'Ok', 'Ok', '', 2000);
        this.set('isResultGridShow', false);
        return;
      }

      if(correctCount>0 && correctCount!=resultListItemsSource.length){
        //correct 할 경우 선택된 모든 항목이 final상태이상 이어야함
        this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9288', 'F', '검사상태를 확인해주시기 바랍니다.'), 'warning', 'Ok', 'Ok', '', 2000);
        this.set('isResultGridShow', false);
        return;
      }
      if(isCorrected && isEmpty(this.get('editReasonSelectedItem'))){
        //변경사유 입력
        this.set('isResultGridShow', false);
        this.set('isCorrectReasonEntryOpened', true);
      }else{
        let inputType = 'item';
        if(this.get('useTypeCode') !== 'Laboratory'){
          inputType = 'culture';
        }
        this.set('isSaveButtonDisabled', true);
        this.get('specimenexaminationreportService').resultSave(inputType, isCorrected, inputStatus, observationResults,this.get('editReasonSelectedItem')).then(function(){
          this.set('editReasonSelectedItem', null);
          this.set('changeReasonRemark', null);
          this.set('isSaveButtonDisabled', false);
          if(inputStatus=='preliminary'){
            this.get('specimenexaminationreportService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
          }else if(inputStatus=='final'){
            isCorrected ? this.get('specimenexaminationreportService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '')
              : this.get('specimenexaminationreportService').onShowToast('save', this.getLanguageResource('8942', 'F', 'Saved'), '');
          }
          if(!isEmpty(cvrItem) && inputStatus=='final'){
            if(cvrItem.length == 1){
              this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('10747', 'F', 'CVR을 전송하시겠습니까?'),
                'question', 'YesNo', 'Yes', '', null).then(function(result){
                if(result === 'Yes'){
                  this._sendCvr(cvrItem.get('firstObject'));
                }
              }.bind(this)).catch(function(error){
                this._catchError(error);
              }.bind(this));
            }else if(cvrItem.length >1){
              this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('10748', 'F', 'CVR 대상검사가 있습니다.'), 'information', 'Ok', 'Ok', '', 20000);
            }
          }
          this._getResultList(this.get('searchCondition'));
          this.get('inputElement').select();
          // this.$('[name*="specimen-examination-report-examination-microbiology_specimenNumber"] input').select();
        }.bind(this)).catch(function(error){
          this.set('isSaveButtonDisabled', false);
          this._catchError(error);
        }.bind(this));
      }
    },
    _addObservationResults(e, observationResults, corrected,status,performer,currentDatetime,changeReasonRemark){
      let value = {};
      let inputStatus = status;
      let isCorrected = corrected;
      if(e.valueTypeCode =='Quantity'){
        value={
          quantity: {
            value: e.value.quantity.value,
            comparatorCode: isEmpty(e.value.quantity.comparatorCode)? '-': e.value.quantity.comparatorCode,
            unitCode: e.get('examinationUnit.code')? e.get('examinationUnit.code'): null,
            unitName: e.get('examinationUnit.name')? e.get('examinationUnit.name'): null
          },
          codeableConcept: null,
          valueString: e.value.valueString
        };
        observationResults.addObject(this.get('specimenexaminationreportService').setObservationResultParams(e, value,isCorrected,inputStatus,performer,currentDatetime,changeReasonRemark));
      }else if(e.valueTypeCode =='CodeableConcept' || e.valueTypeCode == 'ValueString'){
        value=e.value;
        //예문 선택안하면 'ValueString' 타입으로 -저장시에만
        if(isEmpty(value.codeableConcept)){
          set(value, 'quantity', null);
          set(value, 'codeableConcept', null);
          set(e, 'valueTypeCode', 'ValueString');
        }else if(isEmpty(value.codeableConcept.coding)){
          set(value, 'quantity', null);
          set(value, 'codeableConcept', null);
          set(e, 'valueTypeCode', 'ValueString');
        }else if(!isEmpty(value.valueString) && isEmpty(value.codeableConcept.displayContent)){
          set(value, 'quantity', null);
          set(value, 'codeableConcept', null);
          set(e, 'valueTypeCode', 'ValueString');
        }
        observationResults.addObject(this.get('specimenexaminationreportService').setObservationResultParams(e, value,isCorrected,inputStatus,performer,currentDatetime,changeReasonRemark));
      }else if(e.valueTypeCode == 'ValueTextString'){
        value= e.value;
        if(e.isValueTextStringInputStatus){
          inputStatus = e.statusCode;
          isCorrected = false;
        }
        observationResults.addObject(this.get('specimenexaminationreportService').setObservationResultParams(e, value,isCorrected,inputStatus,performer,currentDatetime,changeReasonRemark));
      }
      return observationResults;
    },
    _nullCheck(inputStatus, e){
      //결과값이 없으면 검증 안되게함
      // let res= false;
      // if(e.check.isRecheck){
      //   return res;
      // }
      // if(e.valueTypeCode=="ValueTextString" && isEmpty(e.value.recordNoteId)){
      //   // res= f;
      // }else if(inputStatus==='final' && (e.statusCode=="preliminary" || e.statusCode=="registered") && isEmpty(e.valueValueString)){
      //   // 결과값이 없으면 검증 안되게함. isRecheck이면 null체크 안함
      //   // ValueTextString타입 null체크 안함
      //   if(e.valueTypeCode=="ValueTextString" && isEmpty(e.value.recordNoteId)){
      //     set(e, 'isValueTextStringInputStatus', true);
      //   }else{
      //     res=true;
      //   }
      // }
      // return res;
      //final 저장 시 null값있으면 true리턴
      let res= false;
      if(e.check.isRecheck){
        // isRecheck이면 null체크 안함
        return res;
      }
      const valueValueString= e.valueValueString;
      if(e.valueTypeCode=="ValueTextString" && !isEmpty(e.value.recordNoteId)){
        //recordNoteId있는 ValueTextString타입은 null체크 안함
        // res=true;
      }else if(inputStatus==='final' && isEmpty(valueValueString)){
        // 결과값이 없으면 검증 안되게함.
        // ValueTextString타입 null체크 안함
        if(e.valueTypeCode=="ValueTextString" && isEmpty(e.value.recordNoteId)){
          set(e, 'isValueTextStringInputStatus', true);
        }else if(!e.isNullableReport){
          // if(e.statusCode=='waiting' && inputStatus ==='final'){
          //   // 저장버튼누를 때 미검증상태는 null체크 안하고 검증제외
          // }else{
          // }
          res=true;
        }else if(e.isNullableReport){
          //null로 저장가능
        }
      }
      return res;

    },

    _calculateNegative(arr){
      //value.codeableConcept codeing code, displayName만 셋팅
      const observationResults=[];
      arr.forEach(e=>{
        if(e.valueTypeCode == "CodeableConcept"){
          const tmp={
            isChange: true,
            examinationId: e.examinationId,
            observationResultId: e.observationResultId,
            valueTypeCode: e.valueTypeCode,
            value: this.get('negativeCodeableConcept').value,
            recentObservationResultId: isEmpty(e.recentObservationResult)? null : e.recentObservationResult.observationResultId
          };
          observationResults.addObject(tmp);
          if(!isEmpty(tmp.value.displayContent)){
            tmp.value.displayContent= tmp.value.displayContent.trim();
          }
        }

      });
      const params={
        inputModeType: "Rule",
        isPossibleInputItemId: true,
        subjectId: arr[0].subjectId,
        subjectTypeCode :  'Patient',
        specimenNumber: arr[0].specimenNumber,
        observationResults: observationResults
      };
      this.set('gridDisabled', true);
      this.create(this.get('defaultUrl') + 'observations/results/calculate', null, params).then(result=>{
        this.set('gridDisabled', false);
        if(isEmpty(result)){
          this.set('isResultGridShow',false);
          return;
        }
        this.get('selectedItems').forEach(function(gridItem){
          let item=null;
          const changedItem= result.findBy('examinationId', gridItem.examinationId);
          if (!isEmpty(changedItem)){
            item= changedItem;
            set(gridItem, 'isUpdated', true);

          }
          if(!isEmpty(item) && !isEmpty(item.value)){
            set(gridItem, 'valueValueString', this.get('specimenexaminationreportService')._setValueString(item));
            set(gridItem, 'numericCellInputValue', this.get('specimenexaminationreportService')._setValueString(item));
            set(gridItem, 'value', item.value);
          }
          set(gridItem, 'valueTypeCode', item.valueTypeCode);
          // this._inputCallBackSetting(inputModeType, gridItem, item);
          if(!isEmpty(item.remark)){
            set(gridItem, 'remarkTooltip', isEmpty(item.remark)? '': item.remark.replace(/\n|\r\n/giu, '<br>'));
          }
        }.bind(this));
      }).catch(function(error){
        this._catchError(error);
      }.bind(this));
      this.set('closedByKeyDown', false);
    },
    _getDepartment(){
      const encounterTypeCode= this.get('searchCondition.encounterTypeCode');
      if(!isEmpty(encounterTypeCode)){
        this.getList(this.get('defaultUrl')+ 'departments/search', {encounterTypeCode: encounterTypeCode}, null).then(function(res){
          this.set('deptItemsSource', isEmpty(res)? null : res);
        }.bind(this)).catch(function(error){
          this._catchError(error);
        }.bind(this));
      }
    },

    _setGridData(res) {
      res.map((d, index) => {
        d.rowNum = index;
        const valueValueString= this.get('specimenexaminationreportService')._setValueString(d);
        d.valueValueString = valueValueString;
        d.numericCellInputValue = valueValueString;
        d.recentResult = this.get('specimenexaminationreportService')._setRecentValue(d);
        d.recentResultComments = this._setRecentResultComments(d);
        d.issuedDepartmentCode = d.get('issuedDepartment.name');
        d.departmentCode = d.get('department.name');
        d.orderedStaffName = d.get('orderedStaff.name');
        d.isUpdated = false;
        d.orderNameTooltip = d.examination.displayCode + ', ' + d.examination.name;
        d.iconDisplay = this._setIconDisplay(d.progressType.code, d.isNeedConsent, d.isNeedRequest, d.isInfection);
        d.point = this._setIconDisplayTooltip(d.progressType.code, d.isNeedConsent, d.isNeedRequest, d.isInfection);
        if(!isEmpty(d.interpretation)){
          set(d, 'interpretation.code', d.interpretation.coding.get('firstObject.code'));
        }
        let remark = '';
        let remarkTooltip = '';
        if(isPresent(d.remark)) {
          remark = d.remark.replace(/<br>|<br\/>|<br \/>/giu, '\r\n');
          remarkTooltip = d.remark.replace(/\n|\r\n/giu, '<br>');
        }
        d.remark = remark;
        d.remarkTooltip = remarkTooltip;
        if (isPresent(this.get('returnTextRecordId'))){
          if (isPresent(d.value) && d.value.recordNoteId === this.get('returnTextRecordId')){
            this.set('resultListSelectedItem', d);
            this.set('returnTextRecordId', null);
          }
        }
        let occupyingBed = '';
        let occupyingBedTooltip = '';
        if(isPresent(d.ward)){
          occupyingBed = isEmpty(d.ward.displayCode)? '' : d.ward.displayCode;
          occupyingBed= isEmpty(d.room.roomCode)? occupyingBed : occupyingBed + '/' + d.room.roomCode;
          occupyingBed= isEmpty(d.bed.displayCode)? occupyingBed : occupyingBed + '/' + d.bed.displayCode;
          occupyingBedTooltip = isEmpty(d.ward.name)? '' : d.ward.name;
          occupyingBedTooltip = isEmpty(d.room.roomName)? occupyingBedTooltip : occupyingBedTooltip + '/' + d.room.roomName;
          occupyingBedTooltip = isEmpty(d.bed.name)? occupyingBedTooltip : occupyingBedTooltip + '/' + d.bed.name;
        }
        d.occupyingBed = occupyingBed;
        d.occupyingBedTooltip = occupyingBedTooltip;
      });
      return res;
      // this.set('resultListItemsSource', res);
    },

    _setGridDataB(element){
      let equipRemark= this.get('equipRemark');
      if(isEmpty(equipRemark)){
        if(!isEmpty(element.deviceRemark)){
          equipRemark= element.deviceRemark;
        }
      }else if(!isEmpty(equipRemark) && isPresent(element.deviceRemark)){
        equipRemark= equipRemark+ ' / ' + element.deviceRemark;
      }
      this.set('equipRemark', equipRemark);
      set(element, 'equipRemark' ,equipRemark);
      const valueValueString= this.get('specimenexaminationreportService')._setValueString(element);
      set(element, 'valueValueString', valueValueString);
      set(element, 'numericCellInputValue',valueValueString);
      set(element, 'recentResult', this.get('specimenexaminationreportService')._setRecentValue(element));
      set(element, 'recentResultComments', this._setRecentResultComments(element));
      set(element, 'issuedDepartmentCode', element.get('issuedDepartment.name'));
      set(element, 'departmentCode', element.get('department.name'));
      set(element, 'orderedStaffName', element.get('orderedStaff.name'));
      set(element, 'isUpdated', false);
      set(element, 'orderComment', element.orderComment);
      set(element, 'orderNameTooltip', element.examination.displayCode + ', ' + element.examination.name);
      set(element, 'collectionComment', element.collectionComment);
      set(element, 'iconDisplay', this._setIconDisplay(element.progressType.code, element.isNeedConsent, element.isNeedRequest, element.isInfection,));
      set(element, 'point', this._setIconDisplayTooltip(element.progressType.code, element.isNeedConsent, element.isNeedRequest, element.isInfection,));
      if(!isEmpty(element.interpretation)){
        set(element, 'interpretation.code', element.interpretation.coding.get('firstObject.code'));
      }
      if(!isEmpty(element.remark)){
        set(element, 'remark', isEmpty(element.remark)? '': element.remark.replace(/<br>|<br\/>|<br \/>/giu, '\r\n'));
        set(element, 'remarkTooltip', isEmpty(element.remark)? '': element.remark.replace(/\n|\r\n/giu, '<br>'));
      }
      if (!isEmpty(this.get('returnTextRecordId'))){
        if (!isEmpty(element.value) && element.value.recordNoteId === this.get('returnTextRecordId')){
          this.set('resultListSelectedItem', element);
          this.set('returnTextRecordId', null);
        }
      }
      if(!isEmpty(element.ward)){
        let occupyingBed= isEmpty(element.ward.displayCode)? '' : element.ward.displayCode;
        occupyingBed= isEmpty(element.room.roomCode)? occupyingBed : occupyingBed + '/' + element.room.roomCode;
        occupyingBed= isEmpty(element.bed.displayCode)? occupyingBed : occupyingBed + '/' + element.bed.displayCode;
        set(element, 'occupyingBed', occupyingBed);

        let occupyingBedTooltip= isEmpty(element.ward.name)? '' : element.ward.name;
        occupyingBedTooltip= isEmpty(element.room.roomName)? occupyingBedTooltip : occupyingBedTooltip + '/' + element.room.roomName;
        occupyingBedTooltip= isEmpty(element.bed.name)? occupyingBedTooltip : occupyingBedTooltip + '/' + element.bed.name;
        set(element, 'occupyingBedTooltip', occupyingBedTooltip);

      }else{
        set(element, 'occupyingBed', '');
        set(element, 'occupyingBedTooltip', '' );
      }
    },

    _setRecentResultComments(element){
      const recentValue= isEmpty(element.get('recentObservationResult'))? []: element.get('recentObservationResult');
      let recentResultComments='';
      recentResultComments= isEmpty(recentValue.issuedDatetime)?''
        : this.getLanguageResource('9046', 'S', '검증') +': '+ this.get('fr_I18nService').formatDate(new Date(recentValue.issuedDatetime), 'g');
      return recentResultComments;
    },

    _setIconDisplay(progressTypeCode, isNeedConsent, isNeedRequest, isInfection, prescriptionTypeCode){
      //아이콘 표기 우선순위: isInfection > progressTypeCode"D","F" > isAllergy > isNeedRequest > isNeedConsent
      let res = null;
      if(isInfection){
        res = 'isInfection';
      }else if(progressTypeCode === "F"){
        res = 'F';
      }else if(progressTypeCode === "D"){
        res = 'D';
        res = 'progressTypeCode';
      }else if(isNeedRequest){
        res = 'isNeedRequest';
      }else if(isNeedConsent){
        res = 'isNeedConsent';
      }else if(prescriptionTypeCode == '6'){
        res = 'isDischarge';
      }
      return res;
    },

    _setIconDisplayTooltip(progressTypeCode,isNeedConsent, isNeedRequest, isInfection, prescriptionTypeCode){
      let res=[];
      if(isInfection){
        res.addObject(this.getLanguageResource('581', 'S', 'Infection Precaution') + '<br>');
      }
      if( progressTypeCode === "F"){
        res.addObject(this.getLanguageResource('5725', 'F', '응급')+ '<br>');
      }
      if(progressTypeCode === "D" ){
        res.addObject(this.getLanguageResource('1880', 'F', '당일')+ '<br>');
      }
      // if(isAllergy){
      //   res.addObject(this.getLanguageResource('4682', 'F', 'Allergy') + '<br>');
      // }
      if(isNeedRequest){
        res.addObject(this.getLanguageResource('17066', 'S', '의뢰서 필요') + '<br>');
      }
      if(isNeedConsent){
        res.addObject(this.getLanguageResource('11740', 'S', '동의서 필요') + '<br>');
      }
      if(prescriptionTypeCode == '6'){
        res.addObject(this.getLanguageResource('11988', 'S', '퇴원오더') + '<br>');
      }
      // if(res.length > 0){
      //   res.removeObject(res.firstObject);
      // }
      if(res.length > 1){
        res=res.join('').toString();
      }else{
        res=[];
      }
      return res;
    },
    _getInappropriateInfo() {
      if (isEmpty(this.get('resultListSelectedItem'))) {
        this.get('specimenexaminationreportService')._showMessage( this.getLanguageResource('9260', 'F','Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
        return false;
      }
      if(this._inappropriateRegistrationValidationCheck()==false){
        return;
      }
      this.set('inappropriateInfo', null);
      this.get('specimenCheckInService').getInappropriateInfo(this.get('resultListSelectedItem.specimenId')).then(function(inappropriateInfo){
        if(!isEmpty(inappropriateInfo)){
          this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('10106', 'F', '이미 등록된 검체입니다. <br> 취소하고 다시 접수하시겠습니까?'),
            'question', 'YesNo', 'Yes', '', null).then(function(result){
            if(result === 'Yes'){
              this.set('isInappropriateRegistrationModalOpen', true);
              this.set('inappropriateInfo', inappropriateInfo);
            }
          }.bind(this)).catch(function(e){
            this._catchError(e);
          }.bind(this));
        }else{
          this.set('isInappropriateRegistrationModalOpen', true);
          // this._initializeisInappropriateRegistrationModal();
        }
      }.bind(this)).catch(function(e){
        this._catchError(e);
      }.bind(this));

    },
    _moveFocus(moveType) {
      const grid = this.get('_gridControl');
      const rowIndex = this.get('_currentCell.rowIndex');
      const cellIndex = this.get('_currentCell.cellIndex');
      let moveRow = 0;
      let moveColumn = 0;

      if(moveType === 'down') {
        moveRow = 1;
      } else if(moveType === 'self') {
        moveRow = 0;
        moveColumn = 0;
      }

      next(this, function() {
        if(moveRow != 0) {
          grid.selectRow(rowIndex + moveRow);
          // grid.focusCell(rowIndex + moveRow, cellIndex);
          grid.editCell(rowIndex + moveRow, cellIndex);
          // grid.selectCell(rowIndex + moveRow, cellIndex);
        } else if(moveColumn != 0) {
          // grid.selectCell(rowIndex, cellIndex + moveColumn);
          // grid.focusCell(rowIndex, cellIndex + moveColumn);
        } else if ( moveRow === 0 && moveColumn === 0) {
          // grid.selectCell(rowIndex, cellIndex);
          // grid.focusCell(rowIndex, cellIndex);
        }
      });
    },
    _closeEntryPopups() {
      this.set('isQuantityEntryOpen', false);
      this.set('isConceptEntryOpen', false);
      this.set('isStringEntryOpen', false);
    },
    _catchError(e){
      this.set('isResultGridShow',false);
      this.set('gridDisabled', false);
      this.showResponseMessage(e);
    }
  });