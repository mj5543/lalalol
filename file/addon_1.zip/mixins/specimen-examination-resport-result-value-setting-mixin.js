/* eslint-disable no-console */
// import $ from 'jquery';
import Mixin from '@ember/object/mixin';
// import { inject as service } from '@ember/service';
import { isEmpty, isPresent } from '@ember/utils';
import { set } from '@ember/object';
// import { next } from '@ember/runloop';
// import { copy } from '@ember/object/internals';
// import { A as emberA } from '@ember/array';

export default Mixin.create({
  // specimenexaminationreportService: service('specimen-examination-report-service'),

  onPropertyInit() {
    this._super(...arguments);
  },
  actions: {
  },
  _setValueString(element, objName){
    let returnValueString = '';
    let targetValue = element.value;
    let targetValueTypeCode = element.valueTypeCode;
    const defaultValue = {
      quantity: {value: null},
      codeableConcept: {coding: [{code:null, displayName: null}]},
      valueString: null,
      valueDecimal: 0
    };
    if(objName === 'lastValue') {
      targetValue = element.lastValue;
      targetValueTypeCode = element.lastValueTypeCode;
    }
    if(isEmpty(targetValue)){
      set(element, objName, defaultValue);
    }
    if(targetValueTypeCode == 'Quantity'){
      if(isEmpty(targetValue.quantity)){
        set(element, objName, defaultValue);
      }
      if(isPresent(targetValue.quantity.value)) {
        //저장된 값 있을 경우
        returnValueString= this._setQuantityValueValueString(element, objName);
      }
    }else if(targetValueTypeCode === 'CodeableConcept' && isPresent(targetValue.codeableConcept)){
      if(!isEmpty(targetValue.codeableConcept.coding)){
        if(!isEmpty(targetValue.codeableConcept.coding.get('firstObject.code'))){
          //저장된 값 있을 경우
          returnValueString= this._setCodeValueValueString(element, objName);
        }else if(targetValue.valueString){
          returnValueString = this._setCodeValueValueString(element, objName);
        }
      }else if(targetValue.valueString){
        returnValueString= this._setCodeValueValueString(element, objName);
      }
    }else if(targetValueTypeCode=='ValueString' || (targetValueTypeCode=='ValueTextString' && isEmpty(targetValue.recordNoteId))){
      let valueString= targetValue.valueString;
      if(isEmpty(valueString)){
        valueString= '';
      }else{
        returnValueString = valueString.trim();
      }
    }
    return returnValueString.trim();
  },
  _setQuantityValueValueString(item, type){
    let tartgetValue = item.value;
    if(type === 'lastValue') {
      tartgetValue = item.lastValue;
    }
    let quantityValue= tartgetValue.quantity.value;
    let comparator = tartgetValue.quantity.comparatorCode;
    let valueString= tartgetValue.valueString;
    if(isEmpty(quantityValue)){
      quantityValue= '';
    }
    if(comparator =='-' || isEmpty(comparator)){
      comparator= '';
    }
    if(isEmpty(valueString)){
      valueString= '';
    }
    return comparator+ ' ' + quantityValue + ' ' + valueString;
  },
  _setCodeValueValueString(item, type){
    let displayContent=null;
    let tartgetValue = item.value;
    if(type === 'lastValue') {
      tartgetValue = item.lastValue;
    }
    if(!isEmpty(tartgetValue)){
      displayContent= tartgetValue.codeableConcept.displayContent;
    }
    let valueString= tartgetValue.valueString;
    if(isEmpty(displayContent)){
      displayContent= '';
    }
    if(isEmpty(valueString)){
      valueString= '';
    }
    return displayContent + ' '+ valueString;
  },
  _setRecentValue(element){
    let recentValue= isEmpty(element.recentObservationResult)? []: element.recentObservationResult;
    if(isEmpty(recentValue.displayResult)){
      recentValue = null;
    }else{
      recentValue =recentValue.displayResult;
    }
    return recentValue;
  },


});