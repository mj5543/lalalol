/* eslint-disable no-console */
/* eslint-disable no-undef */
import moment from 'moment';
import Mixin from '@ember/object/mixin';
import { inject as service } from '@ember/service';
import { isEmpty, isPresent } from '@ember/utils';

export default Mixin.create({
  printPopup: null,
  printConfig: null,
  printContent: null,
  reportFooter: null,
  footerCertification: null,
  footerAddress: null,
  cultureResultService: service('specimen-examination-report-culture-result-management-service'),

  onPropertyInit() {
    this._super(...arguments);
  },
  actions: {
    onVerificationPrint() {
      this._verificationPrint();
    },
    onPreviousExaminationResultPrint(){
      this.getReportFooter('P');
    },
    onExaminationResultPrint() {
      this.getReportFooter('R');
      // this._examinationResultPrint();
    },
  },
  async getReportFooter(gubn) {
    try {
      const result = await this.get('cultureResultService').getBusinessCodesSearch({classificationCode: 'LaboratoryMedicalRecordFooter'});
      if(!isEmpty(result)) {
        this.set('reportFooter', `${result[1].name} <br> ${result[2].name}`);
        this.set('footerCertification', result[1].name);
        this.set('footerAddress', result[2].name);
      }
      this._examinationResultPrint(gubn);
    } catch(e) {
      console.error(e);
    }
  },
  _verificationPrint() {
    const gridList = this.get('verifyGridItems');
    const selectedPatientItem = this.get('model.selectedPatientGridItem');
    const reportInfo = this.get('reportInfo');
    const tempList = [];
    if(!isEmpty(gridList)) {
      gridList.forEach(d => {
        let flag = '';
        if(!isEmpty(d.flag)) {
          flag = d.flag.displayCode;
        }
        let examinationUnit = '';
        if(!isEmpty(d.examinationUnit)) {
          examinationUnit = d.examinationUnit.name;
        }
        const tempObj = {
          examinationName: d.examination.name,
          specimenType: d.specimenType.name,
          displayResult: d.displayResult,
          flag: flag,
          examinationUnit: examinationUnit,
          reportedDate: this.get('fr_I18nService').formatDate(new Date(d.reportedDate), 'g'),
        };
        tempList.push(tempObj);
      });
    }
    let wardRoomName = '';
    if(!isEmpty(reportInfo.ward)) {
      wardRoomName = `${reportInfo.ward.name} / ${reportInfo.room.roomName}`;
    }
    let signImagePath = null;
    if(!isEmpty(this.get('writerInfo'))) {
      signImagePath = `${this.get('fileUrl')}/${this.get('writerInfo.imagePath')}`;
    }
    // let examinationImagePath = null;
    // if(!isEmpty(this.get('co_CommonService.hospitalInfo')) && !isEmpty(this.get('co_CommonService.hospitalInfo.hospitalImageContent'))) {
    //   const imageInfo = this.get('co_CommonService.hospitalInfo.hospitalImageContent').find(d => d.hospitalImageType === 7);
    //   if(!isEmpty(imageInfo)) {
    //     examinationImagePath = `${this.get('fileUrl')}/${imageInfo.imagePath}`;
    //   }
    // }
    let certificationNumber = null;
    let examinationImageUrl = null;
    if(isPresent(this.get('certificationInfo'))) {
      certificationNumber = this.get('certificationInfo.certificationNumber');
      examinationImageUrl = this.get('certificationInfo.imageUrl');
    }
    const printContent = {};
    printContent.dataField = { 'verificationResults': tempList };
    printContent.parameterField = {
      verificationItemRemark: this.get('model.orderExaminationsNamesText'),
      patientNumber: selectedPatientItem.patient.displayNumber,
      patientName: selectedPatientItem.patient.name,
      genderAge: `${selectedPatientItem.patient.gender} / ${selectedPatientItem.patient.age}`,
      wardRoomName: wardRoomName,
      departmentName: reportInfo.department.name,
      activationDate: this.get('fr_I18nService').formatDate(new Date(reportInfo.activationDate), 'd'),
      diagnosis: `${reportInfo.diagnosis.name} (${reportInfo.diagnosis.displayCode})`,
      verificationDate: this.get('fr_I18nService').formatDate(new Date(reportInfo.verificationDate), 'd'),
      reportStaffName: `${reportInfo.reportStaff.departmentName} ${reportInfo.reportStaff.employeeName}`,
      licenseNumber: reportInfo.reportStaff.licenseNumber,
      // certificationNumber: this.get('model.certificationNumber'),
      certificationNumber: certificationNumber,
      institutionNumber: this.get('model.institutionNumber'),
      address: this.get('model.address'),
      phoneNumber: this.get('model.phoneNumber'),
      reportFooter: this.get('model.reportFooter'),
      isCalibration: this.get('model.check.isCalibration'),
      isQualityControl: this.get('model.check.isQualityControl'),
      isDelta: this.get('model.check.isDelta'),
      isPanic: this.get('model.check.isPanic'),
      isRecheck: this.get('model.check.isRecheck'),
      isOthers: this.get('model.check.isOthers'),
      othersComment: this.get('model.check.othersComment'),
      interpretationComment: this.get('model.textComment'),
      recommentation: this.get('model.textRecommend'),
      additionalReport: this.get('model.textAdditional'),
      signImageUrl: signImagePath,
      examinationImageUrl: examinationImageUrl,
      // examinationImageUrl: examinationImagePath,
    };
    this.set('printPopup',true);
    const printConfig = {
      'printType': 2,
      'printName': 'VerificationItemRemark',
    };
    this.set('printConfig', printConfig);
    this.set('printContent', printContent);
  },
  _examinationResultPrint(gubn) {
    const gridList = this.get('observationsResultItemsSource');
    const workItem = this.get('model.resultWorksSelectedItem');
    if(isEmpty(workItem)) {
      return;
    }
    let wardRoomName = '';
    if(!isEmpty(workItem.ward)) {
      wardRoomName = `${workItem.ward.name} / ${workItem.room.roomName}`;
    }
    const tableList = [];
    const tableListBasedOnids = [];
    const recordList = [];
    const recordsBasedOnIds = [];
    const multiPrintContent = [];
    const printContent = {};
    printContent.dataField = { 'examinationResults': tableList };
    const specimenName = workItem.specimenType.name;
    const genderAge = `${workItem.subject.gender}/${workItem.subject.age}`;
    const patientName = workItem.subject.name;
    const patientNumber = workItem.subject.number;
    const orderInfo = workItem.specimenOrders[0];
    const orderNames = [];
    // const ordersAbbr = `${orderInfo.abbreviation} (${specimenName})`;
    const remark = this.get('remarkInputValue');
    const orderRemark = this.get('orderRemarkInputValue');
    //의뢰처
    const issuedDepartment = orderInfo.issuedDepartment.name;
    //진료과
    let department = orderInfo.department.name;
    if(!isEmpty(orderInfo.orderedStaff) && !isEmpty(orderInfo.orderedStaff.name)) {
      department = `${orderInfo.department.name} / ${orderInfo.orderedStaff.name}`;
    }
    //채혈일시
    const collectionStartDatetime = workItem.collectionStartDatetime;
    //접수일시
    const checkInDateTime = workItem.checkInDateTime;
    //검사일
    const checkInDate = new Date(workItem.checkInDate);
    const checkInDateString = `${this.get('fr_I18nService').formatDate(checkInDate, 'd')} (${moment(checkInDate).format('YYMMDD')}-${workItem.checkInNumber})`;
    //보고일시
    const reportedDateTime = workItem.reportedDateTime;
    gridList.forEach(d => {
      if(!isEmpty(d.value) && !isEmpty(d.value.recordNoteId)) {
      //보고서형 데이터
        let reporterName = null;
        let signImageUrl = null;
        // if(d.isSigned) {
        //   reporterName = this.get('reporterName');
        // }
        if(!isEmpty(d.writerInfo) && !isEmpty(d.writerInfo.writerName)) {
          reporterName = d.writerInfo.writerName;
          if(d.writerInfo.isWriterSignImage) {
            signImageUrl = d.writerInfo.signImageUrl;
          }
        }
        if((d.isReport && d.isReportable) || gubn === 'P') {
        // 상태가 검증인 데이터만 출력
          const ordersItem = workItem.specimenOrders.find(item => item.basedOn.id === d.basedOnId);
          let orderName = '';
          if(!isEmpty(ordersItem)) {
            orderName = ordersItem.orderName;
          }
          const obj = {
            examinationName: `${this.getLanguageResource('10011', 'F', '', '검사명')} : ${workItem.orderInfo.classification.name} - ${orderName}`,
            recordNoteTextString: d.value.valueTextString,
            reportedStaff: reporterName,
            specimenName: specimenName,
            genderAge: genderAge,
            patientName: patientName,
            patientNumber: patientNumber,
            issuedDepartment: issuedDepartment,
            departmentName: department,
            wardRoomName: wardRoomName,
            remark: remark,
            orderRemark: orderRemark,
            collectionStartDatetime: this.get('fr_I18nService').formatDate(new Date(collectionStartDatetime), 'g'),
            checkInDateTime: this.get('fr_I18nService').formatDate(new Date(checkInDateTime), 'g'),
            checkInDate: checkInDateString,
            reportedDateTime: isEmpty(reportedDateTime) ? null : this.get('fr_I18nService').formatDate(new Date(reportedDateTime), 'g'),
            signImageUrl: signImageUrl,
            footerCertification: this.get('footerCertification'),
            footerAddress: this.get('footerAddress'),
          };
          const pathList = [];
          if(!isEmpty(d.filePaths)) {
            d.filePaths.forEach(path => {
              pathList.push({filePath: path});
            });
          }
          recordList.push({
            parameterField: obj,
            dataField: pathList
          });
        }
        recordsBasedOnIds.push(d.basedOnId);
      } else if((d.isReport && d.isReportable) || gubn === 'P'){
      // 상태가 검증인 데이터만 출력
        let examinationUnit = '';
        if(!isEmpty(d.examinationUnit)) {
          examinationUnit = d.examinationUnit.name;
        }
        let referenceRange = '';
        if(!isEmpty(d.subject.referenceRange)) {
          referenceRange = d.subject.referenceRange.rangeContent;
        }
        let issuedStaff = '';
        if(!isEmpty(d.issuedStaff)) {
          issuedStaff = d.issuedStaff.name;
        }
        let issuedDatetime = null;
        if(!isEmpty(d.issuedDatetime)) {
          issuedDatetime = this.get('fr_I18nService').formatDate(new Date(d.issuedDatetime), 'g');
        }
        // let reporterName = null;
        // if(d.isSigned) {
        //   reporterName = this.get('reporterName');
        // }
        const tempObj = {
          examinationName: d.examination.name,
          displayResult: d.displayResult,
          referenceRange: referenceRange,
          examinationUnit: examinationUnit,
          issuedDatetime: issuedDatetime,
          issuedStaff: issuedStaff,
          reportedStaff: this.get('reporterName'),
          comment: d.remark
        };
        tableList.push(tempObj);
        tableListBasedOnids.push(d.basedOnId);
      }
    });
    workItem.specimenOrders.forEach(item => {
      if(!recordsBasedOnIds.includes(item.basedOn.id) && !orderNames.includes(item.orderName) && tableListBasedOnids.includes(item.basedOn.id)) {
        orderNames.push(item.orderName);
      }
    });
    const ordersAbbr = orderNames.join(', ');
    const examinationTitle = `${this.getLanguageResource('10011', 'F', '', '검사명')} : ${workItem.orderInfo.classification.name} - ${ordersAbbr}`;

    printContent.parameterField = {
      specimenName: specimenName,
      genderAge: genderAge,
      patientName: patientName,
      patientNumber: patientNumber,
      ordersAbbr: examinationTitle,
      remark: remark,
      orderRemark: orderRemark,
      issuedDepartment: issuedDepartment,
      departmentName: department,
      wardRoomName: wardRoomName,
      collectionStartDatetime: this.get('fr_I18nService').formatDate(new Date(collectionStartDatetime), 'g'),
      checkInDateTime: this.get('fr_I18nService').formatDate(new Date(checkInDateTime), 'g'),
      checkInDate: checkInDateString,
      reportedDateTime: isEmpty(reportedDateTime) ? null : this.get('fr_I18nService').formatDate(new Date(reportedDateTime), 'g'),
      reportedStaff: this.get('reporterName'),
      footerCertification: this.get('footerCertification'),
      footerAddress: this.get('footerAddress'),
    };
    if(!isEmpty(tableList)) {
      multiPrintContent.push({
        file: 'ExaminationResultSearch',
        parameterField: printContent.parameterField,
        dataField: printContent.dataField
      });
    }
    if(!isEmpty(recordList)) {
      recordList.forEach(data => {
        multiPrintContent.push({
          file: 'ExaminationResultSearchReport',
          parameterField: data.parameterField,
          dataField: {"examinationResultSearchReport": data.dataField }
        });
      });
    }
    this.set('printPopup',true);
    const printConfig = {
      'printType': 2,
      'printName': 'MultiPrint',
    };
    this.set('printConfig', printConfig);
    this.set("multiPrintContent", multiPrintContent);
  },
  onPrintBtnClick(selectedItems,searchCondition){
    // const selectedItems= this.get('selectedItems');
    if(isEmpty(selectedItems)){
      this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('9260', 'F', 'Select an item.'), 'warning', 'Ok', 'Ok', '', 2000);
      return;
    }
    // const searchCondition =this.get('searchCondition');
    const worklist = [];
    selectedItems.forEach(e=>{
      worklist.addObject({
        "checkInNumber" : e.checkInNumber,
        "checkInDate" : e.checkInDate.toFormatString(true, false),
        "subjectNumber" : e.subject.displayNumber,
        "subjectName" : e.subject.name,
        "issuedDepartmentName" : e.issuedDepartment.name,
        "specimenTypeName" : e.specimenType.name,
        "classificationName" : e.classification.name,
        "specimenNumber" : e.specimenNumber,
        "orderComment" : e.orderComment,
        "ssn":"",
      });
    });

    this.set('printPopup',true);
    const printConfig=
    {
      'printType': 2,
      'commonInformation' : true
    };
    printConfig.printName = "DiagnosisExaminationWorklistPortrait";
    this.set('printConfig',printConfig);
    this.set('printContent',{
      dataField :{
        "worklist": worklist,
      },
      parameterField :{
        "unitWorkIds": isEmpty(this.get('examinationTagNameSelectedItem').property.unitWorkIds)? null
          : this.get('examinationTagNameSelectedItem').property.unitWorkIds.map(function (item) {
            return item.id;
          }),
        "classificationIds" : isEmpty(this.get('examinationTagNameSelectedItem').property.classifications)? null
          : this.get('examinationTagNameSelectedItem').property.classifications.map(function (item) {
            return item.id;
          }),
        "checkInFromDate" : searchCondition.checkInFromDate.toFormatString(true, false),
        "checkInToDate" : searchCondition.checkInToDate.toFormatString(true, false),
      }
    });
  },

  getExportByArrayTypeExcel(initial, itemList, colInfo, origin) {
    /* Initial row */
    const exportItemsWS = XLSX.utils.aoa_to_sheet(initial);
    if (!isEmpty(colInfo)) {
      exportItemsWS['!cols'] = colInfo;
    }

    XLSX.utils.sheet_add_aoa(exportItemsWS, itemList, {origin: isEmpty(origin) ? "A2" : origin});
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, exportItemsWS, 'sheet1');
    const fileName = new Date(this.get('co_CommonService').getNow());
    XLSX.writeFile(wb, `${fileName}.xlsx`);
    this.auditExcelExport('getExportByArrayTypeExcel', 'specimenexaminationreport', itemList.get('firstObject'));
  },

  getExportExcel(gridItemsSource, columns) {
    const firstRow = [];
    const colInfo = [];
    columns.forEach(column => {
      if(!isEmpty(column.field)) {
        firstRow.push(column.title);
        colInfo.push({wpx: column.width});
      }
    });
    const initArr = [firstRow];
    const resultArr = [];
    gridItemsSource.forEach(datas => {
      const tempArr = [];
      columns.forEach(col => {
        if(!isEmpty(col.field)) {
          const fields = col.field.split('.');
          let fieldsData = datas[col.field];
          if(fields.length > 1) {
            if(isEmpty(datas[fields[0]])) {
              fieldsData = '';
            } else {
              fieldsData = datas[fields[0]][fields[1]];
            }
          }
          tempArr.push(fieldsData);
        }
      });
      resultArr.push(tempArr);
    });
    this.getExportByArrayTypeExcel(initArr, resultArr);
  },

  getPrinterName(){
    let printerG =null;
    let printerD =null;
    let printerF =null;
    let printerDefault = null;
    return this.get('co_PersonalizationService').getPersonalPrinterSetting('Laboratory', 'print').then(result =>{
      if(isEmpty(result)){
        return{
          'printerDefault': printerDefault,
          'printerG' : printerG,
          'printerD' : printerD,
          'printerF' : printerF
        };
      }
      const settingValue = JSON.parse(result.get('firstObject.settingValue'));
      if(isEmpty(settingValue)) {
        return{
          'printerDefault': printerDefault,
          'printerG' : printerG,
          'printerD' : printerD,
          'printerF' : printerF
        };
      }
      if(!isEmpty(settingValue.defaultLabelPrinter)){
        printerDefault=settingValue.defaultLabelPrinter;
      }
      if(!isEmpty(settingValue.item)){
        printerG = settingValue.item.findBy('printSettingCode', 'G');
        printerD = settingValue.item.findBy('printSettingCode', 'D');
        printerF = settingValue.item.findBy('printSettingCode', 'F');
      }
      return{
        'printerDefault': printerDefault,
        'printerG' : isEmpty(printerG.printerName)? printerDefault : printerG.printerName,
        'printerD' : isEmpty(printerD.printerName)? printerDefault : printerD.printerName,
        'printerF' : isEmpty(printerF.printerName)? printerDefault : printerF.printerName
      };

    });

  },

  setPrintParams(printSetting, printDataFieldG, printDataFieldD, printDataFieldF, printDataFieldDefault){
    // const res=[];
    if(isEmpty(printDataFieldG) && isEmpty(printDataFieldD) && isEmpty(printDataFieldF)){
      return{
        printConfig: {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerDefault},
        printContent: {
          'parameterField': {}, 'dataField': { "specimenInfo" : printDataFieldDefault}
        }
      };
    }else{
      if(!isEmpty(printDataFieldG)){
        return{
          type: 'printDataFieldG',
          printConfig: {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerG },
          printContent: {
            'parameterField': {}, 'dataField': { "specimenInfo" : printDataFieldG}}
        };
      }
      if(!isEmpty(printDataFieldD)){
        return{
          type: 'printDataFieldD',
          printConfig: {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerD },
          printContent: {
            'parameterField': {}, 'dataField': { "specimenInfo" : printDataFieldD}}
        };
      }
      if(!isEmpty(printDataFieldF)){
        return{
          type: 'printDataFieldF',
          printConfig : {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerF },
          printContent : {
            'parameterField': {}, 'dataField': { "specimenInfo" : printDataFieldF}}
        };
      }
      if(!isEmpty(printDataFieldDefault)){
        return{
          type: 'printDataFieldDefault',
          printConfig: {'printType': 1, 'printName': 'SpecimenLabel', 'printerName': printSetting.printerDefault },
          printContent: {
            'parameterField': {}, 'dataField': { "specimenInfo" : printDataFieldDefault}}
        };
      }
    }
  }
});
