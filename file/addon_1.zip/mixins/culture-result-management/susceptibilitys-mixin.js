/* eslint-disable max-lines */
/* eslint-disable prefer-object-spread */
/* eslint-disable no-console */
import $ from 'jquery';
import Mixin from '@ember/object/mixin';
import { isEmpty } from '@ember/utils';
import { set } from '@ember/object';
import { inject as service } from '@ember/service';
import { next } from '@ember/runloop';
import { A as emberA } from '@ember/array';

export default Mixin.create({
  model: null,
  resultCellsPopupTarget: null,
  isResultCellsPopupOpenByCodeable: false,
  isResultCellsPopupOpenByCodeableQuantity: false,
  susceptibilityResultItemsSource: null,
  susceptibilityGrid: null,
  susceptibilityRemoveIds: null,
  isSusceptibilityLoader: false,
  isSusceptibilityOpen: false,
  susceptibilityTarget: null,
  isEditingSusceptibilityItems: false,
  quantityComparator: null,
  quantityComparatorSelectedItem: null,
  numberValue: null,
  currentItem: null,
  codeableConceptItems: null,
  selectedRowsValueTypeCode: null,
  codeableConceptSelectedItem: {
    code: null,
    displayName: null
  },
  isCellReadOnly: false,
  loaderDimed: false,
  contentLoaderType: 'spinner',
  quantityInputSource: null,
  examinationUnit: null,
  isIdentificationsDisabled: true,
  isIdentificationsFieldsDisabled: true,
  isSusceptibilityTempItemsSource: false,
  isSusceptibilityDisabled: true,
  isSusceptibilityGridDisabled: false,
  cultureResultService: service('specimen-examination-report-culture-result-management-service'),


  onPropertyInit() {
    this._super(...arguments);

    this.setStateProperties([
      'model',
      'susceptibilityResultColumns',
      'resultCellsPopupTarget',
      'isResultCellsPopupOpen'
    ]);

    if(this.hasState()===false) {

      this.set('model', {
        susceptibilitySelectedItem: null,
        susceptibilityCheckedItems: null,
        selectedSusceptibilityExaminationIds : null,
        susceptibilitySelectedItemIndex: null,
        radioButtonsSelectedValue: null,

      });
      this.set('numericOptions', {
        alias: 'numeric',
        autoUnmask: true,
        unmaskAsNumber: true,
      });
      this.set('model.susceptibilityCheckedItems', []);
    }
  },
  actions: {
    onSusceptibilityGridLoad(e) {
      this.set('susceptibilityGrid', e.source);
    },
    onSusceptibilityGridSelectedAction(e) {
      this.set('model.susceptibilityCheckedItems', e.selectedItems);
      this.set('quantityComparatorSelectedItem', null);
      this.set('numberValue', null);
      const gridComponent = e.source;
      const selectedItem = e.selectedItems[0];
      let selectedExaminationIds = [];
      if (!isEmpty(e.selectedItems)) {
        e.selectedItems.map(d => {
          selectedExaminationIds.push(d.examination.id);
        });
        const itemIndex = gridComponent.getItemIndex(selectedItem);
        this.set('model.susceptibilitySelectedItemIndex', itemIndex);
      } else {
        selectedExaminationIds = [];
      }
      this.set('model.selectedSusceptibilityExaminationIds', selectedExaminationIds);
    },
    onSusceptibilityCellClick(e) {
      this._setCurrentCellInfo(e);
      set(e.column, 'readOnly', true);
      if(e.column.field === 'displayResultText') {
        set(e.column, 'type', 'number');
        // if (isEmpty(e.item.valueTypeCode)) {
        //   this._getSusceptibilityValueTypeCode(e.item.examination.id, e.column, false);
        // } else {
        //   set(e.column, 'readOnly', false);
        // }
        set(e.column, 'readOnly', false);
        // if (!isEmpty(e.item.valueTypeCode)) {
        //   set(e.column, 'readOnly', false);
        // }
      }
      if(e.column.field === 'interpretation.displayContent' && isEmpty(e.item.valueTypeCode)) {
        // 결과입력 팝업은 클릭일 때 오픈
        // this.getcodeableConceptItems(e.item.examination.id);
        this.set('resultCellsPopupTarget', `#${e.originalSource.elementId}`);
        this._getSusceptibilityValueTypeCode(e.item.examination.id, e.column, true);
      }
      if (e.column.field === 'antibioticReportableYN') {
        const changeReportable = !e.item.isReportable;
        const changeSymbol = changeReportable ? 'Y' : 'N';
        this._susceptibilitysGridItemChange(changeReportable, 'isReportable');
        this._susceptibilitysGridItemChange(changeSymbol, 'antibioticReportableYN');
      }
    },
    onSusceptibilityCellDoubleClick(e) {
      if(e.column.field === 'displayResultText') {
        set(e.column, 'readOnly', true);
        set(e.column, 'type', 'string');
      }
      if(e.column.field === 'interpretation.displayContent') {
        return;
      }
      this.set('resultCellsPopupTarget', `#${e.originalSource.elementId}`);
      this._setCurrentCellInfo(e);
      if (isEmpty(e.item.valueTypeCode)) {
        this._getSusceptibilityValueTypeCode(e.item.examination.id, e.column, true);
      } else {
        this._setResultFieldColumn(e.item.examination.id, e.column, e.item.valueTypeCode);
      }
    },
    onSusceptibilityEditEnd(e) {
      try {
        if(e.column.field === 'displayResultText') {
          set(e.column, 'readOnly', true);
          if(!isEmpty(e.item.displayResultText) && (e.item.displayResultText !== e.item.quantity.value)) {
            set(e.item, 'quantity.value', e.item.displayResultText);
            set(e.item, 'quantity.comparatorCode', null);
            set(e.item, 'interpretation.displayContent', null);
            this.getSusceptibilitysCalculate();
          }
          if(isEmpty(e.item.displayResultText)) {
            set(e.item, 'displayResultText', this._setDisplayResultValue(e.item.value));
          }
        }
        if (this.cellChagnedCheck(e)) {
          this.set('isEditingSusceptibilityItems', true);
        }
      } catch(err) {
        this._showError(err);
        console.log(err);
      }
    },
    onRemoveSusceptibilityItem() {
      if(isEmpty(this.get('model.susceptibilityCheckedItems'))) {
        this.showWarningMessage(this.getLanguageResource('9260', 'F', '항목을 선택하세요.'), 2000);
      } else {
        this._setRemoveSusceptibilityItems();
      }
    },

    //감수성결과코드조회
    onSusceptibilitySearch(e) {
      if (isEmpty(this.get('model.identificationSelectedItem.observationId'))) {
        // this.showWarningMessage(this.getLanguageResource('tempkey', 'F', '', '동정결과가 저장되지 않았습니다.'), 2000);
        this.showWarningMessage(this.getLanguageResource('9231', 'F', '', '저장되지 않은 데이터가 있습니다.'), 2000);
        return;
      }
      if (this.get('model.identificationCheckedItems').length === 1) {
        this.set('isSusceptibilityOpen', true);
        this.set('susceptibilityTarget', e.originalEvent.currentTarget);
      } else {
        this.showWarningMessage(this.getLanguageResource('11038', 'F', '', '한 개의 동정결과 항목을 선택하십시오.'), 2000);
      }
    },
    onReturnSusceptibility(returnItem) {
      // const valueTypeCode = this.get('model.identificationSelectedItem').get('valueTypeCode');
      // const valueTypeCode = "CodeableConcept";
      let antibiotics = null;
      if (Array.isArray(returnItem.antibiotics)) {
        antibiotics = returnItem.antibiotics;
      } else {
        antibiotics = [returnItem.antibiotics];
      }
      const isReportable = this.get('model.identificationSelectedItem.isReportable');
      console.log('isReportable---', isReportable);
      antibiotics.map(d => {
        d.isReportable = isReportable;
      });
      this._susceptibilitysItemsSetting(antibiotics, returnItem.id);
      this.set('isSusceptibilityOpen', false);
    },
    onCellsPopupOpenedAction() {
      // this.getcodeableConceptItems(this.get('model.susceptibilitySelectedItem.examination.id'));
    },
    onCheckboxlistChanged() {
      //
    },
    onQuantityInputOnLoaded(e) {
      this.set('quantityInputSource', e.source);
    },
    onQuantityOpenedAction() {
      this._setPopupItems();
      this._susceptibilitysGridItemChange(this.get('selectedRowsValueTypeCode'), 'valueTypeCode');

    },
    onQuantitySelectedChanged() {
      //
    },
    onQuantityAplly() {
      this._setQuantitysItem();
    },
    onCodeableConceptApply() {
      const codeableConceptSelectedItem = this.get('codeableConceptSelectedItem');
      this._susceptibilitysGridItemChange(this.get('codeableConceptSelectedItem.code'), 'interpretationCoding.code');
      // this._susceptibilitysGridItemChange(this.get('codeableConceptSelectedItem.displayName'), 'interpretationCoding.displayName');
      this._susceptibilitysGridItemChange(this.get('codeableConceptSelectedItem.displayName'), 'interpretation.displayContent');
      if (isEmpty(codeableConceptSelectedItem)) {
        this._susceptibilitysGridItemChange(null, 'codeableConcept.coding');
      } else {
        this._susceptibilitysGridItemChange([this.get('codeableConceptSelectedItem')], 'codeableConcept.coding');
      }
      this._susceptibilitysGridItemChange(this.get('codeableConceptSelectedItem.displayName'), 'codeableConcept.displayContent');
      this.set('isResultCellsPopupOpenByCodeable', false);
    },
    onQuantityInputTextCommit(){
      this._setQuantitysItem();
    },
    onComparatorComboKeyPress(e) {
      if(e.originalEvent.keyCode === 13){
        this._setQuantitysItem();
      }
    },
  },

  _setCurrentCellInfo(e) {
    const gridComponent = e.source,
      currentCell = gridComponent.getCurrentCell(),
      itemIndex = gridComponent.getItemIndex(currentCell.item);
    const currentValue = this.getCellsCurrentValue(e);
    this.set('model.susceptibilitySelectedItemIndex', itemIndex);
    this.set('model.selectedCellOriginValue', currentValue);

  },

  _susceptibilitysItemsSetting(antibiotics, id){
    antibiotics.forEach(item => {
      const susceptibilityResultItems = this.get('susceptibilityResultItemsSource');
      let hasFindedSameObj = false;
      const hasExaminationId = !isEmpty(item.examination);
      if (!isEmpty(susceptibilityResultItems) && hasExaminationId) {
        hasFindedSameObj = susceptibilityResultItems.find(d => d.examination.id === item.examination.id);
      }
      if (!hasFindedSameObj && hasExaminationId) {
        let tempObj = {};
        tempObj = this._getSusceptibilityDefaultObject();
        tempObj.examination = item.examination;
        tempObj.isReportable = item.isReportable;
        tempObj.antibioticSequence = item.displaySequence;
        // tempObj.valueTypeCode = valueTypeCode;
        tempObj.displayRange = this._getDisplayReferenceRange(item.referenceRanges);
        tempObj.isReportable = item.isReportable;
        tempObj.antibioticReportableYN = item.isReportable ? 'Y' : 'N';
        tempObj.susceptibilityId = id;
        this.get('susceptibilityResultItemsSource').addObject(tempObj);
        // if (item.isReportable) {
        //   this.get('susceptibilityGrid').selectRow(tempObj);
        // }
        this.set('isEditingSusceptibilityItems', true);
      }
    });
  },

  _setQuantitysItem() {
    this._susceptibilitysGridItemChange(this.get('quantityComparatorSelectedItem.code'), 'quantity.comparatorCode');
    this._susceptibilitysGridItemChange(this.get('numberValue'), 'quantity.value');
    const changedText = `${this.get('quantityComparatorSelectedItem.displayCode')} ${this.get('numberValue')}`;
    this._susceptibilitysGridItemChange(changedText, 'displayResultText');
    this._susceptibilitysGridItemChange(this.get('model.susceptibilitySelectedItem.quantity.value'), 'value.quantity.value');
    this._susceptibilitysGridItemChange(this.get('model.susceptibilitySelectedItem.quantity.comparatorCode'), 'value.quantity.comparatorCode');
    // this._susceptibilitysGridItemChange(this.get('model.susceptibilitySelectedItem.quantity.value'), 'quantity.value');
    // this._susceptibilitysGridItemChange(this.get('model.susceptibilitySelectedItem.quantity.comparatorCode'), 'quantity.comparatorCode');
    this.getSusceptibilitysCalculate();
    this.set('isResultCellsPopupOpenByCodeableQuantity', false);
  },
  _setSusceptibilitysDataReset() {
    this.set('isSusceptibilityDisabled', true);
    this.set('susceptibilityRemoveIds', []);
    this.set('isEditingSusceptibilityItems', false);
    this.set('susceptibilityResultItemsSource', []);

  },

  _susceptibilitysGridItemChange(item, column) {
    const selectedIndex = this.get('model.susceptibilitySelectedItemIndex');
    if (!isEmpty(selectedIndex)) {
      const gridList = this.get('susceptibilityResultItemsSource');
      set(gridList[selectedIndex], column, item);
      this.set('isEditingSusceptibilityItems', true);
    }
  },

  _setDisplayResultValue(item) {
    let returnText = '';
    const comparatorCode = item.quantity.comparatorCode === '-' || item.quantity.comparatorCode === null ? '' : item.quantity.comparatorCode;
    const quantityValue = item.quantity.value === null ? '' : item.quantity.value;
    if (!isEmpty(item.quantity.comparatorCode) || !isEmpty(item.quantity.value)) {
      returnText = `${comparatorCode} ${quantityValue}`;
    } else if(!isEmpty(item.observationId) && !isEmpty(item.codeableConcept.coding)){
      // returnText = `${item.codeableConcept.coding[0].displayName}`;
    }
    return returnText;

  },

  _setPopupItems() {
    try {
      const selectedRowItem = this.get('model.susceptibilitySelectedItem');
      const comparatorCode = selectedRowItem.quantity.comparatorCode;
      if (comparatorCode === '-' || isEmpty(comparatorCode)) {
        this.set('quantityComparatorSelectedItem',{
          code: '-',
          displayCode: ''
        });
      } else {
        this.set('quantityComparatorSelectedItem', this.get('quantityComparator').find(function(i){
          return i.code === comparatorCode;
        }));
      }
      // console.log($('#quantitNnumberValueInput input'));
      this.set('numberValue', selectedRowItem.quantity.value);
      next(this, function() {
        $('#quantitNnumberValueInput').find('input').focus();
        if (!isEmpty(selectedRowItem.quantity.value)) {
          next('this', function() {
            $('#quantitNnumberValueInput input').select();
          });
        }
      });
    } catch(e) {
      console.error(e);
    }
  },


  async getSusceptibilitysList(observationId) {
    try {
      const param = {bacterialIdentificationObservationId: observationId};
      const susceptibilitys = await this.get('cultureResultService').getCulturesBacterialIdentificationsSusceptibilitys(param);
      susceptibilitys.map(d => {
        d.interpretationCoding = d.interpretation.coding[0];
        if (isEmpty(d.interpretationCoding)) {
          d.interpretationCoding = {
            code: null,
            displayName: null,
          };
        }
        d.displayRange = isEmpty(d.examinationReferenceRange) ? '' : this._getDisplayReferenceRange(d.examinationReferenceRange);
        d.displayResultText = this._setDisplayResultValue(d.value);
        d.antibioticReportableYN = d.isReportable ? 'Y' : 'N';
        d.quantity = Object.assign({}, d.value.quantity);
        d.codeableConcept = d.value.codeableConcept;
      });
      return susceptibilitys;
    } catch(e) {
      this._showError(e);
      console.error(e);
    }

  },

  async _setSusceptibilitysGrid(observationId) {
    try {
      //TODO: checked remove
      this.set('loaderDimed', false);
      this.set('contentLoaderType', 'spinner');
      this.set('isSusceptibilityLoader', true);
      this.set('isIdentificationsDisabled', true);
      this.set('isIdentificationsFieldsDisabled', true);
      const susceptibilitys = await this.getSusceptibilitysList(observationId);
      const codeableConceptCode = this.get('model.identificationSelectedItem.codeableConceptCoding.code');
      if (!isEmpty(susceptibilitys)) {
        const checkItems = [];
        susceptibilitys.forEach(d => {
          if (d.isReportable) {
            checkItems.push(d);
          }
        });
        this.set('susceptibilityResultItemsSource', susceptibilitys);
      }
      if (isEmpty(susceptibilitys) && !isEmpty(codeableConceptCode)) {
        this._identificationsBySusceptibilitys(codeableConceptCode);
      }
      this.set('isSusceptibilityLoader', false);
      this.set('isIdentificationsDisabled', false);
      this.set('isIdentificationsFieldsDisabled', false);
      // this.get('susceptibilityGrid').selectRows(checkItems);
    } catch(e) {
      this.set('isSusceptibilityLoader', false);
      this._showError(e);
      console.error(e);
    }

  },

  async _identificationsBySusceptibilitys(code) {
    try {
      const param = {displayCode: code};
      const bacterialIdentifications = await this.get('cultureResultService').getBacterialIdentifications(param);
      if (!isEmpty(bacterialIdentifications) && !isEmpty(bacterialIdentifications[0].susceptibility)) {
        const susceptibilitysParam = {displayCode: bacterialIdentifications[0].susceptibility.displayCode};
        const susceptibilitys = await this.get('cultureResultService').getSusceptibilitys(susceptibilitysParam);
        if(!isEmpty(susceptibilitys)) {
          this.set('isEditingSusceptibilityItems', false);
          this.set('isSusceptibilityTempItemsSource', true);
          susceptibilitys.forEach(datas => {
            this._susceptibilitysItemsSetting(datas.antibiotics, datas.id);
          });
        }
      }
    } catch(e) {
      this._showError(e);
      console.error(e);
    }
  },

  async getSusceptibilitysCalculate() {
    try {
      this.set('isSusceptibilityGridDisabled', true);
      const selectedItem = this.get('model.susceptibilitySelectedItem');
      const params = {
        susceptibilityId: selectedItem.susceptibilityId,
        examinationId: selectedItem.examination.id,
        antibioticResultQuantity: {
          value: parseFloat(selectedItem.quantity.value),
          comparatorCode: selectedItem.quantity.comparatorCode,
          unitCode: selectedItem.quantity.unitCode,
          unitName: selectedItem.quantity.unitName
        }
      };
      const resultCalculate = await this.get('cultureResultService').getSusceptibilitysCalculate(params);
      if(!isEmpty(resultCalculate)) {
        const sendObj = {
          code: resultCalculate.code,
          displayName: resultCalculate.name
        };
        this._susceptibilitysGridItemChange(sendObj, 'interpretationCoding');
        this._susceptibilitysGridItemChange(resultCalculate.name, 'interpretation.displayContent');
      }
      this.set('isSusceptibilityGridDisabled', false);
    } catch(e) {
      this.set('isSusceptibilityGridDisabled', false);
      this._showError(e);
      console.log('getSusceptibilitysCalculate Error::', e);
    }
  },

  async _saveIdentificationsSusceptibility() {
    // const listParam = {cultureObservationId: this.get('observationCulturesData.observationId')};
    try {
      this.set('contentLoaderType', 'progress');
      this.set('loaderDimed', true);
      this.set('isSusceptibilityLoader', true);
      // const selectedExaminationIds = this.get('model.selectedSusceptibilityExaminationIds');
      const gridList = this.get('susceptibilityResultItemsSource');
      // gridList.map(item => {
      //   if(selectedExaminationIds.includes(item.examination.id)) {
      //     item.isReportable = true;
      //   }
      // });
      const changedList = this._getChangedIdentificationsSusceptibilityData(gridList);
      const params = {
        cultureObservationId: this.get('observationCulturesData.observationId'),
        bacterialIdentificationObservationId: this.get('model.identificationSelectedItem.observationId'),
        issuedStaffId: this.get('globalCurrentUser.employeeId'),
        susceptibilityResult: changedList
      };
      const deleteParams = {
        bacterialIdentificationObservationId: this.get('model.identificationSelectedItem.observationId'),
        susceptibilityObservationId: this.get('susceptibilityRemoveIds')
      };
      await this.get('cultureResultService').createCulturesBacterialIdentificationsSusceptibilitys(params);
      if (!isEmpty(this.get('susceptibilityRemoveIds'))) {
        await this.get('cultureResultService').deleteCulturesBacterialIdentificationsSusceptibilitys(deleteParams);
      }
      this.showToastSaved();
      // await this.getBacterialIdentifications(this.get('observationCulturesData.observationId'));
      const indentificationsSelectedItem = this.get('model.identificationSelectedItem');
      await this._setSusceptibilitysGrid(indentificationsSelectedItem.bacterialIdentificationRelated.targetObservationId);
      this.set('susceptibilityRemoveIds', []);
      this.set('isEditingSusceptibilityItems', false);
      this.set('isSusceptibilityTempItemsSource', false);
      this.set('isSusceptibilityLoader', false);
    } catch(e) {
      this.set('isSusceptibilityLoader', false);
      this.showToastSaveFail();
      console.error(e);
    }
  },
  _setRemoveSusceptibilityItems() {
    const removeList = this.get('susceptibilityRemoveIds');
    const selectedItems = this.get('model.susceptibilityCheckedItems');
    selectedItems.forEach(item => {
      if (!isEmpty(item.observationId)) {
        removeList.push(item.observationId);
      }
      this.get('susceptibilityResultItemsSource').removeObject(item);
    });
    this.set('isEditingSusceptibilityItems', true);
  },

  _getDisplayReferenceRange(items) {
    let rangeObj = {};
    rangeObj = {
      resistant: null,
      lowIntermediate: null,
      highIntermediate: null,
      susceptible: null
    };
    let intermediateRange = '';
    let resistantRange = '';
    let returnText = '';
    if(!isEmpty(items)) {
      items.forEach(item => {
        if (item.typeCode === 'anti-resistant'){
          rangeObj.resistant = this._setItemsValue(item.low.value);
        } else if (item.typeCode === 'anti-intermediate'){
          rangeObj.lowIntermediate = this._setItemsValue(item.low.value);
          rangeObj.highIntermediate = this._setItemsValue(item.high.value);
        } else if (item.typeCode === 'anti-susceptible'){
          rangeObj.susceptible = this._setItemsValue(item.high.value);
        }
      });
      if (!isEmpty(rangeObj.lowIntermediate) && !isEmpty(rangeObj.highIntermediate)) {
        intermediateRange = `${rangeObj.lowIntermediate}~${rangeObj.highIntermediate}, `;
      }
      if (!isEmpty(resistantRange)) {
        resistantRange = `${rangeObj.resistant}, `;
      }
      returnText = `${resistantRange}${intermediateRange}${rangeObj.susceptible}`;
    }
    return returnText;
  },

  _setItemsValue(value) {
    return isEmpty(value) ? '' : value;
  },

  _getSusceptibilityDefaultObject() {
    const tempObj = {
      observationId: null,
      susceptibilityId: null,
      examination: null,
      interpretationCoding: {
        code: null,
        displayName: null,
      },
      interpretation: {
        coding:{},
        displayContent: null,
      },
      antibioticSequence: null,
      valueTypeCode: null,
      codeableConcept: {
        coding: [],
        displayContent: null,
      },
      value: {
        quantity: {
          value: null,
          comparatorCode: null,
          unitCode: null,
          unitName: null,
        },
      },
      quantity: {
        value: null,
        comparatorCode: null,
        unitCode: null,
        unitName: null,
      },
      displayRange: null,
      isReportable: null,
      antibioticReportableYN: null,
    };
    return tempObj;
  },

  _getChangedIdentificationsSusceptibilityData(gridList) {
    const changedList = [];
    gridList.forEach(d => {
      let tempObj = {};
      let valueTypeCode = d.valueTypeCode;
      if(isEmpty(valueTypeCode) && !isEmpty(d.quantity) && d.quantity.value !== null) {
        valueTypeCode = 'Quantity';
      }
      tempObj = {
        susceptibilityObservationId: d.observationId,
        susceptibilityId: d.susceptibilityId,
        examinationId: d.examination.id,
        interpretationCode: isEmpty(d.interpretationCoding.code) ? null : d.interpretationCoding.code,
        interpretationName: isEmpty(d.interpretation.displayContent) ? null : d.interpretation.displayContent,
        antibioticSequence: d.antibioticSequence,
        valueTypeCode: valueTypeCode,
        antibioticResultQuantity: d.quantity,
        antibioticResultCodeableConcept: isEmpty(d.codeableConcept.coding) ? {} : d.codeableConcept,
        isReportable: d.isReportable,
      };
      changedList.push(tempObj);
    });
    return changedList;

  },

  async _getSusceptibilityValueTypeCode(examinationId, column, isDoubleclick) {
    let valueTypeCode = null;
    let isReadOnry = true;
    try {
      this.set('isSusceptibilityGridDisabled', true);
      const examinationInfo = await this.get('cultureResultService').getSpecimenExaminations({id: examinationId});
      const resultTypeCode = examinationInfo.property.resultTypeCode;
      switch (resultTypeCode) {
        case 'Numeric':
          valueTypeCode = 'Quantity';
          break;
        case 'Character':
          valueTypeCode = 'CodeableConcept';
          break;
        default:
          valueTypeCode = null;
          break;
      }
      // const conceptList = await this.get('cultureResultService').getBusinessCodesSearch({classificationCode: valueTypeCode});
      // console.log('conceptList::::', conceptList);
      this.set('selectedRowsValueTypeCode', valueTypeCode);
      if(isDoubleclick) {
        this._setResultFieldColumn(examinationId, column, valueTypeCode);
      } else if(!isDoubleclick && valueTypeCode === 'Quantity' && column.field === 'displayResultText'){
        set(column, 'readOnly', false);
        isReadOnry = false;
        // set(this.get('susceptibilityGrid').get('columns')[3], 'readOnly', false);
      } else if(!isDoubleclick && valueTypeCode === 'CodeableConcept' && column.field === 'interpretation.displayContent') {
        set(column, 'readOnly', false);
        isReadOnry = false;
      }
      this.set('isSusceptibilityGridDisabled', false);
      return isReadOnry;
    } catch(e) {
      console.error(e);
    }
    return valueTypeCode;
  },

  _setResultFieldColumn(examinationId, column, valueTypeCode) {
    const field = column.field;
    if (valueTypeCode === 'Quantity' && field === 'displayResultText') {
      this._getExaminationUnits(examinationId);
      this.set('isResultCellsPopupOpenByCodeableQuantity', true);
    } else if(valueTypeCode === 'CodeableConcept' && field === 'interpretation.displayContent'){
      this.set('isResultCellsPopupOpenByCodeable', true);
      this.set('isShowPopupLoader', true);
      this.getcodeableConceptItems(this.get('model.susceptibilitySelectedItem.examination.id'));
    } else if(valueTypeCode === 'Quantity' && field === 'interpretation.displayContent') {
      set(column, 'readOnly', true);
    }
  },

  async _getExaminationUnits(examinationId) {
    try {
      const examinationUnits = await this.get('cultureResultService').getExaminationUnits(examinationId);
      if(!isEmpty(examinationUnits)) {
        this.set('examinationUnit', examinationUnits[0].name);
      }
    } catch(e) {
      console.error(e);
    }
  },

  async getQuantityComparator() {
    try {
      const quantityComparator = await this.get('cultureResultService').getBusinessCodesSearch({classificationCode: 'QuantityComparator'});
      this.set('quantityComparator', quantityComparator);
    } catch(e) {
      console.error(e);
    }
  },

  async getcodeableConceptItems(examinationId) {
    try {
      this.set('isSusceptibilityGridDisabled', true);
      this.set('codeableConceptItems', emberA());
      const params = {exampleTypeCode: 'ExampleValue', examinationId: examinationId};
      const codeableConcept = await this.get('cultureResultService').getObservationsExamples(params);
      if(!isEmpty(codeableConcept)) {
        codeableConcept.forEach(items => {
          if(!isEmpty(items.value.codeableConcept.coding)) {
            this.get('codeableConceptItems').addObject(items.value.codeableConcept.coding[0]);
          }
        });
      }
      next(() => {
        this.set('isSusceptibilityGridDisabled', false);
        this.set('isShowPopupLoader', false);
      });
    } catch(e) {
      if(!this.get('isDestroyed')) {
        this.set('isSusceptibilityGridDisabled', false);
      }
      console.error(e);
    }
  },

});