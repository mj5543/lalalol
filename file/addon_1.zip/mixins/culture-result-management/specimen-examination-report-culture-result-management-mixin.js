/* eslint-disable prefer-named-capture-group */
/* eslint-disable require-unicode-regexp */
/* eslint-disable max-lines-per-function */
/* eslint-disable no-console */
import Mixin from '@ember/object/mixin';
import { inject as service } from '@ember/service';
import { isEmpty, compare } from '@ember/utils';
import { get } from '@ember/object';
import $ from 'jquery';

export default Mixin.create({
  model: null,
  currentUser: null,
  specimenNumber:null,
  cvrSendInformation: null,
  initializeTimeVolume: null,
  comments: null,
  contentLoaderType: 'spinner',
  displaySamplingName: null,
  displaySamplingDate: null,
  displayCheckInName: null,
  displayCheckInDate: null,
  cultureResultService: service('specimen-examination-report-culture-result-management-service'),


  onPropertyInit() {
    this._super(...arguments);

    this.setStateProperties([
      'model',
      'currentUser',
      'identificationResultColumns',
      'resultExampleColumns',
      'specimenNumber',
      'cvrSendInformation',
      'comments'
    ]);

    if(this.hasState()===false) {

      this.set('model', {

      });
      this.set('currentUser', this.get('co_CurrentUserService.user'));


    }
  },
  actions: {
    onAddButtonClick() {
      //
    },
    onDeleteButtonClick() {
      //
    },
    // onSendCvrClick(){
    //   console.log('onSendCVRClick---');
    //   const cvrInfo = this.get('cvrInfo');
    //   this.set('isCvrOpen', true);
    //   this.set('cvrSendInformation', Ember.A({
    //     patient : {
    //       id: cvrInfo.subjectId,
    //       displayCode: cvrInfo.subject.displayNumber,
    //       name: cvrInfo.subject.name
    //     },
    //     examination: {
    //       basedOnTypeCode: cvrInfo.basedOnTypeCode,
    //       basedOnId: cvrInfo.basedOnId,
    //       name: cvrInfo.examination.name,
    //       performDate: cvrInfo.performers.get('firstObject.performDatetime')
    //     },
    //     encounter: { id: this.get('resultWorkData.encounterId') },
    //     smsContent: null,
    //     staffs: null,
    //     result: null
    //   }));
    // },

    // getSendResult(){
    //   //
    // },
    onBeforeKeyDown(e) {
      if (e.originalEvent.keyCode === 13) {
        let gridComponent = e.source,
          currentCell = gridComponent.getCurrentCell(),
          itemIndex = gridComponent.getItemIndex(currentCell.item),
          columnIndex = gridComponent.getColumnIndex(currentCell.column);

        if (itemIndex !== -1 && columnIndex !== -1) {
          columnIndex = columnIndex + 1;
          e.cancel = true;
          if (get(gridComponent, 'bindingColumns').length <= columnIndex) {
            itemIndex = itemIndex + 1;
            columnIndex = 0;
          }
          gridComponent.focusCell(itemIndex, columnIndex);
          // gridComponent.editCell(itemIndex, columnIndex);
        }
        gridComponent = null;
        currentCell = null;
      }
    },
  },

  async getBacterialIdentifications(cultureObservationId) {
    try {
      const params = {cultureObservationId: cultureObservationId};
      const bacterialIdentifications = await this.get('cultureResultService').getCulturesBacterialIdentifications(params);
      bacterialIdentifications.map(d => {
        d.interpretationCoding = d.interpretation.coding[0];
        d.interpretationCoding.name = d.interpretationCoding.displayName;
        d.methodCoding = d.method.coding[0];
        d.methodCoding.name = d.methodCoding.displayName;
        if (isEmpty(d.media)) {
          d.media = {
            code: null,
            displayCode: null,
            name: null
          };
        }
        if(!isEmpty(d.remark)) {
          d.remark = d.remark.replace(/(\n|\r\n)/g, '<br>');
        }
        d.codeableConceptCoding = d.value.codeableConcept.coding[0];
        d.resultContent = null;
        d.isReportable = isEmpty(d.isReportable) ? false : d.isReportable;
        d.reportableYN = d.isReportable ? 'Y' : 'N';
      });
      return bacterialIdentifications;
    } catch(e) {
      console.error(e);

    }
  },


  getUnitItem(resultCultures) {
    let unitItem = {};
    unitItem = {title: null, date: null, color: null};

    switch(resultCultures.statusCode) {
      case 'registered':
        // unitItem.title = '접수';
        unitItem.color = '#8dcc1a;';
        break;
      case 'preliminary':
        // unitItem.title = '중간';
        unitItem.color = '#ef9144;';
        break;
      case 'final':
        // unitItem.title = '최종';
        unitItem.color = '#3cb8f5;';
        break;
      case 'corrected':
        // unitItem.title = '수정후보고';
        unitItem.color = '#3cb8f5;';
        break;
      default:
        break;
    }
    unitItem.title = resultCultures.statusName;
    unitItem.date = resultCultures.issuedDatetime;
    return unitItem;

  },

  _getChangedResultData(gridList) {
    const changedList = [];
    gridList.forEach(d => {
      let tempObj = {};
      let remark = d.remark;
      if (!isEmpty(d.remark)) {
        remark = d.remark.replace(/(<br>|<br\/>|<br \/>)/g, '\r\n');
      }
      tempObj = {
        bacterialIdentificationObservationId: d.observationId,
        examinationId: this.get('specimenExaminationId'),
        mediaCode: d.media.code,
        interpretationCode: d.interpretationCoding.code,
        interpretationName: d.interpretationCoding.name,
        colonySequence: d.colonySequence,
        colonyContent: d.colonyContent,
        resultCode: d.codeableConceptCoding.code,
        resultContent: d.codeableConceptCoding.displayName,
        remark: remark,
        characterizationContent: d.characterizationContent,
        methodCode: d.methodCoding.code,
        methodContent: d.methodCoding.name,
        additionalExaminationContent: d.additionalExaminationContent,
        isReportable: d.isReportable,
      };
      changedList.push(tempObj);
    });
    return changedList;
  },

  _getIdentificationDefaultObject() {
    const tempObj = {
      observationId: null,
      isReportable: true,
      reportableYN: 'Y',
      bacterialIdentificationRelated: {
        typeCode: '',
        observationId: '',
        targetObservationId: '',
        displaySequence: null
      },
      media: {
        code: null,
        displayCode: null,
        name: null,
        abbreviation: null
      },
      colonySequence: null,
      colonyContent: null,
      value: {
        attachments: [],
        valueTextString: null,
        recordNoteId: null
      },
      remark: null,
      characterizationContent: null,
      additionalExaminationContent: null,
      issuedStaff: null,
      displaySequence: 1,
      interpretationCoding: {
        code: null,
        displayName: null,
        displayCode: null,
        name: null,
        abbreviation: null
      },
      methodCoding: {
        system: null,
        version: '',
        code: null,
        displayName: null
      },
      codeableConceptCoding: {
        system: null,
        version: null,
        code: null,
        displayName: null
      }
    };

    return tempObj;
  },

  _getCultureObservationResult() {
    //TODO: isReportable
    // const checkedList = this.get('model.identificationCheckedItems');
    // const susceptibilityList = this.get('susceptibilityResultItemsSource');
    const identificationsList = this.get('identificationResultItemsSource');
    // const susceptibilityIds = [];
    const returnList = [];
    // if (checkedList.length === 1) {
    //   susceptibilityList.forEach(item => {
    //     susceptibilityIds.push(item.observationId);
    //   });
    // }
    identificationsList.forEach(data => {
      if (data.isReportable) {
        returnList.push({
          bacterialIdentificationObservationId: data.observationId,
        });
      }
    });
    // checkedList.forEach(datas => {
    //   returnList.push({
    //     bacterialIdentificationObservationId: datas.observationId,
    //     susceptibilityObservationId: susceptibilityIds
    //   });
    // });
    return returnList;

  },

  getRegisterCultureParams(status) {
    const currentResultStatus = this.get('observationCulturesData.statusCode');
    let inputStatus = status;
    if ((currentResultStatus === 'final' || currentResultStatus ==='corrected') && status === 'final') {
      inputStatus = 'corrected';
    } else if ((currentResultStatus === 'final'|| currentResultStatus ==='corrected') && status === 'preliminary') {
      this.showWarningMessage(this.getLanguageResource('9288', 'F', '', '저장만 가능합니다.'), 2000);
      return;
    }
    let resultContentText = '';
    if (!isEmpty(this.get('model.resultExamplesInputText'))) {
      resultContentText = this.get('model.resultExamplesInputText');
    }
    const isReport = currentResultStatus === 'preliminary' ? false : true;
    const params = {
      inputStatus: inputStatus,
      isReport: isReport,
      cultureObservationId: this.get('observationCulturesData.observationId'),
      resultContent: resultContentText,
      issuedStaffId: this.get('globalCurrentUser.employeeId'),
      observationResultChange: this.get('model.resultReason'),
      cultureObservationResult: this._getCultureObservationResult()
    };
    return params;
  },


  getHasEditItems() {
    if (this.get('isEditingIdentificationItems') || this.get('isEditingSusceptibilityItems')) {
      this.showWarningMessage(this.getLanguageResource('9231', 'F', '', '저장 되지 않은 데이터가 있습니다.'), 2000);
      return false;
    } else {
      return true;
    }

  },
  _checkEditingItem() {
    if(this.get('identificationResultItemsSource').length !== this.get('identificationResultItemsOriginal').length) {
      return false;
    } else if(this._compareOriginalSource() > 0){
      return false;
    } else {
      return true;
    }
  },
  _compareOriginalSource() {
    let compareCount = 0;
    const identificationResultItemsSource = this.get('identificationResultItemsSource');
    this.get('identificationResultItemsOriginal').forEach(item => {
      const compareItem = identificationResultItemsSource.find(d => d.observationId === item.observationId);
      if(isEmpty(compareItem)) {
        compareCount++;
      } else {
        const compareRes = compare(item, $.extend(false, {}, compareItem));
        console.log('compareRes---', compareRes);
        if(compareRes < 0) {
          compareCount++;
        }
      }
    });
    return compareCount;
  },

  getCellsCurrentValue(e) {
    const currentField = e.column.field;
    const arrField = currentField.split('.');
    let currentValue = '';
    if (arrField.length > 1) {
      currentValue = e.item[arrField[0]][arrField[1]];
    } else {
      currentValue = e.item[arrField[0]];
    }
    return currentValue;

  },
  cellChagnedCheck(e) {
    const originValue = this.get('model.selectedCellOriginValue');
    const changedValue = this.getCellsCurrentValue(e);
    if (originValue !== changedValue) {
      return true;
    } else {
      return false;
    }
  },

  hasCustomMethodCode(method) {
    if (method.code.indexOf('9999') > -1) {
      return true;
    } else {
      return false;
    }
  },

});