/* eslint-disable max-lines-per-function */
/* eslint-disable no-console */
// import $ from 'jquery';
import Mixin from '@ember/object/mixin';
import { inject as service } from '@ember/service';
// import { isEmpty, isPresent } from '@ember/utils';
// import { next } from '@ember/runloop';
// import { copy } from '@ember/object/internals';
// import EmberObject from '@ember/object';
// import { A as emberA } from '@ember/array';

export default Mixin.create({
  model: null,
  apiService: service('specimen-examination-report-infection-management-service'),

  onPropertyInit() {
    this._super(...arguments);

    this.setStateProperties([
      'model',
    ]);
    const displayDate = new Date(this.get('co_CommonService').getNow());
    this.set('selectedFromDate', displayDate);
    this.set('selectedToDate', displayDate);
    this.set('urlPrefix', this.get('apiService').urlPrefix);

  },
  actions: {
  },

  _getSearchFromTo() {
    const selectedFromDate = new Date(this.get('selectedFromDate'));
    const selectedToDate = new Date(this.get('selectedToDate'));
    const fromDate = new Date(selectedFromDate.getFullYear(), selectedFromDate.getMonth(), selectedFromDate.getDate()).toFormatString();
    const toDate = new Date(selectedToDate.getFullYear(), selectedToDate.getMonth(), selectedToDate.getDate()).toFormatString();
    return {fromDate, toDate};

  }

});