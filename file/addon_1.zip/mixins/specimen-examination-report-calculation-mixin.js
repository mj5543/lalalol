/* eslint-disable max-lines-per-function */
/* eslint-disable no-console */
// import $ from 'jquery';
import Mixin from '@ember/object/mixin';
import { inject as service } from '@ember/service';
import { isEmpty, isPresent } from '@ember/utils';
import EmberObject, { set, get } from '@ember/object';
// import { next } from '@ember/runloop';
// import { copy } from '@ember/object/internals';
// import { A as emberA } from '@ember/array';

export default Mixin.create({
  specimenexaminationreportService: service('specimen-examination-report-service'),
  applyItem: null,

  onPropertyInit() {
    this._super(...arguments);
  },
  actions: {
  },
  _getCalculate(currentItem) {
    const returnCalculatedValueCB = this.get('returnCalculatedValueCB');
    const resultListItemsSource = this.get('resultListItemsSource');
    if(isEmpty(resultListItemsSource)){
      return;
    }
    const isQuantityValueType = currentItem.valueTypeCode === 'Quantity';
    let observationResults = null;
    if(isQuantityValueType) {
      observationResults = this._getQuantityObservationResults(resultListItemsSource, currentItem);
    } else {
      observationResults = this._getCodeableConceptObservationResults(resultListItemsSource, currentItem);
    }
    if(isEmpty(observationResults)) {
      return;
    }
    const params = {
      inputModeType: 'Rule',
      isPossibleInputItemId: true,
      subjectId: currentItem.subjectId,
      subjectTypeCode : 'Patient',
      specimenNumber: currentItem.specimenNumber,
      observationResults: observationResults
    };
    this.set('isPopupShow', true);
    this.set('gridDisabled', true);
    return this.create(this.get('defaultUrl') + 'observations/results/calculate', null, params).then(function(res){
      this.set('gridDisabled', false);
      this.set('isPopupShow', false);
      this.set('closedByConfirmedBtn', false);
      this.set('fullTextValue', null);
      this.set('numberValue', null);
      this.set('commentsValue', null);
      if(isEmpty(res)){
        return;
      }
      if(!isEmpty(returnCalculatedValueCB)) {
        returnCalculatedValueCB(null);
      }
      this.get('resultListItemsSource').forEach(function(gridItem, gridItemIndex){
        let item = null;
        const changedItem=res.findBy('examinationId', gridItem.examinationId);
        if (this.get('mode')=='general' && !isEmpty(changedItem)){
          item= changedItem;
          set(gridItem, 'isUpdated', true);
        }else if(this.get('mode')=='results-by-item'){
          item=res[gridItemIndex];
        }else{
          return;
        }

        const valueValueString = this.get('specimenexaminationreportService')._setValueString(item);
        if(item.valueTypeCode === 'Quantity'){
          if(isPresent(item.value)){
            set(gridItem, 'valueValueString', valueValueString);
            set(gridItem, 'numericCellInputValue',valueValueString );
            set(gridItem, 'value', item.value);
          }
          if(gridItem.examinationId === currentItem.examinationId){
            set(currentItem, 'a', true);
            set(currentItem, 'isUpdated', true);
          }

          if((gridItem.statusCode =='final' || gridItem.statusCode =='corrected') && (valueValueString == gridItem.valueValueString)){
            //검증상태이고 value가 같으면 isUpdated 업데이트 안함
            //gridItem: calculate 전 -> item, valueValueString: calculate 후
            set(currentItem, 'isUpdated', false);
            set(gridItem, 'isUpdated', false);
          }
        }else if(item.valueTypeCode=='CodeableConcept'){
          if(isPresent(item.value)){
            set(gridItem, 'valueValueString', valueValueString);
            set(gridItem, 'numericCellInputValue', valueValueString);
            set(gridItem, 'value', item.value);
          }
        }else if(item.valueTypeCode=='ValueString'){
          set(gridItem, 'valueValueString', valueValueString);
          set(gridItem, 'valueString', valueValueString);
          set(gridItem, 'numericCellInputValue', valueValueString);
          set(gridItem, 'value', item.value);
        }
        set(gridItem, 'check.isCritical', item.check.isCritical);
        set(gridItem, 'check.isDelta', item.check.isDelta);
        set(gridItem, 'check.isPanic', item.check.isPanic);
        set(gridItem, 'check.isRecentCritical', item.check.isRecentCritical);
        // if(gridItem.statusCode == "waiting"){
        if(gridItem.check.isNotAnalyticalMeasurementRange != item.check.isNotAnalyticalMeasurementRange){
          //calculate 후 달라졌을 경우만 업데이트
          set(gridItem, 'check.isNotAnalyticalMeasurementRange', item.check.isNotAnalyticalMeasurementRange);
        }
        set(gridItem, 'interpretation', item.interpretation);
        if(!isEmpty(item.interpretation)){
          set(gridItem, 'interpretation.code', item.interpretation.coding.get('firstObject.code'));
        }
        set(gridItem, 'valueTypeCode', item.valueTypeCode);
        set(gridItem, 'numberValue', null);
      }.bind(this));
      // const changedItem = res.findBy('examinationId', currentItem.examinationId);
      // const valueValueString = this.get('specimenexaminationreportService')._setValueString(changedItem);
      // if(isPresent(changedItem.value)){
      //   set(currentItem, 'valueValueString', valueValueString);
      //   set(currentItem, 'numericCellInputValue', valueValueString);
      //   set(currentItem, 'value', changedItem.value);
      // }
      // set(currentItem, 'check.isCritical', changedItem.check.isCritical);
      // set(currentItem, 'check.isDelta', changedItem.check.isDelta);
      // set(currentItem, 'check.isPanic', changedItem.check.isPanic);
      // set(currentItem, 'check.isRecentCritical', changedItem.check.isRecentCritical);
      // // if(gridItem.statusCode == "waiting"){
      // if(currentItem.check.isNotAnalyticalMeasurementRange != changedItem.check.isNotAnalyticalMeasurementRange){
      //   //calculate 후 달라졌을 경우만 업데이트
      //   set(currentItem, 'check.isNotAnalyticalMeasurementRange', changedItem.check.isNotAnalyticalMeasurementRange);
      // }
      // set(currentItem, 'interpretation', changedItem.interpretation);
      // if(!isEmpty(changedItem.interpretation)){
      //   set(currentItem, 'interpretation.code', changedItem.interpretation.coding.get('firstObject.code'));
      // }
      // set(currentItem, 'valueTypeCode', changedItem.valueTypeCode);
      // set(currentItem, 'numberValue', null);
      //save 작업 위한
      // set(currentItem, 'isUpdated', true);
      // set(currentItem, 'isValueChanged', false);
      // set(currentItem, 'isCleared', false);
      // set(currentItem, 'valueTypeCode', applyItem.valueTypeCode);
      // if(isPresent(this.get('resultChangedItemCB'))) {
      //   this.get('resultChangedItemCB')(currentItem);
      // }
      this.set('isChangesLogOpened', false);
    }.bind(this)).catch(function(error){
      set(currentItem, 'isValueChanged', false);
      this.set('currentItem', null);
      this._catchError(error);
    }.bind(this));

  },
  _getCalculateCommon(inputModeType, applyItem){
    const currentItem = isEmpty(this.get('previousItem'))? this.get('currentItem'): this.get('previousItem');
    const isQuantityValueType = currentItem.valueTypeCode === 'Quantity';
    if(isPresent(applyItem)) {
      this.set('applyItem', applyItem);
    }
    if(isEmpty(currentItem)){
      return;
    }
    const numberValue = this.get('numberValue');
    if((isQuantityValueType && isEmpty(numberValue)) || isEmpty(this.get('fullTextValue'))){
      if(currentItem.isCleared != true){
        // this.get('specimenexaminationreportService')._showMessage(this.getLanguageResource('8945', 'F', '필수값을 입력하세요.'), 'warning', 'Ok', 'Ok', '', 2000);
        return;
      }
    }
    let resultListItemsSource = [];
    let selectedItemsTemp = this.get('selectedItems');
    if (this.get('mode') ==='general') {
      //일반검사결과관리
      resultListItemsSource = this.get('resultListItemsSource');
    }else{
      if(isQuantityValueType) {
        //항목별검사결과관리 에서는 선택항목만 계산
        if(selectedItemsTemp.length==1 && !isEmpty(this.get('currentItem'))){
          //keydown으로 cell이동시 그리드 선택값과 focused cell이 다른 문제
          if(this.get('previousItem') != this.get('currentItem')){
            selectedItemsTemp=[];
            selectedItemsTemp.addObject(this.get('currentItem'));
            this.set('currentItem', currentItem);
          }
        }else if(selectedItemsTemp.length > 1 || selectedItemsTemp.length === 0){
          selectedItemsTemp=[];
          selectedItemsTemp.addObject(this.get('currentItem'));
        }
        this.set('currentItem', currentItem);
      }
      selectedItemsTemp.forEach(function (e) {
        resultListItemsSource.addObject(EmberObject.create(e));
      });
    }
    if(isEmpty(resultListItemsSource)){
      return;
    }
    let observationResults = null;
    if(isQuantityValueType) {
      observationResults = this._getQuantityObservationResults(resultListItemsSource, currentItem);
    } else {
      observationResults = this._getCodeableConceptObservationResults(resultListItemsSource, currentItem);
    }
    if(isEmpty(observationResults)) {
      return;
    }
    const params = {
      inputModeType: inputModeType,
      isPossibleInputItemId: true,
      subjectId: currentItem.subjectId,
      subjectTypeCode : 'Patient',
      specimenNumber: currentItem.specimenNumber,
      observationResults: observationResults
    };
    // if(calculateArr.length === 0){
    //   return;
    // }
    this.set('isPopupShow', true);
    this.set('gridDisabled', true);
    return this.create(this.get('defaultUrl') + 'observations/results/calculate', null, params).then(function(res){
      this.set('gridDisabled', false);
      this.set('isPopupShow', false);
      this.set('closedByConfirmedBtn', false);
      this.set('fullTextValue', null);
      this.set('numberValue', null);
      this.set('commentsValue', null);
      if(isEmpty(res)){
        return;
      }
      const returnCalculatedValueCB = this.get('returnCalculatedValueCB');
      if (this.get('mode')=='results-by-item') {
        //항목별검사관리- 선택항목만 binding
        const item= res.get('firstObject');
        set(item, 'valueValueString', this._setValueString(item));
        set(item, 'numericCellInputValue', this._setValueString(item));
        if(!isEmpty(returnCalculatedValueCB)) {
          returnCalculatedValueCB(item, this.get('currentItem'));
        }
      }else{
        //일반검사관리
        if(!isEmpty(returnCalculatedValueCB)) {
          returnCalculatedValueCB(null);
        }
        this.get('resultListItemsSource').forEach(function(gridItem, gridItemIndex){
          let item=null;
          const changedItem=res.findBy('examinationId', gridItem.examinationId);
          if (this.get('mode')=='general' && !isEmpty(changedItem)){
            item= changedItem;
          }else if(this.get('mode')=='results-by-item'){
            item=res[gridItemIndex];
          }else{
            return;
          }

          const valueValueString = this.get('specimenexaminationreportService')._setValueString(item);
          if(item.valueTypeCode === 'Quantity'){
            if(isPresent(item.value)){
              set(gridItem, 'valueValueString', valueValueString);
              set(gridItem, 'numericCellInputValue',valueValueString );
              set(gridItem, 'value', item.value);
            }
            if(gridItem.examinationId === currentItem.examinationId){
              set(currentItem, 'a', true);
              set(currentItem, 'isUpdated', true);
            }

            if((gridItem.statusCode =='final' || gridItem.statusCode =='corrected') && (valueValueString == gridItem.valueValueString)){
              //검증상태이고 value가 같으면 isUpdated 업데이트 안함
              //gridItem: calculate 전 -> item, valueValueString: calculate 후
              set(currentItem, 'isUpdated', false);
            }
          }else if(item.valueTypeCode=='CodeableConcept'){
            if(isPresent(item.value)){
              set(gridItem, 'valueValueString', valueValueString);
              set(gridItem, 'numericCellInputValue', valueValueString);
              set(gridItem, 'value', item.value);
            }
          }
          set(gridItem, 'check.isCritical', item.check.isCritical);
          set(gridItem, 'check.isDelta', item.check.isDelta);
          set(gridItem, 'check.isPanic', item.check.isPanic);
          set(gridItem, 'check.isRecentCritical', item.check.isRecentCritical);
          // if(gridItem.statusCode == "waiting"){
          if(gridItem.check.isNotAnalyticalMeasurementRange != item.check.isNotAnalyticalMeasurementRange){
            //calculate 후 달라졌을 경우만 업데이트
            set(gridItem, 'check.isNotAnalyticalMeasurementRange', item.check.isNotAnalyticalMeasurementRange);
          }
          set(gridItem, 'interpretation', item.interpretation);
          if(!isEmpty(item.interpretation)){
            set(gridItem, 'interpretation.code', item.interpretation.coding.get('firstObject.code'));
          }
          set(gridItem, 'valueTypeCode', item.valueTypeCode);
          set(gridItem, 'numberValue', null);
        }.bind(this));
      }
      //save 작업 위한
      set(currentItem, 'isUpdated', true);
      set(currentItem, 'isValueChanged', false);
      set(currentItem, 'isCleared', false);
      set(currentItem, 'valueTypeCode', applyItem.valueTypeCode);
      this.set('isChangesLogOpened', false);
      if(this.get('closedByKeyDown')==true){
        // this._moveFocus('down', false);
        this.set('closedByKeyDown', false);
      }
    }.bind(this)).catch(function(error){
      set(currentItem, 'isValueChanged', false);
      this.set('currentItem', null);
      this._catchError(error);
    }.bind(this));
  },

  _getQuantityObservationResults(resultListItemsSource, currentItem) {
    const observationResults = [];
    let value={};
    const calculateArr=[];
    resultListItemsSource.forEach(element=>{
      const e=EmberObject.create(element);
      if(currentItem.examinationId === e.examinationId && currentItem.specimenId === e.specimenId){
        set(e, 'isValueChanged', true);
        set(e, 'value', currentItem.value);
        set(e, 'valueTypeCode', currentItem.valueTypeCode);
        // if(isPresent(currentItem.value)) {
        //   set(e, 'valueString', currentItem.value.valueString);
        // }
        calculateArr.addObject(e);
      }else if(this.get('mode')=='results-by-item'){
        calculateArr.addObject(e);
      }
      if(e.isCleared==true){
        value={
          quantity: {value: null, comparatorCode: null, unitCode: null, unitName: null},
          codeableConcept:  value={coding: null, displayContent: null},
          valueString: null
        };
      }else{
        value=this._setCalculateValue(e);
      }
      if(e.isValueChanged != true){
        //calculate 대상 아닌 경우
        observationResults.addObject(this._addObservationResult(e, value, false));
        return;
      }
      observationResults.addObject(this._addObservationResult(e, value, true));
    });
    if(calculateArr.length === 0){
      return;
    }
    return observationResults;

  },
  _getCodeableConceptObservationResults(resultListItemsSource, currentItem) {
    const observationResults= [];
    let value={};
    if(isEmpty(resultListItemsSource)){
      return;
    }
    const now = this.get('co_CommonService').getNow();
    resultListItemsSource.forEach(element=>{
      const e = element;
      if(currentItem.examinationId==e.examinationId && currentItem.specimenId==e.specimenId && e.value != currentItem.value
         && e.valueValueString != e.fullTextValue){
        set(e, 'isValueChanged', true);
        set(e, 'value', currentItem.value);
        set(e, 'valueTypeCode', currentItem.valueTypeCode);
      }else if(currentItem.examinationId==e.examinationId && currentItem.fullTextValue != this.get('initialDisplayName')){
        set(e, 'isValueChanged', true);
      }
      if(e.isCleared==true){
        value={
          quantity: {value: null, comparatorCode: null, unitCode: null, unitName: null},
          codeableConcept:  value={ coding: null, displayContent: null}, valueString: null};
      }else if((this.get('mode')=='results-by-item' && e.isValueChanged == true) || (this.get('mode')=='general') ){
        //항목별검사결과: 수정한 항목만 calculate 일반검사결과: 리스트중에 하나라도 수정했으면 전부 calculate
        if(isPresent(this.get('applyItem'))) {
          value = this.get('applyItem.value');
        } else {
          value = e.valueTypeCode ==='CodeableConcept'? this._setCodeableValueParam(e, now) : e.get('value');
        }
      }else{
        return;
      }

      if(e.isValueChanged != true){
        // calculate 대상 아닌 것 제거
        const tmp={
          isChange: false,
          examinationId: e.examinationId,
          observationResultId: e.observationResultId,
          valueTypeCode: e.valueTypeCode,
          recentObservationResultId: isEmpty(e.recentObservationResult)? null : e.recentObservationResult.observationResultId,
          value:value,
        };
        observationResults.addObject(tmp);
        return;
      }

      const tmp={
        isChange: true,
        examinationId: e.examinationId,
        observationResultId: e.observationResultId,
        valueTypeCode: e.valueTypeCode,
        value:value,
        recentObservationResultId: isEmpty(e.recentObservationResult)? null : e.recentObservationResult.observationResultId
      };
      if(!isEmpty(tmp.value)){
        if(!isEmpty(tmp.value.displayContent)){
          tmp.value.displayContent= tmp.value.displayContent.trim();
        }
        value.valueString= isEmpty(value.valueString)? null: value.valueString;
      }
      observationResults.addObject(tmp);
    });
    return observationResults;

  },
  _setCodeableValueParam(e, now){
    const commentsValue= this.get('commentsValue')==''? null: this.get('commentsValue');
    let value= {
      quantity: {"value":null},
      codeableConcept: isEmpty(get(e, 'value.codeableConcept'))? {} : e.value.codeableConcept,
      valueString: e.isValueChanged? commentsValue: e.get('value.valueString'),
      valueDecimal: isEmpty(e.value)? 0 : e.value.valueDecimal
    };
    if(!isEmpty(e.selectedExamples)){
      value= this._setValueByselectedExamples(e, value, now);
    }else if(!isEmpty(e.selectedExample)){
      //싱글선택
      value= this._setValueByselectedExample(e,value, now);
    }else if(e.isValueChanged && isEmpty(e.selectedExamples) && isEmpty(e.selectedExample)
    && isEmpty(e.fullTextValue) && !isEmpty(e.valueValueString)){
      //Negative 처리 //fullTextValue 수정//있던 정보 초기화할경우//최초입력이 없었던 경우
      value= e.value;
    }else if(isEmpty(e.selectedExamples) && isEmpty(e.selectedExample)
    && isEmpty(e.valueValueString)){
      if( isEmpty(e.fullTextValue)){
        //최초입력이 없었던 경우
        value={
          quantity: { value: null, comparatorCode: null, unitCode: null, unitName: null},
          codeableConcept:  null, valueString:null
        };
      }
      //valueValueString는 기존 저장되있던 값
      value.codeableConcept= {
        coding: e.get('value.codeableConcept.coding'),
        displayContent: isEmpty(e.get('value.codeableConcept.displayContent'))? null : e.get('value.codeableConcept.displayContent')
      };
    }else if(isEmpty(value.codeableConcept.coding) && !isEmpty(value.valueString)){
      //coding 값 선택 없이 valueSting으로 저장할경우
      // value={
      //   quantity: { value: null, comparatorCode: null, unitCode: null, unitName: null},
      //   codeableConcept: null,
      //   valueString:value.valueString
      // };
    }else{
      //저장되있던 coding값 그대로 넘길경우(comments만 수정)
      value.codeableConcept = {
        coding: e.get('value.codeableConcept.coding'),
        displayContent: isEmpty(e.get('value.codeableConcept.displayContent'))? null :e.get('value.codeableConcept.displayContent'),
        // valueString:value.valueString
      };
    }
    return value;
  },
  _setCalculateValue(e){
    let value={};
    switch(e.valueTypeCode){
      case 'Quantity':
        value={
          quantity: {
            // value: numberValue 다 같은 값으로 업데이트됨
            // value: e.isValueChanged? this.get('numberValue'): e.value.quantity.value,
            //value에 저장된값있는지 확인//diff일 경우 '-'
            value: e.value.quantity.value,
            comparatorCode: e.isValueChanged? e.comparatorSelectedItem: e.value.quantity.comparatorCode,
            unitCode: isEmpty(e.examinationUnit)? null: e.examinationUnit.code,
            unitName: isEmpty(e.examinationUnit)? null: e.examinationUnit.name
          },
          codeableConcept: null,
          valueString: e.isValueChanged? e.valueString : e.value.valueString
        };
        break;
      case 'CodeableConcept':
        value= e.value;
        break;
      default:
        break;
    }
    value.valueString= isEmpty(value.valueString)? null: value.valueString;
    return value;
  },

  _addObservationResult(e, value, isChange){
    return {
      isChange: isChange,
      examinationId: e.examinationId,
      observationResultId: e.observationResultId,
      valueTypeCode: e.valueTypeCode,
      // check: e.check,
      recentObservationResultId: isEmpty(e.recentObservationResult)? null: e.recentObservationResult.observationResultId,
      value: {
        quantity: value.quantity,
        codeableConcept: value.codeableConcept,
        valueDecimal: isEmpty(e.value.valueDecimal)? 0 : e.value.valueDecimal,
        valueString: value.valueString,
        valueBool: true,
      },
    };
  },
  _setValueString(item){
    let valueValueString='';
    if(item.value.quantity.comparatorCode !='-' && isPresent(item.value.quantity.comparatorCode)){
      valueValueString= item.value.quantity.comparatorCode + item.value.quantity.value;
    }else{
      valueValueString= item.value.quantity.value;
    }
    return isEmpty(item.value.valueString)? valueValueString: valueValueString+item.value.valueString;
  },
  _catchError(e){
    console.log('error----', e);
    this.set('isChangesLogOpened', false);
    this.showResponseMessage(e);
  }


});