/* eslint-disable no-console */
import $ from 'jquery';
import { later } from '@ember/runloop';
import Mixin from '@ember/object/mixin';
import { inject as service } from '@ember/service';
import { isEmpty } from '@ember/utils';
import { A } from '@ember/array';
import { set } from '@ember/object';

export default Mixin.create({

  toast: service('toast-service'),
  isCurrentLocaleByKr: true,

  onPropertyInit() {
    this._super(...arguments);
    if(this.get('fr_I18nService.currentLocale') !== 'ko-kr') {
      this.set('isCurrentLocaleByKr', false);
    }
    this.set('fileuploadUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'technicalServiceUrl'));
    this.set('tenantId', this.get('co_CurrentUserService').user.tenant.tenantId);
    this.set('hospitalId', this.get('co_CurrentUserService').user.hospital.hospitalId);
    // this.set('hospitalAdditionalInfo', this.get('co_CommonService.hospitalAdditionalInfo'));
  },
  actions: {
    onGridCellClick(e) {
      this.set('focusCellItem', null);
      this.set('focusFieldName', null);
      const field = e.column.field;
      if(field === 'specimenNumber' || field === 'subjectNumber' || field === 'subject.number' || field === 'subject.displayNumber') {
        this.set('focusFieldName', field);
        this.set('focusCellItem', e.item);
      }
    },
    onGridBeforeKeyDown(e) {
      if(isEmpty(this.get('focusCellItem'))) {
        return;
      }
      if(e.originalEvent.ctrlKey && e.originalEvent.keyCode === 67 ) {
        this.copyToClipboard(this.get(`focusCellItem.${this.get('focusFieldName')}`));
      }
    },
  },
  copyToClipboard(content) {
    try {
      const textArea = $('<textarea>').appendTo(`#${this.elementId}`);
      event.preventDefault();
      textArea.val(content).select();
      document.execCommand('copy');
      later(() => {
        textArea.remove();
      });
    } catch(e) {
      console.error(e);
    }
  },
  _setProperty(res){
    //우선순위 progressTypeCode/isAlert/isNeedConsent/isNeedRequest
    let property = '';
    if(res.isAlert){
      property = ` ${this.getLanguageResource('571', 'S', '감염')}`;
    }
    if(res.isNeedConsent){
      property=property + ` ${this.getLanguageResource('11740', 'S', '동의서필요')}`;
    }
    if(res.isNeedRequest){
      property=property + ` ${this.getLanguageResource('17066', 'S', '의뢰서 필요')}`;
    }
    set(res,'property', property);
  },
  getInboxParams(specimenOrder, resultListSelectedItem, resource, purpose){
    const params = A({
      patient: {
        id: resultListSelectedItem.subjectId,
        displayCode: resultListSelectedItem.get('subject.displayNumber'),
        name: resultListSelectedItem.get('subject.name')},
      examination: {
        name: resultListSelectedItem.get('examination.name'),
        issuedDate: this.get('fr_I18nService').formatDate(specimenOrder.orderDate, 'd')},
      // performDate: isEmpty(resultListSelectedItem.get('performers'))? '': this.get('fr_I18nService').formatDate(resultListSelectedItem.get('performers.firstObject.performDatetime'), 'd')},
      encounter:{ id: specimenOrder.encounterId},
      staffs: [{
        actorTypeName: resource,
        actorId:specimenOrder.orderedStaff.id,
        actorName: specimenOrder.orderedStaff.name
      }],
      purpose: purpose,
      defaultMessage: `${resultListSelectedItem.get('examination.name')} ${this.getLanguageResource('12618', 'F', "검사결과가 보고되었습니다. 검사결과를 확인하시기 바랍니다.")}`
    });
    console.log(params);

    return params;
  },

  showToast(type, content, title){
    this.get('toast').toastr({type: type, content: content, title: title,
      option: {
        closeButton: false,
        timeOut: 3000,
        positionClass: 'toast-bottom-center'
      }
    });
  },

  showMessage(caption, messageBoxImage, messageBoxButton, messageBoxFocus, messageBoxText, messageboxInterval){
    const options = {
      'caption': caption,
      'messageBoxImage': messageBoxImage,
      'messageBoxButton': messageBoxButton,
      'messageBoxFocus': messageBoxFocus,
      'messageBoxText': messageBoxText,
      'messageboxInterval': messageboxInterval
    };

    return messageBox.show(this, options);
  },

  showConfirm(caption, messageBoxText){
    const options = {
      'caption': caption,
      'messageBoxButton': 'YesNo',
      'messageBoxImage': 'question',
      'messageBoxText': messageBoxText,
      'messageBoxFocus': 'No'
    };
    return messageBox.show(this, options);
  },

  showToastWarning(content) {
    this.showToast('error', content, '');
  },

  showToastNotify(content) {
    this.showToast('notify', content, '');
  },

  showConfirmSave(){
    return this.showConfirm(this.getLanguageResource('8939', 'F', null, '저장하시겠습니까?'), '');
  },

  showNotSavedConfirm(){
    return this.showConfirm(this.getLanguageResource('9231', 'F', null, '저장하지 않은 데이터가 있습니다.'), this.getLanguageResource('8939', 'F', null, '저장하시겠습니까?'));
  },

  showConfirmDelete(){
    return this.showConfirm(this.getLanguageResource('8929', 'F', null, '삭제하시겠습니까?'), '');
  },

  showConfirmDeletNotSaved(){
    return this.showConfirm(this.getLanguageResource('9426', 'F', null, '이미 작성 된 데이터가 있습니다. 삭제하시겠습니까?'), '');
  },

  showToastSaved() {
    return this.showToast('save', this.getLanguageResource('8942', 'F', null, '저장되었습니다.'), '');
  },

  showToastSaveFail() {
    this.showToast('error', '', this.getLanguageResource('9195', 'F', '', '저장에 실패하였습니다'));
  },

  showToastDeleted() {
    return this.showToast('delete', '', this.getLanguageResource('8944', 'F', null, '삭제되었습니다'));
  },

  showToastCanceled() {
    return this.showToast('save', '', this.getLanguageResource('8943', 'F', null, '취소되었습니다'));
  },

  showToastDeleteFail() {
    this.showToast('error', '', this.getLanguageResource('11756', 'F', '', '삭제에 실패하였습니다'));
  },

  showWarningMessage(message, interval) {
    return this.showMessage(message, 'warning', 'Ok', 'Ok', '', interval);
  },
  showMessagebox(caption, message, type, interval) {
    return this.showMessage(caption, type, 'Ok', 'Ok', message, interval);
  },
  showConfirmMessage(caption, message){
    let messageText = '';
    if(!isEmpty(message)) {
      messageText = message;
    }
    return this.showConfirm(caption, messageText);
  },
  showToastInputData() {
    this.showToast('new', '', this.getLanguageResource('10275', 'F', '', '필수 항목을 입력하세요.'));
  },
  showToastDuplicateData() {
    this.showToast('error', '', this.getLanguageResource('9842', 'F', '', '중복데이터가 있습니다.'));
  },
  showToastCustomMessage(type, message) {
    this.showToast(type, '', message);
  },
  showToastRefresh(title) {
    let contentTitle = '';
    if(!isEmpty(title)) {
      contentTitle = title;
    }
    this.showToast('refresh', this.getLanguageResource('9861', 'F', '', '조회가 완료되었습니다.'), contentTitle);
  },
  showToastNoData() {
    this.showToast('load', '', this.getLanguageResource('9264', 'F', '', '조회된 정보가 없습니다.'));
  },
  showToastErrorOccurred() {
    this.showToast('error', '', this.getLanguageResource('8947', 'F', '', '에러가 발생했습니다.'));
  },
  showToastSearchhWordError() {
    this.showToast('error', '', this.getLanguageResource('10869', 'F', '', '검색어에러'));
  },
  showToastApiError() {
    this.showToast('error', '', this.getLanguageResource('10867', 'F', '', 'api에러'));
  },
  _showError(e) {
    if(e.status === 500) {
      this.showToastApiError();
    } else if(e.status === 400 && !isEmpty(e.responseJSON)) {
      this.showMessagebox('', e.responseJSON.messages[0], 'warning');
    } else {
      this.showToastErrorOccurred();
    }
    console.log('_showError Error::', e);
  },
  _showSaveError(e) {
    if(e.status === 500) {
      this.showToastSaveFail();
    } else if(e.status === 400 && !isEmpty(e.responseJSON)){
      this.showMessagebox(this.getLanguageResource('9195', 'F', null, '저장 실패'), e.responseJSON.messages[0], 'warning');
    } else {
      this.showToastErrorOccurred();
    }
  },
  showResponseMessage(err){
    if (err.status === 400 && !isEmpty(err.responseJSON)) {
      messageBox.show(this, {
        'messageBoxImage' : 'warning',
        'caption': '',
        'messageBoxText' : err.responseJSON.messages[0]
      });
    }else if(err.status === 500){
      // messageBox.show(this, {
      //   'messageBoxImage' : 'warning',
      //   'caption': this.getLanguageResource('8947'),
      //   // 'messageBoxText' : err.responseJSON.messages[0]
      //   'messageBoxText' : ''
      // });
      this.get('toast').toastr({
        type: 'error',
        content: '',
        title: this.getLanguageResource('8947'),
        option: {
          closeButton: false,
          timeOut: 4000,
          positionClass: 'toast-bottom-center'
        }
      });
    }
  }

});