/* eslint-disable max-lines-per-function */
/* eslint-disable no-console */
// import $ from 'jquery';
import Mixin from '@ember/object/mixin';
import { inject as service } from '@ember/service';
import { isEmpty } from '@ember/utils';
// import { next } from '@ember/runloop';
// import { copy } from '@ember/object/internals';
// import EmberObject from '@ember/object';
import { A as emberA } from '@ember/array';

export default Mixin.create({
  model: null,
  globalCurrentUser: null,
  globalPatient: null,
  comments: null,
  initializeTimeVolume: null,
  contentLoaderType: 'spinner',
  isCommentOpen: false,
  commentPopupTarget: null,
  cultureResultService: service('specimen-examination-report-culture-result-management-service'),
  consignmentService: service('specimen-examination-report-consignment-service'),
  uploadService: service('upload-helper-service'),
  btService: service('specimen-examination-report-blood-type-result-service'),
  specimenexaminationreportService: service('specimen-examination-report-service'),


  onPropertyInit() {
    this._super(...arguments);

    this.setStateProperties([
      'model',
    ]);

    if(this.hasState()===false) {

      if(!isEmpty(this.get('co_CurrentUserService.user'))){
        this.set('globalCurrentUser', this.get('co_CurrentUserService.user'));
      }
      if(!isEmpty(this.get('co_PatientManagerService.selectedPatient'))){
        this.set('globalPatient', this.get('co_PatientManagerService.selectedPatient'));
      }
      this.set('comments', {
        isCommentsExpanded: false,
        deptCommentsCount: 0
      });
      this.set('checkinUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'specimencheckin')+'specimen-checkin/v0/');
    }
  },
  actions: {
    onAddButtonClick() {
      //
    },
    onDeleteButtonClick() {
      //
    },
    onSendCvrClick(){
      try {
        console.log('onSendCVRClick---');
        const resultWorkData = this.get('resultWorkData');
        const observationCulturesData = this.get('observationCulturesData');
        if(isEmpty(resultWorkData) || isEmpty(observationCulturesData)) {
          return;
        }
        if(!this.checkGPatientId(this.get('resultWorkData.subjectId'), true)) {
          return;
        }
        // if(resultWorkData.progressStatusCode !== 'Final') {
        //   this.showWarningMessage(this.getLanguageResource('tempkey', 'F', '', '결과 검증된 검사만 CVR전송이 가능합니다.'), 2000);
        //   return;
        // }
        if(observationCulturesData.statusCode !== 'final' && observationCulturesData.statusCode !== 'corrected') {
          this.showWarningMessage(this.getLanguageResource('13243', 'F', '', '결과 검증된 검사만 CVR전송이 가능합니다.'), 2000);
          return;
        }
        const cvrInfo = this.get('cvrInfo');
        this.set('isCvrOpen', true);
        this.set('cvrSendInformation', emberA({
          patient : {
            id: cvrInfo.subjectId,
            displayCode: cvrInfo.subject.displayNumber,
            name: cvrInfo.subject.name
          },
          examination: {
            basedOnTypeCode: 'Specimen',
            basedOnId: cvrInfo.specimenId,
            id: cvrInfo.examination.id,
            name: cvrInfo.examination.name,
            performDate: cvrInfo.performers.get('firstObject.performDatetime')
          },
          encounter: { id: resultWorkData.encounterId },
          smsContent: null,
          staffs: [{
            actorTypeName: this.getLanguageResource('9686', 'F','처방의'),
            actorId: resultWorkData.orderedStaff.id,
            actorName: resultWorkData.orderedStaff.name
          },
            // {actorTypeName:this.getLanguageResource('8898', 'S','진료의'),
            //   actorId: this.get('physicianStaff.id'),
            //   actorName: this.get('physicianStaff.name')}
          ],
          result: null
        }));
      } catch(e) {
        console.log('onSendCvrClick Error::', e);
      }
    },
    onCommentBtnClick(e){
      this.toggleProperty('initializeTimeVolume');
      this.set('isCommentOpen', true);
      this.set('commentPopupTarget', e.originalEvent.currentTarget);
    },
    onCommentOpenedAction(){
      //
    },
    getSendResult(){
      //
    },
  },

  checkGPatientId(subjectId, isShowMessage) {
    const globalPatientInfo = this.get('globalPatient');
    if (!isEmpty(globalPatientInfo)) {
      if (globalPatientInfo.patientId !== subjectId) {
        if(isShowMessage) {
          this.showWarningMessage(this.getLanguageResource('10338', 'F', '', '환자정보를 확인하세요.'), 2000);
        }
        return false;
      } else {
        return true;
      }
    } else {
      if(isShowMessage) {
        this.showWarningMessage(this.getLanguageResource('10338', 'F', '', '환자정보를 확인하세요.'), 2000);
      }
      return false;
    }
  },

  getUnitItem(resultCultures) {
    let unitItem = {};
    unitItem = {title: null, date: null, color: null};

    switch(resultCultures.statusCode) {
      case 'registered':
        // unitItem.title = '접수';
        unitItem.color = '#8dcc1a;';
        break;
      case 'preliminary':
        // unitItem.title = '중간';
        unitItem.color = '#ef9144;';
        break;
      case 'final':
        // unitItem.title = '최종';
        unitItem.color = '#3cb8f5;';
        break;
      case 'corrected':
        // unitItem.title = '수정후보고';
        unitItem.color = '#3cb8f5;';
        break;
      default:
        break;
    }
    unitItem.title = resultCultures.statusName;
    unitItem.date = resultCultures.issuedDatetime;
    return unitItem;

  },

  _getTagProperties(items) {
    let setObj = {};
    const property = {
      classifications: null,
      observationExaminations: null,
      unitWorks: null
    };
    const tagItems = (type) => {
      const retunrItems = items.tagList
        .filter(tag => tag.type === type)
        .map(tag => tag.items);
      return retunrItems.flat();
    };
    if(!isEmpty(items.tagList)){
      property.classifications = tagItems('category');
      property.unitWorks = tagItems('unit');
      property.observationExaminations = tagItems('exam');
    }
    setObj = {
      workListFindConfigurationId: items.workListFindConfigurationId,
      property
    };
    return setObj;
  },

  getHasEditItems() {
    if (this.get('isEditingIdentificationItems') || this.get('isEditingSusceptibilityItems')) {
      this.showWarningMessage(this.getLanguageResource('9231', 'F', '', '저장 되지 않은 데이터가 있습니다.'), 2000);
      return false;
    } else {
      return true;
    }

  },

  getCellsCurrentValue(e) {
    const currentField = e.column.field;
    const arrField = currentField.split('.');
    let currentValue = '';
    if (arrField.length > 1) {
      currentValue = e.item[arrField[0]][arrField[1]];
    } else {
      currentValue = e.item[arrField[0]];
    }
    return currentValue;

  },
  cellChagnedCheck(e) {
    const originValue = this.get('model.selectedCellOriginValue');
    const changedValue = this.getCellsCurrentValue(e);
    if (originValue !== changedValue) {
      return true;
    } else {
      return false;
    }
  },

  hasCustomMethodCode(method) {
    if (method.code.indexOf('9999') > -1) {
      return true;
    } else {
      return false;
    }
  },
  async _getResultWorkData() {
    try {
      let param = {specimenNumber: this.get('specimenNumber')};
      if(isEmpty(this.get('specimenNumber'))) {
        param = {specimenId: this.get('specimenId')};
      }
      const resultWorks = await this.get('cultureResultService').getResultWorkListsSearch(param);
      resultWorks.map(d => {
        let orderComment = '';
        if(!isEmpty(d.specimenOrders)){
          d.specimenOrders.forEach(e=>{
            if(!isEmpty(e.orderComment)){
              orderComment= orderComment + ' ' + e.orderComment;
            }
          });
          const ordersObj = d.specimenOrders[0];
          const issuedDepartmentName = isEmpty(ordersObj.issuedDepartment) ? '' : ordersObj.issuedDepartment.name;
          const departmentName = isEmpty(ordersObj.department) ? '' : ordersObj.department.name;
          d.referredFrom = `${issuedDepartmentName} / ${departmentName} / ${ordersObj.orderedStaff.name}`;
          d.classificationName = ordersObj.classification.name;
          d.orderInfo = `${ordersObj.orderDate.toFormatString(true, false)}, ${ordersObj.orderName}`;
          d.orderComment = orderComment;
          d.encounterId = ordersObj.encounterId;
          d.orderedStaff = ordersObj.orderedStaff;
          d.specimenOrder = ordersObj;
        }
      });
      return resultWorks[0];
    } catch(e) {
      console.log('_getResultWorkData Error::: ', e);
    }
  },

  async _getSpecimenInformation(specimenNumber) {
    try {
      const specimensOverview = await this.get('cultureResultService').getSpecimenCheckInOverview({specimenNumber: specimenNumber});
      console.log('specimensOverview-', specimensOverview);
      specimensOverview.forEach(item => {
        if (item.titleCode === 'Sampling') {
          // this.set('displaySamplingName', item.titleName);
          this.set('displaySamplingName', this.getLanguageResource('7207', 'F', '', '채혈'));
          this.set('displaySamplingDate', this._getDisplayDate(item));
        } else if(item.titleCode === 'Check-In') {
          this.set('displayCheckInName', item.titleName);
          this.set('displayCheckInDate', this._getDisplayDate(item));
        }
      });
    } catch(e) {
      console.log('_getSpecimenInformation Error::: ', e);
    }
  },

  _setPartialBusicessCodes(item) {
    let cvrObj = {};
    switch(item.classificationCode) {
      case 'CVRReason':
        cvrObj = {
          businessCode: item.code,
          name: item.name
        };
        this.get('cvrReasonItemList').addObject(cvrObj);
        break;
      case 'BacterialIdentificationMethod':
        this.get('bacterialMethodItems').addObject(item);
        break;
      case 'MediaCode':
        this.get('mediaItems').addObject(item);
        break;
      case 'BacterialIdentificationInterpretation':
        this.get('interpretationItems').addObject(item);
        break;
      case 'ColonyContent':
        this.get('colonyContentItems').addObject(item);
        break;
      case 'CultureResultExample':
        this.get('resultExampleList').addObject(item);
        break;
      case 'WorkListSearchCode':
        this.get('workListSearchCodeItems').addObject(item);
        break;
      case 'SpecialistPhysician':
        this.get('specialistPhysicianItems').addObject(item);
        break;
      case 'SpecialistPhysicianOpinion':
        this.get('specialistPhysicianOpinionItems').addObject(item);
        break;
      default:
        break;
    }
  },

  _getDisplayDate(info) {
    let returnDate = '';
    info.specimenInformationItems.forEach(d => {
      if (d.displayCode === 'Datetime') {
        returnDate = d.displayDatetime;
      }
    });
    return returnDate;
  },

  observationExamplesByResultRemark(params) {
    return this.get('cultureResultService').getObservationsExamples(params);
  },
  getByteLength(s) {
    if (s === null || s.length === 0) {
      return 0;
    }
    let size = 0;

    for ( let i = 0; i < s.length; i++) {
      size += this.charByteSize(s.charAt(i));
    }

    return size;
  },
  cutByteLength(s, startInd, len) {
    if (s === null || s.length === 0) {
      return 0;
    }
    let size = 0;
    let rIndex = s.length;

    for ( let i = 0; i < s.length; i++) {
      size += this.charByteSize(s.charAt(i));
      if( size === len ) {
        rIndex = i + 1;
        break;
      } else if( size > len ) {
        rIndex = i;
        break;
      }
    }

    // return s.substring(0, rIndex);
    return s.substr(startInd, rIndex);
  },
  charByteSize(ch) {
    if (ch === null || ch.length === 0) {
      return 0;
    }

    const charCode = ch.charCodeAt(0);

    if (charCode <= 0x00007F) {
      return 1;
    } else if (charCode <= 0x0007FF) {
      return 2;
    } else if (charCode <= 0x00FFFF) {
      // return 3;
      return 2;
    } else {
      return 4;
    }
  },
  fnSubString(str,start,size) {
    let lim = 0;
    let pos = 0;
    let beg = 0;
    // let minus = 0;
    const len = this.fnStrlen(str);
    // 시작위치까지 skip
    let i;
    for(i=0;pos<start;i++) {
      pos += str.charCodeAt(i) > 128 ? 2 : 1;
    }
    beg = i;
    // 시작위치에서 길이만큼 잘라내는 로직
    for (let j=beg; j<len; j++) {
      lim += str.charCodeAt(j) > 128 ? 2 : 1;
      if (lim > size) {
        return str.substring(beg,j);
      }
    }
  },
  fnStrlen(str) {
    let len = 0;
    for(let i=0;i<str.length;i++) {
      len += str.charCodeAt(i) > 128 ? 2 : 1;
    }
    return len;
  },
  _pluck(objs, name) {
    const sol = [];
    for(const i in objs){
      if(objs[i].hasOwnProperty(name)){
        sol.push(objs[i][name]);
      }
    }
    return sol;
  },

});