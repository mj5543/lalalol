/* eslint-disable max-lines-per-function */
/* eslint-disable no-console */
import $ from 'jquery';
import moment from 'moment';
import Mixin from '@ember/object/mixin';
import { inject as service } from '@ember/service';
import { isEmpty, isPresent } from '@ember/utils';
import { get, set } from '@ember/object';
// import { next } from '@ember/runloop';
// import { copy } from '@ember/object/internals';
// import EmberObject from '@ember/object';
// import { A as emberA } from '@ember/array';

export default Mixin.create({
  model: null,
  globalCurrentUser: null,
  globalPatient: null,
  contentLoaderType: 'spinner',
  isOtherTextDisabled: true,
  verifyGridItems: null,
  isRecordViewerOpen: false,
  isRecordDisabled: true,
  calendarSelectedDate: null,
  isSettingOpen: false,
  apiService: service('specimen-examination-report-verification-service'),

  onPropertyInit() {
    this._super(...arguments);

    this.setStateProperties([
      'model',
      'selectedFromDate',
      'selectedToDate',
      'selectedDate',
      'basicGridItems',
    ]);

    if(this.hasState()===false) {

      this.set('model', {
        selectedComment: null,
        selectedRecommend: null,
        selectedAdditional: null,
        textComment: null,
        textRecommend: null,
        textAdditional: null,
        orderExaminationsNames: null,
        orderExaminationsNamesText: null,
        check: {
          isCalibration: false,
          isQualityControl: false,
          isDelta: false,
          isPanic: false,
          isRecheck: false,
          isOthers: false,
          othersComment: null,
        },
        certificationNumber: null,
        institutionNumber: null,
        phoneNumber: null,
        reportFooter: null,
        address: null,
      });
      if(!isEmpty(this.get('co_CurrentUserService.user'))){
        this.set('globalCurrentUser', this.get('co_CurrentUserService.user'));
      }
      if(!isEmpty(this.get('co_PatientManagerService.selectedPatient'))){
        this.set('globalPatient', this.get('co_PatientManagerService.selectedPatient'));
      }
      const displayDate = new Date(this.get('co_CommonService').getNow());
      this.set('selectedFromDate', displayDate);
      this.set('selectedToDate', displayDate);
      this.set('selectedDate', displayDate);
      this.set('calendarSelectedDate', displayDate);
      this.set('userSelectedDate', displayDate);
      const userInfoSets = this.get('globalCurrentUser');
      let hospitalId = null;
      let tenantId=null;
      if(!isEmpty(userInfoSets)){
        hospitalId = userInfoSets.hospital.hospitalId;
        tenantId = userInfoSets.tenant.tenantId;
      }
      this.set('fileuploadUrl', this.get('fr_HostConfigService').getEnvConfig('ServerCallConfig', 'technicalServiceUrl'));
      this.set('fileUrl', this.get('fileuploadUrl')+'file/v4/'+tenantId+'/'+hospitalId+'/view');
    }
  },
  actions: {
    onSettingClick() {
      this.set('isSettingOpen', true);
    },
    onSaveClick() {
      this._setSettingInfo();
    },
    onOpendPopup() {
      //
    },
    onPopupClosed() {
      this._getSettingInfo();
    },
    onOpinionChanged(e) {
      const text = this.get('model.textComment');
      let addText = '';
      if(!isEmpty(text)) {
        addText = `${text} \r\n${e.item.name} `;
      } else {
        addText = e.item.name;
      }
      this.set('model.textComment', addText);
    },
    onCommentChanged(e) {
      const text = this.get('model.textRecommend');
      let addText = '';
      if(!isEmpty(text)) {
        addText = `${text}  \r\n${e.item.name} `;
      } else {
        addText = e.item.name;
      }
      this.set('model.textRecommend', addText);
    },
    onAmendedChanged(e) {
      const text = this.get('model.textAdditional');
      let addText = '';
      if(!isEmpty(text)) {
        addText = `${text} \r\n${e.item.name} `;
      } else {
        addText = e.item.name;
      }
      this.set('model.textAdditional', addText);
    },
    onOtherCheckChanged(e) {
      if(e.checked) {
        this.set('isOtherTextDisabled', false);
      } else {
        this.set('isOtherTextDisabled', true);
      }
    },
    onRecordViewerOpen() {
      this.set('isRecordViewerOpen', true);
    },
  },
  lpad(s, c, n) {
    if (! s || ! c || s.length >= n) {
      return s;
    }
    let retunrS = s;
    var max = (n - s.length)/c.length;
    for (var i = 0; i < max; i++) {
      retunrS = c + s;
    }
    return retunrS;
  },

  isValidDate(inYmd) {
    // const inYmd = moment(new Date(ymd)).format('YYYYMMDD');
    var year = inYmd.substring(0,4);
    var month = inYmd.substring(4,6);
    var day = inYmd.substring(6,8);

    var d = new Date(year, month-1, day);

    if (d.getFullYear() == year && this.lpad(d.getMonth()+1,2,'0') == month && this.lpad(d.getDate(),2,'0') == day) {
      return true;
    }

    return false;
  },

  isPeriodDuplicationDate(fromYmd, toYmd, tarFromYmd, tarToYmd) {

    var rtn = '';
    // 기간 중복 여부
    if(this.isValidDate(fromYmd) && this.isValidDate(toYmd) && this.isValidDate(tarFromYmd) && this.isValidDate(tarToYmd)) {
      if(fromYmd > toYmd) {
        rtn = 'The fromYmd is greater than the toYmd.';
      } else if(tarFromYmd > tarToYmd) {
        rtn = 'The tarFromYmd is greater than the tarToYmd.';
      // } else if(tarFromYmd > toYmd && tarToYmd < toYmd){
      } else if((fromYmd <= tarFromYmd && tarFromYmd <= toYmd)
      || (fromYmd <= tarToYmd && tarToYmd <= toYmd)
      || (tarFromYmd <= fromYmd && toYmd <= tarToYmd)){
        rtn = 'Y';
      } else {
        // 중복되지 않음
        rtn = 'N';
      }
    } else {
      rtn = 'Input data is not valid.';
    }
    return rtn;
  },

  _checkDate() {
    const selectedGridItem = this.get('selectedGridItem');
    if(isEmpty(selectedGridItem)) {
      return;
    }
    let returnVal = false;
    this.get('settingItemsSource').forEach((d, ind) => {
      if(this.get('selectedRowIndex') !== ind) {
        if(returnVal === true) {
          return;
        }
        const rMsg = this.isPeriodDuplicationDate(moment(new Date(selectedGridItem.fromDate)).format('YYYYMMDD'), moment(new Date(selectedGridItem.toDate)).format('YYYYMMDD'), moment(new Date(d.fromDate)).format('YYYYMMDD'), moment(new Date(d.toDate)).format('YYYYMMDD'));
        if(rMsg === 'Y') {
          returnVal = true;
        }
        console.log('rMsg---', rMsg);
      }
    });
    return returnVal;
  },
  async _setSettingInfo() {
    try {
      const settingItemsSource = this.get('settingItemsSource');
      if(isPresent(settingItemsSource)) {
        settingItemsSource.forEach(d => {
          const toDate = isEmpty(d.toDate) ? new Date('9999-12-31 00:00:00'): d.toDate;
          set(d, 'toDate', toDate);
        });
      }
      const settingData = {
        settingOptions: {
          print: {
            certificationNumber: this.get('model.certificationNumber'),
            institutionNumber: this.get('model.institutionNumber'),
            address: this.get('model.address'),
            phoneNumber: this.get('model.phoneNumber'),
            reportFooter: this.get('model.reportFooter'),
            imageInfomations: settingItemsSource,
          },
        }
      };
      const hospitalId = this.get('globalCurrentUser.hospital.hospitalId');
      // await this.get('co_PersonalizationService').setSettingInfo(`verification-report-print`, JSON.stringify(settingData), '종합검증보고서조회 설정 저장');
      await this.get('co_CommonService').setConfigurationSettingInfo('HOSPITAL', hospitalId, `verification-report-print`, JSON.stringify(settingData), '종합검증보고서조회 설정 저장');
      this.showToastSaved();
      this.set('isSettingOpen', false);
    } catch(e) {
      console.log('_setSettingInfo Error::', e);
    }
  },

  async _getSettingInfo() {
    try {
      // const result = await this.get('co_PersonalizationService').getSettingInfo(`verification-report-print`);
      const hospitalId = this.get('globalCurrentUser.hospital.hospitalId');
      const result = await this.get('co_CommonService').getConfigurationSettingInfo('HOSPITAL', hospitalId, 'verification-report-print');
      this.set('settingResult', result);
      this.set('certificationInfo', null);
      if(!isEmpty(result.settingValue)) {
        this.set('settingValue', JSON.parse(get(result, 'settingValue')));
        const settingValue = JSON.parse(get(result, 'settingValue'));
        const printOption = settingValue.settingOptions.print;
        this.set('model.certificationNumber', printOption.certificationNumber);
        this.set('model.institutionNumber', printOption.institutionNumber);
        this.set('model.address', printOption.address);
        this.set('model.phoneNumber', printOption.phoneNumber);
        this.set('model.reportFooter', printOption.reportFooter);
        if(!isEmpty(printOption.imageInfomations)) {
          const today = moment(new Date(this.get('co_CommonService').getNow())).format('YYYYMMDD');
          printOption.imageInfomations.map(d => {
            if(today >= moment(new Date(d.fromDate)).format('YYYYMMDD') && today <= moment(new Date(d.toDate)).format('YYYYMMDD')) {
              this.set('certificationInfo', d);
            }
            if(moment(new Date(d.toDate)).format('YYYY-MM-DD').toString() === '9999-12-31') {
              d.toDate = null;
            }
            d.isRowEditing = false;
          });
          this.set('settingItemsSource', printOption.imageInfomations);
        }
        console.log('printOption---', printOption);
      }
    } catch(e) {
      console.log('_getSettingInfo Error::', e);
    }
  },

  _setVerifyGrid() {
    const selectedExaminationItems = this.get('examinationGrid').selectedItems;
    if(isEmpty(selectedExaminationItems)) {
      return;
    }
    const verifyGridItems = $.extend(true, [], this.get('verifyGridItems'));
    const orderExaminationsNames = $.extend(true, [], this.get('model.orderExaminationsNames'));
    selectedExaminationItems.forEach(item => {
      const sameItem = verifyGridItems.find(d => d.checkInId === item.checkInId && d.examination.id === item.examination.id);
      const sameOrderExamanation = orderExaminationsNames.find(d => d === item.orderExamination.name);
      if(isEmpty(sameItem)) {
        verifyGridItems.addObject(item);
      }
      if(isEmpty(sameOrderExamanation)) {
        orderExaminationsNames.push(item.orderExamination.name);
      }
    });
    const verifyItems = this._setRearrangeVerifyItems(verifyGridItems);
    this.set('verifyGridItems', verifyItems);
    this.set('model.orderExaminationsNames', orderExaminationsNames);
    this.set('model.orderExaminationsNamesText', orderExaminationsNames.join(', '));
  },

  checkGPatientId(subjectId) {
    const globalPatientInfo = this.get('globalPatient');
    if (!isEmpty(globalPatientInfo)) {
      if (globalPatientInfo.patientId !== subjectId) {
        this.showWarningMessage(this.getLanguageResource('10338', 'F', '', '환자정보를 확인하세요.'), 2000);
        return false;
      } else {
        return true;
      }
    } else {
      this.showWarningMessage(this.getLanguageResource('10338', 'F', '', '환자정보를 확인하세요.'), 2000);
      return false;
    }
  },
  getSearchParamsDate() {
    return new Date(this.get('selectedDate').getFullYear(), this.get('selectedDate').getMonth(), this.get('selectedDate').getDate()).toFormatString();
  },
  getSearchParamsCalendarDate() {
    return new Date(this.get('calendarSelectedDate').getFullYear(), this.get('calendarSelectedDate').getMonth(), this.get('calendarSelectedDate').getDate()).toFormatString();
  },
  getParamsDate(date) {
    return new Date(date.getFullYear(), date.getMonth(), date.getDate()).toFormatString();
  },

  dataFieldsReset() {
    // this.set('selectedDate', null);
    this.set('model.selectedComment', null);
    this.set('model.selectedRecommend', null);
    this.set('model.selectedAdditional', null);
    this.set('model.textComment', null);
    this.set('model.textRecommend', null);
    this.set('model.textAdditional', null);
    this.set('model.check.isCalibration',true);
    this.set('model.check.isQualityControl', true);
    this.set('model.check.isDelta', true);
    this.set('model.check.isPanic', true);
    this.set('model.check.isRecheck', true);
    this.set('model.check.isOthers', false);
    this.set('isOtherTextDisabled', true);
    this.set('model.check.othersComment', null);
    this.set('model.orderExaminationsNames', []);
    this.set('model.orderExaminationsNamesText', null);
  },
  async _getRecordSummaryViews(id) {
    try {
      let writerInfo = null;
      const result = await this.getList(this.get('recordViewerUrl') + `integration-documents?originId=${id}`);
      if(!isEmpty(result) && !isEmpty(result.originalDocumentSummaries)){
        const hasSignData = result.originalDocumentSummaries[0].footers.find(d => d.isWriterSignImage === true);
        if(isPresent(hasSignData)) {
          writerInfo = hasSignData;
        }
      }
      this.set('writerInfo', writerInfo);
    } catch(e) {
      console.log(e);
    }
  },


  _eachItemsSetting(result) {
    this.set('isRecordDisabled', true);
    this.set('selectedDate', result.verificationDate);
    if(!isEmpty(result.statusCode) && (result.statusCode.code === 'final' || result.statusCode.code === 'amended')) {
      this.set('isRecordDisabled', false);
    }
    this.set('printOriginId', result.id);
    if(isPresent(result.id)) {
      this._getRecordSummaryViews(result.id);
    }
    // this.set('model.selectedComment', result.interpretationComment);
    // this.set('model.selectedRecommend', result.recommentation);
    // this.set('model.selectedAdditional', result.additionalReport);
    this.set('model.textComment', result.interpretationComment);
    this.set('model.textRecommend', result.recommentation);
    this.set('model.textAdditional', result.additionalReport);
    if(!isEmpty(result.verificationItemRemark)) {
      this.set('model.orderExaminationsNames', result.verificationItemRemark.split(', '));
      this.set('model.orderExaminationsNamesText', result.verificationItemRemark);
    }
    this.set('model.check.othersComment', result.check.othersComment);
    // result.verificationWorklist.map(item => {
    //   item.regInfo = this._setRegInfo(item);
    // });
    if(!isEmpty(result.interpretatedResults)) {
      result.interpretatedResults.map(item => {
        item.regInfo = this._setRegInfo(item);
        if(!isEmpty(item.subjectReferenceRange) && (item.subjectReferenceRange.indexOf('\n') > -1)) {
          item.subjectReferenceRangeTooltip = item.subjectReferenceRange.replace(/\n|\r\n/giu, '<br>');
          item.isReplaceSubjectReferenceRange = true;
        }
      });
      const verifyItems = this._setRearrangeVerifyItems(result.interpretatedResults);
      this.set('verifyGridItems', verifyItems);
    }
    if(result.statusCode === null || result.statusCode === 'waiting') {
      return;
    }
    this.set('model.check.isCalibration', result.check.isCalibration);
    this.set('model.check.isQualityControl', result.check.isQualityControl);
    this.set('model.check.isDelta', result.check.isDelta);
    this.set('model.check.isPanic', result.check.isPanic);
    this.set('model.check.isRecheck', result.check.isRecheck);
    this.set('model.check.isOthers', result.check.isOthers);
    if(result.check.isOthers) {
      this.set('isOtherTextDisabled', false);
    }
    // this.set('basicGridItems', result.verificationWorklist);
  },
  _setRearrangeVerifyItems(dataList) {
    dataList.sort(function(a, b) {
      let returnVal = 0;
      if(a.checkInDatetime > b.checkInDatetime) {
        returnVal = -1;
      } else {
        returnVal = a.checkInDatetime < b.checkInDatetime ? 1 : 0;
      }
      return returnVal;
    });
    const groupList = this.groupBy(dataList, data => data.checkInId);
    const tempList = [];
    const uniqCheckInList = dataList.uniqBy('checkInId');
    uniqCheckInList.forEach(d => {
      const parts = groupList.get(d.checkInId);
      parts.forEach(g => {
        tempList.push(g);
      });
    });
    console.log('tempList==', tempList);
    return tempList;

  },
  _setRegInfo(item) {
    const regInfo = this.get('fr_I18nService').formatDate(item.checkInDatetime, 'g')
    + ' ['+ item.classification.abbreviation + '] [' + item.orderExamination.abbreviation +']';
    return regInfo;
  },
  groupBy(list, keyGetter) {
    const map = new Map();
    list.forEach((item) => {
      const key = keyGetter(item);
      const collection = map.get(key);
      if (!collection) {
        map.set(key, [item]);
      } else {
        collection.push(item);
      }
    });
    return map;
  },

});