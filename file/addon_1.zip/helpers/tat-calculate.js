import { isEmpty } from '@ember/utils';
import { helper } from '@ember/component/helper';

export function tatCalculate(params) {
  if(isEmpty(params[0]) || isEmpty(params[1])){
    return false;
  }
  if((params[1].getTime()- new Date(params[0]).getTime())/24/60/1000/60 > 1){
    //1일 경과
    return true;
  }else{
    return false;
  }
}

export default helper(tatCalculate);
