import { helper } from '@ember/component/helper';

export function specimenexaminationreportFoldSearch([type]) {
  return type ? 'close' : '';
}


export default helper(specimenexaminationreportFoldSearch);
